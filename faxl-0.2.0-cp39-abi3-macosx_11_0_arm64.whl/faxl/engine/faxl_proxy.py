# Vendored engine module (faxl_proxy.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl caching proxy — an OpenAI-compatible /v1/chat/completions endpoint that
sits between an agent (OpenClaw, or any OpenAI client) and Granite, and does the
prefill caching in the middle.

EXACT-TIER LOOKUP (docs/plan-exact-tier-productionisation.md, implements the
boxcar decision docs/boxcar-ladder-result.md §7): a hit requires IDENTITY,
similarity is RETRIEVAL. Per request:
  1. Build the prompt (chat template) from the messages.
  2. Compute the prompt's polynomial prefix-hash array (one O(N) pass,
     ~0.031µs/token measured — no ESN on the lookup path).
  3. For each scheduled checkpoint position, deepest first: look up the
     exact-tier index by prefix hash; on a hit, CONFIRM by comparing the
     stored token prefix byte-for-byte (collision belt-and-braces; outcome
     logged per hit).
     - CONFIRMED: load that checkpoint's recurrent state, prefill ONLY the
       tail beyond it. (identical prefix -> identical state, F3)
     - no confirmed hit: prefill the whole prompt cold. NO cosine fallback —
       near-dup resume serves stale output (semantic-reuse falsification).
  4. CHECKPOINT the resulting state at scheduled positions (blob on disk),
     registering: prefix hash + token prefix (content-addressed, write-once)
     always; an ESN/UltraDim similarity key ONLY at >= KEY_MIN_TOKENS=1025
     (c4 alive, 4-band key complete) — similarity keys serve retrieval and
     near-miss telemetry, never the hit decision.
  5. Return an OpenAI-shaped response.

The old cosine walk (SNAP + tail floors) was REMOVED 2026-08-15 (audit D9):
dead code with no caller. Measured record: wrong-prefix hits 308/420 at SNAP
0.6 (157 at 0.96), rejects 31/135 byte-identical replays
(docs/boxcar-e3.jsonl). It lives in git history.

So: kill the agent, restart it, give it a similar task -> the proxy finds the
prior state and resumes warm instead of cold. That is the cost win, and the
service.

Run:   python3 integration/faxl_proxy.py            (serves on :8767)
Point an OpenAI client at http://faxl.localhost:8767/v1 with any api key.
Console: http://faxl.localhost:8767/console  (FAXL_PORT overrides the port).
Requires: MLX, and the faxl + ultradim wheels (see QUICKSTART.md).
"""
import base64
import hashlib
import json
import queue as _q
import subprocess
import sys
import re
import os
from dataclasses import asdict
import atexit
import threading
import time
import uuid

from flask import (Flask, Response, copy_current_request_context, g,
                   jsonify, make_response, redirect, request)
# A chat template's own refusal (transformers' raise_exception) is the client's
# conversation; a template that does not compile is not (Halo-5w4.35).
from jinja2.exceptions import (TemplateError as _TemplateError,
                               TemplateSyntaxError as _TemplateSyntaxError)
# The compiled cache core. Absent = the proxy cannot cache; fail LOUD at import
# rather than silently degrading to a pass-through nobody notices.
try:
    import faxl
except ImportError as _e:
    faxl = None
    print(f"[faxl] FATAL: the 'faxl' wheel is not installed ({_e})", flush=True)

# Imported here, not with the other faxl.engine imports below: BLOB_DIR
# and STORE_CAP_GB are module-level constants evaluated further down, and the
# backend name has to be known BEFORE the mlx imports, which are gated on it.
from faxl.engine import faxl_config
from faxl.engine import client_compat

# THE BACKEND AND THE MODEL ARE RESOLVED ONCE, HERE, and every later use reads
# these names -- never os.environ again. They live in ~/.faxl/config.json
# (written by the console, read by faxl_start.sh); FAXL_BACKEND / FAXL_MODEL
# still override, and the boot line says which one won, because "why is it
# on exo" is a support question whose answer is usually "the env".
_CFG = faxl_config.describe()
_BACKEND_NAME = _CFG["backend"]["value"]

# MLX IS IMPORTED ONLY FOR THE BACKENDS WHOSE PROXY PATH USES IT (2026-09-22,
# stage 2 chunk 1: this module is vendored from faxl-core to the Mac AND the
# Linux wheel). mlx runs the model; exo runs it on the cluster but this
# process still loads the tokenizer and derives the cache family through
# mlx_lm. Any other backend (vllm) must import this module on a machine that
# has no mlx at all, so the names below are bound to _mlx_only guards there:
# reaching one is a RuntimeError naming the path and the backend, never an
# ImportError three frames from the cause and never a silent substitute.
_MLX_BACKENDS = ("mlx", "exo")


def _mlx_only(what):
    """A callable that refuses: `what` is an mlx-only path on this backend."""
    def _refuse(*_a, **_kw):
        raise RuntimeError(
            f"faxl_proxy: {what} is an mlx-only path, reached on backend "
            f"{_BACKEND_NAME!r}. This backend has no implementation of it yet "
            f"-- route it through the execution backend.")
    _refuse.__name__ = _refuse.__qualname__ = f"mlx_only[{what}]"
    return _refuse


class _MlxOnlyModule:
    """Stands in for `mx` off mlx: any attribute access refuses, loudly."""

    def __getattr__(self, attr):
        _mlx_only(f"mlx.core.{attr}")()


if _BACKEND_NAME in _MLX_BACKENDS:
    import mlx.core as mx
    # Register out-of-tree mlx_lm model loaders faxl carries (e.g. Ling's
    # bailing_hybrid = KDA+MLA+MoE). No-op for models mlx_lm already knows;
    # injects into sys.modules so `mlx_lm.load` resolves them without patching
    # site-packages.
    try:
        from faxl.engine import mlx_models as _faxl_mlx_models
        _faxl_mlx_models.register()
    except Exception as _e:  # never block startup on an optional loader
        print(f"[faxl] mlx_models.register skipped: {_e}", flush=True)
    from mlx_lm import load
    from mlx_lm.models.cache import (make_prompt_cache, save_prompt_cache,
                                     load_prompt_cache, can_trim_prompt_cache,
                                     trim_prompt_cache)
    from mlx_lm.generate import generate_step
    from mlx_lm.sample_utils import make_sampler
else:
    mx = _MlxOnlyModule()
    load = _mlx_only("mlx_lm.load")
    # The mlx_lm cache functions stay bound to refusals for any code that
    # still reaches for them by name. The REQUEST PATH does not: it goes
    # through CACHE (below), which every backend implements.
    make_prompt_cache = _mlx_only("mlx_lm make_prompt_cache")
    save_prompt_cache = _mlx_only("mlx_lm save_prompt_cache")
    load_prompt_cache = _mlx_only("mlx_lm load_prompt_cache")
    can_trim_prompt_cache = _mlx_only("mlx_lm can_trim_prompt_cache")
    trim_prompt_cache = _mlx_only("mlx_lm trim_prompt_cache")
    generate_step = _mlx_only("mlx_lm generate_step")
    make_sampler = _mlx_only("mlx_lm make_sampler")


# ------------------------------------------------------------------ CACHE SEAM
# THE REQUEST PATH TALKS TO `CACHE`, NOT TO mlx_lm (2026-09-25, stage B of
# docs/plans/linux-wheel-handoff.md).
#
# Until now the eight cache operations in the request path were mlx_lm
# functions imported at module top, bound to loud refusals on any other
# backend. That made the shared proxy importable off mlx but not USABLE off
# mlx: FAXL_BACKEND=vllm booted and then raised on the first request, which is
# a stub in the sense docs/Rules.md forbids.
#
# Everything the request path needs from a cache engine is named here. The
# generic path passes and receives PLAIN PYTHON LISTS of token ids; a backend
# that wants framework arrays (mlx) wraps them itself, so no `mx.array` is
# left in the shared path.
class CacheOps:
    """What the request path needs of a cache engine. One subclass per line.

    OPTIONAL MEMBERS (Halo-5w4.43). The request path also reads these with
    getattr/hasattr and behaves as noted when an object lacks one, so they
    are part of the interface: adding one to a backend changes what the
    proxy does. Read from CACHE (the cache engine) or BACKEND (the execution
    backend); on mlx and exo CACHE is an MlxCacheOps, on vLLM CACHE is the
    backend itself.

    CACHE.deferred_saves (bool): checkpoints are recorded during prefill and
        executed with generation in one call (DEFERRED_CACHE; vLLM).
    CACHE.last_finish_reason() -> str or None: an engine-reported "length"
        (a length bound cut the reply: the request's cap or the context
        window) overrides the proxy's own stop/length reading; absent: the
        proxy's reading stands.
    BACKEND.prefill_with_images(ids, cache, images, start): used, when
        BACKEND.accepts_images is true, to prefill a prompt with pictures.
    BACKEND.max_images_per_request (int): more pictures than this is a 400
        (_image_request_refusal); absent: no per-request cap.
    BACKEND.context_window(ids, images) -> (prompt_tokens, max_model_len):
        a prompt with no room to generate is a 400 (_context_length_refusal);
        absent: no window check here.
    BACKEND.console_stats() -> dict: the console's backend panel; absent:
        the panel shows nothing for it.
    BACKEND.env_record() -> dict: the backend's runtime identity in the
        evidence env row (evidence mode).
    BACKEND.begin_evidence_request(identity), last_evidence, last_report,
        gen_timing: evidence mode's per-request engine records.

    Not optional, though read the same way elsewhere: BACKEND.accepts_images
    is read directly for every request that carries pictures (the text-only
    refusal), so every backend has it; on backends outside mlx and exo,
    BACKEND.tokenizer, snapshot_path and checkpoint_grid are read at boot.
    This class's supports_images is not read by the request path.
    """

    #: directory name under the faxl store for this backend's blobs
    store_name = "mlx"
    #: recorded in the telemetry identity; a blob written by one format is
    #: never loadable by another, so it is part of the store's identity
    cache_format = "mlx_safetensors_v1"
    #: whether this backend can answer a request carrying images
    supports_images = True

    def make(self, model):
        raise NotImplementedError

    def load(self, blob):
        raise NotImplementedError

    def save(self, blob, cache):
        raise NotImplementedError

    def can_trim(self, cache):
        raise NotImplementedError

    def trim(self, cache, n):
        raise NotImplementedError

    def prefill(self, ids, cache, start=0, images=None, cancel=None):
        """Fold ids[start:] into `cache`. `ids` is a plain list.

        cancel() is polled per segment where the backend supports it, so a
        stop lands inside a long prefill rather than after it."""
        raise NotImplementedError

    def generate(self, ids, cache, max_tokens, on_token=None, cancel=None):
        """Return (out_ids, t_first_token). `ids` is the FULL prompt as a
        list; a backend that only needs the last token takes it itself.

        on_token(id) is called per decoded token, for streaming; cancel() is
        polled per token so a stop lands within one token's decode rather
        than at the end of the answer. Both optional."""
        raise NotImplementedError

MODEL = _CFG["model"]["value"]
if _BACKEND_NAME == "exo":
    # exo knows models by hub id only; a path here (an mlx model directory
    # left in the config) is how a proxy died on boot with "Repo id must be
    # in the form 'namespace/repo_name'". Name it, if it can be named.
    _hub = faxl_config.hub_id(MODEL)
    if _hub != MODEL:
        print(f"model {MODEL} -> {_hub} (exo takes a hub id)", flush=True)
        MODEL = _hub
EXO = faxl_config.exo_settings()
print(f"backend={_BACKEND_NAME} ({_CFG['backend']['source']}) "
      f"model={MODEL} ({_CFG['model']['source']}) "
      f"config={_CFG['path']}", flush=True)

# ON MLX THE WEIGHTS MUST ALREADY BE ON THIS MAC (2026-09-21). mlx_lm.load and
# mlx_vlm.load treat a hub id they cannot find locally as "download it", and
# they say nothing while they do: a switch left MiniMax-M2.7 (~130 GB)
# configured on mlx and this process spent the afternoon fetching it onto one
# Mac, the console dark the whole time. So the model is resolved HERE to the
# directory it loads from (faxl_config.local_model_dir: the HF cache, then
# exo's ~/.exo/models copy, weights complete), and the loaders are handed
# that path -- a hub id whose weights only exo's directory holds used to be
# fetched again into the HF cache. Not here at all: a loud line and exit 3,
# unless FAXL_ALLOW_DOWNLOAD=1 (a developer) or it is the shipped default
# (under 6 GB, fetched once on a fresh install).
_LOAD_FROM = MODEL
if _BACKEND_NAME == "mlx":
    _here = faxl_config.local_model_dir(MODEL)
    if _here:
        _LOAD_FROM = _here
        if _here != MODEL:
            print(f"model {MODEL} -> {_here} (on this Mac)", flush=True)
    elif os.environ.get("FAXL_ALLOW_DOWNLOAD") == "1":
        print(f"!! FAXL_ALLOW_DOWNLOAD=1: {MODEL} is not on this Mac and IS "
              f"BEING DOWNLOADED now -- the proxy answers when it is done",
              flush=True)
    else:
        # BATTERIES NOT INCLUDED (2026-09-22). faxl ships without weights, and
        # a fresh install has none -- not even the smallest rung, which is
        # still a 2.9 GB download. This used to be two branches: fetch the
        # shipped default unasked (a 64 GB Mac would now pull 36 GB before
        # the console appeared), or exit 3. Both were wrong, and exit 3 was
        # the worse of the two: the CONSOLE IS SERVED BY THIS PROCESS, so
        # exiting here takes down the very page the person would use to
        # choose a model. That is the 2026-09-21 incident's "console dark"
        # symptom arriving by a different road.
        #
        # So: come up WITHOUT a model. The proxy serves the console, the
        # welcome page shows what this Mac should run and what each option
        # would download (faxl_config.recommend_models), and the person
        # picks. /v1 answers 503 with that same sentence until they do.
        # Nothing is downloaded as a side effect of starting, ever.
        _LOAD_FROM = None
        print(f"no model yet: {MODEL} is not on this Mac. faxl does not "
              f"download one as a side effect of starting -- open the "
              f"console and pick one (it will say what fits and what it "
              f"costs). Config: {_CFG['path']}", flush=True)
# THE STORE FOLLOWS THE BACKEND (2026-09-25). This was hardcoded "mlx", so a
# vllm proxy would have written its blobs into the mlx store and then failed to
# load them: a blob's format is part of its identity. The name is resolved from
# the backend here because BLOB_DIR is needed long before the cache engine is
# built; CacheOps.store_name carries the same value and is asserted against
# this at boot (see the CACHE selection below).
_STORE_NAMES = {"mlx": "mlx", "exo": "mlx", "vllm": "vllm"}
if _BACKEND_NAME not in _STORE_NAMES:
    raise RuntimeError(
        f"faxl_proxy: backend {_BACKEND_NAME!r} has no store name. A store "
        f"name is part of a checkpoint's identity, so it is declared here "
        f"rather than defaulted: add it to _STORE_NAMES.")
STORE_NAME = _STORE_NAMES[_BACKEND_NAME]
# Trimming means shortening a stored cache to a shallower position. mlx can
# (mlx_lm's can_trim_prompt_cache decides per model family); the vllm seam
# cannot -- it records a plan and the connector restores at one confirmed
# position, so there is nothing to shorten. Declared, and checked against the
# cache engine's own can_trim() at boot.
_TRIMMABLE_BY_BACKEND = {"mlx": None, "exo": None, "vllm": False}
BLOB_DIR = faxl_config.store_dir(STORE_NAME)
# THE PHOTO STORE (AM 2026-10-02). A second pool, with its own directory and
# its own cap, for checkpoints whose prompt carried an image. See
# faxl_config.photo_store_dir for why the two must not share: photo entries are
# numerous, small and seldom re-read, text entries are large and exist to be
# resumed, and one scored pool let a camera-roll burst evict the conversation
# prefixes that were about to be used.
#
# One Index, two directories. The ladder, the confirm, the grid and the
# serialiser are identical for both -- what differs is only where the blob
# lands and which cap it is swept against -- so splitting the Index would mean
# two copies of the part that must never diverge.
PHOTO_BLOB_DIR = faxl_config.photo_store_dir(STORE_NAME)
PHOTO_CAP_GB = faxl_config.photo_cap_gb()
# Both pools, deduplicated: a deployment that points photo_blob_dir at the same
# directory as blob_dir is one pool again, and every sweep must then visit it
# ONCE or it double-counts the bytes it frees.
_POOL_DIRS = tuple(dict.fromkeys(
    (os.path.abspath(BLOB_DIR), os.path.abspath(PHOTO_BLOB_DIR))))
# FAXL_DB: the user-managed directory for the PERSISTENT UltraDim key store + the
# key→blob index. A cache is not a database if the user cannot say where it lives.
# Default is a stable named dir (NOT a temp dir) so restarts reload the same store.
# CONFIG, NOT JUST ENV (AM 2026-10-02). ONE index serves BOTH pools, so the DB
# must not be a child of either one: defaulting it under BLOB_DIR meant that
# splitting the general pool out of ~/.faxl/photo-cache silently abandoned the
# 30-entry index that was already there, and every cached prefix with it. It
# still defaults under BLOB_DIR for a fresh install (one pool, one obvious
# place), but a deployment that moves a pool can now pin it.
# An override is ~-expanded as always; the default is built from BLOB_DIR as
# it stands, never expanded again (faxl_config.faxl_home, Halo-5w4.34).
_DB_OVERRIDE = faxl_config.get("db_dir", "FAXL_DB")
DB_DIR = (os.path.expanduser(_DB_OVERRIDE) if _DB_OVERRIDE is not None
          else os.path.join(BLOB_DIR, "ultradim_db"))
META_PATH = os.path.join(DB_DIR, "meta.json")
# TOKENS_DIR: content-addressed token prefixes for the exact tier — tokens/<phash>.json
# holds ids[:cpos] for every checkpoint with that prefix hash. Identical prefixes across
# requests/sessions share one file (write-once); ~4 B/token, negligible vs blobs.
TOKENS_DIR = os.environ.get("FAXL_TOKENS", os.path.join(BLOB_DIR, "tokens"))
# FIX D5 (CODE-TRUTH): the defaults above live under /tmp and vanish on reboot.
# A cache whose store silently evaporates is a correctness trap for its operator.
def _volatile(p):
    return os.path.realpath(p).startswith(("/tmp", "/private/tmp", "/var/folders"))
if _volatile(BLOB_DIR) or _volatile(DB_DIR) or _volatile(PHOTO_BLOB_DIR):
    print(f"!! VOLATILE STORE: blobs={BLOB_DIR} photos={PHOTO_BLOB_DIR} "
          f"db={DB_DIR} — one or more is under /tmp and will NOT survive a "
          f"reboot. Set FAXL_BLOBS/FAXL_PHOTO_BLOBS/FAXL_DB to persistent "
          f"paths for production.", flush=True)
SEG = 256
# ESN keys are written only for checkpoints at >= this depth (AM directive): below
# 1025 the stride-1024 c4 band has never fired, so the 4-band key is incomplete and
# measured-bad as an embedding. Sub-1025 checkpoints are exact-tier-only entries.
KEY_MIN_TOKENS = int(os.environ.get("FAXL_KEY_MIN_TOKENS", "1025"))
# Build the similarity key AFTER the first token rather than before generation.
# The key costs ~171 ms per 1000 tokens of prefix and the serving path never
# reads it (the ladder decides hits), so inline it was pure added TTFT.
# FAXL_KEY_DEFER=0 puts it back on the critical path.
KEY_DEFER = os.environ.get("FAXL_KEY_DEFER", "1") != "0"

# Polynomial prefix hash (the exact tier's key; same constants as
# integration/boxcar_ladder.py, measured 570/570 correct, 0 collisions).


# Schedule + prefix hash extracted to ckpt_schedule.py (phase 0, plan v1.5)
# so the simulator and tests import them without loading a model. Schedule v2
# (plan §1): base 250 so short prompts (the translation class, 262–280
# tokens) get a reusable checkpoint — safe because a hit requires an exact
# match. FAXL_CKPT_EVERY / FAXL_CKPT_RATIO env pins are read there.
from faxl.engine.ckpt_schedule import (CKPT_EVERY, CKPT_RATIO, ckpt_positions,  # noqa: F401
                           ckpt_set as _CKPT_SET)
# Prefix hashing moves to the compiled core: same values (verified 0/300
# mismatches vs ckpt_schedule.prefix_hashes), one implementation, and the
# lookup path stays inside the wheel.
prefix_hashes = faxl.prefix_hashes if faxl is not None else None
from faxl.engine.media_regions import (ImageDecodeError, MediaRegion,
                                       entry_key, hash_image_bytes)
# entry_key is imported unconditionally (2026-09-25): it moved INTO
# media_regions, which imports no mlx, so every backend keys its store by the
# same rule. It used to be refused off mlx because it lived in exo_store --
# that refusal meant a non-mlx backend could not key a checkpoint at all.
from faxl.engine.store_lifecycle import (STRATEGIES, ScheduleContext,  # noqa: F401
                                         usage_score,
                             make_policy, append_usage, load_usage,
                             compact_usage)
# LICENCE: a signed key file. Absent or lapsed = the cache tier serves misses
# (every prefill cold) while the proxy keeps answering — a lapsed licence must
# never take an inference endpoint down mid-request.
LICENCE_FILE = os.environ.get("FAXL_LICENCE",
                              os.path.expanduser("~/.faxl-licence"))
GATE_TOKENS = int(os.environ.get("FAXL_GATE_TOKENS", "64"))  # skip cache below this
# PLACEMENT STRATEGY SEAM: the write path consumes
# POLICY.decide(ScheduleContext) -> [Placement]. Strategies are named and
# selectable; see store_lifecycle.STRATEGIES for the registry, the measured
# per-workload costs, and how to add another.
#
#   FAXL_STRATEGY=tail_anchor  (DEFAULT) checkpoint at the next turn's resume
#                              point. Measured +25.7% (journal) / +37.8%
#                              (endurance) net cost vs grid; no change on
#                              one-shot traffic.
#   FAXL_STRATEGY=grid         the previous default: geometric ladder only.
#   FAXL_STRATEGY=none         write nothing (control arm).
#
# Tuning: FAXL_TAIL_MARGIN (>=3, a correctness floor — see the class
# docstring), FAXL_TAIL_WITH_GRID=1 to keep the ladder alongside the anchor,
# FAXL_TAIL_MIN_ARRIVALS=N to write the anchor only for chains seen N times
# before (suppresses useless writes on one-shot traffic).
STRATEGY = os.environ.get("FAXL_STRATEGY", "tail_anchor")
_STRAT_KW = {"gate_tokens": GATE_TOKENS}
if STRATEGY in ("grid", "tail_anchor"):
    _STRAT_KW.update(base=CKPT_EVERY, ratio=CKPT_RATIO)
if STRATEGY == "grid":
    _STRAT_KW = {"base": CKPT_EVERY, "ratio": CKPT_RATIO,
                 "gate_tokens": GATE_TOKENS}
elif STRATEGY == "tail_anchor":
    _STRAT_KW.update(
        margin=int(os.environ.get("FAXL_TAIL_MARGIN", "3")),
        with_grid=os.environ.get("FAXL_TAIL_WITH_GRID", "0") == "1",
        min_arrivals=int(os.environ.get("FAXL_TAIL_MIN_ARRIVALS", "0")),
        # continuation evidence: how many EARLIER requests carried the
        # prefix we resumed from. The fork index already counts exactly
        # this (match_counts), so the gate needs no new bookkeeping.
        count_of=lambda ctx: (forkidx.match_counts.get(str(ctx.d_star_hash), 0)
                              if FORK and ctx.d_star_hash else 0))
elif STRATEGY == "none":
    _STRAT_KW = {}
POLICY = make_policy(STRATEGY, **_STRAT_KW)
print(f"placement strategy: {STRATEGY} "
      f"({ {k: v for k, v in _STRAT_KW.items() if k != 'count_of'} })",
      flush=True)
# A/B CONTROL: FAXL_NOCACHE=1 turns the cache OFF (no walk/resume, no checkpoint
# write) while STILL running through the proxy — so we can measure the same task
# with and without faxl and diff the ROI. Everything else (model, tool parsing,
# metrics logging) is identical, isolating the cache's effect.
NOCACHE = os.environ.get("FAXL_NOCACHE", "0") == "1"
# ---- TURN SETTLE (2026-10-01) -- checkpoint the ANSWER, not just the prompt.
# Checkpoints are written during PREFILL only (decode state is produced
# token-by-token, a chunk decomposition the cold path would never use, so
# persisting it breaks the hybrid grid rule -- see backends.py). The model's
# reply therefore used to enter the store one turn LATE: turn N+1 re-prefilled
# all of turn N's answer, and a two-turn chat showed hit_rate 0. After each
# reply is delivered the proxy now sends ITSELF one prefill-only request
# (header X-Faxl-Settle, loopback only) carrying the conversation plus the
# reply. That request walks the ordinary lookup -> on-grid prefill ->
# checkpoint path bit-for-bit, landing a checkpoint at the last SEG multiple
# inside the answer -- the 256 pulse, the last good offset (AM). It decodes
# nothing and is excluded from TOTALS, the metrics JSONL, telemetry and AUDIT
# outcome rows, so the console never shows phantom traffic. It serialises
# behind live requests on _SERVE_LOCK and runs while the user is reading the
# answer, so its cost is idle time. FAXL_SETTLE=0 disables.
SETTLE = os.environ.get("FAXL_SETTLE", "1") == "1"

# ---- HUGGINGFACE TOKEN ------------------------------------------------------
# A token saved in the console is useless unless the library that downloads
# weights can see it. huggingface_hub reads HF_TOKEN from the environment, so
# the saved value is exported here, once, at boot -- nothing downstream needs
# to know faxl stores it. An env var already set WINS and is left alone: a
# launcher that set it meant it, and silently replacing it with a stale saved
# value is the bug this ordering exists to avoid.
def _export_hf_token():
    try:
        from faxl.engine import faxl_config as _fc
        _fc.export_hf_token()
    except Exception:                                      # noqa: BLE001
        pass                      # a token problem must never stop the boot


_export_hf_token()

# ---- THE SPECULATOR'S LEARNED TABLE ----------------------------------------
# Harvest only. The table fills from every answer served, so that a user who
# turns speculation on later starts with a table that already knows their work
# rather than from nothing. DRAFTING IS NOT WIRED IN HERE: backends.py has the
# hook, but it has an open exactness bug, so nothing attaches it and no env var
# can turn it on. Learning is the half that is safe and valuable on its own.
_SPECULATOR = None
_SPECULATOR_KEY = None
_SPEC_LOCK = threading.Lock()


def _speculator(tenant=""):
    """The table for the model being served, or None when learning is off.

    Built once per (model, revision, tenant) and reused: the constructor reads
    the whole JSON file, so doing this per request would re-read the table on
    every answer. A model switch in the console saves the old table before
    dropping it, or everything learned under the previous model is lost.
    """
    global _SPECULATOR, _SPECULATOR_KEY
    try:
        from faxl.engine import faxl_speculator
    except ImportError:
        return None
    key = (MODEL, REVISION, tenant)
    with _SPEC_LOCK:
        if _SPECULATOR_KEY == key:
            return _SPECULATOR
        if _SPECULATOR is not None:
            try:
                _SPECULATOR.save()          # don't lose the old model's table
            except Exception:               # noqa: BLE001
                pass
        _SPECULATOR = faxl_speculator.for_model(MODEL, REVISION, tenant)
        _SPECULATOR_KEY = key
        return _SPECULATOR


def _speculator_harvest(prompt_ids, out_ids, tenant=""):
    """Learn from one finished answer. Never raises: this is a side benefit,
    and it must not be able to fail a request that already succeeded."""
    try:
        spec = _speculator(tenant)
        if spec is None:
            return
        spec.harvest(list(prompt_ids) + list(out_ids))
    except Exception as exc:                                   # noqa: BLE001
        print(f"!! speculator harvest failed ({type(exc).__name__}: {exc}) -- "
              f"the answer is unaffected", flush=True)


def _speculator_save():
    """Flush on clean shutdown, so a deliberate stop loses nothing."""
    with _SPEC_LOCK:
        if _SPECULATOR is not None:
            try:
                _SPECULATOR.save()
            except Exception:                                  # noqa: BLE001
                pass


atexit.register(_speculator_save)
# ---- FORK-POINT CHECKPOINTING (docs/plan-fork-point-checkpointing.md rev 5) --
FORK = os.environ.get("FAXL_FORK", "0") == "1"
FORK_TIME_RATIO = float(os.environ.get("FAXL_FORK_TIME_RATIO", "5"))
FORK_AMORT = float(os.environ.get("FAXL_FORK_AMORT", "4"))
FORK_MAX_LIVE_GB = float(os.environ.get("FAXL_FORK_MAX_LIVE_GB", "20"))
# TOTAL blob-store cap (2026-08-19 ENOSPC incident: only forks were
# capped; grid/anchor checkpoints filled 88 GB in one campaign).
#
# At cap we EVICT, we do not skip. Writes always land and scored eviction
# makes room after (store_lifecycle.evict_scored: oldest unpopular first, by
# time-since-last-hit over popularity; nothing is permanent under this cap,
# grid included). The earlier skip-at-cap behaviour was removed on AM's
# directive 2026-09-01 after a full store starved live traffic behind stale
# blobs — 21 consecutive hourly cold misses. A store sitting at its cap is
# therefore NORMAL, not degraded.
STORE_CAP_GB = faxl_config.cap_gb()
_STORE_BYTES = [0]     # maintained incrementally after boot scan
# How new a blob must be to be spared by the orphan sweep. A file is an orphan
# the instant it exists and before index.add records it, so a sweep racing a
# write would delete a perfectly good checkpoint. 5 minutes is far longer than
# any write takes (the largest measured blob is 702 MB) and far shorter than
# the interval over which leaked bytes matter.
_ORPHAN_GRACE_SECS = 300
FORK_GATES_OFF = os.environ.get("FAXL_FORK_GATES_OFF", "0") == "1"  # config (d) demo
STREAMS_DIR = os.environ.get("FAXL_STREAMS", os.path.join(BLOB_DIR, "streams"))
# Per-request ROI log: FAXL_METRICS, else $FAXL_HOME/metrics.jsonl when
# FAXL_HOME is set, else /tmp/faxl_metrics.jsonl (faxl_config.metrics_path).
METRICS = faxl_config.metrics_path()
# ---- M0 AUDIT TRAIL (master plan v4.1; register rows 55/56/62/76/130) ------
# FAXL_AUDIT_DIR set => per-request audit events (ns identity, full
# prefix-hash arrays, lookup probes, decisions with raw signals, lifecycle,
# outcome) through audit_trail.AuditTrail — the SAME schema the calibrated
# simulator emits, validated by audit_replay.py. Unset => byte-identical
# legacy behaviour. FAXL_COLLECT=1 = corpus-collection mode: audit REQUIRED,
# volatile sinks refused, any logging failure fails /health loudly (an
# apparently-valid incomplete corpus is the worst outcome).
AUDIT_DIR = os.environ.get("FAXL_AUDIT_DIR")
COLLECT = os.environ.get("FAXL_COLLECT", "0") == "1"
if COLLECT and not AUDIT_DIR:
    raise SystemExit("!! FAXL_COLLECT=1 requires FAXL_AUDIT_DIR (durable, "
                     "non-/tmp) — collection without an audit sink is the "
                     "incomplete-corpus trap M0 exists to close")
WORKLOAD = os.environ.get("FAXL_WORKLOAD", "unlabelled")
SESSION_LABEL = os.environ.get("FAXL_SESSION") or f"session-{uuid.uuid4().hex[:8]}"
TENANT = os.environ.get("FAXL_TENANT", "gamakon-dev")
REVISION = os.environ.get("FAXL_MODEL_REVISION", "unpinned")
DTYPE = os.environ.get("FAXL_DTYPE", "as-published")
LOG_FAILURES = []   # loud logging failures; surfaced by /health (M0/F11)


def _append_metrics(rec):
    """One metrics row, appended. The directory is created first when the path
    has one: the default can now sit under a FAXL_HOME nothing else has
    created yet (Halo-5w4.34), and a lost row is only ever loud, never silent.
    A bare FAXL_METRICS=name.jsonl writes in the working directory, as before.
    """
    try:
        parent = os.path.dirname(METRICS)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(METRICS, "a") as mf:
            mf.write(json.dumps(rec) + "\n")
    except OSError as e:
        # M0 (ER4/F11): NEVER silent — an apparently-valid incomplete log is
        # the worst outcome. Surfaced in /health; fails collection loudly.
        LOG_FAILURES.append(f"metrics write: {e}")
        print(f"!! METRICS WRITE FAILED ({METRICS}: {e}) — ROI log "
              f"INCOMPLETE{'; COLLECTION INVALID' if COLLECT else ''}",
              flush=True)
WIDTH = 1 << 16
D_PROJ = 2048
# Projection seeds are Rust-owned config (single source: faxl-probe's resolve_seeds,
# FAXL_SEEDS-overridable). The proxy READS them from the Rust CLI at startup (see
# `SEEDS = probe.seeds()` below) and NEVER declares its own — so the seeds faxl
# computes keys under and the seeds the UltraDim collection is created with are one
# value by construction. SEEDS is bound after `probe` is built.
SEEDS = None
SOURCE_DIM = 4 * WIDTH
FAMILY = "faxl-live"

app = Flask(__name__)

# ---- running ROI totals (across all requests since boot) ----
# Hit/miss on the exo path is decided by the PrefillServer thread, not by this
# handler -- the ladder runs there, where exo's runner asks for a prefix. These
# counters are how the answer gets back to /metrics and the console. Written by
# that thread, read by the request handler; ints under the GIL, no lock needed.
EXO_COUNTS = {"requests": 0, "hits": 0, "last_served": 0, "stored": 0}

# PER-PROJECT breakdown, so two pipelines sharing one proxy can be told apart:
# which team's traffic is hitting the cache, and which is paying for prefill.
# {project: {"requests","hits","prompt_tokens","prefill_skipped","wall_s"}}
BY_PROJECT = {}


def _bump_project(project, *, hit, prompt_tokens, skipped, secs, paid=0):
    """Attribute one served request to a project tag ('' = untagged)."""
    p = BY_PROJECT.setdefault(project or "(untagged)", {
        "requests": 0, "hits": 0, "prompt_tokens": 0,
        "prefill_skipped": 0, "prefill_paid": 0, "wall_s": 0.0})
    p["requests"] += 1
    p["hits"] += 1 if hit else 0
    p["prompt_tokens"] += int(prompt_tokens)
    p["prefill_skipped"] += int(skipped)
    p["prefill_paid"] += int(paid)
    p["wall_s"] += float(secs)

TOTALS = {"requests": 0, "prompt_tokens": 0, "prefill_paid": 0, "prefill_skipped": 0,
          "hits": 0, "ckpts_written": 0, "ckpts_deduped": 0, "wall_s": 0.0}


# ---- faxl probe (Rust) ----
class Probe:
    """The compiled cache core (faxl wheel).

    Was a subprocess speaking line-JSON to faxl_probe_cli; the reservoir and
    the projection now live in the wheel, so there is no process boundary and
    no pipe to keep in sync. Verified identical to the CLI: same indices,
    cosine 1.0 (the wheel-distribution plan (research archive)).
    """

    def __init__(self):
        if faxl is None:
            raise RuntimeError(
                "the 'faxl' wheel is not installed — pip install the faxl and "
                "ultradim wheels (see QUICKSTART.md)")

    def seeds(self):
        """The Rust-resolved projection seeds (FAXL_SEEDS-overridable). The single
        source; the proxy passes THESE to CreateCollection."""
        return list(faxl.seeds())

    def key(self, tokens):
        return faxl.probe_key(list(tokens))


# ---- UltraDim (embedded wheel) ----
class Licence:
    """Entitlement for the cache tier.

    Enforcement lives in the compiled wheel (faxl.ExactIndex), not here — a
    check in this file is a one-line patch to remove. This class only loads the
    key and reports status.

    On lapse the proxy DEGRADES: it keeps serving, the cache tier stops
    hitting, every prefill runs cold. It never refuses a request — an expired
    licence must not take an inference endpoint down.
    """

    def __init__(self, path=LICENCE_FILE):
        self.customer, self.expiry, self.action = "", 0, "unlicensed"
        # Module-level: the wheel's prefix_hashes/probe_key refuse without it,
        # so deleting this class would not re-enable caching.
        self._gate = faxl
        hw_file = os.path.join(BLOB_DIR, ".faxl-hw")
        try:  # restore the clock high-water mark (anti-rollback)
            if self._gate is not None and os.path.exists(hw_file):
                self._gate.set_high_water(int(open(hw_file).read().strip()))
        except (ValueError, OSError):
            pass
        self._hw_file = hw_file
        if self._gate is None:
            return
        try:
            key = open(path).read().strip()
            key = "".join(ln for ln in key.splitlines() if not ln.startswith("#"))
            self.customer, self.expiry, self.action = self._gate.set_licence(key)
        except FileNotFoundError:
            live, cust, exp, _rem, act = self._gate.licence_status()
            if live:
                # time-limited build (tester wheel): entitled without a key
                self.customer, self.expiry, self.action = cust, exp, act
                days = (exp - time.time()) / 86400.0
                print(f"[faxl] {cust}: cache tier enabled without a key; "
                      f"this build stops accelerating in {days:.0f} days",
                      flush=True)
                return
            print(f"!! NO LICENCE at {path} — cache tier DISABLED (every prefill "
                  f"runs cold). Contact andrew@gamakon.ai.", flush=True)
            return
        except ValueError as e:
            print(f"!! INVALID LICENCE at {path}: {e} — cache tier DISABLED.",
                  flush=True)
            return
        left = (self.expiry - time.time()) / 86400.0
        if left <= 0:
            print(f"!! LICENCE EXPIRED ({self.customer}) — cache tier DISABLED; "
                  f"the proxy still serves, every prefill runs cold.", flush=True)
        else:
            note = "  ** RENEW SOON **" if left < 30 else ""
            print(f"[faxl] licensed to {self.customer}; {left:.0f} days remaining"
                  f"{note}", flush=True)

    def entitled(self):
        """True while the cache tier may serve hits. Checked per request."""
        if self._gate is None:
            return False
        live = self._gate.licence_status()[0]
        try:  # persist the ratchet so a clock rollback cannot revive a lapse
            os.makedirs(os.path.dirname(self._hw_file), exist_ok=True)
            with open(self._hw_file, "w") as f:
                f.write(str(self._gate.high_water()))
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            pass
        return live

    def status(self):
        live, cust, exp, remaining, action = (
            self._gate.licence_status() if self._gate else (False, "", 0, 0, "unlicensed"))
        return {"licensed": live, "customer": cust, "expiry": exp,
                "days_remaining": round(remaining / 86400.0, 1), "on_expiry": action}


class _AlreadyThere(Exception):
    """The collection is already on disk; skip CreateCollection.

    A private control-flow signal, not an error: it keeps the "do not create"
    decision in one place instead of duplicating the reopen bookkeeping in
    both the probe and the exception handler.
    """


def _write_checkpoint_tokens(tokf, token_ids):
    if not os.path.exists(tokf):
        tmpf = tokf + f".tmp{uuid.uuid4().hex[:8]}"
        # PRIVACY: this is the verbatim token-id prefix (system message
        # included) and decodes straight back to the prompt text. It is
        # REQUIRED — the byte-confirm compares against it, which is what
        # makes a hit exact rather than a hash guess. It MUST NOT be
        # world-readable: 0600 via an fd opened with that mode (never
        # chmod-after-write, which leaves a readable window). Reported by
        # a tester, 2026-09-11: these shipped 0644.
        _fd = os.open(tmpf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(_fd, "w") as tf:
            json.dump(list(token_ids), tf)
        os.replace(tmpf, tokf)


def _assert_publication_ready():
    marker = META_PATH + ".publication-pending"
    if globals().get("_PUBLICATION_FAILED", False) or os.path.exists(marker):
        raise RuntimeError(
            f"cache publication is incomplete ({marker}); refuse cache access "
            "until the interrupted store publication has been repaired")


def _sync_paths(paths, directories=()):
    for path in paths:
        with open(path, "rb") as f:
            os.fsync(f.fileno())
    for directory in set(directories) | {os.path.dirname(p) or "." for p in paths}:
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _retain_publication_guard():
    # Poison this process even if the filesystem also refuses the marker.
    # A retained durable marker refuses access again on the next boot.
    global _PUBLICATION_FAILED
    _PUBLICATION_FAILED = True
    marker = META_PATH + ".publication-pending"
    fd = os.open(marker, os.O_WRONLY | os.O_CREAT, 0o600)
    os.close(fd)
    _sync_paths([marker])


def _clear_publication_guard(marker):
    os.unlink(marker)
    try:
        _sync_paths([], directories={os.path.dirname(marker) or "."})
    except OSError:
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT, 0o600)
        os.close(fd)
        _sync_paths([marker])
        raise


def _execute_deferred_checkpoints(cache_ops, checkpoint_index, ids, cache,
                                  max_tokens, records):
    """Execute/prove first, then publish; no publication after failed proof."""
    try:
        result = cache_ops.generate(ids, cache, max_tokens)
        for r in records:
            _write_checkpoint_tokens(r["tok"], ids[:r["cpos"]])
        checkpoint_index.add_deferred_batch(records)
    except BaseException as error:
        failures = []
        for path in [p for r in records for p in
                     (r["blob_path"], r["blob_path"] + ".pending")]:
            try:
                os.unlink(path)
            except FileNotFoundError:
                pass
            except OSError as exc:
                failures.append(f"{path}: {exc}")
        if failures:
            # Failures before add_deferred_batch (proof, token writing, guard
            # creation) need the same durable refusal as failures inside it.
            try:
                _retain_publication_guard()
            except OSError as exc:
                failures.append(f"cannot persist publication guard: {exc}")
            raise RuntimeError(f"checkpoint publication failed: {error}; "
                               f"cleanup failures: {failures}") from error
        raise
    return result


class Index:
    def __init__(self):
        _assert_publication_ready()
        import ultradim
        # PERSISTENT store in the user-managed FAXL_DB dir (not a temp dir), so a
        # restart reloads the same keys+blobs. meta.json holds row_id -> (blob, cpos,
        # key) so we can re-upsert every key into a fresh collection on startup.
        os.makedirs(DB_DIR, exist_ok=True)
        self.db = ultradim.UltraDim(DB_DIR)
        # LOOKUP VIA ULTRADIM (CR EXACT_IDENTITY_GET, wheel 0.3.5): a keyed
        # checkpoint carries its lookup digest as a `content_key` keyword facet, and
        # the lookup is GetUltradimV23RowByContentKey — a walk-free, pre-settle
        # identity get, so the shared DB owns the lookup (not a node-local dict) and
        # the analytics arms see live cache traffic. If the wheel predates the RPC,
        # warn loudly and serve from the local index (resilience over refusal);
        # a clean DB not-found still consults the local dict (sub-1025 entries).
        self._has_identity_get = "GetUltradimV23RowByContentKey" in set(self.db.capabilities())
        if not self._has_identity_get:
            print("!! ULTRADIM WHEEL LACKS GetUltradimV23RowByContentKey — need "
                  ">=0.3.5; lookups fall back to the LOCAL exact dict (node-local, "
                  "no cross-machine share, no analytics). Upgrade the wheel.", flush=True)
        self.built = False
        self.rows = 0        # next UltraDim row id — KEYED entries only (the CSR
                             # requires contiguous row_ids, so exact-only entries
                             # must never consume one)
        self.meta = {}       # UltraDim row_id -> (blob path, cpos)
        self.rid_tok = {}    # UltraDim row_id -> tok file (for byte-confirm on an
                             # identity-get hit; rid comes back from the RPC, tok
                             # is what confirm needs)
        self.fork_blobs = {} # phash -> {blob, cpos, bytes, last_resume} (FORK blobs only)
        self.exact = {}      # prefix hash -> (blob, cpos, tok_file) — LOCAL fallback
                             # + sub-KEY_MIN_TOKENS exact-only lookups (v1 has no
                             # decoupled id space, so those can't move to UltraDim)
        # BLOB++ (AM 2026-09-01): durable per-blob usage — {phash(str):
        # [hits, last_hit_ts]} replayed from an append-only fsync'd JSONL,
        # compacted at boot. Feeds scored eviction (evict_scored_over_cap):
        # never-hit blobs score by file mtime, so stale demo blobs rank
        # first the moment the store fills.
        self.usage_path = os.path.join(BLOB_DIR, "usage.jsonl")
        self.usage = load_usage(self.usage_path)
        if self.usage:
            compact_usage(self.usage_path, self.usage)
        # PERSISTENCE (VERIFIED 2026-08-10): UltraDim persists points AND the trellis
        # index to disk (udv23_csr/keys/registry/trellis). A discriminating probe on
        # the reopened Canada store returned score 1.000 on a stored key with NO
        # re-upsert and NO rebuild (candidates_pooled=34, trellis phase=done). So a
        # reopen must NOT re-run CreateCollection (errors "already registered") and
        # must NOT re-upsert (would duplicate every persisted row). It restores only
        # the row->blob map from meta.json and marks the index already built.
        # REOPEN IS A STATE QUESTION, NOT AN EXCEPTION-MESSAGE ONE.
        #
        # This used to be decided purely by whether CreateCollection raised
        # "already registered". It does raise that, correctly (verified on a
        # scratch store: boot 1 creates, boot 2 raises) -- but the registry
        # JSON it checks is one small file among several, and a store can
        # reach a state where the registry is gone while the CSR, keys and
        # payloads are all intact. Create then SUCCEEDS over 11 committed CSR
        # rows, reopened stays False, and the repair path below re-upserts at
        # the old row ids -- which the CSR refuses:
        #
        #   row_ids must extend the CSR contiguously from n_committed=11
        #   (expected row_ids[0]=11, got Some(3))
        #
        # The proxy then cannot start at all. Measured on the live store
        # 2026-09-20; every other file was 09:40 and the registry alone 09:59,
        # written by the very boot that died.
        #
        # So ask the store what it holds FIRST. CollectionInfo is already
        # consulted two lines further down for the seed-drift guard; calling
        # it up here costs one RPC and makes the answer come from persisted
        # state rather than from the wording of an error.
        reopened = False
        try:
            info0 = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
            if info0.get("registered") or info0.get("success"):
                reopened = True
        except RuntimeError:
            pass          # not there, or the RPC is absent: fall through to Create
        try:
            if reopened:
                raise _AlreadyThere()
            self._call("CreateUltradimV23Collection", {
                "name": FAMILY, "source_dim": SOURCE_DIM, "projection_dim": D_PROJ, "seeds": SEEDS,
                "sparse_substrate": True, "max_nnz_per_row": 4 * 512 + 400,
                "matrix_type": "rademacher_hash_v1", "projection_mode": "formula", "trellis_only": True,
                # NB: `window` is NOT a CreateCollection field (0.3.4 rejects it) — it
                # lives on the build/settle path only. See `_ensure_built`.
            })
        except _AlreadyThere:
            pass                 # CollectionInfo already told us; Create skipped
        except RuntimeError as e:
            msg = str(e).lower()
            if "already" in msg or "registered" in msg or "exist" in msg:
                reopened = True  # collection + its points already persisted on disk
            else:
                raise
        if reopened:
            # DRIFT GUARD: the persisted family's seeds are the source of truth for
            # an existing collection (UltraDim hashes them into family identity). If
            # the configured SEEDS no longer match what this store was created with,
            # every key we compute would silently mismatch — fail loud, never serve.
            try:
                info = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
                stored = list(info.get("seeds") or [])
                if stored and stored != list(SEEDS):
                    raise SystemExit(
                        f"!! SEED DRIFT: collection {FAMILY!r} was created with "
                        f"seeds {stored} but configured seeds are {list(SEEDS)}. A "
                        f"mismatch silently invalidates every key. Set FAXL_SEEDS to "
                        f"{stored} to serve this store, or use a fresh FAXL_DB.")
            except RuntimeError as e:
                # FIX D7: don't block startup on the guard itself, but say so — a
                # skipped guard means seed drift would go undetected this run.
                print(f"!! SEED-DRIFT GUARD SKIPPED (CollectionInfo unavailable: {e}) "
                      f"— serving without drift protection", flush=True)
        self._reload(reopened)
        # THE NEXT ROW ID IS THE CSR'S OWN COUNT, NOT ONE DERIVED FROM META.
        #
        # _reload sets self.rows to the highest row id meta.json still names,
        # plus one. Eviction drops rows from meta.json but the CSR keeps them,
        # so after enough evictions meta.json no longer names the top of the
        # CSR -- and no reading of meta.json, foreign rows counted or not, can
        # recover ids it has forgotten. Measured 2026-10-13 on the live store:
        # meta.json led to next_rid=16 while the CSR held 149, and EVERY keyed
        # write failed ("row_ids must extend the CSR contiguously from
        # n_committed=149 (expected row_ids[0]=149, got Some(16))"). Nothing
        # was stored, so every request ran cold -- a stock Hermes Agent session
        # paid full prefill on all four turns of a growing conversation.
        #
        # The CSR accepts exactly n_committed next, so that is the value.
        committed = self._committed_rows()
        if committed is None:
            print(f"!! INDEX ROW COUNT UNAVAILABLE (CollectionInfo has no "
                  f"points_count) — next row id {self.rows} comes from "
                  f"meta.json, and keyed writes will fail if eviction has "
                  f"left the CSR ahead of it", flush=True)
        elif committed != self.rows:
            print(f"index: next row id {self.rows} (from meta.json) -> "
                  f"{committed} (the CSR's committed count)", flush=True)
            self.rows = committed

    def _committed_rows(self):
        """Rows the CSR holds -- the one id it will accept next -- or None.

        Every seed shard of the collection holds the same rows; points_count is
        read from each and the largest taken. A fresh collection reports 0.
        """
        try:
            info = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
        except RuntimeError:
            return None
        counts = [s.get("points_count") for s in (info.get("shards") or [])
                  if isinstance(s, dict)]
        counts = [c for c in counts
                  if isinstance(c, int) and not isinstance(c, bool) and c >= 0]
        return max(counts) if counts else None

    def _reload(self, reopened):
        """Restore the row_id -> (blob, cpos) map from a prior run's meta.json.

        UltraDim persists the vectors + trellis itself (VERIFIED), so we do NOT
        re-upsert on a reopen — we only rebuild the in-process meta map keyed by the
        SAME row ids the store persisted (meta rows carry their `row`). On a FRESH
        collection (no persisted points) meta.json shouldn't exist; if it does (e.g.
        the store dir was cleared but meta.json left behind) we re-upsert to repair."""
        _assert_publication_ready()
        if not os.path.exists(META_PATH):
            return
        try:
            saved = json.load(open(META_PATH))
        except Exception:
            return
        # NAMESPACE BOOT FILTER: only rows stamped with THIS namespace load.
        # Legacy (pre-namespace) rows load only under FAXL_NS_ADOPT=1, which
        # stamps them once (meta rewrite + resolve-record rename below) —
        # after that boot they are ordinary `mine` rows. Foreign rows are
        # skipped untouched: they belong to another model/config sharing the
        # store, which is now the supported shape.
        mine, legacy, foreign = split_meta_rows(saved, NS)
        if foreign:
            print(f"namespace: {len(foreign)} row(s) belong to OTHER "
                  f"namespaces sharing this store — not loaded here", flush=True)
        adopted = []
        if legacy and NS_ADOPT:
            adopted = legacy
            print(f"namespace: ADOPTING {len(legacy)} legacy row(s) into "
                  f"{NS.digest_hex()[:16]} (FAXL_NS_ADOPT=1, one-time stamp)",
                  flush=True)
        elif legacy:
            print(f"!! namespace: {len(legacy)} legacy (pre-namespace) row(s) "
                  f"NOT loaded — set FAXL_NS_ADOPT=1 on ONE boot to stamp them "
                  f"as {NS.digest_hex()[:16]} if this store was written by "
                  f"exactly this model+config", flush=True)
        loaded = 0
        # Missing blobs may be reservations left by an aborted publication.
        # UltraDim has no delete RPC; never reuse its consumed row IDs.
        maxrid = max((int(r["row"]) for r in saved if r.get("row") is not None),
                     default=-1)
        # Repair bookkeeping: the CSR takes row ids only in an unbroken run, so
        # track the next id it will accept and record what had to be left out.
        repair_next, repair_skipped = 0, []
        for row in sorted(mine + adopted,
                          key=lambda r: (r.get("row") is None, r.get("row") or 0)):
            blob, cpos, rid = row["blob"], row["cpos"], row["row"]
            if not os.path.exists(blob):
                continue  # blob gone: leave the persisted point, just don't map it
            # EXACT TIER: rows written by this version carry phash+tok; restore the
            # hash index. Pre-exact-tier rows (no phash) stay retrieval-only — they
            # can never hit, because a hit requires the token confirm.
            if row.get("phash") and row.get("tok") and os.path.exists(row["tok"]):
                self.exact[row["phash"]] = (blob, cpos, row["tok"])
                if row.get("fork"):
                    self.fork_blobs[row["phash"]] = {
                        "blob": blob, "cpos": cpos,
                        "bytes": os.path.getsize(blob), "last_resume": 0.0}
            if rid is not None:
                # keyed entry: a persisted UltraDim point exists at this rid
                if not reopened and row.get("idx") is not None:
                    # FRESH COLLECTION BUT META PRESENT -> repopulate at their rid.
                    #
                    # THIS ONLY WORKS FOR A CONTIGUOUS 0..n RUN. The CSR requires
                    # row_ids to extend it contiguously, and eviction leaves holes
                    # (measured: rids [3, 6, 7, 10] after four evictions), so a
                    # store that has ever evicted cannot be repaired this way. It
                    # is skipped rather than attempted, because attempting it
                    # raises out of __init__ and the proxy does not start at all
                    # -- losing the whole cache to repair part of it.
                    #
                    # The blobs are NOT lost by skipping: the exact tier above is
                    # keyed by phash in-process and still resumes. What is lost is
                    # the fuzzy retrieval arm for these rows, which is why it says
                    # so out loud rather than failing silently.
                    if rid == repair_next:
                        self._call("UpsertUltradimV23Points", {
                            "name": FAMILY, "batch": {"row_ids": [rid],
                                "sparse_vectors": [{"indices": row["idx"],
                                                    "values": row["val"]}]}})
                        repair_next += 1
                    else:
                        repair_skipped.append(rid)
                self.meta[rid] = (blob, cpos)
                if row.get("tok"):
                    self.rid_tok[rid] = row["tok"]
                maxrid = max(maxrid, rid)
            loaded += 1
        if repair_skipped:
            print(f"!! REPAIR PARTIAL: {len(repair_skipped)} row(s) at "
                  f"non-contiguous ids {repair_skipped[:8]}"
                  f"{'…' if len(repair_skipped) > 8 else ''} could not be "
                  f"restored to the retrieval index — the CSR only takes an "
                  f"unbroken run and eviction left holes. Their blobs still "
                  f"serve exact hits; only fuzzy retrieval is reduced. A fresh "
                  f"FAXL_DB rebuilds cleanly.", flush=True)
        # A ROW ID BELONGS TO THE CSR, NOT TO A NAMESPACE.
        #
        # maxrid above is computed only from `mine + adopted`, because those
        # are the rows this namespace maps. But the UltraDim collection is
        # SHARED by every namespace in the store, and its CSR accepts a new
        # row only as a contiguous extension of what it already holds. A row
        # written by another model still occupies its id.
        #
        # So a store whose rows belong to a PREVIOUS namespace restored zero
        # checkpoints, set next_rid=0, and the first keyed write asked the CSR
        # for row 0 while it held five:
        #
        #   faxl index restored 0 checkpoints … next_rid=0, ns=43eb1b47
        #   RuntimeError: row_ids must extend the CSR contiguously from
        #     n_committed=5 (expected row_ids[0]=5, got Some(0))
        #
        # It surfaced as "the whiteboard app crashes the proxy": the failure
        # is on the checkpoint WRITE, after a correct answer was generated, so
        # only requests long enough to earn a keyed entry (>= KEY_MIN_TOKENS)
        # hit it -- chat was short enough to escape, and camera-roll writes
        # deduped against entries that already existed.
        #
        # Counting every persisted row, foreign included, is what keeps the
        # next id ahead of the CSR. Foreign rows are still NOT loaded or
        # mapped -- this only reserves the ids they occupy.
        for _row in foreign:
            _rid = _row.get("row")
            if _rid is not None:
                maxrid = max(maxrid, int(_rid))
        # next new row must not collide with a persisted id
        self.rows = maxrid + 1
        self.built = reopened  # persisted trellis is already built; fresh needs settle
        if adopted:
            # ONE-TIME adoption rewrite: stamp the rows in meta.json and move
            # each legacy resolve record to its scoped name with ns fields —
            # the next boot sees ordinary `mine` rows and no legacy path runs.
            # (Legacy UltraDim facet rows keep their bare content key and are
            # no longer findable via the scoped RPC — the local dict and the
            # renamed resolve records carry single-node serving; new writes
            # re-key normally. Honest cost, logged here once.)
            for row in adopted:
                row["ns_digest"] = NS.digest_hex()
                row["ns"] = NS.as_dict()
                ph = row.get("phash")
                old = os.path.join(TOKENS_DIR, f"{ph}.meta.json")
                if ph and os.path.exists(old):
                    try:
                        m = json.load(open(old))
                        m["ns"] = NS.as_dict()
                        m["ns_digest"] = NS.digest_hex()
                        new = os.path.join(TOKENS_DIR, _rec_name(ph))
                        tmpf = new + ".tmp"
                        with open(tmpf, "w") as fo:
                            json.dump(m, fo)
                        os.replace(tmpf, new)
                        os.remove(old)
                    except Exception as e:  # noqa: BLE001
                        print(f"!! NS ADOPT: resolve record {ph} not "
                              f"migrated ({e})", flush=True)
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(saved, fo)
            os.replace(tmp, META_PATH)
            print(f"namespace: adoption complete — {len(adopted)} row(s) "
                  f"stamped; legacy shared-DB facet rows are superseded by "
                  f"local serving", flush=True)
        print(f"faxl index restored {loaded} checkpoints from {META_PATH} "
              f"(reopened={reopened}, next_rid={self.rows}, built={self.built}, "
              f"ns={NS.digest_hex()[:16]})")

    def _persist(self, rid, idx, val, blob, cpos, phash=None, tok=None, fork=False):
        """Append one checkpoint to meta.json (rewrite whole file — small, JSON).
        idx/val may be None (exact-tier-only entry below KEY_MIN_TOKENS)."""
        cur = []
        if os.path.exists(META_PATH):
            try:
                cur = json.load(open(META_PATH))
            except Exception:
                cur = []
        cur.append({"row": rid, "idx": idx, "val": val, "blob": blob, "cpos": cpos,
                    "phash": phash, "tok": tok, "fork": bool(fork),
                    "ns_digest": NS.digest_hex(), "ns": NS.as_dict()})
        tmp = META_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cur, f)
        os.replace(tmp, META_PATH)

    def _call(self, rpc, obj):
        r = self.db.call_json(rpc, json.dumps(obj))
        o = json.loads(r) if isinstance(r, str) and r.strip()[:1] in "{[" else r
        if isinstance(o, dict) and o.get("error_message"):
            raise RuntimeError(f"{rpc}: {o['error_message']}")
        return o

    def add(self, idx, val, blob_path, cpos, phash=None, tok=None, fork=False):
        """Register one checkpoint. idx/val may be None: an exact-tier-only entry
        (checkpoint below KEY_MIN_TOKENS — no similarity key is written, the lookup
        needs only phash+tok). MEASURED (2026-08-09): in the EMBEDDED wheel a
        post-settle upsert is NOT searchable until a re-settle (the doc flags
        embedded-vs-gRPC parity as ungraded; verified: a row added after settle is
        invisible to search). So a keyed add marks the index dirty; `_ensure_built`
        re-settles once, lazily, before the next search — but callers should BATCH
        their adds so only ONE settle runs per request, not one per checkpoint."""
        rid = None
        if idx is not None:
            # keyed entry: consumes the next CONTIGUOUS UltraDim row id
            rid = self.rows
            batch = {"row_ids": [rid], "sparse_vectors": [{"indices": idx, "values": val}]}
            # LOOKUP DIGEST as a `content_key` keyword facet (CR EXACT_IDENTITY_GET):
            # GetUltradimV23RowByContentKey matches this exactly, walk-free and
            # pre-settle, so the lookup lives in the shared DB. Written only on keyed
            # (>= KEY_MIN_TOKENS) rows — v1 has no decoupled id space, so a
            # content_key point IS a cosine row; sub-1025 exact-only lookups stay
            # local (see plan-ultradim-lookup-restore.md, CR Q2).
            if phash is not None:
                # NAMESPACE-SCOPED content key: ns_hash + prefix hash, so one
                # shared DB serves many models/configs without same-tokenizer
                # collisions. (We deliberately do NOT seed the polynomial hash
                # with the namespace — that would break audit-row comparability
                # and every existing store; the scope is a routing prefix.)
                batch["facets"] = [{"fields": {"content_key": {"kind": {"KeywordValue": scoped_key(NS, phash)}}}}]
            if hasattr(self, "_deferred_reserved"):
                self._deferred_upsert_uncertain = True
            self._call("UpsertUltradimV23Points", {"name": FAMILY, "batch": batch})
            if hasattr(self, "_deferred_reserved"):
                self._deferred_upsert_uncertain = False
                self._deferred_reserved.append({
                    "row": rid, "idx": idx, "val": val, "blob": blob_path,
                    "cpos": cpos, "phash": phash, "tok": tok, "fork": bool(fork),
                    "ns_digest": NS.digest_hex(), "ns": NS.as_dict()})
            self.meta[rid] = (blob_path, cpos)
            if tok is not None:
                self.rid_tok[rid] = tok
            self.rows += 1
            self.built = False  # dirty until re-settled (embedded-wheel requirement)
        if phash is not None:
            self.exact[phash] = (blob_path, cpos, tok)
            if fork:
                self.fork_blobs[phash] = {"blob": blob_path, "cpos": cpos,
                                          "bytes": (os.path.getsize(blob_path)
                                                    if os.path.exists(blob_path) else 0),
                                          "last_resume": time.time()}
            # FIX D2 (CODE-TRUTH): content-addressed resolve record on the STORE, so
            # a checkpoint written by one node is resolvable by any node that shares
            # the store — the lookup no longer depends on the writer's in-memory maps.
            # Write-once. NAMESPACE-SCOPED filename + the full canonical tuple and
            # digest inside, so a cross-store load can run verify_before_load.
            # (Token files stay UNSCOPED: same token ids = identical content,
            # deliberately shared across namespaces — write-once property kept.)
            rec = os.path.join(TOKENS_DIR, _rec_name(phash))
            if not os.path.exists(rec):
                tmp = rec + ".tmp"
                # PRIVACY: `tok` is the verbatim token-id prefix (system message
                # included) and decodes straight back to the prompt. It is
                # REQUIRED — the byte-confirm compares against it, which is what
                # makes a hit exact rather than a hash guess. So it cannot be
                # removed, but it MUST NOT be world-readable: 0600, written via
                # an fd opened with that mode (never chmod-after-write, which
                # leaves a readable window). Reported by a tester, 2026-09-11:
                # these files shipped 0644.
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w") as f:
                    json.dump({"blob": blob_path, "cpos": cpos, "tok": tok,
                               "ns": NS.as_dict(),
                               "ns_digest": NS.digest_hex()}, f)
                os.replace(tmp, rec)
        self._persist(rid, idx, val, blob_path, cpos, phash, tok, fork=fork)  # survive restart
        return rid

    def attach_key(self, phash, idx, val):
        """Attach a similarity key to a checkpoint already registered exact-tier.

        The analytics/retrieval half of `add`, run late: the entry's blob,
        token prefix and resolve record landed on the write path (idx=None),
        and this adds the UltraDim row + content_key facet once the reply is
        out. Returns True when a row was written.

        A no-op when the entry has gone (evicted between the write and the
        drain) or already carries a row: the key is an analytics artifact, and
        losing one must never cost the request that produced it."""
        ent = self.exact.get(phash)
        if ent is None or idx is None:
            return False
        blob_path, cpos, tok = ent
        if any(b == blob_path for b, _c in self.meta.values()):
            return False          # already keyed
        if not os.path.exists(blob_path):
            return False          # evicted under us
        self.add(idx, val, blob_path, cpos, phash=phash, tok=tok,
                 fork=phash in self.fork_blobs)
        return True

    def add_deferred_batch(self, records):
        """Commit a proved request, or revoke its resolvable metadata/blobs.

        An empty, durable local marker bars lookup and restart during a batch.
        Interrupted publication or failed rollback leaves it in place for
        explicit repair. Consumed CSR IDs remain in the existing meta row
        format, pointing at removed blobs; they reserve IDs but cannot load.
        """
        if not records:
            return []
        _assert_publication_ready()
        marker = META_PATH + ".publication-pending"
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
        _sync_paths([marker])
        before = {name: dict(getattr(self, name))
                  for name in ("exact", "meta", "rid_tok", "fork_blobs")}
        prior_rows = json.load(open(META_PATH)) if os.path.exists(META_PATH) else []
        prior_records = {}
        for r in records:
            rec = os.path.join(TOKENS_DIR, _rec_name(r["phash"]))
            prior_records[rec] = open(rec, "rb").read() if os.path.exists(rec) else None
        # Check every artifact before exposing the first row.
        sizes = [os.path.getsize(r["blob_path"]) for r in records]
        self._deferred_reserved = []
        self._deferred_upsert_uncertain = False
        try:
            for r in records:
                self.add(**r)
            _sync_paths([META_PATH, *prior_records, *[r["tok"] for r in records]])
        except BaseException as error:
            failures = []
            # The marker continues to refuse lookup if any cleanup fails.
            for r in records:
                for path in (r["blob_path"], r["blob_path"] + ".pending"):
                    try:
                        os.unlink(path)
                    except FileNotFoundError:
                        pass
                    except OSError as exc:
                        failures.append(exc)
            for name, value in before.items():
                setattr(self, name, value)
            for rec, old in prior_records.items():
                try:
                    if old is None:
                        if os.path.exists(rec):
                            os.unlink(rec)
                    else:
                        fd = os.open(rec + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                        with os.fdopen(fd, "wb") as f:
                            f.write(old)
                        os.replace(rec + ".tmp", rec)
                except OSError as exc:
                    failures.append(exc)
            try:
                with open(META_PATH + ".tmp", "w") as f:
                    json.dump(prior_rows + self._deferred_reserved, f)
                os.replace(META_PATH + ".tmp", META_PATH)
                _sync_paths([META_PATH, *[p for p, old in prior_records.items()
                                          if old is not None]],
                            directories={TOKENS_DIR, *[os.path.dirname(r["blob_path"])
                                                       or "." for r in records]})
            except OSError as exc:
                failures.append(exc)
            if self._deferred_upsert_uncertain:
                failures.append("UltraDim upsert outcome unknown; consumed row IDs require repair")
            if failures:
                raise RuntimeError(f"checkpoint publication failed: {error}; "
                                   f"rollback failures: {failures}; guard retained: {marker}") from error
            _clear_publication_guard(marker)
            raise
        else:
            _clear_publication_guard(marker)
            return sizes
        finally:
            del self._deferred_reserved
            del self._deferred_upsert_uncertain

    def known_positions(self):
        """Sorted set of every position where this node knows a blob exists —
        grid AND fork (rev-2 fix: fork blobs must be findable by the lookup
        probe or they are write-only)."""
        out = {cpos for (_b, cpos, _t) in self.exact.values()}
        out.update(cpos for (_b, cpos) in self.meta.values())
        return sorted(out, reverse=True)

    def live_fork_gb(self):
        return sum(f["bytes"] for f in self.fork_blobs.values()) / 1e9

    def touch_resume(self, phash):
        f = self.fork_blobs.get(phash)
        if f:
            f["last_resume"] = time.time()

    def record_hit(self, phash):
        """blob++ (AM 2026-09-01): count every confirmed resume, durably.
        One fsync'd line per warm request (~ms on a ~1 s request)."""
        now = time.time()
        p = str(phash)
        hits, _ = self.usage.get(p, (0, 0.0))
        self.usage[p] = [hits + 1, now]
        try:
            append_usage(self.usage_path, p, now)
        except OSError as e:
            LOG_FAILURES.append(f"usage append {p}: {e}")
            print(f"!! USAGE LOG APPEND FAILED ({e}) — hit counts will "
                  f"under-count after a restart", flush=True)

    def _usage_score(self, phash, blob, now):
        """Eviction score = time-since-last-hit / (1 + hits): oldest
        unpopular first. A never-hit blob's 'last hit' is its file mtime.

        The formula lives in store_lifecycle.usage_score so the exo-line
        store scores identically — two copies of a retention rule drift, and
        a store that evicts by a different rule from the one the console
        reports is a store nobody can reason about.
        """
        return usage_score(self.usage, phash, blob, now)

    def sweep_orphans(self, protect=frozenset()):
        """Delete blob files no index entry points at. Returns (n, bytes).

        ORPHANS LEAK AGAINST THE CAP, AND NOTHING COULD RECLAIM THEM. The cap
        is measured from the directory -- _STORE_BYTES sums every
        *.safetensors on disk -- while eviction can only delete blobs it can
        find in self.exact/self.fork_blobs. A file that is on disk and in
        neither map is therefore counted forever and evictable never. Measured
        on the owner's store 2026-10-02: 2 blobs, 0.83 GB, against an 8.0 GB
        cap -- 10% of the budget permanently unreclaimable, and it only grows,
        because every crashed or failed write leaves one behind.

        They arise legitimately: CACHE.save() writes the file BEFORE
        index.add() records it, so any failure between the two (the
        add-failure path a few lines down removes its own blob, but a SIGKILL
        or a power cut does not) strands bytes. The write path calls this after
        a successful store, which is the moment the live set is known good.

        A file younger than _ORPHAN_GRACE_SECS is left alone: a concurrent
        request may have just written it and not yet called index.add, and
        deleting that is a self-inflicted cache miss. _SERVE_LOCK serialises
        inference today, so this is belt-and-braces rather than load-bearing.
        """
        live = {os.path.abspath(ent[0]) for ent in self.exact.values() if ent[0]}
        live |= {os.path.abspath(f["blob"]) for f in self.fork_blobs.values()
                 if f.get("blob")}
        # EVERY ROW meta.json HOLDS, NOT ONLY THE ROWS THIS BOOT LOADED.
        # _reload skips foreign-namespace rows (another model/config/runtime
        # sharing the store -- a supported shape) and un-adopted legacy rows
        # "untouched"; neither reaches self.exact, so without this their blobs
        # looked orphaned and were deleted at the next boot or write. A row
        # names its blob, so its blob is not an orphan, whoever's it is. An
        # unreadable meta.json means the live set is unknown: sweep nothing.
        if os.path.exists(META_PATH):
            try:
                with open(META_PATH) as _fm:
                    _rows = json.load(_fm)
            except (OSError, ValueError) as e:
                LOG_FAILURES.append(f"orphan sweep skipped: meta.json "
                                    f"unreadable: {e}")
                return 0, 0
            live |= {os.path.abspath(r["blob"]) for r in _rows
                     if isinstance(r, dict) and r.get("blob")}
        live |= {os.path.abspath(b) for b in protect if isinstance(b, str)}
        now = time.time()
        n, freed = 0, 0
        pairs = []
        for d in _POOL_DIRS:
            try:
                pairs.extend((d, n) for n in os.listdir(d))
            except OSError as e:                              # noqa: BLE001
                LOG_FAILURES.append(f"orphan sweep listdir {d}: {e}")
        for d, name in pairs:
            if not name.endswith(".safetensors"):
                continue
            path = os.path.abspath(os.path.join(d, name))
            if path in live:
                continue
            try:
                st = os.stat(path)
            except OSError:
                continue          # vanished under us; nothing to reclaim
            if now - st.st_mtime < _ORPHAN_GRACE_SECS:
                continue          # may be a write in flight
            try:
                os.remove(path)
            except OSError as e:                              # noqa: BLE001
                LOG_FAILURES.append(f"orphan sweep remove {name}: {e}")
                print(f"!! ORPHAN BLOB NOT REMOVED ({name}: {e}) — its bytes "
                      f"still count against the cap", flush=True)
                continue
            # The cap is measured from the directory, so the counter has to
            # follow the directory.
            _STORE_BYTES[0] = max(0, _STORE_BYTES[0] - st.st_size)
            n += 1
            freed += st.st_size
        return n, freed

    def pool_bytes(self, pool_dir):
        """Bytes of *.safetensors in one pool directory.

        Measured from the directory, like the global counter, so a leaked blob
        is visible to the cap it leaks against rather than to the other one.
        """
        try:
            return sum(os.path.getsize(os.path.join(pool_dir, f))
                       for f in os.listdir(pool_dir)
                       if f.endswith(".safetensors"))
        except OSError:
            return 0

    def evict_scored_over_cap(self, cap_gb, protect=frozenset(), pool=None):
        """STORE-WIDE scored eviction (AM 2026-09-01, replacing the refuse-
        writes-at-cap guard that froze out live traffic behind stale blobs).
        Runs AFTER a write lands: evict highest-score blobs until the store
        fits the cap. NOTHING is permanent -- grid blobs included. `protect`
        holds phashes never to evict (this request's writes + its resume
        point). Returns the victim list.

        APPROXIMATE BY DESIGN (AM 2026-10-02): the store writes first and
        trims after, so it floats slightly above the cap between a write and
        the sweep that follows it. That is the intended behaviour -- a
        refuse-when-full gate is what this replaced, and it froze live traffic
        out behind stale blobs.

        THE POOL DIRECTORY IS THE EVICTION DOMAIN. The cap is measured from
        the directory (every *.safetensors, every namespace), so candidates
        come from the directory too. Candidates used to come from self.exact,
        which holds the CURRENT namespace only: with the other model's blobs
        filling the store and this model's two entries protected, nothing was
        evictable and the loop gave up still over cap (2026-10-23: the fresh
        anchor was the only candidate on the next request and was deleted).
        Namespace governs readability, never reclaimability. Candidates are
        keyed by absolute blob path: raw phashes collide across namespaces."""
        now = time.time()
        victims = []
        pool_dir = os.path.abspath(pool) if pool else None
        dirs = [pool_dir] if pool_dir else list(_POOL_DIRS)

        # path -> (phash, ns_digest) from every persisted row, foreign
        # included, overlaid by the live map for rows not yet persisted.
        known = {}
        try:
            with open(META_PATH) as _fm:
                for r in json.load(_fm):
                    if isinstance(r, dict) and r.get("blob"):
                        known[os.path.abspath(r["blob"])] = (
                            r.get("phash"), r.get("ns_digest"))
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as e:
            LOG_FAILURES.append(f"eviction: meta.json unreadable: {e}")
            print(f"!! EVICTION: meta.json unreadable ({e}) — foreign blobs "
                  f"are evicted without their metadata", flush=True)
        local = {}
        for ph, ent in self.exact.items():
            if ent[0]:
                local[os.path.abspath(ent[0])] = ph
        for path, ph in local.items():
            known[path] = (ph, NS.digest_hex())
        protected = {path for path, ph in local.items() if ph in protect}

        cands, excluded = [], 0
        for d in dirs:
            try:
                names = os.listdir(d)
            except OSError as e:
                LOG_FAILURES.append(f"eviction listdir {d}: {e}")
                continue
            for name in names:
                if not name.endswith(".safetensors"):
                    continue
                path = os.path.abspath(os.path.join(d, name))
                try:
                    st = os.stat(path)
                except OSError:
                    continue      # vanished under us; nothing to reclaim
                # A blob between CACHE.save() and index.add() is in no map:
                # same in-flight-write race sweep_orphans guards against.
                if path in protected or now - st.st_mtime < _ORPHAN_GRACE_SECS:
                    excluded += 1
                    continue
                ph, dig = known.get(path, (None, None))
                score = self._usage_score(ph if ph is not None else "", path, now)
                cands.append((score, path, st.st_size, ph, dig))
        cands.sort(key=lambda c: c[0], reverse=True)

        # `used` is a private tally, seeded once. It is NOT re-read from
        # _STORE_BYTES: remove_blob and _remove_foreign_blob move the global
        # counter themselves, and this loop only subtracts each victim's
        # statted size from its own copy, so no byte is counted twice.
        used = self.pool_bytes(pool) if pool else _STORE_BYTES[0]
        for score, path, size, ph, dig in cands:
            if used <= cap_gb * 1e9:
                break
            if path in local:
                # Loaded blob: rid purge, token record and usage via
                # remove_blob. Its meta row goes in the single rewrite below.
                self.remove_blob(local[path], persist=False)
                if os.path.exists(path):
                    continue      # remove_blob already logged the failure
                victims.append(local[path])
            else:
                if not self._remove_foreign_blob(path, size, ph, dig):
                    continue
                # Unmapped blob: label it so the audit trail can never mistake
                # a file stem for a phash.
                victims.append(ph if ph is not None
                               else "blob:" + os.path.basename(path)[:-len(".safetensors")])
            used -= size
        # Not purely an exhaustion signal: also fires when candidates existed
        # but every unlink failed, or a listdir failed (see LOG_FAILURES).
        if used > cap_gb * 1e9:
            print(f"!! STORE over {cap_gb} GB cap but nothing evictable "
                  f"({excluded} blob(s) protected or inside the "
                  f"{_ORPHAN_GRACE_SECS}s write grace) — overshoot accepted",
                  flush=True)
        # ONE meta.json rewrite for the whole pass, which also drops rows
        # whose blob is already gone.
        self.reconcile_meta()
        return victims

    def trim_pools(self, pools, protect=frozenset(), report=None):
        """Evict each distinct pool directory to its cap. `pools` is
        [(dir, cap_gb[, label])]. Photo and general may share one directory
        (_POOL_DIRS dedups it); that directory is trimmed ONCE, to the larger
        cap -- trimming it again to the smaller one would cut live
        checkpoints. `report(label, victims, dir, cap)` is called for each
        directory that evicted something; a shared directory's label joins
        the labels of the pools that name it."""
        groups = {}
        for d, cap, *label in pools:
            g = groups.setdefault(os.path.abspath(d), [cap, []])
            g[0] = max(cap, g[0])
            g[1].extend(label)
        victims = []
        for d, (cap, labels) in groups.items():
            if self.pool_bytes(d) <= cap * 1e9:
                continue
            v = self.evict_scored_over_cap(cap, protect=protect, pool=d)
            if v and report:
                report("/".join(labels), v, d, cap)
            victims.extend(v)
        return victims

    def _remove_foreign_blob(self, path, size, phash, ns_digest):
        """Delete a blob this process has no index entry for (another
        namespace's, a dangling row's). Returns True once the file is gone.

        remove_blob cannot do this: handed a phash it does not own it derives
        blob=None, never unlinks, and still deletes the CURRENT namespace's
        resolve record. The counter moves only AFTER the unlink succeeds, and
        never below zero. The meta row goes with the batched reconcile_meta,
        matched by blob path (raw phashes collide across namespaces)."""
        try:
            os.remove(path)
        except FileNotFoundError:
            pass                  # already gone: nothing left to count
        except OSError as e:
            LOG_FAILURES.append(f"evict blob {os.path.basename(path)}: {e}")
            print(f"!! STORE MUTATION FAILED: blob {path} not removed ({e}) "
                  f"— its bytes still count against the cap", flush=True)
            return False
        else:
            _STORE_BYTES[0] = max(0, _STORE_BYTES[0] - size)
        # The foreign namespace's scoped resolve record, named from the row's
        # own digest. Unscoped <phash>.json token files are shared: they stay.
        if phash is not None and isinstance(ns_digest, str) and len(ns_digest) >= 16:
            class _Foreign:
                def ns_hash(self):
                    return int(ns_digest[:16], 16)
            try:
                rec = os.path.join(TOKENS_DIR, scoped_key(_Foreign(), phash)
                                   .replace(":", "_") + ".meta.json")
                if os.path.exists(rec):
                    os.remove(rec)
            except (OSError, ValueError) as e:
                LOG_FAILURES.append(f"remove foreign resolve record {phash}: {e}")
                print(f"!! STORE MUTATION FAILED: foreign resolve record for "
                      f"{phash} not removed ({e})", flush=True)
        return True

    def reconcile_meta(self):
        """Drop meta.json rows whose blob is gone, in one rewrite. Returns the
        number dropped. Matches by blob path, never by raw phash. Rows with a
        non-None `row` under DEFERRED_CACHE stay, as in remove_blob: they
        reserve consumed row ids and cannot load. An unreadable meta.json
        means the row set is unknown: change nothing."""
        if not os.path.exists(META_PATH):
            return 0
        try:
            with open(META_PATH) as _fm:
                rows = json.load(_fm)
        except (OSError, ValueError) as e:
            LOG_FAILURES.append(f"meta reconcile skipped: meta.json unreadable: {e}")
            print(f"!! STORE MUTATION FAILED: meta.json unreadable ({e}) — "
                  f"dangling rows not reconciled", flush=True)
            return 0
        # DEFERRED_CACHE is defined with the backend, far below the boot store
        # scan that calls this -- so at boot the name does not exist yet and a
        # bare reference is a NameError that kills the proxy before it serves
        # (2026-10-23). Absent, assume True: keeping a reservation row costs
        # nothing, dropping one destroys a consumed row id.
        _deferred = globals().get("DEFERRED_CACHE", True)
        keep = [r for r in rows
                if not (isinstance(r, dict) and r.get("blob")
                        and not os.path.exists(r["blob"])
                        and not (_deferred and r.get("row") is not None))]
        if len(keep) == len(rows):
            return 0
        try:
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(keep, fo)
            os.replace(tmp, META_PATH)
        except Exception as e:
            LOG_FAILURES.append(f"meta rewrite on reconcile: {e}")
            print(f"!! STORE MUTATION FAILED: meta.json rewrite ({e}) — a "
                  f"restart will RESURRECT evicted rows", flush=True)
            return 0
        return len(rows) - len(keep)

    def remove_blob(self, phash, persist=True):
        """Supersession/eviction delete: index rows FIRST, then the blob file
        (a raced request falls cold via the guarded load, never 500s). Token
        files stay (content-addressed, shared). Handles ANY blob — fork,
        grid, anchor (grid lost its permanence when scored store-wide
        eviction landed, AM 2026-09-01).

        persist=False skips the meta.json rewrite: a batching caller (scored
        eviction) rewrites once afterwards via reconcile_meta. The two modes
        use DIFFERENT row predicates, deliberately: persist=True drops rows by
        raw phash (which collides across namespaces); reconcile_meta drops
        rows whose blob PATH no longer exists. The path predicate is the safer
        one -- do not "align" it back to phash."""
        f = self.fork_blobs.pop(phash, None)
        ent = self.exact.pop(phash, None)
        # Purge the UltraDim rid bookkeeping too: a stale meta[rid] makes
        # identity_get return None WITHOUT falling back to the live maps
        # (:642-648), so an evicted-then-rewritten prefix would miss forever.
        # The persisted UltraDim row itself stays (no delete RPC); with the
        # rid unmapped, a found-row lookup falls through to the resolve
        # record / exact dict, which the rewrite repopulates.
        _blob_now = f["blob"] if f else (ent[0] if ent else None)
        for rid in [r for r, (b, _c) in self.meta.items() if b == _blob_now]:
            self.meta.pop(rid, None)
            self.rid_tok.pop(rid, None)
        self.usage.pop(str(phash), None)
        rec = os.path.join(TOKENS_DIR, _rec_name(phash))
        _legacy_rec = os.path.join(TOKENS_DIR, f"{phash}.meta.json")
        if not os.path.exists(rec) and os.path.exists(_legacy_rec):
            rec = _legacy_rec   # pre-namespace record: same delete discipline
        # M0 loud-failure sweep (F11): store mutations must never fail
        # silently — a stale record/blob/meta row resurrects deleted state
        # or leaks bytes, and silence hides it (Rules: fail-open is design,
        # a swallowed bug is not). Removal proceeds (the delete itself is
        # still wanted) but every failure is printed and surfaced in /health.
        try:
            if os.path.exists(rec):
                os.remove(rec)
        except OSError as e:
            LOG_FAILURES.append(f"remove resolve record {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: resolve record {rec} not "
                  f"removed ({e}) — a shared-store node may still serve the "
                  f"deleted checkpoint", flush=True)
        blob = f["blob"] if f else (ent[0] if ent else None)
        if blob:
            try:
                _STORE_BYTES[0] -= (os.path.getsize(blob)
                                    if os.path.exists(blob) else 0)
                os.remove(blob)
            except OSError as e:
                LOG_FAILURES.append(f"remove blob {phash}: {e}")
                print(f"!! STORE MUTATION FAILED: blob {blob} not removed "
                      f"({e}) — orphan bytes leak against the cap", flush=True)
        # meta.json: rewrite without this row
        if not persist:
            return
        try:
            cur = [r for r in json.load(open(META_PATH))
                   if r.get("phash") != phash
                   or (DEFERRED_CACHE and r.get("row") is not None)]
            # Deferred CSR row reservations survive eviction as well as an
            # aborted batch. Their missing blobs make them non-loadable.
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(cur, fo)
            os.replace(tmp, META_PATH)
        except Exception as e:
            LOG_FAILURES.append(f"meta rewrite on remove {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: meta.json rewrite ({e}) — a "
                  f"restart will RESURRECT removed row {phash}", flush=True)

    def evict_forks_over_cap(self, cap_gb):
        """FAXL_FORK_MAX_LIVE_GB: evict least-recently-RESUMED fork blobs
        (fork blobs only; grid blobs untouched). Returns the VICTIM phash
        list (M0: the audit trail records each eviction; len() is the
        count callers report)."""
        evicted = []
        while self.live_fork_gb() > cap_gb and self.fork_blobs:
            victim = min(self.fork_blobs, key=lambda k: self.fork_blobs[k]["last_resume"])
            self.remove_blob(victim)
            evicted.append(victim)
        return evicted

    def resolve_from_store(self, phash):
        """FIX D2: resolve phash -> (blob, cpos, tok) from the shared store's
        content-addressed record, independent of this node's in-memory maps.
        Returns None if no record, or if the blob/token files are missing.
        This is the CROSS-STORE path, so verify_before_load runs here — P1's
        caller: a record from another namespace is refused loudly, never
        served (the C3 test's per-row digest + tuple check)."""
        _assert_publication_ready()
        rec = os.path.join(TOKENS_DIR, _rec_name(phash))
        try:
            with open(rec) as f:
                m = json.load(f)
        except Exception:
            return None
        try:
            _ns_verify(NS, m.get("ns"), m.get("ns_digest"))
        except Exception as e:
            print(f"!! NAMESPACE REFUSED on resolve record "
                  f"{os.path.basename(rec)}: {e} — serving cold", flush=True)
            return None
        blob, cpos, tokf = m.get("blob"), m.get("cpos"), m.get("tok")
        if not blob or not tokf or not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def exact_lookup(self, phash):
        """Exact-tier candidate: (blob, cpos, tok_file) for this prefix hash, or None.
        The CALLER must confirm by token compare before resuming (belt and braces
        against the ~2^-61 hash collision; confirm outcome is logged per hit)."""
        _assert_publication_ready()
        ent = self.exact.get(phash)
        if ent is None:
            return None
        blob, cpos, tokf = ent
        if not os.path.exists(blob) or not tokf or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def identity_get(self, content_key):
        """Exact identity lookup via UltraDim (CR EXACT_IDENTITY_GET, wheel 0.3.5):
        GetUltradimV23RowByContentKey is a walk-free, pre-settle keyword-facet get.
        Returns (blob, cpos, tok_file) for an exact hit, else None — same shape as
        exact_lookup, so the caller's byte-confirm is unchanged. Falls back to the
        local exact dict when the wheel lacks the RPC. The rid->tok/(blob,cpos) maps
        are the proxy's own row bookkeeping (the RPC returns only the row id)."""
        _assert_publication_ready()
        if not self._has_identity_get:
            return self.exact_lookup(content_key)
        try:
            # Callers pass the RAW prefix hash; the namespace scope is applied
            # HERE (and only here) so every fallback below keeps using the raw
            # hash against the process-local maps — a scoped key leaking into
            # exact_lookup would silently miss on every fallback.
            r = self._call("GetUltradimV23RowByContentKey",
                           {"name": FAMILY, "content_key": scoped_key(NS, content_key)})
        except RuntimeError as e:
            # FIX D8: never fail the request on a get error, but never be silent either.
            print(f"!! IDENTITY-GET RPC ERROR ({e}) — falling back to the local "
                  f"exact dict for this lookup", flush=True)
            return self.exact_lookup(content_key)
        if not r.get("found"):
            # FIX D1 (CODE-TRUTH): sub-KEY_MIN_TOKENS checkpoints are exact-tier-only
            # (no content_key row in UltraDim), so a clean not-found MUST still
            # consult the local dict or those checkpoints are write-only forever.
            # FIX D2: then the shared store's resolve record (another node's write).
            return self.exact_lookup(content_key) or self.resolve_from_store(content_key)
        rid = r.get("row_id")
        ent = self.meta.get(rid)
        tokf = self.rid_tok.get(rid)
        if ent is None or not tokf:
            # rid known to the shared DB but not to this node: FIX D2 — resolve from
            # the store's content-addressed record (cross-node hit), then local dict.
            return self.resolve_from_store(content_key) or self.exact_lookup(content_key)
        blob, cpos = ent
        if not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    # (cosine walk / trellis search surface removed 2026-08-15 — dead code on
    #  the serving path, audit D9; measured wrong-prefix hits 308/420 at
    #  SNAP 0.6. Record: git history + docs/boxcar-ladder-result.md.)



def _image_digest(url):
    """One image's identity: sha256 of its DECODED RGB PIXELS, truncated.

    Falls back to hashing the URL text when the bytes cannot be decoded --
    which covers the cases the proxy must not treat as an image:

      * A REMOTE URL. exo fetches http(s) image urls itself
        (api/adapters/chat_completions.py:49); this proxy deliberately does
        NOT. Fetching an attacker-supplied URL from inside the proxy is a
        request-forgery vector, and the proxy sits in front of a cluster. The
        url text is then the only identity available, which is honest: two
        requests naming the same url share a key, and nothing is claimed
        about the picture.
      * An UNDECODABLE or oversized image. On exo the original body is
        forwarded and exo decides; on an in-process backend that reads
        images, _image_request_refusal refuses a picture the backend could
        not decode (or a URL it would never fetch) before any prefill, so the
        fallback only keys it. A picture over media_regions' pixel cap that
        Pillow still decodes is served and keyed on its URL text.
      * An image URL that is not a string (JSON null, a list, an object, a
        number): keyed on a fixed text naming its type, never a crash.

    Either fallback can only cause a MISS, never a wrong hit: a different
    identity string simply keys elsewhere.

    The work, and its memo, is _read_image_url's: the refusal reads the same
    record right after flattening, so a picture is decoded once.
    """
    return _read_image_url(url)[0]


_IMAGE_URL_SCHEME_RE = re.compile(r"([A-Za-z][A-Za-z0-9+.\-]{0,31}):")


def _image_part_url(part):
    """The URL value of one image content part, exactly as sent (any type).

    The one spelling of "where is this part's picture" for the flattener, the
    refusal and the pixel collector, which used to repeat it. An object
    image_url yields its "url" member, whatever its JSON type; any other
    image_url (or a bare "url") is stringified, as it always was.
    """
    iu = part.get("image_url")
    if isinstance(iu, dict):
        return iu.get("url", "")
    return str(iu or part.get("url") or "")


def _undecodable_reason(raw):
    """None when Pillow decodes `raw` the way the backends do (open, load,
    RGB) -- e.g. a picture over media_regions' pixel cap, which the hash
    refuses and the backends still read; otherwise why it cannot be read.

    Pillow's UnidentifiedImageError names the BytesIO object by its memory
    address, which is noise to a client and differs per request, so that one
    is said in words.
    """
    import io
    from PIL import Image, UnidentifiedImageError
    try:
        with Image.open(io.BytesIO(raw)) as img:
            img.load()
            img.convert("RGB")
    except UnidentifiedImageError:
        return "not a picture format this server can read"
    except Exception as e:   # noqa: BLE001 -- any decoder failure is the reason
        return f"{type(e).__name__}: {e}"
    return None


def _read_image_url(url, _cache={}):
    """(digest, problem) for one image part's URL value. Never raises.

    digest   the 16-hex identity _image_digest returns: sha256 of decoded RGB
             pixels, else of the URL text (computed exactly as before this
             function existed: same decode, same fallback, same log line).
    problem  None when an in-process backend can read the picture; else
             (code, reason) for _image_request_refusal, where reason completes
             the sentence "Image k of n (messages[i].content[j]) ...".

    Memoised, least-recently-used, 512 entries: a client that sends the same
    photo in several turns of one conversation would otherwise decode it once
    per turn, and the refusal reads the record right after flattening.
    """
    if not isinstance(url, str):
        kind = "null" if url is None else type(url).__name__
        digest = hashlib.sha256(f"<image url of type {kind}>".encode()).hexdigest()
        return digest[:16], ("image_url_not_supported",
                             f"carries an image URL that is not a string ({kind})")
    if url in _cache:
        out = _cache.pop(url)
        _cache[url] = out          # most recently used last
        return out
    digest = problem = None
    if not url:
        problem = ("image_url_not_supported", "carries no image URL")
    elif not url.startswith("data:"):
        m = _IMAGE_URL_SCHEME_RE.match(url)
        problem = ("image_url_not_supported",
                   f"is a URL with the scheme {m.group(1).lower()!r}" if m
                   else "is not a data: URL")
    else:
        # data:image/jpeg;base64,<payload> — the same prefix exo strips.
        _, _, payload = url.partition(",")
        if not payload:
            problem = ("image_not_decodable", "is a data: URL with no image bytes")
        else:
            raw = None
            try:
                raw = base64.b64decode(payload, validate=False)
                digest = hash_image_bytes(raw)
            except (ImageDecodeError, ValueError, TypeError) as e:
                print(f"faxl: image not decodable ({e}) — keying on the "
                      f"request text instead", flush=True)
                if raw is None:
                    problem = ("image_base64_invalid",
                               f"is a data: URL whose base64 payload does not "
                               f"decode ({e})")
                else:
                    reason = _undecodable_reason(raw)
                    if reason is not None:
                        problem = ("image_not_decodable",
                                   f"could not be decoded as a picture ({reason})")
    if digest is None:
        digest = hashlib.sha256(url.encode()).hexdigest()
    out = (digest[:16], problem)
    _cache[url] = out
    if len(_cache) > 512:      # bounded: this is a per-process convenience
        _cache.pop(next(iter(_cache)))
    return out


# What follows each reason in the refusal, per code.
_IMAGE_REFUSAL_TAIL = {
    "image_url_not_supported": (
        "faxl reads a picture only from a data: URL carried in the request "
        "(data:image/<type>;base64,<bytes>). It does not fetch URLs: it serves "
        "from this machine and does not reach the network or the filesystem on "
        "a request's behalf. The model would never see this picture, and faxl "
        "will not answer from a placeholder. Send the picture inline as a "
        "data: URL."),
    "image_base64_invalid": (
        "The picture cannot be read, and faxl will not answer from a "
        "placeholder. Send the picture's bytes base64-encoded in a data: URL."),
    "image_not_decodable": (
        "The model would never see it, and faxl will not answer from a "
        "placeholder. Send the picture in a common format such as PNG or "
        "JPEG."),
}
_IMAGE_REFUSAL_TYPE = {"image_url_not_supported": "unsupported_content",
                       "image_base64_invalid": "invalid_image",
                       "image_not_decodable": "invalid_image",
                       "too_many_images": "unsupported_content"}


def _image_request_refusal(body, backend):
    """The 400 body for an image request this in-process backend cannot read,
    or None when it can read every picture. Halo-5w4.33.

    Runs after the exo forward (exo gets the original body and decides) and
    after the text-only refusal, before any pixel reaches prefill. Without it
    a picture the backend never receives -- a URL it would have to fetch, a
    payload that is not base64 -- left the <image:digest> placeholder as the
    only trace of the picture, and the model answered 200 from that: a reply
    invented rather than read. Bytes the backend could not decode, or more
    pictures than it reads, raised inside the request instead: Flask's opaque
    500, for a request that fails the same way every time.

    Every code is HTTP 400 -- each is a property of the request, not a server
    fault -- with the shape of the text-only refusal plus "param", the
    offending part. Checked in this order:

      too_many_images          the backend declares max_images_per_request
                               (vLLM: 1) and the request carries more image
                               parts; a backend that declares none has no cap
      image_url_not_supported  an image part whose URL is not a data: URL
                               (http, https, file, any other scheme, none, or
                               not a string). faxl does not fetch: fetching is
                               a product decision not taken here
      image_base64_invalid     a data: URL whose payload is not base64
      image_not_decodable      a data: URL with no bytes, or bytes Pillow
                               cannot decode the way the backends do

    The first offending part, in request order, is the one named.
    """
    parts = []
    for i, m in enumerate(body.get("messages") or []):
        c = m.get("content")
        if not isinstance(c, list):
            continue
        for j, part in enumerate(c):
            if (isinstance(part, dict)
                    and part.get("type") in ("image_url", "input_image", "image")):
                parts.append((i, j, part))
    n = len(parts)

    def refuse(code, message, param):
        return {"error": {"message": message, "type": _IMAGE_REFUSAL_TYPE[code],
                          "code": code, "backend": backend.name, "param": param}}

    cap = getattr(backend, "max_images_per_request", None)
    if cap is not None and n > cap:
        return refuse("too_many_images",
                      f"This backend reads at most {cap} image(s) per request, "
                      f"and the request carried {n}. faxl will not answer from "
                      f"a placeholder for the pictures it cannot read. Send at "
                      f"most {cap} image(s) per request.", "messages")
    for k, (i, j, part) in enumerate(parts, 1):
        _digest, problem = _read_image_url(_image_part_url(part))
        if problem is not None:
            code, reason = problem
            return refuse(code,
                          f"Image {k} of {n} (messages[{i}].content[{j}]) "
                          f"{reason}. {_IMAGE_REFUSAL_TAIL[code]}",
                          f"messages[{i}].content[{j}]")
    return None


def _marker_text_param(body):
    """JSON path of the first string under `messages`, then `tools`, holding
    text in the form of the picture marker; None when there is none. Picture
    parts are skipped: their URL never reaches the prompt."""
    def walk(value, path):
        if isinstance(value, str):
            return path if _IMAGE_ATOM_RE.search(value) else None
        if isinstance(value, dict):
            if value.get("type") in ("image_url", "input_image", "image"):
                return None
            items = [(f"{path}.{k}", v) for k, v in value.items()]
        elif isinstance(value, list):
            items = [(f"{path}[{i}]", v) for i, v in enumerate(value)]
        else:
            return None
        for sub, v in items:
            hit = walk(v, sub)
            if hit is not None:
                return hit
        return None
    for key in ("messages", "tools"):
        hit = walk(body.get(key), key)
        if hit is not None:
            return hit
    return None


def _image_marker_refusal(body, n_images, spans, backend):
    """The 400 body when the prompt holds more picture markers than the
    request carries pictures, or None. Halo-5w4.35.

    Every picture becomes the text <image:16 hex> (_flatten_multimodal), and
    every reader finds the pictures again by matching that text in the decoded
    prompt: _atom_spans here, vllm_backend's _with_image_placeholders and the
    Mac line's prefill_with_images. Text a client typed in that form -- or a
    marker echoed back in history -- is the same characters, so the same
    token ids: no reader and no cache key can tell it from a picture, and the
    backends raised on the count (an opaque 500). Keeping it distinct would
    mean carrying "which match is a picture" outside the token stream through
    the placement, the lookup, entry_key and both backends; rewriting the
    client's text would change what the model reads without saying so. So it
    is refused by name, with where it is.

    `spans` is _atom_spans(tok, ids): the pattern is _IMAGE_ATOM_RE (eight or
    more hex digits), vLLM's too. Text in that form with no picture in the
    request is not refused: nothing reads markers then, and it is text.
    """
    if len(spans) <= n_images:
        return None
    where = _marker_text_param(body)
    lead = where if where is not None else "The request's text"
    return {"error": {
        "message": (
            f"{lead} holds text in the form of faxl's picture marker "
            f"(\"<image:\", eight or more hex digits, \">\"). faxl writes that "
            f"marker into the prompt where each picture goes and finds the "
            f"pictures again by it; this prompt holds {len(spans)} markers for "
            f"{n_images} picture(s), so faxl cannot tell the pictures from the "
            f"text, and will not guess. Change that text (for example, put a "
            f"space after \"<image:\") and send the request again."),
        "type": "unsupported_content", "code": "image_marker_text_in_prompt",
        "backend": backend.name,
        "param": where if where is not None else "messages"}}


def _context_length_refusal(ids, images, backend):
    """The 400 body for a prompt the engine cannot hold, or None. Halo-5w4.35.

    The backend declares its window with a METHOD, context_window(ids,
    images) -> (prompt_tokens, max_model_len): the tokens the engine itself
    will read for this prompt (a picture as its expanded image tokens) and the
    most prompt and reply tokens it serves together. Looked up as a method so
    that a failure inside it raises, instead of reading as "no limit" the way
    an AttributeError inside a property read by getattr(..., None) would. A
    backend without it (mlx; exo forwards before this point) declares no
    limit.

    Refused exactly when the engine would refuse: no room for one generated
    token (vllm_backend.generate's budget check). The engine already clamps
    max_tokens to the room that is left, so no request it serves changes.
    """
    measure = getattr(backend, "context_window", None)
    if measure is None:
        return None
    n, window = measure(ids, images)
    if n < window:
        return None
    pictures = (" (each picture counted as the image tokens the model expands "
                "it into)" if images else "")
    hint = ", or send a smaller picture" if images else ""
    return {"error": {
        "message": (
            f"The prompt is {n} tokens as the model reads it{pictures}, and "
            f"this model serves at most {window} tokens of prompt and reply "
            f"together (max_model_len), so a prompt may be at most "
            f"{window - 1} tokens. faxl does not cut a prompt to fit. Shorten "
            f"the conversation{hint} and send it again."),
        "type": "invalid_request_error", "code": "context_length_exceeded",
        "backend": backend.name, "param": "messages"}}


def _deferred_checkpoint_position(pos, spans, seg):
    """Where a DEFERRED (vLLM) backend may checkpoint a prompt that carries
    pictures: on the absolute grid, and never past the first picture.

    `spans` is _atom_spans' list (prompt order); its first entry's start is
    the first image atom. A position at or before it is floored to the grid,
    as the deferred path always did. A position past it becomes the deepest
    grid line at or before the atom: the pre-image prefix. The caller drops 0.

    Why: vLLM expands the atom into the model's image tokens, so after the
    first picture a faxl position names a different place in the engine
    stream, and vllm_backend refuses any save or resume there. Before this, a
    long question after a picture put the tail anchor's grid line past the
    atom and the request died with an opaque 500 (Halo-5w4.33); now it is
    served and only the pre-image prefix is cached. An image-free prefix keys
    like any text prefix (entry_key over the regions below it: none), and the
    grid floor keeps every boundary one the cold path also cuts (Halo-a47).
    """
    first = spans[0][0][0]
    return (min(pos, first) // seg) * seg


def _flatten_multimodal(messages):
    """Make OpenAI multimodal content templatable, and say what was in it.

    A multimodal message carries a LIST of parts -- text and image_url -- where
    a chat template expects a string. Passed through as-is the template
    stringifies the list, the image is silently discarded, and the model is
    handed the wreckage: measured, a 30,000-character base64 JPEG arrived at
    exo as 21 tokens and the model answered "1234567890" from nothing.

    Returns (messages_for_template, n_images). The images themselves are NOT
    dropped -- on the exo path the ORIGINAL body is forwarded, images intact,
    and this projection exists only so the ladder has token ids to hash. An
    image is represented by a stable placeholder so two requests with the same
    picture hash alike and a different picture does not.
    """
    out, n_images = [], 0
    for m in messages:
        c = m.get("content")
        if not isinstance(c, list):
            out.append(m)
            continue
        parts = []
        for part in c:
            if not isinstance(part, dict):
                parts.append(str(part))
                continue
            kind = part.get("type")
            if kind == "text":
                parts.append(part.get("text", ""))
            elif kind in ("image_url", "input_image", "image"):
                n_images += 1
                url = _image_part_url(part)
                # Identify the image by a digest, never by its bytes: the
                # ladder hashes this text, and a megabyte of base64 in the
                # prefix would be hashed on every request for nothing.
                #
                # THE DIGEST IS OF DECODED PIXELS where we can decode them.
                # The same photograph as HEIC and as JPG, or re-encoded at a
                # different quality, is the SAME PICTURE to the model and must
                # be the same cache key; hashing the container makes that a
                # miss. This is the one definition of image identity across
                # every backend -- exo computes the same hash the same way
                # (engines/mlx/vision.py:712), which is asserted by
                # tests/test_media_regions.py against exo's own decoder.
                digest = _image_digest(url)
                parts.append(f"<image:{digest}>")
            else:
                parts.append(json.dumps(part, sort_keys=True))
        mm = dict(m)
        mm["content"] = "\n".join(x for x in parts if x)
        out.append(mm)
    return out, n_images


_IMAGE_ATOM_RE = re.compile(r"<image:[0-9a-f]{8,}>")


def _image_regions(tok, ids):
    """The pictures this prompt carries, as MediaRegions.

    The mlx line's counterpart to media_regions.find_regions. That function
    looks for a run of PAD ids, which is the shape exo sees because exo
    expands the picture before faxl reads the stream. Here the ladder hashes
    the image to an <image:digest> text atom and the expansion happens later,
    inside the backend, so the run to find is textual -- but the RESULT is the
    same type, carrying the same pixel digest, so everything downstream
    (entry_key, truncate_to_first_mismatch) is shared with exo rather than
    reimplemented.

    The digest in the atom IS the content hash: _image_digest computes it from
    decoded RGB pixels, by the same definition exo uses, so the two backends
    agree on what "the same picture" means.
    """
    spans = _atom_spans(tok, ids)
    out = []
    for (a, b), digest in spans:
        out.append(MediaRegion(digest, a, b))
    return out


def _atom_spans(tok, ids):
    """[start, end) of every <image:digest> atom in the token stream.

    THE LADDER'S OWN RULE, FINALLY ENFORCED. Every comment and test in this
    codebase says a checkpoint boundary may fall before or after a picture
    but never inside it -- "half an image is not a smaller image, it is a
    different one". Nothing enforced it on the write path.

    Measured on the camera roll: the atom occupied tokens 1780..1798 and the
    grid snap put a checkpoint at 1792, twelve tokens INSIDE it. The stored
    blob therefore contained one photograph's digest, and the NEXT photograph
    resumed from it: 13 tokens prefilled, the vision tower never run, and a
    confident description of a picture nobody had looked at. That is a wrong
    answer served fast, which is the worst thing a cache can do.

    Found by decoding, not by scanning for a token id: the atom is not one
    token and not a fixed id run ("<image:a07175b9b60dc5b2>" is 18 ids on
    Qwen3-VL and the pieces change with the digest), so the only reliable
    way to locate it is to decode token by token and track offsets.
    """
    try:
        pieces = [tok.decode([int(t)]) for t in ids]
    except Exception:                                    # noqa: BLE001
        return []          # cannot decode: caller keeps the plain grid
    text = "".join(pieces)
    # character offset -> token index
    starts, off = [], 0
    for piece in pieces:
        starts.append(off)
        off += len(piece)
    spans = []
    for m in _IMAGE_ATOM_RE.finditer(text):
        a, b = m.start(), m.end()
        # first token whose text begins at or before `a`, and the token after
        # the one containing b-1
        i = 0
        while i + 1 < len(starts) and starts[i + 1] <= a:
            i += 1
        j = i
        while j < len(starts) and starts[j] < b:
            j += 1
        # ((start_token, end_token), the digest inside the atom)
        spans.append(((i, j), m.group(0)[len("<image:"):-1]))
    return spans


def _clear_of_atoms(pos, spans):
    """Move `pos` back to the start of any image atom it lands inside.

    Before the picture, never through it -- see the call site for why the
    atom specifically, and why this is not safe_depth(). The atom's start is
    also the position that pays: preamble and question are identical across
    photographs, so a checkpoint there is shared by every one of them.
    """
    for (a, b), _digest in spans:
        if a < pos < b:
            return a
    return pos


def _resolve_model_dir(model_id):
    """Where this model's TOKENIZER files live — HF cache, else exo's own dir.

    Two stores exist on a machine running both: faxl loads through the
    HuggingFace cache, while exo downloads into ~/.exo/models and names the
    directory `org--repo`. A model exo fetched itself is therefore invisible to
    hf_repo_to_path, which raises LocalEntryNotFoundError rather than looking
    further — measured on Qwen3-VL, which exo had and the HF cache did not.

    Only the small files are needed here (tokenizer, chat template, config):
    the WEIGHTS stay where they are and run in exo's engine, never in this
    process. Checking both places costs nothing and means faxl can front any
    model exo can run.
    """
    try:
        return hf_repo_to_path(model_id)
    except Exception as hf_err:   # noqa: BLE001 — try exo's dir before giving up
        alt = os.path.expanduser(os.path.join(
            os.environ.get("EXO_MODELS", "~/.exo/models"),
            str(model_id).replace("/", "--")))
        if os.path.isfile(os.path.join(alt, "config.json")):
            print(f"   (not in the HF cache; using exo's copy at {alt})",
                  flush=True)
            # A Path, not a str: mlx_lm joins with `/` on whatever it is given.
            from pathlib import Path as _Path
            return _Path(alt)
        # THIRD: fetch the tokenizer ourselves. On a remote backend the
        # weights belong to exo and may not be placed yet (exo downloads on
        # first request), but faxl needs the small files NOW to start. Making
        # the operator pre-fetch by hand is a step a machine can do: it is a
        # handful of JSON files, seconds, and no weights. Explicitly
        # ignore_patterns the weights so a stray glob can never pull 70 GB
        # into this process's cache.
        #
        # Opt out with FAXL_NO_TOKENIZER_FETCH=1 for a strictly offline box,
        # where the right answer is to fail loudly rather than reach out.
        if os.environ.get("FAXL_NO_TOKENIZER_FETCH") != "1":
            try:
                from huggingface_hub import snapshot_download
                print(f"   (tokenizer not local; fetching the small files for "
                      f"{model_id} — weights stay with the backend)", flush=True)
                got = snapshot_download(
                    str(model_id),
                    allow_patterns=["*.json", "tokenizer*", "*.txt", "*.model",
                                    "merges.txt", "vocab*"],
                    ignore_patterns=["*.safetensors", "*.bin", "*.gguf", "*.pt"],
                )
                if os.path.isfile(os.path.join(got, "config.json")):
                    from pathlib import Path as _Path
                    print(f"   (tokenizer at {got})", flush=True)
                    return _Path(got)
            except Exception as fetch_err:  # noqa: BLE001 — fall through
                print(f"!! tokenizer fetch failed ({type(fetch_err).__name__}: "
                      f"{fetch_err})", flush=True)
        raise RuntimeError(
            f"cannot find {model_id!r} in the HuggingFace cache ({hf_err}) or "
            f"at {alt}, and could not fetch its tokenizer. faxl needs the "
            f"tokenizer files only — the weights stay with the backend — so "
            f"fetch the model, or point EXO_MODELS at the directory holding "
            f"it.") from hf_err


def _trimmable_from_config(cfg, model_path):
    """Is this model's cache trimmable (pure-KV), without loading weights?

    `can_trim_prompt_cache` is `all(c.is_trimmable())` over cache INSTANCES,
    and make_prompt_cache builds those from the model's structure alone. So a
    skeleton model instantiated from config.json gives the same answer as the
    real thing at a fraction of the cost.

    FAILS CLOSED. Any doubt returns False, because the two errors are not
    symmetric: a wrong True runs trim_prompt_cache against a hybrid's
    ArraysCache -- one rolled-up recurrent tensor with no position to trim to
    -- which is the corruption class this project has been bitten by twice. A
    wrong False merely forgoes the trim-on-load optimisation.
    """
    try:
        from mlx_lm.utils import _get_classes
        mc, ma = _get_classes(config=cfg)
        skeleton = mc(ma.from_dict(cfg))
        # The language half owns the cache on a vision model -- see
        # _model_cache_owner below, which this predates in file order. Inlined
        # rather than called so this stays usable at import time.
        _owner = getattr(skeleton, "language_model", None)
        if _owner is None or not hasattr(_owner, "make_cache"):
            _owner = skeleton
        trimmable = can_trim_prompt_cache(make_prompt_cache(_owner))
        del skeleton
        return bool(trimmable)
    except Exception as e:  # noqa: BLE001 — never fatal, never optimistic
        print(f"!! could not determine the cache family without weights "
              f"({type(e).__name__}: {e}) — assuming HYBRID (not trimmable), "
              f"which is the safe answer", flush=True)
        return False


# trust_remote_code: Kimi ships a custom tiktoken tokenizer (tokenization_kimi.py) that
# must execute to load. This means ANY model repo loaded here runs its own tokenizer
# code — only point the model at repos you trust. Off by default on mlx; opt in
# via FAXL_TRUST_REMOTE_CODE=1 (Granite doesn't need it). On exo it follows the
# config's exo.trust_remote_code (on by default, as faxl_exo_up.sh always set
# it: Kimi's tokenizer is code), which FAXL_TRUST_REMOTE_CODE also overrides.
_TRUST = (EXO["trust_remote_code"] if _BACKEND_NAME == "exo"
          else os.environ.get("FAXL_TRUST_REMOTE_CODE", "0") == "1")
if _BACKEND_NAME in _MLX_BACKENDS:
    from mlx_lm.utils import hf_repo_to_path
else:
    hf_repo_to_path = _mlx_only("mlx_lm.utils.hf_repo_to_path")

# VISION MODELS LOAD THROUGH mlx_vlm, AND THE CHOICE IS MADE BY THE MODEL.
#
# mlx_lm.load will happily load Qwen3-VL and give you a working TEXT model: it
# binds the language half and never touches the vision tower. Nothing fails, so
# an image arrives as a placeholder and the reply is invented rather than read.
# For OCR that is the worst failure available -- confident, well formatted, and
# entirely fabricated.
#
# So the loader is selected by config.json's model_type, not by an env var. A
# customer who installs faxl and runs the shipped Qwen3-VL gets vision because
# the model has it, without knowing that mlx_lm and mlx_vlm are different
# libraries. That is the whole point of the console.
def _is_vision_model(model_id):
    """True when the repo declares a vision tower. Read from config.json
    rather than guessed from the name: 'VL' in a repo id is a convention, and
    a convention is not a contract."""
    try:
        import json as _json
        import pathlib
        # load_config() divides its argument as a Path, so a str raises
        # TypeError -- and this used to swallow that and return False, which
        # meant a LOCAL vision model silently loaded as a text model and
        # invented its answers. Read config.json directly: it is one file, and
        # failing to detect vision must never be the quiet outcome.
        # An absolute path to a model directory is already the answer.
        # _resolve_model_dir maps a HUB ID into the cache, and given a path it
        # mangles it into "--Users--andrewmorgan--..." and then fails -- which
        # this used to swallow, loading a vision model as text.
        d = pathlib.Path(os.path.expanduser(str(model_id)))
        if not (d / "config.json").is_file():
            d = pathlib.Path(_resolve_model_dir(model_id))
        cfg = _json.loads((d / "config.json").read_text())
    except Exception as e:  # noqa: BLE001
        print(f"!! could not read config.json for {model_id} ({e}); "
              f"assuming text-only — images will be REFUSED, not invented",
              flush=True)
        return False
    declared = bool(cfg.get("vision_config")
                    or str(cfg.get("model_type", "")).endswith("_vl")
                    or any("ForConditionalGeneration" in a
                           for a in (cfg.get("architectures") or [])))
    if declared and faxl_config.checkpoint_has_vision_weights(str(d)) is False:
        # The config says vision; the weight files carry none (a text-only
        # conversion). Loading it through mlx_vlm would report "vision model
        # ready" and then fail the first photograph. Say so, and load it as
        # the text model it is: pictures are refused with a way forward.
        print(f"!! {model_id}: the config declares a vision tower but its "
              f"weight files contain none -- loading as text-only; images "
              f"will be REFUSED, not invented", flush=True)
        return False
    return declared


VISION = False
def _load_text_model(path):
    """load() for the text path, with the formats mlx_lm does not read itself.

    mlx_lm.load goes straight to load_weights(strict=True), so a checkpoint in
    a quantisation format it does not know is rejected wholesale -- Ling-3.0
    ships compressed-tensors and produced "Received 26496 parameters not in
    model". Converting those is faxl's job, not a patch to mlx_lm: see
    mlx_models/compressed_tensors.py (mac line).

    A format nobody here can read RAISES, naming the format and the model. It
    must never fall through to a loader that would bind the weights as
    something else -- the same rule as the vision path above, and for the same
    reason: a quiet wrong answer is the worst outcome available.
    """
    try:
        from faxl.engine.mlx_models import compressed_tensors as _ct
    except ImportError:
        _ct = None
    if _ct is not None:
        converted = _ct.ensure_mlx_format(path)
        if converted is not None:
            path = converted
    return load(path, tokenizer_config={"trust_remote_code": _TRUST})


def _load_vision_model(path):
    """mlx_vlm.load(), with the memory-mapped PLE table where one applies.

    Qwen3.8-Flash-Next wires a 29.8 GiB trigram lookup table into RAM and reads
    about sixteen rows of it per token. mlx_vlm ships a row-addressable mmap
    store for exactly that, but it is off unless config.json names a manifest
    and nothing builds one -- so faxl builds it, once, and loads the prepared
    view instead. Measured: 76.2 -> 46.4 GiB resident, 27.7s -> 11.9s to load,
    byte-identical output. That is the difference between this model running on
    a 64 GB Mac and not running at all.

    A checkpoint with no PLE, an unsupported layout, or a view that cannot be
    built completely all return None and load the stock way -- slower, correct.
    FAXL_PLE_STORAGE=0 forces that path.
    """
    from mlx_vlm import load as _vlm_load
    try:
        from faxl.engine.mlx_models import ple_storage_setup as _ple
    except ImportError:
        _ple = None
    if _ple is not None:
        prepared = _ple.ensure_ple_storage(path, MODEL)
        if prepared is not None:
            path = prepared
    return _vlm_load(path)


# NO MODEL YET (2026-09-22, "batteries not included"). _LOAD_FROM is None when
# the weights are not on this Mac: the proxy still comes up, because it serves
# the console -- the page where the person chooses a model and starts the
# download. model/tok/PROCESSOR stay None and /v1 answers 503 saying so; the
# console does not touch them.
# A MODEL THAT WILL NOT LOAD MUST NOT COST YOU THE CONSOLE.
#
# The model id is written to config.json when the switch is REQUESTED, before
# anything has tried to load it. So one bad choice used to leave the proxy
# dying at import on every restart -- and the console, the only place to undo
# it, is served BY that proxy. Recovery was hand-editing JSON, which is a dead
# end a user reaches in one click.
#
# So a load failure is caught here, not fatal: fall back to the last model that
# DID load (config "last_good_model"), else come up with no model at all --
# the "batteries not included" path, which already serves the console. The
# failure is printed by name and left in LOAD_ERROR for the console to show.
#
# Deliberately NOT pre-validating the load before persisting: proving a 5 GB
# checkpoint loads means loading it, and the console cannot hold a request
# open that long. Last-known-good is the honest version.
LOAD_ERROR = None
_LOAD_FELL_BACK_FROM = None


def _load_fallback_model():
    """The last model that loaded here, if it is not the one that just failed."""
    last = faxl_config.get("last_good_model")
    if not last or str(last) == str(MODEL):
        return None, None
    try:
        p = _resolve_model_dir(last)
    except Exception:                                    # noqa: BLE001
        return None, None
    return (last, p) if p else (None, None)


model = tok = PROCESSOR = None
if _LOAD_FROM is None:
    print("serving the console only: no model loaded. Pick one in the "
          "console and faxl will fetch it.", flush=True)
elif _BACKEND_NAME == "mlx":
    try:
        VISION = _is_vision_model(_LOAD_FROM)
        if VISION:
            # The processor carries the tokenizer AND the image preprocessing. The
            # rest of this proxy only ever wants the tokenizer -- apply_chat_template
            # for the ladder, stop ids for the decode -- so it is unwrapped here and
            # the processor kept beside it for the pixels.
            print(f"loading {MODEL} (vision) ...")
            model, PROCESSOR = _load_vision_model(_LOAD_FROM)
            tok = getattr(PROCESSOR, "tokenizer", PROCESSOR)
            print(f"vision model ready: images are read, not placeheld", flush=True)
        else:
            print(f"loading {MODEL} ...")
            model, tok = _load_text_model(_LOAD_FROM)
            PROCESSOR = None
        # It loaded. Remember it, so the NEXT bad choice has somewhere to fall back
        # to. Written after the load, never before -- that ordering is the fix.
        if str(faxl_config.get("last_good_model") or "") != str(MODEL):
            try:
                faxl_config.write({"last_good_model": str(MODEL)})
            except Exception as _exc:                        # noqa: BLE001
                print(f"!! could not record last_good_model: {_exc}", flush=True)
    except Exception as _load_exc:                       # noqa: BLE001
        # Loud, named, and NOT fatal. See the comment above the LOAD_ERROR
        # definition: the console is the way out of this state.
        LOAD_ERROR = f"{type(_load_exc).__name__}: {_load_exc}"
        print(f"!! {MODEL} did not load -- {LOAD_ERROR}", flush=True)
        model = tok = PROCESSOR = None
        VISION = False
        _fb_id, _fb_path = _load_fallback_model()
        if _fb_path is not None:
            print(f"!! falling back to the last model that loaded here: {_fb_id}",
                  flush=True)
            try:
                VISION = _is_vision_model(_fb_path)
                if VISION:
                    model, PROCESSOR = _load_vision_model(_fb_path)
                    tok = getattr(PROCESSOR, "tokenizer", PROCESSOR)
                else:
                    model, tok = _load_text_model(_fb_path)
                MODEL = _fb_id
                _LOAD_FELL_BACK_FROM = LOAD_ERROR
                print(f"serving {MODEL} instead. Fix the choice in the console.",
                      flush=True)
            except Exception as _fb_exc:                     # noqa: BLE001
                print(f"!! the fallback did not load either ({_fb_exc}); serving "
                      f"the console only.", flush=True)
                model = tok = PROCESSOR = None
                VISION = False
        else:
            print("serving the console only. Pick another model there.",
                  flush=True)
else:
    # NO WEIGHTS ON THIS PATH. Execution happens on the backend, so loading the
    # model here would mean holding a second copy of it — and for a 700GB Kimi
    # K3 across a Thunderbolt cluster it defeats the entire point: the reason
    # to use a cluster is that the model does NOT fit on one machine.
    #
    # The TOKENIZER is still required: this proxy applies the chat template,
    # derives the stop ids, and hands token ids to the ladder.
    print(f"loading {MODEL} tokenizer only (backend={_BACKEND_NAME}) ...")
    if _BACKEND_NAME not in _MLX_BACKENDS:
        # NON-MLX TOKENIZER (2026-09-25, stage B). This used to raise: the
        # tokenizer-only path below is mlx_lm's, so a vllm proxy could not get
        # a tokenizer at all and refused at boot. transformers is the loader
        # every non-mlx backend already depends on (vLLM requires it), and the
        # STOP-ID RULE IS THE SAME ONE the mlx path uses -- the union of the
        # model's eos ids, read from the tokenizer and from config.json --
        # because a missing eos runs every reply to max_tokens.
        # Construct ONE engine before the namespace/index. Its tokenizer,
        # revision and runtime are the authority for both lookup and execution.
        from faxl.engine.backends import make_backend
        BACKEND = make_backend(_BACKEND_NAME)
        tok = BACKEND.tokenizer
        _LOAD_FROM = BACKEND.snapshot_path
        SEG = BACKEND.checkpoint_grid
        if SEG <= 0:
            raise RuntimeError("backend checkpoint grid must be positive")
        tok.faxl_eos_ids = sorted(BACKEND.stop_ids)
        model = None
        PROCESSOR = None
        # TRIM CAPABILITY follows the cache engine, not the model family: the
        # mlx probe below builds a skeleton mlx model, which does not exist
        # here. CACHE.can_trim() is the authority (see the CACHE seam).
        TRIMMABLE = False
    else:
        from mlx_lm.utils import hf_repo_to_path, load_config, load_tokenizer
        _mpath = _resolve_model_dir(MODEL)
        _cfg = load_config(_mpath)
        # eos_token_ids MUST be passed. mlx_lm's load() does
        #   load_tokenizer(path, cfg, eos_token_ids=config.get("eos_token_id"))
        # and that kwarg is the ONLY source of tok.eos_token_ids. Omitting it
        # silently drops Kimi's <|im_end|> (163586) and every reply then runs to
        # max_tokens — the exact failure the STOP_IDS comment below records.
        tok = load_tokenizer(_mpath, {"trust_remote_code": _TRUST},
                             eos_token_ids=_cfg.get("eos_token_id", None))
        # THE CHAT TEMPLATE MAY LIVE IN ITS OWN FILE, and load_tokenizer does
        # not look there.
        #
        # Qwen3-VL ships `chat_template.json` beside `tokenizer_config.json`
        # rather than inside it -- both the 4B and the 32B do. On the mlx path
        # mlx_vlm.load() picks it up, so single-machine works; the exo path
        # loads the tokenizer ALONE, gets no template, and every request died
        # in apply_chat_template with "Cannot use chat template functions
        # because tokenizer.chat_template is not set". Measured: eight
        # photographs, eight HTTP 500s, on a cluster that was serving fine.
        #
        # Read it ourselves when it is missing. A template is the model's own
        # prompt format -- getting it wrong is silent corruption, not an
        # error -- so this only ever FILLS AN ABSENCE and never overrides a
        # template the tokenizer already carries.
        _inner = getattr(tok, "_tokenizer", tok)
        if not getattr(_inner, "chat_template", None):
            for _name in ("chat_template.json", "chat_template.jinja"):
                _tpl = os.path.join(str(_mpath), _name)
                if not os.path.isfile(_tpl):
                    continue
                try:
                    _raw = open(_tpl).read()
                    _val = (json.loads(_raw).get("chat_template")
                            if _name.endswith(".json") else _raw)
                except (OSError, ValueError) as _e:
                    print(f"!! {_name} unreadable ({_e}) — the chat template "
                          f"is still missing", flush=True)
                    continue
                if _val:
                    _inner.chat_template = _val
                    print(f"chat template loaded from {_name}", flush=True)
                    break
            else:
                print("!! NO CHAT TEMPLATE for this model: neither the "
                      "tokenizer config nor chat_template.json carries one, "
                      "so every request will fail in apply_chat_template",
                      flush=True)
        model = None
        # No pixels are processed here: on the cluster path the ORIGINAL body is
        # forwarded with its images intact and exo's runner does the vision work.
        PROCESSOR = None
# STOP IDS: stop on the UNION of the model's eos ids. Granite terminates on
# tok.eos_token_id; Kimi's chat turns end on <|im_end|> (163586), exposed via
# tok.eos_token_ids, NOT tok.eos_token_id ([EOS]=163585). Missing it runs every
# reply to max_tokens. Union is correct for both families.
STOP_IDS = set()
# NO TOKENIZER ON THE NO-MODEL PATH. _LOAD_FROM is None when the weights are
# not on this Mac ("batteries not included"): model/tok/PROCESSOR stay None by
# design, the console comes up, and /v1 answers 503. Everything below reads the
# tokenizer, so it has to be skipped rather than run against None -- it was
# crashing three lines after printing "serving the console only", which meant
# the proxy could not start AT ALL on a machine with no model. Measured 2026-09-22:
# a bare `import faxl_proxy` with no weights raised
# AttributeError: 'NoneType' object has no attribute 'eos_token_id'.
if tok is None:
    print("no tokenizer: stop ids stay empty until a model is chosen.",
          flush=True)
elif tok.eos_token_id is not None:
    STOP_IDS.add(int(tok.eos_token_id))
# eos_token_ids is a COLLECTION on mlx_lm's tokenizer and sometimes a bare int
# on the one a VLM processor carries. Iterating an int raises, and it raised at
# import -- the proxy would not start at all on the shipped vision model.
# faxl_eos_ids is what the transformers branch above sets (it may not write to
# eos_token_ids -- transformers guards that name); eos_token_ids is mlx_lm's.
_eos_extra = (getattr(tok, "faxl_eos_ids", None)
              or getattr(tok, "eos_token_ids", None))
if isinstance(_eos_extra, int):
    _eos_extra = [_eos_extra]
STOP_IDS |= {int(x) for x in (_eos_extra or ())}
# AND THE MODEL'S OWN config.json, WHICH IS THE ONLY COMPLETE SOURCE ON THE
# VISION PATH. `eos_token_ids` is an mlx_lm tokenizer field; a VLM processor
# carries a plain HuggingFace tokenizer, which has eos_token_id (one id) and
# not eos_token_ids (the set). Qwen3-VL declares [151645, 151643] -- <|im_end|>
# AND <|endoftext|> -- and the union above saw only the first.
#
# The cost of missing one is not a slow reply, it is a WRONG one: generation
# runs past the end of the answer, and the replies that came back were pure
# newlines, or the model's next turn talking to itself. Measured on the camera
# roll: "None of the above." and 200 tokens of "\n" where the model had in
# fact answered correctly and then kept going.
# generation_config.json FIRST: it is where a Qwen3-VL keeps its stop ids.
# config.json's eos_token_id is null on this model, so reading only that finds
# nothing. And take the directory straight from MODEL when MODEL already IS a
# directory -- _resolve_model_dir only speaks repo ids and raises on a path,
# which is how this lookup silently found no config at all.
_mdir = (BACKEND.snapshot_path if _BACKEND_NAME not in _MLX_BACKENDS else
         MODEL if os.path.isdir(str(MODEL)) else
         _LOAD_FROM if os.path.isdir(str(_LOAD_FROM)) else None)
if _mdir is None:
    try:
        _mdir = str(_resolve_model_dir(MODEL))
    except Exception:                                    # noqa: BLE001
        _mdir = None
for _fname in ("generation_config.json", "config.json"):
    if not _mdir:
        break
    try:
        with open(os.path.join(_mdir, _fname)) as _fh:
            _cfg_eos = json.load(_fh).get("eos_token_id")
    except OSError:
        continue
    if isinstance(_cfg_eos, int):
        _cfg_eos = [_cfg_eos]
    if _cfg_eos:
        STOP_IDS |= {int(x) for x in _cfg_eos}
if not STOP_IDS and tok is not None:
    # Only fatal when a model IS loaded: with no stop ids every reply would run
    # to max_tokens, which is a broken serve rather than a slow one. With NO
    # model there is nothing to serve yet -- /v1 answers 503 and the console is
    # the point -- so exiting here would take the console down with it, and the
    # console is where the person picks the model that fixes this.
    raise SystemExit(
        "!! NO STOP IDS. Every reply would run to max_tokens. Check the "
        "model's config.json eos_token_id and its tokenizer.")
print(f"stop ids: {sorted(STOP_IDS)}")
# THE SAMPLER IS THE mlx BACKEND'S, so it is built only there. This was a
# module-level call for every backend and therefore a hard refusal at boot on
# vllm (measured 2026-09-26 on a bare Linux install: "mlx_lm make_sampler is an
# mlx-only path"). Both consumers are mlx-only too -- the warmup below and
# LocalMlxBackend's constructor -- so a vllm process needs no sampler at all:
# vLLM takes its sampling from SamplingParams inside the engine.
sampler = make_sampler(temp=0.0) if _BACKEND_NAME in _MLX_BACKENDS else None
# ---- THE CACHE MUST COME FROM THE MODEL THAT OWNS IT ---------------------------
#
# make_prompt_cache(model) defers to model.make_cache() when it exists and
# otherwise returns [KVCache] * len(model.layers). On a VISION model the
# top-level object is a wrapper -- Model(vision_tower, language_model) -- and it
# has NO make_cache: the one that matters belongs to model.language_model. So
# passing the wrapper gets the FALLBACK, and for a hybrid VLM that fallback is
# wrong in the way this project has been bitten by twice.
#
# Measured on Qwen3.8-Flash-Next (2026-10-01): the model's own make_cache gives
# 36 ArraysCache + 12 QSAKVCache, and make_prompt_cache(wrapper) gave 48 plain
# mlx_lm KVCache instead. Two separate failures followed:
#
#   * every request died in the recurrence --
#     TypeError: create_attention_mask() missing 2 required positional
#     arguments: 'return_array' and 'window_size'
#     because mlx_lm's KVCache.make_mask forwards offset= to mlx_lm's
#     create_attention_mask, while the SSM path calls mlx_vlm's, whose
#     signature is (N, offset, return_array, window_size). The wrong cache
#     class is what put an mlx_lm cache on an mlx_vlm code path at all.
#
#   * TRIMMABLE came back TRUE, because 48 KVCaches are all trimmable. That is
#     the silent half: it would run trim_prompt_cache against a recurrent
#     state with no position to trim to.
#
# Qwen3-VL was unaffected only because it is pure-KV, so the fallback happened
# to produce the right classes. That is luck, not correctness.
def _model_cache_owner(model_obj):
    """The object whose make_cache() describes this model's cache.

    The language half when there is one AND it declares make_cache; otherwise
    the model itself, which is the pre-existing behaviour for text models.
    """
    lm = getattr(model_obj, "language_model", None)
    if lm is not None and hasattr(lm, "make_cache"):
        return lm
    return model_obj


def _make_cache_for(model_obj):
    """make_prompt_cache, asked of the right object."""
    return make_prompt_cache(_model_cache_owner(model_obj))


# Phase A (plan-kv-model-support rev 4.1): capability detection at boot —
# pure-KV models (KVCache) are trimmable, hybrids (ArraysCache) are not;
# can_trim_prompt_cache detects the family automatically.
if model is not None:
    _cap_probe = _make_cache_for(model)
    TRIMMABLE = can_trim_prompt_cache(_cap_probe)
    del _cap_probe
elif _LOAD_FROM is None:
    # NO MODEL AT ALL. _cfg and _mpath are never bound on this path -- they are
    # set by the tokenizer-only branch -- so the skeleton probe below cannot
    # run. Nothing reads TRIMMABLE until a request arrives, and none can be
    # served until a model is chosen, so the safe default stands until restart.
    TRIMMABLE = False
elif _BACKEND_NAME in _MLX_BACKENDS:
    # No weights loaded, but the ladder still branches on this. The cache
    # FAMILY is fixed by the architecture, not the parameters:
    # make_prompt_cache only asks the model for make_cache()/len(layers), so a
    # skeleton built from config.json alone answers identically. mlx allocates
    # lazily, so nothing is materialised.
    #
    # GUARDED BY BACKEND (2026-09-26): _cfg and _mpath are set only by the mlx
    # tokenizer branch, and the skeleton probe builds an mlx model, so this
    # raised NameError at boot on vllm -- measured on a bare Linux install.
    TRIMMABLE = _trimmable_from_config(_cfg, _mpath)
else:
    # Off mlx, trimmability is a property of the cache ENGINE, not of the
    # model's architecture. It is declared per backend here rather than read
    # from CACHE, because CACHE is built further down (it needs prefill and
    # generate, which are defined after this point) and TRIMMABLE is read by
    # the ladder at boot. The two are asserted against each other where CACHE
    # is chosen, so a disagreement cannot survive startup.
    TRIMMABLE = _TRIMMABLE_BY_BACKEND[_BACKEND_NAME]

# ---- MAIN-THREAD INFERENCE (FAXL_MAIN_THREAD_INFER=1) -------------------------
#
# WHY THIS EXISTS. mlx_lm's gated_delta_ops -- the recurrence behind every
# hybrid/recurrent attention (Ling-3.0-tiny, Kimi Linear) -- ABORTS THE PROCESS
# when it runs on a Werkzeug worker thread:
#
#   Fatal Python error: PyThreadState_Get: ... the GIL is released
#
# With MLX_DISABLE_COMPILE=1 the same call raises instead, which names it:
#
#   RuntimeError: There is no Stream(gpu, 0) in current thread.
#
# Stream 0 belongs to the MAIN thread. A worker cannot acquire it: setting the
# default device in the worker, creating a new stream there, synchronising
# before exit, and touching the op on the main thread first were all tried and
# all still abort (tmp/repro_gated_delta_thread_crash.py in faxl-mac-dev).
# _gated_delta_step_ops is @mx.compile'd upstream, and in a thread with no
# stream 0 the compiled path aborts rather than raising.
#
# So the only thing that works is running the model ON the main thread. This
# does it WITHOUT changing the request flow: the handler still calls
# _chat_impl inside _SERVE_LOCK exactly as before; the work is just executed
# on the main thread instead of the caller's.
#
# OFF BY DEFAULT, deliberately. Granite -- the shipped model -- never reaches
# gated_delta_ops and has served correctly on worker threads for months. This
# is the hot path for every request on a line that works today, so it is opt-in
# rather than a rewrite everybody inherits: faxl_config "main_thread_infer",
# env FAXL_MAIN_THREAD_INFER. _needs_main_thread() turns it on automatically
# for the architectures that cannot run any other way.
#
# It costs no concurrency that was not already lost: _SERVE_LOCK has always
# serialised inference (that is what makes threaded=True safe), so requests
# queued before this and queue now.

# Printed at most once per process: see the enable_thinking retry below. A
# one-element list, not a bare bool, for the same reason _STORE_BYTES is: the
# only writer is inside _chat_impl, and a bare name assigned there would be a
# LOCAL -- the read on the same line then raises UnboundLocalError and turns a
# warning into a 500. Mutating a container needs no global declaration.
_THINK_WARNED = [False]
_MAIN_Q = None          # jobs: (callable, result-queue)
_MAIN_THREAD_INFER = False


# THE UPSTREAM CRASH IS FIXED FROM MLX 0.32.1 (verified on 0.32.3, 2026-10-03).
#
# tmp/repro_gated_delta_thread_crash.py in faxl-mac-dev -- the 14-line reproducer
# written when this was diagnosed -- now runs to its own last line, "if you see
# this line, the bug is fixed upstream", and exits 0 on three consecutive runs.
# Verified beyond the toy op too: bailing_hybrid (through faxl's own module),
# kimi_linear and qwen3_5_moe each loaded and DECODED on a worker thread, then
# survived thread teardown and further mlx work. The abort used to land at
# TEARDOWN, after the worker had already printed its result, so each check ran
# past the join before calling it safe.
#
# KEPT, NOT DELETED, AND GATED ON THE VERSION. Three reasons: the workaround
# costs nothing (_SERVE_LOCK already serialises inference, so main-thread
# execution changes which thread runs it, not how many run at once); somebody
# on an older mlx still needs it; and a regression upstream would otherwise
# come back as a process abort with no explanation. Below the fix version the
# old behaviour stands exactly as before.
_MLX_THREAD_FIX = (0, 32, 1)


def _mlx_version():
    """(major, minor, patch) or None when it cannot be read."""
    try:
        import mlx.core as _mx
        parts = str(_mx.__version__).split(".")[:3]
        return tuple(int("".join(c for c in x if c.isdigit()) or 0) for x in parts)
    except Exception:                                    # noqa: BLE001
        return None


def _needs_main_thread(model_obj):
    """True when this model's layers go through gated_delta_ops.

    Keyed off the loaded module, not a name: a renamed or re-quantised copy of
    the same architecture must behave identically.

    qwen4_exp (Qwen3.8-Flash-Next) is here because 36 of its 48 layers are
    Gated DeltaNet -- the same recurrence as Ling and Kimi, so the same
    worker-thread abort. It loads through mlx_vlm rather than mlx_lm (it has a
    vision tower), so the module read here is
    mlx_vlm.models.qwen4_exp.qwen4_exp; matching the substring covers both that
    and the .language half, whichever object is handed in.

    qwen3_5_moe (Qwen3.5/3.6-35B-A3B, 122B-A10B) joined on 2026-10-03. Its
    parent module qwen3_5.py imports gated_delta_update and builds a
    GatedDeltaNet for self.linear_attn, so it is the same recurrence again --
    but the name shares no substring with the three already listed, so
    detection missed it and every request died on the first DECODE:

        RuntimeError: There is no Stream(gpu, 5) in current thread.

    The prefill and the warm-up both pass (the warm-up runs on the main thread
    by construction), so the proxy comes up looking healthy and fails only when
    somebody asks it something -- which is how this reached a running proxy.
    Keyed on the module, so the 122B and any re-quantised copy are covered too.
    """
    try:
        mod = type(model_obj).__module__ or ""
    except Exception:                                    # noqa: BLE001
        return False
    if not any(k in mod
               for k in ("bailing_hybrid", "kimi_linear", "qwen4_exp",
                         "qwen3_5")):
        return False
    # QWEN3.5/3.6 IS NOT COVERED BY THE MLX FIX. Measured on mlx 0.32.3,
    # 2026-10-13: with the version gate below switching the executor off,
    # "There is no Stream(gpu, N) in current thread" came back on the second
    # request of a fresh proxy (and six times in a long-running one's log);
    # forcing the executor on, the same requests all served. Its failure is a
    # thread-local stream, not the teardown abort 0.32.1 fixed, so the
    # version says nothing about it.
    if "qwen3_5" in mod:
        return True
    # The architecture is one that used to abort. Whether it still does is a
    # question about MLX, not about the model: an unreadable version is treated
    # as old, because guessing "new" here costs a process abort.
    v = _mlx_version()
    if v is not None and v >= _MLX_THREAD_FIX:
        return False
    return True


def _run_on_main(fn):
    """Run fn() on the main thread and return its result (or raise).

    A no-op when the executor is off: fn() runs here, as it always has.
    """
    if not _MAIN_THREAD_INFER or _MAIN_Q is None:
        return fn()
    if threading.current_thread() is threading.main_thread():
        return fn()
    import queue as _q
    box = _q.Queue(maxsize=1)
    _MAIN_Q.put((fn, box))
    ok, value = box.get()
    if ok:
        return value
    raise value


def _main_thread_pump():
    """The main thread's job loop. Runs instead of serving directly.

    Never dies on a job's exception -- it is handed back to the caller and the
    pump keeps running, because this thread IS the server's ability to answer.
    """
    while True:
        job = _MAIN_Q.get()
        if job is None:
            return
        fn, box = job
        try:
            box.put((True, fn()))
        except BaseException as exc:                     # noqa: BLE001
            box.put((False, exc))

# TURNED ON HERE, NOT BY THE USER. The decision needs the LOADED model: an
# architecture whose recurrence cannot run off the main thread is a property of
# the weights, not of anything a person should have to know. So switching to
# Ling in the console is enough -- the next boot detects it and the executor
# comes up with it. The env var and the config key only FORCE it on (or off,
# with 0) for testing.
_cfg_main = faxl_config.get("main_thread_infer", "FAXL_MAIN_THREAD_INFER")
if _cfg_main is not None and str(_cfg_main).strip() not in ("", "auto"):
    _MAIN_THREAD_INFER = str(_cfg_main).strip().lower() in ("1", "true", "yes", "on")
    _why = "forced by configuration"
else:
    _MAIN_THREAD_INFER = _needs_main_thread(model)
    _why = "this architecture's recurrence cannot run on a worker thread"
if _MAIN_THREAD_INFER:
    import queue as _queue_mod
    _MAIN_Q = _queue_mod.Queue()
    print(f"inference runs on the main thread ({_why}); HTTP moves to its own "
          f"thread.", flush=True)


# ---- MAIN-THREAD WARM-UP — REQUIRED, DO NOT REMOVE.
# mlx_lm binds lazy per-module state to a THREAD-LOCAL MLX stream on the first
# forward pass. Werkzeug hands every request a fresh thread, so without this the
# first forward runs on an arbitrary worker thread and llama-family models raise
# "RuntimeError: There is no Stream(gpu, 1) in current thread" on EVERY request
# (100% reproducible, and reproducible outside faxl). Hybrid archs (granite-4.0-h,
# the default) happen not to trip it, which is why it hid for so long.
# One real forward pass here binds that state on the main thread, and every
# worker thread afterwards succeeds. Reported by a tester on llama arch,
# 2026-09-11.
def _warmup():
    t0 = time.time()
    try:
        # THE LANGUAGE HALF, not the wrapper. A vision model's __call__ returns
        # a LanguageModelOutput, which generate_step subscripts and cannot --
        # so the warm-up failed, the GPU stream was never bound on the main
        # thread, and EVERY request then died with "no Stream(gpu, N) in
        # current thread". The warm-up exists precisely to prevent that, and
        # its own error message said so; it just could not run.
        # Same wrapper the backend uses, for the same reason: a VLM's language
        # model returns LanguageModelOutput and generate_step subscripts it.
        _m = getattr(model, "language_model", model)
        if _m is not model:
            from faxl.engine.backends import LocalMlxBackend as _LMB
            _m = _LMB._logits_only(_m)
        _c = make_prompt_cache(_m)
        for _t, _ in zip(generate_step(mx.array([1]), _m, prompt_cache=_c,
                                       sampler=sampler), range(1)):
            pass
        mx.eval([_x.state for _x in _c if hasattr(_x, "state")])
        del _c
        print(f"warm-up: main-thread forward pass ok "
              f"({(time.time()-t0)*1000:.0f} ms)", flush=True)
    except Exception as e:
        # Loud, never fatal: a warm-up failure must not stop the proxy serving,
        # but a silent skip would re-hide the thread-local-stream bug.
        print(f"!! warm-up forward pass FAILED ({type(e).__name__}: {e}) — "
              f"llama-family models may raise 'no Stream(gpu, N) in current "
              f"thread' on every request", flush=True)


if model is not None:
    _warmup()
else:
    # No local forward pass on this path, so the thread-local-stream binding
    # the warm-up exists to force cannot matter here.
    print("warm-up skipped: no local model on this backend", flush=True)
licence = Licence()
probe = Probe()
SEEDS = probe.seeds()   # single source: Rust resolve_seeds() (FAXL_SEEDS-overridable)
# ---- Namespace identity — BEFORE the index, which keys the store with it.
# (KV plan rev 4.1 register #76/130: recorded on every metrics row from day
# one — unretrofittable.) config_hash covers every namespace-defining knob:
# the SKILL's "NOT safe to change" list (seeds + the checkpoint grid) IS this
# hash's field list — a changed knob is a different namespace, so it can
# never silently serve a store written under the old one.
from faxl.engine.ns_identity import NamespaceIdentity, scoped_key, split_meta_rows
_ns_config = {"seeds": list(SEEDS), "width": WIDTH, "d_proj": D_PROJ,
              "family": FAMILY, "ckpt_every": CKPT_EVERY, "ckpt_ratio": CKPT_RATIO}
_ns_backend, _ns_format, _ns_dtype = "mlx", "mlx_safetensors_v1", DTYPE
if _BACKEND_NAME not in _MLX_BACKENDS:
    _runtime = BACKEND.runtime_fingerprint()
    _ns_config["runtime"] = _runtime
    _ns_backend, _ns_format = BACKEND.store_name, BACKEND.cache_format
    _ns_dtype = _runtime["dtype"]
    REVISION = BACKEND.resolved_revision
_cfg_hash = hashlib.sha256(json.dumps(_ns_config, sort_keys=True).encode()).hexdigest()[:16]
NS = NamespaceIdentity(
    tenant_domain=TENANT, model=MODEL, revision=REVISION, backend=_ns_backend,
    dtype=_ns_dtype, cache_format=_ns_format, config_hash=_cfg_hash)
NS_ADOPT = os.environ.get("FAXL_NS_ADOPT", "0") == "1"


def _rec_name(phash):
    """Namespace-scoped resolve-record filename (colon → underscore: the
    canonical scoped key is a facet string, filenames stay portable)."""
    return scoped_key(NS, phash).replace(":", "_") + ".meta.json"


def _ns_verify(expected, stored_tuple, stored_digest):
    """verify_before_load with hard-missing fields treated as refusal (a
    record with no recorded identity must never load across the store)."""
    from faxl.engine.ns_identity import verify_before_load, NamespaceError
    if not stored_tuple or not stored_digest:
        raise NamespaceError("resolve record carries no namespace identity")
    return verify_before_load(expected, stored_tuple, stored_digest)
print(f"projection seeds (from Rust): {SEEDS}", flush=True)
index = Index()
# boot scan for the total-store cap (one pass; then incremental)
try:
    for _d in _POOL_DIRS:
        os.makedirs(_d, exist_ok=True)
    _STORE_BYTES[0] = sum(
        os.path.getsize(os.path.join(_d, f))
        for _d in _POOL_DIRS for f in os.listdir(_d)
        if f.endswith(".safetensors"))
    if len(_POOL_DIRS) > 1:
        print(f"store bytes at boot: "
              f"general {index.pool_bytes(BLOB_DIR)/1e9:.2f} GB "
              f"(cap {STORE_CAP_GB} GB), "
              f"photo {index.pool_bytes(PHOTO_BLOB_DIR)/1e9:.2f} GB "
              f"(cap {PHOTO_CAP_GB} GB)", flush=True)
    else:
        print(f"store bytes at boot: {_STORE_BYTES[0]/1e9:.2f} GB "
              f"(cap {STORE_CAP_GB} GB; one pool — photo and general share "
              f"{BLOB_DIR})", flush=True)
    # AND RECLAIM WHAT NOTHING POINTS AT. Without this, a store that leaked
    # orphans before the sweep existed stays over its cap until the next
    # successful write, and a store leaked right up to the cap would evict live
    # entries to make room for bytes that are already garbage. The index has
    # just been loaded, so the live set is known; _ORPHAN_GRACE_SECS still
    # protects anything a previous process wrote seconds ago.
    _dangling = index.reconcile_meta()
    if _dangling:
        print(f"store: {_dangling} dangling meta row(s) dropped at boot",
              flush=True)
    _orph_n, _orph_b = index.sweep_orphans()
    if _orph_n:
        print(f"store: {_orph_n} orphan blob(s) removed at boot, "
              f"{_orph_b/1e9:.2f} GB reclaimed — now "
              f"{_STORE_BYTES[0]/1e9:.2f} GB of {STORE_CAP_GB} GB cap",
              flush=True)
    # THEN TRIM EACH POOL TO ITS CAP, with nothing protected. A store left
    # over cap by a previous namespace stays over until a write lands; the
    # eviction domain is the directory, so it can be cut down now. Must follow
    # the scan above: eviction moves _STORE_BYTES, which the scan initialises.
    _bv = index.trim_pools(((BLOB_DIR, STORE_CAP_GB),
                            (PHOTO_BLOB_DIR, PHOTO_CAP_GB)))
    if _bv:
        print(f"store: {len(_bv)} blob(s) evicted at boot — "
              f"{_STORE_BYTES[0]/1e9:.2f} GB now", flush=True)
except OSError as _e:
    print(f"!! store-cap boot scan failed: {_e}", flush=True)

forkidx = None
NVME_BPS = float(os.environ.get("FAXL_NVME_BPS", "0")) or None
PREFILL_TPS = {"ewma": float(os.environ.get("FAXL_PREFILL_TPS", "250"))}
OBSERVED = {"max_blob": 0}
# ---- TRIM-ON-LOAD (KV plan Phase B; pure-KV models only) -------------------
# Under TRIMMABLE the stream index runs for D* discovery even with fork off
# (B.3: the trim path needs D*), fork BLOB WRITES are suppressed (the anchor
# dominates every fork write), and the chain's live tail anchor supersedes
# its ancestor every turn (B.4) — chain identity via trim_lookup.AnchorRegistry
# (inherited on every extension turn, i.e. head migration is UNCONDITIONAL).
ANCHORS = None
LOAD_FIT = {"intercept_ms": 8.4, "slope_ms_per_gb": 38.7}
try:
    LOAD_FIT = json.load(open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data", "write-cost.json")))["fits"]["load"]
except Exception as _e:
    print(f"!! load-fit table unreadable ({_e}) — using committed defaults",
          flush=True)
if TRIMMABLE:
    from faxl.engine.trim_lookup import AnchorRegistry, economic_gate as trim_economic_gate, resolve_candidate
    ANCHORS = AnchorRegistry(os.path.join(DB_DIR, "anchor_state.json"))
if FORK or TRIMMABLE:
    from faxl.engine.fork_index import ForkIndex as _FI
    if forkidx is None:
        forkidx = _FI(STREAMS_DIR, os.path.join(DB_DIR, "fork_state.json"))
if FORK:
    from faxl.engine.fork_index import (extension_gate, divergence_gate,
                            blob_bytes_predicted, model_slope)
    # BOOT VALIDATION (plan v1.5): an unmeasured model must fail HERE, not
    # mid-request — blob_bytes_predicted/model_slope now raise for unknowns.
    from faxl.engine.fork_index import model_slope as _ms_check
    _ms_check(MODEL)   # raises UnknownModelCurve with instructions if unmeasured
    if NVME_BPS is None:
        # measure the store's write bandwidth once (32 MB, fsync'd) — the
        # extension gate's write-cost side uses a MEASURED number, not a guess.
        _probe_path = os.path.join(BLOB_DIR, ".nvme_probe")
        _t0 = time.time()
        with open(_probe_path, "wb") as _f:
            _f.write(b"\0" * (32 << 20))
            _f.flush(); os.fsync(_f.fileno())
        NVME_BPS = (32 << 20) / max(time.time() - _t0, 1e-6)
        os.remove(_probe_path)
        print(f"fork: measured store write bandwidth {NVME_BPS/1e9:.2f} GB/s", flush=True)
    print(f"fork-point checkpointing ON (gates {'OFF — demo' if FORK_GATES_OFF else 'rev-5'}; "
          f"ratio={FORK_TIME_RATIO} amort={FORK_AMORT} cap={FORK_MAX_LIVE_GB}GB)", flush=True)
# ---- M0 audit trail construction (after SEEDS/index so identity is real) ---
AUDIT = None
STRAT_CFG = {k: v for k, v in _STRAT_KW.items() if k != "count_of"}
# Namespace identity: constructed above, BEFORE the index (it keys the store).
if AUDIT_DIR:
    from faxl.engine.audit_trail import AuditTrail
    try:
        from faxl.engine.fork_index import _curve as _m0_curve
        _m0_flat, _m0_slope = _m0_curve(MODEL)
        _curve_meta = {"flat": _m0_flat, "slope": _m0_slope}
    except Exception:
        _curve_meta = None   # unmeasured model: FORK boot check governs
    AUDIT = AuditTrail(AUDIT_DIR, SESSION_LABEL, NS, collect=COLLECT, meta={
        "emitter": "proxy", "dstar_semantics": "fork_only",
        "strategy": {"name": STRATEGY, "config": STRAT_CFG},
        "fork_enabled": FORK, "gates_off": FORK_GATES_OFF,
        "fork_cap_gb": FORK_MAX_LIVE_GB, "evict_cap_bytes": None,
        "workload": WORKLOAD, "model_curve": _curve_meta,
        "gate_constants": {"time_ratio": FORK_TIME_RATIO, "amort": FORK_AMORT},
        "nocache": NOCACHE, "store_fresh": len(index.exact) == 0,
        "trimmable": TRIMMABLE, "load_fit": LOAD_FIT,
        "collect": COLLECT})
    print(f"M0 audit trail ON -> {AUDIT.path} (collect={COLLECT}, "
          f"session={SESSION_LABEL}, ns={NS.digest_hex()[:16]})", flush=True)

# ---- TELEMETRY (the collection contract; docs/proxy-console-telemetry-plan.md) --
# One transaction -> one designed protobuf event stream (START sync/fail-closed,
# COMPLETION async). The console reads this, NOT the incidental metrics JSONL.
# FAXL_TELEMETRY=0 opts out (byte-identical legacy behaviour otherwise).
from faxl.engine import faxl_telemetry as _tel
_BACKEND_ENUM = {"mlx": _tel.pb.MLX, "hf": _tel.pb.HF,
                 "vllm": _tel.pb.VLLM, "exo": _tel.pb.EXO}.get(
                     _BACKEND_NAME, _tel.pb.MLX)
TELEMETRY = None
if os.environ.get("FAXL_TELEMETRY", "1") == "1":
    _tpath = faxl_config.telemetry_wal_path()
    if _tel.is_volatile_path(_tpath):
        # The collection log is the product's evidence base, not scratch.
        print(f"!! FAXL_TELEMETRY_WAL {_tpath} is a VOLATILE path — history "
              f"will evaporate on reboot; set a durable path", flush=True)
    TELEMETRY = _tel.Telemetry(
        _tel.FileWal(_tpath), _tel.TenantKeyer(),
        backend=_BACKEND_ENUM, model=MODEL,
        boot_id=os.environ.get("FAXL_BOOT_ID", uuid.uuid4().hex[:12]),
        determinism_config_id=os.environ.get("FAXL_DETERMINISM_CONFIG", ""))
    print(f"telemetry ON -> {_tpath} (backend="
          f"{_tel.pb.Backend.Name(_BACKEND_ENUM)}, model={MODEL})", flush=True)
    # Console: the aggregator reads the SAME WAL (refresh-on-read), and the
    # blueprint serves /console + /api/* from it. index_stats is injected so the
    # console never imports serving internals.
    from faxl.engine import faxl_aggregator as _agg
    from faxl.engine import faxl_console as _console
    _AGGREGATOR = _agg.Aggregator()

    def _index_stats():
        """What the console reports as the cache.

        WHICH STORE depends on the backend, and getting it wrong is not
        cosmetic. On the exo path the checkpoints live in ExoStore; the
        mlx-line `index.exact` is empty by construction, so reading it showed
        "CACHE ENTRIES 0" on a page that simultaneously reported an 84% hit
        rate, with 50 checkpoints and 39 GB on disk. A console that
        contradicts itself is worse than one that says nothing.
        """
        try:
            store = getattr(PREFILL_SERVER, "faxl_store", None)
            if store is not None:
                out = {"available": True, "entries": len(store),
                       "used_gb": round(store.live_bytes() / 1e9, 2),
                       "limit_gb": round(float(store.cap_gb), 2)}
                # STORE-WIDE, in a nested try of its own. The namespace hash
                # folds in the model id, so blobs written by another model
                # match 0 of this store's entries and vanish from the numbers
                # above — 56 GB on disk reported as "0 / 60 GB". These keys
                # let the console say "this model" and "all models"
                # separately. A failure here must cost only the extra keys:
                # the tile still has to show the per-model figures rather than
                # collapsing to available:false.
                try:
                    rows = store.store_rows()
                    out["store_entries"] = sum(r["entries"] for r in rows)
                    out["store_used_gb"] = round(
                        sum(r["bytes"] for r in rows) / 1e9, 2)
                    out["namespaces"] = [
                        {"ns_hash": r["ns_hash"], "model": r["model"],
                         "entries": r["entries"],
                         "used_gb": round(r["bytes"] / 1e9, 2)}
                        for r in rows]
                except Exception:  # noqa: BLE001
                    pass
                return out
            return {"available": True, "entries": len(index.exact),
                    "rows": index.rows, "live_fork_gb": round(index.live_fork_gb(), 3)}
        except Exception:  # noqa: BLE001
            return {"available": False}

    def _blob_stats():
        """One row per cached blob for the console's recency/frequency
        scatter: hits + last_used from the durable blob++ usage log; a
        never-hit blob reports its file mtime (same convention as the
        eviction score, so the plot shows exactly what eviction sees).

        WHICH STORE, exactly as _index_stats decides it. On the exo path the
        blobs live in ExoStore and `index.exact` is EMPTY BY CONSTRUCTION, so
        reading it returned {"blobs":[],"count":0} under a heading promising
        one dot per stored blob. The identical bug _index_stats was fixed for;
        the row shape is the same either way, so shape_blobs is unchanged.
        """
        out = []
        try:
            store = getattr(PREFILL_SERVER, "faxl_store", None)
            if store is not None:
                return store.blob_rows()
            for ph, (blob, cpos, _tok) in list(index.exact.items()):
                hits, last = index.usage.get(str(ph), (0, 0.0))
                try:
                    st = os.stat(blob)
                except OSError:
                    continue   # blob gone mid-iteration (eviction race)
                nbytes = st.st_size
                if not last:
                    last = st.st_mtime
                out.append({"phash": str(ph), "hits": hits, "last_used": last,
                            "bytes": nbytes, "pos": cpos})
        except Exception:  # noqa: BLE001 — console must never 500 the proxy
            pass
        return out

    _host_for_bind = os.environ.get("FAXL_HOST", "127.0.0.1")
    app.register_blueprint(_console.create_console(
        aggregator=_AGGREGATOR, wal_path=_tpath, backend_name=_tel.pb.Backend.Name(
            _BACKEND_ENUM).lower(), model=MODEL,
        bind=f"{_host_for_bind}:{os.environ.get('FAXL_PORT', '8767')}",
        index_stats=_index_stats, licence_status=lambda: licence.status(),
        blob_stats=_blob_stats,
        backend_stats=lambda: (BACKEND.console_stats()
                               if hasattr(BACKEND, "console_stats") else None),
        # T-0004: let the console install a pasted key. The wheel's set_licence
        # is passed in rather than imported by the console, which imports
        # nothing from this module; LICENCE_FILE goes with it so a FAXL_LICENCE
        # override this process saw is the one the console writes through to.
        licence_apply=(faxl.set_licence if faxl is not None else None),
        licence_file=LICENCE_FILE,
        # The exo path's hits and stores are counted by the PrefillServer
        # thread, not the WAL. Handed over so the cluster card reads the
        # proxy's own numbers instead of reaching into this module for them.
        prefill_counts=lambda: dict(EXO_COUNTS),
        # parse_licence validates WITHOUT installing, so a lapsed key is
        # refused before it can displace a working entitlement. getattr because
        # older wheels do not have it; apply_key falls back to repairing after
        # the fact when it is None.
        licence_parse=(getattr(faxl, "parse_licence", None)
                       if faxl is not None else None),
        verify_condition=lambda: (
            "vllm: greedy temperature 0 under the resolved deterministic protocol; "
            "cold/cached byte identity requires verification on this runtime"
            if _BACKEND_NAME == "vllm" else
            "mlx: byte-identical, greedy (unconditional on this backend)"),
        # The client-config export builds from the same rows /v1/models
        # serves. A lambda: _model_rows is defined further down the module.
        model_rows=lambda: _model_rows(),
        # The newest model clash, for the console banner (see _clash_with).
        model_clash=lambda: dict(_LAST_CLASH)))
    print(f"console ON -> /console + /api/* (reads {_tpath})", flush=True)
else:
    # Loud, not silent: with telemetry off there is no collection, so /console
    # and /api/* are not registered and will 404 — say so at boot.
    print("console OFF — telemetry disabled (FAXL_TELEMETRY=0); /console and "
          "/api/* are not served", flush=True)

# Normalised client label — NEVER the raw UA/X-Client (linkable PII). A small
# allowlist maps known clients to a coarse category; everything else is "other".
# The allowlist and the fallback for SDK-default UAs live in client_compat.
_CLIENT_LABELS = client_compat.CLIENT_LABELS

_PROJECT_RE = __import__("re").compile(r"[^a-z0-9._-]+")


def _project_tag(raw):
    """Normalise a caller-supplied project/team tag, or "" for none.

    A caller controls this string and it lands in DURABLE analytics, so it is
    bounded and normalised at the edge exactly as client_label is: unbounded
    caller text in a telemetry column turns the analytics store into a log of
    whatever anyone felt like sending, and a tag is for grouping, not for
    carrying payload.

    Lowercased, anything outside [a-z0-9._-] collapsed to '-', 48 chars.
    """
    if not raw:
        return ""
    tag = _PROJECT_RE.sub("-", str(raw).strip().lower()).strip("-.")
    return tag[:48]


def _client_label(ua, messages=None, faxl_client=None):
    return client_compat.client_label(ua, messages, faxl_client)

# ---- fork-point singletons (plan rev 5) ----
for _d in _POOL_DIRS:
    os.makedirs(_d, exist_ok=True)
# 0700: the token records inside decode back to verbatim prompts (see the
# write site) — the directory must not be traversable by other local users.
os.makedirs(TOKENS_DIR, mode=0o700, exist_ok=True)
try:
    os.chmod(TOKENS_DIR, 0o700)   # tighten a dir left 0755 by an older build
except OSError as e:
    print(f"!! could not tighten {TOKENS_DIR} to 0700 ({e}) — token records "
          f"may be readable by other local users", flush=True)


def _tighten_existing_tokens():
    """Re-mode token records written 0644 by an older build. A store built
    before this fix is full of world-readable verbatim prompts; tightening new
    writes alone would leave that history exposed. Cheap (a stat per file) and
    idempotent."""
    fixed = failed = 0
    try:
        with os.scandir(TOKENS_DIR) as it:
            for e in it:
                if not e.is_file():
                    continue
                try:
                    if e.stat().st_mode & 0o077:
                        os.chmod(e.path, 0o600)
                        fixed += 1
                except OSError:
                    failed += 1
    except OSError:
        return
    if fixed or failed:
        print(f"token records re-moded to 0600: {fixed} tightened"
              + (f", {failed} FAILED" if failed else ""), flush=True)


_tighten_existing_tokens()


print(f"faxl proxy ready (exact-tier lookup; ckpt base {CKPT_EVERY}, "
      f"keys >= {KEY_MIN_TOKENS} tok; exact entries: {len(index.exact)}).")


# Kimi tool-call grammar (special tokens; ids 163595-163599 in the Kimi tokenizer;
# decode round-trip verified). Call id looks like "functions.read_file:0" — the
# function name sits between "functions." and the trailing ":<idx>".
_KIMI_CALL = re.compile(
    r"<\|tool_call_begin\|>\s*(?P<id>[^<]+?)\s*<\|tool_call_argument_begin\|>"
    r"\s*(?P<args>\{.*?\})\s*<\|tool_call_end\|>", re.DOTALL)
_KIMI_SECTION = re.compile(
    r"<\|tool_calls_section_begin\|>.*?(?:<\|tool_calls_section_end\|>|\Z)", re.DOTALL)
_GRANITE_CALL = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
# Ling / bailing_hybrid family: one call per `<tool_call>` block, NOT json —
#   <tool_call>NAME\n<arg_key>k</arg_key>\n<arg_value>v</arg_value>...</tool_call>
# (values are bare strings; there may be several key/value pairs, and several
# <tool_call> blocks in one turn). Distinguished from Granite's `<tool_call>{json}`
# by the leading NAME token before any '{' — checked in parse_tool_calls order.
_LING_CALL = re.compile(r"<tool_call>\s*([^\s<{][^\n<]*?)\s*\n(.*?)</tool_call>", re.DOTALL)
_LING_ARG = re.compile(r"<arg_key>\s*(.*?)\s*</arg_key>\s*<arg_value>\s*(.*?)\s*</arg_value>", re.DOTALL)
# Nemotron family: a JSON ARRAY of {name, arguments} inside <TOOLCALL> tags
# (rendered exemplar verified from the chat template's own instructions).
_NEMOTRON_CALL = re.compile(r"<TOOLCALL>\s*(\[.*?\])\s*</TOOLCALL>", re.DOTALL)
# Qwen3.6 family: a <function=NAME> block nested inside <tool_call>, with one
# <parameter=KEY> block per argument and the VALUE on its own lines:
#
#   <tool_call>
#   <function=glob>
#   <parameter=path>
#   /Users/andrewmorgan
#   </parameter>
#   <parameter=pattern>
#   **/AGENTS.md
#   </parameter>
#   </function>
#   </tool_call>
#
# Read from the model's OWN chat template, not from a sample: the template
# instructs the model in exactly this shape ("an inner <function=...></function>
# block must be nested within <tool_call></tool_call> XML tags") and renders a
# past tool call back the same way, so history round-trips.
#
# WHY THIS MATTERS MORE THAN A FIFTH REGEX LOOKS. An unparsed tool call is not
# a cosmetic fault: the client sees no tool_calls field, the call never
# executes, no tool result comes back, and the model re-emits the same calls
# forever -- measured as 8 calls in one message, several duplicated, in an
# agentic coding loop. The reply looks like prose and burns the whole turn.
#
# Values are bare multi-line strings, so the parameter body is captured
# non-greedily up to its own closing tag and only stripped of surrounding
# newlines -- a path or a code block must survive verbatim.
_QWEN36_CALL = re.compile(
    r"<tool_call>\s*<function=\s*(?P<name>[^>\s]+)\s*>(?P<body>.*?)</function>\s*</tool_call>",
    re.DOTALL)
_QWEN36_ARG = re.compile(
    r"<parameter=\s*(?P<key>[^>\s]+)\s*>\n?(?P<val>.*?)\n?</parameter>", re.DOTALL)
# The first token of every family's markup. STREAMING NEEDS THIS because the
# parser can only run on the finished text: tokens are emitted as they decode,
# so without a stop line the raw <tool_call> markup is streamed to the client
# as prose and then the parsed, cleaned content is sent after it -- the client
# accumulates both and the markup ends up in its conversation history, where
# the model reads its own tool-call syntax back on the next turn.
#
# Longest-prefix safe: the drain loop also holds back a trailing fragment that
# COULD still become one of these, so "<tool" at a chunk boundary is not
# emitted and then regretted.
_TOOL_OPENERS = ("<tool_call>", "<TOOLCALL>", "<|tool_calls_section_begin|>",
                 "<|tool_call_begin|>")


def _tool_markup_cut(text):
    """Index where tool-call markup begins, or None.

    Also returns an index when the text merely ENDS in a prefix of an opener:
    a chunk boundary can split "<tool_call>" across two decodes, and emitting
    "<tool" because the rest has not arrived yet is the same leak one token
    later.
    """
    first = None
    for opener in _TOOL_OPENERS:
        i = text.find(opener)
        if i != -1 and (first is None or i < first):
            first = i
    if first is not None:
        return first
    # A trailing partial opener: hold it back until the next token settles it.
    for opener in _TOOL_OPENERS:
        for n in range(len(opener) - 1, 0, -1):
            if text.endswith(opener[:n]):
                return len(text) - n
    return None


def parse_tool_calls(text):
    """(tool_calls, content) from any known family's markup; empty if none."""
    # QWEN3.6 FIRST. Its wrapper is <tool_call>, the same opener Ling and
    # Granite use, but its body is <function=...> rather than a bare name or
    # JSON. Ling's regex would match the opener and then find no <arg_key>
    # pairs and skip, and Granite's would find no '{' -- so the call would fall
    # through all three and be returned as prose. Checking the most specific
    # shape first is what keeps the families from shadowing each other.
    calls = []
    for m in _QWEN36_CALL.finditer(text):
        name = m.group("name").strip()
        if not name:
            continue
        args = {k.strip(): v for k, v in _QWEN36_ARG.findall(m.group("body"))}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        return calls, _QWEN36_CALL.sub("", text).strip()
    m = _NEMOTRON_CALL.search(text)
    if m:
        calls = []
        try:
            arr = json.loads(m.group(1))
        except json.JSONDecodeError:
            arr = []
        for tc in arr if isinstance(arr, list) else []:
            args = tc.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"_raw": args}
            calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                          "function": {"name": tc.get("name", ""),
                                       "arguments": json.dumps(args)}})
        if calls:
            content = _NEMOTRON_CALL.sub("", text).strip()
            return calls, content
    calls = []
    for m in _KIMI_CALL.finditer(text):
        raw_id = m.group("id").strip()
        name = raw_id.split("functions.")[-1].rsplit(":", 1)[0] if "functions." in raw_id \
            else raw_id.rsplit(":", 1)[0]
        try:
            args = json.loads(m.group("args"))
        except json.JSONDecodeError:
            continue
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _KIMI_SECTION.sub("", text).strip()
        return calls, content
    # Ling: <tool_call>NAME <arg_key>k</arg_key><arg_value>v</arg_value>...</tool_call>.
    # Must run BEFORE Granite (both use <tool_call>) — Ling's first token is a bare
    # NAME, Granite's is '{', so a block whose body has arg_key pairs is Ling's.
    for m in _LING_CALL.finditer(text):
        name, body = m.group(1).strip(), m.group(2)
        pairs = _LING_ARG.findall(body)
        if not pairs:
            continue  # not the Ling shape (e.g. a Granite json block) — leave to Granite
        args = {k.strip(): v for k, v in pairs}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _LING_CALL.sub("", text).strip()
        return calls, content
    for m in _GRANITE_CALL.finditer(text):
        try:
            tc = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        # ARGUMENTS MAY ARRIVE ALREADY ENCODED. Granite emits `"arguments"` as an
        # object most of the time, but sometimes as a JSON STRING; dumping that
        # again produced a JSON string wrapping a JSON string, so a correct
        # client's json.loads() returned a str instead of a dict. It then stored
        # the malformed call and replayed it as history, which surfaced in mcode
        # as "Conversation history could not be safely updated" -- a turn-state
        # error with no hint that the cause was our encoding. Decode-then-dump,
        # exactly as the Nemotron branch above does. (Reported with a sniff
        # capture, 2026-10-01.)
        args = tc.get("arguments", {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {"_raw": args}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": tc.get("name", ""),
                                   "arguments": json.dumps(args)}})
    content = re.sub(r"<tool_call>.*?</tool_call>", "", text, flags=re.DOTALL).strip()
    return calls, content


# ---- EXECUTION BACKEND ----------------------------------------------------
# Everything above this line — chat template, ladder lookup, byte-confirm,
# checkpoint placement, store, telemetry, console, licence — is where the
# product lives and is backend-independent. BACKEND is only the part that runs
# the model: mlx_lm in this process (one Mac, the shipped path) or an exo
# cluster (many Macs over Thunderbolt, which is how a model too large for one
# machine becomes runnable at all). Selected by _BACKEND_NAME (config.json's
# "backend", FAXL_BACKEND overriding), resolved once at the top.
#
# The ABSOLUTE GRID is not a backend detail: every backend must chunk prefill
# on multiples of SEG, or hybrid recurrent state diverges from the cold path
# and a warm serve returns a plausible wrong answer (see backends.py).
from faxl.engine.backends import make_backend
# PER-LINE IMPORT. backends.py is NOT synced (each product line ships its own),
# so a line whose backend cannot poll mid-prefill simply has no such exception.
# Falling back to a private class means `except _PrefillCancelled` is always
# valid and never catches anything there -- the cancel still lands at the chunk
# boundary, as it did before.
try:
    from faxl.engine.backends import PrefillCancelled as _PrefillCancelled
except ImportError:                                  # pragma: no cover
    class _PrefillCancelled(Exception):
        prefilled = 0
if _BACKEND_NAME in _MLX_BACKENDS:
    BACKEND = make_backend(
        _BACKEND_NAME,
        **({"model": model, "tokenizer": tok, "sampler": sampler,
            "stop_ids": STOP_IDS, "seg": SEG, "trimmable": TRIMMABLE,
            "processor": PROCESSOR}
           if _BACKEND_NAME == "mlx"
           else {"model_id": MODEL, "seg": SEG, "endpoint": EXO["endpoint"]}))
print(f"execution backend: {BACKEND.name}", flush=True)

# ---- THE PREFILL SERVER. On the exo path this thread is where the ladder
# actually runs: exo's runner dials FAXL_PREFILL_ENDPOINT when it needs a
# prefix (R1) and pushes state back after a cold one (R2). It needs no model
# -- load_prompt_cache rebuilds an mlx cache from the safetensors metadata
# alone -- so it never contends with inference.
# ONE OWNER. faxl binds the socket, so faxl decides the port and PUBLISHES it;
# exo reads that file rather than a second environment variable of its own.
#
# Both sides used to read their own env var (FAXL_PREFILL_PORT here,
# FAXL_PREFILL_ENDPOINT there) with nothing connecting them, so they could
# disagree and neither could tell: measured, exo dialled 52441 while faxl
# listened on 52440, and every request died with ConnectionRefusedError after
# taking the runner down with it. A value two processes must agree on cannot
# be configured twice.
PREFILL_STATE = faxl_config.prefill_state_path()
PREFILL_SERVER = None
if BACKEND.name == "exo":
    _pf_port = EXO["prefill_port"]
    _pf_host = os.environ.get("FAXL_PREFILL_HOST", "127.0.0.1")
    try:
        from faxl.engine.exo_prefill_server import start_prefill_server
        PREFILL_SERVER = start_prefill_server(
            _pf_port, MODEL, host=_pf_host, counts=EXO_COUNTS)
        # Publish what was ACTUALLY bound, keyed by model: one proxy serves one
        # model, and a cluster running two has one entry per model. Written
        # after the bind succeeds, so the file never advertises a dead port.
        try:
            os.makedirs(os.path.dirname(PREFILL_STATE), exist_ok=True)
            _state = {}
            if os.path.exists(PREFILL_STATE):
                with open(PREFILL_STATE) as _fh:
                    _state = json.load(_fh) or {}
            _state[str(MODEL)] = {"endpoint": f"{_pf_host}:{_pf_port}",
                                  "pid": os.getpid(),
                                  "written_at": time.time()}
            _tmp = PREFILL_STATE + f".tmp{os.getpid()}"
            with open(_tmp, "w") as _fh:
                json.dump(_state, _fh, indent=2)
                _fh.flush()
                os.fsync(_fh.fileno())
            os.replace(_tmp, PREFILL_STATE)      # atomic publish
            print(f"published prefill endpoint -> {PREFILL_STATE}", flush=True)
        except OSError as _e:
            # Not fatal: exo can still be pointed by env var. But say so,
            # because the whole point of the file is that it cannot drift.
            print(f"!! could not publish the prefill endpoint ({_e}) — exo "
                  f"will need FAXL_PREFILL_ENDPOINT set by hand", flush=True)
    except Exception as e:   # noqa: BLE001
        # Loud and fatal: FAXL_BACKEND=exo without this thread is a proxy that
        # forwards to a cluster with no cache behind it — a silent no-op of
        # the entire product.
        raise SystemExit(
            f"FATAL: the prefill server did not start ({type(e).__name__}: {e}). "
            f"With FAXL_BACKEND=exo this is the cache; refusing to serve "
            f"without it.")


def _images_from_body(body):
    """Every image in the request, as bytes, in the order they appear.

    _flatten_multimodal deliberately does NOT carry these: it builds the text
    the ladder hashes, where a picture is one <image:digest> atom, because a
    megabyte of base64 in the prefix would be re-hashed on every request for
    nothing. The pixels are still in the body, and the vision path needs them.

    Called only after _image_request_refusal admitted the request, so every
    image part is a data: URL whose payload decodes. This used to skip any
    other URL and swallow a base64 error, which shrank the list silently and
    let the model answer from the placeholder (Halo-5w4.33); reaching either
    case here now is a server bug, and it raises.
    """
    out = []
    for m in (body.get("messages") or []):
        c = m.get("content")
        if not isinstance(c, list):
            continue
        for part in c:
            if not isinstance(part, dict):
                continue
            if part.get("type") not in ("image_url", "input_image", "image"):
                continue
            url = _image_part_url(part)
            if not isinstance(url, str) or not url.startswith("data:"):
                raise RuntimeError(
                    "_images_from_body: an image part that is not a data: URL "
                    "reached the pixel path; _image_request_refusal admits "
                    "only data: URLs")
            out.append(base64.b64decode(url.split(",", 1)[1], validate=False))
    return out


def prefill(ids, cache, start=0, images=None, cancel=None):
    """Fold tokens into `cache` on the absolute grid (see backends.py).

    cancel() is polled per SEGMENT inside the backend, which is finer than the
    caller's checkpoint chunks -- those grow geometrically, so the last chunk
    of a long prompt can be most of the prompt.
    """
    if images and getattr(BACKEND, "accepts_images", False):
        return BACKEND.prefill_with_images(ids, cache, images, start)
    return BACKEND.prefill(ids, cache, start, cancel=cancel)


def generate(seed, cache, max_tokens, on_token=None, cancel=None):
    """Returns (out_ids, t_first): t_first is the wall-clock time the FIRST
    token was decoded (None if none) — TTFT is measured directly against the
    request start, never reconstructed (plan v1.5 phase 0)."""
    return BACKEND.generate(seed, cache, max_tokens,
                            on_token=on_token, cancel=cancel)


class MlxCacheOps(CacheOps):
    """mlx/exo: delegate to mlx_lm exactly as the request path always did.

    Every method here is the call that used to sit inline in chat(), moved
    behind the seam and nothing else. That is deliberate: the Mac suite is the
    only gate that can prove the seam changed no behaviour, so the mlx side
    must be a pure forward.
    """

    store_name = "mlx"
    cache_format = "mlx_safetensors_v1"
    supports_images = True

    def make(self, model):
        return _make_cache_for(model)

    # SAVE AND LOAD GO THROUGH faxl's SERIALISER FOR NON-mlx_lm CACHES.
    # mlx_lm's load_prompt_cache rebuilds each layer with
    # globals()[class_name].from_state(state) -- the name resolved in mlx_lm's
    # OWN namespace, and the one-argument from_state. A vision model's cache is
    # built from mlx_vlm classes (Qwen3.8-Flash-Next: 36 mlx_vlm ArraysCache +
    # 12 QSAKVCache, the latter from mlx_vlm.models.qwen4_exp.language), whose
    # names are absent there and whose from_state takes (state, meta_state).
    # mlx_vlm ships no saver of its own.
    #
    # The cost of getting this wrong was NOT a crash: the ladder found the
    # checkpoint, confirmed the tokens, failed to load the blob, and fell
    # through to cold. So faxl wrote a 188 MB checkpoint per request and read
    # none of them back -- zero tokens skipped, plus the write cost. Worse than
    # no cache. Measured on three byte-identical 2,719-token requests.
    #
    # vlm_cache_io writes the fully-qualified class path and each cache's
    # meta_state, and records None positions explicitly (QSAKVCache's state is
    # a six-tuple whose last two members are legitimately None). A file written
    # by mlx_lm stays readable: without faxl's marker, load() defers to
    # mlx_lm.load_prompt_cache, so an existing store is untouched.
    def _io(self):
        try:
            from faxl.engine.mlx_models import vlm_cache_io
            return vlm_cache_io
        except ImportError:
            return None

    def load(self, blob):
        io = self._io()
        if io is not None:
            return io.load(blob)
        return load_prompt_cache(blob)

    def save(self, blob, cache):
        io = self._io()
        if io is not None and io.needs_faxl_io(cache):
            return io.save(blob, cache)
        return save_prompt_cache(blob, cache)

    def can_trim(self, cache):
        return can_trim_prompt_cache(cache)

    def trim(self, cache, n):
        # F8: trim returns the FIRST layer's count only -- never a total.
        return trim_prompt_cache(cache, n)

    def prefill(self, ids, cache, start=0, images=None, cancel=None):
        # mx.array lives HERE, not in the generic path: the shared proxy hands
        # every backend a plain list.
        return prefill(mx.array(ids), cache, start, images=images,
                       cancel=cancel)

    def generate(self, ids, cache, max_tokens, on_token=None, cancel=None):
        # The mlx decode seeds from the last token only.
        return generate(mx.array(ids[-1:]), cache, max_tokens,
                        on_token=on_token, cancel=cancel)


# WHICH CACHE ENGINE THIS PROCESS USES. Chosen once, by backend, like the model
# and the backend itself. A line that has no implementation fails HERE, at
# boot, naming the backend -- not on the first request.
if _BACKEND_NAME in _MLX_BACKENDS:
    CACHE = MlxCacheOps()
else:
    # The Linux execution backend IS its deferred cache adapter. Reuse the
    # owner constructed above: another factory call allocates another LLM
    # and KV pool on the same device, and splits the plan's ownership.
    CACHE = BACKEND

DEFERRED_CACHE = bool(getattr(CACHE, "deferred_saves", False))

# The store name is resolved twice -- once early for BLOB_DIR, once by the
# cache engine itself -- so they are checked against each other rather than
# trusted. A mismatch means blobs would be written where nothing looks for
# them.
_declared_trim = _TRIMMABLE_BY_BACKEND[_BACKEND_NAME]
if _declared_trim is not None and CACHE.can_trim(None) != _declared_trim:
    raise RuntimeError(
        f"faxl_proxy: trimmability disagreement -- the boot table says "
        f"{_declared_trim} for {_BACKEND_NAME!r} but "
        f"{type(CACHE).__name__}.can_trim() says {CACHE.can_trim(None)}")
if CACHE.store_name != STORE_NAME:
    raise RuntimeError(
        f"faxl_proxy: store name disagreement -- BLOB_DIR uses "
        f"{STORE_NAME!r} but {type(CACHE).__name__} declares "
        f"{CACHE.store_name!r}")


SNIFF = os.environ.get("FAXL_SNIFF")   # path to dump full request/response traffic for inspection


def _sniff(kind, obj):
    """Append a pretty JSON record of one request or response to FAXL_SNIFF, for
    testing/inspection. Off unless FAXL_SNIFF is set. Records the FULL messages,
    tools, raw model text, and parsed tool calls — so you can see exactly what
    OpenClaw sent and what the model did with it."""
    if not SNIFF:
        return
    try:
        with open(SNIFF, "a") as f:
            f.write(json.dumps({"t": time.time(), "kind": kind, **obj}, default=str) + "\n")
            f.flush(); os.fsync(f.fileno())
    except Exception:
        pass


# FIX D6 (CODE-TRUTH): the server now runs threaded so /health, /metrics and
# /v1/models answer during a long generation; MODEL INFERENCE AND STORE WRITES
# stay strictly serialized under this lock (MLX and the Index are not
# thread-safe; per-request behavior is unchanged).
# Explicit raw evidence is separate from normal privacy-preserving telemetry.
from faxl.engine import product_evidence as _product_evidence
EVIDENCE = _product_evidence.from_environment({
    "backend": BACKEND.name, "model": MODEL, "revision": REVISION,
    "snapshot": getattr(BACKEND, "snapshot_path", None),
    "runtime": BACKEND.env_record() if hasattr(BACKEND, "env_record") else None,
    "namespace": NS.as_dict(), "namespace_digest": NS.digest_hex(), "namespace_hash": NS.ns_hash(),
    "blobs": os.path.abspath(BLOB_DIR), "db": os.path.abspath(DB_DIR),
    "tokens": os.path.abspath(TOKENS_DIR), "nocache": NOCACHE,
    "connector_events_path": (os.path.abspath(os.environ["FAXL_VLLM_EVENTS"])
                              if BACKEND.name == "vllm" else None),
    "licence": licence.status(), "entitled": licence.entitled(),
    "store_rows_at_boot": index.rows})
# Raw product evidence with main-thread inference stays refused at boot. Its
# first reason, that the per-request evidence binding lived in Flask's `g` and
# did not cross to the executor thread, no longer holds: the binding is now
# request.environ["faxl.evidence"] and the completion id is passed explicitly
# (Halo-5w4.39, Halo-5w4.41), and both cross wherever the copied request
# context goes. The refusal is kept as a choice until the combination has a
# test of its own.
if EVIDENCE is not None and _MAIN_THREAD_INFER:
    raise RuntimeError(
        "faxl_proxy: raw product evidence is not offered with main-thread "
        "inference on (faxl_config main_thread_infer / FAXL_MAIN_THREAD_INFER): "
        "the combination has not been tested. Turn one of them off.")


@app.before_request
def _evidence_start():
    if EVIDENCE is None or request.path != "/v1/chat/completions":
        return None
    g.evidence_request_id = uuid.uuid4().hex
    g.evidence_api_id = "chatcmpl-" + uuid.uuid4().hex
    # THE REQUEST'S EVIDENCE SLOT (Halo-5w4.39 item 4). In the request's own
    # environ, not in `g`: a stream's _chat_impl runs in another thread, where
    # `g` is a different object but the copied request context carries the
    # same request, so its observations and error reach the response row.
    request.environ["faxl.evidence"] = {"observations": None, "error": None}
    EVIDENCE.append("request", g.evidence_request_id, g.evidence_api_id,
                    request_bytes=_product_evidence.bytes_record(request.get_data(cache=True)),
                    method=request.method, path=request.path)


def _evidence_note(**fields):
    """Record observations and/or an error in THIS request's evidence slot (see
    _evidence_start), from whichever thread serves it. A no-op without the
    writer."""
    if EVIDENCE is None:
        return
    slot = request.environ.get("faxl.evidence")
    if slot is not None:
        slot.update(fields)


def _evidence_stream(inner, request_id, api_id, slot, status):
    """A streamed response's body, passed through unchanged, whose response row
    is written when the stream ENDS (Halo-5w4.39 item 4): the bytes as Werkzeug
    sends them (str chunks are utf-8), the slot's observations and error. It runs
    after Flask has popped the request context, so everything it needs is bound
    here by after_request. A client that hangs up still gets its row: the inner
    generator is closed at once (so _stream's hang-up handling, the cancel, runs
    now rather than at garbage collection), the bytes sent so far are recorded
    and, if nothing else was noted, the hang-up is the row's error. A writer that
    fails here raises inside WSGI iteration after [DONE] went out: the chunked
    body then lacks its terminating chunk and the client sees a connection error;
    the writer's health probe reports the failure. A body that raises anything
    else (none is known to: _stream turns faults into error frames) gets its
    traceback as the row's error, unless a fault was noted first."""
    sent = bytearray()
    it = iter(inner)
    try:
        for chunk in it:
            sent.extend(chunk.encode("utf-8") if isinstance(chunk, str) else chunk)
            yield chunk
    except GeneratorExit:
        close = getattr(it, "close", None)
        if close is not None:
            close()
        if slot.get("error") is None:
            slot["error"] = f"the client closed the stream after {len(sent)} bytes"
        raise
    except Exception:
        if slot.get("error") is None:
            import traceback
            slot["error"] = traceback.format_exc()
        raise
    finally:
        EVIDENCE.append("response", request_id, api_id, http_status=status,
                        response_bytes=_product_evidence.bytes_record(bytes(sent)),
                        observations=slot.get("observations"), error=slot.get("error"),
                        licence=licence.status(), entitled=licence.entitled(), nocache=NOCACHE)


@app.after_request
def _evidence_response(response):
    if EVIDENCE is None or not hasattr(g, "evidence_request_id"):
        return response
    response.headers["X-Faxl-Request-ID"] = g.evidence_request_id
    response.headers["X-Faxl-Boot-ID"] = EVIDENCE.boot_id
    response.headers["X-Faxl-Response-ID"] = g.evidence_api_id
    slot = request.environ.get("faxl.evidence") or {"observations": None, "error": None}
    if response.is_streamed:
        response.response = _evidence_stream(response.response, g.evidence_request_id,
                                             g.evidence_api_id, slot, response.status_code)
        return response
    EVIDENCE.append("response", g.evidence_request_id, g.evidence_api_id,
                    http_status=response.status_code,
                    response_bytes=_product_evidence.bytes_record(response.get_data()),
                    observations=slot.get("observations"), error=slot.get("error"),
                    licence=licence.status(), entitled=licence.entitled(), nocache=NOCACHE)
    return response


_SERVE_LOCK = threading.Lock()

# ---- ON-DEMAND MODEL SWITCHING (AM 2026-10-04) ------------------------------
#
# The `model` field in an OpenAI request is a REQUIREMENT, not a label. If a
# request names a model this proxy holds on disk but is not currently serving,
# faxl switches to it and that model stays resident for whatever comes next.
# No scheduling and no attempt to avoid flip-flops: a switch measured 6s, which
# is cheaper than any machinery built to dodge it.
#
# WHY THE TRIGGERING REQUEST GETS A 503 RATHER THAN BEING SERVED. There is no
# in-process model swap. The model is loaded once at boot into a module global,
# and the tokenizer, STOP_IDS, TRIMMABLE, the cache ops and the main-thread
# executor are all derived from it at IMPORT time. Rebinding them mid-process
# is not a small change, and the executor is the dangerous part -- it exists
# because gated_delta_ops ABORTS THE PROCESS off the main thread, so a
# half-applied switch is a crash rather than an exception.
#
# So a switch is a process restart, and a restart cannot serve the request that
# triggered it: the socket dies with the process and the client cannot tell
# that from a network failure. 503 + Retry-After is the honest answer -- the
# client retries in six seconds and lands on the model it asked for. Every
# OpenAI-compatible client already handles 503 with Retry-After; none of them
# handle a dead socket.
#
# THE SWITCH TAKES _SERVE_LOCK FIRST, which is what keeps it off a live
# generation: holding the lock means by definition that nothing is decoding.
# There is no queue in faxl today (the lock is mutual exclusion, not ordering),
# so this is the only hook that can promise "between requests, never during
# one". The queue that would do this properly is specified in
# docs/plans/serve-queue.md.
# ON BY DEFAULT on the in-process backends, where a switch is a restart this
# proxy can actually perform. Off on exo, where the model lives on a cluster
# and switching it is the cluster's business, not a local relaunch.
# FAXL_SWITCH_ON_DEMAND=0 disables it for an operator who wants a fixed model.
_SWITCH_ON_DEMAND = (
    os.environ.get("FAXL_SWITCH_ON_DEMAND", "1") == "1"
    and _BACKEND_NAME in _MLX_BACKENDS)
_SWITCHING = {"to": None, "at": 0.0}

# ---- MODEL CLASH (2026-10-13) ------------------------------------------------
#
# Two conversations wanting different models at the same time cannot both be
# served by a proxy that holds one model and switches by restarting. Measured
# with stock MiniMax Code: an advisor agent pinned to Qwen3.8 ran while its
# main session kept polling on Qwen3.6. Each request switched faxl to its own
# model and the next one switched it back -- two full model loads per round --
# and the advisor's requests died mid-restart as "Connection error", with
# nothing anywhere saying faxl was the cause.
#
# So a request for another model is refused, with a message that says what to
# change, when a DIFFERENT client or agent used the loaded model within the
# last _CLASH_WINDOW_S. "Different" is (client label, agent name): the same
# client changing its own model -- a person picking another one -- still
# switches exactly as before. The newest clash is kept for the console banner.
_CLASH_WINDOW_S = 120.0
_LAST_USE = {"t": 0.0, "who": None}   # newest request served on MODEL
_LAST_CLASH = {}


def _clash_with(want, who, now=None):
    """The clash record if switching to `want` for `who` would cut off
    another conversation using the loaded model, else None."""
    now = time.time() if now is None else now
    prev, at = _LAST_USE.get("who"), _LAST_USE.get("t", 0.0)
    if prev is None or prev == who or now - at > _CLASH_WINDOW_S:
        return None
    # SAME CLIENT, AGENT UNKNOWN ON EITHER SIDE: not a clash. MiniMax Code's
    # own side calls (the title generator) name no agent, so without this a
    # person switching their session's model just after one would be refused.
    # Within one client it is a clash only when both name different agents.
    if prev[0] == who[0] and (prev[1] is None or who[1] is None):
        return None
    client, agent = who
    wanted = str(want).rstrip("/").split("/")[-1]
    loaded = str(MODEL).rstrip("/").split("/")[-1]
    return {"at": now, "client": client, "agent": agent,
            "requested": wanted, "loaded": loaded,
            "message": client_compat.clash_message(client, agent, wanted,
                                                   loaded)}
# HOW MANY REQUESTS ARE WAITING ON THE SERVE LOCK, and since when.
#
# The lock gives no depth -- that is the gap serve-queue.md is about -- so
# until the queue exists this counter is the only way to see a backlog. It is
# not scheduling; it is a number the console and /health can report so that
# "faxl looks hung" can be answered with "six requests are behind an 85,000
# token job that has been running four minutes".
#
# Measured on 2026-10-04: 64 threads blocked on locks while four 85k-token
# requests ran 190-292s each, and from outside the proxy there was no way to
# tell that from a deadlock.
_WAITING = {"n": 0, "since": None}
_WAIT_LOCK = threading.Lock()


class _Waiting:
    """Count a request for as long as it is blocked on _SERVE_LOCK."""

    def __enter__(self):
        with _WAIT_LOCK:
            _WAITING["n"] += 1
            if _WAITING["since"] is None:
                _WAITING["since"] = time.time()
        return self

    def __exit__(self, *_exc):
        with _WAIT_LOCK:
            _WAITING["n"] = max(0, _WAITING["n"] - 1)
            if _WAITING["n"] == 0:
                _WAITING["since"] = None
        return False


def _is_generative(path):
    """Can this model answer a chat request at all?

    The HF cache holds plenty that cannot: BERT and DistilBERT encoders for
    NER and POS tagging, sentence-transformers embedders, a whisper model.
    Offering them in /v1/models would invite a request that switches to one
    and then cannot serve anything -- a six-second restart into a dead end.

    A generative model declares an eos_token_id (how generation knows to
    stop); an encoder has none. Read from config.json, which is already on
    disk. Unreadable config means NOT offered: the catalogue should err
    toward too short rather than toward a model that cannot reply.
    """
    try:
        with open(os.path.join(path, "config.json")) as fh:
            cfg = json.load(fh)
    except (OSError, ValueError):
        return False
    if cfg.get("eos_token_id") is not None:
        return True
    return (cfg.get("text_config") or {}).get("eos_token_id") is not None


def _context_length(path):
    """The model's context window in tokens, from its config.json, or None.

    /v1/models must carry it. A client that cannot read the window guesses
    one, and guesses low: stock Hermes Agent fell back to its "qwen"
    catch-all of 131,072 for Qwen3.6-35B-A3B, whose window is 262,144, and
    so compressed conversations at half the real size. Compression rewrites
    the prefix, which is precisely what turns a faxl cache hit into a miss.

    faxl imposes no prompt cap of its own, so the model's window IS what
    this server accepts. Multimodal configs nest it under text_config.
    Unreadable or absent means None, and the field is left out: a number
    that is not the model's would be worse than no number.
    """
    try:
        with open(os.path.join(path, "config.json")) as fh:
            cfg = json.load(fh)
    except (OSError, ValueError, TypeError):
        return None
    for c in (cfg.get("text_config") or {}, cfg):
        v = c.get("max_position_embeddings")
        if isinstance(v, int) and not isinstance(v, bool) and v > 0:
            return v
    return None


def _listed_id(mid, all_ids):
    """The id /v1/models offers for `mid`: its bare repo name, unless another
    model on this machine has the same bare name.

    WHY NOT THE REPO ID. Clients address a model as "<provider>/<model>" and
    split on the slash. Stock MiniMax Code requires exactly one: an agent
    pinned to custom_provider:faxl/<org>/<name> is dropped without a word
    ("Unknown agent: advisor" when it is called), while
    custom_provider:faxl/<name> loads -- measured 2026-10-13 on 0.6.9 with
    mlx-community's Qwen3.6 35B-A3B 4-bit. A client that picks from this list, or a user copying from it, got
    the form that breaks. Requests by the full repo id are still served (see
    _switch_target and the ModelMismatch check), so existing configs keep
    working; the full id is reported as `root`, as vLLM does.
    """
    bare = str(mid).rstrip("/").split("/")[-1]
    if bare == mid:
        return mid
    same = [m for m in all_ids if str(m).rstrip("/").split("/")[-1] == bare]
    return mid if len(set(same) | {mid}) > 1 else bare


def _model_entry(mid, path, resident, all_ids=()):
    """One /v1/models row. context_length is the name OpenRouter and LM
    Studio use and Hermes reads first; max_model_len is vLLM's, which other
    OpenAI-compatible clients read. Same number under both."""
    row = {"id": _listed_id(mid, all_ids), "root": mid, "object": "model",
           "owned_by": "faxl", "faxl": {"resident": resident}}
    ctx = _context_length(path) if path else None
    if ctx:
        row["context_length"] = ctx
        row["max_model_len"] = ctx
    return row


def _names_served_model(asked):
    """True when a request's `model` names what this proxy serves: nothing at
    all, a generic alias, the full id, the bare repo name, or a suffix of the
    id after a "/". One rule for the on-demand switch (_switch_target) and the
    vLLM refusal of another model's name (_chat_impl, Halo-5w4.37).

    GENERIC ALIASES MEAN "whatever this proxy serves", and they must keep
    working. Clients configured against faxl before on-demand switching
    existed send model: "faxl" (it is in ~/.minimax/config.yaml, and the
    console's own chat used it), and OpenAI-compatible tools often send a
    placeholder because the endpoint only ever had one model. Treating those
    as a request for a MISSING model turned every such client into a 400 --
    measured immediately after this feature shipped, and worse than the
    problem it was added to solve.
    """
    asked = str(asked or "").strip()
    if not asked or asked.lower() in ("faxl", "default", "auto", "local", "model"):
        return True
    short = str(MODEL).split("/")[-1]
    return asked in (MODEL, short) or str(MODEL).endswith("/" + asked)


def _switch_target(asked):
    """The model id to switch to, or None to serve this request as we are.

    Returns None when the request names the resident model (by full id or by
    the bare repo name, as /v1/models reports both), names nothing at all, or
    names something this machine does not hold -- an unknown name is a 400
    from the caller above, never a switch, because downloading a model as a
    side effect of a chat request is not something a proxy should do.
    """
    asked = str(asked or "").strip()
    if _names_served_model(asked):
        return None
    for mid, _path in faxl_config.local_models():
        if asked in (mid, mid.split("/")[-1]):
            # Same rule as the catalogue: switching to an encoder would spend
            # six seconds to arrive somewhere that cannot answer.
            return mid if _is_generative(_path) else False
    return False        # named, on no disk here: the caller refuses it


def _begin_switch(target):
    """Write the choice, then relaunch. Returns the seconds to advise waiting.

    Called with _SERVE_LOCK HELD, so no generation is in flight. The config is
    written BEFORE the relaunch and a failed write aborts the whole thing: a
    proxy that kills itself and then comes back on whatever the file used to
    say is the "restart brought back a different model" failure the console
    already learned about the hard way.
    """
    faxl_config.set_backend(_BACKEND_NAME, target)
    launcher = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "faxl_start.sh")
    launcher = os.environ.get("FAXL_LAUNCHER", launcher)
    if not os.path.isfile(launcher):
        raise RuntimeError(f"launcher not found at {launcher}")
    # The same directory the console's _log_path reads (faxl_config.faxl_home).
    log_dir = os.path.join(faxl_config.faxl_home(), "logs")
    os.makedirs(log_dir, exist_ok=True)
    # Wait for THIS process to be gone before starting the next one: the
    # launcher refuses to start while a proxy is running (two copies of a model
    # do not fit), and an 80 GB process does not release its memory on a
    # schedule. Same discipline as tools/faxl.sh -- poll, never sleep a guess.
    script = ('sleep 0.5\n'
              'kill "$2" 2>/dev/null\n'
              'for _ in $(seq 1 240); do kill -0 "$2" 2>/dev/null || break; '
              'sleep 0.5; done\n'
              'kill -0 "$2" 2>/dev/null && kill -9 "$2" 2>/dev/null\n'
              'for _ in $(seq 1 60); do kill -0 "$2" 2>/dev/null || break; '
              'sleep 0.5; done\n'
              'exec bash "$1"\n')
    env = dict(os.environ)
    env["FAXL_PYTHON"] = sys.executable
    env.pop("FAXL_MODEL", None)      # the config was just written; do not fight it
    env.pop("EXO_SRC", None)
    with open(os.path.join(log_dir, "switch.log"), "ab") as fh:
        subprocess.Popen(["/bin/bash", "-c", script, "switch", launcher,
                          str(os.getpid())],
                         stdout=fh, stderr=fh, start_new_session=True, env=env)
    _SWITCHING["to"] = target
    _SWITCHING["at"] = time.time()
    return 8

# ---- STOP: cancelling a reply that is already being generated ---------------
#
# A chat client needs to abandon a reply it no longer wants -- a wrong turn, a
# runaway thinking block, three minutes of silence. Without it the only way out
# is killing the proxy, which loses the model load (two minutes for an 80 GB
# checkpoint) and every other client's queued request with it.
#
# HOW IT IS BOUNDED. The decode loop polls cancel() once per token, so the stop
# lands after at most ONE token's decode -- ~60 ms at the 16.7 tok/s measured
# on Qwen3.8-Flash-Next, far inside the half second asked for. It is not a
# timeout and does not interrupt anything mid-operation: the loop simply stops
# and returns what it has, which is a real partial answer rather than an error.
#
# WHAT IT DELIBERATELY DOES NOT DO. It cannot abort a PREFILL. Prefill is a
# handful of large matrix multiplications inside MLX with no Python frame to
# poll between them, and the only way to stop one is to kill the process. So a
# stop during prefill takes effect at the first decoded token. The console says
# which phase it is in, so the wait is legible rather than mysterious.
_CANCELLED = set()          # request ids asked to stop
# WHO ASKED (Halo-5w4.44): "user" for /v1/cancel, "disconnect" for a client that
# closed its stream. Kept beside the flag, under the same lock, so every
# cancelled reply can say why it stopped; the client's deadline is not a flag
# (it is read from the clock) and is named where it is seen.
_CANCEL_CAUSE = {}          # request id -> the first cause recorded for it
_CANCEL_LOCK = threading.Lock()


# Fallback deadline for clients that can send neither header nor body field.
# Unset (0) = wait forever, which is the historic behaviour.
REQUEST_DEADLINE_S = float(os.environ.get("FAXL_REQUEST_DEADLINE_S", "0") or 0)


def _request_deadline_s(raw):
    """Seconds the caller is prepared to wait, or 0.0 for 'no limit'.

    Garbage is ignored rather than refused: a malformed deadline must not cost
    somebody their request, and 0 simply means the old behaviour. Negative and
    absurd values are clamped -- a deadline in the past would cancel every
    request the instant it arrived.
    """
    for v in (raw, REQUEST_DEADLINE_S):
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if f > 0:
            return min(f, 86400.0)      # a day is already past any sane wait
    return 0.0


class _Cancelled(Exception):
    """A stop that landed during PREFILL, before any token was decoded.

    Carries how far the prefill got, so the reply can say "cancelled at N
    tokens" rather than report an error. It is not a failure: the client
    asked, and the checkpoints written before the stop are kept -- the next
    request resumes from them, so the work is banked rather than thrown away.

    `cause` says who stopped it: "user" (/v1/cancel), "deadline" (the
    client's own deadline) or "disconnect" (the client closed its stream).
    Required, so no raise can leave the reply unable to say why (Halo-5w4.44).
    """

    def __init__(self, prefilled_pos=0, *, cause):
        super().__init__(f"cancelled during prefill at {prefilled_pos}")
        self.prefilled_pos = prefilled_pos
        self.cause = cause

# ---- STREAMING: tokens from the decode loop to the open HTTP response -------
#
# The decode runs under _SERVE_LOCK (and, for a hybrid, on the main thread via
# _MAIN_Q). The HTTP response is being written by a Werkzeug worker. A queue is
# what joins them without either side waiting on the other: the decode loop
# PUTS a token and returns to decoding immediately; the worker GETS tokens and
# writes SSE frames as they arrive.
#
# UNBOUNDED ON PURPOSE. A bounded queue would make the decode loop block when a
# slow client stops reading -- and the decode loop holds the serve lock, so one
# stalled browser would wedge the proxy for everybody. That is the failure this
# console has already seen once. The memory cost is a few thousand ints.
class _Sink:
    """One in-flight streamed reply."""

    __slots__ = ("q", "done", "think_open")

    def __init__(self):
        self.q = _q.Queue()
        self.done = False
        # Set by _chat_impl once the prompt is rendered: did the template
        # leave a <think> open, so the first tokens are reasoning?
        self.think_open = None

    def put(self, token_id):
        self.q.put(token_id)

    def finish(self):
        self.done = True
        self.q.put(None)        # the sentinel the reader stops on


_STREAM_SINK = {}           # req_id -> _Sink, only while streaming
_SINK_LOCK = threading.Lock()


def _sink_open(req_id):
    sink = _Sink()
    with _SINK_LOCK:
        _STREAM_SINK[req_id] = sink
    return sink


def _sink_close(req_id):
    with _SINK_LOCK:
        sink = _STREAM_SINK.pop(req_id, None)
    if sink is not None:
        sink.finish()
    return sink


def _cancel_request(req_id, cause="user"):
    """Mark a request cancelled, recording who asked ("user" from /v1/cancel,
    "disconnect" from a stream whose client went away). The first cause
    recorded stands. Returns False for an empty id."""
    if not req_id:
        return False
    with _CANCEL_LOCK:
        _CANCELLED.add(str(req_id))
        _CANCEL_CAUSE.setdefault(str(req_id), cause)
    return True


def _cancel_cause(req_id):
    """Who asked to stop this request, or None if nobody has."""
    if not req_id:
        return None
    with _CANCEL_LOCK:
        return _CANCEL_CAUSE.get(str(req_id))


def _is_cancelled(req_id):
    if not req_id:
        return False
    with _CANCEL_LOCK:
        return str(req_id) in _CANCELLED


def _clear_cancel(req_id):
    """Drop the flag once the request is over, so the set cannot grow without
    bound and an id can never be cancelled before it starts."""
    if not req_id:
        return
    with _CANCEL_LOCK:
        _CANCELLED.discard(str(req_id))
        _CANCEL_CAUSE.pop(str(req_id), None)




def _settle_history_msg(assistant_msg):
    """The assistant turn as the NEXT request will render it.

    THINKING IS KEPT IN THE CURRENT TURN AND DROPPED FROM HISTORY. Every
    reasoning chat template does this -- the model is shown its own reasoning
    while it writes, and never shown it again -- so the reply faxl just
    produced is NOT the text that will be in the prompt next time.

    Measured on Qwen3.6-35B-A3B with a 40-word reasoning block: the settle
    rendered 102 tokens and the next turn rendered 28, diverging at the exact
    character where <think> began. So the settle was caching a prefix that no
    future turn would ever send, and everything after the first assistant
    reply was wasted. In a live console conversation that showed up as
    resume@512 on a 1,711-token prompt -- 1,199 tokens re-prefilled with a
    2,048 checkpoint sitting unusable because it was DEEPER than the prompt.

    Stripping it here is what makes thinking and caching work together, which
    is the combination that matters: a reasoning model's answers are long and
    slow, so they are exactly the ones worth not recomputing.

    The strip is deliberately narrow -- a leading <think>...</think> block and
    nothing else. A reply that merely mentions the tag in prose is untouched,
    because a wrong strip would corrupt the stored prefix rather than merely
    fail to match it.
    """
    # Reasoning now travels in reasoning_content. A final reply becomes plain
    # history on the next turn, where the template drops it; a tool-call turn
    # is still "after the last user message", where the template keeps it --
    # so only the former loses it here.
    if assistant_msg.get("reasoning_content") and not assistant_msg.get("tool_calls"):
        assistant_msg = {k: v for k, v in assistant_msg.items()
                         if k != "reasoning_content"}
    content = assistant_msg.get("content")
    if not isinstance(content, str) or "</think>" not in content:
        return assistant_msg
    head, _, tail = content.partition("</think>")
    stripped = head.lstrip()
    # THE OPENING TAG IS OFTEN NOT IN THE REPLY AT ALL. Several templates --
    # Qwen3.8-Flash-Next among them -- put "<think>\n" at the END OF THE PROMPT,
    # so the model generates only the reasoning body and the closing tag. A
    # reply therefore legitimately begins mid-thought with a bare </think>
    # later on, and requiring the opener would silently skip exactly the models
    # this matters most for.
    #
    # What distinguishes a reasoning block from prose that mentions the tag is
    # that the block comes FIRST: everything before </think> is either the
    # opener, or the reasoning itself with no "</think>" of its own.
    # Prose that merely MENTIONS the tag is left alone: a reasoning block is
    # the whole of the text before </think>, so anything that reads like a
    # sentence continuing afterwards is not one. The test is cheap and
    # conservative -- a reasoning block never has visible prose before its
    # opener, and a sentence about tags is never the entire head.
    looks_like_reasoning = (stripped.startswith("<think>")
                            or ("<think>" not in head
                                and not tail.lstrip().startswith(("to ", "and ",
                                                                 "tag", "in ",
                                                                 "when ", "is "))))
    if looks_like_reasoning:
        out = dict(assistant_msg)
        out["content"] = tail.lstrip("\n")
        return out
    return assistant_msg


def _token_ids(rendered, tok):
    """apply_chat_template's output as list[int], whatever shape it came in."""
    if isinstance(rendered, str):
        rendered = tok.encode(rendered)
    if hasattr(rendered, "ids"):
        rendered = list(rendered.ids)
    elif hasattr(rendered, "get") and rendered.get("input_ids") is not None:
        rendered = rendered["input_ids"]
    if rendered and isinstance(rendered[0], (list, tuple)):
        rendered = rendered[0]
    return [int(t) for t in rendered]


def _settle_as_history(tok, canon, tmpl_kw, ids):
    """The settle's tokens as the NEXT request will render them.

    A settle stores the conversation plus the reply just delivered, so the
    next turn resumes from it. Qwen3.x's template renders the LAST assistant
    turn with an empty "<think>\n\n</think>\n\n" block and drops that block
    once a user turn follows it (measured on Qwen3.6-35B-A3B, 2026-10-14). The
    settle rendered the reply as the last turn, so its checkpoint never
    matched any next request: for short turns -- under the first scheduled
    checkpoint -- every multi-turn request ran cold (voice repair: 0 tokens
    from cache on every chunk).

    The history form is read from the template itself: render the
    conversation followed by a one-character user turn twice, with different
    characters, and keep what the two share -- everything up to where the
    next user's text begins. Used only when the plain settle tokens are NOT
    already a prefix of it, so a template that renders history and last turn
    alike keeps exactly the old behaviour (including a tool turn next).
    """
    kw = dict(tmpl_kw)
    kw["add_generation_prompt"] = False
    try:
        a, b = (_token_ids(tok.apply_chat_template(
                    canon + [{"role": "user", "content": probe}], **kw), tok)
                for probe in ("a", "b"))
    except Exception:                                         # noqa: BLE001
        return ids
    n = 0
    while n < min(len(a), len(b)) and a[n] == b[n]:
        n += 1
    if n == 0 or a[:len(ids)] == ids:
        return ids
    return a[:n]


def _spawn_settle(messages, assistant_msg, tools=None, think=None):
    """Fire-and-forget: POST the conversation + the reply just delivered back
    to THIS proxy as a prefill-only settle request (see SETTLE). It queues on
    _SERVE_LOCK behind any live request, so a user who replies instantly waits
    at most one answer-length prefill; typically it runs while they read."""
    import urllib.request
    assistant_msg = _settle_history_msg(assistant_msg)
    # THE SETTLE MUST RENDER THE SAME PROMPT THE NEXT TURN WILL. Tools are
    # rendered into the system block, so a settle without them diverged at
    # the first token for every agent client: measured with stock MiniMax
    # Code, 4,262 settle tokens against a 12,559-token real prompt -- five
    # seconds of GPU per turn holding the serve lock, for a prefix no request
    # would ever send.
    body = {"model": MODEL, "messages": messages + [assistant_msg],
            "stream": False}
    if tools:
        body["tools"] = tools
    if think is not None:
        body["enable_thinking"] = bool(think)

    def _go():
        try:
            payload = json.dumps(body).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{os.environ.get('FAXL_PORT', '8767')}"
                "/v1/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json",
                         "X-Faxl-Settle": "1"})
            urllib.request.urlopen(req, timeout=600).read()
        except Exception as e:  # noqa: BLE001 -- settle must never hurt a serve
            print(f"!! settle failed ({type(e).__name__}: {e}) -- the answer "
                  f"stays uncached until the next turn re-prefills it",
                  flush=True)
    threading.Thread(target=_go, daemon=True, name="faxl-settle").start()


@app.route("/v1/cancel", methods=["POST"])
def cancel_request():
    """Stop a reply that is being generated. {"id": "<txn id>"} -> 200.

    LOCAL ONLY, and deliberately not under /v1/chat: this does not serve a
    completion, it interrupts one. The id is the txn id the console already
    has (it is in the SSE stream's own frames and in /api/requests), so no new
    bookkeeping is needed to know what to cancel.

    ALWAYS 200, even for an id nobody is running. A stop button that errors
    when the reply has just finished on its own is a stop button people learn
    not to trust -- and "it was already done" is not a failure. The body says
    which it was.

    It never touches the serve lock. Setting a flag is all it does; the decode
    loop reads that flag between tokens and stops itself, which is why this
    answers instantly even while the proxy is busy generating.
    """
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return jsonify({"error": {
            "message": "cancel is available from this machine only",
            "type": "forbidden"}}), 403
    body = request.get_json(silent=True) or {}
    rid = str(body.get("id") or "").strip()
    if not rid:
        return jsonify({"ok": False, "error": "no id"}), 400
    # was_running is reported from the SINK, not from the cancel call: a
    # cancel always succeeds (it just sets a flag), so `or _cancel_request(...)`
    # would make this always true and the field would carry no information.
    # A non-streamed request has no sink and still cancels correctly -- the
    # decode loop polls the same flag -- it simply cannot be observed here.
    running = rid in _STREAM_SINK
    _cancel_request(rid)
    return jsonify({"ok": True, "id": rid, "was_running": bool(running)})


# ---- A CLIENT ERROR IS A NAMED 4xx, NEVER AN OPAQUE 500 (Halo-5w4.35) -------
#
# A request whose body the proxy cannot read used to reach an uncaught
# exception somewhere in chat() or _chat_impl -- `body.get` on a JSON array,
# `len(None)`, `dict("text")`, `int(None)`, an unhashable tool-call id used as
# a dict key -- and the client got Flask's default 500: "the server broke,
# retry", for a request that fails the same way every time. These rules are
# exactly the shapes that crashed (or, for the four _request_shape_problem's
# docstring names, that the OpenAI API itself does not accept); everything
# else the proxy served before is served unchanged.
_IMAGE_PART_TYPES = ("image_url", "input_image", "image")
_MISSING = object()


def _json_kind(value):
    """A parsed JSON value's type, as a refusal message says it."""
    if value is _MISSING:
        return "missing"
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "a boolean"
    if isinstance(value, (int, float)):
        return "a number"
    if isinstance(value, str):
        return "a string"
    if isinstance(value, list):
        return "an array"
    return "an object"


def _request_shape_problem(body):
    """(param, what it must be, what it is) for the first field of a parsed
    request object the proxy cannot serve, in request order; None when there
    is none. Halo-5w4.35.

    Each rule is a shape that raised inside the entry path (the line it hit
    is in the comment), except four the OpenAI API does not accept and some
    chat templates silently turned into an empty turn or an unbounded reply:
    a message that is not an object (a list of key/value pairs happened to
    pass dict()), content that is a number, boolean or object, a null text in
    a picture's part list (dropped), and max_tokens below 1 (vLLM refuses it
    inside generation; mlx_lm served nothing or an unbounded reply).
    """
    kind = _json_kind
    msgs = body.get("messages", _MISSING)
    many = "a non-empty array of message objects"
    if not isinstance(msgs, list):          # len(None), dict("x") in _chat_impl
        return ("messages", many, kind(msgs))
    if not msgs:                            # "empty conversation" in transformers
        return ("messages", many, "an empty array")
    for i, m in enumerate(msgs):
        at = f"messages[{i}]"
        if not isinstance(m, dict):         # dict(m) in the canon loop
            return (at, "a message object", kind(m))
        # A ROLE IS A STRING (Halo-5w4.36). The Qwen3, Qwen3-VL and
        # granite-4 templates drop a message without one, unannounced (the
        # model answers a conversation without it); granite-3.3 and Phi-4
        # raise on a null or number role. OpenAI requires a string.
        role = m.get("role", _MISSING)
        if not isinstance(role, str):
            return (at + ".role", "a string", kind(role))
        c = m.get("content")
        if c is not None and not isinstance(c, (str, list)):
            return (at + ".content", "a string, an array of content parts, or null",
                    kind(c))
        if isinstance(c, list):
            for j, part in enumerate(c):
                # "\n".join over each part's text, in the canon loop and in
                # _flatten_multimodal; a picture's own members never reach it
                if (isinstance(part, dict)
                        and part.get("type") not in _IMAGE_PART_TYPES
                        and "text" in part and not isinstance(part["text"], str)):
                    return (f"{at}.content[{j}].text", "a string", kind(part["text"]))
        if m.get("role") == "assistant" and m.get("tool_calls"):
            calls = m["tool_calls"]
            if not isinstance(calls, list):  # tc.get on a key or a character
                return (at + ".tool_calls", "an array of tool call objects", kind(calls))
            for k, tc in enumerate(calls):
                tat = f"{at}.tool_calls[{k}]"
                if not isinstance(tc, dict):
                    return (tat, "a tool call object", kind(tc))
                if "function" in tc and not isinstance(tc["function"], dict):
                    return (tat + ".function", "an object", kind(tc["function"]))
                if isinstance(tc.get("id"), (list, dict)):   # idmap[id]: unhashable
                    return (tat + ".id", "a string", kind(tc["id"]))
        if (m.get("role") == "tool"
                and isinstance(m.get("tool_call_id"), (list, dict))):  # `in idmap`
            return (at + ".tool_call_id", "a string", kind(m["tool_call_id"]))
    tools = body.get("tools")
    if tools:                               # t.get(...) in _chat_impl's _sniff argument
        if not isinstance(tools, list):
            return ("tools", "an array of tool objects", kind(tools))
        for k, t in enumerate(tools):
            if not isinstance(t, dict):
                return (f"tools[{k}]", "a tool object", kind(t))
            if "function" in t and not isinstance(t["function"], dict):
                return (f"tools[{k}].function", "an object", kind(t["function"]))
    # max_completion_tokens is OpenAI's current name for the same output
    # budget (max_tokens its older one): the same rule (Halo-5w4.36).
    for field in ("max_tokens", "max_completion_tokens"):
        asked = body.get(field)
        if asked is not None:               # int(...) in _chat_impl; null = not given
            try:
                fits = int(asked) >= 1
            except (TypeError, ValueError, OverflowError):
                fits = False
            if not fits:
                shown = (json.dumps(asked) if isinstance(asked, (int, float))
                         and not isinstance(asked, bool) else kind(asked))
                return (field, "a whole number of at least 1, or null", shown)
    if body.get("enable_thinking") is None:  # only then is it read: .get in _chat_impl
        ctk = body.get("chat_template_kwargs")
        if ctk and not isinstance(ctk, dict):
            return ("chat_template_kwargs", "an object", kind(ctk))
    return None


# Refuse request fields and message parts faxl would not honour, instead of
# serving and warning. Off by default: stock agent clients send such fields
# routinely and a refusal breaks them (see _request_shape_refusal).
STRICT_REQUESTS = os.environ.get("FAXL_STRICT_REQUESTS", "0") == "1"
_UNHONOURED_WARNED = set()


def _request_shape_refusal(raw):
    """The 400 body for a request body the proxy cannot read, or None.

    `raw` is the request's bytes. Parsed with json.loads, which is what
    _chat_impl's request.get_json(force=True) does with them (Flask's default
    JSON provider), so what passes here parses the same way there.
    """
    def refuse(code, param, message):
        return {"error": {"message": message, "type": "invalid_request_error",
                          "code": code, "backend": BACKEND.name, "param": param}}
    try:
        body = json.loads(raw)
    except (ValueError, RecursionError) as e:
        return refuse("invalid_json", None,
                      f"The request body is not JSON ({e}). Send one JSON object.")
    if not isinstance(body, dict):
        return refuse("invalid_json", None,
                      f"The request body must be a JSON object; it is "
                      f"{_json_kind(body)}.")
    problem = _request_shape_problem(body)
    if problem is not None:
        param, expected, got = problem
        return refuse("invalid_request_field", param,
                      f"{param} must be {expected}; it is {got}.")
    conflict = _output_budget_conflict(body)
    if conflict is not None:
        return refuse("invalid_request_field", "max_completion_tokens", conflict)
    # exo is handed the client's own body (_forward_to_exo); what it does with
    # these fields is exo's. mlx and vllm generate here, and do not.
    if BACKEND.name != "exo":
        unhonoured = _unhonoured_value_problem(body)
        if unhonoured is not None and not STRICT_REQUESTS:
            # SERVED, AND SAID ONCE. Stock clients send these as a matter of
            # course: MiniMax Code's title request carries response_format
            # json_schema, and refusing it failed every session's title
            # (2026-10-14). faxl adapts to stock clients; the strict refusal
            # below is opt-in (FAXL_STRICT_REQUESTS=1).
            param, value, accepted, does = unhonoured
            if param not in _UNHONOURED_WARNED:
                _UNHONOURED_WARNED.add(param)
                print(f"!! {param}={_shown_value(value)} is not honoured by "
                      f"{BACKEND.name} ({does}); served anyway. Set "
                      f"FAXL_STRICT_REQUESTS=1 to refuse such requests.",
                      flush=True)
        elif unhonoured is not None:
            param, value, accepted, does = unhonoured
            return refuse("unsupported_value", param, (
                f"{param} is {_shown_value(value)}; this backend ({BACKEND.name}) "
                f"{does}, so the reply would be to a different request than the "
                f"one sent. faxl does not ignore what changes the reply. Send "
                f"{accepted}, or leave it out, and send the request again."))
    return None


def _output_budget_conflict(body):
    """The message for max_tokens and max_completion_tokens both given with
    different values, or None (Halo-5w4.36). They are one limit under two
    names; faxl does not pick one silently (vLLM prefers
    max_completion_tokens without saying so)."""
    a, b = body.get("max_completion_tokens"), body.get("max_tokens")
    if a is None or b is None or int(a) == int(b):
        return None
    return (f"max_completion_tokens and max_tokens are the same limit "
            f"(max_tokens is its older name), and this request gives them "
            f"different values ({json.dumps(a)} and {json.dumps(b)}). faxl will "
            f"not choose one for you. Send one of them, or the same value in "
            f"both, and send the request again.")


def _shown_value(value):
    """A refused value as a message shows it: short scalars as JSON, the
    rest by kind (a logit_bias table is not echoed back whole)."""
    if value is None or isinstance(value, (str, int, float, bool)):
        text = json.dumps(value)
        if len(text) <= 60:
            return text
    return _json_kind(value)


def _no_op_number(value, default):
    return value is None or (isinstance(value, (int, float))
                             and not isinstance(value, bool) and value == default)


# FIELDS THE IN-PROCESS ENGINE DOES NOT HONOUR (Halo-5w4.36). On mlx and vllm
# this proxy generates the reply itself: greedy, one choice, stopping only at
# the model's stop ids and max_tokens, no penalties or biases, no format
# constraint, no log probabilities, text only. _chat_impl reads none of these
# fields, so a value that asks for any of that was ignored and the client got a
# reply to a different request. field -> (is it the no-op value, what is
# accepted, what this backend does instead). temperature/top_p are NOT here:
# every value is served greedy (an owner decision, queued).
_UNHONOURED_FIELDS = {
    "n": (lambda v, b: _no_op_number(v, 1), "1 or null",
          "generates one choice per request"),
    "stop": (lambda v, b: v is None or v == ""
             or (isinstance(v, list) and all(x == "" for x in v)),
             'null, "" or []',
             "does not stop at a client's stop sequences; the reply would run "
             "past them"),
    "logit_bias": (lambda v, b: v is None or v == {}, "null or {}",
                   "does not apply token biases"),
    "presence_penalty": (lambda v, b: _no_op_number(v, 0), "0 or null",
                         "does not apply presence or frequency penalties"),
    "frequency_penalty": (lambda v, b: _no_op_number(v, 0), "0 or null",
                          "does not apply presence or frequency penalties"),
    "logprobs": (lambda v, b: v is None or v is False, "false or null",
                 "does not return log probabilities"),
    "top_logprobs": (lambda v, b: _no_op_number(v, 0), "0 or null",
                     "does not return log probabilities"),
    "response_format": (lambda v, b: v is None or (isinstance(v, dict)
                                                   and v.get("type") == "text"),
                        'null or {"type": "text"}',
                        "does not constrain the reply to a format"),
    "tool_choice": (lambda v, b: v is None or v == "auto"
                    or (v == "none" and not b.get("tools")),
                    '"auto" or null ("none" when no tools are sent)',
                    "leaves it to the model whether to call a tool; it cannot "
                    "require a call, name one, or forbid one"),
    "functions": (lambda v, b: v is None or v == [], "null or []",
                  "passes tools, not the older functions list, to the model, so "
                  "the model would not be told of these functions"),
    "function_call": (lambda v, b: v is None or v == "auto" or v == "none",
                      '"auto", "none" or null',
                      "leaves it to the model whether to call a function; it "
                      "cannot require or name one"),
    "modalities": (lambda v, b: v is None or v == ["text"], '["text"] or null',
                   "replies in text only"),
    "audio": (lambda v, b: v is None, "null", "replies in text only"),
    "web_search_options": (lambda v, b: v is None, "null",
                           "does not search the web"),
}


def _unhonoured_value_problem(body):
    """(param, value, accepted, what the backend does) for the first field of
    a shape-checked request, in the body's own key order, whose value asks for
    something the in-process engine does not do; None when there is none.

    A content part whose type is neither text nor a picture is one too: in a
    text-only part list it was joined away to "" in _chat_impl's canon, beside
    a picture it became its own JSON text (_flatten_multimodal). A part with no
    type is left alone (its text, if any, is what reaches the model).
    """
    for key, value in body.items():
        if key == "messages":
            for i, m in enumerate(value):
                c = m.get("content")
                if not isinstance(c, list):
                    continue
                for j, part in enumerate(c):
                    if (isinstance(part, dict) and "type" in part
                            and part["type"] != "text"
                            and part["type"] not in _IMAGE_PART_TYPES):
                        return (f"messages[{i}].content[{j}].type", part["type"],
                                "a text or picture part in its place",
                                "passes only text and pictures to the model, "
                                "so this part would not reach it")
            continue
        rule = _UNHONOURED_FIELDS.get(key)
        if rule is not None and not rule[0](value, body):
            return (key, value, rule[1], rule[2])
    return None


def _refusal_code(payload):
    """The code a refusal body names, for the telemetry terminal event."""
    err = payload.get("error") if isinstance(payload, dict) else None
    if not isinstance(err, dict):
        return "refused"
    return str(err.get("code") or err.get("type") or "refused")


def _template_refusal(error):
    """The 400 body for a conversation the model's chat template refused."""
    return {"error": {
        "message": (f"The model's chat template refused this conversation: "
                    f"{error}. faxl does not change a conversation to fit a "
                    f"template. Fix the conversation (for example the order "
                    f"or roles of its messages) and send it again."),
        "type": "invalid_request_error", "code": "chat_template_rejected",
        "backend": BACKEND.name, "param": "messages"}}


def _raised_in_template(error):
    """Was `error` raised while the chat template's own code ran?

    transformers compiles every chat template from a string
    (jinja_env.from_string), and jinja2 gives the frames of such code the file
    name "<template>"; an error that left the template carries one in its
    traceback (jinja2 rewrites the traceback so it does), including one raised
    in a filter the template called (transformers' tojson). An error from the
    tokenizer, the renderer around the template or this proxy has none.
    """
    tb = getattr(error, "__traceback__", None)
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == "<template>":
            return True
        tb = tb.tb_next
    return False


_REFERENCE_CONVERSATION = ({"role": "user", "content": "Hello."},)


def _template_renders_reference(tok, tmpl_kw):
    """Does the template render a plain one-message conversation with the
    same arguments (minus the client's tools)? If not, it is broken for every
    request, and its failure on this one is the server's, not the request's."""
    kw = {k: v for k, v in tmpl_kw.items() if k != "tools"}
    try:
        tok.apply_chat_template([dict(m) for m in _REFERENCE_CONVERSATION], **kw)
    except Exception:                                          # noqa: BLE001
        return False
    return True


def _template_error_refusal(error):
    """The 400 body for a conversation the template's own code failed on."""
    return {"error": {
        "message": (f"The model's chat template cannot render this conversation "
                    f"({type(error).__name__}: {error}). The error was raised "
                    f"inside the template's own code, and the template renders a "
                    f"plain one-message conversation, so it depends on what this "
                    f"request holds (for example a tool call without its "
                    f"function). faxl does not change a conversation to fit a "
                    f"template. Change the conversation and send it again."),
        "type": "invalid_request_error", "code": "chat_template_error",
        "backend": BACKEND.name, "param": "messages"}}


def _template_fault(error):
    """The named 500 for a fault on the server while applying the chat
    template (Halo-5w4.36): JSON, not Werkzeug's HTML page, and the whole
    error in the proxy log and, with the evidence writer on, in the response
    row, as the exception path in chat() records it."""
    import traceback
    detail = "".join(traceback.format_exception(type(error), error,
                                                error.__traceback__))
    print(f"!! chat template fault ({type(error).__name__}): the server could "
          f"not apply {MODEL}'s chat template; the request was answered 500 "
          f"chat_template_internal_error.\n{detail}", flush=True)
    _evidence_note(error=detail)
    return jsonify({"error": {
        "message": (f"faxl could not apply the model's chat template: "
                    f"{type(error).__name__}: {error}. This is a fault on the "
                    f"server, not in the request; the full error is in the faxl "
                    f"log."),
        "type": "server_error", "code": "chat_template_internal_error",
        "backend": BACKEND.name, "param": None}}), 500


def _serve_fault(error):
    """The named 500 body for any other fault while serving (Halo-5w4.44).

    An engine that raised (mlx, the vLLM execution and its gates, an exo
    cluster that cannot answer) or a bug in this proxy used to reach the client
    as Werkzeug's HTML page on the plain path and as an unnamed {"message"} in
    the stream. Now both carry this one object, the shape every named error
    here has, and the whole traceback goes to the proxy log, as _template_fault
    does. Unlike the template fault it does not say "not in the request": a
    general fault is not proved independent of what the request held.
    """
    import traceback
    detail = "".join(traceback.format_exception(type(error), error,
                                                error.__traceback__))
    print(f"!! serve fault ({type(error).__name__}): faxl answered this "
          f"request 500 internal_error.\n{detail}", flush=True)
    return {"error": {
        "message": (f"faxl could not serve this request: "
                    f"{type(error).__name__}: {error}. This is a fault on the "
                    f"server; the full error is in the faxl log."),
        "type": "server_error", "code": "internal_error",
        "backend": BACKEND.name, "param": None}}


def _prefill_stop_body(stop, txn_id, completion_id=None):
    """The 200 body for a request stopped during prefill (a _Cancelled), on the
    plain and the streaming path alike.

    ONE VOCABULARY FOR EVERY CANCEL (Halo-5w4.44). This said finish_reason
    "cancelled", which is not a value OpenAI clients parse (stop, length,
    content_filter, tool_calls, function_call), while a stop during decode said
    "stop" with faxl.cancelled. Both now say "stop" and let faxl's own block
    say what happened and why: cancelled, the phase it landed in, and who
    stopped it (cancelled_by: "user", "deadline" or "disconnect"). A 200, not an
    error, as before: a harness retries a 5xx, and this was asked for.
    """
    return {
        "id": (completion_id or getattr(g, "evidence_api_id", None)
               or f"chatcmpl-{txn_id}"),
        "object": "chat.completion",
        "created": int(time.time()), "model": MODEL,
        "choices": [{"index": 0, "finish_reason": "stop",
                     "message": {"role": "assistant", "content": None}}],
        "usage": {"prompt_tokens": stop.prefilled_pos,
                  "completion_tokens": 0,
                  "total_tokens": stop.prefilled_pos},
        "faxl": {"cancelled": True, "phase": "prefill",
                 "cancelled_by": stop.cause,
                 "prefilled_tokens": stop.prefilled_pos}}


# WHAT THE TEMPLATE RENDERS NOTHING OF (Halo-5w4.36). A chat template can
# drop a message (Qwen3: any role but system/user/assistant/tool; Qwen3-VL: a
# system message that is not first), a tools list (Phi-4-mini) or the tool
# calls in history (granite-3.3, Phi-4-mini), and the model then answers a
# request the client did not send. Detected by rendering the prompt with the
# part PERTURBED: if it equals the served prompt, nothing of the part reached
# the model. Perturbed, not removed: a template may render a default in place
# of an absent part (granite-4.0-h-tiny's default system prompt), so a removal
# can equal a part that was rendered; a change to the part cannot.
_RENDER_CHECK_SUFFIX = "\n[faxl render check]"
_RENDER_CHECK_TOOL = {"type": "function", "function": {
    "name": "faxl_render_check", "description": "faxl render check",
    "parameters": {"type": "object", "properties": {}}}}
_RENDER_CHECK_CALL = {"id": "faxl_render_check", "type": "function",
                      "function": {"name": "faxl_render_check", "arguments": {}}}
# Rendered in every position by every template probed (Qwen3, Qwen3-VL,
# Phi-4-mini, granite-3.3, granite-4.0), and the bulk of any conversation:
# not compared, so a plain conversation costs no extra render.
_RENDERED_ROLES = ("user", "assistant", "tool")


def _unrendered_refusal(tok, canon, tmpl_kw):
    """The 400 body for the first part of the request the chat template
    renders nothing of, or None: a message whose role is not user, assistant
    or tool (in message order), then the tool-call history, then the tools.

    `canon` and `tmpl_kw` are exactly what _chat_impl rendered. Renders are
    strings (tokenize=False): the served prompt once, then one per part
    compared. A perturbed render that raises means the part reached the
    template's logic, so it is not reported as dropped.
    """
    served = []

    def unchanged(msgs, kw):
        if not served:
            served.append(tok.apply_chat_template(canon, tokenize=False, **tmpl_kw))
        try:
            return tok.apply_chat_template(msgs, tokenize=False, **kw) == served[0]
        except Exception:                                      # noqa: BLE001
            return False

    def refuse(param, message):
        return {"error": {"message": message, "type": "invalid_request_error",
                          "code": "invalid_request_field",
                          "backend": BACKEND.name, "param": param}}

    for i, m in enumerate(canon):
        role = m.get("role")
        if role in _RENDERED_ROLES:
            continue
        alt = list(canon)
        alt[i] = dict(m, content=(m.get("content") or "") + _RENDER_CHECK_SUFFIX)
        if unchanged(alt, tmpl_kw):
            return refuse(f"messages[{i}].role", (
                f"messages[{i}] has role {json.dumps(role)}, and this model's "
                f"chat template renders nothing of that message's content where "
                f"it stands: the model would never read it. faxl does not drop "
                f"part of a conversation silently. Send it with a role this "
                f"model's template renders there (most templates render user, "
                f"assistant and tool messages anywhere, and a system message "
                f"first) and send the request again."))
    at = next((i for i, m in enumerate(canon)
               if m.get("role") == "assistant" and m.get("tool_calls")), None)
    if at is not None:
        alt = list(canon)
        alt[at] = dict(canon[at], tool_calls=list(canon[at]["tool_calls"])
                       + [_RENDER_CHECK_CALL])
        if unchanged(alt, tmpl_kw):
            return refuse(f"messages[{at}].tool_calls", (
                f"messages[{at}].tool_calls: this model's chat template renders "
                f"no tool calls in the conversation history, so the model would "
                f"read its earlier turns without the calls it made. faxl does "
                f"not drop part of a conversation silently. Send the history "
                f"without tool calls (for example as text in the assistant "
                f"turns), or use a model whose template renders them."))
    if tmpl_kw.get("tools"):
        kw = dict(tmpl_kw, tools=list(tmpl_kw["tools"]) + [_RENDER_CHECK_TOOL])
        if unchanged(canon, kw):
            return refuse("tools", (
                "tools: this model's chat template does not render a tools "
                "list, so the model would never be told of these tools. faxl "
                "does not drop part of a request silently. Send the request "
                "without tools, or use a model whose template renders them."))
    return None


@app.route("/v1/chat/completions", methods=["POST"])
def chat():
    # NO MODEL YET: say so in one plain sentence and point at the console,
    # before any telemetry or locking. 503 is the honest code -- the service
    # is real, it just has nothing loaded until the person chooses.
    if model is None and _LOAD_FROM is None:
        return jsonify({"error": {
            "message": ("faxl has no model loaded yet. Open the console "
                        "and pick one -- it will show what fits this Mac "
                        "and what each option downloads. faxl ships without "
                        "weights and never downloads one without being "
                        "asked."),
            "type": "no_model"}}), 503
    # A BODY THE PROXY CANNOT READ IS REFUSED BY NAME, HERE (Halo-5w4.35):
    # before the switch and telemetry (it is not a serve, so no transaction is
    # opened) and before a stream opens, so a streaming client gets a real
    # 400 status. `body` below stays the silent parse it always was.
    _shape = _request_shape_refusal(request.get_data(cache=True))
    if _shape is not None:
        return jsonify(_shape), 400
    # FIX D6: one request at a time through inference + store writes; the lock is
    # what makes threaded=True safe.
    body = request.get_json(silent=True) or {}
    # A settle request (see SETTLE above) is the proxy talking to itself over
    # loopback: no telemetry transaction is opened for it (emit_start without
    # the completion _chat_impl skips would log a false incomplete).
    _settle_req = (request.headers.get("X-Faxl-Settle") == "1"
                   and request.remote_addr in ("127.0.0.1", "::1"))
    if _settle_req and DEFERRED_CACHE:
        # A settle is PREFILL-ONLY by definition, and a deferred backend has no
        # prefill-only execution: its one GPU call runs the whole plan AND
        # generates. Serving the header would spend a full generation per turn
        # and publish under a request nobody made, so it is refused, loudly.
        # _chat_impl never spawns one on this backend (see TURN SETTLE).
        return jsonify({"error": {
            "type": "settle_unsupported_on_deferred_backend",
            "message": (f"{BACKEND.name}: turn settle needs a prefill-only "
                        f"execution, which this deferred backend does not "
                        f"have")}}), 400
    # ---- ON-DEMAND MODEL SWITCH -------------------------------------------
    # Before telemetry and before the lock: a request for another model is not
    # a serve, so it should not open a transaction it will never complete.
    # A SETTLE IS EXEMPT -- it is the proxy talking to itself about the model
    # already loaded, and letting it trigger a switch would be a loop.
    # Who is asking: the client and, when it says, the agent. Used to tell a
    # second conversation wanting another model from one person switching.
    # The CLIENT is read from the User-Agent alone. client_label() also reads
    # the system prompt (to name Hermes in the console), but one app's side
    # calls have other system prompts: Hermes's title request reads as
    # "openai-sdk" while its main loop reads as "hermes", and a person
    # switching model right after a title would have been refused as a clash
    # with "another" client. The UA is the same on every request of one app.
    _who = (client_compat.client_label(request.headers.get("User-Agent", ""),
                                       faxl_client=request.headers.get("X-Faxl-Client")),
            client_compat.agent_name(body.get("messages")))
    if _SWITCH_ON_DEMAND and not _settle_req and model is not None:
        _want = _switch_target(body.get("model"))
        if _want is False:
            # The SAME list /v1/models offers. Showing encoders here would
            # name models that would be refused if asked for.
            _have = sorted(m for m, _p in faxl_config.local_models()
                           if _is_generative(_p))
            return jsonify({"error": {
                "message": (f"{str(body.get('model'))!r} is not on this "
                            f"machine. faxl serves only models already here "
                            f"and never downloads one to answer a request."),
                "type": "model_not_found",
                "available": _have}}), 400
        if _want:
            _clash = _clash_with(_want, _who)
            if _clash:
                _LAST_CLASH.clear()
                _LAST_CLASH.update(_clash)
                print(f"model clash: {_who[0] or 'a client'}"
                      f"{'/' + _who[1] if _who[1] else ''} asked for "
                      f"{_clash['requested']} while {_clash['loaded']} is in "
                      f"use -- not switching", flush=True)
                # On the record, so the console's request log shows it rather
                # than the request vanishing as the switches used to.
                if TELEMETRY is not None:
                    try:
                        _ctx = uuid.uuid4().hex[:16]
                        _ten = (licence.status().get("customer", "")
                                or os.environ.get("FAXL_TENANT", ""))
                        TELEMETRY.emit_start(
                            _ctx, tenant=_ten,
                            prompt_bytes=len(request.get_data(cache=True) or b""),
                            n_messages=len(body.get("messages", [])),
                            client_label=_who[0], deadline_unix_ns=0,
                            project=_project_tag(request.headers.get("X-Faxl-Project")
                                                 or body.get("faxl_project")))
                        TELEMETRY.emit_rejected(
                            _ctx, reject_reason=f"model_clash:{_clash['requested']}"[:60],
                            tenant=_ten, _seq=99)
                    except Exception:                         # noqa: BLE001
                        pass
                return jsonify({"error": {
                    "type": "model_clash", "message": _clash["message"],
                    "requested": _clash["requested"], "loaded": _clash["loaded"],
                    "client": _clash["client"], "agent": _clash["agent"]}}), 409
            # TAKE THE LOCK: holding it means nothing is decoding, which is
            # what keeps the restart off a live generation.
            #
            # DO NOT BLOCK WAITING FOR IT. A blocking acquire parks a Werkzeug
            # worker thread doing nothing, and the client -- which has already
            # been told to retry -- sends another request that parks another
            # one. Measured on this proxy: real jobs of 85,000 tokens running
            # 190-292s, so a 30s wait never succeeded and every retry during a
            # long job cost a thread. Four pending requests looked to the
            # console like faxl had enqueued duplicates; it had not, it was
            # holding four threads hostage on a lock none of them would win.
            #
            # Non-blocking is strictly better here: if something is generating,
            # the honest answer is "busy, retry" IMMEDIATELY, which costs one
            # thread for a millisecond instead of thirty seconds. Retry-After
            # carries the wait instead of the socket.
            if not _SERVE_LOCK.acquire(blocking=False):
                return jsonify({"error": {
                    "message": ("faxl is serving another request and cannot "
                                "switch models until it finishes. Retry; a "
                                "long generation can take several minutes."),
                    "type": "busy"}}), 503, {"Retry-After": "20"}
            try:
                _wait = _begin_switch(_want)
            except Exception as _sw:                          # noqa: BLE001
                _SERVE_LOCK.release()
                print(f"!! model switch to {_want} failed: "
                      f"{type(_sw).__name__}: {_sw}", flush=True)
                return jsonify({"error": {
                    "message": f"could not switch to {_want}: {_sw}",
                    "type": "switch_failed"}}), 500
            # The lock is NOT released: this process is being replaced, and
            # releasing it would let another request start a generation that
            # the relaunch is about to kill.
            print(f"switching model: {MODEL} -> {_want} "
                  f"(asked for by a request; restarting)", flush=True)
            return jsonify({"error": {
                "message": (f"faxl is switching to {_want}. Retry in about "
                            f"{_wait}s -- the model will be resident and this "
                            f"request will be served normally."),
                "type": "model_switching",
                "switching_to": _want}}), 503, {"Retry-After": str(_wait)}
    # This request will be served on MODEL: remember who, for _clash_with.
    if not _settle_req:
        _LAST_USE.update(t=time.time(), who=_who)
    # TELEMETRY START — SYNCHRONOUS + fail-closed, and BEFORE _SERVE_LOCK so a
    # stalled telemetry fsync never serialises behind queued inference. One hook
    # covers both the non-stream and SSE paths below. The txn id threads down to
    # become req_id (one id per request; AUDIT unchanged).
    txn_id = getattr(g, "evidence_request_id", None) or uuid.uuid4().hex[:16]
    # ONE COMPLETION ID PER REQUEST (Halo-5w4.41 item 4). A stream carried two:
    # a random id on its role, keepalive-time and error frames, and the reply's
    # own id on the rest, where OpenAI gives one id per completion. Chosen
    # here, before either exists: the evidence id when this process records
    # evidence (the reply already carried it), else a new one. The reply, the
    # stream's frames and a stop's body all take it as an argument: the
    # stream's worker runs _chat_impl in another thread, where flask.g set
    # here is not the same object.
    completion_id = (getattr(g, "evidence_api_id", None)
                     or f"chatcmpl-{uuid.uuid4().hex[:12]}")
    # PROJECT TAG: X-Faxl-Project header, or `faxl_project` in the body for
    # clients that cannot set headers. Attributes spend and hit rate to the
    # team that caused them.
    _project = _project_tag(request.headers.get("X-Faxl-Project")
                            or body.get("faxl_project"))
    # THE CLIENT'S OWN DEADLINE, HONOURED HERE.
    #
    # A client that times out locally and gives up leaves this proxy prefilling
    # and generating to completion, holding _SERVE_LOCK. The user sees no
    # answer, resubmits, and the retry QUEUES BEHIND THE ZOMBIE -- two rows "in
    # flight", neither moving, and the second one not even started. Measured in
    # mavis, whose Esc stops its own listening and tells faxl nothing.
    #
    # So: let the caller say how long it is prepared to wait, and stop when
    # that runs out. X-Faxl-Deadline-S (header) or faxl_deadline_s (body),
    # seconds from now; FAXL_REQUEST_DEADLINE_S is the fallback for clients
    # that can send neither. 0/unset means wait forever, which is the old
    # behaviour and stays the default -- a deadline nobody asked for would cut
    # off the long legitimate prefills this cache exists to make worthwhile.
    _deadline_s = _request_deadline_s(request.headers.get("X-Faxl-Deadline-S")
                                      or body.get("faxl_deadline_s"))
    _deadline_mono = (time.monotonic() + _deadline_s) if _deadline_s else 0.0
    _deadline_ns = (int((time.time() + _deadline_s) * 1e9) if _deadline_s else 0)
    if TELEMETRY is not None and not _settle_req:
        try:
            _raw = request.get_data(cache=True) or b""
            TELEMETRY.emit_start(
                txn_id,
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")),  # "" = unattributed
                prompt_bytes=len(_raw), n_messages=len(body.get("messages", [])),
                client_label=_client_label(request.headers.get("User-Agent", ""),
                                           body.get("messages"),
                                           request.headers.get("X-Faxl-Client")),
                deadline_unix_ns=_deadline_ns,
                project=_project)
        except _tel.TelemetryError:
            # v1 fail-closed: refuse before inference; retryable. Never a silent
            # untracked serve. (Loud failure already surfaced + in /health.)
            return jsonify({"error": {"type": "telemetry_unavailable",
                                      "message": "telemetry sink unavailable; retry",
                                      "retryable": True}}), 503
    def _serve_error(reason):
        if _settle_req:        # no transaction was opened; nothing to close
            return
        # A request that errored after START is a FAILED request, not a vanished
        # search — close the transaction so the aggregator sees a terminal event
        # (REJECTED serve_error), never a false "incomplete".
        if TELEMETRY is not None:
            TELEMETRY.emit_rejected(
                txn_id, reject_reason=f"serve_error:{reason}"[:60],
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")), _seq=99)

    if not body.get("stream"):
        with _Waiting(), _SERVE_LOCK:
            try:
                # Inside the try (Halo-5w4.44): a backend that cannot open the
                # evidence request is a fault like any other, the named 500
                # with the transaction closed, not Werkzeug's page.
                if EVIDENCE is not None and hasattr(BACKEND, "begin_evidence_request"):
                    BACKEND.begin_evidence_request({
                        "boot_id": EVIDENCE.boot_id, "writer_sha256": EVIDENCE.writer_sha256,
                        "anchor_sha256": EVIDENCE.anchor_sha256, "serving_request_id": txn_id,
                        "api_response_id": g.evidence_api_id})
                # _run_on_main is a no-op unless the executor is on; see
                # _MAIN_THREAD_INFER. The flow is unchanged either way.
                #
                # copy_current_request_context: _chat_impl reads `request`, and
                # the main thread has no request context of its own -- without
                # this it raises "Working outside of request context".
                resp = make_response(_run_on_main(
                    copy_current_request_context(
                        lambda: _chat_impl(txn_id=txn_id, deadline_mono=_deadline_mono,
                                           completion_id=completion_id))))
                # A REFUSAL IS A TERMINAL EVENT. Every refusal _chat_impl
                # returns (text-only, picture, marker, window, template) comes
                # after telemetry START; without this the transaction stayed
                # open and the aggregator counted a refused request as
                # incomplete (Halo-5w4.35).
                if resp.status_code != 200:
                    _serve_error(_refusal_code(resp.get_json(silent=True)))
                return resp
            except _Cancelled as c:
                # STOPPED DURING PREFILL. A 200 with an empty reply, not an
                # error: the client asked for this, and an error would be
                # retried by a harness that reads 5xx as transient. The
                # checkpoints written before the stop are kept, so the next
                # attempt resumes from them. finish_reason "stop", and faxl's
                # block says it was cancelled, in prefill, and by whom
                # (_prefill_stop_body, Halo-5w4.44).
                _clear_cancel(txn_id)
                return jsonify(_prefill_stop_body(c, txn_id, completion_id)), 200
            except ModelMismatch as e:
                # A request for a model this proxy does not serve is the
                # CLIENT's error, not a server fault: answer 400 and name both
                # models, rather than 500 or (far worse) a plausible reply
                # generated by the wrong one.
                _serve_error("model_mismatch")
                return jsonify(_model_mismatch_body(e)), 400
            except Exception as e:   # emit terminal event, then the named 500
                if EVIDENCE is not None:
                    import traceback
                    _evidence_note(error=traceback.format_exc(), observations=_product_evidence.snapshot({
                        "engine": getattr(BACKEND, "last_evidence", None),
                        "connector_report": getattr(BACKEND, "last_report", None)}))
                _serve_error(type(e).__name__)
                # A FAULT IS A NAMED 500, NEVER WERKZEUG'S HTML PAGE (Halo-5w4.44):
                # the same object the stream's error frame carries.
                return jsonify(_serve_fault(e)), 500
    # SSE streaming (2026-08-19): the proxy previously IGNORED
    # stream:true and hung streaming clients — OpenClaw's embedded
    # runner idle-watchdogged every turn at 120 s (OUR bug, isolated
    # after first being misattributed to the gateway). Contract: emit
    # the role frame IMMEDIATELY, SSE keepalive comments while the
    # serve (prefill included) runs, then content/finish frames and
    # [DONE]. Generation itself is unchanged (single-shot under the
    # serve lock) — this is protocol compliance, not incremental
    # decoding; byte-identity of message content is preserved.
    # (copy_current_request_context is imported at module scope; a local
    # `from flask import ...` here would shadow it and make the SAME name
    # unbound in the non-stream path above.)
    result = {}

    @copy_current_request_context
    def _work():
        with _Waiting(), _SERVE_LOCK:
            try:
                # The evidence request opens here as on the plain path, inside
                # the lock (Halo-5w4.39 item 4). completion_id IS the evidence
                # api id when the writer is on (chosen in chat()).
                if EVIDENCE is not None and hasattr(BACKEND, "begin_evidence_request"):
                    BACKEND.begin_evidence_request({
                        "boot_id": EVIDENCE.boot_id, "writer_sha256": EVIDENCE.writer_sha256,
                        "anchor_sha256": EVIDENCE.anchor_sha256, "serving_request_id": txn_id,
                        "api_response_id": completion_id})
                # The SSE path already runs _chat_impl on its own thread, so
                # without this it hits the same abort as the plain path. The
                # context is already copied onto THIS thread by the decorator
                # on _work, and copy_current_request_context here carries it
                # one hop further, to the main thread.
                # make_response: _chat_impl returns a Response when it serves
                # and a (Response, 400) tuple when it refuses; reading the
                # tuple as a Response raised AttributeError and the refusal
                # reached the client as an unnamed error frame (Halo-5w4.35).
                resp = make_response(_run_on_main(
                    copy_current_request_context(
                        lambda: _chat_impl(txn_id=txn_id, deadline_mono=_deadline_mono,
                                           completion_id=completion_id))))
                result["payload"] = resp.get_json()
                result["status"] = resp.status_code
                if resp.status_code != 200:   # a refusal: close the transaction
                    _serve_error(_refusal_code(result["payload"]))
            except _Cancelled as c:
                # A stop during prefill is a normal end to the stream, not an
                # error frame: the client asked for it. The plain path's body
                # (_prefill_stop_body), so a harness does not retry it the way
                # it would a 5xx.
                result["payload"] = _prefill_stop_body(c, txn_id, completion_id)
                result["status"] = 200
            except ModelMismatch as e:
                # The client's error, named as on the plain path's 400.
                result["payload"] = _model_mismatch_body(e)
                result["status"] = 400
                _serve_error("model_mismatch")
            except Exception as e:          # surfaced in-stream below
                if EVIDENCE is not None:     # as the plain path records it
                    import traceback
                    _evidence_note(error=traceback.format_exc(), observations=_product_evidence.snapshot({
                        "engine": getattr(BACKEND, "last_evidence", None),
                        "connector_report": getattr(BACKEND, "last_report", None)}))
                # The plain path's named error, whole (Halo-5w4.44).
                result["error"] = _serve_fault(e)["error"]
                _serve_error(type(e).__name__)   # close txn (not a false incomplete)
            finally:
                # RELEASE THE SINK AND THE CANCEL FLAG, whatever happened. The
                # sink's sentinel is what lets the drain loop above finish
                # rather than wait out its timeout, and a cancel flag left set
                # would stop the NEXT request that happened to reuse the id
                # before it decoded a single token.
                _sink_close(txn_id)
                _clear_cancel(txn_id)

    # THE SINK MUST EXIST BEFORE THE WORKER STARTS. _gen() is a generator and
    # Flask does not call it until it begins consuming the response -- which is
    # AFTER th.start(). So opening the sink inside _gen() was a race: on a fast
    # first token the decode loop read _STREAM_SINK.get(req_id) as None, no
    # tokens streamed at all, and the entire reply arrived in the final frame.
    #
    # The mcode session measured exactly that: 20 streaming events, content
    # length 0 at every one, then a fully-formed message. Opening it here
    # closes the window -- the worker cannot start before the line above it.
    sink = _sink_open(txn_id)
    th = threading.Thread(target=_work, daemon=True)
    th.start()

    def _gen():
        rid = completion_id
        # THE CANCEL ID TRAVELS IN THE FIRST FRAME. A stop button cannot work
        # without it: the client has to name the request it wants stopped, and
        # until now the txn id existed only inside the proxy. It rides in
        # faxl's own block so an OpenAI client that ignores unknown keys is
        # unaffected.
        first = {"id": rid, "object": "chat.completion.chunk",
                 "created": int(time.time()), "model": MODEL,
                 "faxl": {"txn": txn_id, "cancel": "/v1/cancel"},
                 "choices": [{"index": 0,
                              "delta": {"role": "assistant"},
                              "finish_reason": None}]}
        yield f"data: {json.dumps(first)}\n\n"
        # REAL STREAMING. This used to join the worker thread and emit the
        # whole reply as ONE frame at the end -- "streaming" that showed
        # nothing for three minutes and then everything at once, which is
        # indistinguishable from a hang. The decode loop now puts each token
        # into a sink as it is produced (see _Sink), and this drains it.
        #
        # The tokens are decoded INCREMENTALLY rather than per token: a
        # tokenizer turns ids into text with context, so decoding each id on
        # its own splits multi-byte characters and mangles leading spaces.
        # Decoding the accumulated run and emitting the DIFFERENCE is what
        # makes the stream read as the same text the non-streamed path
        # produces.
        sent = ""          # content streamed so far
        r_sent = ""        # reasoning streamed so far
        rs = None          # ReasoningStream, made once the prompt is rendered
        acc = []
        try:
            while True:
                try:
                    tid = sink.q.get(timeout=5)
                except _q.Empty:
                    if not th.is_alive():
                        break
                    # Nothing decoded for 5s: still prefilling, or thinking.
                    # The comment stays so proxies and browsers hold the
                    # connection open rather than timing it out.
                    yield ": keepalive\n\n"
                    continue
                if tid is None:            # finish() sentinel
                    break
                acc.append(tid)
                try:
                    text = tok.decode(acc)
                except Exception:                             # noqa: BLE001
                    continue
                # STOP STREAMING AT THE TOOL-CALL MARKUP. Everything from the
                # first opener onward is markup the parser will lift out of
                # content, so streaming it would put raw <tool_call> syntax in
                # the client's message, and from there into its conversation
                # history -- the model then reads its own tool-call syntax back
                # next turn. Measured against the mcode client: 1,016
                # characters of content carrying the markup on every message
                # that had a tool call, and none on messages that did not.
                if rs is None:
                    rs = client_compat.ReasoningStream(bool(sink.think_open))
                _cut = _tool_markup_cut(text)
                _visible = text if _cut is None else text[:_cut]
                # Reasoning goes out as reasoning_content, the answer as
                # content -- the same split the final message gets.
                _rd, _cd = rs.feed(_visible)
                for _key, _d in (("reasoning_content", _rd), ("content", _cd)):
                    if not _d:
                        continue
                    if _key == "content":
                        sent += _d
                    else:
                        r_sent += _d
                    yield ("data: " + json.dumps(
                        {"id": rid, "object": "chat.completion.chunk",
                         "created": int(time.time()), "model": MODEL,
                         "choices": [{"index": 0,
                                      "delta": {_key: _d},
                                      "finish_reason": None}]}) + "\n\n")
        finally:
            _sink_close(txn_id)
        while th.is_alive():
            th.join(timeout=5)
        if "payload" not in result or result["payload"] is None:
            # A FAULT: the worker's named error (_serve_fault). With no error
            # either, the worker ended without a reply and without an
            # Exception (a BaseException ended the thread): the same shape.
            err = result.get("error") or {
                "message": (f"faxl could not serve this request: the serving "
                            f"thread ended without a reply (status "
                            f"{result.get('status')}). This is a fault on the "
                            f"server."),
                "type": "server_error", "code": "internal_error",
                "backend": BACKEND.name, "param": None}
            yield ("data: " + json.dumps(
                {"id": rid, "object": "chat.completion.chunk",
                 "error": err}) + "\n\n")
            yield "data: [DONE]\n\n"
            return
        if result.get("status") != 200:
            # A REFUSAL decided after the stream opened (the template's, the
            # picture refusals, the context length -- they need the prompt).
            # The 200 went out with the role frame, so the named error rides
            # in-band, whole, and the stream ends (Halo-5w4.35).
            yield ("data: " + json.dumps(
                {"id": rid, "object": "chat.completion.chunk",
                 "error": result["payload"].get("error")}) + "\n\n")
            yield "data: [DONE]\n\n"
            return
        p = result["payload"]
        msg = p["choices"][0]["message"]

        # Every frame carries the stream's one id (rid, chosen in chat()), not
        # the reply's: on exo the reply is the cluster's and keeps exo's own id.
        def _frame(delta):
            return ("data: " + json.dumps(
                {"id": rid, "object": "chat.completion.chunk",
                 "created": p["created"], "model": p["model"],
                 "choices": [{"index": 0, "delta": delta,
                              "finish_reason": None}]}) + "\n\n")

        # ONLY THE REMAINDER. The drain loop above already streamed everything
        # it saw; re-emitting msg["content"] here would double the reply in
        # any client that accumulates deltas (which is all of them). When
        # nothing streamed -- a tool-call-only reply, or a backend with no
        # on_token -- `sent` is empty and this sends the whole thing, which is
        # the old behaviour exactly.
        _rfull = msg.get("reasoning_content") or ""
        if _rfull and _rfull != r_sent and _rfull.startswith(r_sent):
            yield _frame({"reasoning_content": _rfull[len(r_sent):]})
        _full = msg.get("content") or ""
        if _full and _full != sent:
            if _full.startswith(sent):
                _rest = _full[len(sent):]
            elif sent and sent.startswith(_full):
                # MORE STREAMED THAN THE PARSER KEPT. The streamed text is the
                # raw decode; _full is what survived tool-call extraction, so
                # it can legitimately be a PREFIX of what went out. Nothing is
                # owed in that case -- sending _full again would append a
                # second copy of the reply to what the client already has,
                # which is the doubling the mcode session measured.
                _rest = ""
            elif sent:
                # They diverge mid-string. Sending the whole of _full would
                # double the common part, so send only what follows the last
                # agreeing character. This cannot be reached by the ordinary
                # paths above; it is here so that an unforeseen divergence
                # degrades to a seam rather than to a duplicated message.
                _i = 0
                for _a, _b in zip(sent, _full):
                    if _a != _b:
                        break
                    _i += 1
                _rest = _full[_i:]
            else:
                _rest = _full
            if _rest:
                yield _frame({"content": _rest})
        # OpenAI streaming convention, STRICT: fragment 1 = id+name with
        # EMPTY arguments; fragment 2 = the arguments string. A complete
        # tool call in one fragment double-buffers in real accumulators
        # (measured: OpenClaw stringified it → "root: must be object"
        # validation loops).
        for i, tc in enumerate(msg.get("tool_calls") or []):
            fn = tc.get("function", {})
            yield _frame({"tool_calls": [
                {"index": i, "id": tc.get("id"), "type": "function",
                 "function": {"name": fn.get("name", ""),
                              "arguments": ""}}]})
            yield _frame({"tool_calls": [
                {"index": i,
                 "function": {"arguments": fn.get("arguments", "")}}]})
        yield ("data: " + json.dumps(
            {"id": rid, "object": "chat.completion.chunk",
             "created": p["created"], "model": p["model"],
             "choices": [{"index": 0, "delta": {},
                          "finish_reason":
                          p["choices"][0]["finish_reason"]}],
             "usage": p.get("usage"), "faxl": p.get("faxl")}) + "\n\n")
        yield "data: [DONE]\n\n"

    def _stream():
        # A CLIENT THAT HANGS UP STOPS THE WORK (Halo-5w4.44). It used to
        # close only the sink: the worker prefilled and generated to the end
        # holding _SERVE_LOCK for a reply nobody would read, and the client's
        # retry queued behind it. Werkzeug's dev server sees the hang-up only
        # when it writes the next frame (a token's text, or the keepalive after
        # 5 s with none): that write fails, and the server closes this
        # generator, which raises GeneratorExit here. The stop is then the one
        # /v1/cancel sets, with its cause, so whatever polls it stops: the
        # prefill at its next chunk (and, on a backend that polls per segment,
        # its next segment), mlx decode at its next token, and a request still
        # queued for the lock at the check before its first chunk. A deferred
        # backend's single execution polls nothing and runs to its end, as
        # documented where it is called, and so does exo's one forward. The
        # join and the clear make sure a flag raised after the worker's own
        # _clear_cancel cannot outlive the request. The frames are _gen's own:
        # not one byte of a stream changes.
        try:
            yield from _gen()
        except GeneratorExit:
            if th.is_alive():
                print(f"[faxl] the client closed the stream (req {txn_id}); "
                      f"stopping it as /v1/cancel would", flush=True)
                _cancel_request(txn_id, cause="disconnect")
                th.join()
                _clear_cancel(txn_id)
            raise

    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no",
                             # Readable before the first frame arrives, so a
                             # client can arm its stop button while the prompt
                             # is still prefilling -- which is exactly the
                             # window in which a person wants to give up.
                             "X-Faxl-Txn": txn_id})



class ModelMismatch(ValueError):
    """A request named a model this proxy does not serve."""


def _model_mismatch_body(error):
    """The 400 body for a ModelMismatch, on the plain and the streaming path."""
    return {"error": {
        "type": "model_not_found",
        "message": (f"this proxy serves {MODEL!r}, not {str(error)!r}; "
                    f"point the client at the proxy for that model"),
        "param": "model"}}


def _forward_to_exo(body, ids, txn_id, treq0, n_images=0, project=""):
    """Serve this request on the exo cluster. R1 and R2 both happen off to the
    side, on the prefill wire, while this function only moves the request.

    THE DIVISION. exo executes; this proxy remains the front door and the
    operating layer -- licence gate, telemetry, console, analytics all still
    hang off the request arriving here. What does NOT happen here is the
    ladder: exo's runner asks this process's PrefillServer thread for a
    prefix, and that thread decides and counts the hit. Running the ladder
    again in this handler would load a blob into a process with no model to
    use it with, and double-count every request.

    WHAT IS HONESTLY MEASURED. Wall time and token counts are real. Prefill
    and decode spans belong to exo and are not visible from here, so they are
    left UNSET rather than written as plausible zeros -- proto3 cannot
    distinguish 0 from absent, and a fabricated zero is worse than a gap.
    Hit/miss comes from the prefill server's own counters.
    """
    import urllib.error
    import urllib.request

    url = f"{BACKEND.endpoint}/v1/chat/completions"
    payload = dict(body)
    # MODEL NAME: accept an ALIAS for the model this proxy serves, refuse any
    # other model outright.
    #
    # A client may legitimately address this model by a short local name
    # ("granite-4.0-h-small-8bit") while exo knows only the full repo id and
    # answers 404 for anything else -- so a name that is a suffix of, or
    # identical to, this proxy's model is normalised to the full id.
    #
    # A name that is NOT this model is a DIFFERENT model, and this proxy has
    # exactly one: one tokenizer, one ladder, one store keyed to one model_id.
    # Rewriting that name would answer a request for model B with model A, at
    # HTTP 200, with no warning -- measured: a request for Qwen3-VL came back
    # answered by Granite. Silent, plausible and wrong is the worst failure
    # this codebase has, so it is a 400 instead.
    _asked = str(body.get("model") or "").strip()
    _short = MODEL.split("/")[-1]
    if _asked and _asked not in (MODEL, _short) and not MODEL.endswith("/" + _asked):
        raise ModelMismatch(_asked)
    payload["model"] = MODEL
    payload["stream"] = False        # the SSE wrapper above re-frames it
    raw = json.dumps(payload).encode()

    _hits_before = int(EXO_COUNTS.get("hits", 0))
    _reqs_before = int(EXO_COUNTS.get("requests", 0))

    try:
        req = urllib.request.Request(
            url, data=raw, method="POST",
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=BACKEND.timeout_s) as r:
            body_bytes = r.read()
        if not body_bytes.strip():
            # exo answers 200 with an EMPTY body when its runner raised: the
            # exception is logged on its side and swallowed on the wire.
            # Reporting "expecting value at line 1 column 1" here would send
            # the reader hunting a JSON bug in faxl instead of a crash in the
            # engine, so name it for what it is.
            raise RuntimeError(
                f"exo returned an empty body (HTTP 200) — its runner almost "
                f"certainly raised; check the exo log for a traceback")
        reply = json.loads(body_bytes.decode())
    except (urllib.error.URLError, OSError, ValueError) as e:
        # No failover: a cluster that cannot answer is an error, not a quiet
        # fallback to a local model this process may not even have loaded.
        print(f"!! exo backend failed at {url}: {type(e).__name__}: {e}",
              flush=True)
        raise

    dt = time.time() - treq0
    usage = reply.get("usage") or {}
    out_tokens = int(usage.get("completion_tokens", 0))
    # The prefill server counted this request while exo was serving it; the
    # difference is whether THIS request hit.
    hit = int(EXO_COUNTS.get("hits", 0)) > _hits_before
    served = int(EXO_COUNTS.get("last_served", 0)) if hit else 0

    # ONE TOKEN SPACE, THE MODEL'S. `served` is model POSITIONS resumed, so
    # the prompt it is compared against must be model positions too.
    #
    # len(ids) is not that. It counts what THIS process templated, where an
    # image is a single <image:digest> placeholder of about ten tokens; the
    # vision encoder then expands that one placeholder into ~4,200 pad
    # positions before the model sees it. Measured on the photo workload:
    # len(ids)=1785 against a real prompt of 5987. Charting `served` against
    # len(ids) therefore drew "served from cache" ABOVE "received from users"
    # -- 531k of 569k -- which reads as though the cache invented tokens.
    # It did not; the two lines were in different units.
    #
    # exo reports the real count in usage.prompt_tokens, so use it and fall
    # back to len(ids) only when it is absent (a text prompt, where the two
    # agree anyway).
    n_prompt = int(usage.get("prompt_tokens") or 0) or len(ids)

    _bump_project(project, hit=hit, prompt_tokens=n_prompt, skipped=served,
                  paid=max(n_prompt - served, 0), secs=dt)
    TOTALS["requests"] += 1
    TOTALS["prompt_tokens"] += n_prompt
    TOTALS["prefill_paid"] += max(n_prompt - served, 0)
    TOTALS["prefill_skipped"] += served
    TOTALS["hits"] += 1 if hit else 0
    TOTALS["wall_s"] += dt

    if TELEMETRY is not None:
        _pb = _tel.pb
        _tenant = licence.status().get("customer", "") or os.environ.get(
            "FAXL_TENANT", "")
        _cost = _pb.Cost(
            prompt_tokens=n_prompt,
            prefill_paid=max(n_prompt - served, 0),
            prefill_skipped=served,
            warm_wall_ms=dt * 1000.0,
            cold_basis=_pb.ESTIMATED,
            cold_prefill_ms_est=(served / max(PREFILL_TPS["ewma"], 1e-6)) * 1000.0,
            estimator_id="prefill_tps_ewma",
            estimator_version=str(round(PREFILL_TPS["ewma"], 1)))
        # prefill_ms/decode_ms deliberately UNSET: they happened on exo.
        _tim = _pb.Timings()
        TELEMETRY.emit_completion(
            txn_id or uuid.uuid4().hex[:16], tenant=_tenant,
            outcome=(_pb.HIT if hit else _pb.MISS),
            resume_pos=served,
            hit_tier=(_pb.EXACT if hit else _pb.HIT_TIER_UNSPECIFIED),
            ladder=[], cost=_cost, out_tokens=out_tokens, timings=_tim,
            prompt_content=hashlib.sha256(str(ids).encode()).digest(),
            project=project)

    status = "warm" if hit else "cold"
    _img = f" | {n_images} image(s)" if n_images else ""
    _proj = f" | {project}" if project else ""
    print(f"[{status}/exo]{_proj} {len(ids)} tok{_img} | served {served} | "
          f"{out_tokens} out | {dt:.2f}s | {BACKEND.endpoint}", flush=True)
    return jsonify(reply)


def _chat_impl(txn_id=None, deadline_mono=0.0, completion_id=None):
    treq0 = time.time()   # request start — TTFT anchor (direct measurement)
    body = request.get_json(force=True)
    # ANOTHER MODEL'S NAME IS A 400 THAT NAMES THE LOADED ONE (Halo-5w4.37).
    # vLLM serves one model and answered any `model` at HTTP 200 with it: the
    # silent, plausible and wrong reply _forward_to_exo's check exists to stop
    # ("a request for Qwen3-VL came back answered by Granite"). Same
    # exception and 400 body; chat() closes the transaction it opened, and a
    # stream carries it in-band like the other refusals made here. The
    # generic aliases and the bare repo name still mean the loaded model
    # (_names_served_model). Not on mlx or exo: on mlx another name is a
    # switch (chat()'s on-demand block) or, with FAXL_SWITCH_ON_DEMAND=0, the
    # Mac owner's open item on Halo-5w4.37; exo keeps its own check where it
    # forwards.
    if _BACKEND_NAME not in _MLX_BACKENDS and not _names_served_model(body.get("model")):
        raise ModelMismatch(str(body.get("model")).strip())
    # "developer" read as system, leading system messages merged:
    # what stock clients send and the chat templates accept.
    messages = client_compat.normalize_roles(body.get("messages", []))
    _settle = (request.headers.get("X-Faxl-Settle") == "1"
               and request.remote_addr in ("127.0.0.1", "::1"))
    _sniff("request", {
        "n_messages": len(messages),
        "tools": [t.get("function", {}).get("name") for t in (body.get("tools") or [])],
        "max_tokens": body.get("max_tokens"),
        "max_completion_tokens": body.get("max_completion_tokens"),
        # What the client asked for about THINKING, both shapes, recorded
        # verbatim. A client whose UI says "thinking off" while sending
        # neither is the difference between a setting and a label, and only
        # the wire shows which it is.
        "enable_thinking": body.get("enable_thinking"),
        "chat_template_kwargs": body.get("chat_template_kwargs"),
        # EVERY OTHER TOP-LEVEL FIELD, verbatim. The two above were all this
        # recorded, so a client sending reasoning_effort, a thinking block or
        # max_completion_tokens looked identical to one sending nothing --
        # and "what does stock MiniMax Code send when thinking is off" could
        # not be answered from a capture (2026-10-13).
        "body_fields": {k: v for k, v in body.items()
                        if k not in ("messages", "tools")},
        "user_agent": request.headers.get("User-Agent", ""),
        "settle": bool(_settle),
        "messages": messages,   # full text — this is a debug/inspection mode
    })
    # Default raised from 256: agentic edit tool calls carry whole hunks/files as
    # JSON arguments — at 256 the call truncates mid-argument, fails to parse, and
    # the harness sees dead text (measured: every OpenClaw edit turn cut at 256).
    # Default to effectively-unlimited when the client sends no max_tokens: let the
    # model run until its own end token. Clipping only serves as a runaway backstop,
    # and a low default silently truncates reasoning models mid-<think>. A client
    # that WANTS a cap still sends one and it is honoured. Override via
    # FAXL_MAX_TOKENS_DEFAULT if a hard ceiling is ever wanted.
    # null is OpenAI's "no cap given": the default, as when the field is absent
    # (int(None) was a 500, Halo-5w4.35). Any other value goes through the same
    # int() as before; chat() has refused what int() cannot take, or below 1.
    # max_completion_tokens is OpenAI's current name for the same budget: the
    # first NON-NULL of the two is the cap (it was ignored, and such a client got
    # the default; chat() refuses the two given with different values,
    # Halo-5w4.36).
    _max_default = int(os.environ.get("FAXL_MAX_TOKENS_DEFAULT", "1000000"))
    _max_asked = body.get("max_completion_tokens")
    _max_asked = _max_asked if _max_asked is not None else body.get("max_tokens")
    max_tokens = int(_max_asked) if _max_asked is not None else _max_default
    # FORWARD TOOLS: OpenClaw (and any agent) sends OpenAI-shape `tools`. Granite's
    # chat template renders them into a <tools>…</tools> block and instructs the
    # model to reply with <tool_call>{...}</tool_call>. Without this the model is
    # told nothing about the tools and correctly declines (that was the NO_REPLY).
    tools = body.get("tools") or None
    tmpl_kw = {"add_generation_prompt": True}
    if _settle:
        # The checkpoint must be a byte-prefix of the NEXT real prompt. A
        # generation prompt here would plant settle-only tokens inside the
        # stored prefix and fail its confirm (a harmless miss, a wasted settle).
        tmpl_kw["add_generation_prompt"] = False
    if tools:
        tmpl_kw["tools"] = tools
    # THINKING TOGGLE: reasoning models (Ling, Qwen3, ...) open a <think> block by
    # default; for terse/structured-output tasks that just burns the token budget
    # before the answer. Honour an OpenAI-compat `enable_thinking` (or `chat_template_kwargs`)
    # from the request, else the FAXL_ENABLE_THINKING env default (unset = leave the
    # template's own default). Templates without the flag ignore the kwarg harmlessly.
    # The standard OpenAI `reasoning_effort` counts too: stock clients send
    # that, not a Qwen flag. Hermes sends "none" for its title and other side
    # calls; ignoring it ran an 11,784-token think for a one-line title.
    _think = client_compat.thinking_requested(
        body, request.headers.get("User-Agent", ""))
    if _think is None and "FAXL_ENABLE_THINKING" in os.environ:
        _think = os.environ["FAXL_ENABLE_THINKING"].lower() in ("1", "true", "yes")
    if _think is not None:
        tmpl_kw["enable_thinking"] = bool(_think)
    # CANONICALIZE TOOL-CALL IDS before templating (measured failure, run 3 of the
    # OpenClaw commenting task): we return OpenAI-style ids ("call_xxx"); the client
    # echoes them back in history; Kimi's template renders them verbatim and the
    # model then MIMICS that id shape instead of its native "functions.NAME:IDX" —
    # its next call carries an id-shaped tool NAME the harness cannot resolve, and
    # the session loops on an unavailable tool. Rewriting history ids to the native
    # form (consistently across the assistant call and its tool-result message)
    # keeps the model's exemplar format correct. Name-linkage is preserved because
    # the id embeds the function name; Granite's template ignores ids entirely.
    idmap = {}
    canon = []
    for m in messages:
        m = dict(m)
        # Nemotron's Jinja template calls string methods on content and crashes
        # on the two non-string shapes OpenAI clients legally send: None (pure
        # tool-call turns) and multi-part lists [{"type":"text","text":...}]
        # (OpenClaw). Normalize both to plain strings; harmless for every family.
        c = m.get("content")
        if c is None:
            m["content"] = ""
        elif isinstance(c, list):
            # DO NOT FLATTEN A LIST THAT CONTAINS AN IMAGE.
            #
            # This join keeps only the "text" of each part, so an image_url
            # part became the empty string and the picture was GONE before
            # _flatten_multimodal ever ran. n_images was therefore 0, the
            # images-on-a-text-backend guard never fired, no pixels reached
            # the model, and the reply was invented from the words alone --
            # measured: a photograph of a man by the water came back as "a
            # close-up of a single vibrant red rose", then as a strawberry.
            #
            # _flatten_multimodal is the one place that understands these
            # parts: it hashes each image to a stable <image:digest> atom so
            # the ladder can key on it. Leave multimodal content alone here
            # and let it do its job.
            if any(isinstance(p, dict)
                   and p.get("type") in ("image_url", "input_image", "image")
                   for p in c):
                m["content"] = c
            else:
                m["content"] = "\n".join(
                    p.get("text", "") if isinstance(p, dict) else str(p)
                    for p in c)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            tcs = []
            for i, tc in enumerate(m["tool_calls"]):
                tc = json.loads(json.dumps(tc))
                new_id = f"functions.{tc.get('function', {}).get('name', 'tool')}:{i}"
                idmap[tc.get("id")] = new_id
                tc["id"] = new_id
                # arguments: OpenAI history carries a JSON STRING; Ling's Jinja
                # template calls .items() on it and crashes ("str has no attribute
                # items"). Coerce a JSON-object string to a dict — the OpenAI-internal
                # shape every family's template accepts (dict-consumers need it,
                # string-consumers re-serialize it fine).
                fn = tc.get("function", {})
                a = fn.get("arguments")
                if isinstance(a, str):
                    try:
                        parsed = json.loads(a)
                        if isinstance(parsed, dict):
                            fn["arguments"] = parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                tcs.append(tc)
            m["tool_calls"] = tcs
        if m.get("role") == "tool" and m.get("tool_call_id") in idmap:
            m["tool_call_id"] = idmap[m["tool_call_id"]]
        canon.append(m)
    # IMAGES: flatten multimodal parts so the template sees strings. The real
    # images are not lost -- the exo path forwards the ORIGINAL body below --
    # this is only what the ladder hashes.
    canon, _n_images = _flatten_multimodal(canon)
    # THE TEMPLATE MAY REFUSE THE CONVERSATION. HF templates call
    # raise_exception(...) for a conversation they do not accept, which
    # transformers raises as jinja2's TemplateError: the client's conversation,
    # so a named 400 quoting the template, not a 500 (Halo-5w4.35). A template
    # that does not compile is the server's and raises as before.
    try:
        try:
            ids = tok.apply_chat_template(canon, **tmpl_kw)
        except TypeError as _te:
            # A TypeError from the TEMPLATE'S OWN CODE is about the
            # conversation, not the flag: transformers hands extra keyword
            # arguments to the template, so no template raises for
            # enable_thinking (probed on every model in the box's cache,
            # Halo-5w4.36). Retrying it logged a false "THINKING FLAG IGNORED"
            # and raised the same error again; it is classified below instead.
            if _raised_in_template(_te):
                raise
            # A template that doesn't accept enable_thinking (most) — drop it and
            # retry, because refusing the request would be worse than ignoring a
            # flag the model has no notion of.
            #
            # BUT SAY SO. Silently dropping it means a client can ask for thinking
            # OFF, get thinking ON, and find no trace anywhere: the request
            # succeeds, the reply looks normal, and the only symptom is a reasoning
            # trace in the visible answer plus a doubled token bill. A peer session
            # spent a debugging cycle on exactly that shape against Qwen3.8 (whose
            # template DOES take the kwarg, so this path was not the cause -- but
            # nothing in the proxy could have told them so).
            #
            # Once per process, not per request: this is a property of the loaded
            # template, so it would otherwise print on every call.
            _dropped = tmpl_kw.pop("enable_thinking", None)
            if _dropped is not None and not _THINK_WARNED[0]:
                _THINK_WARNED[0] = True
                LOG_FAILURES.append(
                    f"{MODEL}: chat template ignores enable_thinking; requests "
                    f"asking to turn thinking off will still get it")
                print(f"!! THINKING FLAG IGNORED: {MODEL}'s chat template does not "
                      f"accept enable_thinking, so a request asking for thinking "
                      f"OFF still gets it ON. The reasoning trace will appear in "
                      f"the visible reply. Nothing is broken -- this model simply "
                      f"has no switch.", flush=True)
            ids = tok.apply_chat_template(canon, **tmpl_kw)
    except _TemplateSyntaxError as _tpl_err:
        # A template that does not compile is the same for every request: the
        # server's. A named 500, not Werkzeug's HTML page (Halo-5w4.36).
        return _template_fault(_tpl_err)
    except _TemplateError as _tpl_err:
        return jsonify(_template_refusal(_tpl_err)), 400
    except Exception as _tpl_err:                              # noqa: BLE001
        # ANY OTHER ERROR WHILE APPLYING THE TEMPLATE (Halo-5w4.36). Raised
        # inside the template's own code by a template that renders a plain
        # conversation, it depends on what this request holds: a named 400
        # (it was an opaque 500). Raised anywhere else, or by a template that
        # fails on everything, it is the server's: a named 500, logged whole.
        if (_raised_in_template(_tpl_err)
                and _template_renders_reference(tok, tmpl_kw)):
            return jsonify(_template_error_refusal(_tpl_err)), 400
        return _template_fault(_tpl_err)
    # A VLM PROCESSOR'S TOKENIZER RETURNS AN Encoding, NOT A LIST.
    # mlx_lm's tokenizer hands back plain ints, so everything downstream --
    # mx.array(ids[a:b]), len(ids), the prompt hash -- assumed a sequence.
    # Given an Encoding it failed with "Invalid type tokenizers.Encoding
    # received in array initialization" at the first prefill.
    # Three shapes seen in the wild, and the two new ones both came from the
    # VLM processor's tokenizer:
    #   list[int]      mlx_lm's tokenizer, what everything downstream assumes
    #   Encoding       has .ids
    #   BatchEncoding  a dict-like carrying "input_ids", possibly batched
    # A str means the template did not tokenise at all; tokenise it rather
    # than hand a string to mx.array, which fails with a type error three
    # frames away from the cause.
    if isinstance(ids, str):
        ids = tok.encode(ids)
    if hasattr(ids, "ids"):
        ids = list(ids.ids)
    elif hasattr(ids, "get") and ids.get("input_ids") is not None:
        ids = ids["input_ids"]
    if ids and isinstance(ids[0], (list, tuple)):
        ids = ids[0]              # unbatch
    ids = [int(t) for t in ids]
    if _settle:
        ids = _settle_as_history(tok, canon, tmpl_kw, ids)
    # REASONING STARTS IN THE PROMPT for Qwen3.x: its template ends the
    # generation prompt with "<think>\n", so the reply carries only the body
    # and a bare </think>. Knowing that is what lets the reply be split into
    # reasoning_content and content instead of leaking the trace.
    try:
        _think_open = client_compat.prompt_opens_thinking(tok.decode(ids[-16:]))
    except Exception:                                         # noqa: BLE001
        _think_open = False
    with _SINK_LOCK:
        _sk = _STREAM_SINK.get(txn_id)
    if _sk is not None:
        _sk.think_open = _think_open

    # ---- EXO BACKEND: the cluster executes, this proxy stays the front door.
    #
    # The ladder does NOT run here on this path. exo's runner asks for a
    # prefix over the prefill wire (FAXL_PREFILL_ENDPOINT -> this process's
    # PrefillServer thread), which is where a hit or miss is decided and
    # counted; running the ladder a second time in the handler would load the
    # same blob into a process that has no model to use it with.
    #
    # Everything above still applied: the chat template, tool canonicalisation
    # and the thinking toggle shape the messages, and telemetry has already
    # opened the transaction. Only execution moves.
    if BACKEND.name == "exo":
        return _forward_to_exo(body, ids, txn_id, treq0, n_images=_n_images,
                               project=_project_tag(
                                   request.headers.get("X-Faxl-Project")
                                   or body.get("faxl_project")))

    # WHAT THE TEMPLATE RENDERED NOTHING OF IS REFUSED BY NAME (Halo-5w4.36):
    # a message, the tool-call history or the tools list the model would never
    # read. Here, after the exo forward: mlx and vllm generate from exactly
    # this render; exo renders the client's own body itself, so this render
    # cannot show what exo drops. See _unrendered_refusal.
    try:
        _unrendered = _unrendered_refusal(tok, canon, tmpl_kw)
    except Exception as _tpl_err:                              # noqa: BLE001
        return _template_fault(_tpl_err)
    if _unrendered is not None and STRICT_REQUESTS:
        return jsonify(_unrendered), 400
    if _unrendered is not None:
        # Served, as before this check existed, and said: a stock client's
        # conversation is not refused for a part the template drops.
        print(f"!! part of this request is not rendered by the model's "
              f"chat template, served anyway: "
              f"{(_unrendered.get('error') or {}).get('message', '')[:200]}",
              flush=True)

    # IMAGES ON A TEXT BACKEND: REFUSE, DO NOT PRETEND.
    #
    # _flatten_multimodal replaces each image with a text placeholder so the
    # chat template has a string and the ladder has something stable to hash.
    # On the exo path that is harmless -- the ORIGINAL body, pixels intact, is
    # forwarded above. On this path there is nothing downstream to forward to:
    # LocalMlxBackend runs mlx_lm, which loads a vision model as a TEXT model
    # and never sees the vision tower.
    #
    # So the request would have been served 200 with an answer invented from a
    # placeholder. Measured on the exo path before this was understood: a
    # 30,000-character base64 JPEG arrived as 21 tokens and the model answered
    # "1234567890" from nothing. For OCR that is the worst possible failure --
    # confident, well-formatted, and entirely fabricated.
    #
    # A refusal is a limit the caller can see and act on. A fabrication is a
    # lie with a 200 on it. The message names the model it serves, quoted as
    # the other model-naming 400 does (_model_mismatch_body), so a client
    # sees in one step which model to change (owner decision 2026-10-10).
    if _n_images and not BACKEND.accepts_images:
        return jsonify({"error": {
            "message": (
                f"This backend serves {MODEL!r} as text only, and the request "
                f"carried {_n_images} image(s). faxl will not answer from a "
                f"placeholder: the reply would be invented rather than read "
                f"from the picture. Images need a vision-capable backend."),
            "type": "unsupported_content",
            "code": "images_not_supported_on_this_backend",
            "backend": BACKEND.name}}), 400
    # THE SAME RULE ON A BACKEND THAT READS IMAGES (Halo-5w4.33): a picture it
    # will never receive -- a URL it would have to fetch, a payload that is
    # not base64 -- or cannot decode, or more pictures than it reads, is
    # refused by name before any prefill. See _image_request_refusal.
    _image_refused = (_image_request_refusal(body, BACKEND) if _n_images
                      else None)
    if _image_refused is not None:
        return jsonify(_image_refused), 400
    # TEXT IN THE FORM OF THE PICTURE MARKER, BESIDE A PICTURE: refused by
    # name, because nothing downstream can tell it from the marker (see
    # _image_marker_refusal). Without a picture it is text, as before.
    _marker_refused = (_image_marker_refusal(body, _n_images, _atom_spans(tok, ids),
                                             BACKEND) if _n_images else None)
    if _marker_refused is not None:
        return jsonify(_marker_refused), 400
    # Keep the pixels: _flatten_multimodal built the hash text, not the image.
    _req_images = _images_from_body(body) if _n_images else None
    # A PROMPT THE ENGINE CANNOT HOLD is refused here, before the lookup, the
    # plan and the engine, on a backend that declares its window (vLLM); it
    # was the engine's RuntimeError, an opaque 500 (Halo-5w4.35).
    _too_long = _context_length_refusal(ids, _req_images, BACKEND)
    if _too_long is not None:
        return jsonify(_too_long), 400

    t0 = time.time()
    cache_status = "cold"
    prefilled = len(ids)
    resume_pos = 0
    resumed_blob = None   # REPRO DEBUG: the blob actually loaded (None = cold/miss)
    resumed_phash = None  # protected from scored eviction this request
    prompt_hash = hashlib.sha256(str(ids).encode()).hexdigest()[:16]  # exact prompt id
    req_id = txn_id or uuid.uuid4().hex[:16]   # M0: stable request id; == telemetry txn
    aud_probes = []   # ladder walk — always collected (AUDIT + telemetry read it)

    # EXACT-TIER LOOKUP: one O(N) prefix-hash pass, then deepest-first hash lookup +
    # token confirm at each scheduled position. NO ESN probe, NO cosine on this path.
    # Skipped entirely in NOCACHE mode (the A/B control).
    confirm = None      # None = no exact hit; "pass"/"fail" = confirm outcome
    qhash = None
    _regions = []
    hash_build_ms = 0.0
    confirm_ms = 0.0
    # Phase-0 exclusive child spans + one inclusive outer accumulator.
    # cache_blocked_ms totals every cache-path segment the serialised handler
    # spends OUTSIDE prefill/decode; residual_ms = outer − Σ children.
    cache_blocked_ms = 0.0
    probe_rpc_ms = 0.0      # identity_get RPCs (lookup probes + write dedup)
    blob_load_ms = 0.0      # load_prompt_cache on a hit (lazy mmap open)
    fork_discovery_ms = 0.0  # D* search + classify + gate evaluation
    ckpt_write_ms = 0.0     # ALL save_prompt_cache (grid + fork)
    tokfile_ms = 0.0        # token-prefix file writes
    esn_key_ms = 0.0        # probe.key (similarity key) — post-first-token
    upsert_ms = 0.0         # index.add (UltraDim upsert + row bookkeeping)
    # (entry_key, token prefix) per keyed checkpoint, drained after the first
    # token so the key never blocks the reply. See the write site.
    _key_backlog = []
    evict_ms = 0.0          # supersession delete + fork LRU eviction
    # LICENCE GATE: unentitled behaves exactly like NOCACHE — the request is
    # still served, the prefill just runs cold. Degrade, never refuse.
    _entitled = licence.entitled()
    if not NOCACHE and not _entitled:
        cache_status = "unlicensed"
    elif not NOCACHE and len(ids) >= GATE_TOKENS:
        tcb0 = time.time()
        th0 = time.time()
        qhash = prefix_hashes(ids)
        hash_build_ms = (time.time() - th0) * 1000
        # Where this request's pictures sit, so a probe never resumes from a
        # position inside one. Computed once, not per probe.
        _regions = _image_regions(tok, ids) if _n_images else []
        # Plan v1.5 phase 0: probe PERSISTED positions only — every position
        # where a blob is known to exist (grid AND fork). Schedule
        # recomputation is REMOVED from the lookup (it probed positions with
        # no stored blob; regression-tested equal hit sets in
        # test_lookup_regression.py). ckpt_positions stays write-path-only.
        probe_positions = index.known_positions()   # sorted desc
        for pos in probe_positions:
            if pos % SEG and not TRIMMABLE and pos >= SEG:
                # OFF-GRID IS PROBED ONLY ON A PURE-KV MODEL -- above SEG.
                #
                # BELOW SEG THERE IS NO GRID TO BE OFF. The cold path chunks
                # at min(pos + SEG - (pos % SEG), n), so a prompt shorter than
                # one segment is a SINGLE chunk and the only boundary is n
                # itself. A sub-SEG checkpoint is therefore the canonical
                # decomposition, not a departure from it, and refusing to
                # probe it made the write path's sub-SEG anchors write-only --
                # the exact failure this guard exists to prevent, in the other
                # direction. The write side's matching branch has the full
                # reasoning.
                #
                # What this guard protects is HYBRIDS: a recurrent layer's
                # state at a position depends on the chunk decomposition that
                # produced it, so resuming from a boundary the cold path would
                # never have cut at changes the answer. That rule stays.
                #
                # It does not apply to a pure-KV model, where a KV entry is a
                # function of its own position alone -- and this proxy already
                # relies on that, because the TRIM tier resumes off-grid on
                # every warm request ("warm(trimmed,resume@1774,from@1792)").
                #
                # Without this, the image-atom checkpoints the write path now
                # produces are stored and never read: an atom starting at 1780
                # is not a multiple of 256, so every probe skipped it and the
                # run resumed from 256 instead -- 14% reused where the same
                # photographs should reuse ~98%.
                continue
            if pos >= len(ids) - 1:
                continue   # need >=1 tail token to seed generation
            # A BLOB STORED INSIDE THE <image:digest> ATOM IS NOT SERVABLE.
            #
            # THIS IS NOT safe_depth(), and it is not what 2d0fdfb removed.
            # That guard was described as refusing "any depth at or past an
            # image start"; what it actually tested was `a < pos < b` --
            # strictly INSIDE -- and removing it was a misreading. The writer
            # clamp above states the rationale and the reader must agree with
            # it: on the ATOM stream a depth mid-atom is character twelve of a
            # hex digest, so the remainder text-prefills, no chunk carries the
            # marker, the vision tower never runs, and the model answers from
            # the preamble alone.
            #
            # Measured today on the live store, which still holds 20 such
            # blobs written before the clamp existed: three photographs served
            # resume@1792 against an atom at 1780..1798, no vision call in the
            # log, and three confident captions of "a plain white surface with
            # no discernible objects". A wrong answer served in 0.8s, which is
            # the worst thing this cache can do.
            #
            # On the EXPANDED pad stream exo reads, a mid-image depth remains
            # correct and this guard never fires: _regions there are ~1,200
            # pad tokens carrying real embeddings (media_regions.py deletes
            # safe_depth by name, and dad06fb records why). The two lines
            # differ in what a region IS, not in the rule.
            if any(r.start_pos < pos < r.end_pos for r in _regions):
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "inside_atom"})
                continue
            # ON A DEFERRED BACKEND, NOTHING PAST THE FIRST PICTURE IS
            # RESUMABLE: vLLM expands the atom, so a faxl position after it
            # names another place in the engine stream and vllm_backend
            # refuses the resume. The writer never stores one there
            # (_deferred_checkpoint_position); the reader agrees rather than
            # relying on entry_key never matching one (Halo-5w4.33).
            if (DEFERRED_CACHE and _regions
                    and pos > min(r.start_pos for r in _regions)):
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "after_image"})
                continue
            tpr0 = time.time()
            cand = index.identity_get(entry_key(qhash[pos], _regions, pos))
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if cand is None:
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "miss"})
                continue
            blob, cpos, tokf = cand
            # CONFIRM (belt and braces): token-compare the stored prefix.
            # A fail here is a hash collision or store corruption — logged loudly and
            # NEVER resumed. FIX D3 (CODE-TRUTH): a corrupted DEEP entry must not
            # forfeit a valid SHALLOWER hit — continue down the ladder; the request
            # only runs cold if no rung confirms.
            tcf0 = time.time()
            try:
                stored_prefix = json.load(open(tokf))
            except Exception:
                confirm_ms += (time.time() - tcf0) * 1000
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_unreadable"})
                continue
            if stored_prefix != list(ids[:pos]):
                confirm_ms += (time.time() - tcf0) * 1000
                confirm = "fail"
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_fail"})
                print(f"!! EXACT-TIER CONFIRM FAIL @pos={pos} phash={qhash[pos]} "
                      f"tok={os.path.basename(tokf)} — skipping this rung, trying "
                      f"shallower", flush=True)
                continue
            confirm = "pass"
            confirm_ms += (time.time() - tcf0) * 1000
            tbl0 = time.time()
            try:
                cache = CACHE.load(blob)
                blob_load_ms += (time.time() - tbl0) * 1000
            except Exception as e:
                # supersession/eviction race or corrupt blob: fall to shallower
                # rungs, never 500 (plan rev 5 §safety).
                blob_load_ms += (time.time() - tbl0) * 1000
                print(f"!! BLOB LOAD FAILED @pos={pos} ({e}) — trying shallower",
                      flush=True)
                cache = None
                confirm = None
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "load_fail"})
                continue
            if aud_probes is not None:
                aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                   "outcome": "confirm_pass"})
            # KEYED THE WAY THE INDEX IS KEYED -- entry_key, the tokens AND
            # the pictures. This is T-0008 on the mlx line: `index.add` stores
            # under entry_key while these three recorded the bare phash, and
            # for a text-only entry the two strings are identical, so the
            # mismatch is invisible until a prompt carries an image below the
            # checkpoint. Then every hit is recorded against a key the index
            # does not hold, a reused blob scores as never-used, and eviction
            # ranks the most-valuable blobs first. Measured on the exo store:
            # 62 real hits scoring 0, an eviction score of ~160,000 against
            # 645. The camera roll hides it (at 1780 no region starts below
            # pos, so entry_key == phash); an insurance prompt does not.
            _hit_key = entry_key(qhash[pos], _regions, pos)
            if not DEFERRED_CACHE:
                index.touch_resume(_hit_key)
                index.record_hit(_hit_key)     # blob++ (durable usage log)
            resume_pos = cpos
            resumed_blob = blob
            # The protect-set for this request's eviction sweep. It is matched
            # against index keys, which are entry_keys, so protecting the bare
            # phash would protect nothing and the blob just served could be
            # evicted by its own request's write.
            resumed_phash = _hit_key
            prefilled = len(ids) - cpos       # only the tail beyond the checkpoint
            cache_status = f"warm(exact,confirmed,resume@{cpos},delta={prefilled})"
            break
    if qhash is not None:
        cache_blocked_ms += (time.time() - tcb0) * 1000
    # ---- TRIM-ON-LOAD branch (KV plan B.2, TRIMMABLE models only): a
    # divergence at d below an anchor's depth P is served by loading the
    # anchor and trimming P-d tokens. Runs AFTER the exact ladder; engages
    # only when it beats the exact resume. EXEMPT from the ladder's
    # pos >= len-1 guard (a trim candidate legitimately has P >= len-1);
    # its own cap is d = min(D_raw, len-1) [F2].
    trim_rec = None
    if TRIMMABLE and not NOCACHE and qhash is not None:
        ttr0 = time.time()
        _d_raw_t = forkidx.deepest_shared(qhash, len(ids))
        d_t = min(_d_raw_t, len(ids) - 1)
        # THE TRIM TIER IS A SECOND DOOR INTO THE SAME POISON. Two photographs
        # share the preamble, the question AND the literal "<image:" prefix of
        # the atom, so deepest_shared lands a few tokens INSIDE it (~1782 of an
        # atom at 1780..1798). The byte confirm then passes -- those really are
        # the same ids -- and the trim resumes mid-atom, which is exactly the
        # state the reader guard above refuses. Same failure, different path:
        # no marker in the remainder, no vision call, a caption of the
        # preamble. Move back to the atom's start, which is a real boundary
        # and is also the position every photograph shares.
        if _n_images:
            d_t = _clear_of_atoms(d_t, _atom_spans(tok, ids))
        if d_t > resume_pos:
            cand = resolve_candidate(ANCHORS, forkidx.pos_hashes, qhash, d_t)
            if cand is not None:
                ent = index.identity_get(int(cand["phash"]))
                if ent is not None:
                    tblob, tP, ttokf = ent
                    tbytes = os.path.getsize(tblob)
                    gok, save_ms, load_ms = trim_economic_gate(
                        d_t, PREFILL_TPS["ewma"], tbytes,
                        LOAD_FIT["intercept_ms"], LOAD_FIT["slope_ms_per_gb"])
                    trim_rec = {"d_star": _d_raw_t, "d": d_t,
                                "owner": str(cand["owner"]),
                                "anchor_phash": cand["phash"],
                                "anchor_P": tP, "bytes": tbytes,
                                "tps": PREFILL_TPS["ewma"],
                                "save_ms": round(save_ms, 2),
                                "load_ms": round(load_ms, 2),
                                "gate_ok": gok, "outcome": None}
                    if not gok:
                        trim_rec["outcome"] = "gated_out"
                    else:
                        try:
                            stored_prefix = json.load(open(ttokf))
                        except Exception:
                            stored_prefix = None
                        if stored_prefix is None or                                 stored_prefix[:d_t] != list(ids[:d_t]):
                            trim_rec["outcome"] = "trim_confirm_fail"
                            print(f"!! TRIM CONFIRM FAIL @d={d_t} anchor@"
                                  f"{tP} — serving without trim", flush=True)
                        else:
                            try:
                                cache = CACHE.load(tblob)
                                # F8: trim returns the FIRST layer's count
                                # only — never asserted as a total.
                                CACHE.trim(cache, tP - d_t)
                                resume_pos = d_t
                                resumed_blob = tblob
                                # a trim serve is a real reuse of the anchor:
                                # blob++ and protect it from this request's
                                # eviction sweep, same as an exact resume
                                index.record_hit(int(cand["phash"]))
                                resumed_phash = int(cand["phash"])
                                prefilled = len(ids) - d_t
                                cache_status = (f"warm(trimmed,resume@{d_t},"
                                                f"from@{tP})")
                                trim_rec["outcome"] = "served"
                            except Exception as e:
                                trim_rec["outcome"] = "load_fail"
                                print(f"!! TRIM LOAD FAILED ({e}) — falling "
                                      f"back", flush=True)
        cache_blocked_ms += (time.time() - ttr0) * 1000
    if resume_pos == 0:
        cache = CACHE.make(model)
        cache_status = "nocache" if NOCACHE else "cold"
    if AUDIT:
        # #55: prefix-hash arrays for ALL traffic — computed here even for
        # NOCACHE/below-gate requests the lookup skipped (0.031 µs/token).
        _aud_qhash = qhash if qhash is not None else prefix_hashes(ids)
        AUDIT.request(req_id, prompt_len=len(ids), prompt_sha=prompt_hash,
                      prefix_hashes=_aud_qhash, workload=WORKLOAD)
        AUDIT.lookup(req_id, probes=aud_probes, resume_pos=resume_pos,
                     resume_phash=(qhash[resume_pos]
                                   if (resume_pos and qhash) else None),
                     trim=trim_rec)

    # ---- FORK DISCOVERY (plan rev 5): find the proven divergence position D*
    # and gate a checkpoint write there. Runs on EVERY request (warm or cold).
    fork_pos = fork_kind = fork_matched = None
    fork_gate = None
    fork_rec = None   # M0 audit: gate evaluation with RAW inputs (#56)
    fork_write_ms = 0.0
    index_maint_ms = 0.0
    fork_written = False
    _deferred_effects = []
    trim_matched = None   # extension-matched stream (chain identity, B.4)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tfd0 = time.time()
        D_raw = forkidx.deepest_shared(qhash, len(ids))
        _fd_probe0 = probe_rpc_ms   # identity_gets inside discovery counted there
        D = min(D_raw, len(ids) - 2)
        # An EXACT re-arrival (the whole query is already a stored stream) has
        # no divergence point inside it — nothing to fork.
        if 0 < D and D_raw < len(ids):
            kind, matched_stream = forkidx.classify(qhash, D, len(ids))
            if DEFERRED_CACHE:
                _deferred_effects.append((forkidx.observe_match, (qhash[D],)))
            else:
                forkidx.observe_match(qhash[D])
            if kind == "extension":
                trim_matched = matched_stream
            marginal = D - resume_pos   # deepest existing blob on this prefix
            tpr0 = time.time()
            d_star_stored = index.identity_get(qhash[D]) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            # B.3 [F7]: under TRIMMABLE the anchor dominates every fork
            # write — D* is still computed (the trim path needs it), fork
            # BLOB WRITES and their gates are suppressed entirely.
            if FORK and not TRIMMABLE and marginal > 0 and not d_star_stored:
                pb = blob_bytes_predicted(MODEL, D, OBSERVED["max_blob"])
                if FORK_GATES_OFF:
                    fork_ok, fork_gate = True, "gates-off(demo)"
                    fork_rec = {"kind": kind, "d_star": D,
                                "family": "gates_off", "ok": True}
                elif kind == "extension":
                    ch = forkidx.chain_for(matched_stream)
                    ewma_inc = ch["ewma_inc"] if ch else max(len(ids) - D, 1)
                    repaid_tail = len(ids) - resume_pos
                    fork_ok, saved_ms, wr_ms = extension_gate(
                        repaid_tail, ewma_inc, PREFILL_TPS["ewma"], pb,
                        NVME_BPS, FORK_TIME_RATIO)
                    fork_gate = (f"ext saved~{saved_ms:.0f}ms write~{wr_ms:.0f}ms "
                                 f"inc~{ewma_inc:.0f}")
                    fork_rec = {"kind": kind, "d_star": D, "family": "ext",
                                "pb": pb, "inc": ewma_inc,
                                "tps": PREFILL_TPS["ewma"],
                                "repaid": repaid_tail,
                                "kappa": forkidx.kappa,
                                "time_ratio": FORK_TIME_RATIO, "ok": fork_ok}
                    # head must track the conversation EVERY turn, forking or
                    # not, or supersession loses its ancestor (measured: 14.9 GB
                    # of un-superseded fork blobs before this line existed).
                    if DEFERRED_CACHE:
                        _deferred_effects.append((forkidx.migrate_chain,
                            (matched_stream, qhash[len(ids)], len(ids) - D)))
                    else:
                        forkidx.migrate_chain(matched_stream, qhash[len(ids)],
                                              len(ids) - D)
                else:
                    fork_ok, exp_extra, budget = divergence_gate(
                        pb, forkidx.kappa, marginal, model_slope(MODEL), FORK_AMORT)
                    fork_gate = (f"div k={forkidx.kappa:.2f} pred={pb/1e6:.0f}MB "
                                 f"budget={budget/1e6:.0f}MB")
                    fork_rec = {"kind": kind, "d_star": D, "family": "div",
                                "pb": pb, "kappa": forkidx.kappa,
                                "marginal": marginal,
                                "tps": PREFILL_TPS["ewma"],
                                "slope": model_slope(MODEL),
                                "amort": FORK_AMORT, "ok": fork_ok}
                if fork_ok:
                    # GRID SNAP: fork blobs obey the same rule as scheduled
                    # checkpoints — persist only at grid positions (raw D stays
                    # in fork_rec for the audit trail).
                    _D_grid = (D // SEG) * SEG
                    if _D_grid > 0:
                        fork_pos, fork_kind, fork_matched = _D_grid, kind, matched_stream
        _fd_block = (time.time() - tfd0) * 1000
        # discovery span excludes the identity_get RPC counted in probe_rpc_ms
        fork_discovery_ms += _fd_block - (probe_rpc_ms - _fd_probe0)
        cache_blocked_ms += _fd_block

    # Prefill ONLY the tail beyond the resume point, checkpointing at the
    # placements the selected STRATEGY returns (see store_lifecycle
    # STRATEGIES; FAXL_STRATEGY=grid restores the legacy geometric
    # schedule byte-identically). ScheduleContext is constructed AFTER hash
    # + lookup + fork discovery — everything in it is pre-arrival.
    _dstar = (D_raw if ((FORK or TRIMMABLE) and not NOCACHE
                        and qhash is not None) else 0)
    ctx = ScheduleContext(
        prompt_len=len(ids), resume_pos=resume_pos,
        d_star=_dstar,
        fork_kind=fork_kind,
        kappa=(forkidx.kappa if (FORK or TRIMMABLE) else 0.5),
        chain_ewma_inc=None,
        live_bytes=int(index.live_fork_gb() * 1e9) if FORK else 0,
        observed_max=OBSERVED["max_blob"],
        arrivals_at_dstar=0, model=MODEL,
        d_star_hash=(qhash[_dstar] if (_dstar and qhash) else None))
    # GRID SNAP (losslessness fix): states are only ever persisted at absolute
    # multiples of SEG, so a later resume re-enters the same canonical boundary
    # decomposition the cold path uses. Costs at most SEG-1 tokens of skip.
    #
    # EXCEPT WHEN THE WHOLE CONVERSATION IS SHORTER THAN ONE SEGMENT, which is
    # where this silently cached NOTHING. A chat turn is 65-250 tokens, the
    # tail anchor lands at prompt_len-3, and flooring that to a multiple of 256
    # gives 0 -- which `- {0}` then drops. Measured on the live proxy: a
    # 219-token conversation wrote `ckpt +0` and the next turn re-prefilled
    # from scratch, while a 393-token one wrote `ckpt +1`. So the console's own
    # chat -- the demo that exists to PROVE the cache works -- was the one
    # workload guaranteed to miss, for its first two or three turns.
    #
    # Below SEG the grid rule is VACUOUS, not relaxed. The cold path chunks
    # `nxt = min(pos + SEG - ((start+pos) % SEG), n)`, so for n < SEG it is a
    # SINGLE chunk [0..n] and there are no interior boundaries to re-enter. A
    # checkpoint at the anchor is therefore the only decomposition that exists
    # at that length, and a resume from it continues with start=anchor, whose
    # next boundary is min(anchor + SEG - anchor%SEG, n) = n -- exactly where
    # the cold path's single chunk ends. Same boundaries, same state.
    #
    # ABOVE SEG NOTHING CHANGES: once a grid position exists at or below the
    # anchor, the floor finds it and the sub-SEG branch never fires. This only
    # adds checkpoints where there were none.
    _raw = {p.pos for p in POLICY.decide(ctx)}
    placements = {(p // SEG) * SEG for p in _raw} - {0}
    # NOT ON A DEFERRED BACKEND. vLLM captures state only at its own chunk
    # ends (base + k*SEG; vllm_backend's reachability pre-check refuses any
    # other position BEFORE the engine runs), and a sub-SEG prompt is one
    # chunk ending at n, so a sub-SEG anchor would turn every short request
    # into a refusal rather than a cache miss.
    if not placements and len(ids) < SEG and not DEFERRED_CACHE:
        # GUARDED ON THE PROMPT, NOT JUST THE ANCHOR. At n=257 the anchor is
        # 254 (sub-SEG) but the COLD path already cuts at 256, so a checkpoint
        # at 254 would add a boundary the cold path never had -- warm
        # [254, 256, 257] against cold [256, 257] -- and that is precisely the
        # divergence the grid rule prevents. Only when the WHOLE prompt is
        # shorter than one segment is the cold path a single chunk with no
        # interior boundary to contradict. Verified for every n in 65..255.
        placements = {p for p in _raw if GATE_TOKENS <= p < SEG}
    # NEVER CUT A BOUNDARY THROUGH THE <image:digest> ATOM.
    #
    # THIS IS NOT safe_depth(). media_regions.py deletes that function by
    # name and is right to: on the EXPANDED stream exo hands faxl, one image
    # is ~1,200 pad tokens, a depth at 6144 is a real position carrying real
    # embeddings, and refusing such depths would leave the five constant
    # reference photographs of an insurance prompt permanently uncacheable.
    # That reasoning stands and applies unchanged to the exo line.
    #
    # The mlx atom stream is a different object. The picture is 18 TEXT tokens
    # spelling "<image:5d56f67f7b365ebd>", whose only purpose is to be swapped
    # for the model's <|vision_start|><|image_pad|><|vision_end|> marker in
    # backends.prefill_with_images. A depth in the middle of that is character
    # twelve of a hex digest. There is no state it could describe.
    #
    # And the swap is per chunk, so a boundary inside the atom destroys it.
    # Measured on a fresh store today, a checkpoint at 1792 against an atom
    # occupying 1780..1798:
    #
    #   vision SKIPPED: no marker in chunk [0:1792]
    #       tail='...three headings.\n<image:2cb8c7bd7a6'
    #   vision SKIPPED: no marker in chunk [1792:1800]
    #       tail='d5faf><|im_end|>\n<|im_start|>assistant'
    #
    # Neither half matches the marker regex, both text-prefill, the vision
    # tower never runs, and the model answers from the preamble alone -- with
    # no cache involved at all. 0820469 said this invariant held "by
    # construction" because the image is one atom; it is 18 tokens, and
    # nothing enforced it.
    #
    # The cost is bounded and small: a placement moves back at most 18
    # positions, and five images is 90 tokens of exclusion rather than the
    # 6,000 safe_depth() would have cost.
    _spans = _atom_spans(tok, ids) if _n_images else []
    if _spans:
        placements = {_clear_of_atoms(p, _spans) for p in placements} - {0}
        if DEFERRED_CACHE:
            # On the grid, and never past the first picture: a long question
            # after a photograph caches the pre-image prefix and is served,
            # instead of a checkpoint vllm_backend must refuse (Halo-5w4.33).
            placements = {_deferred_checkpoint_position(p, _spans, SEG)
                          for p in placements} - {0}
            if fork_pos is not None and fork_pos > _spans[0][0][0]:
                fork_pos = None
    if AUDIT:
        _cnt = _STRAT_KW.get("count_of")
        AUDIT.decision(req_id, ctx=asdict(ctx),
                       strategy={"name": STRATEGY, "config": STRAT_CFG},
                       placements=sorted(placements),
                       anchor_count=(_cnt(ctx) if callable(_cnt) else None),
                       fork=fork_rec)
        if fork_rec is not None and not fork_rec["ok"]:
            # register #56: REJECTED write decision with raw signals;
            # predicted_ev stays NULL until M3b's ev_model_version exists.
            AUDIT.lifecycle(req_id, "rejected_write",
                            phash=qhash[fork_rec["d_star"]],
                            pos=fork_rec["d_star"], signals=fork_rec)
    n = len(ids) - 1
    bounds = sorted(placements)
    if fork_pos is not None and fork_pos > resume_pos:
        # rev-3 fix: the fork write is exempt from the schedule; D* is inserted
        # into the prefill bounds so the state materializes exactly there.
        bounds = sorted(set(bounds) | {fork_pos})
    if not bounds or bounds[-1] != n:
        bounds.append(n)   # always prefill through to the end
    pos = resume_pos
    stored, deduped = 0, 0
    written_phashes = set()   # this request's writes: never its own victims
    tpf0 = time.time()
    # PICTURES GO IN ON THE FIRST CHUNK, ONCE.
    #
    # The vision tower turns pixels into embeddings that sit inline in the
    # prompt; running it again on a later chunk would splice the same picture
    # in twice. The ladder's own atom rule means an image never straddles a
    # boundary, so handing the images to the first chunk that is actually
    # prefilled is both sufficient and correct. A resumed request has the
    # image already folded into the checkpoint it resumed from -- that IS the
    # saving, ~6,929 tokens for one photograph on Qwen3-VL-4B.
    # Hand the pictures to EVERY chunk and let the backend decide: a chunk
    # whose text carries no <image:...> marker text-prefills itself, and the
    # one that does carries the vision work. Handing them only to the first
    # chunk broke as soon as the preamble grew long enough to checkpoint --
    # which it must, or nothing is ever cached.
    # ALWAYS offer the pictures, resumed or not.
    #
    # This used to be `if resume_pos == 0 else None`, on the reasoning that a
    # resumed request already had the image folded into its checkpoint. That
    # is true only when the checkpoint covers the image, and with a long
    # shared preamble it never does: the preamble checkpoints, the photograph
    # sits in the chunk AFTER it, and that chunk then prefilled the
    # <image:digest> text as literal tokens. The model dutifully read it back
    # -- "<image:a07175b9b60dc5b2>" -- instead of the receipt.
    #
    # The backend decides per chunk: no marker in this chunk's text means
    # text-prefill it, a marker means run the vision tower. That is the only
    # place with the information to make the call.
    deferred_records = []

    def publish_checkpoint(ki, kv, blob, pos, ph, tokf, is_fork_here, _ekey, wrote_ms, tck0):
        nonlocal upsert_ms, stored, fork_written, fork_write_ms, evict_ms, cache_blocked_ms
        tup0 = time.time()
        # Keyed on the tokens AND the pictures covered at this depth --
        # see exo_store.entry_key. Without it four different photographs
        # produced ONE store entry and photos 2-4 were discarded silently
        # (measured through the live stack), because write-once saw a
        # directory that already existed.
        # Immediate backends retain their existing best-effort write policy.
        # Deferred checkpoints were already committed as a strict batch after
        # generation/proof; failure there propagates and never reaches this block.
        if not DEFERRED_CACHE:
            try:
                index.add(ki, kv, blob, pos, phash=_ekey,
                          tok=tokf, fork=is_fork_here)
            except Exception as _e:  # noqa: BLE001 - see above
                LOG_FAILURES.append(
                    f"checkpoint write at {pos}: {type(_e).__name__}: {_e}")
                print(f"!! CHECKPOINT WRITE FAILED at {pos} "
                      f"({type(_e).__name__}: {_e}) — the reply is unaffected, "
                      f"but this prefix will not be cached", flush=True)
                try:
                    os.remove(blob)      # nothing points at it now
                except OSError:
                    pass
                cache_blocked_ms += (time.time() - tck0) * 1000
                return
        upsert_ms += (time.time() - tup0) * 1000
        blob_bytes = None
        try:
            blob_bytes = os.path.getsize(blob)
            _STORE_BYTES[0] += blob_bytes
            OBSERVED["max_blob"] = max(OBSERVED["max_blob"], blob_bytes)
        except OSError as e:
            # M0 loud-failure sweep: a blob we JUST wrote but cannot stat
            # is store corruption, not noise.
            LOG_FAILURES.append(f"stat fresh blob {os.path.basename(blob)}: {e}")
            print(f"!! FRESH BLOB UNSTATTABLE ({blob}: {e}) — store "
                  f"corruption suspected", flush=True)
        stored += 1
        # The protect-set is matched against INDEX keys, so it holds
        # entry_keys. Adding the bare phash protected nothing, and a
        # store at its cap could evict the blob this request had just
        # written, on the same request.
        written_phashes.add(_ekey)
        _kind = ("extension-fork" if (is_fork_here and fork_kind == "extension")
                 else "divergence-fork" if is_fork_here else "grid")
        # B.4: under TRIMMABLE the DEEPEST placement of this request is
        # the chain's live tail ANCHOR — registered per chain, and the
        # chain's previous anchor is superseded (write new -> re-point
        # index -> delete old; ordering per the shipped supersession
        # rule). Shallower placements (with_grid) stay 'grid'.
        _anchor_cid = None
        if TRIMMABLE and placements and pos == max(placements):
            _kind = "anchor"
            _anchor_cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                 trim_matched)
        if AUDIT:
            # per-band summary of the key ALREADY computed above —
            # c1..c4 features for the online learner, zero extra
            # model/reservoir work (None when this write is unkeyed)
            _esn = None
            if ki is not None:
                _esn = {}
                for _c in range(4):
                    _pairs = [(i - _c * WIDTH, v)
                              for i, v in zip(ki, kv)
                              if _c * WIDTH <= i < (_c + 1) * WIDTH]
                    _pairs.sort(key=lambda t: -abs(t[1]))
                    _esn[f"c{_c+1}"] = {
                        "nnz": len(_pairs),
                        "norm": round(sum(v * v
                                          for _, v in _pairs) ** 0.5,
                                      6),
                        "top": [[i, round(v, 5)]
                                for i, v in _pairs[:8]]}
            AUDIT.lifecycle(req_id, "stored", phash=ph, pos=pos,
                            ckpt_kind=_kind,
                            blob_id=os.path.basename(blob),
                            nbytes=blob_bytes, chain_id=_anchor_cid,
                            esn=_esn)
        if _anchor_cid is not None:
            tev0 = time.time()
            _old_anchor = ANCHORS.record_anchor(_anchor_cid, ph, pos,
                                                qhash[len(ids)])
            if _old_anchor is not None:
                index.remove_blob(int(_old_anchor))
                if AUDIT:
                    AUDIT.lifecycle(req_id, "superseded",
                                    phash=_old_anchor, by_phash=ph,
                                    chain_id=_anchor_cid)
            evict_ms += (time.time() - tev0) * 1000
        if is_fork_here:
            fork_written = True
            fork_write_ms += wrote_ms
            tev0 = time.time()
            if fork_kind == "extension":
                # SUPERSESSION: this chain's ancestor FORK blob dies (index
                # row first; grid blobs never touched). The head was migrated
                # to this stream during discovery.
                prev_phash = forkidx.set_chain_fork(qhash[len(ids)], ph, fork_pos)
                if prev_phash and prev_phash != ph:
                    index.remove_blob(prev_phash)
                    if AUDIT:
                        AUDIT.lifecycle(req_id, "superseded",
                                        phash=prev_phash, by_phash=ph)
            else:
                ev = index.evict_forks_over_cap(FORK_MAX_LIVE_GB)
                if ev:
                    print(f"fork LRU: evicted {len(ev)} blob(s) over "
                          f"{FORK_MAX_LIVE_GB} GB cap", flush=True)
                    if AUDIT:
                        for _v in ev:
                            AUDIT.lifecycle(req_id, "evicted", phash=_v)
            evict_ms += (time.time() - tev0) * 1000
        cache_blocked_ms += (time.time() - tck0) * 1000

    _pending_images = _req_images
    # One predicate for the whole serve: a user stop OR the client's deadline.
    # Built once rather than per chunk so the two cannot drift apart. It also
    # records which of them it saw when it first said stop, so the reply can say
    # who stopped it (Halo-5w4.44): the backend raises PrefillCancelled only
    # when this returned true.
    _prefill_stopped_by = []
    def _prefill_cancel():
        if req_id and _is_cancelled(req_id):
            _prefill_stopped_by.append(_cancel_cause(req_id))
            return True
        if deadline_mono and time.monotonic() > deadline_mono:
            _prefill_stopped_by.append("deadline")
            return True
        return False
    for end in bounds:
        if end <= pos:
            continue
        # A STOP LANDS IN PREFILL TOO, AT THE CHUNK BOUNDARY.
        #
        # The stop note above says prefill cannot be aborted. That is true
        # INSIDE one chunk -- a handful of large matmuls with no Python frame
        # to poll between them -- and false ACROSS chunks, which is where the
        # time actually goes on a long prompt. This loop already walks the
        # checkpoint schedule, so there is a clean frame between every chunk
        # and the flag costs one set lookup to read.
        #
        # Why it matters: a client that gives up (mavis' Esc, an HTTP timeout)
        # leaves the prefill running to completion holding _SERVE_LOCK, so the
        # resubmit queues behind the zombie and the user sees TWO rows in
        # flight, neither of them moving. Cancelling between chunks frees the
        # lock within one chunk's work instead of one full prefill.
        # (AM, 2026-10-03: "nothing is unkillable?")
        # A DEFERRED backend has only RECORDED the chunks so far -- nothing
        # executed and nothing will be published -- so it reports 0 tokens
        # prefilled rather than the recorded position.
        if _is_cancelled(req_id):
            _by = _cancel_cause(req_id)
            print(f"[faxl] prefill cancelled ({_by}) at {pos}/{n} tokens "
                  f"(req {req_id})", flush=True)
            raise _Cancelled(0 if DEFERRED_CACHE else pos, cause=_by)
        if deadline_mono and time.monotonic() > deadline_mono:
            # The caller said how long it would wait and that time is up.
            # Stopping here is the whole point: the client has already given
            # up, and carrying on would hold the serve lock against the
            # retry that is almost certainly already queued behind us.
            print(f"[faxl] prefill hit the client deadline at {pos}/{n} "
                  f"tokens (req {req_id})", flush=True)
            raise _Cancelled(0 if DEFERRED_CACHE else pos, cause="deadline")
        # The same predicate the decode loop uses, polled per SEGMENT inside
        # the backend. Between-chunk polling alone was not enough: the
        # checkpoint schedule is geometric, so a stop could sit behind 12k
        # tokens of final chunk.
        try:
            CACHE.prefill(ids[pos:end], cache, pos, images=_pending_images,
                          cancel=_prefill_cancel)
        except _PrefillCancelled as pc:
            if not _prefill_stopped_by:
                # The stop predicate never said stop, so there is no cause to
                # report; inventing one would be the mislabel this replaced.
                raise RuntimeError(
                    "the backend stopped the prefill (PrefillCancelled) though "
                    "the stop predicate it was given never fired") from pc
            at = pos + getattr(pc, "prefilled", 0)
            print(f"[faxl] prefill stopped ({_prefill_stopped_by[0]}) at "
                  f"{at}/{n} tokens (req {req_id})", flush=True)
            raise _Cancelled(at, cause=_prefill_stopped_by[0])
        pos = end
        # NOCACHE: still prefill (the model needs it) but write NO checkpoints.
        # Only checkpoint at a SCHEDULED position (not the ragged final end).
        # (The old refuse-writes-at-cap guard stood here; it starved live
        # traffic behind stale blobs — 21 consecutive hourly cold misses.
        # Writes now always land; scored eviction after the loop makes room.)
        is_fork_here = (fork_pos is not None and pos == fork_pos)
        # Unlicensed also stops WRITING: growing a store for a cache that can
        # never serve from it costs the customer disk for nothing.
        if not NOCACHE and _entitled and (is_fork_here or pos in placements):
            tck0 = time.time()
            ph = qhash[pos] if qhash else prefix_hashes(ids[:pos])[pos]
            # THE KEY THIS ENTRY IS STORED UNDER: tokens AND pictures. One
            # spelling, used by the dedup probe, the write, the protect-set
            # and the hit recorder alike -- see the hit site above for what
            # two spellings cost.
            _ekey = entry_key(ph, _regions, pos)
            # DEDUP, exact: if this precise prefix is already stored, skip the
            # write. Correct by construction (identity, not cosine similarity —
            # the old cosine dedup could merge different prefixes). The invariant
            # agent preamble is thus stored ONCE, ever, across all sessions.
            # FIX D4 (CODE-TRUTH): consult the SAME store the lookup uses (shared DB
            # first, local fallback) — dedup vs the local dict alone re-wrote blobs
            # that the shared DB already holds.
            #
            # PROBED BY entry_key, NOT THE BARE PHASH. Two different
            # photographs at the same offsets share a token prefix and so a
            # phash; probing that, the second photo's write saw the first
            # photo's entry, said "already stored", and nothing was kept --
            # the exact silent discard 14c3cec fixed on the exo store.
            tpr0 = time.time()
            dedup_hit = index.identity_get(_ekey) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if dedup_hit:
                deduped += 1
                if TRIMMABLE and placements and pos == max(placements):
                    # exact repeat: the anchor already exists — keep the
                    # chain registry pointed at it (same phash => no
                    # supersession; record_anchor returns None).
                    _cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                  trim_matched)
                    ANCHORS.record_anchor(_cid, ph, pos, qhash[len(ids)])
                if AUDIT:
                    AUDIT.lifecycle(req_id, "deduped", phash=ph, pos=pos,
                                    ckpt_kind=("extension-fork" if (is_fork_here and fork_kind == "extension")
                                               else "divergence-fork" if is_fork_here
                                               else "grid"))
                cache_blocked_ms += (time.time() - tck0) * 1000
                continue
            # TOKEN PREFIX: content-addressed, write-once (same hash = same file).
            ttk0 = time.time()
            tokf = os.path.join(TOKENS_DIR, f"{ph}.json")
            if not DEFERRED_CACHE:
                _write_checkpoint_tokens(tokf, ids[:pos])
            tokfile_ms += (time.time() - ttk0) * 1000
            # SIMILARITY KEY: only at >= KEY_MIN_TOKENS (c4 alive; 4-band key
            # complete). Below that the entry is exact-tier-only — the lookup
            # doesn't need a key, and a 3-band key is measured-bad as an embedding.
            ki = kv = None
            # Fork blobs are EXACT-TIER-ONLY (rev 4): the key would be dead
            # weight (~seconds at depth) — skip regardless of KEY_MIN_TOKENS.
            #
            # OFF THE CRITICAL PATH (AM 2026-10-23). The key reads the WHOLE
            # prefix, so it costs ~171 ms per 1000 cached tokens -- a median
            # 10.8 s on a 70k resume, 80.6% of time-to-first-token, paid
            # BEFORE generation starts. It buys this request nothing: the
            # ladder decides the hit, and the design has said since 2026-08
            # that similarity keys "serve retrieval and near-miss telemetry,
            # never the hit decision". The checkpoint is therefore written
            # exact-tier-only (idx=None, the same shape every sub-1025 entry
            # already uses) and the key is computed after the first token and
            # attached then, so the UMAP/analytics corpus still accrues in
            # full. KEY_DEFER=0 restores the old inline behaviour.
            if pos >= KEY_MIN_TOKENS and not is_fork_here:
                if KEY_DEFER:
                    _key_backlog.append((_ekey, ids[:pos]))
                else:
                    tek0 = time.time()
                    ki, kv = probe.key(ids[:pos])
                    esn_key_ms += (time.time() - tek0) * 1000
            # BLOB NAME: uuid, NOT index.rows — on restart _reload() skips rows whose
            # blob is gone so `rows` shrinks, and a "{rows}.safetensors" name would
            # then collide with a filename a still-live meta row points at (overwrite
            # + two rows aiming at one file). uuid is collision-free across restarts.
            # WHICH POOL. A prompt that carried a picture writes to the photo
            # store, everything else to the general one. _n_images is already
            # computed for this request (it decides atom spans and the vision
            # call), so the split costs nothing and needs no new signal.
            _pool = PHOTO_BLOB_DIR if _n_images else BLOB_DIR
            blob = os.path.join(_pool, f"ckpt_{uuid.uuid4().hex}.safetensors")
            tw0 = time.time()
            CACHE.save(blob, cache)
            wrote_ms = (time.time() - tw0) * 1000
            ckpt_write_ms += wrote_ms   # grid writes measured AND KEPT (phase 0)
            record = (ki, kv, blob, pos, ph, tokf, is_fork_here, _ekey, wrote_ms, tck0)
            if DEFERRED_CACHE:
                deferred_records.append(record)
            else:
                publish_checkpoint(*record)
    if DEFERRED_CACHE:
        # The only GPU call executes the complete plan and proves every
        # restore/capture before any checkpoint row, statistic or hit is exposed.
        records = [dict(idx=r[0], val=r[1], blob_path=r[2], cpos=r[3],
                        phash=r[7], tok=r[5], fork=r[6]) for r in deferred_records]
        out_ids, t_first_tok = _execute_deferred_checkpoints(
            CACHE, index, ids, cache, max_tokens, records)
        for effect, args in _deferred_effects:
            effect(*args)
        for record in deferred_records:
            publish_checkpoint(*record)
        if resumed_phash is not None:
            index.touch_resume(resumed_phash)
            index.record_hit(resumed_phash)
    pf_secs = time.time() - tpf0
    # STORE-WIDE scored eviction (AM 2026-09-01): after this request's writes
    # land, shrink back under the cap — oldest unpopular blobs first (score =
    # time-since-last-hit / (1 + hits)). Replaces the refuse-writes guard.
    # Sits AFTER pf_secs so housekeeping never pollutes the prefill timing.
    if not NOCACHE and stored:
        # ORPHANS FIRST, AND ONLY AFTER A WRITE LANDED. A blob on disk that no
        # index entry points at counts against the cap (which is measured from
        # the directory) and cannot be evicted (which walks the index), so the
        # bytes are lost for good -- 0.83 GB of an 8.0 GB cap on the owner's
        # store before this existed. Sweeping here, rather than on a timer,
        # means the live set was just confirmed good by a successful add.
        tsw0 = time.time()
        _orphans, _freed = index.sweep_orphans()
        evict_ms += (time.time() - tsw0) * 1000
        if _orphans:
            print(f"store: {_orphans} orphan blob(s) removed, "
                  f"{_freed/1e9:.2f} GB reclaimed — now "
                  f"{_STORE_BYTES[0]/1e9:.1f} GB across both pools",
                  flush=True)
    # EACH POOL AGAINST ITS OWN CAP. Sweeping the sum would let a full photo
    # store evict text entries and vice versa, which is the starvation the
    # split exists to prevent.
    if not NOCACHE:
        _protect = set(written_phashes)
        if resumed_phash is not None:
            _protect.add(resumed_phash)
        tev0 = time.time()
        def _report(label, v, d, cap):
            print(f"{label} store eviction: {len(v)} blob(s) "
                  f"removed (oldest-unpopular first) — "
                  f"{index.pool_bytes(d)/1e9:.1f} GB of "
                  f"{cap} GB cap", flush=True)
        _victims = index.trim_pools(
            ((BLOB_DIR, STORE_CAP_GB, "general"),
             (PHOTO_BLOB_DIR, PHOTO_CAP_GB, "photo")),
            protect=_protect, report=_report)
        evict_ms += (time.time() - tev0) * 1000
        if _victims:
            print(f"store eviction: {len(_victims)} blob(s) removed "
                  f"(oldest-unpopular first) — {_STORE_BYTES[0]/1e9:.1f} GB "
                  f"of {STORE_CAP_GB} GB cap", flush=True)
            if AUDIT:
                for _v in _victims:
                    AUDIT.lifecycle(req_id, "evicted", phash=_v)
    pf_tokens = pos - resume_pos
    if not DEFERRED_CACHE and pf_tokens > 512 and pf_secs > 0.5:   # update only on meaningful prefills
        PREFILL_TPS["ewma"] = 0.7 * PREFILL_TPS["ewma"] + 0.3 * (pf_tokens / pf_secs)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tas0 = time.time()
        index_maint_ms += forkidx.add_stream(ids, qhash)
        cache_blocked_ms += (time.time() - tas0) * 1000
    if stored or deduped:
        cache_status += f" [ckpt +{stored}/dedup {deduped}]"
    if fork_pos is not None:
        cache_status += f" [fork {fork_kind}@{fork_pos}{'+w' if fork_written else ''}]"
    prefill_skipped = resume_pos       # tokens we did NOT re-prefill thanks to resume
    if _settle:
        # Prefill-only: the answer was already delivered by the request that
        # spawned this settle. Everything below the write loop -- TOTALS, the
        # metrics JSONL, AUDIT.outcome, telemetry completion -- is skipped so
        # the console and the ROI log never count the proxy's own traffic.
        # (Never reached on a deferred backend: chat() refuses a settle there,
        # because its single execution generates; see SETTLE.)
        _sdt = time.time() - t0
        # The audit trail stays self-consistent: the writes above logged
        # lifecycle events under this req_id, so the trail gets its outcome
        # row too (honest store work, just never TOTALS/metrics/telemetry).
        if AUDIT:
            AUDIT.outcome(req_id, hit=resume_pos > 0, resume_pos=resume_pos,
                          prompt_len=len(ids), paid=pos - resume_pos,
                          stored=stored, deduped=deduped,
                          fork_written=fork_written, confirm=confirm,
                          wall_s=round(_sdt, 3), ttft_ms=None,
                          cache_blocked_ms=round(cache_blocked_ms, 2))
        print(f"[settle] {len(ids)} tok | resume@{resume_pos} "
              f"paid {pos - resume_pos} | ckpt +{stored}/dedup {deduped} "
              f"| {_sdt:.2f}s | lib={index.rows}", flush=True)
        return jsonify({"faxl": {"settle": True, "cache": cache_status,
                                 "ckpts_written": stored,
                                 "ckpts_deduped": deduped}})
    if not DEFERRED_CACHE:
        # STREAM AND STOP. _stream_cb is set by the SSE path (below) when the
        # client asked for stream:true; cancel is always wired, because a stop
        # must work whether or not the reply is being streamed.
        _sink = _STREAM_SINK.get(req_id) if req_id else None
        out_ids, t_first_tok = CACHE.generate(
            ids, cache, max_tokens,
            on_token=(_sink.put if _sink is not None else None),
            # The decode loop polls this once per token, so a deadline lands
            # within one token just as a stop does -- and the same predicate
            # covers both, rather than two mechanisms that can disagree.
            cancel=((lambda: (_is_cancelled(req_id)
                              or bool(deadline_mono
                                      and time.monotonic() > deadline_mono)))
                    if req_id else
                    (lambda: bool(deadline_mono
                                  and time.monotonic() > deadline_mono))
                    if deadline_mono else None))
        _was_cancelled = _is_cancelled(req_id)
    else:
        # A DEFERRED backend already ran its ONE execution above
        # (_execute_deferred_checkpoints): no token callback and no cancel
        # predicate reach that call, so the reply arrives whole (the SSE path
        # sends it in its final frame) and a stop or deadline that arrived
        # during it did not interrupt anything. Reporting such a reply as
        # cancelled would describe something that did not happen.
        _was_cancelled = False
    # Who stopped a cancelled decode, read before the flag is cleared: the faxl
    # block says it, as a prefill stop's does (Halo-5w4.44).
    _cancelled_by = _cancel_cause(req_id) if _was_cancelled else None
    _clear_cancel(req_id)
    text = tok.decode(out_ids)
    # The decode span ends at the last token. A deferred backend's single
    # execution also proved and published checkpoints, and the store sweep
    # and eviction ran after it, so a clock read here would charge storage
    # work to generation: its decode span is left unmeasured (None).
    t_end = None if DEFERRED_CACHE else time.time()
    # SIMILARITY KEYS, NOW THE REPLY IS OUT. Deferred from the write path (see
    # the write site): the key is an analytics/retrieval artifact the serving
    # path never reads, and building it over a 70k-token prefix cost ~10.8 s of
    # time-to-first-token. Measured AFTER t_end so the decode span stays honest,
    # and reported as esn_key_ms exactly as before -- the work still shows up in
    # the request's cost, it just no longer sits in front of the first token.
    # A failure here loses one embedding, never the answer.
    for _kph, _kids in _key_backlog:
        try:
            tek0 = time.time()
            _ki, _kv = probe.key(_kids)
            esn_key_ms += (time.time() - tek0) * 1000
            index.attach_key(_kph, _ki, _kv)
        except Exception as _e:  # noqa: BLE001
            LOG_FAILURES.append(f"similarity key {_kph}: {type(_e).__name__}: {_e}")
            print(f"!! SIMILARITY KEY FAILED ({type(_e).__name__}: {_e}) — the "
                  f"reply and the cache entry are unaffected; this checkpoint "
                  f"stays exact-tier-only (no analytics row)", flush=True)
    _key_backlog.clear()
    hit = resume_pos > 0
    if EVIDENCE is not None:
        _engine_evidence = getattr(BACKEND, "last_evidence", None)
        if _engine_evidence is not None:
            _engine_evidence = dict(_engine_evidence)
            for _field in ("engine_prompt_ids", "raw_engine_ids", "effective_preparse_ids"):
                _engine_evidence[_field] = _product_evidence.ids_record(_engine_evidence[_field])
            for _field in ("raw_engine_text", "effective_preparse_text"):
                _engine_evidence[_field] = _product_evidence.bytes_record(_engine_evidence[_field].encode("utf-8"))
        # Snapshot while holding _SERVE_LOCK, before another request clears the
        # engine's report; API/engine joining never reads later mutable state.
        _evidence_note(observations=_product_evidence.snapshot({
            "engine": _engine_evidence,
            "gen_timing": getattr(BACKEND, "gen_timing", None),
            "connector_report": getattr(BACKEND, "last_report", None),
            "preparse_ids": _product_evidence.ids_record(out_ids),
            "preparse_text": _product_evidence.bytes_record(text.encode("utf-8")),
            "confirmed": confirm, "hit": hit, "resume_pos": resume_pos,
            "resumed_blob": resumed_blob, "published_checkpoints": stored,
            "cache_status": cache_status, "namespace_digest": NS.digest_hex(),
            "namespace_hash": NS.ns_hash(), "library_rows": index.rows}))
    dt = time.time() - t0
    ttft_ms = (t_first_tok - treq0) * 1000 if t_first_tok else None
    # DECODE SPAN, MEASURED FROM THE FIRST TOKEN. Not wall-minus-prefill: t0 is
    # taken before the cache lookup, hash build, confirm and blob load, so
    # dt - prefill swept all of cache_blocked_ms into "decode" and understated
    # generation speed on every warm request -- the warmer the hit, the worse
    # the lie. The honest span is first token -> last token, which is also what
    # a client timing its own stream sees, so the console and a harness can be
    # compared rather than argued about.
    #
    # len(out_ids) - 1 because the first token's cost is TTFT, already reported
    # separately; counting it here would charge decode for the prefill.
    decode_ms = None
    if t_end is not None and t_first_tok and len(out_ids) >= 2:
        decode_ms = max((t_end - t_first_tok) * 1000.0, 0.0)

    # PARSE TOOL CALLS — family dispatch (the last Granite-coupled seam, now dual):
    #  Granite: <tool_call>{"name":..,"arguments":{..}}</tool_call> (text tags).
    #  Kimi:    <|tool_calls_section_begin|> <|tool_call_begin|> functions.NAME:IDX
    #           <|tool_call_argument_begin|> {json} <|tool_call_end|> ... — special
    #           tokens, VERIFIED to survive tok.decode round-trip, so text-level
    #           parsing is sound. Lift into OpenAI `tool_calls`; content is what
    #           remains outside the call markup.
    # REASONING FIRST, then tool calls from what is left: a call the model
    # drafted while thinking is not a call it made.
    reasoning, _answer = client_compat.split_reasoning(text, _think_open)
    tool_calls, content = parse_tool_calls(_answer)
    # ARGUMENTS TO THE TYPES THE CLIENT DECLARED. Qwen's <parameter=k>v</...>
    # has no types, so every value parsed as a string ("timeout": "120").
    # The tool schema in the request says what each should be.
    tool_calls = client_compat.fit_tool_calls(tool_calls, tools)
    _sniff("response", {
        "raw_model_text": text,          # exactly what the model emitted (incl. any <think>)
        "parsed_tool_calls": tool_calls, # what the parser lifted into OpenAI form
        "content": content,
        "cache_status": cache_status,
    })
    msg = {"role": "assistant", "content": content or None}
    if reasoning:
        msg["reasoning_content"] = reasoning
    # FINISH REASON, AND IT MUST BE HONEST. This said "stop" unconditionally,
    # so a reply CUT OFF at max_tokens was reported as a reply that finished --
    # indistinguishable, to any client, from the model having nothing more to
    # say. An agent harness then acts on half an answer, or on a tool call
    # truncated mid-JSON, with nothing to tell it otherwise. OpenAI's contract
    # is "length" when the cap stopped generation, and clients rely on it to
    # decide whether to continue.
    #
    # The test: generation ran to the cap. A model that stopped on its own
    # emits an eos and comes back short.
    # A CANCELLED REPLY IS NOT A FINISHED ONE. "stop" would tell the client the
    # model chose to end there, and the text is a real partial answer, so
    # nothing else in the response reveals that a person interrupted it.
    # OpenAI has no code for this, so the standard "cancelled" is reported in
    # faxl's own block and finish_reason stays within the values clients parse.
    #
    # THE CAP HERE IS THE CLIENT'S, AND A BACKEND MAY STOP SOONER (Halo-5w4.40).
    # vLLM clamps the budget to the room left in its context window
    # (vllm_backend.generate), so a reply the window cut short came back under
    # the client's cap -- or under FAXL_MAX_TOKENS_DEFAULT when the client sent
    # none -- and was reported "stop", as if the model chose to end there.
    # OpenAI's "length" covers both bounds. The window is the backend's, and a
    # picture's prompt is longer there than `ids`, so the proxy does not work
    # it out: a backend that knows declares the METHOD last_finish_reason(),
    # whose "length" means a length bound (the request's cap or the context
    # window) ended the generate that just ran on it. Such a backend clears its
    # answer at the start of every generate, so a failed or unset one cannot
    # carry an earlier request's "length" into this one (this all runs under
    # _SERVE_LOCK). Looked up as a method, as context_window is, so a failure
    # inside it raises instead of reading as "not reported". Only "length"
    # changes anything; a backend without it (mlx, and exo, which forwarded
    # above) gets the cap rule alone, as before.
    finish = ("length" if len(out_ids) >= max_tokens
              else "stop")
    _reported = getattr(CACHE, "last_finish_reason", None)
    if _reported is not None and _reported() == "length":
        finish = "length"
    if _was_cancelled:
        finish = "stop"
    if tool_calls:
        msg["tool_calls"] = tool_calls
        # tool_calls wins only when the call is COMPLETE. A truncated call
        # parses to nothing useful, and saying "tool_calls" about it would be
        # the same lie one level up.
        if finish != "length":
            finish = "tool_calls"

    # ---- ROI instrumentation (durable JSONL, one line per request) ----
    TOTALS["requests"] += 1
    TOTALS["prompt_tokens"] += len(ids)
    TOTALS["prefill_paid"] += prefilled          # tokens actually prefilled this req
    TOTALS["prefill_skipped"] += prefill_skipped  # tokens skipped via resume
    TOTALS["hits"] += 1 if hit else 0
    TOTALS["ckpts_written"] += stored
    TOTALS["ckpts_deduped"] += deduped
    TOTALS["wall_s"] += dt
    tot_prompt = TOTALS["prompt_tokens"] or 1
    rec = {
        "ts": t0, "mode": "nocache" if NOCACHE else "cache",
        # ns identity on EVERY metrics row (KV plan rev 4.1, day one)
        "ns_digest": NS.digest_hex(), "ns_hash": NS.ns_hash(),
        "trimmable": TRIMMABLE,
        "prompt_tokens": len(ids), "out_tokens": len(out_ids),
        "prefill_paid": prefilled, "prefill_skipped": prefill_skipped,
        "hit": hit, "resume_pos": resume_pos,
        # EXACT TIER: hit tier + per-hit confirm outcome + the O(N) hash cost.
        "hit_tier": (("trim" if (trim_rec and trim_rec.get("outcome") == "served")
                      else "exact") if hit else None), "confirm": confirm,
        # KV plan B.2 metrics: trim outcome + costs (gated-out candidates
        # logged with predicted costs, [F5])
        "trim_gate": (trim_rec or {}).get("outcome"),
        "trim_from": ((trim_rec or {}).get("anchor_P")
                      if (trim_rec or {}).get("outcome") == "served" else None),
        "trim_tokens": ((trim_rec["anchor_P"] - trim_rec["d"])
                        if (trim_rec and trim_rec.get("outcome") == "served")
                        else None),
        "hash_build_ms": round(hash_build_ms, 2),
        # REPRO DEBUG: exact prompt id + which blob was loaded, to tell apart
        # "different tail" from "different blob at same cpos" from "true non-determinism".
        "prompt_hash": prompt_hash,
        "resumed_blob": os.path.basename(resumed_blob) if resumed_blob else None,
        "ckpts_written": stored, "ckpts_deduped": deduped,
        "confirm_ms": round(confirm_ms, 2),
        # Phase-0 cache-path spans: cache_blocked_ms is the INCLUSIVE outer
        # accumulator (all cache work in the serialised handler, never
        # prefill/decode); the children below are EXCLUSIVE; residual_ms is
        # the unexplained remainder. index_maint_ms is now add_stream only
        # (D* discovery moved to fork_discovery_ms). ttft_ms is measured
        # directly: request start -> first decoded token.
        "cache_blocked_ms": round(cache_blocked_ms, 2),
        # the extension gate's own EWMA state, recorded so future traces
        # calibrate the simulator exactly (no reconstruction needed)
        "prefill_tps_ewma": round(PREFILL_TPS["ewma"], 1),
        "probe_rpc_ms": round(probe_rpc_ms, 2),
        "blob_load_ms": round(blob_load_ms, 2),
        "fork_discovery_ms": round(fork_discovery_ms, 2),
        "ckpt_write_ms": round(ckpt_write_ms, 1),
        "tokfile_ms": round(tokfile_ms, 2),
        "esn_key_ms": round(esn_key_ms, 2),
        "upsert_ms": round(upsert_ms, 2),
        "evict_ms": round(evict_ms, 2),
        "residual_ms": round(cache_blocked_ms - (
            hash_build_ms + probe_rpc_ms + confirm_ms + blob_load_ms +
            fork_discovery_ms + ckpt_write_ms + tokfile_ms + esn_key_ms +
            upsert_ms + evict_ms + index_maint_ms), 2),
        "ttft_ms": round(ttft_ms, 1) if ttft_ms is not None else None,
        # Generation speed, the number a client sees timing its own stream.
        # None rather than 0 when unmeasurable, so nothing renders a fake zero.
        "decode_ms": round(decode_ms, 1) if decode_ms is not None else None,
        "decode_tps": (round((len(out_ids) - 1) / (decode_ms / 1000.0), 1)
                       if decode_ms and decode_ms > 0 else None),
        "fork_pos": fork_pos, "fork_kind": fork_kind,
        "fork_gate": fork_gate, "fork_ckpt_written": fork_written,
        "fork_write_ms": round(fork_write_ms, 1),
        "index_maint_ms": round(index_maint_ms, 2),
        "live_fork_gb": round(index.live_fork_gb(), 3),
        "tool_calls": len(tool_calls), "n_tools_offered": len(tools) if tools else 0,
        "wall_s": round(dt, 3), "cache_status": cache_status,
        # running ROI: fraction of ALL prefill tokens we've skipped so far
        "cum_prefill_skipped": TOTALS["prefill_skipped"],
        "cum_prefill_paid": TOTALS["prefill_paid"],
        "cum_skip_frac": round(TOTALS["prefill_skipped"] / (TOTALS["prefill_skipped"] + TOTALS["prefill_paid"] or 1), 4),
        "cum_wall_s": round(TOTALS["wall_s"], 1), "lib_size": index.rows,
    }
    _append_metrics(rec)
    if AUDIT:
        AUDIT.outcome(req_id, hit=hit, resume_pos=resume_pos,
                      prompt_len=len(ids), paid=prefilled, stored=stored,
                      deduped=deduped, fork_written=fork_written,
                      confirm=confirm, wall_s=rec["wall_s"],
                      ttft_ms=rec["ttft_ms"],
                      cache_blocked_ms=rec["cache_blocked_ms"])

    # TELEMETRY COMPLETION — async, off the hot path; mirrors AUDIT.outcome. Only
    # HONESTLY MEASURED spans are set (proto3 can't tell 0 from unset, so an unset
    # span means "not measured", never a plausible zero). saved = cold − warm is
    # left to the aggregator with its basis; here cold is ESTIMATED from the
    # measured prefill EWMA (a global rate — NOT a paired twin).
    # Tenant for telemetry AND the speculator harvest below, so it is bound
    # whether or not telemetry is on (FAXL_TELEMETRY=0 used to reach the
    # harvest with it unassigned: UnboundLocalError after the answer existed).
    _tenant = licence.status().get("customer", "") or os.environ.get(
        "FAXL_TENANT", "")   # "" = unattributed; never a fabricated default
    if TELEMETRY is not None:
        _pb = _tel.pb
        # cold counterfactual: what a cold prefill of the skipped tokens would
        # have cost, at the measured prefill rate. ESTIMATED (rate, not twin).
        # On a MISS prefill_skipped==0, so cold-est==0 and saved==0 by
        # construction — the aggregator needs no miss special-case.
        _cold_ms = (prefill_skipped / max(PREFILL_TPS["ewma"], 1e-6)) * 1000.0
        _cost = _pb.Cost(
            prompt_tokens=len(ids), prefill_paid=prefilled,
            prefill_skipped=prefill_skipped, warm_wall_ms=dt * 1000.0,
            cold_basis=_pb.ESTIMATED, cold_prefill_ms_est=_cold_ms,
            estimator_id="prefill_tps_ewma",
            estimator_version=str(round(PREFILL_TPS["ewma"], 1)))
        if ttft_ms is not None:      # mlx: present; some backends omit → unset
            _cost.has_ttft = True
            _cost.ttft_ms = ttft_ms
        _tim = _pb.Timings(
            hash_build_ms=hash_build_ms, confirm_ms=confirm_ms,
            blob_load_ms=blob_load_ms, prefill_ms=pf_secs * 1000.0,
            # 0.0 means "not measurable on this request" (a one-token reply, or
            # a backend with no first-token timestamp), which the proto's
            # default already means. The aggregator renders that as "--".
            decode_ms=(decode_ms if decode_ms is not None else 0.0),
            cache_blocked_ms=cache_blocked_ms)
        _tier = (_pb.EXACT if hit and rec["hit_tier"] == "exact"
                 else _pb.TRIM if hit and rec["hit_tier"] == "trim"
                 else _pb.HIT_TIER_UNSPECIFIED)
        # Real ladder WALK (not a one-rung reconstruction): the probes actually
        # tried, deepest-first, each with its confirm outcome — powers the
        # request-detail explainability view (§5.3). phash carried as a
        # tenant-keyed hash (never raw).
        _confirm_map = {"confirm_pass": _pb.CONFIRM_PASS,
                        "confirm_fail": _pb.CONFIRM_FAIL}
        _ladder = []
        for _p in aud_probes:
            _lp = _pb.LadderProbe(
                position=_p["pos"],
                confirm=_confirm_map.get(_p["outcome"],
                                         _pb.CONFIRM_OUTCOME_UNSPECIFIED))
            _lp.rung_key.CopyFrom(TELEMETRY.keyer.keyed_hash(
                _tenant, _p["phash"].encode()))
            _ladder.append(_lp)
        TELEMETRY.emit_completion(
            req_id, tenant=_tenant,
            outcome=(_pb.HIT if hit else _pb.MISS), resume_pos=resume_pos,
            hit_tier=_tier, ladder=_ladder, cost=_cost, out_tokens=len(out_ids),
            timings=_tim, prompt_content=prompt_hash.encode(),
            project=_project_tag(request.headers.get("X-Faxl-Project")
                                 or body.get("faxl_project")))

    print(f"[{cache_status}] {len(ids)} tok | paid {prefilled} skip {prefill_skipped} "
          f"| {len(tool_calls)} tool_call(s) | {dt:.2f}s | lib={index.rows} "
          f"| cum_skip={rec['cum_skip_frac']*100:.0f}%", flush=True)
    # TURN SETTLE: now that the reply exists, get it into the store so the
    # NEXT turn starts warm instead of the one after. Text path only (_n_images
    # settles would re-run the vision tower; their atoms already checkpoint on
    # the write path above). Tool-call turns settle too: the next real prompt
    # extends history + this assistant message, tool results and all.
    # NOT on a deferred backend: see the refusal in chat().
    if (SETTLE and not DEFERRED_CACHE and not _settle and not NOCACHE
            and _entitled and not _n_images
            and (msg.get("content") or msg.get("tool_calls"))):
        _spawn_settle(messages, msg, tools=tools,
                      think=tmpl_kw.get("enable_thinking"))
    # SPECULATOR LEARNING. Prompt and output both: the prompt is where agentic
    # repetition lives, and it is a cache of the user's own content either way.
    # Settle requests are excluded -- they re-send text already harvested here,
    # which would double-count it. After the answer exists, so no user waits on
    # it; the table writes itself to disk every tenth harvest.
    if not _settle:
        _speculator_harvest(ids, out_ids, _tenant)
    _faxl = {"cache": cache_status, "prefilled_tokens": prefilled,
             "library_size": index.rows, "latency_s": dt,
             # The one place a client can tell an interrupted reply from a
             # finished one: finish_reason stays "stop" so stock OpenAI
             # clients keep parsing, and this says what really happened.
             "cancelled": bool(_was_cancelled)}
    if _was_cancelled:
        # ...and, as for a stop during prefill, where and by whom (Halo-5w4.44).
        # A reply nobody stopped keeps exactly the block above.
        _faxl.update(phase="decode", cancelled_by=_cancelled_by)
    return jsonify({
        "id": (completion_id or getattr(g, "evidence_api_id", None)
               or f"chatcmpl-{uuid.uuid4().hex[:12]}"),
        "object": "chat.completion",
        "created": int(t0),
        "model": MODEL,
        "choices": [{"index": 0, "message": msg, "finish_reason": finish}],
        "usage": {"prompt_tokens": len(ids), "completion_tokens": len(out_ids),
                  "total_tokens": len(ids) + len(out_ids)},
        "faxl": _faxl,
    })


def _agent_guide():
    """Where an agent finds out what it can do here. Every other way in
    (/health, /v1/models, /, /llms.txt) points at this one text, because the
    agent view of the console is the full control surface and nothing
    announced it: an agent asked to add a model never looked there."""
    o = request.host_url.rstrip("/")
    return {"console": o + "/console?mode=agent", "guide": o + "/llms.txt"}


_LLMS_TXT = """# faxl

faxl is a prefill cache in front of the model running on this machine. It
serves an OpenAI-compatible API and has a console that you can drive.

API:      {o}/v1   (any API key string works)
Console:  {o}/console?mode=agent   <- start here: every page has an agent view
          that lists the commands for what it controls.

Console pages (add ?mode=agent, or ?format=json or ?format=text):
  {o}/console/models      models on this machine; switch the model being served
  {o}/console/status      what is running, licence, cache
  {o}/console/configure   settings, including the Hugging Face token
  {o}/console/connect     client configs (Hermes Agent, MiniMax Code, OpenAI)
  {o}/console/apps        Voice to text, Tag your photos
  {o}/console/requests    the request log
  {o}/console/licence     licence

Switch the model:   read {o}/console/models?mode=agent for the exact call.
Add a model from Hugging Face:
  POST {o}/api/models/fetch        {{"model_id": "org/name"}}
  GET  {o}/api/models/fetch/status progress, or the reason it stopped
  A gated repo needs the Hugging Face token (console/configure). When the
  download finishes the model appears in /v1/models and can be switched to.
  Switching restarts faxl (about a minute); the cache survives.

faxl listens on port 8767 only. Do not start a second copy.
"""


@app.route("/llms.txt", methods=["GET"])
def llms_txt():
    return Response(_LLMS_TXT.format(o=request.host_url.rstrip("/")),
                    mimetype="text/plain")


@app.route("/", methods=["GET"])
def root():
    # A browser wants the console; anything else wants the guide.
    if "text/html" in (request.headers.get("Accept") or ""):
        return redirect("/console")
    return llms_txt()


@app.route("/v1/models", methods=["GET"])
def models():
    """Every model this machine can serve, not just the resident one.

    A client that may ASK for a model by name needs the catalogue, or it is
    guessing at strings. The resident one is marked, so a caller that only
    cares what is loaded right now still gets that in one field.

    Only models whose WEIGHTS are here are listed: faxl never downloads one to
    answer a request, so advertising something absent would be an invitation
    to a 400.
    """
    return jsonify({"object": "list", "data": _model_rows(),
                    "faxl": {"resident": MODEL,
                             "switch_on_demand": bool(_SWITCH_ON_DEMAND),
                             **_agent_guide()}})


def _model_rows():
    """The /v1/models rows. One function, because the console's client-config
    export builds from exactly these: a second copy of the listing would be a
    second answer to "what does faxl serve, under what id, with what window".
    """
    # The catalogue is a convenience; the resident model is the contract.
    # Never fail this over a directory read.
    try:
        _local = list(faxl_config.local_models())
    except Exception as _e:                                   # noqa: BLE001
        print(f"!! /v1/models could not list local models: {_e}", flush=True)
        _local = []
    # MODEL is a path on this machine or an org/name id the catalogue
    # resolves; its window is read from there whether or not switching is on.
    _resident_path = MODEL if os.path.isdir(MODEL) else dict(_local).get(MODEL)
    _ids = [MODEL] + [mid for mid, _p in _local]
    data = [_model_entry(MODEL, _resident_path, True, _ids)]
    if _SWITCH_ON_DEMAND:
        for mid, _path in _local:
            if mid != MODEL and _is_generative(_path):
                data.append(_model_entry(mid, _path, False, _ids))
    return data


@app.route("/health", methods=["GET"])
def health():
    # M0: logging/audit failures surface here (never silent). In collection
    # mode they FAIL health (503) — a corpus with holes must not look green.
    problems = list(LOG_FAILURES)
    if EVIDENCE is not None and EVIDENCE.failed:
        problems.append("evidence writer: " + EVIDENCE.failed)
    if AUDIT and AUDIT.failed:
        problems.append(AUDIT.failed)
    _tel_health = TELEMETRY.health() if TELEMETRY is not None else None
    if _tel_health:
        problems.extend(_tel_health["failures"])
    # SERVE DEPTH. Without this a backlog is indistinguishable from a hang
    # from outside the process -- see _Waiting.
    _busy = _SERVE_LOCK.locked()
    _since = _WAITING["since"]
    body = {"status": "ok" if not problems else "logging-failure",
            "model": MODEL, "library_size": index.rows, "nocache": NOCACHE,
            "serving": _busy,
            "waiting": _WAITING["n"],
            "waiting_longest_s": (round(time.time() - _since, 1)
                                  if _since else 0),
            "collect": COLLECT, "log_failures": problems[:5],
            "n_log_failures": len(problems), "licence": licence.status(),
            "telemetry": _tel_health, **_agent_guide()}
    return jsonify(body), (503 if (problems and COLLECT) else 200)


@app.route("/metrics", methods=["GET"])
def metrics():
    t = dict(TOTALS)
    denom = (t["prefill_skipped"] + t["prefill_paid"]) or 1
    t["skip_frac"] = round(t["prefill_skipped"] / denom, 4)
    t["hit_rate"] = round(t["hits"] / (t["requests"] or 1), 4)
    t["mode"] = "nocache" if NOCACHE else "cache"
    t["backend"] = BACKEND.name
    t["model"] = MODEL
    if BY_PROJECT:
        # skip_frac is served / (served + paid), NOT served / prompt_tokens.
        #
        # Those are two different measures and dividing one by the other gives
        # nonsense: prompt_tokens here counts the token ids the LADDER hashed,
        # while `served` is what the cache handed back — and on a vision
        # request the model expands one image atom into hundreds of positions,
        # so served can exceed the id count outright. Measured: 11,776/5,355
        # reported as "219.9% skipped".
        t["by_project"] = {
            k: dict(v,
                    hit_rate=round(v["hits"] / (v["requests"] or 1), 4),
                    skip_frac=round(
                        v["prefill_skipped"] /
                        ((v["prefill_skipped"] + v["prefill_paid"]) or 1), 4))
            for k, v in BY_PROJECT.items()}
    if BACKEND.name == "exo":
        # On this path the ladder runs in the prefill server thread, so these
        # are the authoritative hit counts -- the handler never probes the
        # store. Reported alongside TOTALS rather than instead of it, so a
        # disagreement is visible rather than hidden.
        t["exo"] = dict(EXO_COUNTS)
        t["exo"]["hit_rate"] = round(
            EXO_COUNTS["hits"] / (EXO_COUNTS["requests"] or 1), 4)
    return jsonify(t)


def main():
    port = int(os.environ.get("FAXL_PORT", "8767"))
    # Loopback by default: the console (and its unauthenticated loopback GETs)
    # assume the proxy is not reachable off-box. Binding elsewhere is an explicit
    # opt-in and prints a loud warning (the console also shows a persistent
    # banner + requires auth on reads when non-loopback — server topology).
    host = os.environ.get("FAXL_HOST", "127.0.0.1")
    if host not in ("127.0.0.1", "localhost", "::1"):
        print(f"!! FAXL_HOST={host} is NOT loopback — the proxy and its /console "
              f"are reachable off-box; ensure auth is configured (the console's "
              f"loopback-GET-no-auth assumption does NOT hold here)", flush=True)
    print(f"faxl proxy on http://{host}:{port}/v1  (model {MODEL})")

    if not _MAIN_THREAD_INFER:
        app.run(host=host, port=port, threaded=True)  # FIX D6 (lock serializes inference)
        return

    # THE MAIN THREAD STOPS BEING THE SERVER AND BECOMES THE EXECUTOR. Flask
    # moves to a thread of its own; this one runs the pump, because stream 0 --
    # the one mlx's compiled recurrence demands -- belongs to the main thread
    # and cannot be handed to another. See _run_on_main.
    #
    # The server thread is a daemon: when the pump returns (SIGINT), the
    # process exits rather than hanging on a serving thread nobody can reach.
    srv = threading.Thread(
        target=lambda: app.run(host=host, port=port, threaded=True,
                               use_reloader=False),
        daemon=True, name="faxl-http")
    srv.start()
    try:
        _main_thread_pump()
    except KeyboardInterrupt:
        print("stopping.", flush=True)


if __name__ == "__main__":
    main()

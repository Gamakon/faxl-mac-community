# Vendored engine module (faxl_voice.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""faxl_voice -- Voice2Text, the server side (docs/plans/voice2text.md).

WHAT THIS IS. Private dictation on the owner's own machine: the browser cuts
microphone audio at pauses (VAD) and posts each chunk here as raw PCM; this
module turns it into text with a local speech model, then asks the model the
faxl proxy is ALREADY serving to repair it (punctuation, misheard words),
through the proxy's own /v1/chat/completions so the prefix cache pays and the
request log sees every call.

What lives here (chunk 1 of 3; the page is chunk 2, the APPS entry chunk 3):

  * CATALOGUE      the speech models, as data: engine per platform, recorded
                   download size WITH the source of that number, languages.
  * ENGINES        load(model_id) / transcribe(pcm16) -- one class per library,
                   each importing its library lazily in load() and raising a
                   NAMED error when it is absent. There is no fallback from one
                   engine to another: a missing mlx-whisper is reported as a
                   missing mlx-whisper, never quietly served by something else.
  * DOWNLOAD       status() (installed? sizes, free disk, does speech model +
                   repair model fit) and a background download job with a
                   state file and measured progress.
  * REPAIR         one chunk at a time against a read-only, forward-only
                   context; ANY failure keeps the raw chunk and advances
                   (the argument is at "---- repair").
  * BACKUP         the browser's MediaRecorder pieces appended in order, and
                   finalize: ffmpeg -> 16 kHz PCM -> the WHOLE recording
                   transcribed (the argument is at "the backup recording").
  * ROUTES         register_voice_routes(bp, ...) -- the one hook
                   faxl_console calls.

Nothing here is imported by faxl_proxy and nothing here loads a model at
import: the libraries (mlx_whisper, faster_whisper, parakeet_mlx, nemo,
huggingface_hub, numpy) are imported inside the functions that need them.
"""
import importlib.util
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
import wave

from faxl.engine import faxl_backends
from faxl.engine import faxl_config

# ---- the catalogue ------------------------------------------------------------
# DATA, NOT CODE. Every number carries where it came from. Nothing estimated is
# presented as measured: `download_bytes_basis` says which it is, and a size
# nobody has recorded is None -- the fit check then REFUSES (faxl_config.judge:
# "size unknown -- refusing rather than guessing") instead of assuming one.

# AM's priority order (docs/plans/voice2text.md, "Languages"): English, French,
# then by estimated total speakers. The bake-off reports in this order and
# English + French gate the first release.
LANGUAGES = [("en", "English"), ("fr", "French"), ("zh", "Chinese"),
             ("hi", "Hindi"), ("es", "Spanish"), ("ar", "Arabic"),
             ("bn", "Bengali"), ("pt", "Portuguese"), ("de", "German"),
             ("ja", "Japanese"), ("ta", "Tamil"), ("ko", "Korean"),
             ("it", "Italian"), ("pl", "Polish"), ("bg", "Bulgarian")]
LANGUAGE_CODES = [c for c, _ in LANGUAGES]

DEFAULT_MODEL_ID = "whisper-large-v3-turbo"

CATALOGUE = {
    "whisper-large-v3-turbo": {
        "label": "Whisper large-v3-turbo",
        "engines": {
            "darwin": {"engine": "mlx-whisper", "package": "mlx-whisper",
                       "module": "mlx_whisper",
                       "repo": "mlx-community/whisper-large-v3-turbo"},
            # faster-whisper (CTranslate2). This is the repo faster-whisper
            # >= 1.1 resolves its built-in name "large-v3-turbo" to; NOT read
            # from the package here (faster-whisper is not installed in the
            # environment this was written in) -- confirm on the first Linux run.
            "linux": {"engine": "faster-whisper", "package": "faster-whisper",
                      "module": "faster_whisper",
                      "repo": "mobiuslabsgmbh/faster-whisper-large-v3-turbo"},
        },
        # ~1.6 GB: the design doc's figure. NOT measured on disk and NOT read
        # from the Hub API (no network where this was written). The download
        # job reads the Hub's own file sizes before it starts and reports that
        # total with basis "hub_api" -- that is the number to record here once
        # a real download has been seen.
        "download_bytes": 1_613_979_798,
        "download_bytes_basis": ("measured: downloaded to "
                                 "~/.cache/huggingface/hub on the owner's Mac, "
                                 "2026-09-22 -- 1,613,979,798 bytes of real "
                                 "files, symlinks not counted (the Hub API "
                                 "totalled the same snapshot at 1,613,979,758; "
                                 "the difference is the cache's own metadata). "
                                 "Replaces the design doc's ~1.6 GB estimate, "
                                 "which was right"),
        "languages": list(LANGUAGE_CODES),
        "languages_note": ("all 15 target languages, per the design doc; "
                           "per-language accuracy is the bake-off's to "
                           "measure, not yet measured"),
        "notes": "the default; one model for every target language",
    },
    "parakeet": {
        "label": "Parakeet TDT 0.6B v3",
        "engines": {
            # Repo ids and library entry points as published by their
            # authors; neither was downloaded or run where this was written.
            "darwin": {"engine": "parakeet-mlx", "package": "parakeet-mlx",
                       "module": "parakeet_mlx",
                       "repo": "mlx-community/parakeet-tdt-0.6b-v3"},
            "linux": {"engine": "nemo", "package": "nemo_toolkit[asr]",
                      "module": "nemo",
                      "repo": "nvidia/parakeet-tdt-0.6b-v3"},
        },
        # The design doc gives only a range for speech models (0.2-2 GB) and
        # 178 MB for "Parakeet Redux", a DIFFERENT (compressed) build. No
        # figure for this repo is recorded anywhere in the repositories, so
        # none is given, and the fit check refuses until the Hub total is
        # read (the download job reads it).
        "download_bytes": None,
        "download_bytes_basis": "unknown: no recorded size for this repo",
        "languages": ["en"],
        # v3 is described as multilingual European; which languages exactly
        # could not be confirmed from any source in the repositories or from
        # package metadata, so only English is claimed.
        "languages_note": "English; others unverified",
        "notes": ("fast CPU path; offered as a choice in the download "
                  "moment"),
    },
}

# Speech model + repair model together must stay under this (design doc,
# "Budget: any model set under 20 GB").
VOICE_BUDGET_BYTES = 20 * 10**9


def catalogue():
    """The catalogue as a list, default first, with the language names."""
    names = dict(LANGUAGES)
    out = []
    for mid in sorted(CATALOGUE, key=lambda m: m != DEFAULT_MODEL_ID):
        e = dict(CATALOGUE[mid])
        e["id"] = mid
        e["default"] = mid == DEFAULT_MODEL_ID
        e["language_names"] = [names.get(c, c) for c in e["languages"]]
        out.append(e)
    return out


def platform_key(platform=None):
    """darwin | linux | the raw value (which has no engine)."""
    p = (platform or faxl_backends.current_platform()).lower()
    return "linux" if p.startswith("linux") else p


def engine_spec(model_id, platform=None):
    """{engine, package, module, repo} for `model_id` on this platform.
    KeyError/ValueError name the problem; there is no substitute engine."""
    if model_id not in CATALOGUE:
        raise KeyError(f"unknown speech model {model_id!r}; known: "
                       f"{', '.join(CATALOGUE)}")
    p = platform_key(platform)
    spec = CATALOGUE[model_id]["engines"].get(p)
    if not spec:
        raise ValueError(f"{model_id} has no engine for platform {p!r} "
                         f"(Voice2Text runs on Apple Silicon macOS and "
                         f"Linux)")
    return dict(spec)


# ---- errors --------------------------------------------------------------------

class VoiceError(RuntimeError):
    """Base for the named failures below. `code` is a short stable name for
    the failure (the page collapses identical failures on it)."""
    code = None

    def __init__(self, msg="", code=None):
        super().__init__(msg)
        if code:
            self.code = code


class EngineMissing(VoiceError):
    """The engine's Python library is not installed. The message is the fix."""


class ModelNotDownloaded(VoiceError):
    """The weights are not on this machine. Nothing downloads as a side
    effect of transcribing: the download moment is explicit."""


class RepairRejected(VoiceError):
    """The repair model answered, but not with a usable correction of the new
    chunk (empty, numbered, several lines, the wrong length, or text copied
    from the context). The raw chunk is kept."""


class RepairUnavailable(VoiceError):
    """The proxy's /v1/chat/completions could not be reached or refused."""


class SaveFailed(VoiceError):
    """Save recording is on and the files could not be written."""


class FfmpegMissing(VoiceError):
    """ffmpeg is not on PATH, so the backup recording (webm/mp4/ogg from the
    browser's MediaRecorder) cannot be decoded. There is no other decoder."""


class DecodeFailed(VoiceError):
    """ffmpeg ran and produced no audio from the backup recording."""


class BackupOrderError(VoiceError):
    """A backup piece arrived out of order (a gap would corrupt the file)."""


def _require(module, package):
    """Import `module` or raise EngineMissing with the pip line."""
    try:
        return __import__(module, fromlist=["_"])
    except ImportError as exc:
        raise EngineMissing(f"{package} is not installed: pip install "
                            f"{package}") from exc


# ---- the HF cache: what is on this machine -------------------------------------

def _repo_dir(repo):
    return os.path.join(faxl_config.hf_hub_dir(),
                        "models--" + repo.replace("/", "--"))


_WEIGHT_EXTS = (".safetensors", ".bin", ".npz", ".nemo", ".gguf")


def installed_path(repo):
    """The snapshot directory refs/main points at, when it holds weights and
    no download is half-done (an *.incomplete blob), else None."""
    root = _repo_dir(repo)
    try:
        with open(os.path.join(root, "refs", "main")) as fh:
            sha = fh.read().strip()
    except OSError:
        return None
    snap = os.path.join(root, "snapshots", sha)
    try:
        names = os.listdir(snap)
        blobs = os.listdir(os.path.join(root, "blobs"))
    except OSError:
        return None
    if any(b.endswith(".incomplete") for b in blobs):
        return None
    if not any(n.endswith(_WEIGHT_EXTS) and os.path.isfile(os.path.join(snap, n))
               for n in names):
        return None
    return snap


def repo_bytes(repo):
    """Bytes under the repo's blobs/ -- the data actually on disk, each file
    once (snapshots/ is symlinks into blobs/, so walking it would count
    twice). In-progress *.incomplete blobs count: this is also the download
    progress figure. Measured, not cached."""
    total = 0
    for root, _d, files in os.walk(os.path.join(_repo_dir(repo), "blobs")):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def free_disk(path=None):
    """(free bytes, the directory measured) for the HF cache's filesystem.
    The cache may not exist yet: walk up to the first directory that does."""
    p = path or faxl_config.hf_hub_dir()
    while p and not os.path.isdir(p):
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    try:
        return shutil.disk_usage(p).free, p
    except OSError:
        return None, p


# ---- engines -------------------------------------------------------------------
# One class per library. load() imports lazily and refuses by name; transcribe
# takes little-endian int16 mono PCM, which is what the page posts.

SAMPLE_RATE = 16000


def _pcm_to_float(pcm16_bytes):
    np = _require("numpy", "numpy")
    if len(pcm16_bytes) % 2:
        raise ValueError("PCM body has an odd number of bytes; expected "
                         "little-endian int16 samples")
    return np.frombuffer(pcm16_bytes, dtype="<i2").astype(np.float32) / 32768.0


def _write_wav(pcm16_bytes, sample_rate):
    """A temporary 16-bit mono WAV of the chunk, for libraries whose API takes
    a file path. The caller deletes it."""
    fd, path = tempfile.mkstemp(prefix="faxl_voice_", suffix=".wav")
    os.close(fd)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm16_bytes)
    return path


def _check_rate(sample_rate):
    if int(sample_rate) != SAMPLE_RATE:
        # No resampler here: the page captures at 16 kHz. A different rate
        # is refused rather than transcribed at the wrong speed.
        raise ValueError(f"sample_rate must be {SAMPLE_RATE}, got "
                         f"{sample_rate}")


# The vocabulary ("names and terms") is Whisper's `initial_prompt`: text the
# decoder is conditioned on as if it had been said before the audio, which
# biases spelling toward those words. Both Whisper libraries take it --
# checked in the published wheels: mlx-whisper 0.4.3 transcribe(...,
# initial_prompt: Optional[str]) and faster-whisper 1.2.1
# WhisperModel.transcribe(..., initial_prompt=str | token ids). Parakeet
# (parakeet-mlx, NeMo) has no such argument: its engines set PROMPT = False
# and the reply says the vocabulary was NOT applied, rather than dropping it
# quietly. 500 characters is ~125 Latin tokens, inside Whisper's 223-token
# prompt window, so nothing sent is silently truncated by the model.
MAX_PROMPT_CHARS = 500
DEFAULT_VOCABULARY = "faxl, Gamakon, Qwen, Jesung, UltraDim, Erquy"


class Engine:
    """The interface. Subclasses set NAME and implement _load/_transcribe."""
    NAME = None
    PROMPT = False     # does the library take a vocabulary (initial_prompt)?

    def __init__(self):
        self.model_id = None
        self.path = None
        self.repo = None

    def load(self, model_id):
        spec = engine_spec(model_id)
        if spec["engine"] != self.NAME:
            raise ValueError(f"{model_id} runs on {spec['engine']} here, not "
                             f"{self.NAME}")
        lib = _require(spec["module"], spec["package"])
        path = installed_path(spec["repo"])
        if not path:
            raise ModelNotDownloaded(
                f"{model_id} ({spec['repo']}) is not downloaded: POST "
                f"/api/voice/download {{\"model_id\": \"{model_id}\"}}")
        self.model_id, self.path, self.repo = model_id, path, spec["repo"]
        self._load(lib, path)
        return self

    def transcribe(self, pcm16_bytes, sample_rate=SAMPLE_RATE, language=None,
                   prompt=None):
        if self.model_id is None:
            raise VoiceError("engine not loaded")
        _check_rate(sample_rate)
        prompt = (prompt or "").strip() or None
        if prompt and len(prompt) > MAX_PROMPT_CHARS:
            raise ValueError(f"names and terms are {len(prompt)} characters; "
                             f"the limit is {MAX_PROMPT_CHARS}")
        t0 = time.time()
        text, lang = self._transcribe(pcm16_bytes, sample_rate, language,
                                      prompt if self.PROMPT else None)
        out = {"text": (text or "").strip(), "language": lang,
               "duration_s": round(len(pcm16_bytes) / 2 / sample_rate, 3),
               "elapsed_s": round(time.time() - t0, 3)}
        if prompt:
            out["vocabulary"] = {"applied": self.PROMPT, "engine": self.NAME}
            if not self.PROMPT:
                out["vocabulary"]["reason"] = (f"{self.NAME} takes no "
                                               f"initial prompt")
        return out

    def _load(self, lib, path):
        raise NotImplementedError

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        raise NotImplementedError


class MlxWhisperEngine(Engine):
    NAME = "mlx-whisper"
    PROMPT = True

    def _load(self, lib, path):
        self._lib = lib   # mlx_whisper loads (and caches) the model per call

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        audio = _pcm_to_float(pcm16_bytes)
        r = self._lib.transcribe(audio, path_or_hf_repo=self.path,
                                 language=language, initial_prompt=prompt)
        return r.get("text", ""), r.get("language")


class FasterWhisperEngine(Engine):
    NAME = "faster-whisper"
    PROMPT = True

    def _load(self, lib, path):
        self._model = lib.WhisperModel(path)

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        audio = _pcm_to_float(pcm16_bytes)
        segments, info = self._model.transcribe(audio, language=language,
                                                initial_prompt=prompt)
        return "".join(s.text for s in segments), getattr(info, "language",
                                                           None)


class ParakeetMlxEngine(Engine):
    NAME = "parakeet-mlx"

    def _load(self, lib, path):
        from parakeet_mlx import from_pretrained
        self._model = from_pretrained(self.repo)

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        # Parakeet takes no language argument; it reports none either, so
        # the language is None (unknown), not the one asked for.
        wav = _write_wav(pcm16_bytes, sample_rate)
        try:
            r = self._model.transcribe(wav)
        finally:
            os.unlink(wav)
        return getattr(r, "text", ""), None


class NemoParakeetEngine(Engine):
    NAME = "nemo"

    def _load(self, lib, path):
        nemo_file = next((os.path.join(path, n) for n in sorted(os.listdir(path))
                          if n.endswith(".nemo")), None)
        if not nemo_file:
            raise ModelNotDownloaded(f"no .nemo file in {path}")
        import nemo.collections.asr as nemo_asr
        self._model = nemo_asr.models.ASRModel.restore_from(nemo_file)

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        wav = _write_wav(pcm16_bytes, sample_rate)
        try:
            out = self._model.transcribe([wav])
        finally:
            os.unlink(wav)
        first = out[0] if out else ""
        return getattr(first, "text", first), None


ENGINES = {c.NAME: c for c in (MlxWhisperEngine, FasterWhisperEngine,
                               ParakeetMlxEngine, NemoParakeetEngine)}


class StubEngine(Engine):
    """TESTS ONLY. Returns a fixed text for any audio. It is NOT in ENGINES,
    no catalogue entry names it, and no route can select it: a test injects
    it through register_voice_routes(engine_factory=...)."""
    NAME = "stub"
    PROMPT = True

    def __init__(self, text="stub transcript"):
        super().__init__()
        self.text = text
        self.calls = []
        self.prompts = []

    def load(self, model_id):
        self.model_id = model_id
        return self

    def _transcribe(self, pcm16_bytes, sample_rate, language, prompt):
        self.calls.append((len(pcm16_bytes), sample_rate, language))
        self.prompts.append(prompt)
        return self.text, language


def make_engine(model_id):
    """A loaded engine for `model_id` on this platform (named errors only)."""
    spec = engine_spec(model_id)
    return ENGINES[spec["engine"]]().load(model_id)


# ---- status: installed? does it fit? -------------------------------------------

def _repair_size(model_id):
    """(bytes, basis) for the serving (repair) model: measured on disk when
    its weights are here, the recorded SHIPPED_DEFAULTS size otherwise."""
    if not model_id:
        return None, None
    d = faxl_config.local_model_dir(model_id)
    if d:
        return faxl_config.dir_bytes(d), "measured on disk"
    n = faxl_config.shipped_size(model_id)
    return (n, "recorded (faxl_config.SHIPPED_DEFAULTS)") if n else (None, None)


def _memory(backend_name):
    """(usable bytes, reason it could not be read, whose memory, and whether
    the repair model shares it). The speech model runs on THIS machine; on
    exo the repair model runs on the cluster, so only speech counts here."""
    desc = faxl_backends.get(backend_name) or {}
    src = desc.get("memory_from", "host_ram")
    if src == "gpu_vram":
        m = faxl_config.gpu_memory()
        return m.get("usable_bytes"), m.get("error"), "the GPU", True
    m = faxl_config.mlx_memory()
    return m.get("usable_bytes"), None, "this machine", src != "cluster_ram"


def status(model_id=None, serving_model=None, backend_name=None,
           platform=None):
    """Everything the download moment shows, for one chosen speech model.

    fit.ok is True only when every check passed with KNOWN numbers:
      memory  speech model + repair model <= usable memory (RAM or VRAM x
              faxl_config.fit_ratio -- the same judge() the model switch uses)
      budget  speech model + repair model <= VOICE_BUDGET_BYTES (20 GB)
      disk    bytes still to download <= free disk under the HF cache
    A size nobody recorded is a refusal with the reason, never a guess.
    """
    mid = model_id or DEFAULT_MODEL_ID
    if mid not in CATALOGUE:
        raise KeyError(f"unknown speech model {mid!r}")
    p = platform_key(platform)
    backend_name = backend_name or faxl_config.backend()
    models = []
    for e in catalogue():
        spec = e["engines"].get(p)
        row = {k: e[k] for k in ("id", "label", "default", "download_bytes",
                                 "download_bytes_basis", "languages",
                                 "language_names", "languages_note", "notes")}
        if spec:
            path = installed_path(spec["repo"])
            row.update(engine=spec["engine"], package=spec["package"],
                       repo=spec["repo"], installed=bool(path), path=path,
                       size_on_disk=repo_bytes(spec["repo"]) if path else None,
                       library_installed=importlib.util.find_spec(
                           spec["module"]) is not None)
        else:
            row.update(engine=None, package=None, repo=None, installed=False,
                       path=None, size_on_disk=None, library_installed=False)
        models.append(row)
    sel = next(m for m in models if m["id"] == mid)

    speech = sel["size_on_disk"] if sel["installed"] else sel["download_bytes"]
    speech_basis = ("measured on disk" if sel["installed"]
                    else sel["download_bytes_basis"])
    rep_bytes, rep_basis = _repair_size(serving_model)
    have, down, place, shares = _memory(backend_name)
    reasons = []
    need_mem = None
    if sel["engine"] is None:
        reasons.append(f"no speech engine for platform {p!r}")
    if speech is None:
        reasons.append(f"{mid}: size unknown — refusing rather than guessing")
    if shares and rep_bytes is None:
        reasons.append(f"repair model {serving_model or '(none configured)'}: "
                       f"size unknown — refusing rather than guessing")
    if speech is not None and (rep_bytes is not None or not shares):
        need_mem = speech + (rep_bytes if shares else 0)
        v = faxl_config.judge(mid, need_mem, have, place, down_reason=down)
        if not v["ok"]:
            reasons.append(f"memory (speech + repair model): {v['reason']}")
        total = speech + (rep_bytes or 0)
        if total > VOICE_BUDGET_BYTES:
            reasons.append(
                f"budget: speech + repair model is "
                f"{faxl_config.fmt_bytes(total)}, over the "
                f"{faxl_config.fmt_bytes(VOICE_BUDGET_BYTES)} Voice2Text budget")
    need_disk = 0 if sel["installed"] else sel["download_bytes"]
    free, where = free_disk()
    if need_disk is None:
        pass   # already refused above as size unknown
    elif free is None:
        reasons.append(f"free disk at {where} could not be read")
    elif need_disk > free:
        reasons.append(f"disk: needs {faxl_config.fmt_bytes(need_disk)}, "
                       f"{where} has {faxl_config.fmt_bytes(free)} free")
    return {
        "platform": p, "backend": backend_name,
        "default_model": DEFAULT_MODEL_ID, "selected": mid,
        "languages": [{"code": c, "name": n} for c, n in LANGUAGES],
        "models": models,
        "speech_model": {"id": mid, "bytes": speech, "bytes_basis": speech_basis,
                         "installed": sel["installed"]},
        "repair_model": {"id": serving_model or None, "bytes": rep_bytes,
                         "bytes_basis": rep_basis,
                         "counted_in_memory": shares},
        "disk": {"free_bytes": free, "where": where,
                 "bytes_needed": need_disk},
        "fit": {"ok": not reasons, "reasons": reasons,
                "need_memory_bytes": need_mem, "have_memory_bytes": have,
                "memory_of": place, "budget_bytes": VOICE_BUDGET_BYTES},
        "requirements": ["microphone and browser permission",
                         "Apple Silicon Mac or NVIDIA GPU on Linux",
                         ffmpeg_requirement()],
        "ffmpeg": {"path": shutil.which("ffmpeg")},
    }


def ffmpeg_requirement():
    """The requirement line for ffmpeg, saying whether it is here."""
    p = shutil.which("ffmpeg")
    if p:
        return (f"ffmpeg (found: {p}) -- decodes the backup recording so the "
                f"whole recording is transcribed at Stop")
    return ("ffmpeg -- NOT FOUND on PATH: the backup recording cannot be "
            "decoded, so the whole-recording transcript at Stop will fail "
            "with FfmpegMissing (install: brew install ffmpeg on macOS, "
            "sudo apt install ffmpeg on Linux, then restart the proxy)")


# ---- the download job ------------------------------------------------------------
# A background THREAD in the proxy process, with a state file. Not a
# subprocess: huggingface_hub is the whole job and it resumes a partial
# download by itself, so a proxy restart mid-download just leaves "interrupted"
# and the next POST continues from the blobs already on disk.
#
# Progress is MEASURED: bytes under the repo's blobs/ (repo_bytes), polled
# once a second, against a total read from the Hub's file listing when it can
# be (basis "hub_api"), else the catalogue's recorded figure with its basis.

_DL_LOCK = threading.Lock()
_DL_THREAD = {"t": None}
_DL_POLL_S = 1.0


def _load_snapshot_download():
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise EngineMissing("huggingface_hub is not installed: pip install "
                            "huggingface_hub") from exc
    return snapshot_download


def _hub_total(repo):
    """(bytes, basis) from the Hub's file listing, or (None, error text)."""
    try:
        from huggingface_hub import HfApi
        info = HfApi().model_info(repo, files_metadata=True)
        n = sum((s.size or 0) for s in (info.siblings or []))
        return (n, "hub_api") if n else (None, "hub_api returned no sizes")
    except Exception as exc:  # noqa: BLE001 -- reported as the basis
        return None, f"hub_api unavailable ({type(exc).__name__})"


def _state_path(state_dir):
    return os.path.join(state_dir, "download.json")


def _write_state(state_dir, st):
    os.makedirs(state_dir, exist_ok=True)
    tmp = _state_path(state_dir) + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(st, fh)
    os.replace(tmp, _state_path(state_dir))


def download_status(state_dir):
    """The job's state file, with "running" checked against this process: a
    file that says running but whose thread is not alive here (the proxy
    restarted) is reported "interrupted"."""
    try:
        with open(_state_path(state_dir)) as fh:
            st = json.load(fh)
    except FileNotFoundError:
        return {"state": "none"}
    except (OSError, ValueError) as exc:
        return {"state": "unknown", "error": str(exc)}
    if st.get("state") == "running":
        t = _DL_THREAD["t"]
        if st.get("pid") != os.getpid() or not (t and t.is_alive()):
            st["state"] = "interrupted"
        elif st.get("repo"):
            st["bytes_done"] = repo_bytes(st["repo"])
    return st


def start_download(model_id, state_dir, platform=None):
    """Start the download job. Returns (http status, payload)."""
    try:
        spec = engine_spec(model_id, platform)
    except (KeyError, ValueError) as exc:
        return 400, {"ok": False, "error": str(exc).strip("'\"")}
    with _DL_LOCK:
        cur = download_status(state_dir)
        if cur.get("state") == "running":
            return 409, {"ok": False, "error": "a download is already running",
                         "status": cur}
        snapshot_download = _load_snapshot_download()   # named error if absent
        total, basis = _hub_total(spec["repo"])
        if total is None:
            rec = CATALOGUE[model_id]["download_bytes"]
            basis = (f"{CATALOGUE[model_id]['download_bytes_basis']}; "
                     f"{basis}")
            total = rec
        st = {"state": "running", "model_id": model_id, "repo": spec["repo"],
              "bytes_done": repo_bytes(spec["repo"]), "bytes_total": total,
              "total_basis": basis, "started": time.time(), "finished": None,
              "error": None, "path": None, "pid": os.getpid()}
        _write_state(state_dir, st)
        t = threading.Thread(target=_download_worker,
                             args=(snapshot_download, dict(st), state_dir),
                             daemon=True, name="faxl-voice-download")
        _DL_THREAD["t"] = t
        t.start()
    return 202, {"ok": True, "status": st}


def _download_worker(snapshot_download, st, state_dir):
    done = threading.Event()

    def poll():
        while not done.wait(_DL_POLL_S):
            st["bytes_done"] = repo_bytes(st["repo"])
            with _DL_LOCK:
                _write_state(state_dir, st)

    poller = threading.Thread(target=poll, daemon=True)
    poller.start()
    try:
        path = snapshot_download(repo_id=st["repo"])
        st.update(state="done", path=path)
    except Exception as exc:  # noqa: BLE001 -- the state file carries it
        st.update(state="failed", error=f"{type(exc).__name__}: {exc}")
    finally:
        done.set()
        poller.join()
        st["bytes_done"] = repo_bytes(st["repo"])
        st["finished"] = time.time()
        with _DL_LOCK:
            _write_state(state_dir, st)


# ---- repair ---------------------------------------------------------------------
# ONE CHUNK AT A TIME, AND A FAILED CORRECTION NEVER HIDES TEXT.
#
# Each repair asks the model for ONE corrected string for the new raw chunk.
# (The first design re-sent the last three chunks numbered [1]..[3] and
# accepted the reply only if every number came back; on 2026-09-22 the 4B
# model answered "[3] ..." alone, the call became a 502, the session did not
# advance, and every later chunk failed the same way -- the owner saw his
# words struck through. Nothing in that design could recover.)
#
# Now: ANY failure -- proxy unreachable, HTTP error, an empty / numbered /
# multi-line / wrong-length reply, or one that copies the context -- keeps
# the RAW chunk, appends it to the transcript, advances the session and
# returns 200 with corrected=None and the reason. The next chunk repairs
# against a transcript that has every word in it.
#
# THE PROMPT, and why its prefix is byte-stable. Two messages: REPAIR_SYSTEM
# (a constant) and
#
#     _HEADER_CONTEXT + CONTEXT + _HEADER_NEW + raw
#
# where CONTEXT = frozen[start:], `frozen` being every chunk accepted so far
# (corrected or raw) joined by single spaces. frozen only ever grows at its
# end, so as long as `start` stays put, prompt k is a byte prefix of prompt
# k+1 up to the end of CONTEXT_k, and the proxy's resume cache prefills only
# the new chunk. A small model's window cannot take an unbounded transcript,
# so CONTEXT is capped: when it passes CONTEXT_MAX_CHARS (1500), `start`
# jumps FORWARD to a sentence start that leaves between CONTEXT_KEEP_CHARS
# (750) and 1500 characters. Why this shape:
#   * forward only, and never back: a start that moved every call (a plain
#     "last 1500 characters" slice) would change the first byte of CONTEXT on
#     every call and the cache would miss every time;
#   * whole sentences: the model never sees a context that begins mid-word;
#   * the 750-character hysteresis: after a jump there is room for ~750 more
#     characters (a minute or so of speech) before the next jump, so the
#     cache misses once per ~750 characters instead of once per chunk.
# If there is no sentence end in that range (unpunctuated speech), the start
# is the last word boundary before the 750 mark, and failing even that the
# plain 1500-character cut -- still forward-only.

CONTEXT_MAX_CHARS = 1500
CONTEXT_KEEP_CHARS = 750
MAX_RAW_CHARS = 4000        # one VAD chunk (<= 60 s of speech) is ~1,000
_HEADER_CONTEXT = "Transcript so far (read-only context, already final):\n"
_HEADER_NEW = "\n\nNew segment to correct:\n"

REPAIR_SYSTEM = (
    "You repair speech-to-text output. You are given the transcript so far "
    "as read-only context, then ONE new segment. Correct misrecognised "
    "words, punctuation and capitalisation in the new segment only, using "
    "the context. Keep the speaker's words and language: do not translate, "
    "summarise, answer, explain or add anything. Reply with the corrected "
    "new segment only, on one line, with no numbering, no quotes and "
    "nothing else. Never repeat the context.")

# A sentence starts after terminal punctuation (and any closing quote or
# bracket) plus whitespace; CJK full stops need no space after them.
_SENT_END = re.compile(r"[.!?…]+[\"'”’)\]]*\s+|[。！？]+")
_NUMBERED_RE = re.compile(r"^\s*\[\d+\]")
_WORD_RE = re.compile(r"\w+")
# Corrected length must be within these multiples of the raw chunk's length.
MIN_LEN_RATIO, MAX_LEN_RATIO = 0.5, 2.0
# A run of this many words that is in the context but not in the raw chunk
# means the model copied the context into its answer.
COPY_RUN_WORDS = 6
_SESSION_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
MAX_SESSIONS = 64


def context_start(frozen, start):
    """Where the read-only context begins: `start` unchanged while the
    context fits CONTEXT_MAX_CHARS, else a later sentence start (see above).
    Never earlier than `start`."""
    n = len(frozen)
    if n - start <= CONTEXT_MAX_CHARS:
        return start
    lo, hi = n - CONTEXT_MAX_CHARS, n - CONTEXT_KEEP_CHARS
    starts = [m.end() for m in _SENT_END.finditer(frozen, lo) if m.end() < n]
    keep = [p for p in starts if p <= hi]
    if keep:
        return keep[-1]
    if starts:
        return starts[0]
    sp = frozen.rfind(" ", lo, hi + 1)
    return sp + 1 if sp >= 0 else lo


def stable_prefix(context):
    """The part of the user message that the NEXT call starts with too,
    while the context start does not move."""
    return _HEADER_CONTEXT + context


def build_messages(context, raw):
    return [{"role": "system", "content": REPAIR_SYSTEM},
            {"role": "user",
             "content": stable_prefix(context) + _HEADER_NEW + raw}]


def max_tokens_for(raw):
    """Bounded by the one chunk being corrected: two tokens per character
    (a CJK character can be a whole token or more; Latin text is ~4
    characters a token) plus 64, capped at 4096. A reply longer than
    MAX_LEN_RATIO x raw is rejected anyway."""
    return min(4096, 64 + 2 * len(raw))


def _shingles(text, n):
    w = _WORD_RE.findall(text.lower())
    return {tuple(w[i:i + n]) for i in range(len(w) - n + 1)}


def check_correction(raw, reply, context):
    """The model's reply -> the corrected chunk, or RepairRejected(code)."""
    text = (reply or "").strip()
    if not text:
        raise RepairRejected("the model returned nothing", code="empty")
    lines = [l for l in text.splitlines() if l.strip()]
    if len(lines) > 1:
        raise RepairRejected(f"the reply has {len(lines)} lines; one "
                             f"corrected segment was asked for",
                             code="multiline")
    if _NUMBERED_RE.match(text):
        raise RepairRejected(f"the reply is numbered ({text[:40]!r}); one "
                             f"unnumbered segment was asked for",
                             code="numbered")
    ratio = len(text) / max(1, len(raw))
    if not MIN_LEN_RATIO <= ratio <= MAX_LEN_RATIO:
        raise RepairRejected(f"the correction is {ratio:.2f}x the raw "
                             f"chunk's length (allowed {MIN_LEN_RATIO}x-"
                             f"{MAX_LEN_RATIO}x)", code="length")
    copied = (_shingles(text, COPY_RUN_WORDS) & _shingles(context,
                                                          COPY_RUN_WORDS)) \
        - _shingles(raw, COPY_RUN_WORDS)
    if copied:
        raise RepairRejected(f"the reply repeats the context "
                             f"({' '.join(next(iter(copied)))!r})",
                             code="repeats_context")
    return text


def _cache_from_reply(reply):
    """{outcome, prefill_skipped, source} from the proxy's own `faxl` block.
    The exo path returns exo's reply unchanged (no block); then both are
    None and the source says where to look instead."""
    fx = reply.get("faxl") if isinstance(reply, dict) else None
    if not isinstance(fx, dict) or "cache" not in fx:
        return {"outcome": None, "prefill_skipped": None,
                "source": "not in the reply; see /api/requests"}
    raw = str(fx.get("cache") or "")
    outcome = ("HIT" if raw.startswith("warm") else
               "MISS" if raw.startswith("cold") else raw or None)
    pt = (reply.get("usage") or {}).get("prompt_tokens")
    paid = fx.get("prefilled_tokens")
    skipped = (pt - paid) if isinstance(pt, int) and isinstance(paid, int) \
        else None
    return {"outcome": outcome, "prefill_skipped": skipped, "detail": raw,
            "source": "reply.faxl"}


class RepairSessions:
    """Per-session transcript (`frozen`) and context start, server side. A
    session lock is held across the model call: chunks of one session repair
    in order."""

    def __init__(self):
        self._lock = threading.Lock()
        self._s = {}

    def _get(self, sid):
        with self._lock:
            s = self._s.get(sid)
            if s is None:
                if len(self._s) >= MAX_SESSIONS:
                    oldest = min(self._s, key=lambda k: self._s[k]["used"])
                    del self._s[oldest]
                s = self._s[sid] = {"frozen": "", "start": 0, "chunks": 0,
                                    "used": time.time(),
                                    "lock": threading.Lock()}
            s["used"] = time.time()
            return s

    def reset(self, sid):
        with self._lock:
            return self._s.pop(sid, None) is not None

    def peek(self, sid):
        with self._lock:
            s = self._s.get(sid)
            return None if s is None else {"frozen": s["frozen"],
                                           "context_start": s["start"],
                                           "chunks": s["chunks"]}

    def repair(self, sid, raw, endpoint, model, timeout):
        """Correct `raw` and append it -- corrected, or raw when the
        correction failed -- to session `sid`. Only a malformed request
        (bad session id, empty or oversized raw) raises; every model or
        proxy failure is returned as corrected=None with the reason."""
        if not _SESSION_RE.match(sid or ""):
            raise ValueError("session must be 1-64 characters of A-Z a-z 0-9 _ -")
        raw = (raw or "").strip()
        if not raw:
            raise ValueError("raw is empty")
        if len(raw) > MAX_RAW_CHARS:
            raise ValueError(f"raw is {len(raw)} characters; the limit is "
                             f"{MAX_RAW_CHARS}")
        s = self._get(sid)
        with s["lock"]:
            start = context_start(s["frozen"], s["start"])
            context = s["frozen"][start:]
            body = {"model": model, "messages": build_messages(context, raw),
                    "temperature": 0, "max_tokens": max_tokens_for(raw),
                    "stream": False}
            t0 = time.time()
            corrected = reason = code = None
            cache = {"outcome": None, "prefill_skipped": None,
                     "source": "no reply"}
            try:
                if not model:
                    raise RepairUnavailable(
                        "no serving model configured; the repair step runs "
                        "on the model the proxy serves", code="no_model")
                reply = post_chat(endpoint, body, timeout)
                cache = _cache_from_reply(reply)
                text = (((reply.get("choices") or [{}])[0].get("message")
                         or {}).get("content") or "")
                corrected = check_correction(raw, text, context)
            except Exception as exc:  # noqa: BLE001 -- returned as `reason`
                reason = f"{type(exc).__name__}: {exc}"
                code = getattr(exc, "code", None) or type(exc).__name__
            added = corrected if corrected is not None else raw
            s["frozen"] = s["frozen"] + " " + added if s["frozen"] else added
            s["start"] = start
            s["chunks"] += 1
            return {"session": sid, "chunk": s["chunks"], "raw": raw,
                    "corrected": corrected, "reason": reason,
                    "reason_code": code, "text_added": added,
                    "final": s["frozen"], "text": s["frozen"],
                    "context_start": start, "context_chars": len(context),
                    "cache": cache, "elapsed_s": round(time.time() - t0, 3),
                    "prompt": body}


def post_chat(endpoint, body, timeout):
    """POST to the proxy's /v1/chat/completions. RepairUnavailable names the
    endpoint and what went wrong; there is no second place to try."""
    req = urllib.request.Request(
        endpoint, data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json",
                 # The request log and the per-project counters tag it.
                 "X-Faxl-Project": "voice2text"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode(errors="replace")[:300]
        raise RepairUnavailable(f"{endpoint} answered HTTP {exc.code}: "
                                f"{detail}", code=f"http_{exc.code}") from exc
    except ValueError as exc:
        raise RepairUnavailable(f"{endpoint} answered with no JSON: {exc}",
                                code="bad_json") from exc
    except (urllib.error.URLError, OSError) as exc:
        raise RepairUnavailable(f"{endpoint} unreachable: "
                                f"{type(exc).__name__}: {exc}",
                                code="unreachable") from exc


def chat_endpoint(bind):
    """The proxy's own chat URL from its bind address; a wildcard bind is
    reached on loopback."""
    host, _, port = (bind or "127.0.0.1:8767").rpartition(":")
    host = host.strip("[]")
    if host in ("", "0.0.0.0", "::", "localhost"):
        host = "127.0.0.1"
    if ":" in host:
        host = f"[{host}]"
    return f"http://{host}:{port or '8767'}/v1/chat/completions"



# ---- save recording ---------------------------------------------------------------
# OFF BY DEFAULT. A session is saved only after POST /api/voice/session/save
# {"session": id, "save": true} (loopback only, like every write here); that
# is the ONE switch -- transcribe takes no save flag of its own. While it is
# on, every chunk transcribed in that session is kept under
#
#     <voice_dir>/<YYYY-MM-DD_HHMMSS>_<session[:8]>/      (0700; UTC time of
#         audio.wav   16 kHz mono int16 PCM, every chunk      the first chunk)
#                     appended; the RIFF and data sizes are
#                     rewritten after each append, so the
#                     file is a valid WAV at every moment
#         raw.txt     "[<offset_s>s] <raw whisper text>", one line per chunk
#         final.txt   the corrected transcript as it stands (frozen + tail),
#                     rewritten after each repair
#         meta.json   session, started, language, speech model, repair
#                     model, and per chunk: offset_s, duration_s, raw,
#                     repaired, cache outcome / prefill_skipped, elapsed_s
#
# every file 0600. voice_dir is $FAXL_HOME/voice, else ~/.faxl/voice. The
# directory is made at the first saved chunk, so switching saving on and
# never speaking writes nothing. Offsets are positions in audio.wav (the sum
# of the saved chunks' durations), not wall-clock time: pauses the page cut
# out are not in the file. "repaired" is the chunk's text as its OWN repair
# returned it; later repairs may still correct it inside the tail, and
# final.txt always has the latest.

SAVE_FILES = {"audio.wav": "audio/wav",
              "raw.txt": "text/plain; charset=utf-8",
              "final.txt": "text/plain; charset=utf-8",
              "meta.json": "application/json",
              "full.txt": "text/plain; charset=utf-8"}

# ---- the backup recording ----------------------------------------------------------
# WHY. The live path (ScriptProcessorNode -> VAD -> chunks) can stop without
# any error: on 2026-09-22 in DuckDuckGo (WebKit) onaudioprocess stopped
# firing ~75 s into a 5-minute dictation and 45.5 s of speech was all that
# reached the server. So the page ALSO runs a MediaRecorder on the same
# microphone stream and posts its pieces, in order, to
#     POST /api/voice/session/<id>/backup?seq=N&part=P
# where they are appended to one file per part. At Stop the page calls
#     POST /api/voice/session/<id>/finalize
# which decodes the backup with ffmpeg to 16 kHz mono PCM and transcribes the
# WHOLE recording with the same engine: that text is authoritative.
#
# WHERE IT IS WRITTEN (decided at the session's first piece, seq 0):
#   Save recording ON   <session folder>/backup.<ext> (kept, like audio.wav)
#   Save recording OFF  <voice_dir>/tmp/<session>/backup.<ext>, 0700/0600,
#                       deleted on POST /api/voice/session/reset and, for
#                       pages closed without a reset, at the next proxy start.
# A part is one MediaRecorder run: if the page has to restart the recorder
# (the microphone track ended) it starts part P+1 in backup-<P+1>.<ext>,
# because a second recorder's pieces are not a continuation of the first
# file. finalize decodes the parts in order and joins the audio.
#
# LIMITS. A 5 s piece is ~20 KB of Opus (Chrome, Firefox) and ~100-160 KB of
# AAC at WebKit's 128-256 kb/s; MAX_BACKUP_PIECE_BYTES (8 MiB) is 50x the
# largest of those, a guard against a runaway body, not a size to reach.
# MAX_BACKUP_BYTES (1 GiB) is ~9 h at 256 kb/s.
BACKUP_TYPES = {"audio/webm": "webm", "audio/mp4": "m4a", "audio/ogg": "ogg"}
_BACKUP_MIME = {v: k for k, v in BACKUP_TYPES.items()}
_BACKUP_NAME_RE = re.compile(r"^backup(?:-([2-9]|[1-9]\d{1,2}))?\.(webm|m4a|ogg)$")
MAX_BACKUP_PIECE_BYTES = 8 * 1024 * 1024
MAX_BACKUP_BYTES = 1024 ** 3
MAX_BACKUP_PARTS = 99


def saved_file_mime(name):
    """The Content-Type for a saved file name, or None when the name is not
    one this module writes (the download route's allow-list)."""
    if name in SAVE_FILES:
        return SAVE_FILES[name]
    m = _BACKUP_NAME_RE.match(name or "")
    return _BACKUP_MIME[m.group(2)] if m else None


def backup_tmp_dir(root=None):
    return os.path.join(root or voice_dir(), "tmp")


class Backup:
    """One session's backup recording: parts appended in seq order."""

    def __init__(self, sid, directory, temp):
        self.sid, self.dir, self.temp = sid, directory, temp
        self.parts = []           # [{"path", "name", "mime", "bytes", "pieces"}]
        self.next_seq = 0
        self.bytes = 0
        self.lock = threading.Lock()

    def append(self, seq, part, mime, data):
        with self.lock:
            if seq < self.next_seq:
                # A retry of a piece that was stored but whose reply was lost.
                return {"duplicate": True, "next_seq": self.next_seq}
            if seq != self.next_seq:
                raise BackupOrderError(f"backup piece {seq} arrived, expected "
                                       f"{self.next_seq}: a gap would corrupt "
                                       f"the recording")
            if part == len(self.parts):
                if part >= MAX_BACKUP_PARTS:
                    raise ValueError(f"more than {MAX_BACKUP_PARTS} parts")
                ext = BACKUP_TYPES[mime]
                name = (f"backup.{ext}" if part == 0
                        else f"backup-{part + 1}.{ext}")
                self.parts.append({"path": os.path.join(self.dir, name),
                                   "name": name, "mime": mime, "bytes": 0,
                                   "pieces": 0})
            elif part != len(self.parts) - 1:
                raise BackupOrderError(f"backup part {part} arrived, current "
                                       f"part is {len(self.parts) - 1}")
            p = self.parts[part]
            if mime != p["mime"]:
                raise ValueError(f"part {part} is {p['mime']}; a {mime} piece "
                                 f"cannot be appended to it")
            if self.bytes + len(data) > MAX_BACKUP_BYTES:
                raise ValueError(f"the backup would pass {MAX_BACKUP_BYTES} "
                                 f"bytes; start a new session")
            fd = _open_private(p["path"], os.O_WRONLY | os.O_APPEND
                               | os.O_CREAT)
            with os.fdopen(fd, "ab") as fh:
                fh.write(data)
            p["bytes"] += len(data)
            p["pieces"] += 1
            self.bytes += len(data)
            self.next_seq += 1
            return {"duplicate": False, "next_seq": self.next_seq,
                    "file": p["path"], "part_bytes": p["bytes"]}


def decode_to_pcm16(path):
    """(16 kHz mono int16 PCM, ffmpeg's warnings) for an audio file, through
    ffmpeg. FfmpegMissing when it is not on PATH -- there is no second
    decoder. No timeout: ffmpeg reading a finite local file ends, and any
    fixed limit would be a guess about the recording's length."""
    exe = shutil.which("ffmpeg")
    if not exe:
        raise FfmpegMissing(
            f"ffmpeg is not installed (not on PATH), so the backup recording "
            f"{os.path.basename(path)} cannot be decoded and the whole "
            f"recording cannot be transcribed. Install it (brew install "
            f"ffmpeg on macOS, sudo apt install ffmpeg on Linux) and restart "
            f"the proxy; the backup file is kept.", code="ffmpeg_missing")
    r = subprocess.run([exe, "-nostdin", "-hide_banner", "-v", "error",
                        "-i", path, "-f", "s16le", "-acodec", "pcm_s16le",
                        "-ac", "1", "-ar", str(SAMPLE_RATE), "pipe:1"],
                       capture_output=True)
    err = r.stderr.decode(errors="replace").strip()
    if not r.stdout:
        raise DecodeFailed(f"ffmpeg decoded no audio from "
                           f"{os.path.basename(path)} (exit {r.returncode}): "
                           f"{err[:300]}", code="decode_failed")
    pcm = r.stdout[:len(r.stdout) - len(r.stdout) % 2]
    # A truncated last piece (page closed mid-write) decodes with warnings
    # and a non-zero exit; the audio before it is real and is returned, the
    # warnings travel with it.
    #
    # A CLEAN DECODE REPORTS NOTHING. ffmpeg writes to stderr on exit 0 for
    # things that are not faults -- a browser's MediaRecorder leaves a few
    # malformed packets at the container boundary, so every webm recording
    # produced "[opus @ 0x...] Error parsing Opus packet header" while
    # decoding perfectly. That reached the page verbatim.
    #
    # Two things were wrong with it. Raw decoder stderr and a heap address
    # are no use to the person reading a transcript; and on a page whose
    # whole argument is that nothing leaves the machine, an unexplained
    # "Opus" reads like a cloud model rather than the audio codec inside
    # every .webm. (AM saw exactly that.) Surfaced only when ffmpeg actually
    # fails, which is when it is diagnostic rather than alarming.
    return pcm, (f"exit {r.returncode}: {err[:300]}" if r.returncode else None)
_WAV_HEADER_BYTES = 44
# RIFF sizes are 32-bit: past this the header cannot describe the file.
_WAV_MAX_DATA = 0xFFFFFFFF - (_WAV_HEADER_BYTES - 8)


def voice_dir():
    """$FAXL_HOME/voice, else ~/.faxl/voice. Read at call time."""
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "voice")


def _wav_header(data_bytes, sample_rate=SAMPLE_RATE):
    import struct
    return struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36 + data_bytes,
                       b"WAVE", b"fmt ", 16, 1, 1, sample_rate,
                       sample_rate * 2, 2, 16, b"data", data_bytes)


def _open_private(path, flags):
    fd = os.open(path, flags, 0o600)
    os.fchmod(fd, 0o600)      # a pre-existing file or a umask cannot widen it
    return fd


def wav_append(path, pcm16_bytes, sample_rate=SAMPLE_RATE):
    """Append PCM to a 16-bit mono WAV (made if absent) and rewrite the RIFF
    and data sizes, so the file is valid after every call. Returns the data
    size in bytes after the append."""
    if len(pcm16_bytes) % 2:
        raise ValueError("PCM has an odd number of bytes")
    import struct
    fd = _open_private(path, os.O_RDWR | os.O_CREAT)
    with os.fdopen(fd, "r+b") as fh:
        fh.seek(0, os.SEEK_END)
        size = fh.tell()
        if size == 0:
            fh.write(_wav_header(0, sample_rate))
            size = _WAV_HEADER_BYTES
        elif size < _WAV_HEADER_BYTES:
            raise ValueError(f"{path} is {size} bytes: not a WAV this wrote")
        data = size - _WAV_HEADER_BYTES + len(pcm16_bytes)
        if data > _WAV_MAX_DATA:
            raise ValueError(f"{path} would pass the WAV format's 4 GiB "
                             f"limit; start a new session")
        fh.write(pcm16_bytes)
        fh.seek(4)
        fh.write(struct.pack("<I", 36 + data))
        fh.seek(40)
        fh.write(struct.pack("<I", data))
    return data


def _write_private(path, text):
    """Write text via a 0600 temp file and rename it over `path`."""
    tmp = path + ".tmp"
    fd = _open_private(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


class Recording:
    """One saved session's files. Every method holds the recording's lock."""

    def __init__(self, sid, root=None):
        self.sid = sid
        self.root = root or voice_dir()
        self.dir = None           # made at the first chunk
        self.meta = None
        self.lock = threading.Lock()

    def _make_dir(self, now):
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        os.chmod(self.root, 0o700)
        stamp = time.strftime("%Y-%m-%d_%H%M%S", time.gmtime(now))
        base = os.path.join(self.root, f"{stamp}_{self.sid[:8]}")
        path, n = base, 1
        while True:
            try:
                os.mkdir(path, 0o700)
                break
            except FileExistsError:
                n += 1
                path = f"{base}-{n}"
        os.chmod(path, 0o700)
        return path

    def _write_meta(self):
        _write_private(os.path.join(self.dir, "meta.json"),
                       json.dumps(self.meta, indent=1, ensure_ascii=False)
                       + "\n")

    def _ensure_locked(self):
        if self.dir is None:
            now = time.time()
            self.dir = self._make_dir(now)
            self.meta = {
                "session": self.sid,
                "started": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                         time.gmtime(now)),
                "started_epoch": round(now, 3),
                "language": None,
                "speech_model": None,
                "repair_model": None,
                "sample_rate": SAMPLE_RATE,
                "format": "WAV, PCM int16 little-endian, mono",
                "chunks": []}
            _write_private(os.path.join(self.dir, "raw.txt"), "")
            _write_private(os.path.join(self.dir, "final.txt"), "")
            self._write_meta()

    def ensure_dir(self):
        """The session folder, made now if no chunk has made it yet (the
        backup recording's first piece can arrive before the first chunk)."""
        with self.lock:
            self._ensure_locked()
            return self.dir

    def add_full(self, res):
        """Record the whole-recording transcript: full.txt and meta."""
        with self.lock:
            self._ensure_locked()
            _write_private(os.path.join(self.dir, "full.txt"),
                           (res.get("full_text") or "") + "\n")
            self.meta["full_recording"] = {
                k: res.get(k) for k in ("audio_s", "elapsed_s", "decode_s",
                                        "parts", "backup_bytes",
                                        "decode_warnings")}
            self._write_meta()
            return self.dir

    def add_chunk(self, pcm16_bytes, tx, speech_model, repair_model,
                  language):
        """Append one transcribed chunk: audio, raw line, meta entry."""
        with self.lock:
            self._ensure_locked()
            for k, v in (("language", language),
                         ("speech_model", speech_model)):
                if self.meta.get(k) is None:
                    self.meta[k] = v
            offset = sum(c["duration_s"] for c in self.meta["chunks"])
            wav_append(os.path.join(self.dir, "audio.wav"), pcm16_bytes)
            raw = tx.get("text") or ""
            fd = _open_private(os.path.join(self.dir, "raw.txt"),
                               os.O_WRONLY | os.O_APPEND | os.O_CREAT)
            with os.fdopen(fd, "a", encoding="utf-8") as fh:
                fh.write(f"[{offset:.3f}s] {raw}\n")
            chunk = {"n": len(self.meta["chunks"]) + 1,
                     "offset_s": round(offset, 3),
                     "duration_s": round(len(pcm16_bytes) / 2 / SAMPLE_RATE,
                                         3),
                     "raw": raw, "language": tx.get("language"),
                     "elapsed_s": tx.get("elapsed_s"),
                     "repaired": None, "repair_reason": None,
                     "repair_state": None, "cache": None,
                     "prefill_skipped": None, "repair_elapsed_s": None}
            self.meta["chunks"].append(chunk)
            if repair_model and not self.meta.get("repair_model"):
                self.meta["repair_model"] = repair_model
            self._write_meta()
            return {"dir": self.dir, "chunk": chunk["n"],
                    "files": sorted(SAVE_FILES)}

    def add_repair(self, raw, out, repair_model):
        """Record a repair outcome: the oldest chunk not yet repaired with
        this raw text gets its corrected text (None when the correction
        failed and the raw text was kept), the reason, and the cache
        outcome; final.txt is rewritten with the transcript as it stands."""
        with self.lock:
            if self.dir is None:
                return None
            raw = (raw or "").strip()
            for c in self.meta["chunks"]:
                if c.get("repair_state") is None and c["raw"].strip() == raw:
                    c["repaired"] = out.get("corrected")
                    c["repair_reason"] = out.get("reason")
                    c["repair_state"] = ("corrected" if out.get("corrected")
                                         is not None else "kept raw")
                    cache = out.get("cache") or {}
                    c["cache"] = cache.get("outcome")
                    c["prefill_skipped"] = cache.get("prefill_skipped")
                    c["repair_elapsed_s"] = out.get("elapsed_s")
                    break
            if repair_model:
                self.meta["repair_model"] = repair_model
            _write_private(os.path.join(self.dir, "final.txt"),
                           (out.get("text") or "") + "\n")
            self._write_meta()
            return self.dir


def find_saved_dir(sid, root=None):
    """The saved directory for session `sid`: newest one whose meta.json
    names it. The session id is checked against _SESSION_RE first, and only
    direct children of voice_dir are looked at."""
    if not _SESSION_RE.match(sid or ""):
        return None
    root = root or voice_dir()
    try:
        names = sorted(os.listdir(root), reverse=True)
    except OSError:
        return None
    for n in names:
        if not n.endswith(sid[:8]) and f"_{sid[:8]}-" not in n:
            continue
        d = os.path.join(root, n)
        try:
            with open(os.path.join(d, "meta.json"), encoding="utf-8") as fh:
                if json.load(fh).get("session") == sid:
                    return d
        except (OSError, ValueError):
            continue
    return None


# ---- routes ---------------------------------------------------------------------
# BODY LIMITS, and why these numbers:
#   transcribe  MAX_PCM_BYTES = 1,920,000 = 60 s of 16 kHz int16 mono
#               (32,000 B/s). The page cuts at pauses, so a chunk is a few
#               seconds; 60 s is the longest unbroken speech worth taking in
#               one piece (two of Whisper's 30 s windows) and bounds memory.
#   repair etc. MAX_JSON_BYTES = 16 KiB: MAX_RAW_CHARS (4,000) of UTF-8 text is
#               at most 16,000 bytes; the JSON wrapper fits in the rest.
MAX_PCM_BYTES = 60 * SAMPLE_RATE * 2
MAX_JSON_BYTES = 16 * 1024

# Repair timeout: the worst case is max_tokens (4,096) decoded at ~20 tok/s on
# the smallest default model (~205 s) plus the prefill of a long frozen
# transcript on a cold cache. 300 s covers that; a shorter one would cut off a
# legitimate long repair, and the call is per chunk, not per session.
REPAIR_TIMEOUT_S = 300


def register_voice_routes(bp, *, caller_is_local, serving_model, bind,
                          backend_name, config_dir, engine_factory=None,
                          decoder=None):
    """Add the /api/voice/* routes to the console blueprint.

    caller_is_local  () -> bool; every POST is refused (403) otherwise
    serving_model    () -> str, the model the proxy serves (the repair model)
    bind             the proxy's bind address; repairs go to its own
                     /v1/chat/completions
    config_dir       the console's config dir; the job state lives in
                     <config_dir>/voice/ (saved recordings do NOT: they are
                     under voice_dir(), see "save recording" above)
    engine_factory   (model_id) -> loaded Engine. TESTS ONLY; the default is
                     make_engine, which only ever picks an engine from ENGINES.
    decoder          (path) -> (pcm16 bytes, warnings). TESTS ONLY; the
                     default is decode_to_pcm16 (ffmpeg, named error if absent).
    """
    from flask import jsonify, request

    factory = engine_factory or make_engine
    decode = decoder or decode_to_pcm16
    backups = {}                # sid -> Backup
    bk_lock = threading.Lock()
    bp.voice_backups = backups
    # Backups of Save-off sessions whose page closed without a reset: the
    # owner did not ask to keep them, so they go at the next start.
    tmp_root = backup_tmp_dir()
    try:
        for n in os.listdir(tmp_root):
            if _SESSION_RE.match(n):
                shutil.rmtree(os.path.join(tmp_root, n))
    except FileNotFoundError:
        pass
    state_dir = os.path.join(os.path.expanduser(config_dir), "voice")
    sessions = RepairSessions()
    engines = {}                # model_id -> loaded engine (one at a time)
    eng_lock = threading.Lock()
    endpoint = chat_endpoint(bind)
    bp.voice_sessions = sessions   # for tests and the page's future reads
    recordings = {}             # sid -> {"on": bool, "rec": Recording}
    rec_lock = threading.Lock()
    bp.voice_recordings = recordings

    def _recording(sid, on_only):
        with rec_lock:
            r = recordings.get(sid) if sid else None
        if r is None or (on_only and not r["on"]):
            return None
        return r["rec"]

    def _local_only():
        if not caller_is_local():
            return jsonify({"ok": False, "error": "Voice2Text is used from "
                            "this machine only"}), 403
        return None

    def _json_body():
        n = request.content_length
        if n is not None and n > MAX_JSON_BYTES:
            return None, (jsonify({"ok": False, "error":
                                   f"body is {n} bytes; the limit is "
                                   f"{MAX_JSON_BYTES}"}), 413)
        data = request.get_data(cache=False)
        if len(data) > MAX_JSON_BYTES:
            return None, (jsonify({"ok": False, "error":
                                   f"body over {MAX_JSON_BYTES} bytes"}), 413)
        try:
            body = json.loads(data.decode() or "{}")
        except (ValueError, UnicodeDecodeError):
            return None, (jsonify({"ok": False, "error":
                                   "body must be JSON"}), 400)
        if not isinstance(body, dict):
            return None, (jsonify({"ok": False, "error":
                                   "body must be a JSON object"}), 400)
        return body, None

    def _engine(model_id):
        with eng_lock:
            e = engines.get(model_id)
            if e is None:
                engines.clear()   # one speech model resident at a time
                e = engines[model_id] = factory(model_id)
            return e

    def _repair(sid, raw):
        # Never raises for a model or proxy failure: the session keeps the
        # raw chunk and the reply says why (see the REPAIR section).
        m = serving_model()
        out = sessions.repair(sid, raw, endpoint, m, REPAIR_TIMEOUT_S)
        out.pop("prompt", None)
        # A recording that has files keeps final.txt current even if saving
        # was switched off after its chunk was saved; one that never saved a
        # chunk writes nothing (add_repair returns None).
        rec = _recording(sid, on_only=False)
        if rec is not None:
            try:
                d = rec.add_repair(raw, out, m)
            except OSError as exc:
                # The transcript advanced; only the files are behind. Said
                # in the reply, not turned into a failed repair.
                out["save_error"] = (f"SaveFailed: final.txt/meta.json could "
                                     f"not be written: {exc}")
                d = None
            if d:
                out["saved"] = {"dir": d, "files": sorted(SAVE_FILES)}
        return out

    def _err(exc):
        code = {EngineMissing: 501, ModelNotDownloaded: 409,
                FfmpegMissing: 501, BackupOrderError: 409,
                RepairUnavailable: 502}.get(
                    type(exc), 400 if isinstance(exc, (ValueError, KeyError))
                    else 500)
        return {"ok": False, "error": str(exc).strip("'\""),
                "error_type": type(exc).__name__}, code

    @bp.route("/api/voice/status", methods=["GET"])
    def api_voice_status():
        try:
            st = status(request.args.get("model") or None,
                        serving_model=serving_model(),
                        backend_name=backend_name)
        except KeyError as exc:
            return jsonify({"ok": False, "error": str(exc).strip("'\"")}), 400
        st["download"] = download_status(state_dir)
        st["ok"] = True
        return jsonify(st)

    @bp.route("/api/voice/download", methods=["POST"])
    def api_voice_download():
        refused = _local_only()
        if refused:
            return refused
        body, bad = _json_body()
        if bad:
            return bad
        mid = str(body.get("model_id") or DEFAULT_MODEL_ID)
        try:
            code, payload = start_download(mid, state_dir)
        except EngineMissing as exc:
            p, c = _err(exc)
            return jsonify(p), c
        return jsonify(payload), code

    @bp.route("/api/voice/download/status", methods=["GET"])
    def api_voice_download_status():
        return jsonify(download_status(state_dir))

    @bp.route("/api/voice/transcribe", methods=["POST"])
    def api_voice_transcribe():
        refused = _local_only()
        if refused:
            return refused
        ctype = (request.mimetype or "").lower()
        if ctype != "application/octet-stream":
            return jsonify({"ok": False, "error": "send raw little-endian "
                            "int16 PCM at 16 kHz as application/octet-stream"
                            }), 415
        n = request.content_length
        if n is not None and n > MAX_PCM_BYTES:
            return jsonify({"ok": False, "error":
                            f"audio is {n} bytes; the limit is "
                            f"{MAX_PCM_BYTES} (60 s at 16 kHz)"}), 413
        pcm = request.stream.read(MAX_PCM_BYTES + 1)
        if len(pcm) > MAX_PCM_BYTES:
            return jsonify({"ok": False, "error":
                            f"audio over {MAX_PCM_BYTES} bytes"}), 413
        if not pcm or len(pcm) % 2:
            return jsonify({"ok": False, "error": "empty or odd-length PCM"
                            }), 400
        lang = (request.args.get("language") or "").strip() or None
        if lang is not None and lang not in LANGUAGE_CODES:
            return jsonify({"ok": False, "error":
                            f"language must be one of "
                            f"{', '.join(LANGUAGE_CODES)} or omitted"}), 400
        mid = request.args.get("model") or DEFAULT_MODEL_ID
        sid = request.args.get("session") or None
        prompt = request.args.get("prompt") or None
        try:
            out = _engine(mid).transcribe(pcm, SAMPLE_RATE, lang, prompt)
        except (VoiceError, ValueError, KeyError) as exc:
            p, c = _err(exc)
            return jsonify(p), c
        out.update(ok=True, model=mid, language_requested=lang)
        rec = _recording(sid, on_only=True)
        if rec is not None:
            try:
                out["saved"] = rec.add_chunk(pcm, out, mid, serving_model(),
                                             lang)
            except (OSError, ValueError) as exc:
                p, c = _err(SaveFailed(f"transcribed, but the recording "
                                       f"could not be saved: {exc}"))
                p["raw"] = out["text"]
                p["transcript"] = out
                return jsonify(p), c
        if sid and out["text"] and request.args.get("repair", "1") != "0":
            try:
                out["repair"] = _repair(sid, out["text"])
            except (VoiceError, ValueError) as exc:
                # The raw text is returned WITH the failure, not in place of
                # a repair: the status says the repair did not happen.
                p, c = _err(exc)
                p["raw"] = out["text"]
                p["transcript"] = out
                return jsonify(p), c
        return jsonify(out)

    @bp.route("/api/voice/repair", methods=["POST"])
    def api_voice_repair():
        refused = _local_only()
        if refused:
            return refused
        body, bad = _json_body()
        if bad:
            return bad
        try:
            out = _repair(str(body.get("session") or ""),
                          str(body.get("raw") or ""))
        except (VoiceError, ValueError) as exc:
            p, c = _err(exc)
            return jsonify(p), c
        out["ok"] = True
        return jsonify(out)

    @bp.route("/api/voice/session/reset", methods=["POST"])
    def api_voice_session_reset():
        refused = _local_only()
        if refused:
            return refused
        body, bad = _json_body()
        if bad:
            return bad
        sid = str(body.get("session") or "")
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        with rec_lock:
            recordings.pop(sid, None)   # saved files stay on disk
        with bk_lock:
            b = backups.pop(sid, None)
        deleted = None
        if b is not None and b.temp:
            with b.lock:
                shutil.rmtree(b.dir, ignore_errors=True)
            deleted = not os.path.exists(b.dir)
        return jsonify({"ok": True, "session": sid,
                        "existed": sessions.reset(sid),
                        "backup_deleted": deleted})

    # ---- the backup recording (see "the backup recording" above) ----
    @bp.route("/api/voice/session/<sid>/backup", methods=["POST"])
    def api_voice_backup(sid):
        refused = _local_only()
        if refused:
            return refused
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        mime = (request.mimetype or "").lower()
        if mime not in BACKUP_TYPES:
            return jsonify({"ok": False, "error": "send a MediaRecorder piece "
                            "as " + ", ".join(BACKUP_TYPES)}), 415
        try:
            seq = int(request.args.get("seq", ""))
            part = int(request.args.get("part", "0"))
            if seq < 0 or part < 0:
                raise ValueError
        except ValueError:
            return jsonify({"ok": False, "error": "seq and part must be "
                            "integers >= 0"}), 400
        n = request.content_length
        if n is not None and n > MAX_BACKUP_PIECE_BYTES:
            return jsonify({"ok": False, "error": f"piece is {n} bytes; the "
                            f"limit is {MAX_BACKUP_PIECE_BYTES}"}), 413
        data = request.stream.read(MAX_BACKUP_PIECE_BYTES + 1)
        if len(data) > MAX_BACKUP_PIECE_BYTES:
            return jsonify({"ok": False, "error": f"piece over "
                            f"{MAX_BACKUP_PIECE_BYTES} bytes"}), 413
        if not data:
            return jsonify({"ok": False, "error": "empty piece"}), 400
        with bk_lock:
            b = backups.get(sid)
            if b is None:
                if seq != 0:
                    return jsonify({"ok": False, "error_type":
                                    "BackupOrderError", "error":
                                    f"no backup for session {sid} on the "
                                    f"server (did the proxy restart?); piece "
                                    f"{seq} cannot start one"}), 409
                rec = _recording(sid, on_only=True)
                try:
                    if rec is not None:
                        d, temp = rec.ensure_dir(), False
                    else:
                        d, temp = os.path.join(backup_tmp_dir(), sid), True
                        os.makedirs(d, mode=0o700, exist_ok=True)
                        os.chmod(os.path.dirname(d), 0o700)
                        os.chmod(d, 0o700)
                except OSError as exc:
                    p, c = _err(SaveFailed(f"the backup folder could not be "
                                           f"made: {exc}"))
                    return jsonify(p), c
                b = backups[sid] = Backup(sid, d, temp)
        try:
            r = b.append(seq, part, mime, data)
        except (VoiceError, ValueError) as exc:
            p, c = _err(exc)
            return jsonify(p), 413 if "would pass" in p["error"] else c
        except OSError as exc:
            p, c = _err(SaveFailed(f"the backup piece could not be written: "
                                   f"{exc}"))
            return jsonify(p), c
        r.update(ok=True, session=sid, seq=seq, part=part, temp=b.temp,
                 bytes=b.bytes)
        return jsonify(r)

    @bp.route("/api/voice/session/<sid>/finalize", methods=["POST"])
    def api_voice_finalize(sid):
        refused = _local_only()
        if refused:
            return refused
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        # navigator.sendBeacon posts text/plain; the body is JSON either way.
        body, bad = _json_body()
        if bad:
            return bad
        lang = (str(body.get("language") or "")).strip() or None
        if lang is not None and lang not in LANGUAGE_CODES:
            return jsonify({"ok": False, "error":
                            f"language must be one of "
                            f"{', '.join(LANGUAGE_CODES)} or omitted"}), 400
        mid = str(body.get("model") or DEFAULT_MODEL_ID)
        prompt = str(body.get("prompt") or "") or None
        with bk_lock:
            b = backups.get(sid)
        if b is None or not b.parts:
            return jsonify({"ok": False, "error": f"no backup recording for "
                            f"session {sid}"}), 404
        t0 = time.time()
        try:
            with b.lock:     # no piece is appended while a part is read
                parts = [dict(p) for p in b.parts]
                decoded = [decode(p["path"]) for p in parts]
            decode_s = round(time.time() - t0, 3)
            pcm = b"".join(d[0] for d in decoded)
            out = _engine(mid).transcribe(pcm, SAMPLE_RATE, lang, prompt)
        except (VoiceError, ValueError, KeyError) as exc:
            p, c = _err(exc)
            return jsonify(p), c
        res = {"ok": True, "session": sid, "full_text": out["text"],
               "audio_s": out["duration_s"], "elapsed_s": out["elapsed_s"],
               "decode_s": decode_s, "parts": len(parts),
               "backup_bytes": sum(p["bytes"] for p in parts),
               "backup_files": [p["path"] for p in parts],
               "backup_temp": b.temp, "language": out.get("language"),
               "model": mid,
               "decode_warnings": [f"{p['name']}: {d[1]}" for p, d in
                                   zip(parts, decoded) if d[1]]}
        if out.get("vocabulary"):
            res["vocabulary"] = out["vocabulary"]
        if not b.temp:
            rec = _recording(sid, on_only=False)
            try:
                if rec is not None:
                    res["saved"] = {"dir": rec.add_full(res),
                                    "file": "full.txt"}
                else:
                    _write_private(os.path.join(b.dir, "full.txt"),
                                   res["full_text"] + "\n")
                    res["saved"] = {"dir": b.dir, "file": "full.txt"}
            except OSError as exc:
                res["save_error"] = f"SaveFailed: full.txt not written: {exc}"
        return jsonify(res)

    # ---- save recording (see the section above register_voice_routes) ----
    @bp.route("/api/voice/session/save", methods=["POST"])
    def api_voice_session_save():
        refused = _local_only()
        if refused:
            return refused
        body, bad = _json_body()
        if bad:
            return bad
        sid = str(body.get("session") or "")
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        save = body.get("save")
        if not isinstance(save, bool):
            return jsonify({"ok": False, "error": "save must be true or "
                            "false"}), 400
        with rec_lock:
            r = recordings.get(sid)
            if r is None and save:
                if len(recordings) >= MAX_SESSIONS:
                    # The registry only says which sessions are saving; a
                    # dropped entry's files stay on disk and listable.
                    del recordings[next(iter(recordings))]
                r = recordings[sid] = {"on": True, "rec": Recording(sid)}
            elif r is not None:
                r["on"] = save
            d = r["rec"].dir if r else None
            root = r["rec"].root if r else voice_dir()
        return jsonify({"ok": True, "session": sid, "save": save,
                        "voice_dir": root, "dir": d})

    def _saved_dir(sid):
        rec = _recording(sid, on_only=False)
        if rec is not None and rec.dir:
            return rec.dir
        return find_saved_dir(sid)

    @bp.route("/api/voice/session/<sid>/files", methods=["GET"])
    def api_voice_session_files(sid):
        refused = _local_only()
        if refused:
            return refused
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        d = _saved_dir(sid)
        if not d:
            return jsonify({"ok": False, "error": f"no saved recording for "
                            f"session {sid}"}), 404
        files = []
        try:
            names = sorted(n for n in os.listdir(d) if saved_file_mime(n))
        except OSError:
            names = []
        for name in names:
            fp = os.path.join(d, name)
            if os.path.isfile(fp):
                files.append({"name": name, "bytes": os.path.getsize(fp),
                              "mimetype": saved_file_mime(name),
                              "url": f"/api/voice/session/{sid}/download"
                                     f"?file={name}"})
        return jsonify({"ok": True, "session": sid, "dir": d,
                        "files": files})

    @bp.route("/api/voice/session/<sid>/download", methods=["GET"])
    def api_voice_session_download(sid):
        from flask import send_file
        refused = _local_only()
        if refused:
            return refused
        if not _SESSION_RE.match(sid):
            return jsonify({"ok": False, "error": "session must be 1-64 "
                            "characters of A-Z a-z 0-9 _ -"}), 400
        name = request.args.get("file") or ""
        # A fixed list of names (and backup[-N].webm|m4a|ogg): nothing from
        # the URL reaches a path otherwise, so there is nothing to traverse
        # with.
        mimetype = saved_file_mime(name)
        if not mimetype:
            return jsonify({"ok": False, "error": "file must be one of "
                            + ", ".join(sorted(SAVE_FILES))
                            + " or backup.<webm|m4a|ogg>"}), 400
        d = _saved_dir(sid)
        fp = os.path.join(d, name) if d else None
        if not fp or not os.path.isfile(fp):
            return jsonify({"ok": False, "error": f"no {name} saved for "
                            f"session {sid}"}), 404
        rec = _recording(sid, on_only=False)
        lock = rec.lock if rec is not None and rec.dir == d else None
        if lock:
            with lock:     # never serve a WAV between data and header write
                with open(fp, "rb") as fh:
                    data = fh.read()
        else:
            with open(fp, "rb") as fh:
                data = fh.read()
        import io
        return send_file(io.BytesIO(data), mimetype=mimetype,
                         as_attachment=True,
                         download_name=f"{os.path.basename(d)}_{name}",
                         max_age=0)

    return bp

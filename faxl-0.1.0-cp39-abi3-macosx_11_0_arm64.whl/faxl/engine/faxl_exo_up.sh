#!/bin/bash
# faxl_exo_up.sh — faxl in front of an exo cluster. A WRAPPER NOW: faxl_start.sh is the launcher.
#
#   ./faxl_exo_up.sh [model]
#
# The backend used to be decided by WHICH of two scripts ran, with the model
# in FAXL_MODEL. Both now live in ~/.faxl/config.json, and faxl_start.sh
# starts whatever it says. This script is kept so the instructions, memory and
# fingers that know its name keep working: it records "exo" as the
# backend -- so the choice SURVIVES a restart from the console -- and hands
# over. [model], when given, is written to the config by faxl_start.sh.
#
# faxl in front, exo behind: the shape for a model too large for one box.
# With no model remembered for exo, it comes up on THE default
# (faxl_config.DEFAULT_MODEL, Qwen3-VL-4B, under 6 GB -- it runs anywhere);
# pick the big one from exo's catalogue in the console, where the fit check
# can size it against the cluster. (The exo default used to be Kimi Linear
# 48B, ~40 GB: a default that only a big machine holds is not a default.)
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${FAXL_PYTHON:-$(command -v python3)}"
export FAXL_PYTHON="$VENV"

"$VENV" -m faxl.engine.faxl_config --set backend=exo >/dev/null || {
  echo "FATAL: $VENV could not write the faxl config -- can it import faxl?"
  echo "       Pass FAXL_PYTHON=<interpreter>."
  exit 1; }
# Running faxl_exo_up.sh IS the choice of backend. A FAXL_BACKEND left exported in
# this shell would override the config just written and start the other one.
if [ -n "${FAXL_BACKEND:-}" ] && [ "$FAXL_BACKEND" != "exo" ]; then
  echo "note: FAXL_BACKEND=$FAXL_BACKEND ignored -- faxl_exo_up.sh means exo"
fi
unset FAXL_BACKEND

exec bash "$HERE/faxl_start.sh" "$@"

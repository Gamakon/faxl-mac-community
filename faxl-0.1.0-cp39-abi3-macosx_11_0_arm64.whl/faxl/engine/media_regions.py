# Vendored engine module (media_regions.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""media_regions.py — image identity for the prefix ladder.

An image does not appear in the token stream. A vision model expands one
image into N copies of a single pad id (Qwen-VL 151655, Gemma 3 262144) and
carries the picture in pixel embeddings alongside. So two prompts holding
completely different photographs produce BYTE-IDENTICAL token ids, and a
ladder that confirms a hit by comparing tokens confirms it happily.

Measured, before this existed: 134 of 141 photo requests collided and 24
different photographs were given one identical caption.

A MediaRegion says where an image sits in the token stream and what it was:

    MediaRegion(content_hash=<sha256 of decoded RGB pixels>,
                start_pos=<first pad index>,
                end_pos=<one past the last>)

BORROWED FROM exo, DELIBERATELY. exo's in-RAM KVPrefixCache already models
this exact shape (worker/engines/mlx/vision.py:186, cache.py:481) and its
`_validate_media_match` truncates a prefix match to the START of the first
region whose hash differs. This module is that idea applied to faxl's
PERSISTENT ladder, so one definition of image identity covers both the
in-RAM cache and the store.

WHY REGIONS AND NOT A MUTATED TOKEN ID. The first version of this folded 20
bits of hash into a fake token id at the head of each pad run. It worked, and
it was wrong twice: 20 bits collides at ~38% over a thousand photos (birthday
bound), and the pad-id set had to be GUESSED from the id stream. A region is
declared by the side that placed the embeddings, carries a full digest, and
knows where the image ENDS as well as where it starts.

THE END POSITION IS NOT DECORATION. It is what makes this case work:

    [instructions] [ex1][ex2][ex3][ex4][ex5] [the claim photo] [ask]

A car-insurance triage prompt shows five reference photographs of a broken
windscreen, then the customer's upload. The five examples are identical on
every claim; only the last image differs. Walking the regions in order, the
match runs PAST all five and truncates at the start of the sixth -- so the
expensive constant prefix (instructions plus five images) is a hit on every
claim, and only the customer's photo is paid for. Truncating at the first
image instead would re-prefill all five, every time.
"""
import hashlib
import io


class MediaRegion:
    """One image's span in the token stream, and what picture was there."""

    __slots__ = ("content_hash", "start_pos", "end_pos")

    def __init__(self, content_hash, start_pos, end_pos):
        self.content_hash = str(content_hash)
        self.start_pos = int(start_pos)
        self.end_pos = int(end_pos)

    def __repr__(self):
        return (f"MediaRegion({self.content_hash[:12]}..., "
                f"{self.start_pos}:{self.end_pos})")

    def __eq__(self, other):
        return (isinstance(other, MediaRegion)
                and self.content_hash == other.content_hash
                and self.start_pos == other.start_pos
                and self.end_pos == other.end_pos)

    def to_dict(self):
        return {"content_hash": self.content_hash,
                "start_pos": self.start_pos, "end_pos": self.end_pos}

    @classmethod
    def from_dict(cls, d):
        return cls(d.get("content_hash", ""),
                   d.get("start_pos", 0), d.get("end_pos", 0))


# A decompression bomb is a small file that decodes to gigabytes. The proxy
# decodes images from request bodies, so this is a remote-input path: cap the
# pixel count rather than trust the header. 64MP passes any real photograph
# (a 100MP phone panorama is the only thing that trips it) and refuses the
# attack. PIL's own default is 89.5MP with a warning; this refuses instead.
MAX_IMAGE_PIXELS = int(64e6)


class ImageDecodeError(ValueError):
    """The image could not be decoded, or was refused as too large."""


def hash_image_bytes(raw):
    """The canonical image identity: sha256 of DECODED RGB pixels.

    NOT the sha256 of the file, and NOT of its base64. The same photograph
    re-encoded as a different JPEG, or arriving as HEIC where it once arrived
    as JPG, is the SAME PICTURE to the model and must be the same cache key.
    Hashing the container makes that a miss; hashing the pixels makes it a
    hit.

    This must match exo's `_find_media_regions`
    (worker/engines/mlx/vision.py:712) byte for byte, because one side looks
    up what the other stored. exo does:

        img = Image.open(BytesIO(raw)).convert("RGB")
        hashlib.sha256(img.tobytes()).hexdigest()

    so this does exactly that and nothing else. Any normalisation added here
    -- a resize, an EXIF rotation, a colour profile -- silently stops the two
    agreeing, and the store fills with entries the other side can never find.

    Raises ImageDecodeError rather than returning a sentinel: a request whose
    image cannot be read must not quietly become a request with no image,
    which would key the ladder on the text alone and serve one photo's state
    for another.
    """
    try:
        from PIL import Image
    except ImportError as e:  # pragma: no cover - Pillow is a dependency
        raise ImageDecodeError(f"Pillow is required to hash images: {e}") from e

    try:
        img = Image.open(io.BytesIO(raw))
        w, h = img.size
        if w * h > MAX_IMAGE_PIXELS:
            raise ImageDecodeError(
                f"image is {w}x{h} = {w * h / 1e6:.0f}MP, over the "
                f"{MAX_IMAGE_PIXELS / 1e6:.0f}MP limit")
        img = img.convert("RGB")
        return hashlib.sha256(img.tobytes()).hexdigest()
    except ImageDecodeError:
        raise
    except Exception as e:  # noqa: BLE001 - any decoder failure, one answer
        raise ImageDecodeError(f"{type(e).__name__}: {e}") from e


def find_regions(token_ids, pad_ids, hashes, min_run=8, tokens_per_image=None):
    """Locate each image's pad run and attach the hash of the picture there.

    `hashes` are in prompt order, one per image, as the caller extracted them
    from the request body. The Nth image gets the Nth hash.

    `min_run` guards against ordinary text that happens to use a pad id: one
    stray occurrence is not an image, a run of eight is. An image with no hash
    left to attach gets "" -- unknown identity, which
    `truncate_to_first_mismatch` treats as never matching, because an image
    we cannot identify must not be assumed to be the same one.

    ADJACENT IMAGES ARE NOT ONE IMAGE. Two images next to each other are two
    pad runs with nothing between them unless the chat template separates
    them. Qwen3-VL does -- verified against its own tokenizer, an image
    renders as <|vision_start|><|image_pad|><|vision_end|> and two images
    tokenise to [151652, 151655, 151653, 151652, 151655, 151653], so the runs
    are always delimited. But that is THIS template's behaviour, and a model
    whose template emits bare pads back to back would fuse every image in the
    prompt into one region: five reference photographs plus a customer's
    upload would become a single block that mismatches wholesale, and the
    constant prefix a claim workload depends on would never be a hit.

    So when `tokens_per_image` is supplied -- the caller knows how many pad
    tokens each image expanded to -- a fused run is CUT at those counts rather
    than trusted to be one picture. Without it, a run is one image.
    """
    regions, pads = [], set(pad_ids)
    run_id, run_len, run_start = None, 0, 0
    ids = list(token_ids)
    counts = list(tokens_per_image or ())

    def close(end):
        if run_len < min_run or run_id not in pads:
            return
        # Split this run across however many images it actually holds.
        start = run_start
        while start < end:
            i = len(regions)
            n = counts[i] if i < len(counts) else (end - start)
            stop = min(start + n, end) if n > 0 else end
            regions.append(MediaRegion(
                hashes[i] if i < len(hashes) else "", start, stop))
            start = stop

    for i, t in enumerate(ids):
        if t == run_id:
            run_len += 1
        else:
            close(i)
            run_id, run_len, run_start = t, 1, i
    close(len(ids))
    return regions


def truncate_to_first_mismatch(match_length, cached_regions, query_regions):
    """Shorten a prefix match so it never runs into a DIFFERENT picture.

    Returns the length the match may safely keep. Regions are compared by
    start position: a region present in both at the same offset and with the
    same hash is the same image and the match continues past it. The first
    one that differs cuts the match to that region's start_pos -- before the
    image, never one token inside it, because a partially-restored image is
    state describing a picture that was never there.

    An empty hash on either side never matches: unidentified is not equal.

    This is exo's `_validate_media_match` (cache.py:481), kept deliberately
    equivalent so the in-RAM cache and the persistent store cannot disagree
    about which prefixes are reusable.
    """
    if not cached_regions:
        return match_length
    by_start = {r.start_pos: r for r in query_regions or ()}
    for cached in sorted(cached_regions, key=lambda r: r.start_pos):
        if cached.start_pos >= match_length:
            break
        q = by_start.get(cached.start_pos)
        if q is None:
            # The stored prefix had an image here and this prompt does not.
            # Whatever is at this offset now, it is not that picture.
            return cached.start_pos
        if not q.content_hash or not cached.content_hash \
                or q.content_hash != cached.content_hash:
            return cached.start_pos
    return match_length


# NO safe_depth(). A checkpoint INSIDE an image is correct, and refusing one
# would break the case this module exists for.
#
# The reasoning that argued for it: state covering half a picture looks wrong,
# so round the depth down to the image's start. The arithmetic kills it. A real
# insurance prompt -- 200 tokens of instructions, five reference photographs at
# ~1200 tokens each, then the claim photo -- is 7442 tokens, and of the 28
# multiples of SEG=256 inside it exactly ONE (7424) is clear of every image,
# past the claim photo and therefore useless as a shared prefix. Refusing
# mid-image depths leaves the five constant examples permanently uncacheable:
# the whole saving, gone.
#
# And it is not needed, because resuming mid-image is genuinely safe. exo's
# `patch_embed_tokens` (generator/generate.py:98) tracks an ABSOLUTE offset
# across prefill chunks and splices `embeddings[overlap_start:overlap_end]` by
# position, so a tail prefill beginning inside a pad run receives exactly the
# vision embeddings belonging to those positions. The grid, not the image
# boundary, is what governs re-entry: a pad token is an ordinary position that
# happens to carry a vision embedding instead of a text one.
#
# Truncation alone is the correct constraint. A stored checkpoint sitting
# inside a MATCHING image is fine -- `truncate_to_first_mismatch` compares
# regions by start position, so a stored depth of 6144 inside example five
# still matches when example five is the same picture. What must never happen
# is EXTENDING a match into a DIFFERING image, and that is exactly what
# truncation prevents.


# ---------------------------------------------------------------- entry identity
# MOVED HERE from exo_store (2026-09-25). The rule is pure hashlib over
# MediaRegion attributes -- no mlx in its logic -- but it lived in a module
# that imports mlx_lm at its top, so every non-mlx backend had to refuse it
# and therefore could not key a store at all. It belongs beside the regions it
# keys on. exo_store re-exports it, so `from exo_store import entry_key`
# keeps working: ONE implementation, no copy to drift.


def entry_key(phash, regions, pos):
    """The identity of one stored checkpoint: its tokens AND its pictures.

    THE TOKENS ARE NOT ENOUGH, and the failure is silent. An image is N copies
    of one pad id, so two prompts holding different photographs at the same
    offsets produce the SAME token prefix and the same phash. Keyed on phash
    alone, the second photo's checkpoint lands on a directory that already
    exists, write-once says "already held", and nothing is stored -- measured:
    four different photos through the live stack produced ONE entry, and
    photos 2-4 were discarded without a word.

    So an entry covering images is keyed on the pictures it covers as well.
    Only regions that START before `pos` count: one beginning later was never
    folded into this state and must not change its identity.

    A prompt with no image (or none below pos) keeps the bare phash, so a
    text-only store keys exactly as it always did.
    """
    covered = sorted(str(r.content_hash) for r in (regions or [])
                     if int(r.start_pos) < int(pos))
    if not covered:
        return str(phash)
    digest = hashlib.sha256((str(phash) + ":" + ":".join(covered)).encode())
    return f"{phash}-{digest.hexdigest()[:16]}"

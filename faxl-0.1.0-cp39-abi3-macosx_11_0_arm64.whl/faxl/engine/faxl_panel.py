# Vendored engine module (faxl_panel.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""The console as one desktop control panel (plan: console-dashboard-rebuild §B, §D).

One page, `/console`, rendered from ONE state object. The top bar is state and
control, the left rail is the work done, the centre is the evidence (token chart
over the live request log), the right column is the actions module's
(`faxl_panel_right`, imported below and optional). Drawers slide over from the
right for the rare things.

THE CONTRACT THIS MODULE KEEPS (§D):

  render_panel(state, nonce=None) -> str      a complete, self-contained page
  window.faxl                                  the runtime the right column and
                                               the drawers are written against:
      faxl.state  faxl.onState(fn)  faxl.refresh()  faxl.api(path, {method, body})
      faxl.openDrawer(id)  faxl.closeDrawer()  faxl.toast(text, level)
      faxl.fmt.tok .bytes .ms .ago .clock .pct .dash   ("—" for null, never 0)

  plus, as conveniences the contract does not require:
      faxl.twoStep(button, question, fn)    the inline "sure? [yes][no]" confirm
      faxl.fmt.int .dur .model               grouped integer, uptime, short model
      faxl.esc(text)                          HTML escape
      [data-drawer="drawer-x"] on any element opens that drawer on click;
      [data-close] inside a drawer closes it; each drawer receives
      "faxl:drawer-open" / "faxl:drawer-close" events (bubbling, detail.id).

HONESTY RULES, because this page is the product's claim made visible:

  * null is unmeasured and renders "—", never 0;
  * nothing estimated reaches the headline -- the only headline is prompt tokens
    not prefilled, counted;
  * first reply is shown only per request, or as medians within one prompt-size
    band with n -- a 5k-token image hit against a 21-token miss is a true pair of
    numbers and a false comparison;
  * cold is a state, said plainly, with no sample data.

WHY THE STATE IS ONE JSON BLOB. Python values never enter JavaScript through an
f-string: the initial state goes in a <script type="application/json"> with
<, > and & escaped as \\u003c etc., and every script reads it with JSON.parse.
All CSS and JS here are raw strings with no substitutions at all.

WHY NO LIBRARY. The page is served under
  default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';
  connect-src 'self'; img-src 'self' data:; font-src data:
so the chart is hand-drawn SVG and the only assets are faxl_brand's data: URIs.
"""

import html as _html
import json as _json
import math as _math

try:
    from faxl.engine.faxl_brand import LOGO_SVG_URI, ICON_32_URI, FONT_BOLD_URI
except Exception:  # noqa: BLE001 -- the panel must render without the brand
    LOGO_SVG_URI = ICON_32_URI = FONT_BOLD_URI = ""


def _right_parts():
    """The actions module's five strings, or five empty ones.

    Imported per render inside try/except, so a missing or broken right column
    leaves this page working with a quiet placeholder instead of taking the
    whole console down with it.
    """
    empty = {"RIGHT_HTML": "", "RIGHT_JS": "", "RIGHT_CSS": "",
             "DRAWERS_HTML": "", "DRAWERS_JS": ""}
    try:
        from faxl.engine.faxl_panel_right import (RIGHT_HTML, RIGHT_JS,
                                                   RIGHT_CSS, DRAWERS_HTML,
                                                   DRAWERS_JS)
    except Exception:  # noqa: BLE001
        return empty, False
    parts = {"RIGHT_HTML": RIGHT_HTML, "RIGHT_JS": RIGHT_JS,
             "RIGHT_CSS": RIGHT_CSS, "DRAWERS_HTML": DRAWERS_HTML,
             "DRAWERS_JS": DRAWERS_JS}
    return {k: (v if isinstance(v, str) else "") for k, v in parts.items()}, True


def _clean(v):
    """JSON-safe copy: NaN/inf become null (JSON.parse rejects them), tuples and
    sets become lists, anything else unknown becomes its str()."""
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return v if _math.isfinite(v) else None
    if isinstance(v, dict):
        return {str(k): _clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple, set, frozenset)):
        return [_clean(x) for x in v]
    return str(v)


def state_json(state):
    """The state as a JSON text that is safe inside a <script> element.

    Escaping <, > and & as \\u escapes keeps it valid JSON while making
    `</script>` and `<!--` impossible to spell, whatever a model id, client label
    or path contains."""
    text = _json.dumps(_clean(state if isinstance(state, dict) else {}),
                       separators=(",", ":"), ensure_ascii=True)
    return (text.replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("&", "\\u0026"))


def _font_css():
    # Only the bold face, and only for the wordmark: the application type is
    # the system sans. One 45 KB face, not four.
    if not FONT_BOLD_URI:
        return ""
    return ('@font-face{font-family:"Latin Modern";font-style:normal;'
            'font-weight:700;font-display:swap;src:url(%s) format("woff2")}'
            % FONT_BOLD_URI)


def _nonce_attr(nonce):
    return (' nonce="%s"' % _html.escape(str(nonce), quote=True)) if nonce else ""


def _logo_html():
    return ('<img src="%s" alt="" width="22" height="24">'
            % _html.escape(LOGO_SVG_URI, quote=True)) if LOGO_SVG_URI else ""


# The top bar's way to the exo page. On the exo page it reads "console" and
# leads back, and "agent view" is that page's own agent view.
_EXO_LINK = '<a class="agent-link" id="nav-exo" href="/console/exo">exo</a>'


def topbar_html(logo=None, here="panel"):
    """The shared top bar. `here` is the page wearing it: "panel" or "exo"."""
    bar = TOPBAR_HTML.replace("@@LOGO@@", _logo_html() if logo is None else logo)
    if here == "exo":
        bar = bar.replace(_EXO_LINK, '<a class="agent-link" id="nav-exo" '
                                     'href="/console">console</a>')
        bar = bar.replace('href="/console?mode=agent"',
                          'href="/console/exo?mode=agent"')
    return bar


def render_shell(state, *, title, main_html, page_css="", page_js="",
                 here="panel", nonce=None, app_id="app", with_right_js=False):
    """A console page in the panel's shell: the stylesheet, the top bar, the
    drawers (licence, verify, models, store, diagnostics -- the top bar opens
    them on every page), the state blob and the runtime, then the page's own
    markup and script. `main_html` is everything inside <div id="app"> after
    the top bar; `page_js` must end with faxl.start()."""
    right, have_right = _right_parts()
    na = _nonce_attr(nonce)
    icon = ('<link rel="icon" type="image/png" href="%s">'
            % _html.escape(ICON_32_URI, quote=True)) if ICON_32_URI else ""
    out = [
        '<!doctype html><html lang="en-GB"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        '<meta name="robots" content="noindex, nofollow">',
        '<meta name="color-scheme" content="light dark">',
        '<title>', _html.escape(title), '</title>', icon,
        '<style', na, '>', _font_css(), PANEL_CSS, '</style>',
    ]
    if right["RIGHT_CSS"]:
        out += ['<style', na, '>', right["RIGHT_CSS"], '</style>']
    if page_css:
        out += ['<style', na, '>', page_css, '</style>']
    out += [
        '</head><body>',
        '<div id="%s">' % _html.escape(app_id, quote=True),
        topbar_html(here=here),
        main_html, '</div>',
        '<div id="drawers"><div class="scrim" id="drawer-scrim"></div>',
        REQUEST_DRAWER_HTML if here == "panel" else "",
        right["DRAWERS_HTML"], '</div>',
        '<script type="application/json" id="faxl-state">', state_json(state),
        '</script>',
        # Each script in its own element: a syntax error in one never stops
        # the others, and the runtime is always defined first.
        '<script', na, '>', RUNTIME_JS, '</script>',
    ]
    if page_js:
        out += ['<script', na, '>', page_js, '</script>']
    keys = ("RIGHT_JS", "DRAWERS_JS") if with_right_js else ("DRAWERS_JS",)
    for key in keys:
        if right[key]:
            out += ['<script', na, '>', right[key], '</script>']
    out.append('</body></html>')
    return "".join(out)


def render_panel(state, nonce=None):
    """The whole console page, as one string. `state` is the /api/state payload
    (anything falsy renders as unmeasured); `nonce`, when given, is set on
    every <style> and <script> element."""
    right, have_right = _right_parts()
    right_html = right["RIGHT_HTML"] if have_right and right["RIGHT_HTML"] \
        else _RIGHT_PLACEHOLDER
    main = "".join([LEFT_HTML, CENTRE_HTML,
                    '<aside id="col-right" aria-label="chat and apps">',
                    right_html, '</aside>'])
    return render_shell(state, title="faxl — console", main_html=main,
                        page_js=PANEL_BODY_JS, here="panel", nonce=nonce,
                        with_right_js=True)


_RIGHT_PLACEHOLDER = (
    '<section class="card placeholder"><h2 class="card-h">Chat and apps</h2>'
    '<p class="muted">Not installed in this build.</p></section>')


# --------------------------------------------------------------------------
# CSS. The tokens in :root are the contract every module styles against (§D):
# --bg --panel --ink --ink-2 --line --accent --teal --ok --warn --bad --mono
# --sans --gap --radius, plus the classes .card .card-h .btn .btn-quiet
# .btn-danger .pill .pill-ok .pill-bad .pill-warn .mono .muted .row .kv .drawer
# .field. Light is the faxl teal ground with navy controls; dark is the brand
# slate with gold controls, as on faxl.ai.
# --------------------------------------------------------------------------
PANEL_CSS = r"""
:root{
  --bg:#bfe3dc; --panel:#fffdf7; --panel-2:#eef5f2; --ink:#16212b; --ink-2:#4a5963;
  --line:rgba(22,33,43,.13); --line-2:rgba(22,33,43,.26);
  --accent:#273641; --accent-ink:#ffffff; --accent-hover:#1a242c;
  --teal:#2f9990; --ok:#3d7a22; --warn:#8a6210; --bad:#962729; --bad-ink:#ffffff;
  --focus:#0a6c9e; --series-1:#273641; --series-2:#2f9990;
  --mono:ui-monospace,"SF Mono",SFMono-Regular,Menlo,Consolas,monospace;
  --sans:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  --serif:"Latin Modern","Latin Modern Roman",Georgia,"Times New Roman",serif;
  --gap:8px; --radius:6px;
  color-scheme:light;
}
@media (prefers-color-scheme:dark){
  :root:not([data-theme="light"]){
    --bg:#17212a; --panel:#1f2c36; --panel-2:#273741; --ink:#e6ebf0; --ink-2:#a3afb9;
    --line:rgba(255,255,255,.11); --line-2:rgba(255,255,255,.24);
    --accent:#d4bd7a; --accent-ink:#1a242c; --accent-hover:#e8d48a;
    --teal:#5cc2b8; --ok:#8cc970; --warn:#e2b659; --bad:#f07b73; --bad-ink:#1a1010;
    --focus:#7cc7ff; --series-1:#c8d3dc; --series-2:#5cc2b8;
    color-scheme:dark;
  }
}
:root[data-theme="dark"]{
  --bg:#17212a; --panel:#1f2c36; --panel-2:#273741; --ink:#e6ebf0; --ink-2:#a3afb9;
  --line:rgba(255,255,255,.11); --line-2:rgba(255,255,255,.24);
  --accent:#d4bd7a; --accent-ink:#1a242c; --accent-hover:#e8d48a;
  --teal:#5cc2b8; --ok:#8cc970; --warn:#e2b659; --bad:#f07b73; --bad-ink:#1a1010;
  --focus:#7cc7ff; --series-1:#c8d3dc; --series-2:#5cc2b8;
  color-scheme:dark;
}
*,*::before,*::after{box-sizing:border-box}
[hidden]{display:none!important}
html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--ink);font:13.5px/1.4 var(--sans);
  overflow:hidden;-webkit-font-smoothing:antialiased}
h1,h2,h3{margin:0;font-size:inherit}
p{margin:0}
a{color:inherit}
.mono,.num{font-family:var(--mono);font-variant-numeric:tabular-nums}
.muted{color:var(--ink-2)}
.vh{position:absolute!important;width:1px;height:1px;overflow:hidden;
  clip:rect(0 0 0 0);white-space:nowrap;margin:-1px;padding:0;border:0}
.row{display:flex;align-items:center;gap:var(--gap)}
.spacer{flex:1 1 auto}
:focus-visible{outline:2px solid var(--focus);outline-offset:2px}

/* ---- grid: rail | centre | right, the page never scrolls, panels do ---- */
#app{display:grid;min-width:1280px;max-width:100vw;height:100vh;
  grid-template-columns:300px minmax(0,1fr) clamp(420px,27vw,480px);
  grid-template-rows:auto minmax(0,1fr);gap:var(--gap);padding:0 var(--gap) var(--gap)}
#col-left,#col-right{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:var(--gap)}
#col-centre{min-height:0;min-width:0;display:flex;flex-direction:column;gap:var(--gap)}

/* ---- top bar ---- */
#topbar{grid-column:1/-1;display:flex;align-items:center;gap:0;height:44px;
  margin:0 calc(-1 * var(--gap));padding:0 12px;background:var(--panel);
  border-bottom:1px solid var(--line);white-space:nowrap;min-width:0;overflow:hidden}
.brand{display:flex;align-items:center;gap:6px;padding-right:6px;text-decoration:none;color:var(--ink)}
.brand img{display:block;width:22px;height:24px}
.brand .wm{font-family:var(--serif);font-weight:700;font-size:21px;line-height:1;letter-spacing:-.01em}
.tb-group{flex:0 1 auto;min-width:0;display:flex;align-items:center;gap:5px;padding:0 7px;height:28px;
  border-left:1px solid var(--line)}
.tb-label{font-weight:600}
.tb-sub{color:var(--ink-2);font:12px var(--mono);font-variant-numeric:tabular-nums}
#m-name{max-width:210px;overflow:hidden;text-overflow:ellipsis}
#m-select{max-width:150px}
@media (max-width:1699px){#m-name{display:none}}
/* The toast hangs just under the bar's right end, so a long message never
   pushes a control off a 1280px bar. It WRAPS: a refusal is a sentence the
   owner has to read to the end ("… is not in exo's catalogue — register it
   first"), and a one-line pill with an ellipsis cut exactly that part off.
   Held inside the viewport on both sides; a click dismisses it. */
#toast{position:fixed;top:48px;right:12px;z-index:60;max-width:min(480px,calc(100vw - 24px));
  pointer-events:none}
#toast .pill{display:block;max-width:100%;height:auto;min-height:26px;padding:5px 12px;
  white-space:normal;overflow-wrap:anywhere;word-break:normal;line-height:1.35;text-align:left;
  border-radius:10px;font-size:12.5px;background:var(--panel);box-shadow:0 4px 16px rgba(0,0,0,.14);
  pointer-events:auto;cursor:pointer;max-height:calc(100vh - 60px);overflow:auto}
#topbar .spacer{flex:1 1 0;min-width:0}
#toast .pill-ok{background:color-mix(in srgb,var(--ok) 12%,var(--panel))}
#toast .pill-warn{background:color-mix(in srgb,var(--warn) 13%,var(--panel))}
#toast .pill-bad{background:color-mix(in srgb,var(--bad) 12%,var(--panel))}
/* Sun and moon, the size of a capital Q. The moon is the way into the dark;
   the sun, drawn with rays, the way back. A choice is kept per browser. */
.theme-btn{flex:none;display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;
  margin-left:8px;padding:0;border:0;border-radius:50%;background:transparent;color:var(--ink);opacity:.55;cursor:pointer}
.theme-btn:hover{opacity:1;background:var(--panel-2)}
.theme-btn .sun{display:none;color:#e8d48a}
:root[data-theme="dark"] .theme-btn .moon{display:none}
:root[data-theme="dark"] .theme-btn .sun{display:block}
@media (prefers-color-scheme:dark){
  :root:not([data-theme="light"]) .theme-btn .moon{display:none}
  :root:not([data-theme="light"]) .theme-btn .sun{display:block}
}
.agent-link{flex:none;color:var(--ink-2);font-size:12px;padding-left:10px;border-left:1px solid var(--line);line-height:28px}
.lamp{flex:none;width:9px;height:9px;border-radius:50%;background:var(--ink-2);opacity:.4}
.lamp.ok{background:var(--ok);opacity:1}
.lamp.warn{background:var(--warn);opacity:1}
.lamp.bad{background:var(--bad);opacity:1}
.lamp.busy{animation:pulse 1.1s ease-in-out infinite}
@keyframes pulse{50%{opacity:.35}}

/* ---- controls ---- */
.btn{display:inline-flex;align-items:center;gap:4px;height:24px;padding:0 10px;
  font:600 12px/1 var(--sans);white-space:nowrap;cursor:pointer;
  border:1px solid var(--accent);border-radius:var(--radius);
  background:var(--accent);color:var(--accent-ink)}
.btn:hover{background:var(--accent-hover);border-color:var(--accent-hover)}
.btn-quiet{background:transparent;color:var(--ink);border-color:var(--line-2)}
/* The kill button sits beside the "in flight" pill in the log's result cell:
   small enough not to shout on a table of finished rows, and only ever
   rendered on a row that is actually running. */
.rq-kill{margin-left:6px;padding:0 6px;font-size:11px;line-height:1.6;vertical-align:middle}
.rq-kill:disabled{opacity:.55}
.btn-quiet:hover{background:var(--panel-2);border-color:var(--ink-2)}
.btn-danger{background:var(--bad);border-color:var(--bad);color:var(--bad-ink)}
.btn-danger:hover{background:var(--bad);border-color:var(--bad);filter:brightness(1.12)}
.btn[disabled],.btn[disabled]:hover{opacity:.45;cursor:default;filter:none}
.btn-quiet[disabled]:hover{background:transparent;border-color:var(--line-2)}
/* The backend is a first-class choice: a segmented control, the serving one
   pressed. The question hangs under the group, in words, before anything
   restarts -- the bar has no room for the sentence and it must be read. */
#tb-be{position:relative}
#be-seg button[disabled]{opacity:.45;cursor:default}
#be-seg button.serving::before{content:"\25CF\00A0"}
#be-info{max-width:160px;overflow:hidden;text-overflow:ellipsis}
@media (max-width:1499px){#be-info{display:none}}
#be-info.warn{color:var(--warn)}
.be-ask{position:absolute;top:34px;left:6px;z-index:70;display:flex;flex-direction:column;gap:6px;
  white-space:normal;width:340px;padding:8px 10px;background:var(--panel);
  border:1px solid var(--line-2);border-radius:var(--radius);box-shadow:0 4px 16px rgba(0,0,0,.16);
  font-size:12.5px;line-height:1.35}
.be-ask[hidden]{display:none}
.be-ask .row{display:flex;gap:6px}
#c-dls .meter{flex-wrap:wrap;margin:6px 0 0}
#c-dls .meter .mono:first-child{flex-basis:100%;text-align:left;overflow:hidden;text-overflow:ellipsis}
.sure{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:600;color:var(--bad)}
select,input[type=search],input[type=text],input[type=number],textarea{
  font:13px var(--sans);color:var(--ink);background:var(--panel);
  border:1px solid var(--line-2);border-radius:var(--radius);height:26px;padding:0 8px}
textarea{height:auto;padding:6px 8px;font-family:var(--mono);font-size:12px}
.field{display:flex;flex-direction:column;gap:3px;font-size:12px;margin:0 0 10px}
.field>label{color:var(--ink-2);font-weight:600}

/* ---- pills ---- */
.pill{display:inline-flex;align-items:center;gap:4px;height:20px;padding:0 8px;
  border-radius:999px;border:1px solid var(--line-2);background:transparent;
  font:600 11.5px/1 var(--sans);color:var(--ink-2);white-space:nowrap}
button.pill{cursor:pointer}
button.pill:hover{border-color:var(--ink-2)}
.pill-ok{color:var(--ok);border-color:var(--ok);background:color-mix(in srgb,var(--ok) 10%,transparent)}
.pill-warn{color:var(--warn);border-color:var(--warn);background:color-mix(in srgb,var(--warn) 11%,transparent)}
.pill-bad{color:var(--bad);border-color:var(--bad);background:color-mix(in srgb,var(--bad) 10%,transparent)}
.pill-info{color:var(--ink);border-color:var(--line-2);background:var(--panel-2)}

/* ---- cards ---- */
.card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);
  padding:10px 12px;min-width:0}
.card-h{display:flex;align-items:center;gap:8px;margin:0 0 8px;min-height:22px;
  font:700 11px/1.2 var(--sans);letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2)}
.card-h h2{font:inherit;color:inherit;margin:0}
.card-h .aux,.aux{font:500 12px var(--sans);text-transform:none;letter-spacing:0;color:var(--ink-2);white-space:nowrap}
.kv{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;margin:0;font-size:13px}
.kv dt{color:var(--ink-2)}
.kv dd{margin:0;text-align:right;font-family:var(--mono);font-variant-numeric:tabular-nums;min-width:0}
.kv dd.wrap{word-break:break-all}
.note{font-size:11.5px;color:var(--ink-2);margin-top:6px}

/* ---- left rail ---- */
.headline{font:600 26px/1.1 var(--mono);font-variant-numeric:tabular-nums;letter-spacing:-.02em}
.headline.small{font-size:18px}
.headline .of{font:500 13px var(--sans);letter-spacing:0;color:var(--ink-2)}
.headline-sub{color:var(--ink-2);font-size:12.5px;margin:3px 0 8px}
.meter{display:flex;align-items:center;gap:8px;margin:0 0 10px}
.bar{flex:1;height:6px;border-radius:3px;background:var(--panel-2);border:1px solid var(--line);overflow:hidden}
.bar>i{display:block;height:100%;width:0;background:var(--series-2)}
.bar.gauge{height:10px}
.bar.gauge>i{background:var(--series-1)}
.bar.gauge.hi>i{background:var(--warn)}
.meter .mono{font-size:12.5px;min-width:56px;text-align:right}
.cold{border:1px dashed var(--line-2);border-radius:var(--radius);background:var(--panel-2);
  padding:7px 9px;margin:0 0 10px;font-size:12.5px}
#notices{display:flex;flex-direction:column;gap:6px}
.notice{border:1px solid var(--line-2);border-left-width:3px;border-radius:var(--radius);
  background:var(--panel);padding:6px 9px;font-size:12.5px}
.notice-warn,.notice-setup{border-left-color:var(--warn)}
.notice-error{border-left-color:var(--bad)}
table.bands{width:100%;border-collapse:collapse;font-size:12.5px}
.bands th{text-align:left;font-weight:600;color:var(--ink-2);padding:3px 4px;font-size:11.5px}
.bands td,.bands tbody th{padding:4px;border-top:1px solid var(--line)}
.bands tbody th{color:var(--ink);font-weight:500;font-family:var(--mono)}
.bands .num{text-align:right;white-space:nowrap}
.bands .slower{color:var(--warn)}
.path{display:flex;align-items:center;gap:6px;margin-top:8px}
.path code{flex:1;min-width:0;overflow:hidden;white-space:nowrap;font:12px var(--mono);color:var(--ink-2)}

/* ---- centre: chart ---- */
#card-chart{flex:0 0 clamp(230px,36vh,380px);display:flex;flex-direction:column}
#card-chart .card-h{flex-wrap:nowrap}
.chart-foot{display:flex;align-items:baseline;gap:14px;margin-top:6px}
.chart-foot .note{margin:0;flex:1;min-width:0}
.legend{flex:none;display:inline-flex;gap:12px;font:500 12px var(--sans);color:var(--ink-2)}
.sw{display:inline-block;width:12px;height:3px;border-radius:2px;vertical-align:middle;margin-right:5px}
.sw.s1{background:var(--series-1)} .sw.s2{background:var(--series-2)}
.seg{display:inline-flex;border:1px solid var(--line-2);border-radius:var(--radius);overflow:hidden;flex:none}
.seg button{font:600 11.5px var(--sans);height:22px;padding:0 9px;border:0;border-left:1px solid var(--line);
  background:transparent;color:var(--ink-2);cursor:pointer;text-transform:none;letter-spacing:0}
.seg button:first-child{border-left:0}
.seg button:hover{color:var(--ink)}
.seg button[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink)}
#chart-box{position:relative;flex:1 1 auto;min-height:0}
#chart{position:absolute;left:0;top:0;display:block;overflow:visible}
#chart .grid{stroke:var(--line);stroke-width:1}
#chart .ax{fill:var(--ink-2);font:11px var(--mono)}
#chart .l1{fill:none;stroke:var(--series-1);stroke-width:1.75}
#chart .l2{fill:none;stroke:var(--series-2);stroke-width:1.75}
#chart .a2{fill:var(--series-2);opacity:.16}
#chart .b1{fill:var(--series-1);opacity:.5}
#chart .b2{fill:var(--series-2)}
#chart .cross{stroke:var(--ink-2);stroke-width:1;stroke-dasharray:3 3}
#chart-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
  color:var(--ink-2);font-size:13px;text-align:center;padding:0 24px}
#chart-tip{position:absolute;top:4px;pointer-events:none;display:none;z-index:2;
  background:var(--panel);border:1px solid var(--line-2);border-radius:var(--radius);
  padding:4px 8px;font:12px var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap;
  box-shadow:0 4px 14px rgba(0,0,0,.12)}

/* ---- centre: live log ---- */
#card-log{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;padding:0}
#card-log .card-h{padding:8px 12px 0;margin:0 0 8px}
#log-filter{width:170px;height:24px}
.table-wrap{flex:1 1 auto;min-height:0;overflow:auto;border-top:1px solid var(--line)}
/* Below ~1500px the centre is narrower than nine columns: the log scrolls
   sideways inside its panel rather than dropping model and client. */
table.log{min-width:760px;width:100%;border-collapse:separate;border-spacing:0;font-size:12.5px}
.log thead th{position:sticky;top:0;z-index:1;background:var(--panel-2);text-align:left;
  font:600 11px var(--sans);color:var(--ink-2);text-transform:uppercase;letter-spacing:.05em;
  padding:6px 8px;border-bottom:1px solid var(--line-2);white-space:nowrap}
.log td{padding:4px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
.log .num{text-align:right;font-family:var(--mono);font-variant-numeric:tabular-nums}
.log .mono{font-family:var(--mono);font-variant-numeric:tabular-nums}
.log th.num{white-space:normal;line-height:1.15;vertical-align:bottom}
.log td.trunc{max-width:0;overflow:hidden;text-overflow:ellipsis}
.log td.c-model{width:34%}
.log td.c-client{width:14%}
.log tbody tr{cursor:pointer}
.log tbody tr:hover{background:var(--panel-2)}
.log tbody tr:focus-visible{outline-offset:-2px}
.log tr.flash{animation:flash 2.4s ease-out}
@keyframes flash{from{background:color-mix(in srgb,var(--teal) 30%,transparent)}to{background:transparent}}
.log-empty{padding:28px 16px;color:var(--ink-2);text-align:center}

/* ≥2200px: the centre splits chart | log side by side */
@media (min-width:2200px){
  #col-centre{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);grid-template-rows:minmax(0,1fr)}
  #card-chart{flex:none;min-height:0}
}

/* ---- drawers ---- */
.scrim{position:fixed;inset:0;z-index:40;background:rgba(8,16,22,.3);opacity:0;visibility:hidden;
  transition:opacity .16s ease,visibility 0s linear .16s}
.scrim.on{opacity:1;visibility:visible;transition:opacity .16s ease}
.drawer{position:fixed;top:0;right:0;bottom:0;z-index:50;width:min(620px,44vw);min-width:460px;
  display:block;overflow-y:auto;background:var(--panel);border-left:1px solid var(--line-2);
  box-shadow:-14px 0 36px rgba(0,0,0,.2);transform:translateX(102%);visibility:hidden;
  transition:transform .18s ease,visibility 0s linear .18s}
.drawer.open{transform:none;visibility:visible;transition:transform .18s ease}
.drawer:focus{outline:none}
.drawer-h{position:sticky;top:0;z-index:1;display:flex;align-items:center;gap:8px;
  padding:10px 14px;background:var(--panel);border-bottom:1px solid var(--line)}
.drawer-h h2{font-size:14px;font-weight:700;margin:0;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis}
.drawer-b{padding:12px 14px 20px}
/* The right-hand drawers write their own body markup without .drawer-b, so
   text sat flush against the edge. Pad any child that is not the header. */
.drawer>:not(.drawer-h):not(.drawer-b){padding:0 22px 20px}
.drawer>:not(.drawer-h):not(.drawer-b) .drawer>*{padding:0}
.drawer .kv dd{white-space:normal;overflow-wrap:anywhere}
.drawer h3{font:700 11px var(--sans);letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2);margin:16px 0 6px}
.req-sum{font-size:13.5px;margin:0 0 4px}
table.mini{width:100%;border-collapse:collapse;font-size:12.5px}
.mini th{text-align:left;color:var(--ink-2);font-weight:600;font-size:11.5px;padding:3px 6px;border-bottom:1px solid var(--line-2)}
.mini td{padding:3px 6px;border-bottom:1px solid var(--line);font-family:var(--mono);font-variant-numeric:tabular-nums}
.placeholder p{font-size:12.5px}

@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation:none!important;transition:none!important}
  .log tr.flash{box-shadow:inset 3px 0 0 var(--teal)}
}
"""


# --------------------------------------------------------------------------
# Markup. Static: every value is filled by the runtime from faxl.state, so the
# server never formats a number in two places. "—" until then (a few ms).
# --------------------------------------------------------------------------
TOPBAR_HTML = r"""<header id="topbar">
<h1 class="vh">faxl console</h1>
<a class="brand" href="/console" aria-label="faxl console">@@LOGO@@<span class="wm">faxl</span></a>
<div class="tb-group" id="tb-proxy" role="group" aria-label="proxy">
  <span class="lamp" id="px-lamp" aria-hidden="true"></span>
  <span class="tb-label" id="px-text">proxy</span>
  <span class="tb-sub" id="px-up"></span>
  <button type="button" class="btn btn-quiet" id="px-restart">restart</button>
  <button type="button" class="btn btn-quiet" id="px-stop">stop</button>
</div>
<div class="tb-group" id="tb-backend" role="group" aria-label="serving backend and model">
  <span class="lamp" id="be-lamp" aria-hidden="true"></span>
  <span class="tb-label" id="be-name">&#8212;</span>
  <span class="tb-sub" id="m-name">&#8212;</span>
  <label class="vh" for="m-select">model to serve</label>
  <select id="m-select"></select>
  <button type="button" class="btn" id="m-switch" disabled>switch</button>
</div>
<div class="tb-group" id="tb-be" role="group" aria-label="execution backend">
  <div class="seg" id="be-seg" role="group" aria-label="execution backend: pick one to switch"></div>
  <span class="tb-sub" id="be-info"></span>
  <button type="button" class="btn btn-quiet" id="exo-stop" hidden>stop exo</button>
  <div class="be-ask" id="be-ask" role="alertdialog" aria-labelledby="be-q" hidden>
    <span id="be-q"></span>
    <select id="be-choice" class="be-choice" hidden aria-label="model"></select>
    <span class="row"><button type="button" class="btn btn-danger" id="be-yes">yes, switch</button><button type="button" class="btn btn-quiet" id="be-no">no</button></span>
  </div>
</div>
<div class="tb-group" role="group" aria-label="verification and licence">
  <button type="button" class="pill" id="ll-verify" data-drawer="drawer-verify">verify</button>
  <button type="button" class="pill" id="lic-pill" data-drawer="drawer-licence">licence &#8212;</button>
  <button type="button" class="pill" id="hft-pill" data-drawer="drawer-store">hf_token &#8212;</button>
</div>
<span class="spacer"></span>
<div id="toast" role="status" aria-live="polite"></div>
<a class="agent-link" href="/console/about">about</a>
<a class="agent-link" href="/console?mode=agent">agent view</a>
<a class="agent-link" id="nav-exo" href="/console/exo">exo</a>
<button type="button" id="theme-btn" class="theme-btn" aria-label="switch to dark mode" title="dark mode">
  <svg class="moon" viewBox="0 0 20 20" width="15" height="15" aria-hidden="true"><path d="M13.6 2.4a7.6 7.6 0 1 0 4 14.2A8.4 8.4 0 0 1 13.6 2.4z" fill="currentColor"/></svg>
  <svg class="sun" viewBox="0 0 20 20" width="15" height="15" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"><circle cx="10" cy="10" r="3.2"/><path d="M10 1.6v2.6M10 15.8v2.6M1.6 10h2.6M15.8 10h2.6M4.1 4.1l1.8 1.8M14.1 14.1l1.8 1.8M4.1 15.9l1.8-1.8M14.1 5.9l1.8-1.8"/><path d="M10 6.2a3.8 3.8 0 0 1 3.8 3.8" stroke-width=".8"/></svg>
</button>
</header>"""

LEFT_HTML = r"""<aside id="col-left" aria-label="work done">
<div id="notices" hidden></div>
<section class="card" id="card-work" aria-labelledby="h-work">
  <div class="card-h"><h2 id="h-work">Prefill skipped</h2><span class="aux">counted, not estimated</span></div>
  <p id="cold" class="cold" hidden></p>
  <div class="headline"><span id="w-skipped">&#8212;</span> <span class="of">of</span> <span id="w-received">&#8212;</span></div>
  <p class="headline-sub">prompt tokens not prefilled</p>
  <div class="meter"><div class="bar" aria-hidden="true"><i id="w-bar"></i></div><span class="mono" id="w-pct">&#8212;</span></div>
  <dl class="kv">
    <dt>hit rate</dt><dd id="k-hitrate">&#8212;</dd>
    <dt>requests</dt><dd id="k-requests">&#8212;</dd>
    <dt>hits</dt><dd id="k-hits">&#8212;</dd>
    <dt>misses</dt><dd id="k-misses">&#8212;</dd>
    <dt>incomplete</dt><dd id="k-incomplete">&#8212;</dd>
    <dt>rejected</dt><dd id="k-rejected">&#8212;</dd>
    <dt>in flight</dt><dd id="k-pending">&#8212;</dd>
    <dt>tokens prefilled</dt><dd id="k-prefilled">&#8212;</dd>
  </dl>
</section>
<section class="card" id="card-cluster" aria-labelledby="h-cluster" hidden>
  <div class="card-h"><h2 id="h-cluster">Cluster</h2><span class="aux">exo executes, faxl in front</span></div>
  <dl class="kv">
    <dt>nodes</dt><dd id="c-nodes">&#8212;</dd>
    <dt>exo</dt><dd id="c-endpoint" class="wrap">&#8212;</dd>
    <dt>prefill requests</dt><dd id="c-req">&#8212;</dd>
    <dt>prefill hits</dt><dd id="c-hits">&#8212;</dd>
    <dt>states stored</dt><dd id="c-stored">&#8212;</dd>
  </dl>
  <p class="note" id="c-pnote" hidden>The prefill server&#8217;s counts are not exposed to the console by this proxy.</p>
  <div id="c-dls"></div>
</section>
<section class="card" id="card-engine" aria-labelledby="h-engine" hidden>
  <div class="card-h"><h2 id="h-engine">Engine</h2><span class="aux" id="e-aux">&#8212;</span></div>
  <dl class="kv">
    <dt>engine</dt><dd id="e-where" class="wrap">&#8212;</dd>
    <dt>model</dt><dd id="e-model" class="wrap">&#8212;</dd>
    <dt>memory</dt><dd id="e-mem" class="wrap">&#8212;</dd>
  </dl>
  <dl class="kv" id="e-settings"></dl>
  <dl class="kv" id="e-stats"></dl>
  <p class="note" id="e-snote" hidden>The engine&#8217;s own counters are not exposed to the console by this proxy.</p>
</section>
<section class="card" id="card-first" aria-labelledby="h-first">
  <div class="card-h"><h2 id="h-first">First reply</h2><span class="aux">median (n), like for like</span></div>
  <table class="bands">
    <thead><tr><th scope="col">prompt tokens</th><th scope="col" class="num">hit</th><th scope="col" class="num">miss</th></tr></thead>
    <tbody id="bands"></tbody>
  </table>
  <p class="note">A hit is compared with a miss only inside the same prompt-size band.</p>
</section>
<section class="card" id="card-store" aria-labelledby="h-store">
  <div class="card-h"><h2 id="h-store">Cache store</h2></div>
  <div class="headline small"><span id="s-used">&#8212;</span> <span class="of">of</span> <span id="s-cap">&#8212;</span></div>
  <div class="meter"><div class="bar gauge" id="s-gauge" aria-hidden="true"><i id="s-bar"></i></div><span class="mono" id="s-pct">&#8212;</span></div>
  <dl class="kv">
    <dt>entries</dt><dd id="s-entries">&#8212;</dd>
    <dt>free on disk</dt><dd id="s-free">&#8212;</dd>
  </dl>
  <div class="path"><code id="s-path">&#8212;</code>
    <button type="button" class="btn btn-quiet" id="s-change" data-drawer="drawer-store">change&#8230;</button></div>
</section>
</aside>"""

CENTRE_HTML = r"""<main id="col-centre">
<section class="card" id="card-chart" aria-labelledby="h-chart">
  <div class="card-h"><h2 id="h-chart">Tokens</h2>
    <span class="spacer"></span>
    <div class="seg" role="group" aria-label="chart shows" id="chart-mode">
      <button type="button" data-mode="cum" aria-pressed="true">running total</button><button type="button" data-mode="buckets" aria-pressed="false">per interval</button>
    </div>
    <div class="seg" role="group" aria-label="time range" id="chart-range">
      <button type="button" data-range="1h" aria-pressed="false">1h</button><button type="button" data-range="24h" aria-pressed="true">24h</button><button type="button" data-range="7d" aria-pressed="false">7d</button><button type="button" data-range="all" aria-pressed="false">all</button>
    </div>
  </div>
  <div id="chart-box"><svg id="chart" role="img" aria-labelledby="chart-cap"></svg><div id="chart-empty" hidden></div><div id="chart-tip" aria-hidden="true"></div></div>
  <div class="chart-foot"><span class="legend" aria-hidden="true"><span><i class="sw s1"></i>received</span><span><i class="sw s2"></i>served from cache</span></span>
    <p class="note" id="chart-cap"></p></div>
</section>
<section class="card" id="card-log" aria-labelledby="h-log">
  <div class="card-h"><h2 id="h-log">Requests</h2>
    <span class="aux" id="log-live" role="status" aria-live="polite">loading&#8230;</span>
    <span class="aux mono" id="log-upd"></span>
    <span class="spacer"></span>
    <label class="aux" for="log-filter">filter</label>
    <input type="search" id="log-filter" placeholder="hit, miss, client, model" autocomplete="off" spellcheck="false">
    <span class="aux mono" id="log-count"></span>
  </div>
  <div class="table-wrap" id="log-wrap">
    <table class="log" aria-describedby="log-live">
      <thead><tr>
        <th scope="col">time</th>
        <th scope="col">result</th>
        <th scope="col" class="num" title="prompt tokens received (prompt_tokens)">prompt tok</th>
        <th scope="col" class="num" title="prompt tokens not prefilled (prefill_skipped)">from cache</th>
        <th scope="col" class="num" title="prompt tokens prefilled (prefill_paid)">prefilled</th>
        <th scope="col" class="num" title="position the model resumed from (resume_pos)">resumed at</th>
        <th scope="col" class="num" title="time to first token, ms (ttft_ms)">first reply ms</th>
        <th scope="col">model</th>
        <th scope="col">client</th>
      </tr></thead>
      <tbody id="log-body"></tbody>
    </table>
    <div class="log-empty" id="log-empty" hidden></div>
  </div>
</section>
</main>"""

REQUEST_DRAWER_HTML = r"""<section class="drawer" id="drawer-request" aria-labelledby="drawer-request-h">
  <div class="drawer-h"><h2 id="drawer-request-h" tabindex="-1">Request</h2>
    <a class="btn btn-quiet" id="req-json" href="#" target="_blank" rel="noopener">JSON</a>
    <button type="button" class="btn btn-quiet" data-close>close</button></div>
  <div class="drawer-b" id="req-body"></div>
</section>"""


# --------------------------------------------------------------------------
# The runtime. Defines window.faxl (§D), renders the top bar from faxl.state,
# polls /api/state every 3 s while the tab is visible, and owns the drawer
# chrome and the toasts. Every console page that wears the shell (the panel,
# the exo page) ships it first, then its own script, which registers its
# feeds with faxl.addPoll and ends with faxl.start().
# --------------------------------------------------------------------------
RUNTIME_JS = r"""
(function () {
  "use strict";
  var F = window.faxl = window.faxl || {};
  var DASH = "—";
  var MON = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var POLL_MS = 3000;

  function $(id) { return document.getElementById(id); }
  function isNum(v) { return typeof v === "number" && isFinite(v); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c];
    });
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = String(text);
    return e;
  }
  function get(o, path) {
    var p = path.split(".");
    for (var i = 0; i < p.length; i++) {
      if (o == null || typeof o !== "object") return null;
      o = o[p[i]];
    }
    return o === undefined ? null : o;
  }
  function setText(id, text, title) {
    var e = $(id); if (!e) return;
    var t = String(text);
    if (e.textContent !== t) e.textContent = t;
    if (title !== undefined) e.title = title || "";
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function trim0(s) { return s.indexOf(".") >= 0 ? s.replace(/\.?0+$/, "") : s; }
  function midTrunc(s, n) {
    s = String(s || "");
    if (s.length <= n) return s;
    var a = Math.ceil((n - 1) * 0.4), b = n - 1 - a;
    return s.slice(0, a) + "…" + s.slice(s.length - b);
  }
  function shortModel(m) {
    var parts = String(m || "").replace(/\\/g, "/").split("/").filter(Boolean);
    if (!parts.length) return "";
    var name = parts[parts.length - 1];
    var i = parts.indexOf("snapshots", 1);
    if (i > 0) name = parts[i - 1];
    if (name.indexOf("models--") === 0) name = name.slice(8);
    var j = name.indexOf("--");
    if (j >= 0) name = name.slice(j + 2);
    return name;
  }
  function safeHref(h) {
    h = String(h || "");
    return (h.charAt(0) === "/" && h.charAt(1) !== "/") || h.charAt(0) === "#" ? h : "#";
  }

  // ---- formatting: every function returns "—" for null / non-numbers ------
  var fmt = {
    dash: function (v) {
      return (v == null || v === "" || (typeof v === "number" && !isFinite(v))) ? DASH : String(v);
    },
    int: function (n) { return isNum(n) ? Math.round(n).toLocaleString("en-GB") : DASH; },
    tok: function (n) {
      if (!isNum(n)) return DASH;
      var a = Math.abs(n);
      if (a < 10000) return Math.round(n).toLocaleString("en-GB");
      if (a < 1e6) return trim0((n / 1e3).toFixed(a < 1e5 ? 1 : 0)) + "k";
      if (a < 1e9) return trim0((n / 1e6).toFixed(a < 1e7 ? 2 : 1)) + "M";
      return trim0((n / 1e9).toFixed(2)) + "B";
    },
    bytes: function (n) {
      if (!isNum(n)) return DASH;
      var u = ["B", "KB", "MB", "GB", "TB", "PB"], i = 0, v = n;
      while (Math.abs(v) >= 1024 && i < u.length - 1) { v /= 1024; i++; }
      return (i === 0 ? String(Math.round(v)) : v.toFixed(Math.abs(v) < 10 ? 2 : Math.abs(v) < 100 ? 1 : 0)) + " " + u[i];
    },
    ms: function (n) {
      if (!isNum(n)) return DASH;
      var a = Math.abs(n);
      if (a < 1000) return n.toFixed(1) + " ms";
      if (a < 60000) return (n / 1000).toFixed(2) + " s";
      return (n / 60000).toFixed(1) + " min";
    },
    ms1: function (n) {
      return isNum(n) ? n.toLocaleString("en-GB", {minimumFractionDigits: 1, maximumFractionDigits: 1}) : DASH;
    },
    pct: function (x) {
      if (!isNum(x)) return DASH;
      var p = x * 100;
      if (p === 0 || p === 100) return p + "%";
      if (p > 0 && p < 0.1) return "<0.1%";
      if (p > 99.9 && p < 100) return ">99.9%";
      return p.toFixed(1) + "%";
    },
    ago: function (ts) {
      if (!isNum(ts)) return DASH;
      var s = Math.max(0, Date.now() / 1000 - ts);
      if (s < 60) return Math.round(s) + " s ago";
      if (s < 3600) return Math.round(s / 60) + " min ago";
      if (s < 86400) return Math.round(s / 3600) + " h ago";
      return Math.round(s / 86400) + " d ago";
    },
    clock: function (ts) {
      if (!isNum(ts)) return DASH;
      var d = new Date(ts * 1000), now = new Date();
      var t = pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
      if (d.toDateString() !== now.toDateString()) t = d.getDate() + " " + MON[d.getMonth()] + " " + t;
      return t;
    },
    dur: function (s) {
      if (!isNum(s)) return DASH;
      s = Math.max(0, Math.floor(s));
      var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
      if (d) return d + "d " + h + "h";
      if (h) return h + "h " + m + "m";
      if (m) return m + "m";
      return s + "s";
    },
    model: function (m) { var s = shortModel(m); return s || DASH; },
    // Decimal GB, the unit RAM is sold in and the server's fit reasons use
    // ("needs 130 GB, this Mac has 90 GB usable"): one spelling on the page.
    gb: function (n) {
      if (!isNum(n)) return DASH;
      return (n >= 10e9 ? String(Math.round(n / 1e9)) : (n / 1e9).toFixed(1)) + " GB";
    },
    // "this Mac: 128 GB RAM, 90 GB usable for a model" from state.memory --
    // the serving backend's memory SOURCE (descriptor memory_from), never its
    // name: gpu_vram reads "GPU: NVIDIA RTX 4090 · 24 GB VRAM, 3.1 GB used,
    // 17 GB usable for a model".
    budget: function (s) {
      var d = (F.be && F.be.serving(s)) || get(s, "backend.descriptor") || {};
      if (d.memory_from === "gpu_vram") {
        var g = get(s, "memory.gpu_vram") || {};
        if (!isNum(g.vram_bytes)) return g.error ? "GPU: " + g.error : "";
        var names = (g.gpus || []).map(function (x) { return x && x.name; }).filter(Boolean);
        return "GPU: " + (names.length ? names.join(" + ") + " · " : "") + fmt.gb(g.vram_bytes) + " VRAM, " +
          (isNum(g.used_bytes) ? fmt.gb(g.used_bytes) + " used, " : "") + fmt.gb(g.usable_bytes) + " usable for a model";
      }
      var m = get(s, "memory.host_ram") || {};
      if (!isNum(m.ram_bytes)) return "";
      return "this Mac: " + fmt.gb(m.ram_bytes) + " RAM, " + fmt.gb(m.usable_bytes) + " usable for a model";
    }
  };
  F.fmt = fmt;

  // Theme. The stylesheet already answers to data-theme on <html>; this only
  // sets it, remembers it, and keeps the button's label honest.
  (function () {
    var btn = $("theme-btn"); if (!btn) return;
    var root = document.documentElement;
    function isDark() {
      var t = root.getAttribute("data-theme");
      if (t) return t === "dark";
      return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    }
    function label() {
      var d = isDark();
      btn.setAttribute("aria-label", d ? "switch to light mode" : "switch to dark mode");
      btn.title = d ? "light mode" : "dark mode";
    }
    try { var saved = localStorage.getItem("faxl.theme"); if (saved === "dark" || saved === "light") root.setAttribute("data-theme", saved); } catch (e) {}
    btn.addEventListener("click", function () {
      var next = isDark() ? "light" : "dark";
      root.setAttribute("data-theme", next);
      try { localStorage.setItem("faxl.theme", next); } catch (e) {}
      label();
    });
    label();
  })();
  F.esc = esc;

  // ---- state -------------------------------------------------------------
  function readInitial() {
    var n = $("faxl-state");
    if (!n) return {};
    try {
      var s = JSON.parse(n.textContent || "{}");
      return (s && typeof s === "object") ? s : {};
    } catch (e) { return {}; }
  }
  F.state = readInitial();
  var subs = [];
  function safe(fn, arg) {
    try { fn(arg); } catch (e) { if (window.console) console.error("faxl: state handler failed", e); }
  }
  F.onState = function (fn) {
    if (typeof fn !== "function") return;
    subs.push(fn);
    if (F.state) safe(fn, F.state);
  };
  function publish(s) {
    F.state = s;
    for (var i = 0; i < subs.length; i++) safe(subs[i], s);
  }

  // ---- api: JSON in and out; rejects with the server's own error text -----
  function errText(d) {
    if (!d || typeof d !== "object") return "";
    var e = d.error;
    if (typeof e === "string") return e;
    if (e && typeof e === "object") return e.message || e.type || "";
    return d.message || "";
  }
  F.api = function (path, opts) {
    opts = opts || {};
    var init = {method: opts.method || (opts.body !== undefined ? "POST" : "GET"),
                headers: {"Accept": "application/json"}, cache: "no-store",
                credentials: "same-origin"};
    if (opts.body !== undefined) {
      init.headers["Content-Type"] = "application/json";
      init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
    }
    return fetch(path, init).then(function (r) {
      return r.text().then(function (t) {
        var d = null;
        if (t) { try { d = JSON.parse(t); } catch (e) { d = null; } }
        if (!r.ok || (d && typeof d === "object" && d.ok === false)) {
          var err = new Error(errText(d) || ("HTTP " + r.status + (r.statusText ? " " + r.statusText : "")));
          err.status = r.status; err.data = d;
          throw err;
        }
        return d !== null ? d : t;
      });
    }, function () {
      var err = new Error("proxy not answering");
      err.network = true; err.status = 0;
      throw err;
    });
  };

  // ---- toast -------------------------------------------------------------
  var toastTimer = null;
  var LEVEL = {ok: "pill-ok", pass: "pill-ok", info: "pill-info", setup: "pill-warn",
               warn: "pill-warn", bad: "pill-bad", fail: "pill-bad", error: "pill-bad"};
  // Errors stay up 12 s (or until clicked), everything else 6 s. The whole
  // message is shown, wrapped -- never cut to one line.
  F.toast = function (text, level) {
    var box = $("toast"); if (!box) return;
    box.textContent = "";
    var bad = level === "bad" || level === "error" || level === "fail";
    var t = el("span", "pill " + (LEVEL[level] || "pill-info"), text);
    t.title = "click to dismiss";
    if (bad) t.setAttribute("role", "alert");
    t.addEventListener("click", function () {
      if (toastTimer) { clearTimeout(toastTimer); toastTimer = null; }
      if (t.parentNode) t.parentNode.removeChild(t);
    });
    box.appendChild(t);
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { box.textContent = ""; toastTimer = null; },
                            bad ? 12000 : 6000);
  };

  // ---- two-step confirm: click -> "sure? [yes] [no]", never window.confirm -
  F.twoStep = function (btn, question, fn) {
    if (!btn) return;
    btn.addEventListener("click", function () {
      if (btn.disabled) return;
      var q = typeof question === "function" ? question() : question;
      if (q === false) return;
      var box = el("span", "sure"); box.setAttribute("role", "group");
      box.setAttribute("aria-label", q || "sure?");
      box.title = q || "";
      box.appendChild(el("span", null, "sure?"));
      if (q) F.toast(q, "warn");   // the consequence, where there is room for it
      var yes = el("button", "btn btn-danger", "yes"); yes.type = "button";
      var no = el("button", "btn btn-quiet", "no"); no.type = "button";
      box.appendChild(yes); box.appendChild(no);
      btn.hidden = true;
      btn.parentNode.insertBefore(box, btn.nextSibling);
      var timer = setTimeout(function () { done(false); }, 8000);
      function done(go) {
        clearTimeout(timer);
        if (box.parentNode) box.parentNode.removeChild(box);
        btn.hidden = false;
        if (btn.focus) btn.focus();
        if (go) fn();
      }
      yes.addEventListener("click", function () { done(true); });
      no.addEventListener("click", function () { done(false); });
      box.addEventListener("keydown", function (ev) {
        if (ev.key === "Escape") { ev.stopPropagation(); ev.preventDefault(); done(false); }
      });
      no.focus();
    });
  };

  // ---- drawers -----------------------------------------------------------
  var openId = null, returnFocus = null;
  function focusables(root) {
    return Array.prototype.filter.call(
      root.querySelectorAll('a[href],button,input,select,textarea,[tabindex]:not([tabindex="-1"])'),
      function (e) { return !e.disabled && !e.hidden && e.offsetParent !== null; });
  }
  function ensureChrome(d) {
    if (!d.getAttribute("role")) d.setAttribute("role", "dialog");
    d.setAttribute("aria-modal", "true");
    if (!d.hasAttribute("tabindex")) d.setAttribute("tabindex", "-1");
    if (!d.querySelector("[data-close]")) {
      var head = d.querySelector(".drawer-h");
      if (!head) { head = el("div", "drawer-h"); head.appendChild(el("span", "spacer")); d.insertBefore(head, d.firstChild); }
      var x = el("button", "btn btn-quiet", "close"); x.type = "button"; x.setAttribute("data-close", "");
      head.appendChild(x);
    }
    if (!d.getAttribute("aria-label") && !d.getAttribute("aria-labelledby")) {
      var h = d.querySelector("h2,h3");
      if (h) { if (!h.id) h.id = d.id + "-title"; d.setAttribute("aria-labelledby", h.id); }
    }
  }
  function fire(d, name) {
    try { d.dispatchEvent(new CustomEvent(name, {bubbles: true, detail: {id: d.id}})); } catch (e) { /* old engine */ }
  }
  F.openDrawer = function (id) {
    var d = $(id);
    if (!d || !d.classList.contains("drawer")) return false;
    if (openId && openId !== id) F.closeDrawer(true);
    if (!openId) returnFocus = document.activeElement;
    ensureChrome(d);
    d.hidden = false;
    d.classList.add("open");
    d.setAttribute("aria-hidden", "false");
    var s = $("drawer-scrim"); if (s) s.classList.add("on");
    openId = id;
    fire(d, "faxl:drawer-open");
    var target = d.querySelector("[autofocus]") || d.querySelector("h2[tabindex]") || d;
    setTimeout(function () { if (openId === id && target.focus) target.focus(); }, 30);
    return true;
  };
  F.closeDrawer = function (keepFocus) {
    if (!openId) return;
    var d = $(openId);
    openId = null;
    if (d) { d.classList.remove("open"); d.setAttribute("aria-hidden", "true"); fire(d, "faxl:drawer-close"); }
    var s = $("drawer-scrim"); if (s) s.classList.remove("on");
    if (keepFocus === true) return;
    var rf = returnFocus; returnFocus = null;
    if (rf && rf.focus && document.body.contains(rf)) rf.focus();
  };
  document.addEventListener("keydown", function (ev) {
    if (!openId) return;
    var d = $(openId);
    if (ev.key === "Escape") { ev.preventDefault(); F.closeDrawer(); return; }
    if (ev.key === "Tab" && d) {
      var f = focusables(d);
      if (!f.length) { ev.preventDefault(); d.focus(); return; }
      var first = f[0], last = f[f.length - 1];
      if (!d.contains(document.activeElement)) { ev.preventDefault(); first.focus(); }
      else if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
    }
  });
  document.addEventListener("click", function (ev) {
    var t = ev.target;
    if (!t || !t.closest) return;
    var c = t.closest("[data-close]");
    if (c && c.closest(".drawer")) { ev.preventDefault(); F.closeDrawer(); return; }
    if (t.id === "drawer-scrim") { F.closeDrawer(); return; }
    var o = t.closest("[data-drawer]");
    if (o) {
      ev.preventDefault();
      if (!F.openDrawer(o.getAttribute("data-drawer"))) {
        var fb = o.getAttribute("data-fallback");
        if (fb) location.href = safeHref(fb);
        else F.toast("that panel is not installed in this build", "warn");
      }
    }
  });

  // ---- polling and the proxy's own state ----------------------------------
  var down = false, lastOk = Date.now(), tr = null, inflight = null;
  // tr: a transition the user started (restart / stop / model switch / exo),
  // so the lamp says "restarting…" instead of "not answering" while it happens.
  function startTransition(kind, label) {
    tr = {kind: kind, label: label, since: Date.now(), sawDown: false,
          uptime: get(F.state, "proxy.uptime_s"), model: get(F.state, "model.id"),
          target: arguments[2] || null,
          limit: kind === "backend" ? 240000 : 180000};
    renderProxy(F.state); syncSwitch();
  }
  function endTransition() { tr = null; renderProxy(F.state); syncSwitch(); }
  function checkTransition(s) {
    if (!tr) return;
    var up = get(s, "proxy.uptime_s");
    if (tr.kind === "backend") {
      // Done only when the proxy ANSWERS on the new backend: a restart that
      // came back on the old one is not a switch.
      if (get(s, "backend.name") === tr.target) {
        tr = null;
        F.toast("now serving on " + backendLabel(s, get(s, "backend.name")), "ok");
      } else if (Date.now() - tr.since > tr.limit) {
        var was = tr.target; tr = null;
        F.toast("no switch to " + was + " seen after 4 minutes — see ~/.faxl/logs/power.log", "bad");
      }
      return;
    }
    var back = tr.sawDown || (isNum(up) && isNum(tr.uptime) && up + 5 < tr.uptime) ||
               (tr.kind === "switch" && get(s, "model.id") !== tr.model);
    if (back) {
      var k = tr.kind; tr = null;
      if (k === "switch") F.toast("now serving " + (get(s, "model.short") || fmt.model(get(s, "model.id"))), "ok");
      else if (k === "stop") F.toast("the proxy is running again", "info");
      else F.toast("proxy answering again", "ok");
    } else if (Date.now() - tr.since > 180000) {
      tr = null;
      F.toast("no restart seen after 3 minutes — see ~/.faxl/logs/", "warn");
    }
  }
  F.refresh = function () {
    if (inflight) return inflight;
    inflight = F.api("/api/state").then(function (s) {
      inflight = null;
      if (!s || typeof s !== "object") throw new Error("bad state");
      down = false; lastOk = Date.now();
      checkTransition(s);
      publish(s);
      return s;
    }).catch(function (e) {
      inflight = null;
      down = true;
      if (tr) tr.sawDown = true;
      if (tr && Date.now() - tr.since > tr.limit) {
        var bk = tr.kind === "backend"; tr = null;
        F.toast("still not answering after " + (bk ? "4" : "3") + " minutes — see ~/.faxl/logs/" +
                (bk ? "power.log" : ""), "bad");
      }
      renderProxy(F.state);
      return null;
    });
    return inflight;
  };

  // ---- top bar -----------------------------------------------------------
  function renderProxy(s) {
    var cls = "ok", label = "proxy", sub = "";
    if (down) {
      if (tr && tr.kind === "stop") { cls = "bad"; label = "proxy stopped"; sub = "start it again from a terminal"; }
      else if (tr) { cls = "warn busy"; label = tr.label; }
      else { cls = "bad"; label = "proxy not answering"; sub = "last answer " + fmt.ago(lastOk / 1000); }
    } else if (tr) {
      cls = "warn busy"; label = tr.label;
    } else {
      var up = get(s, "proxy.uptime_s");
      if (get(s, "proxy.running") === false) { cls = "bad"; label = "proxy stopped"; }
      sub = isNum(up) ? "up " + fmt.dur(up) : "";
    }
    $("px-lamp").className = "lamp " + cls;
    setText("px-text", label);
    setText("px-up", sub);
    var bind = get(s, "proxy.bind"), ver = get(s, "proxy.version");
    $("tb-proxy").title = [bind, ver ? "version " + ver : ""].filter(Boolean).join(" · ");
    $("px-restart").disabled = !!tr || down;
    $("px-stop").disabled = !!tr || down;
  }

  var modelSig = "", userPicked = false;
  // THE FIT RULE, SHOWN BEFORE THE CLICK. A model that does not fit (the
  // server's fits === false: too big for RAM x fit_ratio, size unknown, or
  // not on this Mac) is listed but DISABLED, with the server's reason as its
  // label -- "MiniMax-M2.7-4bit — needs 130 GB, this Mac has 90 GB usable".
  // The server refuses it anyway (409); this is so nobody has to click to
  // find out. The one serving is never disabled: it is what runs.
  function fillModels(s) {
    var sel = $("m-select");
    // Only what can be served now: on disk (null is unknown, not offered),
    // or the one already serving.
    var list = (get(s, "models") || []).filter(function (x) {
      return x && x.id && (x.on_disk === true || x.serving === true);
    });
    var serving = servingId(s);
    var budget = fmt.budget(s);
    var sig = JSON.stringify([list.map(function (x) { return [x.id, x.short, x.serving, x.size_bytes, x.fits, x.fit_reason]; }), serving, budget]);
    if (sig === modelSig || document.activeElement === sel) { syncSwitch(); return; }
    modelSig = sig;
    var keep = sel.value;
    sel.textContent = "";
    sel.title = budget;
    if (!list.length) {
      var o0 = el("option", null, "no models on disk"); o0.value = "";
      sel.appendChild(o0); sel.disabled = true;
    } else {
      sel.disabled = false;
      var usable = [];
      list.forEach(function (x) {
        var here = x.serving === true || x.id === serving;
        var name = x.short || fmt.model(x.id);
        var blocked = !here && x.fits === false;
        var o = el("option", null, blocked
          ? name + " — " + (x.fit_reason || "does not fit")
          : name + (isNum(x.size_bytes) ? " · " + fmt.gb(x.size_bytes) : "") + (here ? " (serving)" : ""));
        o.value = x.id;
        o.title = blocked ? x.id + ": " + (x.fit_reason || "does not fit") : x.id;
        if (blocked) { o.disabled = true; o.setAttribute("data-fit", "no"); }
        else usable.push(x.id);
        sel.appendChild(o);
      });
      sel.value = (userPicked && usable.indexOf(keep) >= 0) ? keep :
                  (usable.indexOf(serving) >= 0 ? serving : (usable[0] || ""));
    }
    syncSwitch();
  }
  // The serving model as the list spells it: on exo the list is exo's own
  // catalogue ids, while model.id is what the proxy was started with.
  function servingId(s) {
    var list = get(s, "models") || [];
    for (var i = 0; i < list.length; i++) if (list[i] && list[i].serving === true) return list[i].id;
    return get(s, "model.id");
  }
  function syncSwitch() {
    var sel = $("m-select"), serving = servingId(F.state);
    var o = sel.options[sel.selectedIndex];
    $("m-switch").disabled = !sel.value || sel.value === serving || !!tr || down ||
      !!(o && o.disabled);
  }
  function renderBackend(s) {
    var be = get(s, "backend") || {}, m = get(s, "model") || {};
    $("be-lamp").className = "lamp " + (be.up === true ? "ok" : be.up === false ? "bad" : "");
    setText("be-name", be.name || DASH);
    $("tb-backend").title = be.endpoint ? "endpoint " + be.endpoint :
                            (be.in_process ? "the model runs inside the proxy process" : "");
    var name = m.short || fmt.model(m.id);
    setText("m-name", name + (m.vision === true ? " · vision" : ""), m.id || "");
    fillModels(s);
  }

  // ---- the backend: a first-class choice ---------------------------------
  // faxl runs ONE execution backend per proxy: this Mac (MLX), the model in
  // this process, or the exo cluster -- many machines running one model with
  // faxl in front. Picking the other one restarts the proxy onto it; nothing
  // is ever started beside the one serving.
  //
  // Which backend is which is the SERVER's to say (faxl_backends
  // descriptors in state.backend.available): the page never tests a
  // backend's name, only its capabilities -- memory_from "cluster_ram" is
  // the cluster behind faxl, models_from "local_dirs" is models on this
  // disk. A backend the server adds shows up here with no page change.
  var BE = {
    list: function (s) { return (get(s, "backend.available") || []).filter(function (a) { return a && a.name; }); },
    find: function (s, name) { return BE.list(s).filter(function (a) { return a.name === name; })[0] || null; },
    byCap: function (s, field, value) { return BE.list(s).filter(function (a) { return a[field] === value; })[0] || null; },
    serving: function (s) {
      return BE.list(s).filter(function (a) { return a.serving; })[0] || get(s, "backend.descriptor") || null;
    },
    cluster: function (s) { return BE.byCap(s, "memory_from", "cluster_ram"); },
    local: function (s) { return BE.byCap(s, "models_from", "local_dirs"); },
    isCluster: function (a) { return !!a && a.memory_from === "cluster_ram"; },
    onCluster: function (s) { return BE.isCluster(BE.serving(s)); }
  };
  F.be = BE;
  function backendLabel(s, name) {
    var a = BE.find(s, name);
    return a ? (a.label || name) : (name || DASH);
  }
  var beSig = "", beAskFor = null;
  function renderBackendChoice(s) {
    var be = get(s, "backend") || {}, ex = be.exo || {}, seg = $("be-seg");
    var av = (be.available || []).filter(function (a) { return a && a.name; });
    if (!av.length) av = [{name: be.name || DASH, label: be.name || DASH, serving: true}];
    var sig = JSON.stringify([av, !!tr, down]);
    if (sig !== beSig) {
      beSig = sig;
      seg.textContent = "";
      av.forEach(function (a) {
        var b = el("button", a.serving ? "serving" : null, a.label || a.name);
        b.type = "button";
        b.setAttribute("data-be", a.name);
        b.setAttribute("aria-pressed", a.serving ? "true" : "false");
        if (a.serving) b.title = "serving now";
        else if (a.can_switch === false) { b.disabled = true; b.title = a.note || "cannot switch from here"; }
        else b.title = "switch the backend to " + (a.label || a.name) + " — the proxy restarts onto it";
        if (tr || down) b.disabled = true;
        seg.appendChild(b);
      });
    }
    // what the serving backend is, or why the other cannot be picked
    var info = "", cls = "tb-sub", blocked = av.filter(function (a) { return !a.serving && a.can_switch === false && a.note; });
    if (BE.onCluster(s)) {
      info = "● " + backendLabel(s, be.name) + " · " + (isNum(ex.nodes) ? ex.nodes + (ex.nodes === 1 ? " node" : " nodes") : "nodes " + DASH);
      if (ex.running === false) { info = backendLabel(s, be.name) + " not answering"; cls = "tb-sub warn"; }
    } else if (ex.running) {
      info = "exo is running without faxl in front"; cls = "tb-sub warn";
    } else if (blocked.length) {
      info = blocked[0].label + ": " + blocked[0].note;
    }
    // The environment outranks config.json: while FAXL_BACKEND / FAXL_MODEL
    // is set in this proxy's env the switch would be undone on restart, and
    // the server refuses it (409). Say so before the click, not after.
    var pinned = ["backend", "model"].filter(function (k) {
      return get(s, "config." + k + ".source") === "env";
    }).map(function (k) { return get(s, "config." + k + ".env_var") || k; });
    if (pinned.length && cls !== "tb-sub warn") {
      info = (info ? info + " · " : "") + pinned.join(" and ") +
        " set in the environment — the switch is locked until it is unset";
      cls = "tb-sub warn";
    }
    $("be-info").className = cls;
    setText("be-info", info, info);
    // The exo page link only where a cluster backend is offered (the
    // descriptors say; a Linux box has none). On the exo page it leads back.
    var nav = $("nav-exo");
    if (nav && /\/console\/exo$/.test(nav.getAttribute("href") || "")) nav.hidden = !BE.cluster(s);
    var stop = $("exo-stop");
    var showStop = BE.onCluster(s) || !!ex.running;
    if (!stop.parentNode.querySelector(".sure")) stop.hidden = !showStop;
    stop.disabled = !!tr || down;
  }
  function askBackend(name) {
    var s = F.state, a = null, av = get(s, "backend.available") || [];
    for (var i = 0; i < av.length; i++) if (av[i] && av[i].name === name) a = av[i];
    if (!a || a.serving || a.can_switch === false || tr || down) return;
    // The confirm NAMES THE MODEL it comes up on, with its size: each backend
    // comes back on its own last model (config "models"), never the other
    // one's -- so what "switch to this Mac" brings up is said, not assumed.
    var q, on = a.model ? " comes up on " + shortModel(a.model) +
      (isNum(a.size_bytes) ? " (" + fmt.gb(a.size_bytes) + ")" : "") : "";
    var lbl = a.label || name, cur = BE.serving(s);
    if (BE.isCluster(a)) {
      q = "switch to " + lbl + "?" + (on || " the proxy restarts onto it") +
          " — about a minute; the cache store survives" + (a.note ? " · " + a.note : "");
    } else if (a.kind === "in_process") {
      q = "switch to " + lbl + "?" + (on || " the proxy restarts with the model in its own process") +
          (BE.isCluster(cur) ? " · " + (cur.label || cur.name) + " stops" : "") + (a.note ? " · " + a.note : "");
    } else {
      q = "switch to " + (a.label || name) + "? the proxy restarts onto it";
    }
    beAskFor = {name: name, model: null, stop: false};
    showAsk(q, "yes, switch");
  }
  function showAsk(q, yesText) {
    setText("be-q", q);
    setText("be-yes", yesText);
    $("be-ask").hidden = false;
    $("be-no").focus();
  }
  function hideAsk() { $("be-ask").hidden = true; beAskFor = null; }
  // Also used by the models drawer: "serve this on the cluster".
  F.switchBackend = function (name, modelId) {
    if (tr) return Promise.reject(new Error("a restart is already under way"));
    var label = backendLabel(F.state, name);
    startTransition("backend", "switching to " + label + "…", name);
    var body = {backend: name};
    if (modelId) body.model_id = modelId;
    return F.api("/api/backend/switch", {method: "POST", body: body}).then(function (d) {
      F.toast("switching to " + label + (d && d.model ? " with " + shortModel(d.model) : "") +
              " — the proxy is restarting", "info");
      return d;
    }, function (e) {
      if (expectDrop(e)) return null;       // the proxy stopped itself: expected
      endTransition();
      // A MODEL QUESTION IS NOT A FAILURE. The switch refuses when the
      // cluster is not serving the model faxl would carry over, and hands
      // back what it COULD run instead -- because the alternative is a
      // switch that looks fine and then 500s on the first photograph.
      var q = e && e.data;   // F.api attaches the parsed body as .data
      if (q && q.needs === "model" && (q.choices || []).length) {
        F.askModelChoice(name, q);
        return null;
      }
      F.toast("switch refused: " + e.message, "bad");
      throw e;
    });
  };

  // THE CHOICES THE SERVER OFFERED, in the confirm dialog that already
  // exists. Nothing here is invented: every option came from the cluster's
  // own /v1/models, or is the model faxl is already carrying.
  F.askModelChoice = function (name, q) {
    var sel = $("be-choice");
    sel.innerHTML = (q.choices || []).map(function (c) {
      return '<option value="' + esc(c.action) + "|" + esc(c.model_id) +
             '">' + esc(c.label) + " — " + esc(c.note || "") + "</option>";
    }).join("");
    sel.hidden = false;
    beAskFor = null;
    setText("be-q", q.error);
    setText("be-yes", "use this model");
    $("be-ask").hidden = false;
    $("be-yes").onclick = function () {
      var v = String(sel.value || "").split("|");
      $("be-ask").hidden = true; sel.hidden = true; $("be-yes").onclick = null;
      if (!v[1]) return;
      if (v[0] === "download") {
        F.toast("asking the cluster for " + shortModel(v[1]) +
                " — a large model can take a while", "info");
      }
      startTransition("backend", "switching to " + backendLabel(F.state, name) + "…", name);
      F.api("/api/backend/switch", {method: "POST",
        body: {backend: name, model_id: v[1], confirm: true}})
        .catch(function (e) { if (!expectDrop(e)) { endTransition();
          F.toast("switch refused: " + e.message, "bad"); } });
    };
  };

  function renderLossless(s) {
    // One control. The verify button IS the lossless state: green once it
    // has passed, amber until it has been run, red after a failure. The
    // separate "lossless: never" pill said the same thing twice.
    var L = get(s, "lossless") || {}, v = $("ll-verify");
    var cls = "pill pill-warn", text = "verify", title = "losslessness not verified on this machine — run the check";
    if (L.status === "pass") { cls = "pill pill-ok"; text = "lossless ✓"; title = "verified " + (isNum(L.verified_at) ? fmt.ago(L.verified_at) : ""); }
    else if (L.status === "fail") { cls = "pill pill-bad"; text = "lossless failed"; title = "the cache returned a different answer — open to see why"; }
    v.className = cls; setText("ll-verify", text); v.title = title;
  }
  // THE TOKEN PILL. A HuggingFace token was reachable only behind "change..."
  // on the Cache store card -- nothing on the page said "HuggingFace", so a
  // user meeting their first gated model had no way to find it. It sits beside
  // the licence because it is the same kind of thing: a credential the proxy
  // needs, whose state you want to see at a glance. (AM, 2026-10-07.)
  //
  // It opens the store drawer, where the field already lives: one setting, one
  // place to edit it. Never shows the token, only whether there is one.
  function renderHfToken(s) {
    var t = get(s, "hf_token") || {}, p = $("hft-pill");
    if (!p) return;
    var cls = "pill", text = "hf_token " + DASH, title =
      "a HuggingFace token, for gated or private models";
    if (t.set) {
      text = "hf_token set";
      title = t.source === "env"
        ? "set by " + (t.env_var || "the environment") + ", which outranks "
          + "anything saved here"
        : t.source === "hf_cli"
        ? "signed in with `hf auth login`; faxl uses that"
        : "saved on this machine";
    } else {
      // NOT a warning. Most models are not gated, so no token is the normal
      // state and colouring it amber would cry wolf on a healthy install.
      text = "hf_token " + DASH;
      title = "no token — needed only for gated or private models";
    }
    p.className = cls; setText("hft-pill", text); p.title = title;
  }
  function renderLicence(s) {
    var lic = get(s, "licence") || {}, p = $("lic-pill"), d = lic.days_remaining, st = lic.state;
    var cls = "pill", text = "licence " + DASH;
    if (st && st !== "active") {
      // Expired is a renewal, not a mistake: amber, not red.
      cls = (st === "expired" || st === "missing") ? "pill pill-warn" : "pill pill-bad";
      text = "licence " + st;
    } else if (isNum(d)) {
      cls = d < 30 ? "pill pill-warn" : "pill";
      text = "licence " + Math.max(0, Math.floor(d)) + "d";
    } else if (st) { text = "licence " + st; }
    p.className = cls; setText("lic-pill", text);
    p.title = [lic.licensed_to ? "licensed to " + lic.licensed_to : "", lic.expires ? "expires " + lic.expires : ""]
      .filter(Boolean).join(" · ");
  }

  // ---- left rail ---------------------------------------------------------
  function renderNotices(s) {
    var box = $("notices"), list = (get(s, "notices") || []).filter(Boolean);
    if (!box) return;                       // a page without the left rail
    box.textContent = "";
    list.forEach(function (n) {
      var c = el("div", "notice notice-" + String(n.level || "info").replace(/[^a-z]/g, ""));
      c.appendChild(el("b", null, n.title || ""));
      if (n.text) c.appendChild(document.createTextNode(" " + n.text));
      if (n.href) {
        var h = String(n.href);
        var a = el("a", null, "open");
        var dm = /^\/console\?open=(drawer-[a-z-]+)$/.exec(h);
        if (h.indexOf("#drawer-") === 0) { a.href = "#"; a.setAttribute("data-drawer", h.slice(1)); }
        else if (dm) {
          // A drawer on this very page (build_state's _panel_href): open it in
          // place. The href stays a real link for a new tab or a middle click.
          a.href = h; a.setAttribute("data-drawer", dm[1]);
        }
        else a.href = safeHref(h);
        c.appendChild(document.createTextNode(" ")); c.appendChild(a);
      }
      box.appendChild(c);
    });
    box.hidden = !list.length;
  }

  // ---- controls ----------------------------------------------------------
  function expectDrop(e) { return e && e.network; }  // a restart kills the socket
  F.twoStep($("px-restart"), "restart the proxy? back in a few seconds", function () {
    startTransition("restart", "proxy restarting…");
    F.api("/api/proxy/power", {method: "POST", body: {action: "restart"}}).then(function () {
      F.toast("restarting the proxy…", "info");
    }, function (e) {
      if (expectDrop(e)) return;
      endTransition(); F.toast("restart refused: " + e.message, "bad");
    });
  });
  F.twoStep($("px-stop"), "stop the proxy? this console stops with it", function () {
    startTransition("stop", "proxy stopping…");
    F.api("/api/proxy/power", {method: "POST", body: {action: "stop"}}).then(function () {
      F.toast("proxy stopping — start it again from a terminal", "warn");
    }, function (e) {
      if (expectDrop(e)) return;
      endTransition(); F.toast("stop refused: " + e.message, "bad");
    });
  });
  $("m-select").addEventListener("change", function () { userPicked = true; syncSwitch(); });
  // Restart this proxy, on this backend, onto another model. Also the exo
  // page's "serve" when exo is already the backend.
  F.restartModel = function (id) {
    if (!id) return Promise.reject(new Error("no model given"));
    if (tr) return Promise.reject(new Error("a restart is already under way"));
    startTransition("switch", "switching model…");
    return F.api("/api/restart", {method: "POST", body: {model_id: id}}).then(function (d) {
      userPicked = false;
      F.toast("restarting on " + fmt.model(id) + "…", "info");
      return d;
    }, function (e) {
      if (expectDrop(e)) { userPicked = false; return null; }
      endTransition(); F.toast("switch refused: " + e.message, "bad");
      throw e;
    });
  };
  F.twoStep($("m-switch"), function () {
    return "restart on " + fmt.model($("m-select").value) + "? about a minute offline";
  }, function () {
    var id = $("m-select").value;
    if (!id) return;
    F.restartModel(id).catch(function () { /* toasted */ });
  });
  $("be-seg").addEventListener("click", function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest("button[data-be]") : null;
    if (!b || b.disabled) return;
    askBackend(b.getAttribute("data-be"));
  });
  $("be-no").addEventListener("click", hideAsk);
  $("be-ask").addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") { ev.stopPropagation(); ev.preventDefault(); hideAsk(); }
  });
  $("be-yes").addEventListener("click", function () {
    var want = beAskFor; hideAsk();
    if (!want) return;
    if (want.stop) {
      F.api("/api/backend/power", {method: "POST", body: {state: "off"}}).then(function () {
        F.toast("stopping exo…", "info");
        setTimeout(F.refresh, 1500);
      }, function (e) { F.toast("exo stop refused: " + e.message, "bad"); });
      return;
    }
    F.switchBackend(want.name, want.model).catch(function () { /* toasted */ });
  });
  $("exo-stop").addEventListener("click", function () {
    if (tr || down) return;
    beAskFor = {stop: true};
    var loc = BE.local(F.state);
    showAsk(BE.onCluster(F.state)
      ? "stop exo? nothing will serve until the backend is started again" +
        (loc ? " — switch to " + (loc.label || loc.name) + " to keep serving" : "")
      : "stop exo? it is running without faxl in front of it, so nothing is using it", "yes, stop exo");
  });

  function renderTop(s) {
    [renderProxy, renderBackend, renderBackendChoice, renderLossless, renderLicence,
     renderHfToken, renderNotices].forEach(function (fn) { safe(fn, s); });
  }

  // ---- the loop: every 3 s while visible, paused while hidden -------------
  // The shell polls /api/state; each page adds its own feeds with
  // faxl.addPoll(fn(tick, first) -> promise|null) and calls faxl.start() once
  // its script has run. first is true for the immediate call at start.
  var timer = null, tick = 0, pollers = [], started = false;
  F.addPoll = function (fn) { if (typeof fn === "function") pollers.push(fn); };
  function runPollers(first) {
    var jobs = [];
    pollers.forEach(function (p) {
      try {
        var j = p(tick, first);
        if (j && typeof j.then === "function") jobs.push(j.then(null, function () { return null; }));
      } catch (e) { if (window.console) console.error("faxl: poll failed", e); }
    });
    return jobs;
  }
  function loop() {
    timer = null;
    if (document.hidden) return;
    tick++;
    Promise.all([F.refresh()].concat(runPollers(false))).then(schedule, schedule);
  }
  function schedule() {
    if (timer || document.hidden || !started) return;
    timer = setTimeout(loop, POLL_MS);
  }
  document.addEventListener("visibilitychange", function () {
    if (timer) { clearTimeout(timer); timer = null; }
    if (!document.hidden && started) loop();
  });
  F.start = function () {
    if (started) return;
    started = true;
    if (!document.hidden) Promise.all(runPollers(true)).then(schedule, schedule);
  };

  // What page scripts share with the shell, so no page copies a helper.
  F.util = {$: $, el: el, get: get, setText: setText, isNum: isNum, esc: esc,
            midTrunc: midTrunc, shortModel: shortModel, safeHref: safeHref,
            pad: pad, MON: MON, DASH: DASH, safe: safe};
  F.backendLabel = function (name) { return backendLabel(F.state, name); };
  F.onState(renderTop);
})();
"""

# The panel's own body: left rail, chart, live log, drawer-request.
PANEL_BODY_JS = r"""
(function () {
  "use strict";
  var F = window.faxl;
  if (!F || !F.util) return;
  var U = F.util, fmt = F.fmt, $ = U.$, el = U.el, get = U.get, setText = U.setText,
      isNum = U.isNum, esc = U.esc, midTrunc = U.midTrunc, shortModel = U.shortModel,
      safeHref = U.safeHref, pad = U.pad, MON = U.MON, DASH = U.DASH, safe = U.safe;

  function renderWork(s) {
    var tok = get(s, "tokens") || {}, c = get(s, "counts") || {}, cache = get(s, "cache") || {};
    var rec = tok.received, sk = tok.skipped;
    setText("w-skipped", fmt.tok(sk), isNum(sk) ? fmt.int(sk) + " tokens" : "");
    setText("w-received", fmt.tok(rec), isNum(rec) ? fmt.int(rec) + " tokens" : "");
    var frac = (isNum(sk) && isNum(rec) && rec > 0) ? sk / rec : null;
    $("w-bar").style.width = frac == null ? "0" : Math.min(100, frac * 100).toFixed(1) + "%";
    setText("w-pct", frac == null ? DASH : fmt.pct(frac));
    setText("k-hitrate", fmt.pct(get(s, "hit_rate")));
    setText("k-requests", fmt.int(c.requests));
    setText("k-hits", fmt.int(c.hits));
    setText("k-misses", fmt.int(c.misses));
    setText("k-incomplete", fmt.int(c.incomplete));
    setText("k-rejected", fmt.int(c.rejected));
    setText("k-pending", fmt.int(c.pending));
    setText("k-prefilled", fmt.int(tok.prefilled));
    // Cold is a state, said plainly: no sample data, no projection.
    var msg = "", req = c.requests, entries = cache.entries;
    if (cache.cold === true) {
      if (!(isNum(sk) && sk > 0)) msg = "cold — " + (isNum(entries) ? entries : 0) +
        " entries, nothing skipped yet. The first requests will be misses.";
      else msg = "cold — " + (isNum(entries) ? entries : 0) +
        " entries in the store. The next requests will be misses until it warms.";
    } else if (req === 0) {
      msg = "No requests yet since the proxy started" +
        (isNum(entries) ? "; the store holds " + fmt.int(entries) + " entries." : ".");
    }
    var box = $("cold");
    setText("cold", msg);
    box.hidden = !msg;
  }
  function bandCell(x) {
    var td = el("td", "num");
    if (!x || !isNum(x.median_ms)) { td.textContent = DASH; return td; }
    td.appendChild(document.createTextNode(fmt.ms(x.median_ms) + " "));
    td.appendChild(el("span", "muted", "(" + (isNum(x.n) ? x.n : "?") + ")"));
    return td;
  }
  function renderBands(s) {
    var tb = $("bands"), bands = get(s, "first_reply.bands");
    tb.textContent = "";
    if (!Array.isArray(bands) || !bands.length) {
      var r0 = el("tr"), td0 = el("td", "muted", "no first-reply times measured yet");
      td0.colSpan = 3; r0.appendChild(td0); tb.appendChild(r0);
      return;
    }
    bands.forEach(function (b) {
      if (!b) return;
      var r = el("tr"), th = el("th", null, b.label || DASH);
      th.scope = "row";
      r.appendChild(th);
      var h = bandCell(b.hit), m = bandCell(b.miss);
      if (b.hit && b.miss && isNum(b.hit.median_ms) && isNum(b.miss.median_ms) && b.hit.median_ms > b.miss.median_ms) {
        h.classList.add("slower");
        h.title = "in this band, hits were slower than misses";
      }
      r.appendChild(h); r.appendChild(m);
      tb.appendChild(r);
    });
  }
  function renderStore(s) {
    var c = get(s, "cache") || {};
    setText("s-used", fmt.bytes(c.used_bytes));
    setText("s-cap", isNum(c.cap_bytes) ? fmt.bytes(c.cap_bytes) : (c.cap_bytes === null && isNum(c.used_bytes) ? "no cap" : DASH));
    var f = (isNum(c.used_bytes) && isNum(c.cap_bytes) && c.cap_bytes > 0) ? c.used_bytes / c.cap_bytes : null;
    $("s-bar").style.width = f == null ? "0" : Math.min(100, f * 100).toFixed(1) + "%";
    $("s-gauge").className = "bar gauge" + (f != null && f >= 0.9 ? " hi" : "");
    setText("s-pct", fmt.pct(f));
    setText("s-entries", fmt.int(c.entries));
    setText("s-free", fmt.bytes(c.free_bytes));
    setText("s-path", c.path ? midTrunc(c.path, 26) : DASH, c.path || "");
  }

  function renderCluster(s) {
    var c = get(s, "cluster"), card = $("card-cluster");
    card.hidden = !c;
    if (!c) return;
    var n = c.nodes, pf = c.prefill;
    setText("c-nodes", isNum(n) ? String(n) : DASH);
    setText("c-endpoint", get(s, "backend.exo.endpoint") || get(s, "backend.endpoint") || DASH);
    setText("c-req", pf ? fmt.int(pf.requests) : DASH);
    setText("c-hits", pf ? fmt.int(pf.hits) + (isNum(pf.hit_rate) ? " (" + fmt.pct(pf.hit_rate) + ")" : "") : DASH);
    setText("c-stored", pf ? fmt.int(pf.stored) : DASH);
    $("c-pnote").hidden = !!pf;
    var box = $("c-dls"), dls = Array.isArray(c.downloads) ? c.downloads : [];
    box.textContent = "";
    dls.forEach(function (d) {
      if (!d) return;
      var p = isNum(d.percent) ? Math.max(0, Math.min(100, d.percent)) : null;
      var row = el("div", "meter");
      var lab = el("span", "mono", shortModel(d.model) || DASH);
      lab.title = d.model || "";
      var bar = el("div", "bar"), fill = el("i");
      bar.setAttribute("role", "progressbar");
      bar.setAttribute("aria-label", "downloading " + (d.model || ""));
      if (p != null) bar.setAttribute("aria-valuenow", String(p));
      fill.style.width = p == null ? "0" : p.toFixed(1) + "%";
      bar.appendChild(fill);
      var pct = el("span", "mono", (p == null ? DASH : p.toFixed(1) + "%") +
        (isNum(d.gb) ? " of " + d.gb + " GB" : ""));
      row.appendChild(lab); row.appendChild(bar); row.appendChild(pct);
      box.appendChild(row);
    });
    if (!dls.length) box.appendChild(el("p", "note", "no downloads in flight"));
  }


  // ---- chart: received vs served from cache -------------------------------
  // Drawn from /api/requests (the newest 500 rows the endpoint allows), so it
  // is counted per request, never modelled. If 500 rows do not reach back to
  // the start of the range, the caption says exactly where the data starts.
  var CHART_LIMIT = 500;
  var RANGES = {"1h": 3600, "24h": 86400, "7d": 604800, "all": 0};
  var RANGE_NAME = {"1h": "the last hour", "24h": "the last 24 hours", "7d": "the last 7 days", "all": "the log"};
  var RANGE_CAP = {"1h": "Last hour", "24h": "Last 24 hours", "7d": "Last 7 days", "all": "All logged"};
  var LADDER = [60, 300, 900, 1800, 3600, 10800, 21600, 43200, 86400, 604800];
  var chart = {range: "24h", mode: "cum", rows: [], loaded: false, capped: false, stale: true, view: null};
  try {
    var pr = localStorage.getItem("faxl.chart.range"), pm = localStorage.getItem("faxl.chart.mode");
    if (pr && RANGES.hasOwnProperty(pr)) chart.range = pr;
    if (pm === "cum" || pm === "buckets") chart.mode = pm;
  } catch (e) { /* storage blocked: defaults */ }

  function num0(v) { return isNum(v) ? v : 0; }
  function chartData() {
    var now = Date.now() / 1000, span = RANGES[chart.range];
    var rows = chart.rows.filter(function (r) {
      return r && isNum(r.ts) && isNum(r.prompt_tokens) && (!span || r.ts >= now - span);
    }).sort(function (a, b) { return a.ts - b.ts; });
    var t0, t1;
    if (span) { t0 = now - span; t1 = now; }
    else if (rows.length) { t1 = Math.max(now, rows[rows.length - 1].ts); t0 = Math.min(rows[0].ts, t1 - 60); }
    else { t0 = now - 3600; t1 = now; }
    return {rows: rows, t0: t0, t1: t1, span: span};
  }
  function pickBucket(span) {
    for (var i = 0; i < LADDER.length; i++) if (span / LADDER[i] <= 60) return LADDER[i];
    return LADDER[LADDER.length - 1];
  }
  function niceScale(max) {
    if (!(max > 0)) max = 1;
    var raw = max / 4, mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), n = raw / mag;
    var step = (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * mag;
    if (step < 1) step = 1;
    var ticks = Math.max(1, Math.ceil(max / step));
    return {top: step * ticks, step: step, ticks: ticks};
  }
  function xLabel(t, span) {
    var d = new Date(t * 1000);
    if (span <= 2 * 86400) return pad(d.getHours()) + ":" + pad(d.getMinutes());
    return d.getDate() + " " + MON[d.getMonth()];
  }
  function f1(v) { return (Math.round(v * 10) / 10).toString(); }

  function drawChart() {
    var box = $("chart-box"), svg = $("chart"), empty = $("chart-empty");
    if (!box || !svg) return;
    var W = Math.floor(box.clientWidth), H = Math.floor(box.clientHeight);
    var D = chartData(), sumR = 0, sumC = 0;
    D.rows.forEach(function (r) { sumR += r.prompt_tokens; sumC += num0(r.prefill_skipped); });
    // caption: what this figure is, so a screenshot carries its provenance
    var cap = "Measured from the request log, not estimated. " + RANGE_CAP[chart.range] + ": " +
      fmt.int(D.rows.length) + " requests, " + fmt.tok(sumR) + " prompt tokens received, " +
      fmt.tok(sumC) + " served from cache" + (sumR > 0 ? " (" + fmt.pct(sumC / sumR) + ")" : "") + ".";
    if (chart.capped && chart.rows.length) {
      var oldest = Infinity;
      chart.rows.forEach(function (r) { if (r && isNum(r.ts) && r.ts < oldest) oldest = r.ts; });
      if (isFinite(oldest) && (!D.span || oldest > D.t0))
        cap += " Only the newest " + CHART_LIMIT + " requests are charted, from " + fmt.clock(oldest) + ".";
    }
    setText("chart-cap", chart.loaded ? cap : "loading the request log…");
    if (W < 60 || H < 60) return;
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("width", W); svg.setAttribute("height", H);
    if (!D.rows.length) {
      svg.textContent = ""; chart.view = null; hideTip();
      empty.textContent = !chart.loaded ? "" :
        (chart.rows.length ? "No requests in " + RANGE_NAME[chart.range] + "." :
         "No requests yet. The chart starts with the first one.");
      empty.hidden = false;
      return;
    }
    empty.hidden = true;
    var ML = 52, MR = 12, MT = 10, MB = 22, PW = W - ML - MR, PH = H - MT - MB;
    var v = {mode: chart.mode, ML: ML, PW: PW, W: W};
    var max = 0, pts = null, bk = null;
    if (chart.mode === "cum") {
      pts = [{t: D.t0, recv: 0, cache: 0}];
      var rr = 0, cc = 0;
      D.rows.forEach(function (r) { rr += r.prompt_tokens; cc += num0(r.prefill_skipped); pts.push({t: r.ts, recv: rr, cache: cc}); });
      max = Math.max(rr, cc);
      v.x0 = D.t0; v.x1 = D.t1; v.pts = pts;
    } else {
      var B = pickBucket(D.t1 - D.t0), start = Math.floor(D.t0 / B) * B;
      var nb = Math.floor((D.t1 - start) / B) + 1, arr = [];
      for (var i = 0; i < nb; i++) arr.push({t: start + i * B, recv: 0, cache: 0, n: 0});
      D.rows.forEach(function (r) {
        var k = Math.floor((r.ts - start) / B);
        if (k >= 0 && k < nb) { arr[k].recv += r.prompt_tokens; arr[k].cache += num0(r.prefill_skipped); arr[k].n++; }
      });
      arr.forEach(function (b) { if (b.recv > max) max = b.recv; if (b.cache > max) max = b.cache; });
      v.x0 = start; v.x1 = start + nb * B; v.arr = arr; v.B = B; v.start = start;
    }
    var sc = niceScale(max);
    function X(t) { return ML + PW * (t - v.x0) / ((v.x1 - v.x0) || 1); }
    function Y(val) { return MT + PH - PH * val / sc.top; }
    v.X = X;
    var g = "", k2;
    for (k2 = 0; k2 <= sc.ticks; k2++) {
      var val = sc.step * k2, yy = f1(Y(val));
      g += '<line class="grid" x1="' + ML + '" x2="' + (W - MR) + '" y1="' + yy + '" y2="' + yy + '"/>' +
           '<text class="ax" x="' + (ML - 6) + '" y="' + f1(Y(val) + 4) + '" text-anchor="end">' + esc(fmt.tok(val)) + '</text>';
    }
    var nx = Math.max(2, Math.min(8, Math.floor(PW / 110)));
    for (k2 = 0; k2 <= nx; k2++) {
      var t = v.x0 + (v.x1 - v.x0) * k2 / nx;
      var anc = k2 === 0 ? "start" : k2 === nx ? "end" : "middle";
      g += '<text class="ax" x="' + f1(X(t)) + '" y="' + (H - 6) + '" text-anchor="' + anc + '">' + esc(xLabel(t, v.x1 - v.x0)) + '</text>';
    }
    if (chart.mode === "cum") {
      var pR = "M" + f1(X(pts[0].t)) + " " + f1(Y(0)), pC = pR;
      for (var j = 1; j < pts.length; j++) {
        var xx = f1(X(pts[j].t));
        pR += "H" + xx + "V" + f1(Y(pts[j].recv));
        pC += "H" + xx + "V" + f1(Y(pts[j].cache));
      }
      var xe = f1(X(v.x1));
      pR += "H" + xe; pC += "H" + xe;
      g += '<path class="a2" d="' + pC + "V" + f1(Y(0)) + "H" + f1(X(pts[0].t)) + 'Z"/>' +
           '<path class="l1" d="' + pR + '"/><path class="l2" d="' + pC + '"/>';
    } else {
      v.arr.forEach(function (b) {
        if (!b.n) return;
        var xa = X(b.t) + 1, w = Math.max(2, X(b.t + v.B) - X(b.t) - 2), hw = Math.max(1, w / 2);
        g += '<rect class="b1" x="' + f1(xa) + '" y="' + f1(Y(b.recv)) + '" width="' + f1(hw) + '" height="' + f1(Y(0) - Y(b.recv)) + '"/>' +
             '<rect class="b2" x="' + f1(xa + hw) + '" y="' + f1(Y(b.cache)) + '" width="' + f1(hw) + '" height="' + f1(Y(0) - Y(b.cache)) + '"/>';
      });
    }
    g += '<line class="cross" id="chart-x" x1="0" x2="0" y1="' + MT + '" y2="' + (MT + PH) + '" visibility="hidden"/>';
    svg.innerHTML = g;
    chart.view = v;
  }
  function hideTip() {
    var tip = $("chart-tip"); if (tip) tip.style.display = "none";
    var c = $("chart-x"); if (c) c.setAttribute("visibility", "hidden");
  }
  function onChartMove(ev) {
    var v = chart.view, box = $("chart-box");
    if (!v) return;
    var rect = box.getBoundingClientRect(), px = ev.clientX - rect.left;
    if (px < v.ML || px > v.ML + v.PW) { hideTip(); return; }
    var t = v.x0 + (px - v.ML) / v.PW * (v.x1 - v.x0), text;
    if (v.mode === "cum") {
      var p = v.pts[0];
      for (var i = 1; i < v.pts.length && v.pts[i].t <= t; i++) p = v.pts[i];
      text = "by " + fmt.clock(t) + " · received " + fmt.int(p.recv) + " · from cache " + fmt.int(p.cache) +
             (p.recv > 0 ? " (" + fmt.pct(p.cache / p.recv) + ")" : "");
    } else {
      var b = v.arr[Math.max(0, Math.min(v.arr.length - 1, Math.floor((t - v.start) / v.B)))];
      text = fmt.clock(b.t) + " +" + fmt.dur(v.B) + " · " + b.n + " req · received " + fmt.int(b.recv) +
             " · from cache " + fmt.int(b.cache);
    }
    var c = $("chart-x");
    if (c) { c.setAttribute("x1", f1(px)); c.setAttribute("x2", f1(px)); c.setAttribute("visibility", "visible"); }
    var tip = $("chart-tip");
    tip.textContent = text; tip.style.display = "block";
    var tw = tip.offsetWidth || 240;
    tip.style.left = (px + 14 + tw > v.W ? Math.max(0, px - 14 - tw) : px + 14) + "px";
  }
  function pollChart() {
    return F.api("/api/requests?limit=" + CHART_LIMIT).then(function (d) {
      chart.rows = (d && Array.isArray(d.requests)) ? d.requests : [];
      chart.loaded = true; chart.capped = chart.rows.length >= CHART_LIMIT; chart.stale = false;
      drawChart();
    }, function () { /* the lamp already says why */ });
  }
  function pressed(groupId, attr, value) {
    Array.prototype.forEach.call($(groupId).querySelectorAll("button"), function (b) {
      b.setAttribute("aria-pressed", b.getAttribute(attr) === value ? "true" : "false");
    });
  }
  $("chart-range").addEventListener("click", function (ev) {
    var b = ev.target.closest ? ev.target.closest("button[data-range]") : null;
    if (!b) return;
    chart.range = b.getAttribute("data-range");
    pressed("chart-range", "data-range", chart.range);
    try { localStorage.setItem("faxl.chart.range", chart.range); } catch (e) { /* ignore */ }
    drawChart();
  });
  $("chart-mode").addEventListener("click", function (ev) {
    var b = ev.target.closest ? ev.target.closest("button[data-mode]") : null;
    if (!b) return;
    chart.mode = b.getAttribute("data-mode");
    pressed("chart-mode", "data-mode", chart.mode);
    try { localStorage.setItem("faxl.chart.mode", chart.mode); } catch (e) { /* ignore */ }
    drawChart();
  });
  pressed("chart-range", "data-range", chart.range);
  pressed("chart-mode", "data-mode", chart.mode);
  $("chart-box").addEventListener("mousemove", onChartMove);
  $("chart-box").addEventListener("mouseleave", hideTip);
  var rafPending = false;
  function schedDraw() {
    if (rafPending) return;
    rafPending = true;
    (window.requestAnimationFrame || setTimeout)(function () { rafPending = false; drawChart(); });
  }
  if (window.ResizeObserver) new ResizeObserver(schedDraw).observe($("chart-box"));
  else window.addEventListener("resize", schedDraw);

  // ---- the live request log ---------------------------------------------
  var log = {rows: [], known: null, byKey: {}, inflight: null, live: ""};
  function rowKey(r) { return r.transaction_id ? String(r.transaction_id) : (r.ts + "|" + r.client); }
  function rowSig(r) {
    // A PENDING ROW'S AGE IS PART OF ITS SIGNATURE. fillRow only runs when the
    // signature changes, so without the age bucket the "in flight 2m" clock
    // would freeze at whatever it said when the row first appeared. Bucketed
    // to 10s so a settled table is not re-rendered every poll for nothing.
    var age = (String(r.status || "").toLowerCase() === "pending" && isNum(r.ts))
      ? Math.floor(((Date.now() / 1000) - r.ts) / 10) : "";
    return [r.status, r.outcome, r.prompt_tokens, r.prefill_skipped, r.prefill_paid, r.resume_pos,
            r.ttft_ms, r.model, r.client, r.ts, age].join("|");
  }
  function resultPill(r) {
    var o = String(r.outcome || "").toUpperCase(), st = String(r.status || "").toLowerCase();
    if (o === "HIT") return el("span", "pill pill-ok", "hit");
    if (o === "MISS") return el("span", "pill", "miss");
    if (st === "rejected") { var p = el("span", "pill pill-bad", "rejected"); if (r.reject_reason) p.title = r.reject_reason; return p; }
    if (st === "incomplete") return el("span", "pill pill-warn", "incomplete");
    if (st === "pending") {
      // HOW LONG IT HAS BEEN IN FLIGHT, not just that it is.
      //
      // Two rows sat at a bare "in flight" for eight minutes with nothing to
      // say whether they were working or wedged -- the aggregator only
      // relabels them "incomplete" after a 30-MINUTE watermark, so the table
      // looked alive and healthy while the proxy was stuck behind a zombie.
      // The age is the one fact that distinguishes a long prefill from a hang,
      // and it costs a subtraction. (AM, 2026-10-03.)
      var age = isNum(r.ts) ? Math.max(0, (Date.now() / 1000) - r.ts) : null;
      var p = el("span", "pill pill-info",
                 "in flight" + (age === null ? "" : " " + fmt.dur(age)));
      if (age !== null && age > 120) p.className = "pill pill-warn";
      p.title = age === null ? "" :
        ("running " + fmt.dur(age) + " — the console calls it incomplete at 30 min");
      return p;
    }
    return el("span", "pill", st || DASH);
  }
  function td(text, cls, title) {
    var c = el("td", cls || null, text);
    if (title) c.title = title;
    return c;
  }
  function fillRow(tr, r) {
    tr.textContent = "";
    var d = isNum(r.ts) ? new Date(r.ts * 1000) : null;
    tr.appendChild(td(fmt.clock(r.ts), "mono", d ? d.toString() : ""));
    var cell = el("td"); cell.appendChild(resultPill(r));
    // KILL. Only on a row that is actually in flight, and only when we have
    // the txn id to name it with. POST /v1/cancel sets a flag the prefill loop
    // and the decode loop both poll, so the stop lands at the next chunk or
    // the next token -- it never waits on the serve lock, which is the whole
    // reason it can answer while the proxy is busy.
    if (String(r.status || "").toLowerCase() === "pending" && r.transaction_id) {
      var k = el("button", "btn btn-quiet rq-kill", "kill");
      k.type = "button";
      k.title = "stop this request — lands at the next chunk (prefill) or next token (generating)";
      k.addEventListener("click", function (ev) {
        ev.stopPropagation();            // the row itself opens the drawer
        k.disabled = true; k.textContent = "stopping…";
        F.api("/v1/cancel", {method: "POST", body: {id: String(r.transaction_id)}})
          .then(function (d) {
            F.toast(d && d.was_running ? "stopping — it lands within a chunk or a token"
                                       : "that request had already finished", "info");
          }, function (e) {
            k.disabled = false; k.textContent = "kill";
            F.toast("could not stop it: " + (e && e.message), "bad");
          });
      });
      cell.appendChild(k);
    }
    tr.appendChild(cell);
    tr.appendChild(td(fmt.int(r.prompt_tokens), "num"));
    tr.appendChild(td(fmt.int(r.prefill_skipped), "num"));
    tr.appendChild(td(fmt.int(r.prefill_paid), "num"));
    var hit = String(r.outcome || "").toUpperCase() === "HIT";
    var noResume = !hit && r.resume_pos === 0;
    tr.appendChild(td(noResume ? DASH : fmt.int(r.resume_pos), "num", noResume ? "nothing resumed" : ""));
    tr.appendChild(td(fmt.ms1(r.ttft_ms), "num", isNum(r.ttft_ms) ? "" : "not measured"));
    tr.appendChild(td(fmt.model(r.model), "trunc c-model", r.model || ""));
    tr.appendChild(td(r.client || DASH, "trunc c-client", r.client || ""));
    var hay = [hit ? "hit" : "", String(r.outcome || "").toLowerCase(), String(r.status || "").toLowerCase(),
               String(r.client || "").toLowerCase(), shortModel(r.model).toLowerCase(), String(r.model || "").toLowerCase()];
    tr.setAttribute("data-hay", hay.join(" "));
    tr.setAttribute("aria-label", "request " + fmt.clock(r.ts) + ", " + (hit ? "hit" : String(r.outcome || r.status || "").toLowerCase()) + ", open details");
  }
  function makeRow(key) {
    var tr = el("tr");
    tr.tabIndex = 0;
    tr.setAttribute("data-key", key);
    tr.addEventListener("click", function () { openRequest(key); });
    tr.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); openRequest(key); }
    });
    return tr;
  }
  function renderLog(rows) {
    var body = $("log-body"), first = log.known === null, fresh = 0;
    var next = {}, seen = log.known || {};
    log.rows = rows;
    rows.forEach(function (r, i) {
      if (!r) return;
      var key = rowKey(r), ent = log.byKey[key];
      if (!ent) { ent = {tr: makeRow(key), sig: ""}; }
      ent.row = r;
      var sig = rowSig(r);
      if (sig !== ent.sig) { fillRow(ent.tr, r); ent.sig = sig; }
      if (!first && !seen[key]) {
        fresh++;
        var t = ent.tr;
        t.classList.remove("flash"); void t.offsetWidth; t.classList.add("flash");
        setTimeout(function () { t.classList.remove("flash"); }, 2600);
      }
      next[key] = ent;
      if (body.children[i] !== ent.tr) body.insertBefore(ent.tr, body.children[i] || null);
    });
    while (body.children.length > Object.keys(next).length) body.removeChild(body.lastChild);
    log.byKey = next;
    var known = {};
    Object.keys(next).forEach(function (k) { known[k] = true; });
    if (log.known) Object.keys(log.known).forEach(function (k) { known[k] = true; });
    log.known = known;
    if (fresh) chart.stale = true;
    var empty = $("log-empty");
    if (!rows.length) {
      var s = F.state || {};
      empty.textContent = get(s, "cache.cold") === true ?
        "No requests yet. The cache is cold, so the first requests will be misses." :
        "No requests yet.";
    }
    empty.hidden = rows.length > 0;
    applyFilter();
  }
  function applyFilter() {
    var q = String($("log-filter").value || "").toLowerCase().split(/\s+/).filter(Boolean);
    var shown = 0, total = 0;
    Array.prototype.forEach.call($("log-body").children, function (tr) {
      total++;
      var hay = tr.getAttribute("data-hay") || "";
      var ok = q.every(function (w) { return hay.indexOf(w) >= 0; });
      tr.hidden = !ok;
      if (ok) shown++;
    });
    setText("log-count", q.length ? shown + " of " + total : total + " rows");
  }
  $("log-filter").addEventListener("input", applyFilter);
  function setLive(text) {
    if (log.live === text) return;
    log.live = text;
    setText("log-live", text);
  }
  function pollLog() {
    if (log.inflight) return log.inflight;
    log.inflight = F.api("/api/requests?limit=200").then(function (d) {
      log.inflight = null;
      renderLog((d && Array.isArray(d.requests)) ? d.requests : []);
      setLive("live");
      setText("log-upd", "updated " + fmt.clock(Date.now() / 1000));
    }, function (e) {
      log.inflight = null;
      setLive(e && e.network ? "not answering — showing the last rows received" : "log unavailable: " + (e && e.message));
    });
    return log.inflight;
  }

  // ---- drawer-request ----------------------------------------------------
  var reqToken = 0;
  function kv(pairs) {
    var dl = el("dl", "kv");
    pairs.forEach(function (p) {
      if (!p) return;
      dl.appendChild(el("dt", null, p[0]));
      var dd = el("dd", p[2] || null, p[1]);
      if (p[3]) dd.title = p[3];
      dl.appendChild(dd);
    });
    return dl;
  }
  function summary(d, r) {
    var c = d.cost || null, o = String(d.outcome || r.outcome || "").toUpperCase(), st = d.status || r.status;
    if (st === "rejected" || d.reject_reason) return "Rejected" + (d.reject_reason ? ": " + d.reject_reason : "") + ".";
    if (!c) return st === "pending" ? "In flight — no completion recorded yet." :
                   "No completion recorded (" + (st || "unknown") + ").";
    var s;
    if (o === "HIT") s = "Hit: " + fmt.int(c.prefill_skipped) + " of " + fmt.int(c.prompt_tokens) +
                         " prompt tokens came from the cache; " + fmt.int(c.prefill_paid) + " were prefilled.";
    else if (o === "MISS") s = "Miss: " + fmt.int(c.prefill_paid) + " of " + fmt.int(c.prompt_tokens) + " prompt tokens were prefilled.";
    else s = fmt.int(c.prefill_paid) + " of " + fmt.int(c.prompt_tokens) + " prompt tokens were prefilled.";
    s += isNum(c.ttft_ms) ? " First reply " + fmt.ms(c.ttft_ms) + "." : " First reply not measured by this backend.";
    return s;
  }
  function renderRequest(d, r) {
    var body = $("req-body"), c = d.cost || {}, tm = d.timings_ms || {}, st = d.start || {};
    body.textContent = "";
    body.appendChild(el("p", "req-sum", summary(d, r)));
    body.appendChild(el("h3", null, "Request"));
    body.appendChild(kv([
      ["time", isNum(r.ts) ? fmt.clock(r.ts) + " (" + fmt.ago(r.ts) + ")" : DASH, "mono"],
      ["status", fmt.dash(d.status)],
      ["outcome", fmt.dash(d.outcome ? String(d.outcome).toLowerCase() : null)],
      ["hit tier", fmt.dash(d.hit_tier && d.hit_tier !== "HIT_TIER_UNSPECIFIED" ? String(d.hit_tier).toLowerCase() : null)],
      ["model", fmt.dash(d.model), "wrap"],
      ["client", fmt.dash(st.client_label || r.client)],
      ["backend", fmt.dash(d.backend)],
      ["messages", fmt.int(st.n_messages)],
      ["prompt size", fmt.bytes(st.prompt_bytes)],
      ["transaction", fmt.dash(d.transaction_id), "wrap"]
    ]));
    body.appendChild(el("h3", null, "Tokens"));
    body.appendChild(kv([
      ["prompt tokens", fmt.int(c.prompt_tokens)],
      ["from cache", fmt.int(c.prefill_skipped)],
      ["prefilled", fmt.int(c.prefill_paid)],
      ["resumed at", fmt.int(d.resume_pos)],
      ["generated", fmt.int(d.out_tokens)]
    ]));
    body.appendChild(el("h3", null, "Time"));
    body.appendChild(kv([
      ["first reply", fmt.ms(c.ttft_ms)],
      ["wall clock", fmt.ms(c.warm_wall_ms)],
      ["hash build", fmt.ms(tm.hash_build)],
      ["confirm", fmt.ms(tm.confirm)],
      ["blob load", fmt.ms(tm.blob_load)],
      ["prefill", fmt.ms(tm.prefill)],
      ["decode", fmt.ms(tm.decode)]
    ]));
    if (c.cold_basis && c.cold_basis !== "BASIS_UNSPECIFIED") {
      var basis = String(c.cold_basis).toLowerCase();
      body.appendChild(el("h3", null, "Cold baseline"));
      body.appendChild(kv([["cold prefill (" + basis + ")", fmt.ms(c.cold_prefill_ms_est), null,
        basis === "estimated" ? "a model of what this prompt would cost cold, not a measurement" : ""]]));
    }
    if (Array.isArray(d.ladder) && d.ladder.length) {
      body.appendChild(el("h3", null, "Lookup ladder"));
      var tbl = el("table", "mini"), th = el("tr");
      ["position", "confirm", "rung key"].forEach(function (h) { var x = el("th", null, h); x.scope = "col"; th.appendChild(x); });
      var thead = el("thead"); thead.appendChild(th); tbl.appendChild(thead);
      var tb = el("tbody");
      d.ladder.forEach(function (p) {
        if (!p) return;
        var row = el("tr");
        row.appendChild(el("td", null, fmt.int(p.position)));
        row.appendChild(el("td", null, fmt.dash(p.confirm ? String(p.confirm).replace(/^CONFIRM_/, "").toLowerCase() : null)));
        row.appendChild(el("td", null, fmt.dash(p.rung_key)));
        tb.appendChild(row);
      });
      tbl.appendChild(tb); body.appendChild(tbl);
    }
    if (d.reject_reason) {
      body.appendChild(el("h3", null, "Rejected"));
      body.appendChild(el("p", "mono", d.reject_reason));
    }
  }
  function openRequest(key) {
    var ent = log.byKey[key], r = ent ? ent.row : null;
    if (!r) return;
    showRequest(r);
  }
  // r is a log row, or {transaction_id} alone when the request came from a URL
  // (?txn=) and is not in the rows loaded so far: the drawer then reads
  // everything it shows from /api/requests/<id>.
  function showRequest(r) {
    var id = r.transaction_id, my = ++reqToken, body = $("req-body");
    setText("drawer-request-h", "Request " + (isNum(r.ts) ? fmt.clock(r.ts) : ""));
    body.textContent = "";
    body.appendChild(el("p", "muted", id ? "loading…" : "This row has no transaction id."));
    var j = $("req-json");
    j.hidden = !id;
    if (id) j.href = "/api/requests/" + encodeURIComponent(id);
    F.openDrawer("drawer-request");
    if (!id) return;
    F.api("/api/requests/" + encodeURIComponent(id)).then(function (d) {
      if (my !== reqToken) return;
      renderRequest(d && typeof d === "object" ? d : {}, r);
    }, function (e) {
      if (my !== reqToken) return;
      body.textContent = "";
      body.appendChild(el("p", "muted", "Could not load this request: " + e.message));
    });
  }

  // ---- ?open=<drawer-id> and ?txn=<id> -----------------------------------
  // The old per-page URLs redirect here (plan: "Retired pages"): /console/licence
  // lands on /console?open=drawer-licence, /console/requests?txn=X on
  // ?open=drawer-request&txn=X. Run once every inline script has, so the right
  // module's drawers exist and are listening; an unknown drawer id is ignored.
  // The parameters then leave the address bar, so a reload does not reopen it.
  function openFromUrl() {
    var q;
    try { q = new URLSearchParams(location.search); } catch (e) { return; }
    var want = q.get("open"), txn = q.get("txn");
    if (!want && !txn) return;
    if (txn && (!want || want === "drawer-request")) showRequest({transaction_id: txn});
    else if (want && /^drawer-[a-z-]+$/.test(want)) F.openDrawer(want);
    q.delete("open"); q.delete("txn");
    var rest = q.toString();
    try {
      history.replaceState(history.state, "", location.pathname + (rest ? "?" + rest : "") + location.hash);
    } catch (e) { /* a sandboxed frame may refuse; the drawer is open regardless */ }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", openFromUrl);
  else setTimeout(openFromUrl, 0);

  // The engine card: state.engine (an in-process engine with settings or
  // counters of its own -- vLLM on Linux). Every row is from the state; the
  // settings and stats blocks are rendered key by key, never by name.
  function kvRows(box, obj) {
    box.textContent = "";
    Object.keys(obj || {}).forEach(function (k) {
      var v = obj[k];
      if (v !== null && typeof v === "object") return;
      box.appendChild(el("dt", null, k.replace(/_/g, " ")));
      box.appendChild(el("dd", "mono", v === null || v === undefined ? DASH : String(v)));
    });
  }
  function renderEngine(s) {
    var e = get(s, "engine"), card = $("card-engine");
    card.hidden = !e;
    if (!e) return;
    setText("e-aux", e.label || DASH);
    setText("e-where", e.endpoint ? e.endpoint + (e.up === false ? " · not answering" : " · up")
                                  : "in this process" + (e.up === false ? " · down" : " · up"));
    setText("e-model", e.model || DASH, e.model || "");
    setText("e-mem", fmt.budget(s) || DASH);
    kvRows($("e-settings"), e.settings);
    kvRows($("e-stats"), e.stats);
    $("e-snote").hidden = !!e.stats;
  }
  function renderBody(s) {
    [renderWork, renderCluster, renderEngine, renderBands, renderStore].forEach(function (fn) { safe(fn, s); });
  }
  F.onState(renderBody);
  drawChart();
  // The log and the chart ride the shell's 3 s loop.
  F.addPoll(function (t, first) {
    var jobs = [pollLog()];
    if (first || chart.stale || t % 5 === 0) jobs.push(pollChart()); else drawChart();
    return Promise.all(jobs);
  });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) setLive("paused while this tab is hidden");
  });
  if (document.hidden) setLive("paused while this tab is hidden");
  F.start();
})();
"""

# The panel's script as one string (the shell's runtime, then its body).
PANEL_JS = RUNTIME_JS + PANEL_BODY_JS

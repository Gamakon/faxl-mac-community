# Vendored engine module (faxl_console_human.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Human-mode console — a single self-contained HTML asset (spec §5).

One embedded page: inline CSS + JS, no external assets (CSP: default-src 'none';
style-src/script-src 'unsafe-inline'; connect-src 'self'). It polls /api/* every
2 s and renders the same data model the Agent view renders — the frontend never
hardcodes which metric is the headline (backend orders savings[]), and an
`estimated` value is always visibly marked (structural honesty).

Brand tokens (§4) are PLACEHOLDERS (gamakon.ai values are an open AM item) — the
structure is here; the exact colors are TBD and must not be fabricated.

RETIRED FROM SERVICE (2026-09-21). This was the human /console/analytics page;
a person's /console is the desktop control panel (faxl_panel) now and that URL
redirects there. The module is kept because tools/sync_engine.py vendors it to
every line, and its links were pointed at the panel so that nothing it renders,
anywhere, sends a person to a retired page: the footer lists welcome, apps and
the agent view only; verify and licence open the panel's drawers.
"""

# NOTE: brand values are TBD placeholders (neutral), not invented gamakon colors.
HUMAN_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>faxl — console</title>
<style>
  /* ---- brand tokens (§4) — TBD PLACEHOLDERS, not fabricated gamakon values ---- */
  :root{
    --ink:#1a1a1a; --ink-2:#666; --paper:#fafaf8; --paper-2:#fff;
    --line:#e3e3df; --accent:#2b7a5b; --accent-2:#b06a2c; --danger:#b02c2c;
    --series-1:#2a78d6; --series-2:#1baf7a; /* chart: received / from cache (validated) */
    --font-sans:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    --font-mono:"SF Mono",Menlo,Consolas,monospace;
    --radius:4px;
  }
  :root:not([data-theme="light"]){}
  @media (prefers-color-scheme:dark){
    :root:not([data-theme="light"]){
      --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
      --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
    --series-1:#3987e5; --series-2:#199e70;
    }
  }
  :root[data-theme="dark"]{
    --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
    --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
    --series-1:#3987e5; --series-2:#199e70;
  }
  *{box-sizing:border-box}
  body{background:var(--paper);color:var(--ink);font-family:var(--font-sans);
       margin:0;padding:64px 16px 40px;}
  .wrap{max-width:960px;margin:0 auto}
  .mono{font-family:var(--font-mono);font-variant-numeric:tabular-nums}
  .headline{font-family:var(--font-mono);font-size:clamp(28px,5vw,56px);line-height:1.05;
            font-variant-numeric:tabular-nums;margin:0}
  .sub{color:var(--ink-2);margin:8px 0 0;font-size:15px}
  .est{color:var(--accent-2);font-size:.7em;font-weight:600;text-transform:uppercase;
       letter-spacing:.04em;margin-left:.4em}
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
         gap:16px;margin:40px 0}
  .tile{background:var(--paper-2);border:1px solid var(--line);border-radius:var(--radius);
        padding:16px}
  .tile .label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;
               color:var(--ink-2)}
  .tile .val{font-family:var(--font-mono);font-size:clamp(16px,2.2vw,28px);
             margin-top:6px;font-variant-numeric:tabular-nums;
             overflow-wrap:anywhere}
  .badge{display:inline-block;margin-top:24px;padding:6px 12px;border-radius:var(--radius);
         border:1px solid var(--line);font-size:14px}
  .badge.pass{color:var(--accent);border-color:var(--accent)}
  .badge.fail{color:var(--danger);border-color:var(--danger)}
  .badge.never{color:var(--ink-2)}
  .tile .pair{display:flex;align-items:baseline;gap:.5em;flex-wrap:wrap}
  .tile .pair .val{font-size:1.25rem}
  .tile .pair .plabel{font-size:12px;color:var(--ink-2)}
  a{color:var(--accent);text-decoration:none}
  a:after{content:" →"}
  a.plain:after{content:""}
  .nav{margin:.2em 0 1.6em;font-size:13px;color:var(--ink-2)}
  /* This page gives every link a trailing arrow, which reads as "go do this".
     A site map is not a call to action, and the nav links are injected by the
     shared _nav_html() so they cannot carry the .plain class. Suppress it in
     the nav's own scope instead. */
  .nav a:after{content:""}
  .nav a{color:var(--ink-2);text-decoration:none;border-bottom:1px solid var(--line)}
  .nav a:hover{color:var(--accent);border-bottom-color:var(--accent)}
  .foot{margin-top:40px;color:var(--ink-2);font-size:13px;border-top:1px solid var(--line);
        padding-top:16px}
  table{width:100%;border-collapse:collapse;margin-top:24px;font-size:14px}
  td,th{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}
  th{color:var(--ink-2);font-weight:600;font-size:12px;text-transform:uppercase}
  /* Same card as the shell's TABLE_CSS, in this asset's token names -- the
     standalone page does not go through faxl_shell.page(). */
  .table-card{background:var(--paper-2);border:1px solid var(--line);margin:24px 0}
  .table-scroll{max-height:420px;overflow:auto}
  .table-card table{margin:0}
  .table-card thead th{position:sticky;top:0;background:var(--paper-2);
    border-bottom:1px solid var(--line);padding:10px 12px;z-index:1}
  .table-card td{padding:8px 12px}
  .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
  .chartbtn{font:12px var(--font-sans);padding:4px 10px;border:1px solid var(--line);
            background:var(--paper-2);color:var(--ink-2);border-radius:var(--radius);
            cursor:pointer}
  .chartbtn.active{color:var(--ink);border-color:var(--accent)}
  .hit{background:var(--accent)} .miss{background:var(--accent-2)}
  /* ---- licence panel (T-0004) ------------------------------------------- */
  /* The banner is the point of this page: it must say WHICH thing went wrong.
     .banner-error is for a key that cannot be used (malformed / bad signature).
     .banner-lapsed is EXPIRED and is deliberately NOT red — that customer is a
     renewal, not a mistake, and dressing it as a failure is the thing the
     ticket asks us not to do. */
  #lic-card{border:1px solid var(--line);border-radius:var(--radius);
            background:var(--paper-2);padding:20px;margin-top:32px}
  #lic-card h2{font-size:15px;margin:0 0 4px;font-weight:600}
  #lic-card .hint{font-size:13px;color:var(--ink-2);margin:0 0 14px}
  #lic-key{width:100%;box-sizing:border-box;min-height:76px;resize:vertical;
           font-family:var(--font-mono);font-size:12px;line-height:1.5;
           padding:10px;border:1px solid var(--line);border-radius:var(--radius);
           background:var(--paper);color:var(--ink)}
  #lic-key:focus{outline:2px solid var(--accent);outline-offset:-1px}
  #lic-actions{display:flex;align-items:center;gap:12px;margin-top:10px}
  #lic-save{font:inherit;font-size:13px;padding:7px 16px;cursor:pointer;
            border:1px solid var(--accent);border-radius:var(--radius);
            background:var(--accent);color:#fff}
  #lic-save[disabled]{opacity:.55;cursor:default}
  #lic-note{font-size:13px;color:var(--ink-2)}
  .banner{border-radius:var(--radius);padding:11px 13px;margin:14px 0 0;
          font-size:13px;line-height:1.5}
  .banner-error{border:1px solid var(--danger);
                background:color-mix(in srgb,var(--danger) 7%,transparent);
                color:var(--danger)}
  .banner-lapsed{border:1px solid var(--accent-2);
                 background:color-mix(in srgb,var(--accent-2) 8%,transparent);
                 color:var(--accent-2)}
  .banner-ok{border:1px solid var(--accent);
             background:color-mix(in srgb,var(--accent) 8%,transparent);
             color:var(--accent)}
  .banner b{font-weight:600}
  .banner .detail{display:block;margin-top:5px;font-family:var(--font-mono);
                  font-size:11.5px;opacity:.85}
  .banner a{color:inherit}
  /* the read-only "what this key grants" view */
  #lic-grant{margin-top:16px;border-top:1px solid var(--line);padding-top:14px}
  #lic-grant dl{display:grid;grid-template-columns:max-content 1fr;
                gap:7px 18px;margin:0;font-size:13px}
  #lic-grant dt{color:var(--ink-2)}
  #lic-grant dd{margin:0}
  #lic-grant .advisory{color:var(--ink-2);font-size:12px;font-style:italic}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <p class="mono" style="color:var(--ink-2);font-size:13px">gamakon · faxl</p>
  <!-- The site map, for a HUMAN. This page is a self-contained asset that does
       NOT go through the agent renderer's nav, so for a browser it offered only
       "verify" and the agent view: register, licence, requests and models all
       answered 200 and were reachable by nobody holding a mouse.
       The links are INJECTED, not written here: this asset is vendored to every
       line (mac, nvidia) and the lines do not serve the same routes, so a
       hardcoded list would have one line advertising another line's 404s. The
       console substitutes _nav_html() for this placeholder at serve time, from
       the same _NAV_ITEMS the agent renderer uses. -->
  <p class="nav" id="nav"><!--nav--></p>
  <h1 class="headline" id="headline">…</h1>
  <p class="sub" id="sub"></p>
  <div class="tiles" id="tiles"></div>
  <div id="lossless"></div>
  <div id="chartbox" style="margin-top:32px">
    <div style="font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-2)">
      tokens, running total</div>
    <div style="font-size:13px;color:var(--ink-2);margin:6px 0 4px">
      <span style="color:var(--series-1)">●</span> received from users&nbsp;&nbsp;
      <span style="color:var(--series-2)">●</span> served from cache</div>
    <svg id="chart" width="100%" height="180" viewBox="0 0 900 180"
         style="display:block"></svg>
    <div id="charttip" class="mono" style="display:none;font-size:12px;color:var(--ink-2);margin-top:2px"></div>
    <p id="chartcaption" style="font-style:italic;font-size:13px;color:var(--ink-2);margin:8px 0 0">
      loading…</p>
    <div style="margin-top:8px">
      <button id="mode-cum" class="chartbtn active">running total</button>
      <button id="mode-buckets" class="chartbtn">per interval</button>
    </div>
  </div>
  <div class="table-card"><div class="table-scroll">
  <table id="recent" style="margin-top:0"><thead><tr>
    <th>time</th><th>hit/miss</th><th>prompt<br>(tokens)</th><th>from cache<br>(tokens)</th>
    <th>resumed at<br>(token)</th><th>first reply<br>(ms)</th><th>took<br>(s)</th><th>speed<br>(tok/s)</th><th>client</th>
  </tr></thead><tbody id="recent-body"></tbody></table>
  </div></div>
  <!-- The licence panel lived here too, in a second design that shared no
       markup with /console/licence: two different boxes, two different
       layouts, for one job. It is on its own page now, which the welcome page
       links when no key is installed. One licence UI, one place. -->
  <p class="hint" id="lic-pointer" style="margin-top:1.5rem"></p>
  <p class="foot" id="foot">
    <span id="foot-status">loading…</span> ·
    <a href="/console" class="plain">welcome</a> ·
    <a href="/console/apps" class="plain">apps</a> ·
    <a href="/console?mode=agent" class="plain">agent view →</a>
  </p>
</div>
<script>
  // No external calls (CSP connect-src 'self'); poll our own /api.
  var REDUCED = matchMedia("(prefers-reduced-motion:reduce)").matches;
  function fmtCompact(n){
    // metric exponents for big counts: 12,300 -> 12.3k, 3,636,158 -> 3.64M,
    // trillions -> T. 3 significant digits; exact value goes in the title.
    if(n==null) return "—";
    var a=Math.abs(n);
    if(a<10000) return Number.isInteger(n)?n.toLocaleString():n.toFixed(2);
    var u=[["T",1e12],["B",1e9],["M",1e6],["k",1e3]];
    for(var i=0;i<u.length;i++){
      if(a>=u[i][1]) return (n/u[i][1]).toPrecision(3).replace(/\.0+$/,"")+u[i][0];
    }
    return String(n);
  }
  function fmtMs(x){ // large millisecond values read better as seconds
    if(x==null) return "—";
    return x>=1000 ? (x/1000).toFixed(2)+" s" : Math.round(x)+" ms";
  }
  function fmtNum(v){
    if(Array.isArray(v)) return v.map(function(x){return x==null?"—":fmtNum(x)}).join(" / ");
    if(typeof v==="number"){ return Number.isInteger(v)?String(v):v.toFixed(2); }
    return String(v);
  }
  function estMark(e){
    if(e.basis!=="estimated") return "";
    // "measured 0%" read as a verdict on the whole page. Say what it counts:
    // how many of the requests behind this total had a MEASURED saving.
    var c = e.coverage, cov = "";
    if(c && c.n_measured!=null && c.n_estimated!=null)
      cov = " · "+c.n_measured+" of "+(c.n_measured+c.n_estimated)+
            " requests measured, the rest modelled";
    else if(c && c.measured_fraction!=null)
      cov = " · "+Math.round(c.measured_fraction*100)+"% of it measured";
    return ' <span class="est">estimated'+cov+'</span>';
  }
  function render(ov){
    var s = ov.savings||[];
    var head = s[0];
    var headTxt = "waiting for first request";
    if(head){
      if(head.total_received){
        var pct = Math.round(100*head.value/Math.max(head.total_received,1));
        headTxt = fmtCompact(head.value)+" of "+fmtCompact(head.total_received)+
                  " prompt tokens served from cache — "+pct+"%";
      } else {
        headTxt = fmtNum(head.value)+" "+head.unit+" "+(head.label||"");
      }
    }
    document.getElementById("headline").innerHTML = headTxt;
    var subEntries = s.slice(1,3).map(function(e){
      // the label already says "(estimated)"; the mark says it once, louder.
      var lab = (e.label||"").replace(/\s*\(estimated\)\s*$/,"");
      var v = (e.unit==="ratio"&&typeof e.value==="number") ?
        Math.round(e.value*100)+"%" : fmtNum(e.value)+" "+e.unit;
      return v+" "+lab+estMark(e);
    });
    document.getElementById("sub").innerHTML = subEntries.join(" · ");
    // tiles
    document.getElementById("tiles").innerHTML = (ov.tiles||[]).map(function(t){
      var val, exact;
      if(Array.isArray(t.value) && Array.isArray(t.parts)){
        // A pair with NAMED parts (first reply: cache hit vs cold). "15.63 s /
        // 2.66 s" does not say which is which, and the order is not guessable
        // -- so each number carries its own label and its sample size.
        var f = t.unit==="ms" ? fmtMs : fmtCompact;
        exact = fmtNum(t.value)+(t.unit?" "+t.unit:"");
        return '<div class="tile"><div class="label">'+(t.label||t.key)+'</div>'+
          t.value.map(function(x,i){
            var n = (t.n&&t.n[i]!=null) ? " · n="+t.n[i] : "";
            return '<div class="pair"><span class="val" title="'+
              (x==null?"not measured":fmtNum(x)+" "+t.unit)+'">'+f(x)+
              '</span><span class="plabel">'+(t.parts[i]||"")+n+'</span></div>';
          }).join("")+estMark(t)+'</div>';
      }
      if(t.unit==="ms"){
        val = Array.isArray(t.value)? t.value.map(fmtMs).join(" / ") : fmtMs(t.value);
        exact = fmtNum(t.value)+" ms";
      } else {
        val = Array.isArray(t.value)? t.value.map(fmtCompact).join(" / ")
                                    : fmtCompact(t.value);
        exact = fmtNum(t.value)+(t.unit?" "+t.unit:"");
        if(t.unit&&t.unit!=="ratio"&&t.unit!=="count"&&t.unit!=="days") val += " "+t.unit;
      }
      var style = (t.key==="licence" && t.value < 30) ?
        ' style="color:var(--accent-2)"' : "";
      return '<div class="tile"><div class="label">'+(t.label||t.key)+'</div>'+
             '<div class="val"'+style+' title="'+exact+'">'+val+
             (t.key==="licence" ? " days left" : "") +
             '</div>'+estMark(t)+'</div>';
    }).join("");
    // lossless badge
    var L = ov.lossless||{}; var cls="never";
    var txt="lossless: never verified on this machine", go="run the check →";
    if(L.status==="pass"){cls="pass";txt="✓ lossless";go="verify again →";}
    else if(L.status==="fail"){cls="fail";txt="✕ verify failed";go="see why →";}
    document.getElementById("lossless").innerHTML =
      '<span class="badge '+cls+'">'+txt+' · <a href="/console?open=drawer-verify">'+go+'</a></span>';
    // chart caption: provenance for screenshots — what this figure IS
    var cap = document.getElementById("chartcaption");
    if(cap) cap.textContent =
      "faxl prefill-cache console — model "+(ov.model||"?")+" at "+(ov.bind||"?")+
      ". Prompt tokens received from users vs served from the cache ("+
      (chartMode==="cum"?"running total":"volume per "+bucketLabel)+
      "); all token counts measured, not estimated.";
    // footer
    document.getElementById("foot-status").textContent =
      (ov.model||"")+" · "+(ov.bind||"");
  }
  function renderRecent(rows){
    document.getElementById("recent-body").innerHTML = (rows||[]).map(function(r){
      var oc = (r.outcome||r.status||"").toLowerCase();
      var dot = oc==="hit"?'<span class="dot hit"></span>hit':
                oc==="miss"?'<span class="dot miss"></span>miss':oc;
      var ts = r.ts? new Date(r.ts*1000).toLocaleTimeString():"";
      return "<tr><td class=mono>"+ts+"</td><td>"+dot+"</td><td class=mono>"+
        (r.prompt_tokens!=null?r.prompt_tokens:"")+"</td><td class=mono>"+
        (r.prefill_skipped!=null?r.prefill_skipped:"")+"</td><td class=mono>"+
        (r.resume_pos!=null?r.resume_pos:"")+"</td><td class=mono>"+
        (r.ttft_ms!=null?Math.round(r.ttft_ms):"")+"</td><td class=mono>"+
        (r.wall_ms!=null?(r.wall_ms/1000).toFixed(1):"")+"</td><td class=mono>"+
        // speed: tokens the model actually PROCESSED (prefill paid + generated)
        // per second of clock — cached tokens excluded, that's the point.
        ((r.wall_ms&&r.prefill_paid!=null&&r.out_tokens!=null)?
          Math.round((r.prefill_paid+r.out_tokens)/(r.wall_ms/1000)):"")+
        "</td><td>"+(r.client||"")+"</td></tr>";
    }).join("");
  }
  var chartPts = [];
  var chartMode = "cum";   // "cum" (running total) | "buckets" (volume per interval)
  var lastRows = [];
  // Interval adapts to the data span (slow traffic gets day buckets, a live
  // demo gets 15-minute ones), aiming for a readable number of buckets.
  var BUCKET_LADDER = [[900,"15 min"],[3600,"hour"],[21600,"6 h"],[86400,"day"]];
  var bucketSecs = 900, bucketLabel = "15 min";
  function pickBucket(rows){
    var lo=Infinity, hi=-Infinity;
    rows.forEach(function(r){ if(r.ts!=null){ lo=Math.min(lo,r.ts); hi=Math.max(hi,r.ts);} });
    var span = (hi>lo)? hi-lo : 0;
    bucketSecs = BUCKET_LADDER[BUCKET_LADDER.length-1][0];
    bucketLabel = BUCKET_LADDER[BUCKET_LADDER.length-1][1];
    for(var i=0;i<BUCKET_LADDER.length;i++){
      if(span / BUCKET_LADDER[i][0] <= 48){ bucketSecs=BUCKET_LADDER[i][0]; bucketLabel=BUCKET_LADDER[i][1]; break; }
    }
    var btn=document.getElementById("mode-buckets");
    if(btn) btn.textContent = "per "+bucketLabel;
  }
  function toPoints(rows){
    if(chartMode==="cum"){
      var pts=[], recv=0, cache=0;
      rows.slice().reverse().forEach(function(r){
        if(r.prompt_tokens==null) return;
        recv += r.prompt_tokens; cache += (r.prefill_skipped||0);
        pts.push({t:r.ts, recv:recv, cache:cache});
      });
      return pts;
    }
    // token VOLUME per interval (rising and falling)
    var B=bucketSecs, buckets={};
    rows.forEach(function(r){
      if(r.prompt_tokens==null||r.ts==null) return;
      var b=Math.floor(r.ts/B)*B;
      if(!buckets[b]) buckets[b]={t:b, recv:0, cache:0};
      buckets[b].recv += r.prompt_tokens;
      buckets[b].cache += (r.prefill_skipped||0);
    });
    var ks=Object.keys(buckets).map(Number).sort(function(a,b){return a-b});
    if(!ks.length) return [];
    // fill empty intervals with zeros so the time axis is linear, not compressed
    var pts=[];
    for(var t=ks[0]; t<=ks[ks.length-1]; t+=B)
      pts.push(buckets[t] || {t:t, recv:0, cache:0});
    return pts;
  }
  function drawChart(rows){
    lastRows = rows;
    pickBucket(rows);
    var pts = toPoints(rows);
    chartPts = pts;
    var svg = document.getElementById("chart");
    if(pts.length<2){ svg.innerHTML=""; return; }
    // plot area with margins for labelled axes (units on both — tokens / time)
    // y-max over ALL points: cumulative ends at its max, but bucket volumes
    // peak anywhere in the series
    var W=900,H=180, ML=64,MR=8,MT=18,MB=28;   // MT: headroom for the unit label
    // y-max over BOTH series. Using recv alone clipped the cache line off the
    // top of the chart whenever served exceeded received -- which is normal,
    // not an anomaly: one cache hit can serve far more tokens than the prompt
    // that asked for it (an image prompt of 1,785 ids resumed 5,888 model
    // positions). Measured at 2.48x, so the green line simply stopped
    // mid-chart and looked like data loss.
    var max=1;
    pts.forEach(function(p){
      if(p.recv>max) max=p.recv;
      if(p.cache>max) max=p.cache;
    });
    var PW=W-ML-MR, PH=H-MT-MB;
    function x(i){ return ML+PW*i/(pts.length-1); }
    function y(v){ return MT+PH-PH*v/max; }
    function path(key){
      return pts.map(function(p,i){return (i?"L":"M")+x(i).toFixed(1)+" "+y(p[key]).toFixed(1)})
                .join(" ");
    }
    // y gridlines + tick labels (compact token counts), 0/half/max
    var g="";
    [0,0.5,1].forEach(function(f){
      var v=max*f, yy=y(v);
      g+='<line x1="'+ML+'" x2="'+(W-MR)+'" y1="'+yy+'" y2="'+yy+
         '" stroke="var(--line)" stroke-width="1"/>'+
         '<text x="'+(ML-6)+'" y="'+(yy+4)+'" text-anchor="end" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+fmtCompact(Math.round(v))+'</text>';
    });
    // x tick labels: first / middle / last timestamps; add the date once the
    // series crosses a day, otherwise identical clock times mislead
    var spanS = pts[pts.length-1].t - pts[0].t;
    [0, Math.floor((pts.length-1)/2), pts.length-1].forEach(function(i){
      var t=new Date(pts[i].t*1000);
      var lbl = (spanS>86400)
        ? t.toLocaleDateString([], {day:"numeric",month:"short"})+" "+
          t.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})
        : t.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});
      var anch = i===0?"start":(i===pts.length-1?"end":"middle");
      g+='<text x="'+x(i)+'" y="'+(H-10)+'" text-anchor="'+anch+'" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+lbl+'</text>';
    });
    // axis unit label. LEFT-aligned at the plot's left edge, not right-aligned
    // into the tick column: at y=MT it sat 4px from the top tick label and the
    // two overprinted ("345k" + "tokens" rendered as "tokeks").
    g+='<text x="'+ML+'" y="'+(MT+10)+'" text-anchor="start" font-size="10" fill="var(--ink-2)">'+
       (chartMode==="cum"?"tokens":"tokens / "+bucketLabel)+'</text>';
    g+='<text x="'+(W-MR)+'" y="'+(H-10)+'" text-anchor="start" font-size="10" fill="var(--ink-2)"></text>';
    svg.innerHTML = g+
      '<path d="'+path("recv")+'" fill="none" stroke="var(--series-1)" stroke-width="2"/>'+
      '<path d="'+path("cache")+'" fill="none" stroke="var(--series-2)" stroke-width="2"/>'+
      '<line id="cross" x1="0" x2="0" y1="'+MT+'" y2="'+(MT+PH)+'" stroke="var(--ink-2)" stroke-width="1" style="display:none"/>';
    svg.onmousemove = function(ev){
      var rect = svg.getBoundingClientRect();
      var fx = (ev.clientX-rect.left)/rect.width*900;          // logical x
      var i = Math.round((fx-64)/(900-64-8)*(pts.length-1));    // ML=64, MR=8
      i = Math.max(0, Math.min(pts.length-1, i));
      var p = pts[i], c=document.getElementById("cross");
      c.style.display="block"; c.setAttribute("x1",x(i)); c.setAttribute("x2",x(i));
      var tip=document.getElementById("charttip"); tip.style.display="block";
      tip.textContent = new Date(p.t*1000).toLocaleTimeString()+
        " — received "+p.recv.toLocaleString()+" tok · from cache "+
        p.cache.toLocaleString()+" tok ("+Math.round(100*p.cache/Math.max(p.recv,1))+"%)";
    };
    svg.onmouseleave = function(){
      var c=document.getElementById("cross"); if(c) c.style.display="none";
      document.getElementById("charttip").style.display="none";
    };
  }
  function setMode(m){
    chartMode=m;
    document.getElementById("mode-cum").className="chartbtn"+(m==="cum"?" active":"");
    document.getElementById("mode-buckets").className="chartbtn"+(m==="buckets"?" active":"");
    drawChart(lastRows);
  }
  document.getElementById("mode-cum").onclick=function(){setMode("cum")};
  document.getElementById("mode-buckets").onclick=function(){setMode("buckets")};
  function poll(){
    fetch("/api/overview",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(render).catch(function(){});
    fetch("/api/requests?limit=200",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()})
      .then(function(d){renderRecent(d.requests); drawChart(d.requests||[]);})
      .catch(function(){});
  }
  // ---- licence (T-0004) ----------------------------------------------------
  // Paste a key, it is validated and applied live, and the front end saves it
  // where the proxy reads it. The customer never sees a file path.
  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;")
                    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  function licDate(ep){
    if(!ep) return "";
    var d = new Date(ep*1000);
    if(isNaN(d)) return String(ep);
    return d.toISOString().slice(0,10);
  }
  // The banner. Three outcomes, three different things to say -- collapsing
  // them into "invalid key" is exactly the failure this page exists to avoid.
  function licBanner(kind, html){
    var el = document.getElementById("lic-banner");
    if(!el) return;            // panel lives on /console/licence now
    if(!kind){ el.innerHTML = ""; return; }
    var cls = kind === "lapsed" ? "banner-lapsed"
            : kind === "ok"     ? "banner-ok" : "banner-error";
    el.innerHTML = '<div class="banner '+cls+'">'+html+'</div>';
  }
  // Read-only: what the key grants, straight from the decoded signed payload.
  function renderGrant(lic){
    var box = document.getElementById("lic-grant");
    // This page no longer shows the grant; it only says whether a key is
    // missing, and links to the page that takes one.
    var ptr = document.getElementById("lic-pointer");
    if(ptr){
      ptr.innerHTML = (lic && lic.licensed) ? "" :
        'No licence installed \u2014 the cache is off, so every prompt is '+
        'processed from cold. <a href="/console?open=drawer-licence">Install a key '+
        '\u2192</a>';
    }
    if(!box) return;
    if(!lic || !lic.grant){
      box.innerHTML = lic && lic.licensed ? "" :
        '<p class="advisory" style="margin:0">No licence installed. The proxy '+
        'still serves every request, but the cache is off, so each prompt is '+
        'processed from cold.</p>';
      return;
    }
    var g = lic.grant, rows = [];
    function row(k,v,note){
      if(v===undefined||v===null||v==="") return;
      rows.push("<dt>"+esc(k)+"</dt><dd>"+esc(v)+
        (note?' <span class="advisory">'+esc(note)+"</span>":"")+"</dd>");
    }
    row("Licensed to", g.customer);
    row("Product", g.product);
    row("Tier", g.tier);
    row("Issued", licDate(g.issued));
    row("Expires", licDate(g.expiry));
    if(typeof g.days_remaining === "number"){
      row("Days remaining", g.days_remaining < 0 ? "expired"
                                                 : Math.round(g.days_remaining));
    }
    // seats: ADVISORY. Never a ratio, never a progress bar -- verification is
    // offline, so a copied key counts from zero. It records what was bought.
    // seats 0 means UNSTATED (licence.rs), not "zero seats" -- omit the row
    // rather than render a number that reads as a limit of none.
    if(g.seats) row("Seats", g.seats, "as purchased — not enforced by the proxy");
    if(g.features && g.features.length) row("Features", g.features.join(", "));
    box.innerHTML = rows.length ? "<dl>"+rows.join("")+"</dl>" : "";
  }
  function loadLicence(){
    fetch("/api/licence",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()})
      .then(function(lic){
        renderGrant(lic);
        var note = document.getElementById("lic-note");
        if(!note) return;      // moved to /console/licence
        if(lic.licensed && lic.grant && typeof lic.days_remaining === "number"
           && lic.days_remaining < 30){
          note.textContent = "Expires in "+Math.round(lic.days_remaining)+
                             " days — renew at faxl.ai";
        } else { note.textContent = ""; }
      })
      .catch(function(){});
  }
  function saveLicence(){
    var ta = document.getElementById("lic-key");
    var btn = document.getElementById("lic-save");
    var key = ta.value;
    if(!key.trim()){
      licBanner("error","<b>Nothing to save.</b> Paste your licence key first.");
      return;
    }
    btn.disabled = true; btn.textContent = "Checking…";
    licBanner(null);
    fetch("/api/licence",{method:"POST",
        headers:{"Content-Type":"application/json",Accept:"application/json"},
        body:JSON.stringify({key:key})})
      .then(function(r){return r.json().then(function(b){return [r.status,b]})})
      .then(function(pair){
        var body = pair[1];
        if(body && body.ok){
          ta.value = "";
          var warn = body.warning
            ? ' <span class="detail">'+esc(body.warning)+"</span>" : "";
          licBanner("ok","<b>Licence saved.</b> The cache is on."+warn);
          renderGrant(body.licence);
          loadLicence();
          return;
        }
        // The server owns the wording -- it is the same text the agent view and
        // the text mode render, so the three cannot drift. Bold only the first
        // sentence here; do NOT prepend a heading, or it double-prints.
        var b = (body && body.banner) || {};
        var msg = b.message || "The key could not be applied.";
        var cut = msg.indexOf(". ");
        var lead = cut > 0 ? msg.slice(0, cut+1) : msg;
        var rest = cut > 0 ? msg.slice(cut+1) : "";
        var html = "<b>"+esc(lead)+"</b>"+esc(rest);
        if(b.type === "expired"){
          // NOT an error. A renewal -- and the server text already names
          // faxl.ai in words, so there is nothing to add.
          //
          // DELIBERATELY NOT A LINK. This page is one self-contained asset
          // under default-src 'none'; connect-src 'self', so it works on a
          // machine with no internet -- the point of a local admin surface.
          // An <a href> to an absolute URL would be blocked by that CSP
          // anyway: it would look clickable and do nothing. Plain text the
          // customer can read and type is honest and actually works, and it
          // matches how the countdown above says the same thing.
          licBanner("lapsed", html);
        } else {
          if(b.detail) html += '<span class="detail">'+esc(b.detail)+"</span>";
          licBanner("error", html);
        }
        loadLicence();
      })
      .catch(function(){
        licBanner("error","<b>Could not reach the proxy.</b> "+
          "The key was not saved. Check the proxy is still running.");
      })
      .then(function(){
        btn.disabled = false; btn.textContent = "Save licence";
      });
  }
  // The paste box moved to /console/licence, so these elements are no longer
  // on this page. Guarded rather than deleted: loadLicence() still runs, to
  // turn the pointer line below into a link when there is no key installed.
  var licSaveBtn = document.getElementById("lic-save");
  if(licSaveBtn){
    licSaveBtn.addEventListener("click", saveLicence);
    document.getElementById("lic-key").addEventListener("keydown", function(e){
      if((e.metaKey||e.ctrlKey) && e.key === "Enter") saveLicence();
    });
  }
  loadLicence();
  poll();
  if(!REDUCED) setInterval(poll, 2000);
</script>
</body>
</html>
"""


# ---- the same asset, in the pieces the site shell needs ----------------------
#
# HUMAN_HTML above is a whole document, and it stays that way: it is the
# fallback, it is what the CSP test drives, and a self-contained page is what
# the spec asks for. But the console is becoming a SITE -- every page inside
# faxl.ai's own header, nav and footer -- and the shell supplies the document,
# so it needs this page's parts rather than its chrome.
#
# Split here, derived from the one string, rather than kept as a second copy.
# Two copies of 25 KB of markup drift, and the drift shows up as one page
# quietly lagging the other.

def _between(text, start, end):
    i = text.index(start) + len(start)
    return text[i:text.index(end, i)]


# The page's own CSS. Goes in as head_extra, which is how the public site does
# a page-local component (see shop.html, account.html).
#
# ONE TOKEN COLLIDES with the site stylesheet: --accent. The site's is gold
# (#7c672f); this page's is green (#2b7a5b) and is used for the hit dots and the
# licence-ok state. This block is emitted AFTER the brand CSS, so it would win
# and quietly re-tint the whole site's accent -- links, the nav underline, the
# .n figures -- to green. Renamed to --hit so both survive: the page keeps its
# green for cache hits, the site keeps its gold for everything else.
# Inside the site shell this page must stop being its own website.
#
# It was written as a standalone asset, so it declares its own ground, its own
# type and its own palette -- and being emitted after the brand CSS, it won
# every one of those contests: mono headline, boxed cards and a white ground
# sitting under faxl.ai's header. The panels and the script are good and stay
# untouched; only the rules that fight the shell are rewritten.
#
# The page's tokens are MAPPED onto the site's rather than deleted, so the ~500
# lines of chart and table JS that read them keep working unchanged.
_SHELL_FIXES = [
    # The site owns the ground and the page margins; .wrap is already the
    # site's container, so the standalone body padding double-indents inside it.
    ("body{background:var(--paper);color:var(--ink);font-family:var(--font-sans);\n"
     "       margin:0;padding:64px 16px 40px;}",
     "/* the shell owns body; see _SHELL_FIXES */"),
    (".wrap{max-width:960px;margin:0 auto}", ""),
    # The headline is the site's voice, not a terminal readout.
    ("font-family:var(--font-mono);font-size:clamp(28px,5vw,56px)",
     "font-size:clamp(28px,5vw,56px)"),
    # Boxed, but in the page's own palette. The unboxed version read as a row
    # of floating numbers, and the boxed one it replaced used hardcoded white
    # on white -- a card that only looked like a card on the marketing page's
    # background. These are brand tokens, so the tiles sit ON the page in both
    # themes instead of hovering above it.
    (".tile{background:var(--paper-2);border:1px solid var(--line);border-radius:var(--radius);\n"
     "        padding:16px}",
     ".tile{background:var(--card);box-shadow:0 0 0 1px var(--rule);\n"
     "        border:0;border-radius:0;padding:1.1rem 1.2rem}"),
    # ONE ROW. auto-fit sized the columns from the viewport, so four tiles fit
    # and a fifth dropped to a row of its own -- the figures stopped reading as
    # a set and started looking scattered. Four explicit columns, hairline-
    # ruled like the welcome cards, collapsing to two then one on narrow
    # screens. This has to live in the PAGE's style, not the shell's: the
    # page's <style> is emitted after the brand CSS and wins, so a shell rule
    # here is silently overridden.
    ("repeat(auto-fit,minmax(160px,1fr));\n         gap:16px;margin:40px 0}",
     "repeat(4,1fr);\n         gap:1px;margin:2.4rem 0;align-items:stretch;\n"
     "         background:var(--card);border:1px solid var(--rule)}\n"
     "  @media (max-width:60rem){.tiles{grid-template-columns:repeat(2,1fr)}}\n"
     "  @media (max-width:30rem){.tiles{grid-template-columns:1fr}}"),
    # The headline should not run wider than the text under it.
    (".headline{font-size:clamp(28px,5vw,56px)",
     ".headline{max-width:22ch;font-size:clamp(28px,4.2vw,48px)"),
]

_TOKEN_MAP = [
    # page token -> site token. --paper/--ink are the ground and text; --line is
    # the site's hairline; --accent-2 is the estimated-mark, which must stay
    # visibly different from body text.
    ("var(--paper-2)", "var(--card)"),
    ("var(--paper)", "var(--bg)"),
    ("var(--ink-2)", "var(--muted)"),
    ("var(--ink)", "var(--text)"),
    ("var(--line)", "var(--rule)"),
    ("var(--font-sans)", "var(--serif)"),
    ("var(--font-mono)", "var(--mono)"),
    # ONE NAME COLLIDES: the site's --accent is gold, this page's is the green
    # of a cache hit. Renamed rather than dropped, so the hit dots stay green
    # and the site keeps its gold for links and the nav underline.
    ("var(--accent-2)", "var(--accent-strong)"),
    ("var(--accent)", "var(--hit)"),
]


def _shell_style():
    css = _between(HUMAN_HTML, "<style>", "</style>")
    for old, new in _SHELL_FIXES:
        css = css.replace(old, new)
    css = css.replace("--accent:", "--hit:")
    for old, new in _TOKEN_MAP:
        css = css.replace(old, new)
    return css


HUMAN_STYLE = _shell_style()

# Everything between <body> and </body>: the .wrap, the panels, and the script.
def _shell_body():
    """The panels and the script, without the chrome the shell now supplies.

    The standalone asset carried its own wordmark and its own site map. Inside
    the shell both are duplicated -- the screenshot showed "gamakon · faxl" and
    a text breadcrumb sitting directly under faxl.ai's real header and nav.
    """
    body = _between(HUMAN_HTML, "<body>", "</body>")
    body = body.replace(
        '<p class="mono" style="color:var(--ink-2);font-size:13px">gamakon · faxl</p>',
        "")
    # The nav placeholder and its long explanatory comment go with it; the shell
    # renders the site map from the same _NAV_ITEMS.
    i = body.find("<!-- The site map, for a HUMAN.")
    if i >= 0:
        j = body.find("</p>", body.index('<p class="nav" id="nav">', i))
        body = body[:i] + body[j + len("</p>"):]
    return body


HUMAN_BODY = _shell_body()

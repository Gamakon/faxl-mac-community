# Vendored engine module (faxl_console_human.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Human-mode console — a single self-contained HTML asset (spec §5).

One embedded page: inline CSS + JS, no external assets (CSP: default-src 'none';
style-src/script-src 'unsafe-inline'; connect-src 'self'). It polls /api/* every
2 s and renders the same data model the Agent view renders — the frontend never
hardcodes which metric is the headline (backend orders savings[]), and an
`estimated` value is always visibly marked (structural honesty).

Brand tokens (§4) are PLACEHOLDERS (gamakon.ai values are an open AM item) — the
structure is here; the exact colors are TBD and must not be fabricated.
"""

# NOTE: brand values are TBD placeholders (neutral), not invented gamakon colors.
HUMAN_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>faxl — console</title>
<style>
  /* ---- brand tokens (§4) — TBD PLACEHOLDERS, not fabricated gamakon values ---- */
  :root{
    --ink:#1a1a1a; --ink-2:#666; --paper:#fafaf8; --paper-2:#fff;
    --line:#e3e3df; --accent:#2b7a5b; --accent-2:#b06a2c; --danger:#b02c2c;
    --series-1:#2a78d6; --series-2:#1baf7a; /* chart: received / from cache (validated) */
    --font-sans:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    --font-mono:"SF Mono",Menlo,Consolas,monospace;
    --radius:4px;
  }
  :root:not([data-theme="light"]){}
  @media (prefers-color-scheme:dark){
    :root:not([data-theme="light"]){
      --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
      --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
    --series-1:#3987e5; --series-2:#199e70;
    }
  }
  :root[data-theme="dark"]{
    --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
    --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
    --series-1:#3987e5; --series-2:#199e70;
  }
  *{box-sizing:border-box}
  body{background:var(--paper);color:var(--ink);font-family:var(--font-sans);
       margin:0;padding:64px 16px 40px;}
  .wrap{max-width:960px;margin:0 auto}
  .mono{font-family:var(--font-mono);font-variant-numeric:tabular-nums}
  .headline{font-family:var(--font-mono);font-size:clamp(28px,5vw,56px);line-height:1.05;
            font-variant-numeric:tabular-nums;margin:0}
  .sub{color:var(--ink-2);margin:8px 0 0;font-size:15px}
  .est{color:var(--accent-2);font-size:.7em;font-weight:600;text-transform:uppercase;
       letter-spacing:.04em;margin-left:.4em}
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
         gap:16px;margin:40px 0}
  .tile{background:var(--paper-2);border:1px solid var(--line);border-radius:var(--radius);
        padding:16px}
  .tile .label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;
               color:var(--ink-2)}
  .tile .val{font-family:var(--font-mono);font-size:clamp(16px,2.2vw,28px);
             margin-top:6px;font-variant-numeric:tabular-nums;
             overflow-wrap:anywhere}
  .badge{display:inline-block;margin-top:24px;padding:6px 12px;border-radius:var(--radius);
         border:1px solid var(--line);font-size:14px}
  .badge.pass{color:var(--accent);border-color:var(--accent)}
  .badge.fail{color:var(--danger);border-color:var(--danger)}
  .badge.never{color:var(--ink-2)}
  a{color:var(--accent);text-decoration:none}
  a:after{content:" →"}
  a.plain:after{content:""}
  .foot{margin-top:40px;color:var(--ink-2);font-size:13px;border-top:1px solid var(--line);
        padding-top:16px}
  table{width:100%;border-collapse:collapse;margin-top:24px;font-size:14px}
  td,th{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}
  th{color:var(--ink-2);font-weight:600;font-size:12px;text-transform:uppercase}
  .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
  .chartbtn{font:12px var(--font-sans);padding:4px 10px;border:1px solid var(--line);
            background:var(--paper-2);color:var(--ink-2);border-radius:var(--radius);
            cursor:pointer}
  .chartbtn.active{color:var(--ink);border-color:var(--accent)}
  .hit{background:var(--accent)} .miss{background:var(--accent-2)}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <p class="mono" style="color:var(--ink-2);font-size:13px">gamakon · faxl</p>
  <h1 class="headline" id="headline">…</h1>
  <p class="sub" id="sub"></p>
  <div class="tiles" id="tiles"></div>
  <div id="lossless"></div>
  <div id="chartbox" style="margin-top:32px">
    <div style="font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-2)">
      tokens, running total</div>
    <div style="font-size:13px;color:var(--ink-2);margin:6px 0 4px">
      <span style="color:var(--series-1)">●</span> received from users&nbsp;&nbsp;
      <span style="color:var(--series-2)">●</span> served from cache</div>
    <svg id="chart" width="100%" height="180" viewBox="0 0 900 180"
         style="display:block"></svg>
    <div id="charttip" class="mono" style="display:none;font-size:12px;color:var(--ink-2);margin-top:2px"></div>
    <p id="chartcaption" style="font-style:italic;font-size:13px;color:var(--ink-2);margin:8px 0 0">
      loading…</p>
    <div style="margin-top:8px">
      <button id="mode-cum" class="chartbtn active">running total</button>
      <button id="mode-buckets" class="chartbtn">per interval</button>
    </div>
  </div>
  <div style="max-height:420px;overflow-y:auto;margin-top:24px;border:1px solid var(--line);border-radius:var(--radius)">
  <table id="recent" style="margin-top:0"><thead style="position:sticky;top:0;background:var(--paper)"><tr>
    <th>time</th><th>hit/miss</th><th>prompt<br>(tokens)</th><th>from cache<br>(tokens)</th>
    <th>resumed at<br>(token)</th><th>first reply<br>(ms)</th><th>took<br>(s)</th><th>speed<br>(tok/s)</th><th>client</th>
  </tr></thead><tbody id="recent-body"></tbody></table>
  </div>
  <div style="margin-top:28px">
    <div style="font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-2)">
      cache contents — each dot is one stored blob</div>
    <div style="font-size:13px;color:var(--ink-2);margin:6px 0 4px">
      last used (x) vs times reused (y); the oldest least-reused dots —
      bottom left — are evicted first when the store fills</div>
    <svg id="scatter" width="100%" height="200" viewBox="0 0 900 200"
         style="display:block" role="img"
         aria-label="Scatter: one dot per cached blob, last-used time on x, times reused on y"></svg>
    <div id="scattertip" class="mono" style="display:none;font-size:12px;color:var(--ink-2);margin-top:2px"></div>
  </div>
  <p class="foot" id="foot">
    <span id="foot-status">loading…</span> ·
    <a href="/console?mode=agent" class="plain">agent view →</a>
  </p>
</div>
<script>
  // No external calls (CSP connect-src 'self'); poll our own /api.
  var REDUCED = matchMedia("(prefers-reduced-motion:reduce)").matches;
  function fmtCompact(n){
    // metric exponents for big counts: 12,300 -> 12.3k, 3,636,158 -> 3.64M,
    // trillions -> T. 3 significant digits; exact value goes in the title.
    if(n==null) return "—";
    var a=Math.abs(n);
    if(a<10000) return Number.isInteger(n)?n.toLocaleString():n.toFixed(2);
    var u=[["T",1e12],["B",1e9],["M",1e6],["k",1e3]];
    for(var i=0;i<u.length;i++){
      if(a>=u[i][1]) return (n/u[i][1]).toPrecision(3).replace(/\.0+$/,"")+u[i][0];
    }
    return String(n);
  }
  function fmtMs(x){ // large millisecond values read better as seconds
    if(x==null) return "—";
    return x>=1000 ? (x/1000).toFixed(2)+" s" : Math.round(x)+" ms";
  }
  function fmtNum(v){
    if(Array.isArray(v)) return v.map(function(x){return x==null?"—":fmtNum(x)}).join(" / ");
    if(typeof v==="number"){ return Number.isInteger(v)?String(v):v.toFixed(2); }
    return String(v);
  }
  function estMark(e){
    if(e.basis!=="estimated") return "";
    var cov = e.coverage ? " · measured "+Math.round(e.coverage.measured_fraction*100)+"%" : "";
    return '<span class="est">estimated'+cov+'</span>';
  }
  function render(ov){
    var s = ov.savings||[];
    var head = s[0];
    var headTxt = "waiting for first request";
    if(head){
      if(head.total_received){
        var pct = Math.round(100*head.value/Math.max(head.total_received,1));
        headTxt = fmtCompact(head.value)+" of "+fmtCompact(head.total_received)+
                  " prompt tokens served from cache — "+pct+"%";
      } else {
        headTxt = fmtNum(head.value)+" "+head.unit+" "+(head.label||"");
      }
    }
    document.getElementById("headline").innerHTML = headTxt;
    var subEntries = s.slice(1,3).map(function(e){
      return fmtNum(e.value)+" "+e.unit+" "+(e.label||"")+estMark(e);
    });
    document.getElementById("sub").innerHTML = subEntries.join(" · ");
    // tiles
    document.getElementById("tiles").innerHTML = (ov.tiles||[]).map(function(t){
      var val, exact;
      if(t.unit==="ms"){
        val = Array.isArray(t.value)? t.value.map(fmtMs).join(" / ") : fmtMs(t.value);
        exact = fmtNum(t.value)+" ms";
      } else {
        val = Array.isArray(t.value)? t.value.map(fmtCompact).join(" / ")
                                    : fmtCompact(t.value);
        exact = fmtNum(t.value)+(t.unit?" "+t.unit:"");
        if(t.unit&&t.unit!=="ratio"&&t.unit!=="count"&&t.unit!=="days") val += " "+t.unit;
      }
      var style = (t.key==="licence" && t.value < 30) ?
        ' style="color:var(--accent-2)"' : "";
      return '<div class="tile"><div class="label">'+(t.label||t.key)+'</div>'+
             '<div class="val"'+style+' title="'+exact+'">'+val+
             (t.key==="licence" ? " days left" : "") +
             '</div>'+estMark(t)+'</div>';
    }).join("");
    // lossless badge
    var L = ov.lossless||{}; var cls="never", txt="never verified";
    if(L.status==="pass"){cls="pass";txt="✓ lossless";}
    else if(L.status==="fail"){cls="fail";txt="✕ verify failed";}
    document.getElementById("lossless").innerHTML =
      '<span class="badge '+cls+'">'+txt+' · <a href="/console/verify" class="plain">verify →</a></span>';
    // chart caption: provenance for screenshots — what this figure IS
    var cap = document.getElementById("chartcaption");
    if(cap) cap.textContent =
      "faxl prefill-cache console — model "+(ov.model||"?")+" at "+(ov.bind||"?")+
      ". Prompt tokens received from users vs served from the cache ("+
      (chartMode==="cum"?"running total":"volume per "+bucketLabel)+
      "); all token counts measured, not estimated.";
    // footer
    document.getElementById("foot-status").textContent =
      (ov.model||"")+" · "+(ov.bind||"");
  }
  function renderRecent(rows){
    document.getElementById("recent-body").innerHTML = (rows||[]).map(function(r){
      var oc = (r.outcome||r.status||"").toLowerCase();
      var dot = oc==="hit"?'<span class="dot hit"></span>hit':
                oc==="miss"?'<span class="dot miss"></span>miss':oc;
      var ts = r.ts? new Date(r.ts*1000).toLocaleTimeString():"";
      return "<tr><td class=mono>"+ts+"</td><td>"+dot+"</td><td class=mono>"+
        (r.prompt_tokens!=null?r.prompt_tokens:"")+"</td><td class=mono>"+
        (r.prefill_skipped!=null?r.prefill_skipped:"")+"</td><td class=mono>"+
        (r.resume_pos!=null?r.resume_pos:"")+"</td><td class=mono>"+
        (r.ttft_ms!=null?Math.round(r.ttft_ms):"")+"</td><td class=mono>"+
        (r.wall_ms!=null?(r.wall_ms/1000).toFixed(1):"")+"</td><td class=mono>"+
        // speed: tokens the model actually PROCESSED (prefill paid + generated)
        // per second of clock — cached tokens excluded, that's the point.
        ((r.wall_ms&&r.prefill_paid!=null&&r.out_tokens!=null)?
          Math.round((r.prefill_paid+r.out_tokens)/(r.wall_ms/1000)):"")+
        "</td><td>"+(r.client||"")+"</td></tr>";
    }).join("");
  }
  var chartPts = [];
  var chartMode = "cum";   // "cum" (running total) | "buckets" (volume per interval)
  var lastRows = [];
  // Interval adapts to the data span (slow traffic gets day buckets, a live
  // demo gets 15-minute ones), aiming for a readable number of buckets.
  var BUCKET_LADDER = [[900,"15 min"],[3600,"hour"],[21600,"6 h"],[86400,"day"]];
  var bucketSecs = 900, bucketLabel = "15 min";
  function pickBucket(rows){
    var lo=Infinity, hi=-Infinity;
    rows.forEach(function(r){ if(r.ts!=null){ lo=Math.min(lo,r.ts); hi=Math.max(hi,r.ts);} });
    var span = (hi>lo)? hi-lo : 0;
    bucketSecs = BUCKET_LADDER[BUCKET_LADDER.length-1][0];
    bucketLabel = BUCKET_LADDER[BUCKET_LADDER.length-1][1];
    for(var i=0;i<BUCKET_LADDER.length;i++){
      if(span / BUCKET_LADDER[i][0] <= 48){ bucketSecs=BUCKET_LADDER[i][0]; bucketLabel=BUCKET_LADDER[i][1]; break; }
    }
    var btn=document.getElementById("mode-buckets");
    if(btn) btn.textContent = "per "+bucketLabel;
  }
  function toPoints(rows){
    if(chartMode==="cum"){
      var pts=[], recv=0, cache=0;
      rows.slice().reverse().forEach(function(r){
        if(r.prompt_tokens==null) return;
        recv += r.prompt_tokens; cache += (r.prefill_skipped||0);
        pts.push({t:r.ts, recv:recv, cache:cache});
      });
      return pts;
    }
    // token VOLUME per interval (rising and falling)
    var B=bucketSecs, buckets={};
    rows.forEach(function(r){
      if(r.prompt_tokens==null||r.ts==null) return;
      var b=Math.floor(r.ts/B)*B;
      if(!buckets[b]) buckets[b]={t:b, recv:0, cache:0};
      buckets[b].recv += r.prompt_tokens;
      buckets[b].cache += (r.prefill_skipped||0);
    });
    var ks=Object.keys(buckets).map(Number).sort(function(a,b){return a-b});
    if(!ks.length) return [];
    // fill empty intervals with zeros so the time axis is linear, not compressed
    var pts=[];
    for(var t=ks[0]; t<=ks[ks.length-1]; t+=B)
      pts.push(buckets[t] || {t:t, recv:0, cache:0});
    return pts;
  }
  function drawChart(rows){
    lastRows = rows;
    pickBucket(rows);
    var pts = toPoints(rows);
    chartPts = pts;
    var svg = document.getElementById("chart");
    if(pts.length<2){ svg.innerHTML=""; return; }
    // plot area with margins for labelled axes (units on both — tokens / time)
    // y-max over ALL points: cumulative ends at its max, but bucket volumes
    // peak anywhere in the series
    var W=900,H=180, ML=64,MR=8,MT=8,MB=28;
    var max=1; pts.forEach(function(p){ if(p.recv>max) max=p.recv; });
    var PW=W-ML-MR, PH=H-MT-MB;
    function x(i){ return ML+PW*i/(pts.length-1); }
    function y(v){ return MT+PH-PH*v/max; }
    function path(key){
      return pts.map(function(p,i){return (i?"L":"M")+x(i).toFixed(1)+" "+y(p[key]).toFixed(1)})
                .join(" ");
    }
    // y gridlines + tick labels (compact token counts), 0/half/max
    var g="";
    [0,0.5,1].forEach(function(f){
      var v=max*f, yy=y(v);
      g+='<line x1="'+ML+'" x2="'+(W-MR)+'" y1="'+yy+'" y2="'+yy+
         '" stroke="var(--line)" stroke-width="1"/>'+
         '<text x="'+(ML-6)+'" y="'+(yy+4)+'" text-anchor="end" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+fmtCompact(Math.round(v))+'</text>';
    });
    // x tick labels: first / middle / last timestamps; add the date once the
    // series crosses a day, otherwise identical clock times mislead
    var spanS = pts[pts.length-1].t - pts[0].t;
    [0, Math.floor((pts.length-1)/2), pts.length-1].forEach(function(i){
      var t=new Date(pts[i].t*1000);
      var lbl = (spanS>86400)
        ? t.toLocaleDateString([], {day:"numeric",month:"short"})+" "+
          t.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})
        : t.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});
      var anch = i===0?"start":(i===pts.length-1?"end":"middle");
      g+='<text x="'+x(i)+'" y="'+(H-10)+'" text-anchor="'+anch+'" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+lbl+'</text>';
    });
    // axis unit labels
    g+='<text x="'+(ML-6)+'" y="'+(MT-0)+'" text-anchor="end" font-size="10" fill="var(--ink-2)">'+
       (chartMode==="cum"?"tokens":"tokens / "+bucketLabel)+'</text>';
    g+='<text x="'+(W-MR)+'" y="'+(H-10)+'" text-anchor="start" font-size="10" fill="var(--ink-2)"></text>';
    svg.innerHTML = g+
      '<path d="'+path("recv")+'" fill="none" stroke="var(--series-1)" stroke-width="2"/>'+
      '<path d="'+path("cache")+'" fill="none" stroke="var(--series-2)" stroke-width="2"/>'+
      '<line id="cross" x1="0" x2="0" y1="'+MT+'" y2="'+(MT+PH)+'" stroke="var(--ink-2)" stroke-width="1" style="display:none"/>';
    svg.onmousemove = function(ev){
      var rect = svg.getBoundingClientRect();
      var fx = (ev.clientX-rect.left)/rect.width*900;          // logical x
      var i = Math.round((fx-64)/(900-64-8)*(pts.length-1));    // ML=64, MR=8
      i = Math.max(0, Math.min(pts.length-1, i));
      var p = pts[i], c=document.getElementById("cross");
      c.style.display="block"; c.setAttribute("x1",x(i)); c.setAttribute("x2",x(i));
      var tip=document.getElementById("charttip"); tip.style.display="block";
      tip.textContent = new Date(p.t*1000).toLocaleTimeString()+
        " — received "+p.recv.toLocaleString()+" tok · from cache "+
        p.cache.toLocaleString()+" tok ("+Math.round(100*p.cache/Math.max(p.recv,1))+"%)";
    };
    svg.onmouseleave = function(){
      var c=document.getElementById("cross"); if(c) c.style.display="none";
      document.getElementById("charttip").style.display="none";
    };
  }
  function setMode(m){
    chartMode=m;
    document.getElementById("mode-cum").className="chartbtn"+(m==="cum"?" active":"");
    document.getElementById("mode-buckets").className="chartbtn"+(m==="buckets"?" active":"");
    drawChart(lastRows);
  }
  document.getElementById("mode-cum").onclick=function(){setMode("cum")};
  document.getElementById("mode-buckets").onclick=function(){setMode("buckets")};
  function drawScatter(blobs){
    var svg = document.getElementById("scatter");
    if(!svg) return;
    if(!blobs || blobs.length<1){ svg.innerHTML=""; return; }
    var W=900,H=200, ML=64,MR=12,MT=10,MB=28, now=Date.now()/1000;
    var PW=W-ML-MR, PH=H-MT-MB;
    var lo=Infinity, hi=-Infinity, ymax=1;
    blobs.forEach(function(b){
      lo=Math.min(lo,b.last_used); hi=Math.max(hi,b.last_used);
      ymax=Math.max(ymax,b.hits);
    });
    if(hi<=lo){ lo=hi-1; }
    var x=function(t){ return ML+PW*(t-lo)/(hi-lo); };
    var y=function(h){ return MT+PH-PH*h/ymax; };
    var g="";
    // y gridlines: 0 / half / max reuse counts (integers)
    [0,0.5,1].forEach(function(f){
      var v=Math.round(ymax*f), yy=y(v);
      g+='<line x1="'+ML+'" x2="'+(W-MR)+'" y1="'+yy+'" y2="'+yy+
         '" stroke="var(--line)" stroke-width="1"/>'+
         '<text x="'+(ML-6)+'" y="'+(yy+4)+'" text-anchor="end" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+v+'</text>';
    });
    // x ticks: oldest / middle / newest last-used times (dates past a day)
    [lo,(lo+hi)/2,hi].forEach(function(t,i){
      var d=new Date(t*1000);
      var lbl=(now-lo>86400)
        ? d.toLocaleDateString([], {day:"numeric",month:"short"})+" "+
          d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})
        : d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
      var anch=i===0?"start":(i===2?"end":"middle");
      g+='<text x="'+x(t)+'" y="'+(H-10)+'" text-anchor="'+anch+'" font-size="11"'+
         ' fill="var(--ink-2)" font-family="var(--font-mono)">'+lbl+'</text>';
    });
    g+='<text x="'+(ML+8)+'" y="'+(MT+12)+'" text-anchor="start" font-size="10"'+
       ' fill="var(--ink-2)">times reused</text>';
    blobs.forEach(function(b,i){
      g+='<circle data-i="'+i+'" cx="'+x(b.last_used).toFixed(1)+
         '" cy="'+y(b.hits).toFixed(1)+'" r="4" fill="var(--series-1)"'+
         ' fill-opacity="0.65" stroke="var(--paper)" stroke-width="1"/>';
    });
    svg.innerHTML=g;
    svg.onmousemove=function(ev){
      var t=ev.target, tip=document.getElementById("scattertip");
      if(t.tagName!=="circle"){ tip.style.display="none"; return; }
      var b=blobs[+t.getAttribute("data-i")];
      tip.style.display="block";
      tip.textContent="checkpoint at "+(b.pos!=null?b.pos.toLocaleString()+" tokens":"?")+
        " — reused "+b.hits+"×, last used "+new Date(b.last_used*1000).toLocaleString()+
        (b.bytes!=null?", "+(b.bytes/1e6).toFixed(0)+" MB":"");
    };
    svg.onmouseleave=function(){
      document.getElementById("scattertip").style.display="none";
    };
  }
  function poll(){
    fetch("/api/overview",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(render).catch(function(){});
    fetch("/api/requests?limit=200",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()})
      .then(function(d){renderRecent(d.requests); drawChart(d.requests||[]);})
      .catch(function(){});
    fetch("/api/blobs",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()})
      .then(function(d){drawScatter(d.blobs||[]);})
      .catch(function(){});
  }
  poll();
  if(!REDUCED) setInterval(poll, 2000);
</script>
</body>
</html>
"""

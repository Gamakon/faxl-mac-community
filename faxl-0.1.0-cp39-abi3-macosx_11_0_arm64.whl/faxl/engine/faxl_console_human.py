#!/usr/bin/env python3
"""Human-mode console — a single self-contained HTML asset (spec §5).

One embedded page: inline CSS + JS, no external assets (CSP: default-src 'none';
style-src/script-src 'unsafe-inline'; connect-src 'self'). It polls /api/* every
2 s and renders the same data model the Agent view renders — the frontend never
hardcodes which metric is the headline (backend orders savings[]), and an
`estimated` value is always visibly marked (structural honesty).

Brand tokens (§4) are PLACEHOLDERS (gamakon.ai values are an open AM item) — the
structure is here; the exact colors are TBD and must not be fabricated.
"""

# NOTE: brand values are TBD placeholders (neutral), not invented gamakon colors.
HUMAN_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>faxl — console</title>
<style>
  /* ---- brand tokens (§4) — TBD PLACEHOLDERS, not fabricated gamakon values ---- */
  :root{
    --ink:#1a1a1a; --ink-2:#666; --paper:#fafaf8; --paper-2:#fff;
    --line:#e3e3df; --accent:#2b7a5b; --accent-2:#b06a2c; --danger:#b02c2c;
    --font-sans:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    --font-mono:"SF Mono",Menlo,Consolas,monospace;
    --radius:4px;
  }
  :root:not([data-theme="light"]){}
  @media (prefers-color-scheme:dark){
    :root:not([data-theme="light"]){
      --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
      --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
    }
  }
  :root[data-theme="dark"]{
    --ink:#f0f0ec; --ink-2:#9a9a94; --paper:#161714; --paper-2:#1e201c;
    --line:#2c2e29; --accent:#54b98c; --accent-2:#d69a5c; --danger:#e06a6a;
  }
  *{box-sizing:border-box}
  body{background:var(--paper);color:var(--ink);font-family:var(--font-sans);
       margin:0;padding:64px 16px 40px;}
  .wrap{max-width:960px;margin:0 auto}
  .mono{font-family:var(--font-mono);font-variant-numeric:tabular-nums}
  .headline{font-family:var(--font-mono);font-size:56px;line-height:1.05;
            font-variant-numeric:tabular-nums;margin:0}
  .sub{color:var(--ink-2);margin:8px 0 0;font-size:15px}
  .est{color:var(--accent-2);font-size:.7em;font-weight:600;text-transform:uppercase;
       letter-spacing:.04em;margin-left:.4em}
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
         gap:16px;margin:40px 0}
  .tile{background:var(--paper-2);border:1px solid var(--line);border-radius:var(--radius);
        padding:16px}
  .tile .label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;
               color:var(--ink-2)}
  .tile .val{font-family:var(--font-mono);font-size:28px;margin-top:6px;
             font-variant-numeric:tabular-nums}
  .badge{display:inline-block;margin-top:24px;padding:6px 12px;border-radius:var(--radius);
         border:1px solid var(--line);font-size:14px}
  .badge.pass{color:var(--accent);border-color:var(--accent)}
  .badge.fail{color:var(--danger);border-color:var(--danger)}
  .badge.never{color:var(--ink-2)}
  a{color:var(--accent);text-decoration:none}
  a:after{content:" →"}
  a.plain:after{content:""}
  .foot{margin-top:40px;color:var(--ink-2);font-size:13px;border-top:1px solid var(--line);
        padding-top:16px}
  table{width:100%;border-collapse:collapse;margin-top:24px;font-size:14px}
  td,th{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}
  th{color:var(--ink-2);font-weight:600;font-size:12px;text-transform:uppercase}
  .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
  .hit{background:var(--accent)} .miss{background:var(--accent-2)}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <p class="mono" style="color:var(--ink-2);font-size:13px">gamakon · faxl</p>
  <h1 class="headline" id="headline">…</h1>
  <p class="sub" id="sub"></p>
  <div class="tiles" id="tiles"></div>
  <div id="lossless"></div>
  <table id="recent"><thead><tr>
    <th>time</th><th>hit/miss</th><th>rung</th><th>reused</th><th>ttft</th><th>client</th>
  </tr></thead><tbody id="recent-body"></tbody></table>
  <p class="foot" id="foot">
    <span id="foot-status">loading…</span> ·
    <a href="/console?mode=agent" class="plain">agent view →</a>
  </p>
</div>
<script>
  // No external calls (CSP connect-src 'self'); poll our own /api.
  var REDUCED = matchMedia("(prefers-reduced-motion:reduce)").matches;
  function fmtNum(v){
    if(Array.isArray(v)) return v.map(function(x){return x==null?"—":fmtNum(x)}).join(" / ");
    if(typeof v==="number"){ return Number.isInteger(v)?String(v):v.toFixed(2); }
    return String(v);
  }
  function estMark(e){
    if(e.basis!=="estimated") return "";
    var cov = e.coverage ? " · measured "+Math.round(e.coverage.measured_fraction*100)+"%" : "";
    return '<span class="est">estimated'+cov+'</span>';
  }
  function render(ov){
    var s = ov.savings||[];
    var head = s[0];
    document.getElementById("headline").innerHTML =
      head ? (fmtNum(head.value)+" "+head.unit+" "+ (head.label||"")) : "waiting for first request";
    var subEntries = s.slice(1,3).map(function(e){
      return fmtNum(e.value)+" "+e.unit+" "+(e.label||"")+estMark(e);
    });
    document.getElementById("sub").innerHTML = subEntries.join(" · ");
    // tiles
    document.getElementById("tiles").innerHTML = (ov.tiles||[]).map(function(t){
      return '<div class="tile"><div class="label">'+(t.label||t.key)+'</div>'+
             '<div class="val">'+fmtNum(t.value)+
             (t.unit&&t.unit!=="ratio"&&t.unit!=="count"?" "+t.unit:"")+
             '</div>'+estMark(t)+'</div>';
    }).join("");
    // lossless badge
    var L = ov.lossless||{}; var cls="never", txt="never verified";
    if(L.status==="pass"){cls="pass";txt="✓ lossless";}
    else if(L.status==="fail"){cls="fail";txt="✕ verify failed";}
    document.getElementById("lossless").innerHTML =
      '<span class="badge '+cls+'">'+txt+' · <a href="/console/verify" class="plain">verify →</a></span>';
    // footer
    document.getElementById("foot-status").textContent =
      (ov.model||"")+" · "+(ov.bind||"");
  }
  function renderRecent(rows){
    document.getElementById("recent-body").innerHTML = (rows||[]).slice(0,10).map(function(r){
      var oc = (r.outcome||r.status||"").toLowerCase();
      var dot = oc==="hit"?'<span class="dot hit"></span>hit':
                oc==="miss"?'<span class="dot miss"></span>miss':oc;
      var ts = r.ts? new Date(r.ts*1000).toLocaleTimeString():"";
      return "<tr><td class=mono>"+ts+"</td><td>"+dot+"</td><td class=mono>"+
        (r.resume_pos!=null?r.resume_pos:"")+"</td><td class=mono>"+
        (r.prefill_skipped!=null?r.prefill_skipped:"")+"</td><td class=mono>"+
        (r.ttft_ms!=null?Math.round(r.ttft_ms):"")+"</td><td>"+(r.client||"")+"</td></tr>";
    }).join("");
  }
  function poll(){
    fetch("/api/overview",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(render).catch(function(){});
    fetch("/api/requests?limit=10",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(function(d){renderRecent(d.requests)})
      .catch(function(){});
  }
  poll();
  if(!REDUCED) setInterval(poll, 2000);
</script>
</body>
</html>
"""

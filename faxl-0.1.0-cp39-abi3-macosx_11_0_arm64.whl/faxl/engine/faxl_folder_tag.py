# Vendored engine module (faxl_folder_tag.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl_folder_tag -- catalogue a FOLDER of photographs: a camera card, a download.

The Mac Photos job (apps/cameraroll.py + apps/tag_via_faxl.py) reaches photographs
through Photos.app. Most photographs a working photographer cares about never go
near Photos: they are on an SD card, or in a folder somebody sent. This job
points at the folder instead:

    files in a folder  ->  faxl (whatever model it is serving)  ->  tags written
                                                                     next to them

    python -m faxl.engine.faxl_folder_tag --path /Volumes/EOS_DIGITAL/DCIM \
        --recursive --write

WHAT GETS WRITTEN, AND WHERE (only with --write; --dry-run writes nothing
outside faxl's own job directory):

  * A JPEG gets the tags in its OWN EXIF (ImageDescription, UserComment,
    XPKeywords), so they travel with the file. The pixels are copied
    byte-for-byte and every other tag (camera, lens, GPS, dates) is kept: the
    writer is the Linux phototag app's, ported verbatim, and its docstring is
    the long version of why.
  * Everything else -- PNG, HEIC, TIFF, WebP, and the raw half of a raw+JPEG
    pair -- gets an XMP SIDECAR with the same basename (IMG_0001.CR3 ->
    IMG_0001.xmp), the Lightroom / Capture One convention, so those programs
    pick the keywords up on import. A raw file is never opened for writing.
  * catalogue.csv in the photograph's folder, one row per file: a person with
    a spreadsheet can search the card without faxl.

RAW FILES. faxl cannot decode raw yet. A camera set to RAW+JPEG writes both,
and the JPEG IS the same shot, so the pair is read once (the JPEG) and both
files get the tags. A raw file alone gets an error row that says why -- never
silently skipped, because a card with 400 raws and a report of "0 photographs"
reads as a broken product rather than as an honest limit.

THE MODEL IS NEVER NAMED. The request carries no "model" field, so the proxy
answers with whatever it is serving. Naming one makes the proxy SWITCH to it:
the Mac job defaulted to Qwen3-VL-4B, and every photograph came back HTTP 503
"faxl is switching to ... Retry in about 8s" -- a tagging run that restarted
the user's model. If the proxy is switching anyway (someone else asked), the
job waits and retries the same photograph rather than recording a failure.

THE JOB FILES are the camera-roll job's conventions, under jobs/folder/:
status.json (polled by the console), catalogue.jsonl (one row per shot,
appended and fsynced as each finishes -- the durable record and the resume
point), current.json (the photograph in front of the model right now) and
previews/ (small JPEGs the page shows).

Stdlib + Pillow only.
"""
import argparse
import base64
import csv
import hashlib
import io
import json
import os
import re
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from xml.sax.saxutils import escape as _xml_escape

# ---------------------------------------------------------------- the prompt

# The fixed preamble, shared VERBATIM with the Mac app (apps/tag_via_faxl.py)
# and the Linux one (apps/phototag.py). Long ON PURPOSE: it has to clear
# faxl's 1024-token gate for the ladder to engage at all, and every
# photograph in a run resumes from the same checkpoint inside it. Sharing it
# means a photograph catalogued by any of the three gets the same headings.
PREAMBLE = (
    "You are a photo cataloguer. For each image you are shown, report:\n"
    "1. TEXT: every word legible in the image, verbatim. If none, write NONE.\n"
    "2. SCENE: what the photograph shows, in one short sentence.\n"
    "3. TAGS: three to six lowercase keywords, comma separated.\n\n"
    "Rules you must follow exactly:\n"
    "- Report only what is visible. Never guess at text you cannot read.\n"
    "- Do not describe the image quality, resolution, or file format.\n"
    "- Do not speculate about when or where the photo was taken unless a\n"
    "  date or place name is legible in the image itself.\n"
    "- Keep the whole reply under 80 words.\n"
    "- Use the three headings above, in that order, nothing else.\n\n"
    "Reference notes for consistency across a catalogue:\n"
    + ("A document photographed at an angle is still a document; tag it by "
       "what it says, not by the angle. A screenshot is a screenshot even if "
       "it contains a photograph. A receipt, invoice or business card should "
       "have its numbers reported character by character, because a digit "
       "misread is worse than a digit omitted. Handwriting should be marked "
       "as handwriting so it can be reviewed by a person later. ") * 20
)
QUESTION = "Catalogue this photograph using the three headings."

# How the request log names this job. The User-Agent is the one the Mac
# tagger already sends (the console's client column says "phototag"), and the
# client/project headers put it beside the camera-roll job on the page.
HEADERS = {"User-Agent": "faxl-phototag",
           "X-Faxl-Client": "cameraroll",
           "X-Faxl-Project": "phototag"}

# ---------------------------------------------------------------- file kinds

JPEG_EXT = {".jpg", ".jpeg"}
# Read and sent to the model; tags go to a sidecar, never into the file.
OTHER_EXT = {".png": "PNG", ".heic": "HEIC", ".heif": "HEIC",
             ".tif": "TIFF", ".tiff": "TIFF", ".webp": "WebP"}
HEIC_EXT = {".heic", ".heif"}
# Raw: never decoded, never written. Paired with a same-name JPEG if one exists.
RAW_EXT = {".cr2", ".cr3", ".nef", ".arw", ".dng", ".orf", ".rw2", ".raf"}

RAW_ALONE = ("a raw file with no JPEG of the same shot: faxl cannot read raw "
             "files yet")

# A failed photograph is retried this many times when the proxy says "not
# now" (switching model, busy, restarting) before the failure is recorded.
MAX_TRIES = 6
RETRY_DEFAULT_SECS = 10.0
RETRY_MAX_SECS = 120.0

MODEL_EDGE = 1568        # what the model reads (phototag's figure)
PREVIEW_EDGE = 512       # what the page shows
PREVIEW_RE = re.compile(r"[0-9a-f]{40}\.jpg")
PREVIEW_MAX_MB = float(os.environ.get("FAXL_PREVIEW_MAX_MB", "500"))

XMP_NS = "https://faxl.ai/ns/1.0/"

# Indirection so the tests can run the retry and window waits instantly.
_sleep = time.sleep


def kind_of(name):
    """The label scan() and the page use for a file, or None if not a photo."""
    ext = os.path.splitext(name)[1].lower()
    if ext in JPEG_EXT:
        return "JPEG"
    if ext in OTHER_EXT:
        return OTHER_EXT[ext]
    if ext in RAW_EXT:
        return f"raw ({ext[1:].upper()})"
    return None


# ---------------------------------------------------------------- job files

def faxl_home():
    return os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")


def job_dir():
    d = os.path.join(faxl_home(), "jobs", "folder")
    os.makedirs(d, exist_ok=True)
    return d


def status_path():
    return os.path.join(job_dir(), "status.json")


def catalogue_path():
    return os.path.join(job_dir(), "catalogue.jsonl")


def current_path():
    """The photograph in front of the model right now (the page's ANALYSING)."""
    return os.path.join(job_dir(), "current.json")


def preview_dir():
    """Small JPEGs of what this job worked on, so the page can show them.

    0700: these are pictures of somebody's life, on a possibly shared Mac.
    """
    d = os.path.join(job_dir(), "previews")
    os.makedirs(d, mode=0o700, exist_ok=True)
    return d


def preview_name(path):
    """A preview's file name: a hash of the photograph's absolute path.

    A hash, not the file name: every camera card in the world has an
    IMG_0001.JPG, and two cards tagged in a row would overwrite each other's
    previews. A hash also contains nothing a URL or a path can trip over.
    """
    return hashlib.sha1(os.path.abspath(path).encode("utf-8", "surrogateescape")
                        ).hexdigest() + ".jpg"


def preview_file(name):
    """The on-disk path of preview `name`, or None.

    THE NAME IS NOT A PATH. Only the exact shape preview_name() makes -- 40
    hex digits and .jpg -- is accepted, then joined to the preview directory,
    so nothing a caller sends ("../x", an absolute path) can escape it.
    """
    if not isinstance(name, str) or not PREVIEW_RE.fullmatch(name):
        return None
    p = os.path.join(preview_dir(), name)
    return p if os.path.isfile(p) else None


def _atomic_json(path, data):
    """tmp + os.replace: the console polls these files and must never read
    half a document."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(data, fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except OSError:
        pass          # a progress file is never worth failing a run for


def read_status():
    """status.json as a dict, {"state": "none"} if no job has run."""
    try:
        with open(status_path()) as fh:
            return json.load(fh)
    except FileNotFoundError:
        return {"state": "none"}
    except (OSError, ValueError) as exc:
        return {"state": "unknown", "error": str(exc)}


def read_rows():
    """Every catalogue.jsonl row, oldest first. A torn final line is skipped."""
    rows = []
    try:
        with open(catalogue_path()) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    continue
    except OSError:
        pass
    return rows


def already_done(rows=None):
    """Paths that need no more work: catalogued without error, or a raw file
    alone (that error is a fact about the file, and asking again changes
    nothing -- re-trying it every run would only add duplicate rows)."""
    done = set()
    for r in rows if rows is not None else read_rows():
        if r.get("path") and (not r.get("error") or r.get("error") == RAW_ALONE):
            done.add(r["path"])
    return done


# ---------------------------------------------------------------- the window

def parse_window(spec):
    """"23:00-07:00" -> (1380, 420) in minutes past midnight, or None.

    The camera-roll job's parser, copied rather than imported so this module
    stands alone on every product line. A window that wraps midnight is the
    normal case -- the whole point is to run while the owner is asleep -- so
    the pair is NOT required to be ascending and `inside_window` handles it.
    """
    if not spec:
        return None
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*", spec)
    if not m:
        raise ValueError(f"window must look like 23:00-07:00, not {spec!r}")
    a_h, a_m, b_h, b_m = (int(x) for x in m.groups())
    for h, mi in ((a_h, a_m), (b_h, b_m)):
        if h > 23 or mi > 59:
            raise ValueError(f"{spec!r} is not a time of day")
    start, stop = a_h * 60 + a_m, b_h * 60 + b_m
    if start == stop:
        raise ValueError(f"{spec!r} is an empty window")
    return start, stop


def inside_window(win, now=None):
    if not win:
        return True
    now = now or time.localtime()
    mins = now.tm_hour * 60 + now.tm_min
    start, stop = win
    return start <= mins < stop if start < stop else (mins >= start or mins < stop)


# ---------------------------------------------------------------- finding shots

def _folder_problem(path):
    """A plain-words reason `path` cannot be read as a folder, or None."""
    if not path:
        return "no folder was given"
    if not os.path.exists(path):
        return f"there is no folder at {path}"
    if not os.path.isdir(path):
        return f"{path} is a file, not a folder"
    try:
        os.listdir(path)
    except PermissionError:
        if sys.platform == "darwin":
            return (f"macOS did not let faxl read {path}. Give Full Disk "
                    "Access to whatever you started faxl from (System "
                    "Settings -> Privacy & Security -> Full Disk Access), "
                    "then try again.")
        return f"faxl is not allowed to read {path}"
    except OSError as exc:
        return f"could not read {path}: {exc.strerror or exc}"
    return None


def _listing(path, recursive):
    """(folder, [file names]) pairs, sorted so a run is repeatable.

    HIDDEN FILES ARE NOT PHOTOGRAPHS. A card that has been in a Mac is full of
    ._IMG_0001.JPG AppleDouble files -- 4 KB of Finder metadata wearing a
    photograph's name -- and every one would come back "could not read".
    """
    if recursive:
        for folder, dirs, names in os.walk(path, onerror=lambda e: None):
            dirs[:] = sorted(d for d in dirs if not d.startswith("."))
            yield folder, sorted(n for n in names if not n.startswith("."))
    else:
        names = []
        for n in sorted(os.listdir(path)):
            if not n.startswith(".") and os.path.isfile(os.path.join(path, n)):
                names.append(n)
        yield path, names


def find_shots(path, recursive=False):
    """Every shot under `path`, in order. A shot is one photograph:

        {"path": the file the model reads (the raw itself if it is alone),
         "files": [every file of this shot, full paths],
         "kind": "JPEG" | "PNG" | ... | "raw (CR3)",
         "pair": True for raw+JPEG, "error": RAW_ALONE for a raw alone}

    A raw pairs with a JPEG of the same basename in the same folder (the
    camera wrote both for one exposure); compared case-insensitively because
    a card read on a case-insensitive Mac may show IMG_0001.JPG beside
    img_0001.cr3 after a copy tool lowercased one of them.
    """
    shots = []
    for folder, names in _listing(path, recursive):
        jpegs, raws = {}, {}
        for n in names:
            stem, ext = os.path.splitext(n)
            ext = ext.lower()
            if ext in JPEG_EXT:
                jpegs.setdefault(stem.lower(), n)
            elif ext in RAW_EXT:
                raws.setdefault(stem.lower(), []).append(n)
        for n in names:
            k = kind_of(n)
            if not k:
                continue
            stem, ext = os.path.splitext(n)
            full = os.path.join(folder, n)
            if ext.lower() in RAW_EXT:
                if stem.lower() in jpegs:
                    continue                    # carried by its JPEG's shot
                shots.append({"path": full, "files": [full], "kind": k,
                              "pair": False, "error": RAW_ALONE})
            elif ext.lower() in JPEG_EXT and jpegs.get(stem.lower()) == n \
                    and stem.lower() in raws:
                shots.append({"path": full,
                              "files": [full] + [os.path.join(folder, r)
                                                 for r in raws[stem.lower()]],
                              "kind": k, "pair": True})
            else:
                shots.append({"path": full, "files": [full], "kind": k,
                              "pair": False})
    return shots


def scan(path, recursive=False):
    """What the page shows BEFORE starting: how many photographs, of what kind.

    Names only -- nothing is opened or decoded, so a card of 2,000 files
    answers in well under a second. Never raises: a bad path is
    {"ok": False, "error": <plain words>}.

        {"ok", "path", "photos": shots faxl can read (a pair counts once),
         "files": photo files seen, "by_kind": {"JPEG": n, "raw (CR3)": n, ...},
         "raw_with_jpeg": n, "raw_alone": n}
    """
    out = {"ok": False, "path": path, "photos": 0, "files": 0, "by_kind": {},
           "raw_with_jpeg": 0, "raw_alone": 0}
    try:
        # Empty is refused BEFORE abspath, which would turn "" into the
        # console's own working directory and scan that instead.
        why = _folder_problem(path)
        if not why:
            path = os.path.abspath(os.path.expanduser(path))
            out["path"] = path
            why = _folder_problem(path)
        if why:
            out["error"] = why
            return out
        for shot in find_shots(path, recursive):
            for f in shot["files"]:
                k = kind_of(f)
                out["by_kind"][k] = out["by_kind"].get(k, 0) + 1
                out["files"] += 1
                if shot.get("pair") and k.startswith("raw"):
                    out["raw_with_jpeg"] += 1
            if shot.get("error") == RAW_ALONE:
                out["raw_alone"] += 1
            else:
                out["photos"] += 1
        out["ok"] = True
    except Exception as exc:                              # noqa: BLE001
        out["error"] = f"could not look through {path}: {exc}"
    return out


# ---------------------------------------------------------------- reading pictures

def _heic_to_jpeg(path, tmpdir):
    """Convert a HEIC to a JPEG derivative with macOS's own sips. Returns the
    derivative's path. argv, never a shell string: a file name from a card is
    not something to hand a shell."""
    out = os.path.join(tmpdir, "heic.jpg")
    r = subprocess.run(["/usr/bin/sips", "-s", "format", "jpeg", path,
                        "--out", out], capture_output=True, text=True,
                       timeout=120)
    if r.returncode != 0 or not os.path.isfile(out):
        raise RuntimeError("macOS could not convert this HEIC picture: "
                           + ((r.stderr or r.stdout or "").strip()[:200]
                              or f"sips exited {r.returncode}"))
    return out


def _open_upright(path, tmpdir):
    """A Pillow image of `path`, rotated the way the camera meant it.

    HEIC needs help: Pillow cannot open it alone. On a Mac, sips converts a
    derivative (the original is not touched); elsewhere pillow-heif does, if
    it is installed; otherwise the photograph fails with a reason naming it.
    """
    from PIL import Image, ImageOps
    src = path
    if os.path.splitext(path)[1].lower() in HEIC_EXT:
        if sys.platform == "darwin":
            src = _heic_to_jpeg(path, tmpdir)
        else:
            try:
                import pillow_heif                         # type: ignore
                pillow_heif.register_heif_opener()
            except ImportError:
                raise RuntimeError("faxl needs pillow-heif to read HEIC "
                                   "pictures on this system: pip install "
                                   "pillow-heif")
    with Image.open(src) as im:
        im.load()
        im = ImageOps.exif_transpose(im)      # apply the orientation flag
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        return im.copy()


def encode_for_model(path, max_edge=MODEL_EDGE, preview_to=None):
    """base64 JPEG bytes for the API (phototag's encode_for_model).

    Two jobs, and both matter. ORIENTATION: a phone writes the picture in
    sensor order plus an EXIF orientation flag, so a portrait photo handed to a
    model unrotated arrives sideways and the reply is noise. SIZE: a 12 MP
    original is megabytes of base64 for no gain in what the model can read.
    This is a DERIVATIVE -- the file on disk is never re-encoded.

    `preview_to`: also save a small JPEG there from the same decode, so a
    photograph is read off the card once, not twice.
    """
    tmpdir = tempfile.mkdtemp(prefix="faxl-folder-")
    try:
        im = _open_upright(path, tmpdir)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    big = im.copy()
    big.thumbnail((max_edge, max_edge))
    buf = io.BytesIO()
    big.save(buf, format="JPEG", quality=88)
    if preview_to:
        try:
            small = im.copy()
            small.thumbnail((PREVIEW_EDGE, PREVIEW_EDGE))
            tmp = preview_to + ".tmp"
            small.convert("RGB").save(tmp, format="JPEG", quality=80)
            os.replace(tmp, preview_to)
        except OSError:
            pass                       # a preview is a nicety, never a failure
    return base64.b64encode(buf.getvalue()).decode()


def parse_catalogue(text):
    """Pull SCENE / TAGS / TEXT out of the model's reply.

    The model was asked for three headings and mostly obeys, but a small
    quantised model drifts -- so this tolerates missing or reordered sections
    and returns whatever it could find rather than failing the photograph.
    (Same rule as the Mac line's write_to_photos.parse_catalogue.)
    """
    out = {"scene": "", "tags": [], "text": ""}
    if not text:
        return out
    for key, pat in (("text", r"TEXT\s*:\s*(.*?)(?=\n\s*(?:SCENE|TAGS)\s*:|\Z)"),
                     ("scene", r"SCENE\s*:\s*(.*?)(?=\n\s*(?:TEXT|TAGS)\s*:|\Z)"),
                     ("tags", r"TAGS\s*:\s*(.*?)(?=\n\s*(?:TEXT|SCENE)\s*:|\Z)")):
        m = re.search(pat, text, re.S | re.I)
        if not m:
            continue
        val = " ".join(m.group(1).split())
        if key == "tags":
            out["tags"] = [t.strip().lower() for t in val.split(",")
                           if t.strip()]
        else:
            out[key] = val
    return out


def caption_for(parsed):
    """One line for the description: the scene, or the legible text if the
    photograph is a document and the scene came back empty."""
    scene = (parsed.get("scene") or "").strip()
    if scene:
        return scene
    txt = (parsed.get("text") or "").strip()
    if txt and txt.upper() != "NONE":
        return txt[:200]
    return ""


# ---------------------------------------------------------------- the proxy

class NotNow(Exception):
    """The proxy cannot answer this photograph YET -- it is switching model,
    busy with another request, or restarting. Wait and send it again."""

    def __init__(self, reason, wait):
        super().__init__(reason)
        self.reason = reason
        self.wait = wait


class Refused(Exception):
    """The proxy answered, and the answer is no. Recorded against the photo."""


def _retry_after(headers):
    try:
        v = float((headers or {}).get("Retry-After"))
        return max(0.0, min(v, RETRY_MAX_SECS))
    except (TypeError, ValueError):
        return RETRY_DEFAULT_SECS


def _error_message(raw):
    """The proxy's own sentence out of an error body, or the body itself."""
    try:
        d = json.loads(raw)
        e = d.get("error")
        if isinstance(e, dict) and e.get("message"):
            return str(e["message"])
        if isinstance(e, str):
            return e
    except (ValueError, AttributeError):
        pass
    return raw.strip()


def model_reads_pictures(endpoint, timeout=10):
    """True / False / None (unknown), from the proxy's /api/state model.vision.

    Raises NotNow if the proxy is not answering, so the caller can wait for a
    restarting proxy rather than declaring the job failed on a blip.
    """
    try:
        with urllib.request.urlopen(urllib.request.Request(
                f"{endpoint}/api/state",
                headers={"Accept": "application/json", **HEADERS}),
                timeout=timeout) as r:
            st = json.loads(r.read().decode() or "{}")
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise NotNow(f"faxl is not answering at {endpoint} "
                     f"({getattr(exc, 'reason', exc)})", RETRY_DEFAULT_SECS)
    v = (st.get("model") or {}).get("vision")
    return v if isinstance(v, bool) else None


def ask(endpoint, b64, timeout=600):
    """One photograph to the proxy. Returns (reply dict, seconds).

    NO "model" KEY: the proxy serves whatever it has loaded. See the module
    docstring for the bug that caused.
    """
    body = {
        "messages": [
            {"role": "system", "content": PREAMBLE},
            # THE QUESTION THEN THE PICTURE -- the order the Mac app's working
            # run used across several hundred photographs. Do not reorder: the
            # preamble is what checkpoints, so every photograph resumes from
            # the same grid boundary inside the shared text.
            {"role": "user", "content": [
                {"type": "text", "text": QUESTION},
                {"type": "image_url",
                 "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
            ]},
        ],
        # THINKING OFF. A reasoning model (Qwen3.6, the Mac's usual one)
        # otherwise spends the whole allowance thinking and returns no
        # answer: on 2026-10-14 every photo of a live run came back "the
        # model returned an empty reply" with exactly 140 tokens generated.
        # Both spellings: faxl's own field, and the chat-template one vLLM
        # and other OpenAI-style servers read. 400 leaves room for a long
        # TEXT heading on a document photo.
        "enable_thinking": False,
        "chat_template_kwargs": {"enable_thinking": False},
        "max_tokens": 400,
        "temperature": 0,
    }
    req = urllib.request.Request(
        f"{endpoint}/v1/chat/completions", data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", **HEADERS},
        method="POST")
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        detail = _error_message(e.read().decode(errors="replace"))
        # 503 is the proxy saying "not now": switching model, busy with
        # another request, no model yet, telemetry blip. 502/504 is a backend
        # restarting behind it. All of them deserve a wait, not a failure.
        if e.code in (502, 503, 504):
            raise NotNow(detail or f"HTTP {e.code}", _retry_after(e.headers))
        raise Refused(f"faxl refused this photograph (HTTP {e.code}): {detail}")
    except urllib.error.URLError as e:
        # Connection refused / reset: the proxy is restarting (a model switch
        # replaces the process). A TIMEOUT is not retried -- the request may
        # still be generating, and sending it again would queue a duplicate.
        reason = getattr(e, "reason", e)
        if isinstance(reason, (TimeoutError,)) or "timed out" in str(reason):
            raise Refused(f"faxl did not answer within {timeout:.0f}s")
        raise NotNow(f"faxl is not answering ({reason})", RETRY_DEFAULT_SECS)
    except (ConnectionError, OSError) as e:
        if isinstance(e, TimeoutError):
            raise Refused(f"faxl did not answer within {timeout:.0f}s")
        raise NotNow(f"faxl is not answering ({e})", RETRY_DEFAULT_SECS)
    if not raw.strip():
        raise Refused("faxl sent back an empty reply -- check its log")
    try:
        return json.loads(raw.decode()), time.time() - t0
    except ValueError:
        raise Refused("faxl sent back something that is not JSON: "
                      + raw.decode(errors="replace")[:200])


def last_request(endpoint, txn=None):
    """What the proxy recorded for the request just made (tag_via_faxl's).

    /metrics counts only what the exo prefill server reports, so on the mlx
    path it reads zero through a run that is hitting the cache every time.
    The request feed is written by both backends, so read that.
    """
    try:
        with urllib.request.urlopen(
                f"{endpoint}/api/requests?limit=8", timeout=10) as r:
            rows = json.loads(r.read().decode()).get("requests") or []
    except Exception:                                    # noqa: BLE001
        return {}
    if txn:
        for row in rows:
            if row.get("transaction_id") == txn:
                return row
    return rows[0] if rows else {}


# ---------------------------------------------------------------- JPEG EXIF writer
# Ported verbatim from apps/phototag.py (Halo-329), except the extended-
# attribute handling, which on Linux used os.getxattr -- absent on macOS. A
# Mac keeps Finder tags and the quarantine flag in xattrs; replacing the file
# without copying them would silently strip a photograph's Finder tags.

def _jpeg_parts(data):
    """Split a complete JPEG without changing any marker or entropy bytes."""
    if data[:2] != b'\xff\xd8':
        raise ValueError('not a JPEG')
    parts = [(0xd8, data[:2])]
    pos = 2
    while pos < len(data):
        start = pos
        if data[pos] != 255:
            raise ValueError('invalid JPEG marker')
        while pos < len(data) and data[pos] == 255:
            pos += 1
        if pos == len(data):
            raise ValueError('truncated JPEG marker')
        marker = data[pos]
        pos += 1
        if marker == 0xd9:
            if pos != len(data) or not any(kind == 0xda for kind, _ in parts):
                raise ValueError('unsupported JPEG trailing bytes or missing scan')
            return parts + [(marker, data[start:pos])]
        if marker in (0, 0xd8) or 0xd0 <= marker <= 0xd7:
            raise ValueError('unexpected JPEG marker')
        if marker != 1:
            if pos + 2 > len(data):
                raise ValueError('truncated JPEG segment')
            length = int.from_bytes(data[pos:pos+2], 'big')
            if length < 2 or pos + length > len(data):
                raise ValueError('invalid JPEG segment length')
            pos += length
        parts.append((marker, data[start:pos]))
        if marker == 0xda:
            start = pos
            while True:
                stop = data.find(b'\xff', pos)
                if stop < 0:
                    raise ValueError('unterminated JPEG scan')
                at = stop + 1
                while at < len(data) and data[at] == 255:
                    at += 1
                if at == len(data):
                    raise ValueError('truncated JPEG scan marker')
                if data[at] == 0 or 0xd0 <= data[at] <= 0xd7:
                    pos = at + 1
                    continue
                parts.append((None, data[start:stop]))
                pos = stop
                break
    raise ValueError('JPEG missing EOI')


def _updated_tiff(tiff, caption, keywords, full_reply):
    """Append replacement IFDs; retain all original payloads at their offsets.

    In particular, never decode/repack unknown tags, MakerNotes or thumbnails.
    Only the TIFF root link and the root's Exif link change. Old tables remain
    inert in the payload; repeated updates consume the bounded APP1 capacity.
    """
    if len(tiff) < 8 or tiff[:2] not in (b'II', b'MM'):
        raise ValueError('unsupported TIFF header')
    endian = '<' if tiff[:2] == b'II' else '>'
    unpack = lambda fmt, at: struct.unpack_from(endian + fmt, tiff, at)  # noqa: E731
    pack = lambda fmt, *args: struct.pack(endian + fmt, *args)  # noqa: E731
    if unpack('H', 2)[0] != 42:
        raise ValueError('unsupported TIFF format')
    sizes = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 6: 1, 7: 1, 8: 2, 9: 4, 10: 8,
             11: 4, 12: 8, 13: 4}

    def table(offset, root=False):
        if offset < 8 or offset + 2 > len(tiff):
            raise ValueError('IFD offset outside EXIF')
        count = unpack('H', offset)[0]
        end = offset + 2 + count * 12
        if end + (4 if root else 0) > len(tiff):
            raise ValueError('truncated IFD')
        entries = {}
        for at in range(offset + 2, end, 12):
            tag, kind, number = unpack('HHI', at)
            if tag in entries or kind not in sizes or number == 0:
                raise ValueError('duplicate tag or unsupported TIFF value')
            size = sizes[kind] * number
            if size > 4:
                pointer = unpack('I', at + 8)[0]
                if pointer < 8 or pointer + size > len(tiff):
                    raise ValueError('TIFF value outside EXIF')
            entries[tag] = tiff[at:at+12]
        # Exif sub-IFDs have no chain used by EXIF readers; keep any original
        # following bytes too, without interpreting/rebasing opaque pointers.
        following = tiff[end:end+4] if end + 4 <= len(tiff) else b'\0'*4
        return entries, following

    root_offset = unpack('I', 4)[0]
    validated = set()

    def validate_links(offset, chained, ancestors):
        if offset in ancestors:
            raise ValueError('cyclic TIFF IFD link')
        state = (offset, chained)
        if state in validated:
            return
        entries, following = table(offset, root=chained)
        ancestors = ancestors | {offset}
        for tag in (330, 34665, 34853, 40965):
            if tag not in entries:
                continue
            _, kind, number, pointer = struct.unpack(endian + 'HHII', entries[tag])
            if kind not in (4, 13) or (tag != 330 and number != 1):
                raise ValueError('invalid TIFF IFD link type/count')
            offsets = (pointer,) if number == 1 else unpack('I'*number, pointer)
            for child in offsets:
                validate_links(child, tag == 330, ancestors)
        if chained:
            following_offset = struct.unpack(endian + 'I', following)[0]
            if following_offset:
                validate_links(following_offset, True, ancestors)
        validated.add(state)

    validate_links(root_offset, True, set())
    zeroth, next_ifd = table(root_offset, root=True)
    exif, exif_next = {}, b'\0'*4
    if 34665 in zeroth:
        _, kind, number, offset = struct.unpack(endian + 'HHII', zeroth[34665])
        if kind != 4 or number != 1 or offset == root_offset:
            raise ValueError('invalid Exif IFD link')
        exif, exif_next = table(offset)
    out = bytearray(tiff)

    def append(data):
        if len(out) % 2:
            out.append(0)
        offset = len(out)
        out.extend(data)
        return offset

    def value(tag, kind, data):
        encoded = data.ljust(4, b'\0') if len(data) <= 4 else pack('I', append(data))
        return pack('HHI', tag, kind, len(data)) + encoded

    def append_table(entries, following):
        if len(entries) > 65535:
            raise ValueError('too many TIFF entries')
        return append(pack('H', len(entries))
                      + b''.join(entries[k] for k in sorted(entries)) + following)

    if caption:
        zeroth[270] = value(270, 2, caption.encode('utf-8') + b'\0')
    if keywords:
        zeroth[40094] = value(40094, 1, ';'.join(keywords).encode('utf-16le'))
    if full_reply:
        exif[37510] = value(37510, 7, b'\0'*8 + full_reply.encode('utf-8'))
        zeroth[34665] = pack('HHII', 34665, 4, 1, append_table(exif, exif_next))
    out[4:8] = pack('I', append_table(zeroth, next_ifd))
    return bytes(out)


def _updated_jpeg(data, caption, keywords, full_reply):
    parts = _jpeg_parts(data)
    indices = [i for i, (marker, segment) in enumerate(parts)
               if marker == 0xe1 and segment.lstrip(b'\xff')[3:9] == b'Exif\0\0']
    if len(indices) > 1:
        raise ValueError('multiple Exif APP1 segments are ambiguous')
    if indices:
        segment = parts[indices[0]][1]
        marker_prefix = segment[:len(segment)-len(segment.lstrip(b'\xff'))+1]
        tiff = segment.lstrip(b'\xff')[9:]
    else:
        marker_prefix = b'\xff\xe1'
        tiff = b'II\x2a\0\x08\0\0\0\0\0\0\0\0\0'
    updated = _updated_tiff(tiff, caption, keywords, full_reply)
    payload = b'Exif\0\0' + updated
    if len(payload) + 2 > 65535:
        raise ValueError('EXIF exceeds JPEG APP1 capacity; original unchanged')
    segment = marker_prefix + struct.pack('>H', len(payload) + 2) + payload
    if indices:
        parts[indices[0]] = (0xe1, segment)
    else:
        # Retain leading JFIF/other metadata, inserting before the first scan.
        index = next((i for i, (marker, _) in enumerate(parts) if marker == 0xda),
                     len(parts)-1)
        parts.insert(index, (0xe1, segment))
    return b''.join(segment for _, segment in parts)


_DARWIN_XATTR = {}


def _darwin_libc():
    """libc's xattr calls via ctypes: Python on macOS has no os.getxattr."""
    if "libc" not in _DARWIN_XATTR:
        import ctypes
        libc = ctypes.CDLL(None, use_errno=True)
        sz, c = ctypes.c_size_t, ctypes.c_char_p
        libc.flistxattr.argtypes = [ctypes.c_int, ctypes.c_void_p, sz, ctypes.c_int]
        libc.flistxattr.restype = ctypes.c_ssize_t
        libc.fgetxattr.argtypes = [ctypes.c_int, c, ctypes.c_void_p, sz,
                                   ctypes.c_uint32, ctypes.c_int]
        libc.fgetxattr.restype = ctypes.c_ssize_t
        libc.setxattr.argtypes = [c, c, ctypes.c_void_p, sz, ctypes.c_uint32,
                                  ctypes.c_int]
        libc.setxattr.restype = ctypes.c_int
        _DARWIN_XATTR["libc"] = libc
        _DARWIN_XATTR["ctypes"] = ctypes
    return _DARWIN_XATTR["libc"], _DARWIN_XATTR["ctypes"]


def _fd_xattrs(fd):
    """Every extended attribute of an open file, {name: bytes}."""
    if hasattr(os, "listxattr"):
        return {k: os.getxattr(fd, k) for k in os.listxattr(fd)}
    if sys.platform != "darwin":
        return {}
    libc, ctypes = _darwin_libc()

    def check(n):
        if n < 0:
            e = ctypes.get_errno()
            raise OSError(e, os.strerror(e))
        return n
    n = check(libc.flistxattr(fd, None, 0, 0))
    if not n:
        return {}
    buf = ctypes.create_string_buffer(n)
    n = check(libc.flistxattr(fd, buf, n, 0))
    out = {}
    for name in buf.raw[:n].split(b"\0"):
        if not name:
            continue
        size = check(libc.fgetxattr(fd, name, None, 0, 0, 0))
        val = ctypes.create_string_buffer(max(size, 1))
        size = check(libc.fgetxattr(fd, name, val, size, 0, 0))
        out[name.decode("utf-8", "surrogateescape")] = val.raw[:size]
    return out


def _path_xattrs(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        return _fd_xattrs(fd)
    finally:
        os.close(fd)


def _copy_xattrs(attributes, path):
    """Put `attributes` on `path`. On Linux shutil.copystat already did; on a
    Mac it does not copy xattrs, so this does, and the caller verifies."""
    if hasattr(os, "listxattr") or sys.platform != "darwin":
        return
    libc, ctypes = _darwin_libc()
    for k, v in attributes.items():
        if libc.setxattr(os.fsencode(path), k.encode("utf-8", "surrogateescape"),
                         v, len(v), 0, 0x0001) != 0:          # XATTR_NOFOLLOW
            e = ctypes.get_errno()
            raise OSError(e, f"could not copy the {k} attribute: {os.strerror(e)}")


def _write_jpeg_exif(path, caption, keywords, full_reply):
    temporary = None
    try:
        before = os.lstat(path)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('EXIF update requires a regular file, not a symlink')
        # Refuse a symlink substitution after lstat as well. O_NOFOLLOW /
        # O_NONBLOCK also avoid blocking on a substituted FIFO.
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as source:
            opened = os.fstat(source.fileno())
            if not stat.S_ISREG(opened.st_mode) or \
                    (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
                raise ValueError('input changed before EXIF read')
            attributes = _fd_xattrs(source.fileno())
            original = source.read()
        updated = _updated_jpeg(original, caption, keywords, full_reply)
        fd, temporary = tempfile.mkstemp(prefix='.phototag-',
                                         dir=os.path.dirname(os.path.abspath(path)))
        with os.fdopen(fd, 'wb') as target:
            # chown can clear mode/capability bits, so it precedes the final
            # metadata copy. Inability to retain ownership is a hard refusal.
            os.fchown(target.fileno(), before.st_uid, before.st_gid)
            target.write(updated)
            target.flush()
            os.fsync(target.fileno())
        current = os.lstat(path)

        def identity(info):
            return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
                    info.st_ctime_ns)
        if identity(current) != identity(before):
            raise ValueError('input changed during EXIF update')
        shutil.copystat(path, temporary)
        _copy_xattrs(attributes, temporary)
        copied = os.stat(temporary)
        if (copied.st_uid, copied.st_gid, stat.S_IMODE(copied.st_mode)) != \
                (before.st_uid, before.st_gid, stat.S_IMODE(before.st_mode)):
            raise ValueError('could not preserve file ownership/mode')
        # copystat may suppress xattr errors (including ACL/capability errors).
        # Check actual retained values so failure cannot silently alter access.
        if _path_xattrs(temporary) != attributes:
            raise ValueError('could not preserve file extended attributes')
        if identity(os.lstat(path)) != identity(before):
            raise ValueError('input changed during metadata publication')
        os.replace(temporary, path)
        temporary = None
    except PermissionError:
        return False, 'could not write EXIF: the folder is not writable'
    except Exception as exc:                              # noqa: BLE001
        # Never an empty reason: an exception without a message is named by
        # its type.
        return False, f'could not write EXIF: {str(exc) or type(exc).__name__}'
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass
    return True, 'written'


def write_exif(path, caption, keywords, full_reply):
    """Write caption/keywords into a JPEG's own metadata, pixels untouched.
    (ok, why). Anything but a JPEG is refused by name, before it is opened."""
    if os.path.splitext(path)[1].lower() in JPEG_EXT:
        return _write_jpeg_exif(path, caption, keywords, full_reply)
    return False, "only a JPEG can carry the tags in the file itself"


# ---------------------------------------------------------------- XMP sidecar

def sidecar_path(path):
    """IMG_0001.CR3 -> IMG_0001.xmp: the Lightroom / Capture One convention,
    which is what makes those programs read the keywords on import."""
    return os.path.splitext(path)[0] + ".xmp"


def _xmp_namespaces(text):
    return set(re.findall(r'xmlns:([A-Za-z_][\w.-]*)\s*=', text))


# The namespaces a faxl sidecar declares, and nothing else.
_OUR_NS = {"x", "rdf", "dc", "xmp", "faxl"}


def _sidecar_is_ours(text):
    """Did faxl write this sidecar, and ONLY faxl?

    The marker alone is not enough. Lightroom keeps unknown namespaces when it
    rewrites a sidecar, so a file that started as faxl's can come back holding
    somebody's develop settings (crs:), ratings and colour labels. Overwriting
    that would throw away an afternoon's editing for the sake of five
    keywords, so a sidecar is faxl's to replace only if it has the marker AND
    declares no namespace faxl does not write.
    """
    return (f'xmlns:faxl="{XMP_NS}"' in text and 'faxl:tagger="faxl"' in text
            and _xmp_namespaces(text) <= _OUR_NS)


def xmp_document(scene, keywords, text_in_picture=""):
    """An XMP packet: dc:description (x-default) = the scene, dc:subject =
    the keywords, and the faxl marker that says who wrote it."""
    e = lambda s: _xml_escape(s or "", {'"': "&quot;"})  # noqa: E731
    subj = "".join(f"\n     <rdf:li>{e(k)}</rdf:li>" for k in keywords)
    extra = (f'\n   faxl:text="{e(text_in_picture)}"'
             if text_in_picture and text_in_picture.upper() != "NONE" else "")
    return (
        '<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>\n'
        '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="faxl">\n'
        ' <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n'
        '  <rdf:Description rdf:about=""\n'
        '   xmlns:dc="http://purl.org/dc/elements/1.1/"\n'
        '   xmlns:xmp="http://ns.adobe.com/xap/1.0/"\n'
        f'   xmlns:faxl="{XMP_NS}"\n'
        '   xmp:CreatorTool="faxl"\n'
        f'   faxl:tagger="faxl"{extra}>\n'
        '   <dc:description>\n    <rdf:Alt>\n'
        f'     <rdf:li xml:lang="x-default">{e(scene)}</rdf:li>\n'
        '    </rdf:Alt>\n   </dc:description>\n'
        f'   <dc:subject>\n    <rdf:Bag>{subj}\n    </rdf:Bag>\n   </dc:subject>\n'
        '  </rdf:Description>\n'
        ' </rdf:RDF>\n'
        '</x:xmpmeta>\n'
        '<?xpacket end="w"?>\n')


def write_sidecar(path, scene, keywords, text_in_picture=""):
    """Write `path`'s XMP sidecar. Returns the write-field sentence.

    Atomic (tmp + os.replace): Lightroom may be watching the folder, and a
    half-written sidecar it imports is worse than none.
    """
    side = sidecar_path(path)
    name = os.path.basename(side)
    try:
        with open(side, encoding="utf-8", errors="replace") as fh:
            existing = fh.read()
        if not _sidecar_is_ours(existing):
            return ("skipped: an .xmp sidecar from another program is "
                    "already there")
    except FileNotFoundError:
        pass
    except OSError as exc:
        return f"not written: could not read {name} ({exc.strerror or exc})"
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(prefix=".faxl-", suffix=".xmp",
                                   dir=os.path.dirname(os.path.abspath(side)))
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(xmp_document(scene, keywords, text_in_picture))
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, side)
        tmp = None
    except PermissionError:
        return f"not written: the folder is not writable ({name})"
    except OSError as exc:
        return f"not written: could not write {name} ({exc.strerror or exc})"
    finally:
        if tmp:
            try:
                os.unlink(tmp)
            except OSError:
                pass
    return f"written to {name}"


# ---------------------------------------------------------------- catalogue.csv

CSV_HEADER = ["file", "scene", "keywords", "text_in_picture"]


def append_csv(folder, rows):
    """Append rows to catalogue.csv in `folder`. Returns None or a reason.

    For the person with a spreadsheet and no faxl: one row per FILE (both
    halves of a raw+JPEG pair), so looking up IMG_0001.CR3 finds it.
    """
    p = os.path.join(folder, "catalogue.csv")
    try:
        new = not os.path.exists(p) or os.path.getsize(p) == 0
        with open(p, "a", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            if new:
                w.writerow(CSV_HEADER)
            w.writerows(rows)
            fh.flush()
            os.fsync(fh.fileno())
    except PermissionError:
        return f"catalogue.csv not written: {folder} is not writable"
    except OSError as exc:
        return f"catalogue.csv not written: {exc.strerror or exc}"
    return None


# ---------------------------------------------------------------- one shot

def write_shot(shot, parsed, reply, sidecars_this_run):
    """Put the tags where they belong for every file of the shot.

    Returns (write sentence, warning or None). Never raises: a photograph
    whose write failed is still catalogued, and the row says what happened.
    """
    scene = caption_for(parsed)
    tags = parsed["tags"]
    text = parsed.get("text") or ""
    said, warning = [], None
    for f in shot["files"]:
        ext = os.path.splitext(f)[1].lower()
        if ext in JPEG_EXT:
            ok, why = write_exif(f, scene, tags, reply)
            if ok:
                said.append("written into the photo")
                continue
            # The EXIF writer refuses rather than risk the file (a JPEG with
            # trailing bytes, an APP1 that is full). The tags then go to a
            # sidecar so they are not lost, and the row says both.
            said.append(f"not written into the photo ({why})")
        side = sidecar_path(f)
        owner = sidecars_this_run.get(side)
        if owner is not None and owner != shot["path"]:
            # IMG_1.png and IMG_1.heic in one folder share IMG_1.xmp; the
            # second would silently replace the first one's tags.
            said.append(f"skipped: {os.path.basename(side)} already holds the "
                        f"tags of {os.path.basename(owner)}")
            continue
        if owner == shot["path"]:
            continue                 # a pair's files share one sidecar
        res = write_sidecar(f, scene, tags, text)
        if res.startswith("written"):
            sidecars_this_run[side] = shot["path"]
        said.append(res)
    folder = os.path.dirname(shot["path"])
    keywords = "; ".join(tags)
    txt = "" if text.upper() == "NONE" else text
    problem = append_csv(folder, [[os.path.basename(f), scene, keywords, txt]
                                  for f in shot["files"]])
    if problem:
        said.append(problem)
        warning = problem
    return "; ".join(said), warning


# ---------------------------------------------------------------- the job

_stopping = {"now": False}


def _note_stop(signum, frame):                           # noqa: ARG001
    _stopping["now"] = True
    print("[folder] stop requested -- finishing this photograph",
          file=sys.stderr, flush=True)


def _wait(secs):
    """Sleep in short steps so a stop is honoured within a second."""
    left = float(secs)
    while left > 0 and not _stopping["now"]:
        step = min(1.0, left)
        _sleep(step)
        left -= step


def sweep_previews():
    """Keep the preview store under its size cap, oldest first. Once per run:
    a stat of every file is not worth doing per photograph."""
    try:
        d = preview_dir()
        files = []
        for n in os.listdir(d):
            p = os.path.join(d, n)
            try:
                st = os.stat(p)
            except OSError:
                continue
            files.append((st.st_mtime, st.st_size, p))
        files.sort()
        total = sum(f[1] for f in files)
        while files and total > PREVIEW_MAX_MB * 1e6:
            _m, sz, p = files.pop(0)
            try:
                os.remove(p)
                total -= sz
            except OSError:
                break
    except Exception:                                     # noqa: BLE001
        pass


class Job:
    """Status bookkeeping for one run. Every write is the whole document."""

    def __init__(self, args):
        self.st = {"state": "running", "pid": os.getpid(),
                   "started": time.time(), "updated": None, "target": 0,
                   "tagged": 0, "failed": 0, "source": "folder",
                   "path": args.path, "recursive": bool(args.recursive),
                   "write": bool(args.write and not args.dry_run),
                   "dry_run": bool(args.dry_run),
                   "window": args.window or None, "error": None}

    def set(self, **fields):
        self.st.update(fields)
        self.st["updated"] = time.time()
        _atomic_json(status_path(), self.st)


def _record(fh, row):
    """APPEND AND FSYNC PER PHOTOGRAPH: the JSONL is the durable record and
    the resume point, so a run stopped at any moment loses nothing."""
    row.setdefault("ts", time.time())
    fh.write(json.dumps(row) + "\n")
    fh.flush()
    os.fsync(fh.fileno())


def _tag_one(shot, args, job, out_fh, sidecars, index, of):
    """Catalogue one shot. Returns "tagged", "failed", "stopped" or a fatal
    error message (str starting "fatal:") that ends the run."""
    path = shot["path"]
    base = {"photo": os.path.basename(path), "path": path,
            "files": [os.path.basename(f) for f in shot["files"]],
            "preview": None}
    if shot.get("error"):
        _record(out_fh, dict(base, error=shot["error"],
                             write="not written"))
        return "failed"

    pname = preview_name(path)
    _atomic_json(current_path(), {"photo": base["photo"], "path": path,
                                  "files": base["files"], "preview": pname,
                                  "index": index, "of": of,
                                  "started_at": time.time()})
    try:
        b64 = encode_for_model(path, preview_to=os.path.join(preview_dir(), pname))
    except Exception as exc:                              # noqa: BLE001
        why = str(exc) or type(exc).__name__
        if "cannot identify image file" in why:
            why = ("could not read this picture: it is damaged, or not the "
                   "kind of file its name says")
        elif not why.startswith(("faxl needs", "macOS")):
            why = f"could not read this picture: {why}"
        _record(out_fh, dict(base, error=why, write="not written"))
        return "failed"
    base["preview"] = pname if os.path.isfile(os.path.join(preview_dir(), pname)) else None

    for attempt in range(1, MAX_TRIES + 1):
        try:
            reply, dt = ask(args.endpoint, b64, args.timeout)
            break
        except NotNow as nn:
            if attempt == MAX_TRIES:
                _record(out_fh, dict(base, error=(
                    f"faxl was still not ready after {MAX_TRIES} tries: "
                    f"{nn.reason}"), write="not written"))
                job.set(state="running", reason=None)
                return "failed"
            job.set(state="waiting", reason=(
                f"{nn.reason} (waiting {nn.wait:.0f}s, try {attempt + 1} of "
                f"{MAX_TRIES})"))
            print(f"[folder] {base['photo']}: {nn.reason} -- waiting "
                  f"{nn.wait:.0f}s", file=sys.stderr, flush=True)
            _wait(nn.wait)
            if _stopping["now"]:
                return "stopped"
            job.set(state="running", reason=None)
        except Refused as rf:
            _record(out_fh, dict(base, error=str(rf), write="not written"))
            if "images_not_supported" in str(rf):
                return ("fatal:the model faxl is serving cannot read pictures")
            return "failed"

    try:
        text = reply["choices"][0]["message"].get("content")
    except (KeyError, IndexError, TypeError, AttributeError):
        text = None
    if not text:
        _record(out_fh, dict(base, error="the model returned an empty reply",
                             write="not written"))
        return "failed"
    text = text.split("<|")[0].strip()
    parsed = parse_catalogue(text)
    row = last_request(args.endpoint, reply.get("id"))
    served = int(row.get("prefill_skipped", 0) or 0)
    prompt_toks = int((reply.get("usage") or {}).get("prompt_tokens", 0) or 0) \
        or int(row.get("prompt_tokens", 0) or 0)
    ttft = row.get("ttft_ms")

    if args.dry_run:
        write, warning = "not written (dry run)", None
    elif not args.write:
        write, warning = "not written (run without --write)", None
    else:
        write, warning = write_shot(shot, parsed, text, sidecars)
    if warning:
        job.st["warning"] = warning
    _record(out_fh, dict(
        base, catalogue={"text": parsed["text"], "scene": parsed["scene"],
                         "tags": parsed["tags"]},
        reply=text, served=served, outcome=row.get("outcome", "?"),
        prompt_tokens=prompt_toks, secs=round(dt, 2),
        ttft_ms=round(float(ttft), 1) if ttft else None,
        write=write, error=None))
    print(f"  {index}/{of} {base['photo']}  {dt:5.1f}s  "
          f"{caption_for(parsed) or '(no caption)'}  [{write}]",
          file=sys.stderr, flush=True)
    return "tagged"


def run(args):
    """The job. Returns the process exit code. Writes status.json throughout."""
    _stopping["now"] = False
    job = Job(args)
    try:
        win = parse_window(args.window)
    except ValueError as exc:
        job.set(state="failed", error=str(exc))
        print(f"FATAL: {exc}", file=sys.stderr)
        return 2
    why = _folder_problem(args.path)
    if not why:
        args.path = os.path.abspath(os.path.expanduser(args.path))
        job.st["path"] = args.path
        why = _folder_problem(args.path)
    if why:
        job.set(state="failed", error=why)
        print(f"FATAL: {why}", file=sys.stderr)
        return 2
    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        job.set(state="failed", error="Pillow is not installed: pip install "
                "'faxl[photos]'")
        return 2

    shots = find_shots(args.path, args.recursive)
    done = already_done()
    pending = [s for s in shots if s["path"] not in done]
    if args.count:
        # --count is photographs to catalogue THIS RUN. Raw-alone shots cost
        # nothing to report, so they ride along rather than eat the budget.
        picked, n = [], 0
        for s in pending:
            if n >= args.count:
                break
            picked.append(s)
            if not s.get("error"):
                n += 1
        pending = picked
    job.set(state="running", target=len(pending),
            already_done=sum(1 for s in shots if s["path"] in done))
    print(f"[folder] {len(shots)} photograph(s) in {args.path}, "
          f"{len(pending)} to do; faxl at {args.endpoint}"
          + (" [dry run: nothing will be written]" if args.dry_run else ""),
          file=sys.stderr, flush=True)

    # CAN THE MODEL SEE? Asked once, before any photograph is sent: a
    # text-only model refuses every picture, and a run of 2,000 refusals is
    # 2,000 error rows for one fact. A proxy mid-restart is waited for.
    if any(not s.get("error") for s in pending):
        for attempt in range(1, MAX_TRIES + 1):
            try:
                vision = model_reads_pictures(args.endpoint)
                break
            except NotNow as nn:
                if attempt == MAX_TRIES or _stopping["now"]:
                    job.set(state="failed", error=nn.reason)
                    print(f"FATAL: {nn.reason}", file=sys.stderr)
                    return 2
                job.set(state="waiting", reason=nn.reason)
                _wait(nn.wait)
        if vision is False:
            msg = "the model faxl is serving cannot read pictures"
            job.set(state="failed", error=msg)
            print(f"FATAL: {msg}. Nothing was sent.", file=sys.stderr)
            return 2

    sidecars = {}
    os.makedirs(job_dir(), exist_ok=True)
    with open(catalogue_path(), "a", buffering=1) as out_fh:
        for i, shot in enumerate(pending, 1):
            # THE WINDOW IS CHECKED BETWEEN PHOTOGRAPHS, and slept through in
            # short steps so a stop is honoured at once, not after the night.
            while not inside_window(win) and not _stopping["now"]:
                job.set(state="waiting",
                        reason=f"outside the window {args.window}")
                _wait(60)
            if _stopping["now"]:
                break
            if job.st["state"] != "running":
                job.set(state="running", reason=None)
            res = _tag_one(shot, args, job, out_fh, sidecars, i, len(pending))
            if res == "tagged":
                job.st["tagged"] += 1
            elif res == "failed":
                job.st["failed"] += 1
            elif res.startswith("fatal:"):
                job.st["failed"] += 1
                job.set(state="failed", error=res[len("fatal:"):])
                _clear_current()
                return 2
            if res == "stopped" or _stopping["now"]:
                break
            job.set()
    _clear_current()
    sweep_previews()
    state = "stopped" if _stopping["now"] else "done"
    job.set(state=state, reason=None)
    print(f"[folder] {state}: {job.st['tagged']} catalogued, "
          f"{job.st['failed']} failed -> {catalogue_path()}", file=sys.stderr)
    return 0


def _clear_current():
    """No photograph is in front of the model any more: a stale marker would
    pin the last one on the page for ever."""
    try:
        os.remove(current_path())
    except OSError:
        pass


def build_parser():
    ap = argparse.ArgumentParser(
        prog="python -m faxl.engine.faxl_folder_tag",
        description="Catalogue a folder of photographs with the model faxl "
                    "is serving: EXIF into JPEGs, XMP sidecars for the rest.")
    ap.add_argument("--path", required=True, help="the folder of photographs")
    ap.add_argument("--recursive", action="store_true",
                    help="include sub-folders (a card's DCIM/100CANON ...)")
    ap.add_argument("--count", type=int, default=0,
                    help="photographs to catalogue THIS RUN (0 = all); ones "
                         "already done do not count towards it")
    ap.add_argument("--endpoint", default=os.environ.get(
        "FAXL_ENDPOINT", "http://127.0.0.1:8767"))
    ap.add_argument("--window", default="",
                    help="only run between these times, e.g. 23:00-07:00")
    ap.add_argument("--write", action="store_true",
                    help="write the tags: EXIF into JPEGs, .xmp sidecars for "
                         "everything else, catalogue.csv in each folder")
    ap.add_argument("--dry-run", action="store_true",
                    help="ask the model, write nothing outside faxl's job "
                         "directory (overrides --write)")
    ap.add_argument("--timeout", type=float, default=600.0,
                    help="seconds to wait for one photograph's answer")
    return ap


def main(argv=None):
    args = build_parser().parse_args(argv)
    # STOP IS SIGTERM (the console's Stop button), honoured between
    # photographs: the one in flight finishes and is recorded, so nothing is
    # lost and the proxy is not left generating for nobody. Previous handlers
    # are put back so main() can be called in-process (the tests do).
    old = {}
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            old[sig] = signal.signal(sig, _note_stop)
        except ValueError:            # not the main thread
            pass
    try:
        return run(args)
    finally:
        for sig, h in old.items():
            signal.signal(sig, h)


if __name__ == "__main__":
    sys.exit(main())

"""ns_identity.py — the canonical namespace identity (M0, master plan v4.1).

ONE namespace contract on every record type (register rows 17/76/130;
review ER2/ER10/F1/F9): the canonical 7-tuple, its cryptographic digest,
and the 64-bit index prefix derived from it.

    tuple  = (tenant_domain, model, revision, backend, dtype,
              cache_format, config_hash)          # tenant FIRST
    bytes  = RFC 8785 (JCS) canonical JSON of {field: value} in UTF-8
    digest = SHA-256(bytes)                       # 32 raw bytes
    ns_hash = int.from_bytes(digest[:8], "big")   # INDEX PREFIX ONLY

ns_hash is never the resume authority: every key/filter/join/group uses
the composite (ns_hash, ns_digest), and the canonical tuple is verified
before ANY state load (`verify_before_load`).

RFC 8785 compliance, stated precisely: JCS in full generality requires
ES6 number serialization. This module RESTRICTS the domain to flat
objects whose seven fixed ASCII keys map to non-empty NFC-normalized
strings. On that domain, Python's
    json.dumps(obj, sort_keys=True, separators=(",", ":"),
               ensure_ascii=False).encode("utf-8")
is byte-for-byte RFC 8785: string escaping matches JCS (\" \\ and the
two-char escapes \b \t \n \f \r, other controls as \\u00XX lowercase-
hex-free, all else literal), ASCII keys sort identically under UTF-16
code-unit order, and no numbers occur. The golden vectors in
test_ns_identity.py (including a non-ASCII value and an
escaping-required value) are the cross-language contract.
"""
import hashlib
import json
import unicodedata
from dataclasses import dataclass, fields

FIELDS = ("tenant_domain", "model", "revision", "backend", "dtype",
          "cache_format", "config_hash")


class NamespaceError(ValueError):
    """Malformed namespace identity, or a verify-before-load mismatch."""


@dataclass(frozen=True)
class NamespaceIdentity:
    tenant_domain: str
    model: str
    revision: str
    backend: str
    dtype: str
    cache_format: str
    config_hash: str

    def __post_init__(self):
        for f in fields(self):
            v = getattr(self, f.name)
            if not isinstance(v, str) or not v:
                raise NamespaceError(
                    f"namespace field {f.name!r} must be a non-empty string, "
                    f"got {v!r}")
            n = unicodedata.normalize("NFC", v)
            if n != v:
                # normalize rather than reject: the CANONICAL bytes are NFC,
                # so a non-NFC input silently naming a different namespace is
                # the failure mode this guards against.
                object.__setattr__(self, f.name, n)

    def as_dict(self):
        return {f: getattr(self, f) for f in FIELDS}

    def canonical_bytes(self):
        """RFC 8785 bytes on the restricted (string-valued) domain."""
        return json.dumps(self.as_dict(), sort_keys=True,
                          separators=(",", ":"),
                          ensure_ascii=False).encode("utf-8")

    def digest(self):
        """32 raw SHA-256 bytes — ns_digest, stored FixedString(32)."""
        return hashlib.sha256(self.canonical_bytes()).digest()

    def digest_hex(self):
        return self.digest().hex()

    def ns_hash(self):
        """First 8 digest bytes, big-endian — an INDEX PREFIX, never the
        resume authority (ER2/ER10)."""
        return int.from_bytes(self.digest()[:8], "big")


def from_dict(d):
    """Build from a stored tuple dict; unknown/missing keys are hard errors
    (a record whose identity cannot be reconstructed must never load)."""
    if set(d.keys()) != set(FIELDS):
        raise NamespaceError(
            f"namespace dict keys {sorted(d.keys())} != required "
            f"{sorted(FIELDS)}")
    return NamespaceIdentity(**{k: d[k] for k in FIELDS})


def verify_before_load(expected: NamespaceIdentity, stored_tuple: dict,
                       stored_digest_hex: str):
    """The verify-before-load check (ER2): the stored record's canonical
    tuple AND digest must both match the expected namespace exactly.
    Raises NamespaceError on any mismatch — the caller treats it as a
    refused load (fall cold), never a soft continue. Returns the verified
    NamespaceIdentity on success."""
    stored = from_dict(stored_tuple)
    if stored.as_dict() != expected.as_dict():
        diff = {k: (expected.as_dict()[k], stored.as_dict()[k])
                for k in FIELDS
                if expected.as_dict()[k] != stored.as_dict()[k]}
        raise NamespaceError(
            f"namespace tuple mismatch (expected, stored): {diff} — refusing "
            f"to load state across namespaces")
    if stored.digest_hex() != stored_digest_hex:
        raise NamespaceError(
            f"namespace digest mismatch: recomputed "
            f"{stored.digest_hex()} != stored {stored_digest_hex} — record "
            f"corrupt or forged; refusing to load")
    if stored.digest_hex() != expected.digest_hex():
        raise NamespaceError(
            "namespace digest mismatch vs expected — refusing to load")
    return stored

# Vendored engine module (faxl_panel_exo.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""The exo cluster page: `/console/exo` for a person (plan:
console-dashboard-rebuild, "The exo page").

exo is the backend a model too large for one Mac runs on -- many machines
running one model, with faxl in front: the proxy forwards to exo on :52415 and
its prefill server answers exo's runner for a hit and stores the state after a
cold prefill. The owner calls it the product's most important feature, so it
has a page, in the panel's own shell (stylesheet, top bar, drawers and the
`window.faxl` runtime are imported from faxl_panel, never copied):

  top      exo running or not, endpoint, version (when exo says), whether faxl
           is in front of it, the backend switch, start / stop exo
  left     the cluster: nodes with chip, memory, addresses and the shards they
           hold; totals online; faxl's prefill server
  centre   exo's catalogue: family, quantization, hybrid or attention, vision,
           thinking, multi-node, context, size, on disk per node, built in or
           added, serving; download (bars per node) and serve; add a model
  right    the network: links between nodes as exo reports them, where the
           serving model's shards sit, and exo's log

Everything is live from GET /api/exo (3 s). HONESTY: only values exo reports
or faxl measures; null renders "—"; when exo does not expose a fact the card
says so once, not in every row.

  render_exo(state, cluster, nonce=None) -> str
      state    the /api/state payload (the top bar reads it)
      cluster  the /api/exo payload (this page reads it)
"""

from faxl.engine import faxl_panel as _P


def render_exo(state, cluster, nonce=None):
    """The whole exo page as one string. Both payloads may be empty or
    partial: every value is filled by the script, "—" until then."""
    blob = ('<script type="application/json" id="faxl-exo">'
            + _P.state_json(cluster if isinstance(cluster, dict) else {})
            + '</script>')
    return _P.render_shell(state, title="faxl — exo cluster",
                           main_html=EXO_HTML + blob, page_css=EXO_CSS,
                           page_js=EXO_JS, here="exo", nonce=nonce,
                           app_id="app-exo")


# --------------------------------------------------------------------------
# CSS: the panel's tokens and classes, plus this page's grid.
# --------------------------------------------------------------------------
EXO_CSS = r"""
#app-exo{display:grid;min-width:1280px;max-width:100vw;height:100vh;
  grid-template-columns:340px minmax(0,1fr) clamp(400px,27vw,500px);
  grid-template-rows:auto auto minmax(0,1fr);gap:var(--gap);padding:0 var(--gap) var(--gap)}
#x-status{grid-column:1/-1}
#x-left,#x-right{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:var(--gap)}
#x-centre{min-height:0;min-width:0;display:flex;flex-direction:column;gap:var(--gap)}
.xs-row{display:flex;align-items:center;gap:18px;flex-wrap:wrap}
.xs-title{display:flex;align-items:center;gap:8px;font:700 15px var(--sans)}
.xs-facts{display:flex;gap:18px;margin:0;flex-wrap:wrap}
.xs-facts div{display:flex;flex-direction:column;gap:1px;min-width:0}
.xs-facts dt{font-size:11px;color:var(--ink-2);text-transform:uppercase;letter-spacing:.06em;font-weight:700}
.xs-facts dd{margin:0;font-family:var(--mono);font-size:12.5px;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.xs-ctl{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.xs-warn{margin-top:8px;border:1px solid var(--warn);border-left-width:3px;border-radius:var(--radius);
  padding:6px 9px;font-size:12.5px;background:color-mix(in srgb,var(--warn) 9%,var(--panel))}
.xs-warn.bad{border-color:var(--bad);background:color-mix(in srgb,var(--bad) 8%,var(--panel))}
#x-notices{display:flex;flex-direction:column;gap:6px;margin-top:8px}
#x-notices:empty{display:none;margin:0}
.node{border:1px solid var(--line);border-radius:var(--radius);padding:7px 9px;margin:0 0 8px;background:var(--panel)}
.node-h{display:flex;align-items:center;gap:7px;margin:0 0 5px;min-width:0}
.node-h b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.node-h .mono{font-size:11px;color:var(--ink-2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.node .kv{font-size:12.5px}
.node .kv dd{overflow-wrap:anywhere}
.shard{font:12px var(--mono);color:var(--ink)}
#x-models{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;padding:0}
#x-models .card-h{padding:8px 12px 0;margin:0 0 6px;flex-wrap:wrap}
#xm-filter{width:190px;height:24px}
.xm-key{padding:0 12px 8px;font-size:12.5px;line-height:1.45}
.xm-key .hy{color:var(--ok);font-weight:600}
.xm-add{display:flex;gap:6px;align-items:center;padding:0 12px 8px;flex-wrap:wrap}
.xm-add input{width:320px}
table.cat{min-width:1020px;width:100%;border-collapse:separate;border-spacing:0;font-size:12.5px}
.cat thead th{position:sticky;top:0;z-index:1;background:var(--panel-2);text-align:left;
  font:600 11px var(--sans);color:var(--ink-2);text-transform:uppercase;letter-spacing:.05em;
  padding:0;border-bottom:1px solid var(--line-2);white-space:nowrap}
.cat thead th button{all:unset;display:block;padding:6px 8px;cursor:pointer;box-sizing:border-box;width:100%}
.cat thead th button:focus-visible{outline:2px solid var(--focus);outline-offset:-2px}
.cat thead th[aria-sort="ascending"] button::after{content:" \25B2"}
.cat thead th[aria-sort="descending"] button::after{content:" \25BC"}
.cat td{padding:4px 8px;border-bottom:1px solid var(--line);white-space:nowrap;vertical-align:top}
.cat td.id{max-width:340px;overflow:hidden;text-overflow:ellipsis}
.cat td.num{text-align:right;font-family:var(--mono);font-variant-numeric:tabular-nums}
.cat td.tick{text-align:center}
.cat tr.hy td.id,.cat tr.hy td.arch{color:var(--ok);font-weight:600}
.cat tr.unk td.arch{color:var(--ink-2);font-style:italic}
.cat tr.serving{background:color-mix(in srgb,var(--teal) 12%,transparent)}
.cat td.act{min-width:170px}
.pn{display:flex;align-items:center;gap:6px;margin:1px 0;font:11.5px var(--mono)}
.pn .bar{flex:1;min-width:60px}
.pn .who{max-width:90px;overflow:hidden;text-overflow:ellipsis}
.xm-empty{padding:28px 16px;color:var(--ink-2);text-align:center}
table.lk{width:100%;border-collapse:collapse;font-size:12.5px}
.lk th{text-align:left;color:var(--ink-2);font-weight:600;font-size:11.5px;padding:3px 6px;border-bottom:1px solid var(--line-2)}
.lk td{padding:3px 6px;border-bottom:1px solid var(--line);font-family:var(--mono);font-variant-numeric:tabular-nums;
  overflow-wrap:anywhere}
.pl-h{font-weight:600;margin:6px 0 3px;overflow-wrap:anywhere}
#x-log{flex:1 1 auto;min-height:220px;display:flex;flex-direction:column}
#xl-pre{flex:1 1 auto;min-height:0;overflow:auto;margin:0;padding:6px 8px;background:var(--panel-2);
  border:1px solid var(--line);border-radius:var(--radius);font:11.5px/1.4 var(--mono);white-space:pre-wrap;
  overflow-wrap:anywhere}
"""


# --------------------------------------------------------------------------
# Markup: static; every value is filled from the /api/exo payload.
# --------------------------------------------------------------------------
EXO_HTML = r"""<section class="card" id="x-status" aria-labelledby="xh-status">
  <div class="xs-row">
    <h2 class="xs-title" id="xh-status"><span class="lamp" id="xs-lamp" aria-hidden="true"></span><span id="xs-state">exo &#8212;</span></h2>
    <dl class="xs-facts">
      <div><dt>endpoint</dt><dd id="xs-endpoint">&#8212;</dd></div>
      <div><dt>version</dt><dd id="xs-version">&#8212;</dd></div>
      <div><dt>serving backend</dt><dd id="xs-backend">&#8212;</dd></div>
      <div><dt>faxl in front</dt><dd id="xs-front">&#8212;</dd></div>
      <div><dt>cluster state from</dt><dd id="xs-stateep">&#8212;</dd></div>
    </dl>
    <span class="spacer"></span>
    <div class="xs-ctl" role="group" aria-label="exo controls">
      <button type="button" class="btn" id="xs-use-exo" hidden>switch to exo cluster</button>
      <button type="button" class="btn btn-quiet" id="xs-use-mlx" hidden>back to this Mac (MLX)</button>
      <button type="button" class="btn" id="xs-start" hidden>start exo</button>
      <button type="button" class="btn btn-quiet" id="xs-stop" hidden>stop exo</button>
    </div>
  </div>
  <p class="xs-warn" id="xs-warn" role="status" hidden></p>
  <p class="note" id="xs-note" hidden></p>
  <div id="x-notices"></div>
</section>
<aside id="x-left" aria-label="the cluster">
  <section class="card" id="x-totals" aria-labelledby="xh-totals">
    <div class="card-h"><h2 id="xh-totals">Cluster</h2><span class="aux" id="xt-upd"></span></div>
    <dl class="kv">
      <dt>nodes online</dt><dd id="xt-online">&#8212;</dd>
      <dt>RAM online</dt><dd id="xt-ram">&#8212;</dd>
      <dt>RAM free online</dt><dd id="xt-free">&#8212;</dd>
      <dt title="what one model may take: RAM online x fit_ratio -- the fit rule the serve buttons follow">usable for a model</dt><dd id="xt-usable">&#8212;</dd>
    </dl>
    <div class="meter" style="margin-top:6px"><div class="bar gauge" aria-hidden="true"><i id="xt-bar"></i></div><span class="mono" id="xt-pct">&#8212;</span></div>
    <p class="note" id="xt-note" hidden></p>
  </section>
  <section class="card" id="x-nodes-card" aria-labelledby="xh-nodes">
    <div class="card-h"><h2 id="xh-nodes">Nodes</h2><span class="aux" id="xn-count"></span></div>
    <div id="x-nodes"></div>
    <p class="note" id="xn-note" hidden></p>
  </section>
  <section class="card" id="x-prefill" aria-labelledby="xh-prefill">
    <div class="card-h"><h2 id="xh-prefill">Prefill server</h2><span class="aux">the thread exo dials</span></div>
    <dl class="kv">
      <dt>endpoint</dt><dd id="xp-ep" class="wrap">&#8212;</dd>
      <dt>published by pid</dt><dd id="xp-pid">&#8212;</dd>
      <dt>requests</dt><dd id="xp-req">&#8212;</dd>
      <dt>hits</dt><dd id="xp-hits">&#8212;</dd>
      <dt>states stored</dt><dd id="xp-stored">&#8212;</dd>
    </dl>
    <p class="note" id="xp-note"></p>
  </section>
</aside>
<main id="x-centre">
  <section class="card" id="x-models" aria-labelledby="xh-models">
    <div class="card-h"><h2 id="xh-models">Models on the cluster</h2>
      <span class="aux" id="xm-count"></span>
      <span class="spacer"></span>
      <label class="aux" for="xm-filter">filter</label>
      <input type="search" id="xm-filter" placeholder="name, family, hybrid, on disk" autocomplete="off" spellcheck="false">
    </div>
    <p class="xm-key"><span class="hy">&#9632; <span id="xm-nhy">&#8212;</span> hybrid / recurrent &#8212; only faxl caches these correctly.</span>
      Mamba, SSM and linear-attention models keep one rolled-up recurrent tensor instead of a KV cache.
      Cached without handling that, they return a different answer &#8212; plausible, not an error, so nothing
      tells you it happened. faxl stores and replays the real state, and the output is byte-identical to running
      uncached. <span class="muted">&#9632; <span id="xm-nkv">&#8212;</span> conventional attention &#8212; standard KV cache, cached correctly everywhere.</span></p>
    <div class="xm-add">
      <label class="aux" for="xm-repo">Add a HuggingFace model</label>
      <input type="text" id="xm-repo" placeholder="mlx-community/Qwen3.5-35B-A3B-8bit" autocomplete="off" spellcheck="false">
      <button type="button" class="btn btn-quiet" id="xm-add">add to exo&#8217;s catalogue</button>
      <span class="aux">fetches the model&#8217;s card, no weights</span>
    </div>
    <div class="table-wrap" id="xm-wrap">
      <table class="cat" id="xm-table">
        <thead><tr>
          <th scope="col" data-sort="id"><button type="button">model</button></th>
          <th scope="col" data-sort="arch"><button type="button">arch</button></th>
          <th scope="col" data-sort="family"><button type="button">family</button></th>
          <th scope="col" data-sort="quantization"><button type="button">quant</button></th>
          <th scope="col" data-sort="size"><button type="button">size</button></th>
          <th scope="col" data-sort="context"><button type="button">context</button></th>
          <th scope="col" data-sort="vision"><button type="button">vision</button></th>
          <th scope="col" data-sort="thinking"><button type="button">thinking</button></th>
          <th scope="col" data-sort="multi_node"><button type="button">multi-node</button></th>
          <th scope="col" data-sort="custom"><button type="button">card</button></th>
          <th scope="col" data-sort="disk"><button type="button">on disk</button></th>
          <th scope="col" data-sort="serving"><button type="button">serve</button></th>
        </tr></thead>
        <tbody id="xm-body"></tbody>
      </table>
      <div class="xm-empty" id="xm-empty" hidden></div>
    </div>
  </section>
</main>
<aside id="x-right" aria-label="the network">
  <section class="card" id="x-links" aria-labelledby="xh-links">
    <div class="card-h"><h2 id="xh-links">Network</h2><span class="aux">links between nodes, as exo reports them</span></div>
    <div id="xk-body"></div>
    <p class="note" id="xk-note" hidden></p>
  </section>
  <section class="card" id="x-place" aria-labelledby="xh-place">
    <div class="card-h"><h2 id="xh-place">Placement</h2><span class="aux">where the model&#8217;s shards sit</span></div>
    <div id="xq-body"></div>
    <p class="note" id="xq-note" hidden></p>
  </section>
  <section class="card" id="x-log" aria-labelledby="xh-log">
    <div class="card-h"><h2 id="xh-log">exo log</h2><span class="aux mono" id="xl-path"></span></div>
    <pre id="xl-pre" tabindex="0" aria-label="the last 60 lines of exo's log"></pre>
  </section>
</aside>"""


# --------------------------------------------------------------------------
# The page's script. Runs after the shell's runtime (window.faxl); polls
# /api/exo, /api/models/progress and /api/exo/log on the shell's 3 s loop.
# --------------------------------------------------------------------------
EXO_JS = r"""
(function () {
  "use strict";
  var F = window.faxl;
  if (!F || !F.util) return;
  var U = F.util, fmt = F.fmt, $ = U.$, el = U.el, get = U.get, setText = U.setText,
      isNum = U.isNum, DASH = U.DASH, shortModel = U.shortModel;

  function readBlob() {
    var n = $("faxl-exo");
    try { var d = JSON.parse((n && n.textContent) || "{}"); return d && typeof d === "object" ? d : {}; }
    catch (e) { return {}; }
  }
  var X = readBlob(), progress = {}, dlStarted = 0;
  function nodeName(id) {
    var ns = X.nodes || [];
    for (var i = 0; i < ns.length; i++) if (ns[i] && ns[i].id === id) return ns[i].name || shortId(id);
    return shortId(id);
  }
  function shortId(id) { id = String(id == null ? "" : id); return id.length > 14 ? id.slice(0, 6) + "…" + id.slice(-5) : id; }
  function gb(b) { return isNum(b) ? fmt.bytes(b) : DASH; }
  function clear(e) { while (e && e.firstChild) e.removeChild(e.firstChild); }
  function note(id, text) { var n = $(id); if (!n) return; n.textContent = text || ""; n.hidden = !text; }
  // Which backend is the cluster, and which runs on this Mac, is the
  // descriptors' to say (F.be over X.backend.available), never a name.
  function servingAv() { return F.be.find(X, get(X, "exo.serving_backend")); }
  function onExo() { return F.be.isCluster(servingAv()); }
  function clusterAv() { return F.be.cluster(X); }
  function localAv() { return F.be.local(X); }
  function avLabel(a, dflt) { return a ? (a.label || a.name) : dflt; }

  // ---- top: exo status and its controls -----------------------------------
  function renderStatus() {
    var ex = X.exo || {};
    var run = ex.running;
    $("xs-lamp").className = "lamp " + (run === true ? (ex.faxl_in_front ? "ok" : "warn") : run === false ? (onExo() ? "bad" : "") : "");
    setText("xs-state", run === true ? "exo is running" : run === false ? "exo is not running" : "exo " + DASH);
    setText("xs-endpoint", fmt.dash(ex.endpoint), ex.endpoint || "");
    setText("xs-version", ex.version ? ex.version : (run ? "not reported by exo" : DASH));
    var be = ex.serving_backend;
    setText("xs-backend", avLabel(servingAv(), fmt.dash(be)));
    setText("xs-front", ex.faxl_in_front === true ? "yes" : run === true ? "no" : DASH);
    setText("xs-stateep", ex.state_endpoint ? ex.state_endpoint : (run ? "not exposed" : DASH));
    var w = $("xs-warn");
    w.textContent = ex.warn || ""; w.hidden = !ex.warn;
    w.className = "xs-warn" + (onExo() && run === false ? " bad" : "");
    note("xs-note", ex.can_start === false && ex.note && !run ? "exo cannot be started from here: " + ex.note : "");
    // The top bar's restart button is disabled exactly while a restart or
    // switch is under way, or the proxy is not answering.
    var busy = !!($("px-restart") && $("px-restart").disabled);
    var exoAv = clusterAv(), mlxAv = localAv();
    var ue = $("xs-use-exo"), um = $("xs-use-mlx"), sa = $("xs-start"), so = $("xs-stop");
    if (!sure(ue)) { ue.hidden = onExo(); ue.disabled = !exoAv || exoAv.can_switch === false || busy;
      ue.title = exoAv && exoAv.note ? exoAv.note : "the proxy restarts onto exo, with faxl in front"; }
    if (!sure(um)) { um.hidden = !onExo(); um.disabled = !mlxAv || mlxAv.can_switch === false || busy;
      um.title = mlxAv && mlxAv.note ? mlxAv.note : "exo stops; the proxy restarts with the model in its own process"; }
    if (!sure(sa)) { sa.hidden = !(onExo() && run === false); sa.disabled = ex.can_start === false || busy; }
    if (!sure(so)) { so.hidden = run !== true; so.disabled = busy; }
    var box = $("x-notices"); clear(box);
    (X.notices || []).forEach(function (n) {
      if (!n) return;
      var c = el("div", "notice notice-" + String(n.level || "info").replace(/[^a-z]/g, ""));
      c.appendChild(el("b", null, n.title || ""));
      if (n.text) c.appendChild(document.createTextNode(" " + n.text));
      box.appendChild(c);
    });
  }
  function sure(btn) { return btn && btn.parentNode && btn.parentNode.querySelector(".sure") && btn.hidden; }
  // Every confirm NAMES THE MODEL it comes up on, and its size: each backend
  // comes back on its own last model, never the other one's.

  function comesUpOn(a) {
    if (!a || !a.model) return "";
    return " comes up on " + shortModel(a.model) + (isNum(a.size_bytes) ? " (" + fmt.gb(a.size_bytes) + ")" : "") +
      (a.note && a.note !== "serving now" ? " · " + a.note : "");
  }
  F.twoStep($("xs-use-exo"), function () {
    var a = clusterAv();
    return "switch to " + avLabel(a, "the cluster") + "?" + (comesUpOn(a) || " the proxy restarts onto it") +
           " — about a minute; the cache store survives";
  }, function () { var a = clusterAv(); if (a) F.switchBackend(a.name).catch(function () {}); });
  F.twoStep($("xs-use-mlx"), function () {
    var a = localAv();
    return "switch to " + avLabel(a, "this Mac") + "?" + (comesUpOn(a) || " the proxy restarts with the model in its own process") +
           " · exo stops";
  }, function () { var a = localAv(); if (a) F.switchBackend(a.name).catch(function () {}); });
  F.twoStep($("xs-start"), function () {
    return "start exo?" + (comesUpOn(clusterAv()) || "") +
      " — the proxy restarts with exo behind it and faxl in front, about a minute";
  },
    function () {
      F.api("/api/backend/power", {method: "POST", body: {state: "on"}}).then(function () {
        F.toast("starting exo, with faxl in front — the proxy restarts", "info");
      }, function (e) { if (!e.network) F.toast("exo start refused: " + e.message, "bad"); });
    });
  F.twoStep($("xs-stop"), function () {
    return onExo() ? "stop exo? nothing will serve until it is started again — switch to this Mac (MLX) to keep serving"
                   : "stop exo? it is running without faxl in front of it, so nothing is using it";
  }, function () {
    F.api("/api/backend/power", {method: "POST", body: {state: "off"}}).then(function () {
      F.toast("stopping exo…", "info"); setTimeout(pollExo, 1500);
    }, function (e) { F.toast("exo stop refused: " + e.message, "bad"); });
  });

  // ---- left: the cluster --------------------------------------------------
  function renderTotals() {
    var t = X.totals || {}, ex = X.exposes || {};
    var known = t.nodes_known, on = t.nodes_online;
    setText("xt-online", isNum(on) ? on + " of " + known : (isNum(known) ? DASH + " of " + known + " known" : DASH));
    setText("xt-ram", gb(t.ram_total));
    setText("xt-free", gb(t.ram_free));
    setText("xt-usable", isNum(t.usable_for_model)
      ? fmt.gb(t.usable_for_model) + (isNum(t.fit_ratio) ? " (" + Math.round(t.fit_ratio * 100) + "% of RAM)" : "")
      : DASH);
    var f = (isNum(t.ram_total) && isNum(t.ram_free) && t.ram_total > 0) ? 1 - t.ram_free / t.ram_total : null;
    $("xt-bar").style.width = f == null ? "0" : Math.min(100, f * 100).toFixed(1) + "%";
    setText("xt-pct", f == null ? DASH : fmt.pct(f) + " used");
    var msg = "";
    if (X.exo && X.exo.running && !ex.memory) msg = "exo does not report its nodes' memory, so the totals are unknown.";
    else if (isNum(t.ram_nodes_reporting) && isNum(known) && t.ram_nodes_reporting < known)
      msg = "memory from " + t.ram_nodes_reporting + " of " + known + " nodes: the rest do not report it.";
    else if (!isNum(on) && X.exo && X.exo.running) msg = "exo does not say which nodes are reachable.";
    note("xt-note", msg);
  }
  var nodesSig = "";
  function renderNodes() {
    var ns = X.nodes, ex = X.exposes || {}, box = $("x-nodes");
    var sig = JSON.stringify([ns, ex]);
    if (sig === nodesSig) return;
    nodesSig = sig;
    clear(box);
    setText("xn-count", Array.isArray(ns) ? ns.length + (ns.length === 1 ? " node" : " nodes") : "");
    if (!Array.isArray(ns)) { note("xn-note", X.exo && X.exo.running === false ? "exo is not answering: no nodes to show." : "unknown"); return; }
    if (!ns.length) { note("xn-note", "exo reports no nodes."); return; }
    var missing = [];
    if (!ex.nodes) missing.push("name, chip or address");
    if (!ex.memory) missing.push("memory");
    note("xn-note", missing.length ? "exo does not report its nodes' " + missing.join(" or ") + "." : "");
    ns.forEach(function (n) {
      if (!n) return;
      var c = el("div", "node"), h = el("div", "node-h");
      var lamp = el("span", "lamp " + (n.reachable === true ? "ok" : n.reachable === false ? "bad" : ""));
      lamp.title = n.reachable === true ? "reachable" : n.reachable === false ? "not reachable" : "reachability not reported";
      h.appendChild(lamp);
      h.appendChild(el("b", null, n.name || shortId(n.id)));
      var idn = el("span", "mono", n.id); idn.title = n.id; h.appendChild(idn);
      c.appendChild(h);
      var dl = el("dl", "kv");
      function row(k, v) { dl.appendChild(el("dt", null, k)); dl.appendChild(el("dd", null, v)); }
      if (ex.nodes) { row("chip", fmt.dash(n.chip)); row("device", fmt.dash(n.device)); }
      if (ex.memory) {
        row("RAM", gb(n.ram_total));
        row("RAM free", gb(n.ram_free));
      }
      if (isNum(n.gpu_memory)) row("GPU memory", gb(n.gpu_memory));
      if (isNum(n.gpu_usage)) row("GPU busy", fmt.pct(n.gpu_usage));
      if (ex.nodes) row("address", (n.addresses && n.addresses.length) ? n.addresses.join(", ") : DASH);
      row("on disk", (n.on_disk && n.on_disk.length) ? n.on_disk.length + (n.on_disk.length === 1 ? " model" : " models") : "none");
      c.appendChild(dl);
      (n.shards || []).forEach(function (s) {
        c.appendChild(el("div", "shard", "▸ " + (shortModel(s.model) || DASH) + " · " + fmt.dash(s.kind) +
          " rank " + fmt.dash(s.rank) + "/" + fmt.dash(s.world) +
          (isNum(s.start_layer) ? " · layers " + s.start_layer + "–" + fmt.dash(s.end_layer) + (isNum(s.n_layers) ? " of " + s.n_layers : "") : "") +
          (s.runner_status ? " · " + s.runner_status : "")));
      });
      if (ex.placement && !(n.shards || []).length) c.appendChild(el("div", "shard muted", "holds no shards"));
      box.appendChild(c);
    });
  }
  function renderPrefill() {
    var p = X.prefill || {};
    setText("xp-ep", fmt.dash(p.endpoint), p.file || "");
    setText("xp-pid", isNum(p.pid) ? p.pid + (p.pid_alive === true ? " (running)" : p.pid_alive === false ? " (gone)" : "") : DASH);
    setText("xp-req", fmt.int(p.requests));
    setText("xp-hits", isNum(p.hits) ? fmt.int(p.hits) + (isNum(p.hit_rate) ? " (" + fmt.pct(p.hit_rate) + ")" : "") : DASH);
    setText("xp-stored", fmt.int(p.stored));
    var msgs = [];
    if (!p.endpoint) msgs.push("No prefill endpoint published" + (p.file ? " in " + p.file : "") + " — the proxy writes it when it starts on exo.");
    if (!isNum(p.requests)) msgs.push("This proxy does not expose the prefill server's counts" + (onExo() ? "." : ": it is not running on exo."));
    note("xp-note", msgs.join(" "));
  }

  // ---- centre: exo's catalogue -------------------------------------------
  var sortKey = "default", sortDir = 1, catSig = "", progCells = {};
  try {
    var sk = localStorage.getItem("faxl.exo.sort");
    if (sk) { var sp = sk.split(":"); sortKey = sp[0]; sortDir = sp[1] === "-1" ? -1 : 1; }
  } catch (e) { /* storage blocked */ }
  function arch(m) { return m.hybrid === true ? "hybrid" : m.hybrid === false ? "attention" : "?"; }
  function sortVal(m, k) {
    switch (k) {
      case "arch": return arch(m);
      case "size": return isNum(m.size_bytes) ? m.size_bytes : (isNum(m.gb) ? m.gb * 1e9 : -1);
      case "context": return isNum(m.context) ? m.context : -1;
      case "disk": return (m.on_disk_nodes || []).length + (m.on_disk ? 0.5 : 0);
      case "serving": return m.serving ? 2 : m.download ? 1 : 0;
      case "vision": case "thinking": case "multi_node": case "custom": return m[k] ? 1 : 0;
      default: return String(m[k] == null ? "" : m[k]).toLowerCase();
    }
  }
  function sorted(rows) {
    var r = rows.slice();
    if (sortKey === "default") return r;   // the server's order: serving, on disk, hybrid first
    r.sort(function (a, b) {
      var x = sortVal(a, sortKey), y = sortVal(b, sortKey);
      return (x < y ? -1 : x > y ? 1 : 0) * sortDir;
    });
    return r;
  }
  function tick(v) {
    var td = el("td", "tick", v === true ? "✓" : v === false ? "·" : DASH);
    td.setAttribute("aria-label", v === true ? "yes" : v === false ? "no" : "unknown");
    return td;
  }
  function matches(m, q) {
    if (!q.length) return true;
    var hay = [m.id, m.family, m.quantization, arch(m), m.custom ? "added here" : "built in",
               m.on_disk ? "on disk" : "", m.serving ? "serving" : "", m.vision ? "vision" : "",
               m.thinking ? "thinking" : "", m.multi_node ? "multi-node" : ""].join(" ").toLowerCase();
    return q.every(function (w) { return hay.indexOf(w) >= 0; });
  }
  function diskCell(m) {
    var td = el("td"), nodes = m.on_disk_nodes || [], total = (X.nodes || []).length;
    if (nodes.length) {
      td.textContent = total ? nodes.length + " of " + total + " node" + (total === 1 ? "" : "s") : nodes.length + " node(s)";
      td.title = nodes.map(nodeName).join(", ");
    } else td.textContent = m.on_disk === false ? "no" : m.on_disk === true ? "yes" : DASH;
    return td;
  }
  function actCell(m) {
    var td = el("td", "act");
    if (m.serving) { td.appendChild(el("span", "pill pill-ok", "serving")); return td; }
    var pc = el("div"); progCells[m.id] = pc; td.appendChild(pc);
    fillProgress(pc, m.id);
    if (m.download || progress[m.id]) return td;
    var wrap = el("span", "row");
    if (m.on_disk === true && m.fits === false) {
      // The fit rule: the server refuses (409) a model the cluster cannot
      // hold; the button says so, with the server's reason, before a click.
      var nb = el("button", "btn", "serve"); nb.type = "button";
      nb.disabled = true; nb.title = m.fit_reason || "does not fit";
      nb.setAttribute("data-fit", "no");
      wrap.appendChild(nb);
      wrap.appendChild(el("span", "muted", m.fit_reason || "does not fit"));
    } else if (m.on_disk === true) {
      var b = el("button", "btn", "serve"); b.type = "button";
      b.title = onExo() ? "restart the proxy on exo with this model" : "switch the backend to exo cluster with this model";
      wrap.appendChild(b);
      F.twoStep(b, function () {
        return (onExo() ? "serve " : "switch to exo cluster and serve ") + shortModel(m.id) +
          "? the proxy restarts onto exo with it — about a minute; the cache store survives";
      }, function () {
        if (onExo()) F.restartModel(m.id).catch(function () {});
        else { var a = clusterAv(); if (a) F.switchBackend(a.name, m.id).catch(function () {}); }
      });
    } else {
      var d = el("button", "btn btn-quiet", "download"); d.type = "button";
      if (!onExo()) { d.disabled = true; d.title = "switch the backend to exo cluster first, so faxl is in front of what it downloads and serves"; }
      wrap.appendChild(d);
      F.twoStep(d, function () {
        return "download " + shortModel(m.id) + (isNum(m.size_bytes) ? " (" + fmt.bytes(m.size_bytes) + ")" : "") +
          " onto the cluster? exo places it on its nodes and pulls the weights in the background";
      }, function () {
        dlStarted = Date.now();
        F.api("/api/models/download", {method: "POST", body: {model_id: m.id}}).then(function (r) {
          F.toast(r && r.already ? shortModel(m.id) + " is already on disk" : "downloading " + shortModel(m.id) + " in the background", "info");
          pollProgress(); pollExo();
        }, function (e) { F.toast("download refused: " + e.message, "bad"); });
      });
    }
    td.appendChild(wrap);
    return td;
  }
  function fillProgress(box, id) {
    if (!box) return;
    clear(box);
    var p = progress[id], per = p && Array.isArray(p.per_node) && p.per_node.length ? p.per_node : null;
    if (!p) {
      var m = null; (X.models || []).forEach(function (x) { if (x && x.id === id) m = x; });
      p = m && m.download; per = p && Array.isArray(p.per_node) && p.per_node.length ? p.per_node : null;
    }
    if (!p) return;
    var lines = per || [{node: null, percent: p.percent, gb: p.gb, gb_done: p.gb_done}];
    lines.forEach(function (x) {
      var row = el("div", "pn"), pct = isNum(x.percent) ? Math.max(0, Math.min(100, x.percent)) : null;
      var who = el("span", "who", x.node ? nodeName(x.node) : "all nodes"); who.title = x.node || "";
      var bar = el("div", "bar"), fill = el("i");
      bar.setAttribute("role", "progressbar");
      bar.setAttribute("aria-label", "downloading " + id + (x.node ? " on " + nodeName(x.node) : ""));
      if (pct != null) bar.setAttribute("aria-valuenow", String(pct));
      fill.style.width = pct == null ? "0" : pct.toFixed(1) + "%";
      bar.appendChild(fill);
      row.appendChild(who); row.appendChild(bar);
      row.appendChild(el("span", null, (pct == null ? DASH : pct.toFixed(1) + "%") + (isNum(x.gb) ? " of " + x.gb + " GB" : "")));
      box.appendChild(row);
    });
  }
  function renderModels(force) {
    var ms = X.models, body = $("xm-body"), empty = $("xm-empty");
    var q = String($("xm-filter").value || "").toLowerCase().split(/\s+/).filter(Boolean);
    var busy = document.activeElement && body.contains(document.activeElement);
    var anySure = !!body.querySelector(".sure");
    var sig = JSON.stringify([ms && ms.map(function (m) { return [m.id, m.on_disk, m.on_disk_nodes, m.serving, !!m.download, m.custom, m.gb, m.fits, m.fit_reason]; }),
                              q, sortKey, sortDir, get(X, "exo.serving_backend"), (X.nodes || []).length, Object.keys(progress).sort()]);
    if (!force && (sig === catSig || anySure || busy)) {
      Object.keys(progCells).forEach(function (id) { fillProgress(progCells[id], id); });
      return;
    }
    catSig = sig;
    clear(body); progCells = {};
    Array.prototype.forEach.call(document.querySelectorAll("#xm-table thead th"), function (th) {
      var k = th.getAttribute("data-sort");
      if (k === sortKey) th.setAttribute("aria-sort", sortDir > 0 ? "ascending" : "descending");
      else th.removeAttribute("aria-sort");
    });
    if (!Array.isArray(ms)) {
      setText("xm-count", ""); setText("xm-nhy", DASH); setText("xm-nkv", DASH);
      empty.textContent = X.exo && X.exo.running === false
        ? "exo is not answering, and the catalogue is exo's. " + (onExo() ? "Start exo above." : "Switch the backend to exo cluster to see and serve its models.")
        : "loading exo's catalogue…";
      empty.hidden = false;
      return;
    }
    var hy = ms.filter(function (m) { return m && m.hybrid === true; }).length;
    setText("xm-nhy", String(hy)); setText("xm-nkv", String(ms.length - hy));
    var shown = 0;
    sorted(ms).forEach(function (m) {
      if (!m || !m.id || !matches(m, q)) return;
      shown++;
      var tr = el("tr", (m.hybrid === true ? "hy" : m.hybrid == null ? "unk" : "kv") + (m.serving ? " serving" : ""));
      var idc = el("td", "id", m.id); idc.title = m.id; tr.appendChild(idc);
      tr.appendChild(el("td", "arch", arch(m)));
      tr.appendChild(el("td", null, m.family || DASH));
      tr.appendChild(el("td", null, m.quantization || DASH));
      tr.appendChild(el("td", "num", isNum(m.size_bytes) ? fmt.bytes(m.size_bytes) : (isNum(m.gb) && m.gb > 0 ? m.gb + " GB" : DASH)));
      tr.appendChild(el("td", "num", isNum(m.context) && m.context > 0 ? Math.round(m.context / 1024) + "k" : DASH));
      tr.appendChild(tick(m.vision)); tr.appendChild(tick(m.thinking)); tr.appendChild(tick(m.multi_node));
      tr.appendChild(el("td", null, m.custom ? "added here" : "built in"));
      tr.appendChild(diskCell(m));
      tr.appendChild(actCell(m));
      body.appendChild(tr);
    });
    setText("xm-count", q.length ? shown + " of " + ms.length : ms.length + " models");
    empty.textContent = ms.length ? "no model matches the filter" : "exo's catalogue is empty";
    empty.hidden = shown > 0;
  }
  $("xm-filter").addEventListener("input", function () { renderModels(true); });
  document.querySelector("#xm-table thead").addEventListener("click", function (ev) {
    var th = ev.target && ev.target.closest ? ev.target.closest("th[data-sort]") : null;
    if (!th) return;
    var k = th.getAttribute("data-sort");
    if (sortKey === k) sortDir = -sortDir; else { sortKey = k; sortDir = 1; }
    try { localStorage.setItem("faxl.exo.sort", sortKey + ":" + sortDir); } catch (e) { /* ignore */ }
    renderModels(true);
  });
  $("xm-add").addEventListener("click", function () {
    var repo = String($("xm-repo").value || "").trim(), b = $("xm-add");
    if (!repo) { F.toast("type a HuggingFace repo id: org/name", "warn"); return; }
    b.disabled = true;
    F.api("/api/models/register", {method: "POST", body: {model_id: repo}}).then(function (d) {
      b.disabled = false; $("xm-repo").value = "";
      F.toast("added " + ((d && d.model && d.model.id) || repo) + " to exo's catalogue" +
              (d && d.model && isNum(d.model.gb) && d.model.gb > 0 ? " (" + d.model.gb + " GB)" : ""), "ok");
      pollExo();
    }, function (e) { b.disabled = false; F.toast("could not add " + repo + ": " + e.message, "bad"); });
  });

  // ---- right: network, placement, log -------------------------------------
  function renderLinks() {
    var box = $("xk-body"), L = X.links, ex = X.exposes || {};
    clear(box);
    if (!Array.isArray(L)) {
      note("xk-note", X.exo && X.exo.running ? "exo does not expose the links between its nodes (Thunderbolt, RDMA or ethernet)." :
                                                 "exo is not answering.");
      return;
    }
    if (!L.length) { note("xk-note", "exo reports no links between nodes" + ((X.nodes || []).length === 1 ? " — one node, nothing to link." : ".")); return; }
    var anyLat = L.some(function (l) { return isNum(l.latency); }), anyTp = L.some(function (l) { return isNum(l.throughput); });
    var t = el("table", "lk"), th = el("tr");
    ["from", "to", "link"].concat(anyLat ? ["latency"] : [], anyTp ? ["throughput"] : [], ["address"]).forEach(function (h) {
      var x = el("th", null, h); x.scope = "col"; th.appendChild(x);
    });
    var thead = el("thead"); thead.appendChild(th); t.appendChild(thead);
    var tb = el("tbody");
    L.forEach(function (l) {
      var r = el("tr");
      r.appendChild(el("td", null, l.from ? nodeName(l.from) : DASH));
      r.appendChild(el("td", null, l.to ? nodeName(l.to) : DASH));
      var k = el("td", null, l.kind || l.as_reported || DASH); if (l.as_reported) k.title = "exo: " + l.as_reported; r.appendChild(k);
      if (anyLat) r.appendChild(el("td", null, fmt.dash(l.latency)));
      if (anyTp) r.appendChild(el("td", null, fmt.dash(l.throughput)));
      r.appendChild(el("td", null, fmt.dash(l.address)));
      tb.appendChild(r);
    });
    t.appendChild(tb); box.appendChild(t);
    var msgs = [];
    if (anyLat || anyTp) msgs.push("Latency and throughput are shown exactly as exo reports them, in exo's units.");
    else msgs.push("exo does not report latency or bandwidth for these links.");
    note("xk-note", msgs.join(" "));
  }
  function renderPlacement() {
    var box = $("xq-body"), P = X.placement;
    clear(box);
    if (!Array.isArray(P)) {
      note("xq-note", X.exo && X.exo.running ? "exo does not expose where its instances are placed." : "exo is not answering.");
      return;
    }
    if (!P.length) { note("xq-note", "no model is placed on the cluster" + (onExo() ? " — nothing is loaded yet." : ".")); return; }
    note("xq-note", "");
    P.forEach(function (p) {
      box.appendChild(el("div", "pl-h", (p.serving ? "● serving: " : "") + (p.model || DASH) + (p.kind ? " · " + p.kind : "")));
      var t = el("table", "lk"), hr = el("tr");
      ["node", "shard", "rank", "layers", "runner"].forEach(function (h) { var x = el("th", null, h); x.scope = "col"; hr.appendChild(x); });
      var thead = el("thead"); thead.appendChild(hr); t.appendChild(thead);
      var tb = el("tbody");
      (p.shards || []).forEach(function (s) {
        var r = el("tr");
        r.appendChild(el("td", null, nodeName(s.node)));
        r.appendChild(el("td", null, fmt.dash(s.kind)));
        r.appendChild(el("td", null, fmt.dash(s.rank) + "/" + fmt.dash(s.world)));
        r.appendChild(el("td", null, isNum(s.start_layer) ? s.start_layer + "–" + fmt.dash(s.end_layer) + (isNum(s.n_layers) ? " of " + s.n_layers : "") : DASH));
        r.appendChild(el("td", null, fmt.dash(s.runner_status)));
        tb.appendChild(r);
      });
      t.appendChild(tb); box.appendChild(t);
    });
  }
  var logAt = 0;
  function pollLog() {
    return F.api("/api/exo/log?lines=60").then(function (d) {
      var pre = $("xl-pre"), atEnd = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 4;
      setText("xl-path", (d && d.path) || "", (d && d.path) || "");
      var text = d && d.exists ? ((d.lines || []).join("\n") || "(the log is empty)") : ((d && d.note) || "no exo log yet");
      if (pre.textContent !== text) { pre.textContent = text; if (atEnd) pre.scrollTop = pre.scrollHeight; }
    }, function (e) {
      $("xl-pre").textContent = e && e.status === 403 ? "exo's log is readable from this machine only." :
        "the log could not be read: " + (e && e.message);
    });
  }

  function renderAll() {
    [renderStatus, renderTotals, renderNodes, renderPrefill, renderModels, renderLinks, renderPlacement]
      .forEach(function (fn) { U.safe(fn); });
    setText("xt-upd", isNum(X.ts) ? "updated " + fmt.clock(X.ts) : "");
  }
  function pollExo() {
    return F.api("/api/exo").then(function (d) {
      if (d && typeof d === "object") { X = d; renderAll(); }
    }, function () { /* the top bar's lamp says why */ });
  }
  function pollProgress() {
    if (!(X.exo && X.exo.running)) { progress = {}; return null; }
    var want = (X.downloads && X.downloads.length) || Date.now() - dlStarted < 60000 || Object.keys(progress).length;
    if (!want) return null;
    return F.api("/api/models/progress").then(function (d) {
      var next = {};
      ((d && d.downloads) || []).forEach(function (x) { if (x && x.model) next[x.model] = x; });
      progress = next;
      renderModels();
    }, function () { /* keep the last bars */ });
  }
  F.onState(function () { U.safe(renderStatus); });
  renderAll();
  F.addPoll(function (t, first) {
    return Promise.all([pollExo().then(pollProgress), pollLog()]);
  });
  F.start();
})();
"""

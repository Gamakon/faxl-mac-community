# Vendored engine module (faxl_panel_photos.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Tag your photos, the page: `/console/apps/cameraroll`.

AM, 2026-10-14: the camera-roll page ignored the console's light/dark choice,
wore the old single-column style, said "1 / 1 completed" for a run whose one
photo was refused, and only knew Apple Photos -- a customer with a folder from
a camera card, on Linux or a Mac, had nothing. Mocked up, agreed, built here.

THE CONSOLE'S LAYOUT (the shell, top bar, drawers and runtime come from
faxl_panel, never copied; the left rail is LEFT_HTML, filled by RAIL_JS):

  centre   settings on one row (from, folder or photos, how many, write back,
           when), Start / Stop / progress; the photograph being read now, with
           what the model wrote; the photos tagged so far, newest first, in
           their own scroll, with a "needs a look" filter.
  right    this run (tagged, needs a look, written, typical time, cache),
           where each photo is, and the activity, newest first.

ADAPTIVE. A folder works everywhere and is the default. Apple Photos appears
only where /api/apps/photos/sources says a library exists; a library macOS is
blocking is offered with the way to unblock it.

THE MODEL IS ASKED, NEVER SWITCHED BEHIND YOUR BACK. Tagging needs a model
that reads pictures. When the serving one does not, Start is off and the page
asks whether to switch to one that is on this machine, does, and fits; it
switches only on "Switch model" (F.restartModel, the top bar's own switch).
The jobs never name a model: they use whatever is serving.

  render_photos(state, nonce=None) -> str    the human page
  photos_payload(library, origin) -> dict    ?format=json
  render_photos_agent(p) -> str              agent-mode inner HTML
  render_photos_text(p) -> str               ?format=text
"""

import html as _html

from faxl.engine import faxl_panel as _P

URL = "/console/apps/cameraroll"
NAME = "Tag your photos"
WHAT = ("Captions and keywords for your photos, made on this machine. "
        "Nothing is uploaded.")


def _e(s):
    return _html.escape(str(s), quote=True)


def render_photos(state, nonce=None):
    page = _P.render_shell(state, title="faxl — Tag your photos",
                           main_html=_P.LEFT_HTML + PHOTOS_HTML,
                           page_css=PHOTOS_CSS, page_js=PHOTOS_JS,
                           here="photos", nonce=nonce, app_id="app-photos",
                           rail=True)
    return page.replace('href="/console?mode=agent"',
                        'href="%s?mode=agent"' % URL, 1)


def photos_payload(library, origin):
    o = origin.rstrip("/")
    return {
        "app": "cameraroll", "name": NAME, "what": WHAT, "url": URL,
        "sources": {"folder": True, "photos_library": library},
        "endpoints": [
            {"method": "GET", "path": "/api/apps/photos/sources",
             "what": "which sources this machine has"},
            {"method": "POST", "path": "/api/apps/photos/folder/scan",
             "body": '{"path": "/full/path", "recursive": true}',
             "what": "what is in a folder, before starting"},
            {"method": "POST", "path": "/api/apps/photos/folder/start",
             "body": '{"path": "/full/path", "recursive": true, "count": 0, '
                     '"write": true, "window": "23:00-07:00"}',
             "what": "tag a folder (count 0 = all; window optional)"},
            {"method": "GET", "path": "/api/apps/photos/folder/status",
             "what": "progress and the newest results"},
            {"method": "POST", "path": "/api/apps/photos/folder/stop",
             "what": "stop after the photo in hand"},
            {"method": "POST", "path": "/api/apps/cameraroll/start",
             "body": '{"count": 20, "write_photos": true}',
             "what": "Apple Photos (Mac): tag the chosen photos"},
            {"method": "GET", "path": "/api/apps/cameraroll/status",
             "what": "Apple Photos job progress"},
        ],
        "example": (f"curl -sS -X POST {o}/api/apps/photos/folder/start "
                    f"-H 'Content-Type: application/json' "
                    f"-d '{{\"path\": \"/Volumes/EOS_DIGITAL/DCIM\", "
                    f"\"recursive\": true, \"write\": true}}'"),
    }


def render_photos_agent(p):
    lib = (p.get("sources") or {}).get("photos_library") or {}
    rows = "".join(f"<li><code>{_e(x['method'])} {_e(x['path'])}</code> — "
                   f"{_e(x['what'])}</li>" for x in p["endpoints"])
    return (f"<p>{_e(WHAT)}</p><p>Sources: a folder (always); Apple Photos "
            f"{'available' if lib.get('available') else 'not available'}"
            f"{' — ' + _e(lib.get('detail')) if lib.get('detail') else ''}.</p>"
            f"<ul>{rows}</ul><pre>{_e(p['example'])}</pre>"
            f'<p><a href="{URL}?format=json">{URL}?format=json</a></p>')


def render_photos_text(p):
    lib = (p.get("sources") or {}).get("photos_library") or {}
    lines = [f"{NAME}\t{URL}", WHAT, "",
             "source\tfolder\tavailable",
             f"source\tApple Photos\t{'available' if lib.get('available') else 'not available'}"
             f"\t{lib.get('detail') or ''}", ""]
    lines += [f"{x['method']}\t{x['path']}\t{x['what']}" for x in p["endpoints"]]
    return "\n".join(lines + ["", p["example"]]) + "\n"


# --------------------------------------------------------------------------
# Markup. Static; the script fills every value.
# --------------------------------------------------------------------------
PHOTOS_HTML = r"""<main id="p-main">
<div id="p-errors" aria-live="assertive"></div>
<section class="card" id="p-card" aria-labelledby="p-h">
  <div class="p-top">
    <div class="card-h"><h2 id="p-h">Tag your photos</h2>
      <span class="aux">captions and keywords for your photos, made on this machine. Nothing is uploaded.</span></div>
    <div class="p-grid">
      <div class="p-field" id="p-src-field" hidden><span class="lab">From</span>
        <span class="seg"><button type="button" id="p-src-folder" aria-pressed="true">A folder</button><button type="button" id="p-src-photos" aria-pressed="false">Apple Photos</button></span>
        <span class="muted" id="p-src-note">a camera card, a download, any folder of pictures</span></div>
      <div class="p-field p-wide" id="p-f-folder"><span class="lab"><label for="p-path">Folder</label></span>
        <span class="row"><input type="text" id="p-path" spellcheck="false" autocomplete="off"
          placeholder="the folder's full path, e.g. /Volumes/EOS_DIGITAL/DCIM">
        <button class="btn btn-quiet" type="button" id="p-choose">Choose…</button></span>
        <label class="row"><input type="checkbox" id="p-recursive" checked> include subfolders</label>
        <span class="muted" id="p-scan" role="status"></span></div>
      <div class="p-field" id="p-f-photos" hidden><span class="lab">Photos</span>
        <span id="p-photos-ok"><span class="row"><button class="btn btn-quiet" type="button" id="p-pick">Choose photos…</button></span>
          <span class="muted" id="p-picknote" role="status">opens the Mac's own photo picker</span></span>
        <span class="p-ask" id="p-photos-blocked" hidden></span></div>
      <div class="p-field"><span class="lab"><label for="p-count">How many</label></span>
        <span class="row"><input type="number" id="p-count" min="1" step="1" placeholder="all"><span class="muted" id="p-countof"></span></span></div>
      <div class="p-field"><span class="lab">Write back</span>
        <label class="row"><input type="checkbox" id="p-write" checked> <span id="p-wbtext">into each photo (JPEG) or an .xmp file beside it</span></label>
        <span class="muted" id="p-wbnote">your photos' pictures are never changed · also catalogue.csv in the folder</span></div>
      <div class="p-field p-when"><span class="lab">When</span>
        <span class="row"><label><input type="radio" name="p-when" id="p-now" checked> now</label>
          <label><input type="radio" name="p-when" id="p-later"> only between</label>
          <input type="time" id="p-from" value="23:00" disabled aria-label="from">–<input type="time" id="p-to" value="07:00" disabled aria-label="to"></span></div>
    </div>
    <div class="p-ask" id="p-ask" hidden>
      <p><b>The model faxl is running can't read pictures.</b> Tagging needs one that can. You are running <span class="mono" id="p-ask-now"></span>.</p>
      <p id="p-ask-offer"></p>
      <p class="row"><button class="btn" type="button" id="p-switch">Switch model</button>
        <button class="btn" type="button" id="p-dl" hidden>Download it</button>
        <button class="btn btn-quiet" type="button" id="p-notnow">Not now</button>
        <span class="muted" id="p-asknote">Anything using the current model waits while it switches. You can switch back from the top bar.</span></p>
      <div class="p-prog" id="p-dlprog" hidden><div class="bar" aria-hidden="true"><i id="p-dlbar"></i></div><span class="mono" id="p-dltxt" role="status"></span></div>
      <p class="row" id="p-token" hidden><span id="p-tokentxt">If Hugging Face refuses the download, add your Hugging Face token first.</span>
        <button class="btn btn-quiet" type="button" data-drawer="drawer-store">Add Hugging Face token</button></p>
    </div>
    <div class="p-run">
      <button class="btn big" type="button" id="p-start">Start tagging</button>
      <button class="btn btn-quiet big" type="button" id="p-stop" disabled>Stop</button>
      <div class="p-prog" id="p-prog" hidden><div class="bar" aria-hidden="true"><i id="p-bar"></i></div><span class="mono" id="p-progtxt" role="status"></span></div>
      <span class="muted" id="p-note" role="status"></span>
    </div>
    <div class="p-fail" id="p-fail" hidden></div>
  </div>
  <div id="p-nowbox" hidden>
    <div class="ph" id="p-nowph"><img id="p-nowimg" alt="the photo being read"><span id="p-nowname"></span></div>
    <div class="p-out">
      <h3 id="p-nowh">Reading now</h3>
      <p class="scene" id="p-scene"></p>
      <div class="tags" id="p-tags"></div>
      <p class="meta" id="p-meta"></p>
    </div>
  </div>
</section>
<section class="card" id="p-done" aria-labelledby="p-done-h">
  <div class="card-h"><h2 id="p-done-h">Tagged so far</h2><span class="aux">newest first</span>
    <span class="spacer"></span><span class="seg sm"><button type="button" id="p-f-all" aria-pressed="true">all</button><button type="button" id="p-f-bad" aria-pressed="false">needs a look</button></span></div>
  <div class="p-tiles" id="p-tiles"><p class="muted" id="p-empty">Nothing tagged yet. Choose your photos and press Start tagging; each one appears here as it is read.</p></div>
</section>
</main>
<aside id="p-side" aria-label="this run">
<section class="card">
  <div class="card-h"><h2 id="p-r-state-h">This run</h2><span class="aux" id="p-r-state">not started</span></div>
  <dl class="kv">
    <dt>tagged</dt><dd id="p-r-tagged">&#8212;</dd>
    <dt>needs a look</dt><dd id="p-r-bad">&#8212;</dd>
    <dt>written</dt><dd id="p-r-written">&#8212;</dd>
    <dt>typical photo</dt><dd id="p-r-secs">&#8212;</dd>
    <dt>instructions from cache</dt><dd id="p-r-cache">&#8212;</dd>
    <dt>model</dt><dd id="p-r-model">&#8212;</dd>
  </dl>
</section>
<section class="card">
  <div class="card-h"><h2>Where each photo is</h2></div>
  <ul class="stages">
    <li id="p-st-chosen"><span class="dot"></span>chosen<span class="num">&#8212;</span></li>
    <li id="p-st-wait"><span class="dot"></span>waiting<span class="num">&#8212;</span></li>
    <li id="p-st-read"><span class="dot"></span>being read<span class="num">&#8212;</span></li>
    <li id="p-st-tagged"><span class="dot"></span>tagged<span class="num">&#8212;</span></li>
    <li id="p-st-written"><span class="dot"></span>written<span class="num">&#8212;</span></li>
  </ul>
</section>
<section class="card" id="p-logcard">
  <div class="card-h"><h2>Activity</h2><span class="aux">newest first</span></div>
  <ul class="p-log" id="p-log"></ul>
</section>
</aside>"""

PHOTOS_CSS = r"""
/* The console's grid: rail | the job | its log. The page never scrolls; the
   columns and the tagged-so-far grid do (scroll bars from PANEL_CSS). */
#app-photos{display:grid;height:100vh;min-width:0;
  grid-template-columns:300px minmax(0,1fr) clamp(340px,24vw,440px);
  grid-template-rows:auto minmax(0,1fr);gap:var(--gap);padding:0 var(--gap) var(--gap)}
#p-main{min-height:0;min-width:0;display:flex;flex-direction:column;gap:var(--gap)}
#p-side{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:var(--gap)}
#p-errors{display:flex;flex-direction:column;gap:6px;flex:none}
#p-errors:empty{display:none}
.p-err{display:flex;gap:8px;align-items:flex-start;border:1px solid var(--bad);border-left-width:3px;
  border-radius:var(--radius);background:color-mix(in srgb,var(--bad) 8%,var(--panel));padding:7px 10px;font-size:13px}
.p-err span{flex:1;overflow-wrap:anywhere}
#p-card{flex:none;padding:0;max-height:62vh;overflow:auto}
.p-top{padding:10px 12px;display:flex;flex-direction:column;gap:10px}
.p-top .card-h{margin:0;flex-wrap:wrap}
.p-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px 16px;align-items:start}
.p-field{display:flex;flex-direction:column;gap:4px;font-size:12.5px;min-width:0}
.p-field .lab{font:700 10.5px var(--sans);letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2)}
.p-field .row{flex-wrap:wrap}
.p-wide{grid-column:span 2}
#p-path{flex:1;min-width:0}
#p-count{width:90px}
.p-field input[type=time]{width:96px}
.p-when{grid-column:span 2}
.p-when .row{flex-wrap:nowrap;white-space:nowrap}
.seg{display:inline-flex;border:1px solid var(--line-2);border-radius:var(--radius);overflow:hidden;align-self:flex-start}
.seg button{font:600 12px/1 var(--sans);height:24px;padding:0 10px;border:0;background:transparent;color:var(--ink-2);cursor:pointer}
.seg button[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink)}
.seg.sm button{height:20px;font-size:11px}
.p-run{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.btn.big{height:32px;padding:0 18px;font-size:13.5px}
.p-prog{display:flex;align-items:center;gap:10px;font-size:13px;flex:1;min-width:220px}
.p-prog .bar{height:8px}
.p-ask{border:1px solid var(--warn);border-left-width:3px;border-radius:var(--radius);padding:8px 12px;font-size:13px;
  background:color-mix(in srgb,var(--warn) 8%,var(--panel));display:flex;flex-direction:column;gap:6px}
.p-ask p{margin:0}
.p-fail{border:1px solid var(--bad);border-left-width:3px;border-radius:var(--radius);padding:7px 10px;font-size:13px;
  background:color-mix(in srgb,var(--bad) 8%,var(--panel))}
#p-nowbox{display:grid;grid-template-columns:minmax(150px,220px) minmax(0,1fr);gap:14px;padding:12px;border-top:1px solid var(--line)}
.ph{border-radius:var(--radius);aspect-ratio:4/3;max-width:100%;position:relative;overflow:hidden;background:var(--panel-2)}
.ph img{display:block;width:100%;height:100%;object-fit:cover}
.ph img:not([src]){visibility:hidden}
.ph span{position:absolute;left:8px;bottom:6px;font:600 11px var(--mono);color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.8)}
.p-out{display:flex;flex-direction:column;gap:8px;min-width:0}
.p-out h3{font:700 11px var(--sans);letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2);margin:0}
.p-out .scene{font-size:16px;line-height:1.5;margin:0}
.p-out .meta{font:12px var(--mono);color:var(--ink-2);margin:0}
.tags{display:flex;flex-wrap:wrap;gap:5px}
.tag{font:500 12px var(--sans);padding:2px 8px;border-radius:999px;background:var(--panel-2);border:1px solid var(--line)}
#p-done{flex:1 1 auto;min-height:200px;display:flex;flex-direction:column;padding:0}
#p-done .card-h{padding:10px 12px 0;margin-bottom:6px}
.p-tiles{flex:1 1 auto;min-height:0;overflow:auto;padding:0 12px 12px;display:grid;
  grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;align-content:start}
#p-empty{grid-column:1/-1;margin:6px 0}
.tile{border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;background:var(--panel);display:flex;flex-direction:column}
.tile .ph{border-radius:0}
.tile .tx{padding:6px 8px;font-size:12px;display:flex;flex-direction:column;gap:4px;overflow-wrap:anywhere}
.tile .tx .tag{font-size:11px;padding:1px 6px}
.tile .wb{font:11px var(--mono);color:var(--ink-2)}
.tile.bad{border-color:var(--bad)}
.tile.bad .tx{color:var(--bad)}
.stages{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px;font-size:13px}
.stages li{display:grid;grid-template-columns:16px 1fr auto;gap:8px;align-items:center;padding:3px 0}
.stages .dot{width:10px;height:10px;border-radius:50%;border:2px solid var(--line-2)}
.stages .on .dot{border-color:var(--teal);background:var(--teal);animation:pulse 1.1s ease-in-out infinite}
.stages .done .dot{border-color:var(--ok);background:var(--ok)}
.stages .num{font-family:var(--mono);font-variant-numeric:tabular-nums}
@media (prefers-reduced-motion:reduce){.stages .on .dot{animation:none}}
#p-logcard{flex:1 1 auto;min-height:220px;display:flex;flex-direction:column}
.p-log{flex:1 1 auto;min-height:0;overflow:auto;margin:0 -12px -10px;padding:0;list-style:none;font:12px/1.5 var(--mono);color:var(--ink-2)}
.p-log li{padding:4px 12px;border-top:1px solid var(--line);overflow-wrap:anywhere}
.p-log .ok{color:var(--ok)} .p-log .bad{color:var(--bad)}
@media (max-width:1100px){
  body{overflow:auto}
  #app-photos{height:auto;grid-template-columns:minmax(0,1fr)}
  #col-left{order:3}
  #p-card{max-height:none}
  #p-nowbox{grid-template-columns:1fr}
  .p-wide,.p-when{grid-column:auto}
  .p-tiles{max-height:520px}
  .p-log{max-height:320px}
}
"""

PHOTOS_JS = r"""
(function () {
  "use strict";
  var F = window.faxl, U = F.util, $ = U.$, el = U.el, get = U.get, fmt = F.fmt;
  var src = "folder", lib = null, polling = null, filter = "all", lastRows = [];
  var countTouched = false, picked = null, scanTimer = null, dismissed = null;
  try { dismissed = localStorage.getItem("faxl.photos.dismissed"); } catch (e) {}

  function err(msg) {
    var box = $("p-errors"), p = el("div", "p-err");
    p.appendChild(el("span", null, msg));
    var x = el("button", "btn btn-quiet", "dismiss"); x.type = "button";
    x.addEventListener("click", function () { if (p.parentNode) p.parentNode.removeChild(p); });
    p.appendChild(x);
    box.insertBefore(p, box.firstChild);
    while (box.children.length > 3) box.removeChild(box.lastChild);
  }
  function emsg(e) { return (e && e.message) || String(e); }
  function n(k, one, many) { return fmt.int(k) + " " + (k === 1 ? one : (many || one + "s")); }

  // ---- EVERY ERROR IS A SENTENCE AND A WAY TO FIX IT (AM, 2026-10-14: "it
  // is filled with errors with no actions that fix the errors"). What the
  // job recorded -- often a proxy's raw JSON -- is translated here into what
  // happened, in plain words, and which button fixes it. The raw text stays
  // available on hover, never as the message.
  //   fix: "again" (tag it again), "folder" (choose another folder or turn
  //   write-back off), "install" (a missing piece: the sentence says which),
  //   "none" (nothing to press: the sentence says what to do instead).
  function explain(e) {
    var raw = String(e || ""), low = raw.toLowerCase();
    if (/switching to|is loading|retry in about/.test(low))
      return {text: "faxl was changing models when this photo was sent, so it was not read. That was a fault in faxl, fixed on 14 October.", fix: "again", raw: raw};
    if (/empty reply/.test(low))
      return {text: "The model gave no answer for this photo (a thinking model used its whole reply on thinking). Fixed on 14 October.", fix: "again", raw: raw};
    if (/cannot read pictures|images_not_supported|reads no pictures/.test(low))
      return {text: "The model faxl is running can't read pictures.", fix: "model", raw: raw};
    if (/raw file with no jpeg/.test(low))
      return {text: "A raw file with no JPEG of the same shot. faxl can't read raw files yet: set the camera to RAW+JPEG, or export a JPEG, and it will be tagged.", fix: "none", raw: raw};
    if (/pillow.heif|pillow_heif/.test(low))
      return {text: "This HEIC photo needs pillow-heif to be read on this machine: pip install pillow-heif in the Python faxl runs from, then tag it again.", fix: "again", raw: raw};
    if (/not writable|permission denied|read-only|could not write/.test(low))
      return {text: "faxl could not write to this folder (it is read-only, or locked). Choose a folder you can write to, or turn Write back off.", fix: "folder", raw: raw};
    if (/timed out|timeout/.test(low))
      return {text: "The model took too long with this photo.", fix: "again", raw: raw};
    if (/refused|not answering|connection|urlopen|http 50[0-9]/.test(low))
      return {text: "faxl's model server did not answer for this photo.", fix: "again", raw: raw};
    if (/batch rc=|exit status|rc=\d/.test(low))
      return {text: "The tagging run stopped part-way.", fix: "again", raw: raw};
    return {text: raw ? "This photo was not tagged: " + raw.replace(/^error:\s*/i, "").slice(0, 160) : "This photo was not tagged.", fix: "again", raw: raw};
  }
  function save(k, v) { try { localStorage.setItem("faxl.photos." + k, v); } catch (e) {} }
  function load(k) { try { return localStorage.getItem("faxl.photos." + k); } catch (e) { return null; } }

  // ---- where the photos come from: a folder everywhere, Apple Photos only
  // where this machine has a library (adaptive) ----------------------------
  function setSrc(s) {
    src = s;
    $("p-src-folder").setAttribute("aria-pressed", s === "folder" ? "true" : "false");
    $("p-src-photos").setAttribute("aria-pressed", s === "photos" ? "true" : "false");
    $("p-f-folder").hidden = s !== "folder"; $("p-f-photos").hidden = s !== "photos";
    U.setText("p-src-note", s === "folder" ? "a camera card, a download, any folder of pictures"
                                           : "your Photos library on this Mac");
    U.setText("p-wbtext", s === "folder" ? "into each photo (JPEG) or an .xmp file beside it"
                                         : "captions and keywords into Photos");
    U.setText("p-wbnote", s === "folder" ? "your photos' pictures are never changed · also catalogue.csv in the folder"
                                         : "Photos keeps them with each picture");
    save("src", s);
    gate(); poll();
  }
  $("p-src-folder").addEventListener("click", function () { setSrc("folder"); });
  $("p-src-photos").addEventListener("click", function () { setSrc("photos"); });
  var dlOffer = null, hfSet = null, fetching = false, fetched = null;
  F.api("/api/apps/photos/sources").then(function (d) {
    lib = d.photos_library || {};
    dlOffer = d.download_offer || null;
    hfSet = !!(d.hf_token && d.hf_token.set);
    $("p-src-field").hidden = !lib.available;
    if (lib.available && lib.blocked) {
      $("p-photos-ok").hidden = true; $("p-photos-blocked").hidden = false;
      U.setText("p-photos-blocked", lib.detail || "macOS is blocking faxl from the Photos library.");
    }
    setSrc(lib.available && load("src") === "photos" ? "photos" : "folder");
    library();      // the Photos selection, now that we know there is a library
  }, function (e) { err("Could not read which photo sources this machine has: " + emsg(e)); setSrc("folder"); });

  // ---- a folder: path, the system picker, and what is in it ---------------
  var path = $("p-path");
  path.value = load("path") || "";
  function scan() {
    var p = path.value.trim();
    save("path", p);
    if (!p) { U.setText("p-scan", ""); U.setText("p-countof", ""); return; }
    U.setText("p-scan", "looking…");
    F.api("/api/apps/photos/folder/scan", {body: {path: p, recursive: $("p-recursive").checked}}).then(function (d) {
      if (!d.ok) { U.setText("p-scan", d.error || "could not read that folder"); U.setText("p-countof", ""); return; }
      var kinds = Object.keys(d.by_kind || {}).map(function (k) { return d.by_kind[k] + " " + k; }).join(", ");
      var t = fmt.int(d.photos) + " photo" + (d.photos === 1 ? "" : "s") + (kinds ? ": " + kinds : "");
      if (d.raw_with_jpeg) t += " · " + fmt.int(d.raw_with_jpeg) + " raw file" + (d.raw_with_jpeg === 1 ? " has" : "s have") + " a JPEG of the same shot";
      if (d.raw_alone) t += " · " + fmt.int(d.raw_alone) + " raw only (cannot be read yet)";
      U.setText("p-scan", t);
      U.setText("p-countof", "of " + fmt.int(d.photos));
      if (!countTouched) $("p-count").value = "";
    }, function (e) { U.setText("p-scan", emsg(e)); });
  }
  path.addEventListener("change", scan);
  path.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); scan(); } });
  $("p-recursive").addEventListener("change", scan);
  $("p-choose").addEventListener("click", function () {
    var b = this; b.disabled = true;
    U.setText("p-scan", "a folder picker opened on this machine — choose the folder there");
    F.api("/api/apps/photos/folder/choose", {body: {}}).then(function (d) {
      if (d.ok) { path.value = d.path; scan(); }
      else U.setText("p-scan", d.error || "no folder was chosen");
    }, function (e) { U.setText("p-scan", emsg(e)); }).then(function () { b.disabled = false; });
  });
  if (path.value) scan();
  $("p-count").addEventListener("input", function () { countTouched = !!this.value; });

  // ---- Apple Photos: the Mac's own picker ---------------------------------
  function library() {
    if (!lib || !lib.available || lib.blocked) return;
    F.api("/api/apps/cameraroll/library").then(function (d) {
      if (!d.ok) { U.setText("p-picknote", d.error || "press Choose photos to begin"); return; }
      picked = d.selected || null;
      U.setText("p-picknote", d.selected ? n(d.selected, "photo") + " chosen"
        : d.status === "authorized" ? fmt.int(d.photos || 0) + " photos in the library"
        : "no photos chosen yet — press Choose photos");
      if (d.selected) U.setText("p-countof", "of " + fmt.int(d.selected));
    }, function () {});
  }
  $("p-pick").addEventListener("click", function () {
    var b = this; b.disabled = true;
    U.setText("p-picknote", "the Photos picker is open on this Mac — choose the photos faxl may read");
    F.api("/api/apps/cameraroll/pick", {body: {}}).then(function (d) {
      U.setText("p-picknote", n(d.picked || 0, "photo") + " chosen"); library();
    }, function (e) { U.setText("p-picknote", emsg(e)); }).then(function () { b.disabled = false; });
  });

  // ---- when ----------------------------------------------------------------
  function when() {
    if (!$("p-later").checked) return "";
    var a = $("p-from").value, b = $("p-to").value;
    return a && b ? a + "-" + b : "";
  }
  function paintWhen() { var on = $("p-later").checked; $("p-from").disabled = $("p-to").disabled = !on; }
  $("p-now").addEventListener("change", paintWhen); $("p-later").addEventListener("change", paintWhen);

  // ---- the model must read pictures; ask before switching -----------------
  // F.state.model.vision is the console's own reading (the files, or the
  // engine when it says). A row of F.state.models with vision true, on this
  // machine and fitting, is what we offer; the shipped Qwen3-VL-4B first.
  var offer = null, declined = false;
  function vision() { return get(F.state, "model.vision"); }
  function pickOffer() {
    var rows = (get(F.state, "models") || []).filter(function (m) {
      return m && m.vision === true && m.on_disk && m.fits !== false && !m.serving;
    });
    rows.sort(function (a, b) {
      var av = /Qwen3-VL-4B/.test(a.id) ? 0 : 1, bv = /Qwen3-VL-4B/.test(b.id) ? 0 : 1;
      return av - bv || (a.size_bytes || 0) - (b.size_bytes || 0);
    });
    return rows[0] || null;
  }
  function gate() {
    var v = vision(), ask = $("p-ask"), running = !!(lastStatus && lastStatus.running);
    var no = v === false && !running;
    ask.hidden = !no;
    if (no) {
      // THE WAYS FORWARD, in order (AM, 2026-10-14): switch to a model on
      // this machine that reads pictures; else download one that fits; and
      // say where the Hugging Face token goes if the download may need it.
      U.setText("p-ask-now", get(F.state, "model.short") || get(F.state, "model.id") || "the current model");
      offer = fetched || pickOffer();
      var dl = !offer && dlOffer && !fetching;
      $("p-switch").hidden = !offer;
      $("p-dl").hidden = !dl;
      if (offer) {
        U.setText("p-ask-offer", "Switch to " + (offer.short || offer.id) + "? It is on this machine" +
          (offer.size_bytes ? " (" + fmt.gb(offer.size_bytes) + ")" : "") + " and reads pictures.");
      } else if (dlOffer) {
        U.setText("p-ask-offer", "No model on this machine reads pictures. Download " + (dlOffer.short || dlOffer.id) +
          (dlOffer.size_bytes ? " (" + fmt.gb(dlOffer.size_bytes) + ")" : "") +
          "? It reads pictures and fits this machine. When it is downloaded, faxl asks before switching to it.");
      } else {
        U.setText("p-ask-offer", "No model on this machine reads pictures. Choose one that does from the model picker in the top bar " +
          "(for example a Qwen3-VL model), then come back here.");
      }
      $("p-token").hidden = !(dl || fetching) || hfSet !== false;
      if (declined) U.setText("p-asknote", "Not switched. Tagging stays off until a model that reads pictures is running.");
    }
    $("p-start").disabled = no || running;
  }
  $("p-switch").addEventListener("click", function () {
    if (!offer || !F.restartModel) return;
    var b = this; b.disabled = true;
    U.setText("p-asknote", "Switching to " + (offer.short || offer.id) + "… Start tagging comes back when it is ready.");
    F.restartModel(offer.id).catch(function () { b.disabled = false; });
  });
  $("p-notnow").addEventListener("click", function () { declined = true; gate(); });
  $("p-dl").addEventListener("click", function () {
    if (!dlOffer) return;
    var b = this; b.disabled = true; fetching = true; gate();
    $("p-dlprog").hidden = false; U.setText("p-dltxt", "starting the download…");
    F.api("/api/models/fetch", {body: {model_id: dlOffer.id}}).then(watchFetch, function (e) {
      fetching = false; b.disabled = false; $("p-dlprog").hidden = true;
      U.setText("p-asknote", "The download did not start: " + emsg(e)); gate();
    });
  });
  function watchFetch() {
    F.api("/api/models/fetch/status").then(function (st) {
      var done = st.bytes_done || 0, total = st.bytes_total || 0;
      if (total) $("p-dlbar").style.width = Math.min(100, done / total * 100).toFixed(1) + "%";
      U.setText("p-dltxt", fmt.gb(done) + (total ? " of " + fmt.gb(total) : "") + " · " + (st.model || ""));
      if (st.state === "running") { setTimeout(watchFetch, 2000); return; }
      fetching = false; $("p-dl").disabled = false;
      if (st.state === "done") {
        fetched = {id: st.model, short: (st.model || "").split("/").pop(), size_bytes: done};
        $("p-dlprog").hidden = true;
        U.setText("p-asknote", "Downloaded. Switch to it to start tagging.");
      } else {
        $("p-dlprog").hidden = true;
        U.setText("p-asknote", st.error || "The download stopped.");
        if (st.code === "needs_token") {
          $("p-token").hidden = false;
          U.setText("p-tokentxt", "Hugging Face needs your token for this download.");
        }
      }
      gate();
    }, function () { setTimeout(watchFetch, 4000); });
  }
  // a download already under way when the page opens is picked up, not restarted
  F.api("/api/models/fetch/status").then(function (st) {
    if (st && st.state === "running") { fetching = true; $("p-dlprog").hidden = false; watchFetch(); }
  }, function () {});
  F.onState(function () { gate(); });

  // ---- start / stop ----------------------------------------------------------
  $("p-start").addEventListener("click", function () { startRun(this); });
  function startRun(btn) {
    var b = btn || $("p-start"), k = parseInt($("p-count").value, 10);
    var body, url;
    if (src === "folder") {
      var p = path.value.trim();
      if (!p) { U.setText("p-note", "type or choose a folder first"); path.focus(); return; }
      url = "/api/apps/photos/folder/start";
      body = {path: p, recursive: $("p-recursive").checked, write: $("p-write").checked, window: when()};
      if (k > 0) body.count = k;
    } else {
      url = "/api/apps/cameraroll/start";
      // "Tag it again" retries the same photos: the chosen ones, else the
      // last run's size -- never a made-up batch of 20
      body = {count: k > 0 ? k : (picked || (lastStatus && lastStatus.target) || 20),
              write_photos: $("p-write").checked, window: when()};
    }
    b.disabled = true; U.setText("p-note", "starting…");
    F.api(url, {body: body}).then(function () {
      U.setText("p-note", "running — you can close this page; it keeps going");
      $("p-fail").hidden = true; dismissed = null; poll();
    }, function (e) { U.setText("p-note", ""); err("Tagging did not start: " + explain(emsg(e)).text); b.disabled = false; });
  }
  $("p-stop").addEventListener("click", function () {
    var b = this; b.disabled = true;
    U.setText("p-note", "stopping — the photo in hand finishes first");
    F.api(src === "folder" ? "/api/apps/photos/folder/stop" : "/api/apps/cameraroll/stop", {body: {}})
      .then(function (d) { U.setText("p-note", d.note || ""); poll(); },
            function (e) { U.setText("p-note", emsg(e)); b.disabled = false; });
  });

  // ---- one row, whichever job wrote it ------------------------------------
  // The folder job writes {text, scene, tags}; the Photos job keeps the
  // model's raw reply ("TEXT: … SCENE: … TAGS: …"), parsed here the same way.
  function cat(r) {
    var c = r.catalogue;
    if (c && typeof c === "object") return {text: c.text || "", scene: c.scene || "", tags: c.tags || []};
    var s = String(c || ""), out = {text: "", scene: "", tags: []};
    var m = /TEXT:\s*([\s\S]*?)(?=\n?\s*SCENE:|$)/i.exec(s); if (m) out.text = m[1].trim();
    m = /SCENE:\s*([\s\S]*?)(?=\n?\s*TAGS:|$)/i.exec(s); if (m) out.scene = m[1].trim();
    m = /TAGS:\s*([\s\S]*)$/i.exec(s); if (m) out.tags = m[1].split(",").map(function (t) { return t.trim(); }).filter(Boolean);
    if (!out.scene && !out.tags.length) out.scene = s.trim();
    return out;
  }
  function tagList(tags) { return (typeof tags === "string" ? tags.split(",") : tags || []).map(function (t) { return String(t).trim(); }).filter(Boolean); }
  function preview(r) {
    if (!r || !r.preview) return null;
    return (src === "folder" ? "/api/apps/photos/folder/preview/" : "/api/apps/cameraroll/preview/") + encodeURIComponent(r.preview);
  }
  function written(r) {
    if (r.write) return r.write;
    var w = r.photos_write;
    if (w === true || w === "ok") return "written to Photos";
    if (w && typeof w === "object") return w.ok ? "written to Photos" : "not written: " + (w.error || "Photos refused");
    return "";
  }
  function isWritten(r) { var w = written(r); return /^written/.test(w); }
  function tile(r) {
    var t = el("div", "tile" + (r.error ? " bad" : ""));
    var ph = el("div", "ph"), src2 = preview(r);
    if (src2) { var im = el("img"); im.loading = "lazy"; im.alt = r.photo || ""; im.src = src2; ph.appendChild(im); }
    ph.appendChild(el("span", null, r.photo || ""));
    t.appendChild(ph);
    var tx = el("div", "tx");
    if (r.error) {
      var x = explain(r.error);
      tx.appendChild(el("b", null, "needs a look"));
      var sp = el("span", null, x.text); sp.title = x.raw; tx.appendChild(sp);
    }
    else {
      var c = cat(r);
      tx.appendChild(el("span", null, c.scene || "(no description)"));
      var tg = el("div", "tags"); tagList(c.tags).forEach(function (x) { tg.appendChild(el("span", "tag", x)); });
      tx.appendChild(tg);
      var w = written(r); if (w) tx.appendChild(el("span", "wb", w));
    }
    t.appendChild(tx);
    return t;
  }
  function paintTiles() {
    var box = $("p-tiles"), rows = lastRows.filter(function (r) { return filter === "all" || r.error; });
    box.textContent = "";
    if (!rows.length) {
      box.appendChild(el("p", "muted", filter === "all" ? "Nothing tagged yet. Choose your photos and press Start tagging; each one appears here as it is read."
                                                       : "Nothing needs a look."));
      return;
    }
    rows.forEach(function (r) { box.appendChild(tile(r)); });
  }
  $("p-f-all").addEventListener("click", function () { filter = "all"; this.setAttribute("aria-pressed", "true"); $("p-f-bad").setAttribute("aria-pressed", "false"); paintTiles(); });
  $("p-f-bad").addEventListener("click", function () { filter = "bad"; this.setAttribute("aria-pressed", "true"); $("p-f-all").setAttribute("aria-pressed", "false"); paintTiles(); });

  // ---- the run: progress, the photo in front of the model, the log --------
  var lastStatus = null;
  function hm(ts) { var d = new Date(ts * 1000); return d.toTimeString().slice(0, 8); }
  function stage(id, n, cls) { var li = $(id); li.className = cls || ""; li.querySelector(".num").textContent = n == null ? U.DASH : fmt.int(n); }
  function render(st) {
    lastStatus = st;
    var rows = st.recent || [], running = !!st.running;
    var tagged = st.tagged_this_run != null ? st.tagged_this_run : st.done_this_run;
    var bad = st.failed_this_run || rows.filter(function (r) { return r.error; }).length;
    var target = st.target || 0, wr = rows.filter(isWritten).length;
    lastRows = rows;
    paintTiles();
    U.setText("p-f-all", "all " + rows.length);
    U.setText("p-f-bad", "needs a look " + rows.filter(function (r) { return r.error; }).length);

    var state = st.state || "none";
    U.setText("p-r-state", {running: "running", waiting: "waiting", done: "finished", stopped: "stopped",
      failed: "stopped", interrupted: "interrupted", none: "not started"}[state] || state);
    U.setText("p-r-tagged", target ? fmt.int(tagged || 0) + " of " + fmt.int(target) : fmt.int(tagged || 0));
    U.setText("p-r-bad", fmt.int(bad || 0));
    U.setText("p-r-written", fmt.int(wr));
    var c = st.cache || {};
    U.setText("p-r-secs", c.secs_mean != null ? c.secs_mean + " s" : U.DASH);
    U.setText("p-r-cache", c.photos ? fmt.int(c.hits || 0) + " of " + fmt.int(c.photos) : U.DASH);
    U.setText("p-r-model", get(F.state, "model.short") || U.DASH);

    var reading = st.current ? 1 : 0;
    var waiting = target ? Math.max(0, target - (tagged || 0) - (bad || 0) - reading) : null;
    stage("p-st-chosen", target || null, target ? "done" : "");
    stage("p-st-wait", running ? waiting : 0, "");
    stage("p-st-read", reading, reading ? "on" : "");
    stage("p-st-tagged", tagged || 0, tagged ? "done" : "");
    stage("p-st-written", wr, wr ? "done" : "");

    $("p-stop").disabled = !running;
    $("p-prog").hidden = !(running || state === "waiting") || !target;
    if (target) {
      var f = Math.min(1, ((tagged || 0) + (bad || 0)) / target);
      $("p-bar").style.width = (f * 100).toFixed(1) + "%";
      var left = c.secs_mean && running ? Math.round((target - (tagged || 0) - (bad || 0)) * c.secs_mean / 60) : null;
      U.setText("p-progtxt", fmt.int((tagged || 0) + (bad || 0)) + " of " + fmt.int(target) +
        (left != null ? " · about " + (left < 1 ? "a minute" : left + " min") + " left" : "") +
        (state === "waiting" ? " · waiting: " + (st.error || st.reason || "outside the time window") : ""));
    }
    // a run that ended badly is said plainly, not shown as complete
    var fail = $("p-fail");
    var ended = st.updated || st.started || 0, old = !running && ended && (Date.now() / 1000 - ended > 1800);
    var lastBad = rows.filter(function (r) { return r.error; })[0];
    if (!running && st.started && dismissed !== String(st.started) &&
        (state === "failed" || state === "interrupted" || (state !== "none" && target && !tagged && bad))) {
      var x = explain(lastBad ? lastBad.error : st.error);
      fail.hidden = false; fail.textContent = "";
      fail.appendChild(el("p", null, (old ? "Your last run, at " + hm(st.started).slice(0, 5) + ", " : "This run ") +
        "stopped after " + fmt.int(tagged || 0) + " of " + n(target || 0, "photo") + ". " + x.text));
      var acts = el("p", "row");
      function act(label, fn, quiet) { var bt = el("button", "btn" + (quiet ? " btn-quiet" : ""), label); bt.type = "button"; bt.addEventListener("click", fn); acts.appendChild(bt); }
      if (x.fix === "again") act(bad === 1 ? "Tag it again" : "Tag them again", function () { startRun(this); });
      if (x.fix === "folder") { act("Choose another folder", function () { setSrc("folder"); $("p-choose").click(); });
                                act("Turn write back off and tag again", function () { $("p-write").checked = false; startRun(this); }, true); }
      if (x.fix === "model") act("See the choices", function () { gate(); $("p-ask").scrollIntoView({block: "center"}); });
      act("Dismiss", function () { dismissed = String(st.started); try { localStorage.setItem("faxl.photos.dismissed", dismissed); } catch (e) {} render(st); }, true);
      if (bad > 1) acts.appendChild(el("span", "muted", "Photos already tagged are skipped."));
      fail.appendChild(acts);
      if (x.raw) fail.title = x.raw;
    } else fail.hidden = true;
    U.setText("p-r-state-h", old ? "Last run" : "This run");
    if (old) U.setText("p-r-state", "ended " + hm(ended).slice(0, 5));

    // the photo in front of the model; after it, the newest one done
    var cur = st.current, show = cur || rows[0];
    var box = $("p-nowbox");
    box.hidden = !show || (!running && dismissed === String(st.started));
    if (show) {
      var im = $("p-nowimg"), p = preview(show);
      if (p) im.src = p; else im.removeAttribute("src");
      U.setText("p-nowname", show.photo || show.file || "");
      U.setText("p-nowh", cur ? "Reading now" : (show.error ? "Last photo — needs a look" : "Last photo tagged"));
      var cc = cur ? {scene: "", tags: [], text: ""} : cat(show);
      U.setText("p-scene", cur ? "the model is reading this photo…" : (show.error ? explain(show.error).text : cc.scene || ""));
      var tg = $("p-tags"); tg.textContent = "";
      tagList(cc.tags).forEach(function (x) { tg.appendChild(el("span", "tag", x)); });
      U.setText("p-meta", cur ? "sent " + Math.max(0, Math.round(Date.now() / 1000 - (cur.started_at || 0))) + " s ago"
        : [cc.text && cc.text !== "NONE" ? "text in the picture: " + cc.text : "", show.secs ? "read in " + show.secs + " s" : "",
           show.outcome === "HIT" ? "the instructions came from the cache" : "", written(show)].filter(Boolean).join(" · "));
    }

    var log = $("p-log"); log.textContent = "";
    if (cur) log.appendChild(el("li", null, hm(cur.started_at || Date.now() / 1000) + " " + (cur.photo || cur.file || "") + " being read"));
    rows.forEach(function (r) {
      var li = el("li", r.error ? "bad" : "ok");
      if (r.error) li.title = String(r.error);
      li.textContent = hm(r.ts || 0) + " " + (r.photo || "") + (r.error ? " not tagged: " + explain(r.error).text
        : " tagged" + (r.secs ? " in " + r.secs + " s" : "") + (written(r) ? " · " + written(r) : ""));
      log.appendChild(li);
    });
    if (st.started) log.appendChild(el("li", null, hm(st.started) + " started" + (st.path ? ": " + st.path : "") + (target ? ", " + n(target, "photo") : "")));
    gate();
  }
  function poll() {
    var url = src === "folder" ? "/api/apps/photos/folder/status" : "/api/apps/cameraroll/status";
    return F.api(url).then(render, function () {});
  }
  F.addPoll(function () { return poll(); });
  library();
  window.faxlPhotos = {cat: cat};
  F.start();
})();
"""

"""Halo telemetry — the transaction event collection contract.

The schema is defined in faxl_event.proto; faxl_event_pb2 is the vendored
generated binding (regenerate with the protoc command in the .proto header).
"""
from . import faxl_event_pb2  # noqa: F401

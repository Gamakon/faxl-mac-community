"""faxl runtime registration of custom mlx_lm model loaders.

faxl never patches site-packages permanently (Rules.md). Instead we insert our
loader module into ``sys.modules`` under the name mlx_lm expects, so that
``mlx_lm.utils._get_classes`` resolves ``model_type`` via
``importlib.import_module("mlx_lm.models.<model_type>")`` and finds ours.
"""

import importlib
import sys


def register() -> None:
    """Register faxl's custom model loaders with mlx_lm (idempotent)."""
    from . import bailing_hybrid  # noqa: WPS433 (local import on purpose)
    from . import deepseek_v4      # noqa: WPS433

    # OVERRIDE, NOT JUST FILL-IN. Assigning into sys.modules only wins if
    # nothing has already imported the real name. An environment that still has
    # a FORKED mlx-lm installed ships its own deepseek_v4, and whichever ran
    # first would win -- so the same code could resolve to our file on one
    # machine and to a stale fork's on another, silently. Measured: importing
    # mlx_lm.models.deepseek_v4 before register() left the site-packages copy
    # in place and our vendored module unused.
    #
    # So drop any already-imported copy of the names we own before claiming
    # them. Ours is the one that is credited, licence-noted and tested.
    for _name in ("mlx_lm.models.bailing_hybrid", "mlx_lm.models.deepseek_v4"):
        sys.modules.pop(_name, None)

    sys.modules["mlx_lm.models.bailing_hybrid"] = bailing_hybrid
    # DeepSeek V4 is not in stock mlx-lm. exo reached it by pinning mlx-lm to a
    # personal branch; we vendor the one module instead and register it the same
    # way, so stock mlx-lm can stay stock. See deepseek_v4.py for credit and
    # licence.
    sys.modules["mlx_lm.models.deepseek_v4"] = deepseek_v4

    # Make sure the real mlx_lm.models package is importable, so our injected
    # submodules sit alongside the genuine ones.
    _models = importlib.import_module("mlx_lm.models")

    # AND BIND THEM AS ATTRIBUTES OF THE PARENT PACKAGE. sys.modules alone is
    # not enough: `import mlx_lm.models.deepseek_v4` consults the parent
    # package, and if a forked mlx-lm ships a file of that name on disk the
    # import machinery loads it and rebinds the attribute, quietly replacing
    # ours. Setting the attribute is what makes the override stick.
    _models.bailing_hybrid = bailing_hybrid
    _models.deepseek_v4 = deepseek_v4

    # qwen4_exp (Qwen3.8-Flash-Next) is NOT registered this way, because
    # mlx-vlm already ships a complete implementation of it -- it is a
    # vision-language model, so it lives there rather than in mlx_lm. What faxl
    # adds is a repair to the WEIGHTS of the published mlx-optiq builds, which
    # carry a different key prefix and pre-shifted norm gains. See qwen4_exp.py.
    # A no-op when mlx-vlm is absent or too old to have the architecture.
    try:
        from . import qwen4_exp  # noqa: WPS433
        qwen4_exp.install()
    except Exception as _exc:                                 # noqa: BLE001
        print(f"[faxl] qwen4_exp repair not installed: {_exc}", flush=True)

    # QSAKVCache holds one non-array scalar in its state, which safetensors
    # cannot write -- so save_prompt_cache raised std::bad_cast and NOTHING on
    # this model was ever cached. Moving that scalar to meta_state (the channel
    # mlx_lm provides for exactly this) makes the whole mixed cache
    # serialisable. Must run BEFORE a model builds its cache.
    try:
        from . import qsa_cache  # noqa: WPS433
        qsa_cache.install()
    except Exception as _exc:                                 # noqa: BLE001
        print(f"[faxl] QSA cache fix not installed: {_exc}", flush=True)

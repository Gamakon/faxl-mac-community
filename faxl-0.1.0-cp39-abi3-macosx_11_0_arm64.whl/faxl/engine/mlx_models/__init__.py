"""Halo runtime registration of custom mlx_lm model loaders.

Halo never patches site-packages permanently (Rules.md). Instead we insert our
loader module into ``sys.modules`` under the name mlx_lm expects, so that
``mlx_lm.utils._get_classes`` resolves ``model_type`` via
``importlib.import_module("mlx_lm.models.<model_type>")`` and finds ours.
"""

import importlib
import sys


def register() -> None:
    """Register Halo's custom model loaders with mlx_lm (idempotent)."""
    from . import bailing_hybrid  # noqa: WPS433 (local import on purpose)

    sys.modules["mlx_lm.models.bailing_hybrid"] = bailing_hybrid

    # Make sure the real mlx_lm.models package is importable first, so our
    # injected submodule sits alongside the genuine ones.
    importlib.import_module("mlx_lm.models")

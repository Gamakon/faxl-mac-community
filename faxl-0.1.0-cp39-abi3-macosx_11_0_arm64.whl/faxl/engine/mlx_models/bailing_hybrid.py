# faxl MLX loader for Ling-3.0-tiny (model_type: bailing_hybrid,
# arch: BailingMoeV3ForCausalLM).
#
# This is a MoE-wrapped sibling of Kimi Linear. The linear layer is Kimi Delta
# Attention (KDA); the full-attention layer is DeepSeek-style Multi-Latent
# Attention (MLA, non-absorbed, with a q-LoRA path and a head-wise output gate).
#
# Authoritative spec: the model's own remote code
#   modeling_bailing_moe_v3.py / configuration_bailing_moe_v3.py
# in the HF snapshot.  Assembled here from three verified MLX references:
#   mlx_lm/models/kimi_linear.py   (KDA plumbing, ShortConv1d, MoE select, cache)
#   mlx_lm/models/gated_delta.py   (the shared KDA recurrence kernel/ops)
#   mlx_lm/models/deepseek_v2.py   (non-absorbed MLA with q-LoRA + traditional rope)
#
# CRITICAL DEVIATION FROM KIMI (would silently emit garbage if wrong):
#   Ling KDA uses safe_gate=True, lower_bound=-5.  The fla kernel gate is
#       b_gk = lower_bound * sigmoid(exp(A_log) * (g + dt_bias))     (log-space)
#       decay = exp(b_gk)
#   NOT the vanilla  exp(-exp(A_log)*softplus(a+dt_bias))  that MLX's
#   gated_delta_update / compute_g hardcodes.  So we compute the decay + beta
#   ourselves and call gated_delta_kernel / gated_delta_ops directly, which
#   accept a precomputed vectorized decay g of shape [B, T, Hv, Dk].
#   (fla source: fla/ops/kda/fused_recurrent.py, USE_LOWER_BOUND branch.)

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import mlx.core as mx
import mlx.nn as nn

from mlx_lm.models.activations import swiglu
from mlx_lm.models.base import (
    BaseModelArgs,
    create_attention_mask,
    create_ssm_mask,
    scaled_dot_product_attention,
)
from mlx_lm.models.cache import ArraysCache, KVCache
from mlx_lm.models.gated_delta import gated_delta_kernel, gated_delta_ops
from mlx_lm.models.switch_layers import SwitchGLU


@dataclass
class ModelArgs(BaseModelArgs):
    model_type: str = "bailing_hybrid"
    vocab_size: int = 157184
    hidden_size: int = 1536
    intermediate_size: int = 4608
    num_hidden_layers: int = 24
    num_attention_heads: int = 16
    num_key_value_heads: int = 16
    head_dim: int = 128
    rms_norm_eps: float = 1e-6
    rope_theta: float = 6000000.0
    max_position_embeddings: int = 131072

    # decoder-layer interleave: layer is full-attention (MLA) when
    #   (idx+1) % layer_group_size == 0  (else KDA linear-attention)
    layer_group_size: int = 4

    # MLA (BailingMoeV3MultiLatentAttention)
    q_lora_rank: Optional[int] = 256
    kv_lora_rank: int = 512
    qk_nope_head_dim: int = 128
    qk_rope_head_dim: int = 64
    v_head_dim: int = 128
    rope_interleave: bool = True
    gated_attention_proj_granularity_type: Optional[str] = "head_wise"
    use_qkv_bias: bool = False
    rope_scaling: Optional[Dict[str, Any]] = None

    # KDA (BailingMoeV3KimiDeltaAttention)
    short_conv_kernel_size: int = 4
    no_kda_lora: bool = True
    kda_safe_gate: bool = True
    kda_lower_bound: Optional[float] = -5.0

    # MoE (BailingMoeV3SparseMoeBlock)
    num_experts: int = 128
    num_experts_per_tok: int = 8
    num_shared_experts: int = 1
    moe_intermediate_size: int = 512
    moe_shared_expert_intermediate_size: int = 512
    n_group: int = 8
    topk_group: int = 4
    routed_scaling_factor: float = 2.5
    norm_topk_prob: bool = True
    first_k_dense_replace: int = 1
    moe_router_enable_expert_bias: bool = True

    # tokens / heads
    tie_word_embeddings: bool = False
    num_nextn_predict_layers: int = 0

    def attention_layer_type(self, layer_idx: int) -> str:
        # Mirror BailingMoeV3DecoderLayer.__init__ exactly. The second clause
        # (layer_idx >= num//group*group) is a tail guard; for a layer count
        # divisible by the group it never fires, but keep it faithful.
        n = self.num_hidden_layers
        g = self.layer_group_size
        if (layer_idx + 1) % g == 0 or layer_idx >= n // g * g:
            return "attention"
        return "linear_attention"


# ---------------------------------------------------------------------------
# MoE
# ---------------------------------------------------------------------------
class BailingMLP(nn.Module):
    def __init__(self, args: ModelArgs, intermediate_size: Optional[int] = None):
        super().__init__()
        dim = args.hidden_size
        hidden = intermediate_size or args.intermediate_size
        self.gate_proj = nn.Linear(dim, hidden, bias=False)
        self.up_proj = nn.Linear(dim, hidden, bias=False)
        self.down_proj = nn.Linear(hidden, dim, bias=False)

    def __call__(self, x: mx.array) -> mx.array:
        return self.down_proj(swiglu(self.gate_proj(x), self.up_proj(x)))


@mx.compile
def _group_expert_select(
    gates: mx.array,
    bias: mx.array,
    top_k: int,
    n_group: int,
    topk_group: int,
    routed_scaling_factor: float,
    renormalize: bool,
) -> Tuple[mx.array, mx.array]:
    # noaux_tc / sigmoid scoring with group-limited top-k.
    # Matches BailingMoeV3Gate: score=sigmoid(logits); routing on score+bias;
    # group score = sum of top-2 per group; keep topk_group groups.
    scores = mx.sigmoid(gates.astype(mx.float32))
    orig_scores = scores
    scores = scores + bias.astype(scores.dtype)

    if n_group > 1:
        scores = mx.unflatten(scores, axis=-1, shape=(n_group, -1))
        group_scores = mx.topk(scores, 2, axis=-1).sum(axis=-1, keepdims=True)
        k = n_group - topk_group
        group_idx = mx.argpartition(group_scores, kth=k - 1, axis=-2)[..., :k, :]
        scores = mx.put_along_axis(
            scores, mx.stop_gradient(group_idx), mx.array(0.0, scores.dtype), axis=-2
        )
        scores = mx.flatten(scores, -2, -1)

    inds = mx.argpartition(-scores, kth=top_k - 1, axis=-1)[..., :top_k]
    scores = mx.take_along_axis(orig_scores, inds, axis=-1)

    if top_k > 1 and renormalize:
        scores = scores / (scores.sum(axis=-1, keepdims=True) + 1e-20)

    return inds, (scores * routed_scaling_factor).astype(gates.dtype)


class BailingSparseMoE(nn.Module):
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.args = args
        h = args.hidden_size
        self.gate = nn.Linear(h, args.num_experts, bias=False)
        self.switch_mlp = SwitchGLU(h, args.moe_intermediate_size, args.num_experts)
        self.expert_bias = mx.zeros((args.num_experts,), dtype=mx.float32)
        if args.num_shared_experts and args.num_shared_experts > 0:
            self.shared_experts = BailingMLP(
                args,
                intermediate_size=args.moe_shared_expert_intermediate_size
                * args.num_shared_experts,
            )
        else:
            self.shared_experts = None

    def __call__(self, x: mx.array) -> mx.array:
        gates = self.gate(x)
        inds, weights = _group_expert_select(
            gates,
            self.expert_bias,
            self.args.num_experts_per_tok,
            self.args.n_group,
            self.args.topk_group,
            self.args.routed_scaling_factor,
            self.args.norm_topk_prob,
        )
        y = self.switch_mlp(x, inds)
        y = (y * weights[..., None]).sum(axis=-2)
        if self.shared_experts is not None:
            y = y + self.shared_experts(x)
        return y


# ---------------------------------------------------------------------------
# MLA  (non-absorbed, q-LoRA, head-wise gate, interleaved partial rope)
# ---------------------------------------------------------------------------
class BailingMLAAttention(nn.Module):
    def __init__(self, args: ModelArgs, layer_idx: int):
        super().__init__()
        self.args = args
        self.layer_idx = layer_idx
        self.num_heads = args.num_attention_heads
        self.q_lora_rank = args.q_lora_rank
        self.kv_lora_rank = args.kv_lora_rank
        self.qk_nope_head_dim = args.qk_nope_head_dim
        self.qk_rope_head_dim = args.qk_rope_head_dim
        self.v_head_dim = args.v_head_dim
        self.q_head_dim = self.qk_nope_head_dim + self.qk_rope_head_dim  # 192

        self.scale = self.q_head_dim**-0.5

        h = args.hidden_size
        if self.q_lora_rank is None:
            self.q_proj = nn.Linear(h, self.num_heads * self.q_head_dim, bias=False)
        else:
            self.q_a_proj = nn.Linear(h, self.q_lora_rank, bias=args.use_qkv_bias)
            self.q_a_layernorm = nn.RMSNorm(self.q_lora_rank, eps=args.rms_norm_eps)
            self.q_b_proj = nn.Linear(
                self.q_lora_rank, self.num_heads * self.q_head_dim, bias=False
            )

        self.kv_a_proj_with_mqa = nn.Linear(
            h, self.kv_lora_rank + self.qk_rope_head_dim, bias=args.use_qkv_bias
        )
        self.kv_a_layernorm = nn.RMSNorm(self.kv_lora_rank, eps=args.rms_norm_eps)
        self.kv_b_proj = nn.Linear(
            self.kv_lora_rank,
            self.num_heads * (self.qk_nope_head_dim + self.v_head_dim),
            bias=False,
        )

        self.granularity = args.gated_attention_proj_granularity_type
        if self.granularity == "head_wise":
            self.g_proj = nn.Linear(h, self.num_heads, bias=False)
        elif self.granularity == "element_wise":
            self.g_proj = nn.Linear(h, self.num_heads * self.v_head_dim, bias=False)
        else:
            self.g_proj = None

        self.dense = nn.Linear(
            self.num_heads * self.v_head_dim, h, bias=args.use_qkv_bias
        )

    def _rope(self, x: mx.array, offset: int) -> mx.array:
        # rope_interleave=True -> mx.fast.rope traditional (interleaved) rotation,
        # partial rotary on the last qk_rope_head_dim dims (already sliced out).
        return mx.fast.rope(
            x,
            self.qk_rope_head_dim,
            traditional=self.args.rope_interleave,
            base=self.args.rope_theta,
            scale=1.0,
            offset=offset,
        )

    def __call__(
        self,
        x: mx.array,
        mask: Optional[mx.array] = None,
        cache: Optional[KVCache] = None,
    ) -> mx.array:
        B, L, _ = x.shape

        if self.q_lora_rank is None:
            q = self.q_proj(x)
        else:
            q = self.q_b_proj(self.q_a_layernorm(self.q_a_proj(x)))
        q = q.reshape(B, L, self.num_heads, self.q_head_dim).transpose(0, 2, 1, 3)
        q_nope, q_pe = mx.split(q, [self.qk_nope_head_dim], axis=-1)

        compressed_kv = self.kv_a_proj_with_mqa(x)
        compressed_kv, k_pe = mx.split(compressed_kv, [self.kv_lora_rank], axis=-1)
        k_pe = k_pe.reshape(B, L, 1, self.qk_rope_head_dim).transpose(0, 2, 1, 3)

        kv = self.kv_b_proj(self.kv_a_layernorm(compressed_kv))
        kv = kv.reshape(B, L, self.num_heads, -1).transpose(0, 2, 1, 3)
        k_nope, values = mx.split(kv, [self.qk_nope_head_dim], axis=-1)

        offset = cache.offset if cache is not None else 0
        q_pe = self._rope(q_pe, offset)
        k_pe = self._rope(k_pe, offset)
        k_pe = mx.repeat(k_pe, self.num_heads, axis=1)

        queries = mx.concatenate([q_nope, q_pe], axis=-1)
        keys = mx.concatenate([k_nope, k_pe], axis=-1)

        if cache is not None:
            keys, values = cache.update_and_fetch(keys, values)

        out = scaled_dot_product_attention(
            queries, keys, values, cache=cache, scale=self.scale, mask=mask
        )  # [B, H, L, v_head_dim]

        if self.g_proj is not None:
            gate = mx.sigmoid(self.g_proj(x).astype(mx.float32)).astype(out.dtype)
            if self.granularity == "head_wise":
                # gate: [B, L, H] -> [B, H, L, 1]
                gate = gate.transpose(0, 2, 1)[..., None]
            else:
                gate = gate.reshape(B, L, self.num_heads, self.v_head_dim).transpose(
                    0, 2, 1, 3
                )
            out = out * gate

        out = out.transpose(0, 2, 1, 3).reshape(B, L, -1)
        return self.dense(out)


# ---------------------------------------------------------------------------
# KDA  (Kimi Delta Attention, no-lora single f_proj/g_proj, safe-gate)
# ---------------------------------------------------------------------------
class ShortConv1d(nn.Module):
    """Depthwise causal short conv with silu, carrying a (k-1)-frame state.
    Copied structurally from kimi_linear.ShortConv1d."""

    def __init__(self, channels: int, kernel_size: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.conv = nn.Conv1d(
            in_channels=channels,
            out_channels=channels,
            kernel_size=kernel_size,
            bias=False,
            groups=channels,
            padding=0,
        )

    def __call__(
        self,
        x: mx.array,
        state: Optional[mx.array],
        mask: Optional[mx.array],
        lengths: Optional[mx.array],
    ) -> Tuple[mx.array, mx.array]:
        if mask is not None:
            x = mx.where(mask[..., None], x, 0)
        if state is None:
            state = mx.zeros(
                (x.shape[0], self.kernel_size - 1, x.shape[-1]), dtype=x.dtype
            )
        conv_input = mx.concatenate([state, x], axis=1)
        out = nn.silu(self.conv(conv_input))
        n_keep = self.kernel_size - 1
        if lengths is not None:
            ends = mx.clip(lengths, 0, x.shape[1])
            positions = (ends[:, None] + mx.arange(n_keep))[..., None]
            new_state = mx.take_along_axis(conv_input, positions, axis=1)
        else:
            new_state = mx.contiguous(conv_input[:, -n_keep:, :])
        return out, new_state


class BailingKimiDeltaAttention(nn.Module):
    def __init__(self, args: ModelArgs, layer_idx: int):
        super().__init__()
        self.args = args
        self.layer_idx = layer_idx
        self.num_heads = args.num_attention_heads
        self.head_dim = args.head_dim
        self.conv_kernel = args.short_conv_kernel_size
        self.projection_dim = self.num_heads * self.head_dim
        self.no_kda_lora = args.no_kda_lora
        self.lower_bound = args.kda_lower_bound
        self.safe_gate = args.kda_safe_gate

        h = args.hidden_size
        self.scale = float(self.head_dim) ** -0.5

        self.q_proj = nn.Linear(h, self.projection_dim, bias=False)
        self.k_proj = nn.Linear(h, self.projection_dim, bias=False)
        self.v_proj = nn.Linear(h, self.projection_dim, bias=False)

        self.q_conv = ShortConv1d(self.projection_dim, self.conv_kernel)
        self.k_conv = ShortConv1d(self.projection_dim, self.conv_kernel)
        self.v_conv = ShortConv1d(self.projection_dim, self.conv_kernel)

        # no_kda_lora=True -> single-matrix f_proj / g_proj (not the a/b lora pair)
        if self.no_kda_lora:
            self.f_proj = nn.Linear(h, self.projection_dim, bias=False)
            self.g_proj = nn.Linear(h, self.projection_dim, bias=False)
        else:
            self.f_a_proj = nn.Linear(h, self.head_dim, bias=False)
            self.f_b_proj = nn.Linear(self.head_dim, self.projection_dim, bias=False)
            self.g_a_proj = nn.Linear(h, self.head_dim, bias=False)
            self.g_b_proj = nn.Linear(self.head_dim, self.projection_dim, bias=False)

        self.b_proj = nn.Linear(h, self.num_heads, bias=False)

        self.A_log = mx.zeros((self.num_heads,))
        self.dt_bias = mx.zeros((self.projection_dim,))

        self.o_norm = nn.RMSNorm(self.head_dim, eps=args.rms_norm_eps)
        self.o_proj = nn.Linear(self.projection_dim, h, bias=False)

    def _decay(self, x: mx.array, B: int, T: int) -> mx.array:
        """Compute the KDA multiplicative decay g, shape [B, T, H, head_dim].

        fla safe-gate path (fla/ops/kda/fused_recurrent.py, USE_LOWER_BOUND):
            b_g  = f + dt_bias                          # per key-channel
            b_gk = lower_bound * sigmoid(exp(A_log) * b_g)   # log-space, <=0
            decay = exp(b_gk)
        A_log is per-head (broadcast over head_dim); dt_bias is per key-channel.
        """
        if self.no_kda_lora:
            f = self.f_proj(x)
        else:
            f = self.f_b_proj(self.f_a_proj(x))
        f = f + self.dt_bias  # [B, T, projection_dim]
        f = f.reshape(B, T, self.num_heads, self.head_dim).astype(mx.float32)
        a = mx.exp(self.A_log.astype(mx.float32)).reshape(1, 1, self.num_heads, 1)
        if self.safe_gate and self.lower_bound is not None:
            b_gk = self.lower_bound * mx.sigmoid(a * f)
        else:
            b_gk = -a * nn.softplus(f)
        return mx.exp(b_gk)  # [B, T, H, head_dim]

    def __call__(
        self,
        x: mx.array,
        mask: Optional[mx.array] = None,
        cache: Optional[Any] = None,
    ) -> mx.array:
        B, T, _ = x.shape
        dtype = x.dtype

        if cache is not None:
            q_state, k_state, v_state, ssm_state = cache[0], cache[1], cache[2], cache[3]
            lengths = cache.lengths
        else:
            q_state = k_state = v_state = ssm_state = None
            lengths = None

        if q_state is None:
            s = mx.zeros((B, self.conv_kernel - 1, self.projection_dim), dtype=dtype)
            q_state = k_state = v_state = s

        q_conv, q_state = self.q_conv(self.q_proj(x), q_state, mask, lengths)
        k_conv, k_state = self.k_conv(self.k_proj(x), k_state, mask, lengths)
        v_conv, v_state = self.v_conv(self.v_proj(x), v_state, mask, lengths)

        if cache is not None:
            cache[0], cache[1], cache[2] = q_state, k_state, v_state

        q = q_conv.reshape(B, T, self.num_heads, self.head_dim)
        k = k_conv.reshape(B, T, self.num_heads, self.head_dim)
        v = v_conv.reshape(B, T, self.num_heads, self.head_dim)

        # use_qk_l2norm_in_kernel=True: l2-normalise q,k and fold the 1/sqrt(d)
        # scale in (identical trick to kimi_linear).
        inv_scale = self.scale
        q = (inv_scale**2) * mx.fast.rms_norm(q, None, 1e-6)
        k = inv_scale * mx.fast.rms_norm(k, None, 1e-6)

        g = self._decay(x, B, T)                       # [B, T, H, head_dim]
        # beta in model dtype (matches the validated kimi kernel input combo).
        beta = mx.sigmoid(self.b_proj(x).astype(mx.float32)).astype(dtype)  # [B, T, H]

        use_kernel = (
            mx.default_device() == mx.gpu and mx.metal.is_available()
        )
        if ssm_state is None:
            ssm_state = mx.zeros(
                (B, self.num_heads, self.head_dim, self.head_dim), dtype=mx.float32
            )
        if use_kernel:
            out, ssm_state = gated_delta_kernel(q, k, v, g, beta, ssm_state, mask)
        else:
            out, ssm_state = gated_delta_ops(q, k, v, g, beta, ssm_state, mask)

        if cache is not None:
            cache[3] = ssm_state
            cache.advance(T)

        if self.no_kda_lora:
            gate = self.g_proj(x)
        else:
            gate = self.g_b_proj(self.g_a_proj(x))
        gate = gate.reshape(B, T, self.num_heads, self.head_dim)
        out = (
            self.o_norm(out.reshape(B, T, self.num_heads, self.head_dim))
            * mx.sigmoid(gate)
        ).reshape(B, T, -1)
        return self.o_proj(out)


# ---------------------------------------------------------------------------
# Decoder / model
# ---------------------------------------------------------------------------
class BailingDecoderLayer(nn.Module):
    def __init__(self, args: ModelArgs, layer_idx: int):
        super().__init__()
        self.layer_type = args.attention_layer_type(layer_idx)
        self.is_linear = self.layer_type == "linear_attention"
        if self.is_linear:
            self.attention = BailingKimiDeltaAttention(args, layer_idx)
        else:
            self.attention = BailingMLAAttention(args, layer_idx)

        if args.num_experts is not None and layer_idx >= args.first_k_dense_replace:
            self.mlp = BailingSparseMoE(args)
        else:
            self.mlp = BailingMLP(args)

        self.input_layernorm = nn.RMSNorm(args.hidden_size, eps=args.rms_norm_eps)
        self.post_attention_layernorm = nn.RMSNorm(
            args.hidden_size, eps=args.rms_norm_eps
        )

    def __call__(
        self,
        x: mx.array,
        mask: Optional[mx.array] = None,
        cache: Optional[Any] = None,
    ) -> mx.array:
        r = self.attention(self.input_layernorm(x), mask, cache)
        h = x + r
        r = self.mlp(self.post_attention_layernorm(h))
        return h + r


class BailingModel(nn.Module):
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.args = args
        self.word_embeddings = nn.Embedding(args.vocab_size, args.hidden_size)
        self.layers = [
            BailingDecoderLayer(args, i) for i in range(args.num_hidden_layers)
        ]
        self.norm = nn.RMSNorm(args.hidden_size, eps=args.rms_norm_eps)

        # mask-plumbing indices: first linear (ssm) layer and first full-attn layer
        self.ssm_idx = 0
        self.attn_idx = 0
        for i in range(args.num_hidden_layers):
            if args.attention_layer_type(i) == "linear_attention":
                self.ssm_idx = i
                break
        for i in range(args.num_hidden_layers):
            if args.attention_layer_type(i) == "attention":
                self.attn_idx = i
                break

    def __call__(self, inputs: mx.array, cache: Optional[List[Any]] = None) -> mx.array:
        h = self.word_embeddings(inputs)
        if cache is None:
            cache = [None] * len(self.layers)

        ssm_mask = create_ssm_mask(h, cache[self.ssm_idx])
        attn_mask = create_attention_mask(h, cache[self.attn_idx], return_array=True)

        for layer, c in zip(self.layers, cache):
            mask = ssm_mask if layer.is_linear else attn_mask
            h = layer(h, mask=mask, cache=c)
        return self.norm(h)


class Model(nn.Module):
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.args = args
        self.model_type = args.model_type
        self.model = BailingModel(args)
        if args.tie_word_embeddings:
            self.lm_head = None
        else:
            self.lm_head = nn.Linear(args.hidden_size, args.vocab_size, bias=False)

    def __call__(self, inputs: mx.array, cache: Optional[List[Any]] = None) -> mx.array:
        out = self.model(inputs, cache)
        if self.lm_head is None:
            return self.model.word_embeddings.as_linear(out)
        return self.lm_head(out)

    @property
    def layers(self):
        return self.model.layers

    def make_cache(self):
        caches: List[Any] = []
        for layer in self.layers:
            if layer.is_linear:
                caches.append(ArraysCache(size=4))
            else:
                caches.append(KVCache())
        return caches

    def sanitize(self, weights: Dict[str, mx.array]) -> Dict[str, mx.array]:
        # Drop MTP / multi-token-predict layers (index >= num_hidden_layers) and
        # any nextn weights; the bf16 base has num_nextn_predict_layers=0 but be
        # defensive against the int4-style layout.
        n = self.args.num_hidden_layers
        drop = []
        for k in weights:
            if k.startswith("model.mtp"):
                drop.append(k)
                continue
            if k.startswith("model.layers."):
                try:
                    li = int(k.split(".")[2])
                    if li >= n:
                        drop.append(k)
                except (IndexError, ValueError):
                    pass
        for k in drop:
            weights.pop(k, None)

        if self.args.tie_word_embeddings:
            weights.pop("lm_head.weight", None)

        for layer_idx, layer in enumerate(self.layers):
            prefix = f"model.layers.{layer_idx}"

            # MoE experts: stack per-expert {gate,up,down}_proj into switch_mlp.
            if isinstance(layer.mlp, BailingSparseMoE):
                for name in ("gate_proj", "up_proj", "down_proj"):
                    e0 = f"{prefix}.mlp.experts.0.{name}.weight"
                    if e0 in weights:
                        stacked = [
                            weights.pop(f"{prefix}.mlp.experts.{i}.{name}.weight")
                            for i in range(self.args.num_experts)
                        ]
                        weights[f"{prefix}.mlp.switch_mlp.{name}.weight"] = mx.stack(
                            stacked
                        )
                # router expert bias: checkpoint name is mlp.gate.expert_bias
                for src in (
                    f"{prefix}.mlp.gate.expert_bias",
                    f"{prefix}.mlp.gate.e_score_correction_bias",
                ):
                    if src in weights:
                        weights[f"{prefix}.mlp.expert_bias"] = weights.pop(src)

            # KDA short conv weights: HF stores conv1d as [ch,1,k]; MLX Conv1d
            # wants [ch,k,1]. Map q/k/v_conv1d.weight -> *_conv.conv.weight.
            attn = getattr(layer, "attention", None)
            if isinstance(attn, BailingKimiDeltaAttention):
                for src, dst in (
                    ("q_conv1d", "q_conv"),
                    ("k_conv1d", "k_conv"),
                    ("v_conv1d", "v_conv"),
                ):
                    sk = f"{prefix}.attention.{src}.weight"
                    if sk in weights:
                        w = weights.pop(sk)
                        if w.ndim == 3:
                            w = w.moveaxis(2, 1)  # [ch,1,k] -> [ch,k,1]
                        weights[f"{prefix}.attention.{dst}.conv.weight"] = w
                dk = f"{prefix}.attention.dt_bias"
                if dk in weights and weights[dk].ndim > 1:
                    weights[dk] = mx.reshape(weights[dk], (-1,))

        return weights

    @property
    def cast_predicate(self):
        def predicate(path: str):
            if path.endswith("expert_bias"):
                return False
            if path.endswith("A_log") or path.endswith("dt_bias"):
                return False
            return True

        return predicate

    @property
    def quant_predicate(self):
        # Match the checkpoint's own quant ignore-list intent: keep the MoE
        # router gate in higher precision.
        def predicate(path, _module):
            if path.endswith("mlp.gate"):
                return {"group_size": 64, "bits": 8}
            return True

        return predicate

"""Memory-map a model's PLE table instead of wiring it into RAM.

WHAT THIS BUYS, measured on Qwen3.8-Flash-Next-OptiQ-2bit (2026-10-03):

    resident   76.2 GiB -> 45.6 GiB   (-41%, -30.6 GiB)
    load        27.4 s  -> 10.0 s     (2.7x)
    output      byte-identical

That is the difference between this model running on a 64 GB Mac and not
running at all.

WHY IT IS FREE. The 29.8 GiB is a 320-million-row trigram lookup table (PLE,
"parallel lookup embedding"). It is a GATHER: 16 heads read one row each per
token, so a handful of kilobytes are touched while the whole table sits wired
in memory. mlx_vlm already ships the fix -- a row-addressable mmap store,
`mlx_vlm/models/qwen4_exp/ple_storage.py`, whose own docstring says "Loading
those shards as ordinary MLX parameters wires roughly 30 GiB of cold lookup
data" -- but it is OFF unless config.json names a manifest. Nothing builds that
manifest. This module does, once per checkpoint, and caches it.

WHAT WE ADD over calling the upstream builder directly:

  * a done-marker and atomic publish, so a half-built view is never used and
    the build happens once rather than every boot (the same contract as
    compressed_tensors.ensure_mlx_format, and the same shape);
  * symlink resolution -- `prepare_external_ple_model` hard-links its inputs,
    and every file in a HuggingFace snapshot is a symlink into ../../blobs, so
    the stock builder dies with FileNotFoundError on the first HF-cached model
    it meets (measured);
  * a same-device check, because a hard link cannot cross volumes and
    ~/.faxl may not be on the same disk as the HF cache;
  * completeness checking, so a checkpoint whose vision weights would be left
    behind is REFUSED rather than quietly loaded without them.

THE RULE THIS FILE OBEYS. A model we cannot prepare returns None and loads the
stock way -- slower, correct. We never return a view we have not proven carries
every non-PLE tensor the original had. A model that silently loses its vision
tower answers from a placeholder and invents the picture, which is the worst
outcome available (see faxl_proxy._is_vision_model's note).
"""

import json
import os
import shutil
import tempfile

PLE_MARKER = ".ple.ple_embedding.ngram_embedding.shards."

# The one layout mlx_vlm's mmap reader implements. Checked against the
# checkpoint rather than assumed: the OptiQ build's top-level quantisation is
# 4/64 while its PLE shards are 4/32, so reading the top level would be wrong.
_SUPPORTED = {(4, 32, "affine"), (4, 16, "nvfp4")}

# Files this module may rewrite. These are COPIED, never hard-linked: a hard
# link shares the inode, so writing through one writes the user's checkpoint.
_MUTABLE = {"model.safetensors.index.json", "config.json"}


def _is_on(name, default=True):
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() not in ("0", "false", "no", "off", "")


def _prepared_dir(model_dir):
    """Where the prepared view lives.

    Keyed on the snapshot directory name -- a commit sha in a HuggingFace
    cache, so two revisions never share a view. (exo's org--repo directories
    carry no revision; a view built from one is still correct, it just cannot
    be told apart from another revision's. Noted, not fixed here.)
    """
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "ple", os.path.basename(os.path.normpath(model_dir)))


def _config(model_dir):
    try:
        with open(os.path.join(model_dir, "config.json")) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def ple_quantization(model_dir):
    """The quantisation of this checkpoint's PLE shards, or None if it has none.

    Read from the PER-SHARD entries, never from the top level: on the OptiQ
    build the top level is 4/64 and the shards are 4/32, and only the shards'
    layout decides whether the mmap reader can serve them.
    """
    cfg = _config(model_dir)
    if not cfg:
        return None
    q = cfg.get("quantization") or (cfg.get("text_config") or {}).get("quantization") or {}
    for key, val in q.items():
        if PLE_MARKER in key and isinstance(val, dict):
            return (val.get("bits"), val.get("group_size"), val.get("mode"))
    return None


def _same_device(a, b):
    """Hard links cannot cross volumes; the builder uses os.link.

    `b` does not exist yet, so walk UP to the first parent that does -- stat'ing
    the dirname of a path whose parent is also absent reports the wrong volume
    and refuses a view that would have worked (measured: ~/.faxl/ple did not
    exist, so this compared against ~/.faxl's parent).
    """
    try:
        dev_a = os.stat(a).st_dev
    except OSError:
        return False
    d = os.path.dirname(os.path.normpath(b))
    while d and not os.path.exists(d):
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    try:
        return dev_a == os.stat(d or "/").st_dev
    except OSError:
        return False


def _resolve_symlinks_into(src, dst):
    """Copy src's tree to dst with symlinks resolved. MUTABLE FILES ARE COPIED.

    HuggingFace snapshots are entirely symlinks into ../../blobs, and
    `prepare_external_ple_model` calls os.link, which cannot link through a
    relative symlink from another directory. So they must be resolved first.

    HARD LINKS SHARE AN INODE, SO WRITING THROUGH ONE WRITES THE ORIGINAL.
    This is not a theoretical hazard: an earlier version of this file
    hard-linked `model.safetensors.index.json` into a scratch directory and
    then rewrote it, which silently corrupted the user's real checkpoint --
    the index named a file that did not exist and the model would not load.
    (2026-10-03. Recovered by hand; no weights were lost.)

    So: anything this module may MODIFY is copied, and only the large immutable
    weight files are hard-linked. The copy costs a few hundred kilobytes; the
    link saves ~74 GiB, which is the whole point of a "view".
    """
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        s_, d_ = os.path.join(src, name), os.path.join(dst, name)
        if os.path.isdir(s_) and not os.path.islink(s_):
            _resolve_symlinks_into(s_, d_)
            continue
        real = os.path.realpath(s_)
        if not os.path.exists(real):
            continue                      # a dangling link: an incomplete download
        if name in _MUTABLE or not name.endswith(".safetensors"):
            shutil.copy2(real, d_)        # never share an inode with the original
            continue
        try:
            os.link(real, d_)             # weights: immutable, link them
        except OSError:
            shutil.copy2(real, d_)        # cross-device, or a link limit


def _index_subdirs(model_dir):
    """Directories named inside the index's weight_map, e.g. {"optiq"}."""
    out = set()
    try:
        with open(os.path.join(model_dir, "model.safetensors.index.json")) as fh:
            wm = (json.load(fh) or {}).get("weight_map") or {}
    except (OSError, ValueError):
        return out
    for fn in wm.values():
        d = os.path.dirname(str(fn))
        if d:
            out.add(d)
    return out


def _tensor_keys(model_dir):
    """Every tensor name in the checkpoint, from the safetensors headers only."""
    import glob
    import struct
    names = set()
    for f in sorted(glob.glob(os.path.join(model_dir, "*.safetensors"))):
        try:
            with open(f, "rb") as fh:
                n = struct.unpack("<Q", fh.read(8))[0]
                hdr = json.loads(fh.read(n))
            names.update(k for k in hdr if k != "__metadata__")
        except (OSError, ValueError, struct.error):
            return None                   # unreadable: refuse to judge
    return names


def _view_is_complete(source, view):
    """Every non-PLE tensor of `source` must be present in `view`.

    The builder drops the shards that hold PLE. If a shard holds anything ELSE
    too -- a vision tower, say -- dropping it loses that silently, and a vision
    model without its tower answers from a placeholder. So this is checked, and
    an incomplete view is discarded rather than served.
    """
    have = _tensor_keys(view)
    want = _tensor_keys(source)
    if have is None or want is None:
        return False, "could not read the safetensors headers"
    missing = {k for k in want if PLE_MARKER not in k} - have
    if missing:
        sample = ", ".join(sorted(missing)[:3])
        return False, f"{len(missing)} non-PLE tensors would be lost (e.g. {sample})"
    return True, ""


def ensure_ple_storage(model_dir, model_id=None):
    """Prepare an mmap-PLE view of `model_dir`; return its path, or None.

    None means "load this model the stock way" -- not an error. Reasons:
    the checkpoint has no PLE, its PLE is in a layout the reader does not
    implement, the feature is switched off, or the view could not be built
    completely. Every one of those is a correct, slower load.
    """
    if not _is_on("FAXL_PLE_STORAGE"):
        return None
    model_dir = str(model_dir)
    if not os.path.isdir(model_dir):
        return None

    quant = ple_quantization(model_dir)
    if quant is None:
        return None                       # the common case: no PLE at all
    if quant not in _SUPPORTED:
        print(f"[faxl] {model_id or model_dir}: PLE is {quant}, and the mmap "
              f"reader implements {sorted(_SUPPORTED)} -- loading it resident "
              f"instead", flush=True)
        return None

    dest = _prepared_dir(model_dir)
    done = os.path.join(dest, ".faxl-ple")
    if os.path.isfile(done):
        return dest

    try:
        from mlx_vlm.models.qwen4_exp.ple_storage import (
            build_quantized_ple_manifest, prepare_external_ple_model)
    except ImportError:
        return None                       # no mlx_vlm (the linux wheel)

    if not _same_device(model_dir, dest):
        print(f"[faxl] PLE view would cross volumes ({model_dir} -> {dest}); "
              f"loading resident instead", flush=True)
        return None

    print(f"[faxl] preparing the memory-mapped PLE table for "
          f"{model_id or model_dir} (once; saves ~30 GiB of RAM) ...", flush=True)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = tempfile.mkdtemp(prefix=".ple-", dir=os.path.dirname(dest))
    try:
        # The builder hard-links, so resolve HF's symlink farm first.
        src = os.path.join(tmp, "src")
        _resolve_symlinks_into(model_dir, src)

        manifest = os.path.join(tmp, "ple-manifest.json")
        build_quantized_ple_manifest(src, manifest)

        # FLATTEN THE INDEX'S NESTED ENTRIES BEFORE BUILDING.
        #
        # The builder takes its file list from the index's weight_map and calls
        # os.link(source / name, target / name) with no makedirs, so a nested
        # name -- "optiq/optiq_vision.safetensors", which every mlx-optiq build
        # has -- raises FileNotFoundError. Pre-creating that directory does not
        # help: it then refuses the target as non-empty. Both were measured.
        #
        # So rewrite those entries to a flat name and hard-link the file under
        # it (same inode, no copy). The builder then sees a flat directory, and
        # the view's own index names the flat file, so nothing needs undoing.
        idx_path = os.path.join(src, "model.safetensors.index.json")
        if os.path.isfile(idx_path):
            with open(idx_path) as fh:
                idx = json.load(fh)
            wmap = idx.get("weight_map") or {}
            nested = {}
            for key, fname in list(wmap.items()):
                if os.path.dirname(str(fname)):
                    flat = str(fname).replace(os.sep, "__")
                    nested[flat] = str(fname)
                    wmap[key] = flat
            if nested:
                for flat, orig in nested.items():
                    f, o = os.path.join(src, flat), os.path.join(src, orig)
                    if not os.path.exists(f) and os.path.exists(o):
                        try:
                            os.link(o, f)
                        except OSError:
                            shutil.copy2(o, f)
                with open(idx_path, "w") as fh:
                    json.dump(idx, fh)

        view = os.path.join(tmp, "view")
        prepare_external_ple_model(src, view)

        # Carry across whatever lives in a subdirectory and was never named in
        # the weight_map -- the optiq metadata and sensitivity report. The
        # builder does not know about those.
        for name in sorted(os.listdir(model_dir)):
            sub = os.path.join(model_dir, name)
            if os.path.isdir(sub) and not os.path.islink(sub):
                _resolve_symlinks_into(sub, os.path.join(view, name))

        ok, why = _view_is_complete(model_dir, view)
        if not ok:
            print(f"[faxl] refusing the PLE view: {why}. Loading resident "
                  f"instead -- a model missing weights answers from a "
                  f"placeholder.", flush=True)
            return None


        # THE MANIFEST POINTS AT THE ORIGINAL CHECKPOINT, NOT THE SCRATCH COPY.
        #
        # It records byte ranges into the PLE shards and reads them at run time,
        # so `source_root` must name a directory that still exists. The builder
        # fills it in relative to wherever it was built -- our temp "src" --
        # which we then delete, and the first lookup dies with FileNotFoundError
        # on model-00001 (measured). Rewriting it to the real snapshot is what
        # makes the view durable; the original shards are never written, only
        # read, so pointing at them is safe.
        with open(manifest) as fh:
            man = json.load(fh)
        man["source_root"] = os.path.abspath(model_dir)
        with open(os.path.join(view, "ple-manifest.json"), "w") as fh:
            json.dump(man, fh)
        cfg_path = os.path.join(view, "config.json")
        with open(cfg_path) as fh:
            cfg = json.load(fh)
        target = cfg.get("text_config", cfg)
        target["ple_storage"] = {"manifest": "ple-manifest.json"}
        with open(cfg_path, "w") as fh:
            json.dump(cfg, fh, indent=2)

        with open(os.path.join(view, ".faxl-ple"), "w") as fh:
            json.dump({"source": model_dir, "quantization": list(quant)}, fh)

        # Publish atomically: a half-built view must never be loadable.
        if os.path.exists(dest):
            shutil.rmtree(dest, ignore_errors=True)
        os.replace(view, dest)
        return dest
    except Exception as exc:              # noqa: BLE001 -- a failed view is not fatal
        print(f"[faxl] could not prepare the PLE view ({type(exc).__name__}: "
              f"{exc}); loading resident instead", flush=True)
        return None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

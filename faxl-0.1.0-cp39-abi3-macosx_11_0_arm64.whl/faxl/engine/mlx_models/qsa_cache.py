"""Make Qwen3.8-Flash-Next's QSA cache serialisable, so the prefix cache works.

WHAT WAS BROKEN. Every long request on this model came back MISS, "from cache
0", "resumed at --". In the whole proxy log the largest request that had ever
written a checkpoint was 85 tokens; a 2,074-token prompt wrote nothing. Turn
settle ran after each answer and reported `resume@82 paid 1882 | ckpt +0` --
re-prefilling the whole conversation every turn and banking none of it.

So faxl's core product -- the prefix cache -- was silently inert on this model,
while working on Qwen3.6-35B, Granite and Ling. (AM, 2026-10-03: "there is no
point having a cache, if it doesnt cache!!!")

THE CAUSE, isolated. `save_prompt_cache` writes safetensors, which holds arrays
and nothing else. This model's cache is mixed:

    ArraysCache  x36  (the GDN/recurrent half)   saves fine
    QSAKVCache   x12  (the full-attention half)  RuntimeError: std::bad_cast

QSAKVCache.state is a 6-tuple, and its last element -- index_block_ratio -- is
a plain Python int:

    [0] array (1, 2, 3, 256)      keys
    [1] array (1, 2, 3, 256)      values
    [2] array (1, 3, 128)         index_keys
    [3] array (1, 3)              index_position_ids
    [4] array (1, 1, 0, 128)      index_block_keys
    [5] int                       index_block_ratio   <-- not an array

tree_flatten hands that int to mx.save_safetensors, which casts it to an array
and throws. One scalar in a 48-layer cache cost the model its entire cache.

THE FIX. mlx_lm already has the right channel for this: `meta_state`, a string
carried beside the tensors precisely so a cache can record what is not an
array. KVCache defines it and QSAKVCache inherits it unused. So this subclass
puts the scalar there and keeps the arrays where they belong -- no change to
the serialiser, no patch to mlx_vlm, and a checkpoint written by this class
reloads through the stock loader.

Registered the same way faxl already substitutes model classes
(mlx_models/__init__.py): the name is replaced before the model builds its
cache, so nothing downstream needs to know.
"""

import json


# DEFINED AT MODULE LEVEL, DELIBERATELY. faxl's vlm_cache_io rebuilds a cache
# by importing its class by qualified name, so a class nested inside a factory
# function saves fine and then cannot be loaded back:
#
#   faxl vlm_cache_io cannot rebuild
#   'faxl.engine.mlx_models.qsa_cache:_patched_class.<locals>.QSAKVCache':
#   a cache class defined inside a function cannot be imported back.
#
# The base class is resolved lazily in __init_subclass__-free fashion below:
# we cannot subclass at import time because mlx_vlm may be absent (the Linux
# line), so the module builds the subclass on first install() and binds it to
# THIS module's namespace under a stable name.
_BASE = None


def _build():
    """Create the subclass once, bound to this module under a stable name."""
    global _BASE
    from mlx_vlm.models.qwen4_exp.language import QSAKVCache as Base
    _BASE = Base

    def _state_get(self):
        """The arrays only. The scalar rides in meta_state."""
        parts = list(Base.state.fget(self))
        return tuple(p for p in parts if p is None or hasattr(p, "shape"))

    def _state_set(self, value):
        value = list(value)
        if len(value) == 5:
            value.append(getattr(self, "_faxl_block_ratio", None))
        Base.state.fset(self, tuple(value))

    def _meta_get(self):
        """The parts of the state safetensors cannot hold, as JSON."""
        return json.dumps({
            "index_block_ratio": getattr(self, "index_block_ratio", None),
        })

    def _meta_set(self, value):
        try:
            blob = json.loads(value) if value else {}
        except (TypeError, ValueError):
            blob = {}
        ratio = blob.get("index_block_ratio")
        self._faxl_block_ratio = ratio
        if ratio is not None:
            self.index_block_ratio = ratio

    cls = type("QSAKVCache", (Base,), {
        "__module__": __name__,          # so it imports back by name
        "__qualname__": "QSAKVCache",
        "state": property(_state_get, _state_set),
        "meta_state": property(_meta_get, _meta_set),
        "__doc__": "Serialisable QSA cache: identical arithmetic, the one "
                   "non-array part of the state moved to meta_state.",
    })
    globals()["QSAKVCache"] = cls        # module-level, importable by name
    return cls


def install():
    """Replace QSAKVCache with the serialisable subclass.

    A no-op when mlx_vlm is absent or the class has moved: this is a cache
    OPTIMISATION, and a line that cannot apply it simply runs without a prefix
    cache on this one model, exactly as it did before.
    """
    try:
        from mlx_vlm.models.qwen4_exp import language as _lang
    except Exception:                                      # noqa: BLE001
        return False
    if getattr(_lang, "_faxl_qsa_patched", False):
        return True
    try:
        cls = globals().get('QSAKVCache') or _build()
        _lang.QSAKVCache = cls
        # AND PUT THE NAME WHERE THE LOADER LOOKS. load_prompt_cache resolves a
        # saved cache's class by name out of mlx_lm.models.cache's own globals:
        #     globals()[c].from_state(state, meta_state)
        # QSAKVCache does not live there, so a checkpoint saved fine and then
        # failed to reload with KeyError: 'QSAKVCache'. Registering the class
        # under that module is what closes the round trip.
        import mlx_lm.models.cache as _lmcache
        setattr(_lmcache, "QSAKVCache", cls)
        # AND ArraysCache MUST COME FROM mlx_vlm TOO. The loader resolves EVERY
        # class by name from this one module, so a mixed checkpoint rebuilt
        # ArraysCache from mlx_lm -- which has no update_window and no
        # speculation support -- and the next forward died with
        # AttributeError. They are different classes with the same name
        # (issubclass is False), and mlx_vlm's is a strict superset: 22 extra
        # methods, none removed. So the vlm one is what the loader must find.
        try:
            import mlx_vlm.models.cache as _vlmcache
            if hasattr(_vlmcache, "ArraysCache"):
                setattr(_lmcache, "ArraysCache", _vlmcache.ArraysCache)
        except ImportError:
            pass
        _lang._faxl_qsa_patched = True
        return True
    except Exception as exc:                               # noqa: BLE001
        print(f"[faxl] QSA cache not made serialisable: "
              f"{type(exc).__name__}: {exc}", flush=True)
        return False

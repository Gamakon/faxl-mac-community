"""Save and load prompt caches whose classes belong to mlx_vlm.

THE FAILURE THIS FIXES. faxl wrote a 188 MB checkpoint for
Qwen3.8-Flash-Next, found it on the next request, confirmed the tokens, and
then could not read it back:

    !! BLOB LOAD FAILED @pos=2560 (not enough values to unpack
       (expected 3, got 2)) -- trying shallower

Every request fell through to cold. The cache was WRITTEN and never READ, so
the proxy paid full prefill every time AND paid the checkpoint write on top:
strictly worse than no cache at all. Measured: 0 tokens skipped across three
byte-identical 2,719-token requests.

WHY mlx_lm's VERSION CANNOT DO IT. mlx_lm.save_prompt_cache /
load_prompt_cache assume every cache object is an mlx_lm one. Two hard stops,
both load-side:

  1. `globals()[c].from_state(state)` resolves the class NAME in mlx_lm's own
     module namespace. A vision model's cache is built from mlx_vlm classes --
     for Qwen3.8-Flash-Next, 36 mlx_vlm ArraysCache + 12 QSAKVCache (which
     lives in mlx_vlm.models.qwen4_exp.language, not even in mlx_vlm's cache
     module). None of those names exist in mlx_lm, so the lookup raises
     KeyError even once the unpack is fixed.

  2. mlx_vlm's `from_state` takes TWO arguments -- `(state, meta_state)` --
     and every mlx_vlm cache carries a `meta_state` property that mlx_lm
     neither saves nor passes. mlx_lm's takes one. So the signatures are
     incompatible, not merely the namespace.

mlx_vlm ships NO save_prompt_cache/load_prompt_cache of its own (checked:
hasattr is False for both), so there is nothing upstream to delegate to. faxl
is the first thing to exercise this, because faxl is what persists these
caches.

WHAT THIS WRITES. The same safetensors shape, with the metadata carrying what
is needed to rebuild the exact classes:

    __faxl_cache_io__   "1"                 format marker
    classes             fully-qualified "module:QualName", one per layer
    meta_state          each cache's meta_state, as a string
    nones               flattened-state positions that held None
    scalars             positions that held an int/float/bool/str

The class is imported by MODULE PATH rather than looked up in a namespace, so
a cache class anywhere -- mlx_lm, mlx_vlm, or a faxl shim -- round-trips. A
file written by mlx_lm's own saver is still readable: without the marker, this
falls back to mlx_lm.load_prompt_cache unchanged.

NONE IS A REAL VALUE HERE, NOT A GAP. QSAKVCache.state is a six-tuple and its
last two members -- index_block_keys, index_block_ratio -- are legitimately
None whenever the derived index blocks have not been built or were cleared by
trim(). A saver that cannot represent None loses the distinction between "no
blocks yet" and "zero blocks", which is why the positions are recorded
explicitly instead of being dropped.
"""

import importlib

import mlx.core as mx
from mlx.utils import tree_flatten, tree_unflatten

_MARKER = "__faxl_cache_io__"
_VERSION = "1"


def _qualname(obj):
    """module:QualName, the string this module imports a class back from."""
    cls = type(obj)
    return f"{cls.__module__}:{cls.__qualname__}"


def _import_qualname(spec):
    """Resolve "module:QualName" to the class itself.

    Dotted qualnames (a nested class) are walked attribute by attribute, so a
    cache class defined inside another class still resolves.

    A class defined inside a FUNCTION carries "<locals>" in its qualname and
    cannot be re-imported by any path -- it does not exist as a module
    attribute. That is unreachable for a real cache class (every one lives at
    module level), but it must fail with the reason rather than
    AttributeError: 'function' object has no attribute '<locals>'.
    """
    module_name, _, qual = spec.partition(":")
    if "<locals>" in qual:
        raise ValueError(
            f"faxl vlm_cache_io cannot rebuild {spec!r}: a cache class defined "
            f"inside a function cannot be imported back. Define it at module "
            f"level.")
    obj = importlib.import_module(module_name)
    for part in qual.split("."):
        obj = getattr(obj, part)
    return obj


def needs_faxl_io(cache):
    """True when any cache object is NOT an mlx_lm one.

    Keyed off the defining module rather than a list of class names: a new
    mlx_vlm architecture, or a faxl shim, must be handled without an edit here.
    """
    for c in cache:
        mod = type(c).__module__ or ""
        if not mod.startswith("mlx_lm"):
            return True
    return False


def save(file_name, cache, metadata=None):
    """Write `cache` so that load() can rebuild the exact classes."""
    scalars = []
    nones = []

    def encode(item):
        pos, data = item
        if isinstance(data, mx.array):
            return (pos, data)
        if data is None:
            # Recorded, not dropped -- see the module docstring.
            nones.append(pos)
            return (pos, mx.array([]))
        if isinstance(data, bool):
            # BEFORE int: bool is a subclass of int, and round-tripping True as
            # 1 would silently change a flag's type.
            scalars.append((pos, "bool"))
            return (pos, mx.array(data))
        if isinstance(data, (int, float)):
            scalars.append((pos, "scalar"))
            return (pos, mx.array(data))
        if isinstance(data, str):
            scalars.append((pos, "string"))
            return (pos, mx.array([ord(ch) for ch in data]))
        raise ValueError(
            f"faxl vlm_cache_io cannot serialise {type(data).__name__} at "
            f"{pos!r}. Add it here rather than dropping it: a cache member "
            f"that does not round-trip is a wrong answer later.")

    flat = tree_flatten([c.state for c in cache])
    arrays = dict(map(encode, flat))

    meta = {
        _MARKER: _VERSION,
        "classes": [_qualname(c) for c in cache],
        "meta_state": [_meta_state_of(c) for c in cache],
        "nones": nones,
        "scalars": scalars,
        "metadata": metadata or {},
    }
    mx.save_safetensors(file_name, arrays, dict(tree_flatten(meta)))


def _meta_state_of(cache_obj):
    """A cache's meta_state as a string ("" when it has none).

    mlx_vlm caches all expose this and their from_state REQUIRES it; mlx_lm
    caches do not have it. Normalised to a string so the metadata stays flat.
    """
    value = getattr(cache_obj, "meta_state", "")
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        # A tuple meta_state (RotatingKVCache's shape) survives as its repr
        # only if from_state accepts that; keep it exact instead.
        return [str(v) for v in value]
    return str(value)


def _is_faxl_file(cache_metadata):
    return _MARKER in cache_metadata


def load(file_name, return_metadata=False):
    """Read a cache written by save(), or defer to mlx_lm for its own files."""
    arrays, raw_meta = mx.load(file_name, return_metadata=True)
    if not _is_faxl_file(raw_meta):
        # NOT OURS. A file mlx_lm wrote stays mlx_lm's to read, so an existing
        # store keeps working untouched.
        from mlx_lm.models.cache import load_prompt_cache
        return load_prompt_cache(file_name, return_metadata=return_metadata)

    meta = tree_unflatten([(k, v) for k, v in raw_meta.items()
                           if k != _MARKER])
    classes = _as_list(meta.get("classes"))
    meta_states = _as_list(meta.get("meta_state"))
    nones = set(_as_list(meta.get("nones")))
    scalars = meta.get("scalars") or []

    for pos in nones:
        arrays[pos] = None
    for pos, kind in _pairs(scalars):
        if pos in nones:
            continue
        value = arrays[pos]
        if kind == "scalar":
            arrays[pos] = value.item()
        elif kind == "bool":
            arrays[pos] = bool(value.item())
        elif kind == "string":
            arrays[pos] = "".join(chr(i) for i in value.tolist())
        else:
            raise ValueError(f"faxl vlm_cache_io: unknown scalar kind {kind!r}")

    states = tree_unflatten(list(arrays.items()))
    cache = []
    for spec, state, meta_state in zip(classes, states, meta_states):
        cls = _import_qualname(spec)
        cache.append(_rebuild(cls, state, meta_state))

    if return_metadata:
        return cache, meta.get("metadata", {})
    return cache


def _rebuild(cls, state, meta_state):
    """from_state across both signatures.

    mlx_vlm's is from_state(state, meta_state); mlx_lm's is from_state(state).
    Try the two-argument form first and fall back, because the two-argument
    classes REQUIRE it -- a cache rebuilt without its meta_state is silently
    missing whatever that carried.
    """
    try:
        return cls.from_state(state, meta_state)
    except TypeError:
        return cls.from_state(state)


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _pairs(scalars):
    """scalars round-trips as a list of [pos, kind] (or an empty list)."""
    out = []
    for entry in _as_list(scalars):
        if isinstance(entry, (list, tuple)) and len(entry) == 2:
            out.append((entry[0], entry[1]))
    return out

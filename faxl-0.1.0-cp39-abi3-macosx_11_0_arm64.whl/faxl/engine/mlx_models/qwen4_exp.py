"""Make the mlx-optiq Qwen3.8-Flash-Next checkpoints loadable by mlx-vlm.

THE FAILURE THIS FIXES. mlx-community/Qwen3.8-Flash-Next-OptiQ-2bit is the only
published build of this model that fits one Mac (79.9 GB on disk against a
115.4 GB Metal working set on an M3 Max; the stock 4-bit build is 111.5 GB).
Loaded as published it raises

    ValueError: Received 3239 parameters not in model:
      model.embed_tokens.biases, model.layers.0.linear_attn.A_log, ...

and if you get past that by renaming, it generates noise:

    , 1。...re0,2

Both come from the SAME cause -- the checkpoint was written by mlx-optiq, not
by mlx-vlm's converter -- and both are repairs to the weight dict, so they
belong in a sanitize hook rather than a patch to mlx-vlm.

WHAT IS ACTUALLY DIFFERENT, measured against mlx-community/Qwen3.8-Flash-Next-4bit
(the reference build, whose own README documents the correct values):

  1. THE KEY PREFIX. This build stores bare `model.*` and `lm_head.*`; mlx-vlm's
     qwen4_exp expects `language_model.model.*` / `language_model.lm_head.*`.
     mlx-vlm's sanitize_key has branches for `model.language_model*`,
     `model.visual*` and `lm_head*`, but NONE for a bare `model.*`, so those
     keys pass through untouched and load_weights rejects all 3,239.

     Remapping `model.` -> `language_model.model.` maps all 3,575 keys onto the
     4-bit build's key set with ZERO orphans, which is what says this is a
     naming difference and not a different architecture. (The 192 keys only the
     4-bit build has are `gate`/`shared_expert_gate` quantisation params; this
     build leaves those two gates unquantised, which is legal.)

  2. THE NORM GAINS ARE PRE-SHIFTED. Qwen4ExpRMSNorm stores gains centred at
     ZERO and applies `1 + w` at runtime (language.py `_qwen4_rms_norm`). This
     build folded that +1 into the saved tensors, so the model applies it twice
     -- mlx-vlm issue #2041. Subtract 1 to undo it.

     ONLY Qwen4ExpRMSNorm. Qwen4ExpRMSNormGated -- `linear_attn.norm` on the 36
     Gated DeltaNet layers -- is initialised to ONES and uses plain
     mx.fast.rms_norm with no +1, so it is already correct and de-shifting it
     CORRUPTS it. Measured, per-tensor mean, this build vs the 4-bit reference:

         attn_hyper_connection.hc_norm   +1.0359  vs  -0.0635   shifted
         self_attn.q_norm                +1.4542  vs  +0.2833   shifted
         hyper_connection_mixer.hc_norm  +3.7498  vs  +2.7497   shifted
         linear_attn.norm                +1.0239  vs  +0.9668   NOT shifted

     This cost a wrong answer once: subtracting 1 from all 184 one-dimensional
     norm tensors "fixed" 148 and broke 36, the output stayed noise, and I read
     that as "the shift is not the problem". Correcting exactly the 148 -- the
     count the 4-bit README states -- produces coherent text on the first try.

GATED ON THE SIGNATURE, NOT ON THE REPO NAME. A build that is already correct
must not be de-shifted, so the gain centre decides; a rename or a
re-quantisation of the same artifact behaves identically.
"""

import mlx.core as mx

# The Qwen4ExpRMSNorm instances, by weight-name suffix. linear_attn.norm is
# deliberately ABSENT: it is Qwen4ExpRMSNormGated, centred at one, and already
# correct. Keep this list explicit rather than matching "norm" loosely -- the
# whole bug was a too-broad match.
_SHIFTED_SUFFIXES = (
    "hc_norm.weight",
    "q_norm.weight",
    "k_norm.weight",
    "q_layernorm.weight",
    "k_layernorm.weight",
    "norm_conv.weight",
    "norm_key.weight",
    "norm_query.weight",
)

# A gated norm sits near 1.0 by construction; a DOUBLE-SHIFTED Qwen4ExpRMSNorm
# also sits near 1.0 away from zero. The reference build's real centres run from
# -0.06 to +2.75, so no single threshold separates them -- which is why the
# suffix list above, not a value test, decides WHICH tensors to touch. The
# threshold below only decides WHETHER this checkpoint was shifted at all.
_SHIFT_DETECT_MIN = 0.5


def _is_shifted_norm(key):
    """True for a Qwen4ExpRMSNorm gain in the language model."""
    if key.startswith("vision_tower"):
        return False
    return any(key.endswith(s) for s in _SHIFTED_SUFFIXES)


def remap_keys(weights):
    """Give bare `model.*` / `lm_head.*` keys the `language_model.` prefix.

    A no-op on a checkpoint that already has it, so running this against the
    stock 4-bit build changes nothing.
    """
    out = {}
    moved = 0
    for key, value in weights.items():
        if key.startswith("vision_tower.") or key.startswith("language_model."):
            out[key] = value
            continue
        if key.startswith("model.") or key.startswith("lm_head."):
            # Not model.language_model.* and not model.visual.* -- mlx-vlm's
            # own sanitize_key handles both of those.
            if not key.startswith("model.language_model") and not key.startswith(
                "model.visual"
            ):
                out["language_model." + key] = value
                moved += 1
                continue
        out[key] = value
    return out, moved


def looks_double_shifted(weights):
    """Was this checkpoint written with the +1 folded in?

    Reads the hyper-connection norms, which the reference build centres BELOW
    the shift threshold (-0.06). Returns False on any doubt: de-shifting a
    correct build is the damaging direction.
    """
    centres = []
    for key, value in weights.items():
        if key.endswith("attn_hyper_connection.hc_norm.weight"):
            try:
                if value.ndim == 1:
                    centres.append(float(mx.mean(value.astype(mx.float32))))
            except Exception:                                 # noqa: BLE001
                return False
    if not centres:
        return False
    return (sum(centres) / len(centres)) > _SHIFT_DETECT_MIN


def deshift_norms(weights):
    """Subtract the folded +1 from the Qwen4ExpRMSNorm gains. Returns the count."""
    n = 0
    for key in list(weights):
        value = weights[key]
        if _is_shifted_norm(key) and getattr(value, "ndim", 0) == 1:
            weights[key] = value - 1.0
            n += 1
    return n


def repair(weights, verbose=True):
    """Apply both repairs. Safe to run on an already-correct checkpoint."""
    weights, moved = remap_keys(weights)
    shifted = 0
    if looks_double_shifted(weights):
        shifted = deshift_norms(weights)
    if verbose and (moved or shifted):
        print(
            f"[faxl] qwen4_exp: re-prefixed {moved} keys, "
            f"de-shifted {shifted} norm gains (gated norms untouched)",
            flush=True,
        )
    return weights


def install():
    """Wrap mlx-vlm's qwen4_exp sanitize so faxl's repairs run inside load().

    Wrapping sanitize rather than load() keeps mlx-vlm's quantisation handling
    -- which reads per-path overrides off the FULL prefixed path and knows not
    to quantise the vision Conv3d -- exactly as it is. Idempotent, and a no-op
    when mlx-vlm is too old to carry qwen4_exp at all (0.4.4 does not).
    """
    try:
        from mlx_vlm.models.qwen4_exp import qwen4_exp as _mod
    except Exception:                                         # noqa: BLE001
        return False
    if getattr(_mod.Model.sanitize, "_faxl_wrapped", False):
        return True
    _inner = _mod.Model.sanitize

    def sanitize(self, weights):
        # OUR REPAIRS FIRST. mlx-vlm's sanitize splits fused expert tensors and
        # rewrites ngram shard names on keys it expects to be prefixed already,
        # so the prefix has to be right before it runs.
        weights = repair(weights)
        return _inner(self, weights)

    sanitize._faxl_wrapped = True
    _mod.Model.sanitize = sanitize
    return True

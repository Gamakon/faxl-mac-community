"""Read compressed-tensors checkpoints, which mlx_lm cannot.

THE FAILURE THIS FIXES. inclusionAI/Ling-3.0-tiny-int4 would not load at all:

    ValueError: Received 26496 parameters not in model:
      model.layers.1.mlp.experts.0.down_proj.weight_packed, ...

Nothing is corrupt. The repo ships `compressed-tensors` in its
`pack-quantized` format, where every quantised weight is THREE tensors --
`weight_packed`, `weight_scale`, `weight_shape` -- and mlx_lm's loader goes
straight to `load_weights(strict=True)`, which rejects every name it does not
recognise. Ling is a hybrid/recurrent MoE, the class faxl exists to cache
correctly, so "cannot load it" is the wrong answer.

WHAT IT ACTUALLY IS, measured on the real checkpoint (2026-10-01):

    weight_packed  [R, C/8]  int32   8 int4 values per word, LSB-first
    weight_scale   [R, C/32] bf16    one scale per group of 32
    weight_shape   [2]       int64   the logical shape; redundant, dropped

    config.json quantization_config: pack-quantized, 4 bits, int, symmetric,
    strategy "group", group_size 32.

and MLX's own affine quantisation wants exactly the same three shapes:

    weight  [R, C/8]  uint32
    scales  [R, C/32]
    biases  [R, C/32]

so THIS IS A REMAP, NOT A DEQUANTISATION. Nothing is widened to bf16 and the
5.4 GB checkpoint stays 5.4 GB. Two differences, both verified against the
real weights rather than assumed:

  1. compressed-tensors stores SIGNED int4 (-8..7, two's complement in the
     nibble). MLX stores UNSIGNED 0..15 with an affine bias. So each nibble
     gains +8 and the bias is -8*scale. Checked nibble by nibble against
     mx.quantize's own packing of the same values: identical.
  2. The nibble ORDER is the same (LSB-first), which is why only the +8
     differs. An earlier attempt put the +8 in the bias alone and left the
     nibbles signed; it decoded to garbage (max error 0.23 against a weight
     std of 0.084). The test pins the correct one.

Round trip: max |err| 4.9e-4 against a weight std of 0.084 -- bf16 rounding of
the scales, not decode error.

WHAT IS QUANTISED, and it is not everything. On Ling only the MoE experts are
compressed (8832 = 23 layers x 128 experts x 3 projections); attention,
shared experts, embeddings and lm_head ship as plain bf16, exactly as the
`ignore` list in the config says. The expert tensors are then STACKED into
`switch_mlp` by bailing_hybrid's sanitize(), which looks for
`experts.{i}.{name}.weight` -- a name this format never produces, which is the
second half of why 26,496 tensors had nowhere to go.

A FORMAT WE CANNOT READ IS A REFUSAL, NOT A GUESS. `ensure_mlx_format` returns
None for a checkpoint it does not recognise (so the stock loader runs
untouched) and RAISES, naming the format and the model, for a
compressed-tensors variant it cannot convert. It never falls through to a
loader that would bind the weights as something else: faxl_proxy's vision path
carries the same rule, for the reason written there -- a quiet wrong answer is
the worst outcome available, and on a hybrid it is a plausible wrong answer
with nothing to signal it.
"""
import glob
import json
import os
import shutil
import tempfile

# The formats this module can convert. Anything else is refused BY NAME.
_SUPPORTED_FORMAT = "pack-quantized"
_SUPPORTED_BITS = 4
_VALUES_PER_WORD = 8          # 32-bit word / 4 bits


def quantization_config(model_dir):
    """The repo's own quantisation metadata, or None.

    Detection is from the MODEL's config.json -- never the repo name. A
    renamed or re-hosted copy of the same weights must behave identically.
    """
    try:
        with open(os.path.join(model_dir, "config.json")) as fh:
            cfg = json.load(fh)
    except (OSError, ValueError):
        return None
    q = cfg.get("quantization_config") or cfg.get("compression_config")
    if not isinstance(q, dict):
        return None
    if str(q.get("quant_method", "")).lower() != "compressed-tensors":
        return None
    return q


def _group_size(q):
    """The group size, from the first config group that states one."""
    for g in (q.get("config_groups") or {}).values():
        w = (g or {}).get("weights") or {}
        if w.get("group_size"):
            return int(w["group_size"]), int(w.get("num_bits", 0)), bool(
                w.get("symmetric", True))
    return None, None, None


def _check_supported(q, model_id):
    """Raise, naming the format, unless this is a variant we have verified."""
    fmt = str(q.get("format", "")).lower()
    gs, bits, symmetric = _group_size(q)
    why = None
    if fmt != _SUPPORTED_FORMAT:
        why = f"format {fmt!r} (only {_SUPPORTED_FORMAT!r} is implemented)"
    elif bits != _SUPPORTED_BITS:
        why = f"{bits}-bit weights (only {_SUPPORTED_BITS}-bit is implemented)"
    elif not symmetric:
        why = ("asymmetric quantisation (only symmetric is implemented; an "
               "asymmetric zero-point is not the same as MLX's affine bias)")
    elif not gs or gs % _VALUES_PER_WORD:
        why = f"group_size {gs!r}"
    if why:
        raise ValueError(
            f"faxl cannot load {model_id}: it is quantised with "
            f"compressed-tensors {why}. Refusing rather than loading it as "
            f"something else -- on a hybrid model a wrong load returns a "
            f"plausible wrong answer with nothing to signal it.")
    return gs


def _unpack_int4(packed, logical_cols):
    """compressed-tensors pack-quantized int4 -> unsigned 0..15, MLX order.

    THE SIGN IS AN OFFSET, NOT TWO'S COMPLEMENT, and that is the whole bug.
    The reference implementation
    (compressed_tensors.compressors.pack_quantized.helpers.unpack_from_int32)
    ends with

        offset = 1 << (num_bits - 1)
        return (output - offset)

    so a stored nibble of 0..15 means -8..7 by SUBTRACTING 8. I first read it
    as two's complement (15 -> -1), which is the usual convention and is wrong
    here. Measured against the reference: max error 0.23 on a weight whose std
    is 0.042 -- finite, well-scaled, right shape, and completely wrong. The
    model loaded and generated the same token forever.

    MLX's affine form wants exactly that unsigned 0..15 with bias -8*scale, so
    the stored nibbles are ALREADY in MLX's convention and nothing has to be
    re-signed at all.

    The group reshape below mirrors the reference's own structure (groups of
    `num_bits` words, element i at global bit position i*num_bits). For 4-bit
    it is provably equivalent to a per-word split, because 8 values divide a
    32-bit word exactly -- verified by sabotaging it, which changed nothing.
    It is written this way so a future bit width that DOES straddle a word
    boundary (3, 5, 6) is handled by the same code rather than silently
    mis-decoded.
    """
    import numpy as np

    p = np.ascontiguousarray(np.array(packed, copy=False)).view(np.uint32)
    rows, num_words = p.shape
    words_per_group = _SUPPORTED_BITS                 # 4 words = 32 elements
    if num_words % words_per_group:
        raise ValueError(
            f"packed tensor has {num_words} words, not a multiple of "
            f"{words_per_group}; this layout is not implemented")
    groups = num_words // words_per_group
    g = p.reshape(rows * groups, words_per_group)

    elem = np.arange(32, dtype=np.int64)
    bit_start = elem * _SUPPORTED_BITS
    word_idx = bit_start // 32
    bit_off = bit_start % 32
    out = (g[:, word_idx] >> bit_off) & 0xF           # 4 bits never straddle
    return out.reshape(rows, groups * 32)[:, :logical_cols].astype(np.uint32)


def remap_packed(packed, scale, group_size=32, logical_cols=None):
    """(weight_packed, weight_scale) -> (wq, scales, biases) in MLX's layout.

    `packed` is int32 [R, C/8], `scale` is [R, C/32]. Returns mx arrays ready
    for a quantised MLX module: nothing is widened to bf16, so a 5.4 GB
    checkpoint stays 5.4 GB.
    """
    import numpy as np
    import mlx.core as mx

    sc = np.array(mx.array(scale).astype(mx.float32), copy=False)
    cols = logical_cols if logical_cols is not None else sc.shape[1] * group_size
    u = _unpack_int4(packed, cols)                     # unsigned 0..15

    rows, c = u.shape
    u = u.reshape(rows, c // _VALUES_PER_WORD, _VALUES_PER_WORD)
    out = np.zeros((rows, c // _VALUES_PER_WORD), dtype=np.uint32)
    for i in range(_VALUES_PER_WORD):
        out |= (u[:, :, i] & 0xF) << (4 * i)

    return (mx.array(out),
            mx.array(sc).astype(mx.bfloat16),
            mx.array(-8.0 * sc).astype(mx.bfloat16))


def _converted_dir(model_dir):
    """Where a converted copy of this snapshot lives.

    Keyed on the SNAPSHOT directory name, which for a HuggingFace cache is the
    commit sha -- so two revisions of the same repo never share a conversion.
    """
    from faxl.engine import faxl_config
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "converted", os.path.basename(
        os.path.normpath(model_dir)))


def ensure_mlx_format(model_dir, model_id=None):
    """Convert a compressed-tensors checkpoint; return the new dir, or None.

    None means "not this format, use the stock loader" -- NOT "something went
    wrong". A format we recognise but cannot convert raises.

    The conversion is written ONCE and reused: it is the same size as the
    original, and re-doing it on every boot would add minutes to a restart.
    """
    model_dir = str(model_dir)
    if not os.path.isdir(model_dir):
        return None
    q = quantization_config(model_dir)
    if q is None:
        return None                      # the common case: nothing to do
    gs = _check_supported(q, model_id or model_dir)

    dest = _converted_dir(model_dir)
    done = os.path.join(dest, ".faxl-converted")
    if os.path.isfile(done):
        return dest

    print(f"converting {model_id or model_dir} from compressed-tensors "
          f"(this happens once) ...", flush=True)
    _convert(model_dir, dest, gs)
    with open(done, "w") as fh:
        fh.write(json.dumps({"source": model_dir, "group_size": gs}) + "\n")
    return dest


def _convert(src, dest, group_size):
    """Write an MLX-format copy of `src` into `dest`.

    Atomic at the directory level: everything is built in a sibling temp dir
    and renamed into place, so an interrupted conversion never leaves a
    half-written snapshot that the `.faxl-converted` marker would bless.
    """
    import numpy as np
    import mlx.core as mx
    from safetensors import safe_open
    import mlx.core as _mx_io

    # READ AND WRITE THROUGH MLX, NOT NUMPY. The scales are bf16 and numpy has
    # no such dtype: safetensors' numpy reader raises
    # "data type 'bfloat16' not understood" on the first scale tensor. mx.load
    # / mx.save_safetensors handle bf16 natively, which is also what mlx_lm
    # will read the result with.

    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    tmp = tempfile.mkdtemp(prefix=".faxl-converting-",
                           dir=os.path.dirname(dest) or ".")
    try:
        # Everything that is not a weight file: config, tokenizer, template.
        for name in os.listdir(src):
            if name.endswith(".safetensors") or name.endswith(".index.json"):
                continue
            s = os.path.join(src, name)
            if os.path.isfile(s):
                shutil.copy2(s, os.path.join(tmp, name))

        shards = sorted(glob.glob(os.path.join(src, "*.safetensors")))
        index = {}
        for n, shard in enumerate(shards):
            out = {}
            w = _mx_io.load(shard)
            keys = list(w)
            bases = {k[:-len(".weight_packed")] for k in keys
                     if k.endswith(".weight_packed")}
            for k in keys:
                if k.endswith(".weight_shape"):
                    continue                  # redundant: implied by the shapes
                if k.endswith((".weight_packed", ".weight_scale")):
                    continue                  # handled per base below
                out[k] = w[k]
            for b in sorted(bases):
                wq, sc, bi = remap_packed(w[b + ".weight_packed"],
                                          w[b + ".weight_scale"], group_size)
                out[b + ".weight"] = wq
                out[b + ".scales"] = sc
                out[b + ".biases"] = bi
            name = os.path.basename(shard)
            _mx_io.save_safetensors(os.path.join(tmp, name), out,
                                    metadata={"format": "pt"})
            for k in out:
                index[k] = name
            del w, out
            print(f"  shard {n + 1}/{len(shards)}", flush=True)

        with open(os.path.join(tmp, "model.safetensors.index.json"), "w") as fh:
            json.dump({"metadata": {}, "weight_map": index}, fh)

        # The quantisation block now describes MLX's layout, not the source's:
        # mlx_lm reads it to decide how to build the quantised modules.
        cpath = os.path.join(tmp, "config.json")
        with open(cpath) as fh:
            cfg = json.load(fh)
        cfg.pop("compression_config", None)
        cfg["quantization"] = {"group_size": group_size,
                               "bits": _SUPPORTED_BITS, "mode": "affine"}
        cfg["quantization_config"] = dict(cfg["quantization"])
        with open(cpath, "w") as fh:
            json.dump(cfg, fh, indent=2)

        # Into place as ONE rename, so a crash mid-convert leaves no snapshot
        # for the marker file to bless.
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(tmp, dest)
        tmp = None
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)

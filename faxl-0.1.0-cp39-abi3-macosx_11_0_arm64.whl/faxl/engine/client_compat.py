# Vendored engine module (client_compat.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""OpenAI-compatibility rules that let stock agent clients work unmodified.

WHY THIS FILE EXISTS. faxl was made to work with MiniMax Code by patching the
CLIENT: a fork that coerced tool arguments, sent a Qwen-specific thinking
flag, and set a faxl-only User-Agent. Every one of those was faxl's gap, not
the client's, and none of it helped the next client. Hermes Agent, installed
clean and pointed at faxl with `provider: custom`, then failed the same ways:

  * reasoning leaked into the visible reply as "...\\n</think>\\n\\nanswer",
    because Qwen's template opens <think> in the PROMPT and faxl returned the
    raw decode as `content`;
  * `reasoning_effort: "none"` (the standard OpenAI field Hermes sends for its
    title and other side calls) was ignored, so a one-line title ran 11,784
    tokens / 128 s of thinking while holding the serve lock;
  * Qwen3.6 tool arguments all came back as STRINGS -- `"timeout": "120"`,
    `"todos": "[...]"` -- because <parameter=k>v</parameter> carries no type.
    The tool schema the client sent says what each one should be;
  * both clients were labelled "other" in the console.

Everything here is pure (no model, no Flask) so the suite can import it.
"""
import json
import re

# ---- THINKING ON / OFF ------------------------------------------------------

_EFFORT_OFF = ("none", "off", "disabled", "minimal", "false", "0")


# Clients whose silence about thinking is itself an answer. Stock MiniMax Code
# (User-Agent "MiniMaxCode") sends reasoning_effort on every request while its
# thinking switch is ON, and NOTHING when it is OFF -- measured 2026-10-13 on
# 0.6.9: switch on -> {"reasoning_effort": "medium", ...}; switch off ->
# {"max_completion_tokens": 16384} alone. Read as "unspecified", the off
# switch fell through to Qwen's template default and the model thought anyway,
# which is the "Thinking Off in the status bar, thinking on the wire" bug a fork
# of the client was patched for. Only clients measured to behave this way are
# listed; anyone else's silence still means "the model's default".
_SILENCE_MEANS_OFF = ("minimaxcode",)


def thinking_requested(body, user_agent=""):
    """True / False if the request says whether to think, else None.

    Every shape a stock client is known to send, faxl-specific ones first so
    an explicit flag always wins over a generic effort level:
      enable_thinking                       (faxl, Qwen/vLLM convention)
      chat_template_kwargs.enable_thinking  (vLLM / SGLang)
      reasoning_effort                      (OpenAI; Hermes sends this)
      reasoning: {effort|enabled}           (OpenRouter-style)
      thinking: {type: enabled|disabled}    (Anthropic-style, some gateways)
    and, last, silence from a client in _SILENCE_MEANS_OFF reads as False.
    """
    said = _thinking_said(body)
    if said is None and any(c in (user_agent or "").lower()
                            for c in _SILENCE_MEANS_OFF):
        return False
    return said


def _thinking_said(body):
    if not isinstance(body, dict):
        return None
    v = body.get("enable_thinking")
    if v is not None:
        return bool(v)
    v = (body.get("chat_template_kwargs") or {}).get("enable_thinking")
    if v is not None:
        return bool(v)
    eff = body.get("reasoning_effort")
    r = body.get("reasoning")
    if eff is None and isinstance(r, dict):
        if r.get("enabled") is not None:
            return bool(r["enabled"])
        eff = r.get("effort")
    if eff is not None:
        return str(eff).strip().lower() not in _EFFORT_OFF
    t = body.get("thinking")
    if isinstance(t, dict) and t.get("type"):
        return str(t["type"]).lower() != "disabled"
    return None


# ---- REQUEST SHAPE ------------------------------------------------------------

def normalize_roles(messages):
    """Messages with OpenAI's newer "developer" role read as "system".

    OpenAI renamed the system role for its reasoning models, and current
    clients (stock MiniMax Code 0.6.9) send it. Chat templates only know
    "system": Qwen3.6's raised "Unexpected message role" and the run failed
    after six retries. Leading system messages are then merged into one,
    because templates accept a system message only at the start.
    """
    out = []
    for m in messages or []:
        if isinstance(m, dict) and m.get("role") == "developer":
            m = dict(m, role="system")
        if (isinstance(m, dict) and m.get("role") == "system" and out
                and all(x.get("role") == "system" for x in out)):
            prev = out[-1]
            out[-1] = dict(prev, content=_text(prev.get("content")) + "\n\n"
                           + _text(m.get("content")))
            continue
        out.append(m)
    return out


def _text(c):
    if isinstance(c, list):
        # `or ""`: a part may carry "text": None (a picture part does), and
        # get("text", "") returns that None -- a 500 on the agent-name read,
        # caught by faxl-core's client-errors corpus (2026-10-14).
        return "\n".join((p.get("text") or "") if isinstance(p, dict)
                         else str(p) for p in c)
    return "" if c is None else str(c)


def max_tokens_requested(body):
    """The output cap, under either name OpenAI has used for it, else None."""
    for key in ("max_completion_tokens", "max_tokens", "max_output_tokens"):
        v = (body or {}).get(key)
        if v is not None:
            try:
                return int(v)
            except (TypeError, ValueError):
                pass
    return None


# ---- REASONING OUT OF CONTENT ----------------------------------------------

OPEN, CLOSE = "<think>", "</think>"


def prompt_opens_thinking(prompt_text):
    """Did the chat template end the prompt inside an open <think> block?

    Qwen3.x puts "<think>\\n" at the end of the generation prompt, so the
    model's reply begins mid-thought and contains only the closing tag. With
    thinking OFF the same template emits "<think>\\n\\n</think>\\n\\n", which is
    closed and must not be treated as open.
    """
    tail = (prompt_text or "")[-64:]
    i = tail.rfind(OPEN)
    return i >= 0 and CLOSE not in tail[i:]


def split_reasoning(text, think_open=False):
    """(reasoning, content) from a complete decode.

    Reasoning is recognised only at the START of the reply -- either the
    prompt left a <think> open, or the reply itself opens with one. A reply
    that merely mentions the tag later in prose is left untouched.
    """
    if not isinstance(text, str):
        return "", text
    s = text.lstrip()
    if s.startswith(OPEN):
        s = s[len(OPEN):]
    elif not think_open:
        return "", text
    if CLOSE not in s:
        # Still thinking when generation stopped (length cap / cancel). All of
        # it is reasoning; there is no answer to show.
        return s.strip(), ""
    reasoning, _, content = s.partition(CLOSE)
    return reasoning.strip(), content.lstrip()


class ReasoningStream:
    """Incremental twin of split_reasoning for SSE.

    feed(full_text_so_far) returns the new (reasoning_delta, content_delta).
    Text that could be the start of a split "</think>" is held back until the
    next feed, so a tag cut across two decodes never leaks into either field.
    """

    def __init__(self, think_open=False):
        self.mode = "undecided" if not think_open else "reasoning"
        self.r_sent = 0       # chars of reasoning already emitted
        self.c_sent = 0       # chars of content already emitted
        self.body_at = 0      # index in text where reasoning starts
        self.content_at = None

    def feed(self, text, final=False):
        if self.mode == "undecided":
            s = text.lstrip()
            if s.startswith(OPEN):
                self.mode = "reasoning"
                self.body_at = text.index(OPEN) + len(OPEN)
            elif len(s) >= len(OPEN) or (s and not OPEN.startswith(s)) or final:
                self.mode = "content"
                self.content_at = 0
            else:
                return "", ""          # could still become "<think>"
        r_delta = ""
        if self.mode == "reasoning":
            j = text.find(CLOSE, self.body_at)
            if j >= 0:
                r_end = j
                self.mode = "content"
                self.content_at = j + len(CLOSE)
            else:
                r_end = len(text) if final else _safe_end(text, self.body_at)
            body = text[self.body_at:r_end]
            if self.r_sent == 0:
                body_l = body.lstrip()
                self.body_at += len(body) - len(body_l)
                body = body_l
            r_delta = body[self.r_sent:]
            self.r_sent += len(r_delta)
            if self.mode == "reasoning":
                return r_delta, ""
        c = text[self.content_at:]
        if self.c_sent == 0:
            stripped = c.lstrip()
            if not stripped and not final:
                return r_delta, ""
            self.content_at += len(c) - len(stripped)
            c = stripped
        c_delta = c[self.c_sent:]
        self.c_sent += len(c_delta)
        return r_delta, c_delta


def _safe_end(text, start):
    """End of the span that cannot be the beginning of a split CLOSE tag."""
    for k in range(min(len(CLOSE) - 1, len(text) - start), 0, -1):
        if CLOSE.startswith(text[-k:]):
            return len(text) - k
    return len(text)


# ---- TOOL ARGUMENTS TO THE TYPES THE SCHEMA ASKS FOR -------------------------

def _types(schema):
    t = (schema or {}).get("type")
    if isinstance(t, list):
        return t
    if t:
        return [t]
    out = []
    for key in ("anyOf", "oneOf"):
        for sub in (schema or {}).get(key) or []:
            out += _types(sub)
    return out


def _coerce(value, schema):
    """value converted toward schema; unchanged when no safe conversion exists.

    Only strings are rewritten, and only when the result has exactly the
    shape the schema asks for -- anything else is left for the client's own
    validator to reject loudly.
    """
    if not isinstance(value, str) or not isinstance(schema, dict):
        if isinstance(value, dict) and isinstance(schema, dict):
            return coerce_arguments(value, schema)
        if isinstance(value, list) and isinstance(schema, dict):
            item = schema.get("items")
            return [_coerce(v, item) for v in value] if isinstance(item, dict) else value
        return value
    want = _types(schema)
    if not want or "string" in want:
        return value
    s = value.strip()
    if "integer" in want:
        try:
            return int(s)
        except ValueError:
            pass
    if "number" in want:
        try:
            f = float(s)
            return int(f) if f.is_integer() and "." not in s and "e" not in s.lower() else f
        except ValueError:
            pass
    if "boolean" in want and s.lower() in ("true", "false"):
        return s.lower() == "true"
    if "null" in want and s.lower() in ("null", "none", ""):
        return None
    if "array" in want or "object" in want:
        try:
            parsed = json.loads(s)
        except ValueError:
            return value
        if ("array" in want and isinstance(parsed, list)) or \
           ("object" in want and isinstance(parsed, dict)):
            return _coerce(parsed, schema)
    return value


def coerce_arguments(args, schema):
    """A tool-call argument dict with each value fitted to its property schema."""
    if not isinstance(args, dict) or not isinstance(schema, dict):
        return args
    props = schema.get("properties") or {}
    return {k: _coerce(v, props.get(k)) for k, v in args.items()}


def fit_tool_calls(tool_calls, tools):
    """Rewrite each call's JSON `arguments` against the tool the client sent."""
    if not tool_calls or not tools:
        return tool_calls
    schemas = {}
    for t in tools:
        fn = (t or {}).get("function") or {}
        if fn.get("name"):
            schemas[fn["name"]] = fn.get("parameters") or {}
    for tc in tool_calls:
        fn = tc.get("function") or {}
        schema = schemas.get(fn.get("name"))
        if schema is None:
            continue
        try:
            args = json.loads(fn.get("arguments") or "{}")
        except ValueError:
            continue
        fixed = coerce_arguments(args, schema)
        if fixed != args:
            fn["arguments"] = json.dumps(fixed)
    return tool_calls


# ---- WHO IS CALLING ---------------------------------------------------------

# Matched as substrings of the lowercased User-Agent. Stock clients first:
# MiniMax Code sends "MiniMaxCode", Hermes sends the OpenAI SDK's own UA.
CLIENT_LABELS = ("openclaw", "hermes", "faxleet", "minimaxcode", "mcode",
                 "curl", "wget", "python-requests", "claude", "lynx", "w3m")

# A generic SDK UA says nothing about the agent behind it. These are checked
# against the start of the first system message instead: a stable identity
# line every request from that agent's main loop carries.
_SYSTEM_SIGNATURES = (("you are hermes agent", "hermes"),)


def client_label(ua, messages=None):
    """Coarse client category -- never the raw UA (linkable PII)."""
    low = (ua or "").lower()
    for name in CLIENT_LABELS:
        if name in low:
            return "minimaxcode" if name == "mcode" else name
    for m in messages or ():
        if isinstance(m, dict) and m.get("role") in ("system", "developer"):
            c = m.get("content")
            if isinstance(c, list):
                c = " ".join((p.get("text") or "") for p in c
                             if isinstance(p, dict))
            head = str(c or "")[:200].lower()
            for sig, name in _SYSTEM_SIGNATURES:
                if sig in head:
                    return name
            break
    if "openai/" in low:
        return "openai-sdk"
    return "other" if low else ""


# ---- WHICH AGENT A REQUEST IS FOR --------------------------------------------
#
# Stock MiniMax Code opens the first user message of every request with an
# <agent-context> block naming the agent it is running:
#     agent: advisor  # display name
#     agentName: advisor  # routing ID
# The main session is "mavis"; a sub-agent (an advisor, a reviewer) is itself.
# That is how faxl can tell a person "your advisor asked for a different model"
# rather than "a request did" (measured on 0.6.9, 2026-10-13).
_AGENT_NAME = re.compile(r"^\s*agentName:\s*([A-Za-z0-9_.-]+)", re.M)


def agent_name(messages):
    """The agent this request is for, if the client says, else None."""
    for m in messages or ():
        if isinstance(m, dict) and m.get("role") == "user":
            c = _text(m.get("content"))
            if "<agent-context>" not in c:
                return None
            got = _AGENT_NAME.search(c.split("</agent-context>", 1)[0])
            return got.group(1) if got else None
    return None


# What a person calls each client, by client_label().
CLIENT_NAMES = {"minimaxcode": "MiniMax Code", "hermes": "Hermes",
                "openclaw": "OpenClaw", "claude": "Claude Code",
                "faxleet": "faxleet"}


def clash_message(client, agent, wanted, loaded):
    """What a person reads when a request asks for a model faxl will not
    switch to, because another session is using the loaded one.

    Written for the person, not for a log: say sorry, say what happened in
    their terms (their client, their agent, the two models by the names they
    configured), then the easiest fix first. Wording agreed with AM,
    2026-10-13.
    """
    who = CLIENT_NAMES.get(client or "")
    if who and agent:
        return (f"Sorry - {who} asked for the {agent} to run on {wanted}, but "
                f"your main session is using {loaded}, and faxl can only run "
                f"one model at a time.\n\n"
                f"The easiest fix is to let the {agent} use the same model as "
                f"your session: just remove the model line from the {agent}'s "
                f"settings. If you'd rather use {wanted} for everything, switch "
                f"to it in the faxl console first.")
    asker = who or "This request"
    return (f"Sorry - {asker} asked for {wanted}, but another session is using "
            f"{loaded}, and faxl can only run one model at a time.\n\n"
            f"The easiest fix is to use {loaded} here too. If you'd rather use "
            f"{wanted} for everything, switch to it in the faxl console first.")

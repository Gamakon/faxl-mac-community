# Vendored engine module (faxl_licence.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Licence key handling for the console paste field — validate, decode, persist.

ONE definition of "apply a pasted key", shared by the console's POST /api/licence
and by faxl_mcp's faxl_install_licence, so the two cannot drift on what counts as
a valid key or how the file is written.

Three things live here and nowhere else:

  normalise()  what a mail client did to the key, undone.
  classify()   the wheel's ValueError -> which failure it was. The console's red
               banner has to say WHICH thing went wrong (Malformed is a
               recoverable paste error, BadSignature is not, Expired is a
               renewal and must never read as "invalid"), and the wheel does not
               make that easy -- see classify() for why.
  write_key()  atomic, mode 600. It is a bearer token, and an interrupted write
               that leaves half a key breaks the next boot.

WHY THE DECODE IS HERE AND NOT IN THE WHEEL: licence::Licence carries tier,
seats, features and issued, but the pyo3 bindings return only
(customer, expiry, action). The console has to render what the key grants, so
the payload is decoded here -- but ONLY after the wheel's set_licence() has
returned Ok on the identical string, so what is rendered is the bytes the wheel
verified, never unverified content. Reported to faxl-mac-community: a
parse_licence() that validates without installing would let this file delete
both the decoder and the expiry dance in apply_key().
"""
import base64
import json
import os
import tempfile
import time

# The wheel raises a bare ValueError for every bad key, so the only thing
# separating "truncated in transit" from "not a faxl key" is the message text.
# These are the two prefixes licence.rs produces (Invalid::Display).
_MALFORMED_PREFIX = "malformed licence: "
_BADSIG_TEXT = "licence signature does not verify"

MALFORMED = "malformed"
BAD_SIGNATURE = "bad_signature"
EXPIRED = "expired"
UNKNOWN = "unknown"


def licence_path():
    """The file the startup path reads. `FAXL_LICENCE` overrides it.

    NOT ~/.faxl/licence.key -- that path appears in T-0004's "Done when" and
    was on faxl.ai's install page, and is wrong. exo_store.py, faxl_proxy.py
    and faxl_mcp.py all read this one.
    """
    return os.path.expanduser(os.environ.get("FAXL_LICENCE", "~/.faxl-licence"))


def normalise(raw):
    """A pasted key, cleaned of what a mail client did to it.

    The key is one long base64url line with a '.' in it, and neither half can
    contain whitespace -- so every space and newline inside it is damage from
    wrapping, and stripping them is safe rather than lossy. Leading '#' comment
    lines are dropped because the file reader already ignores them, so a
    customer who pastes the contents of a key file gets the same answer as one
    who pastes the key.
    """
    lines = [ln for ln in (raw or "").splitlines() if not ln.strip().startswith("#")]
    return "".join(lines).strip().replace(" ", "").replace("\t", "")


def classify(exc):
    """Which failure the wheel's ValueError actually was.

    Returns (kind, detail). Matching on message text is brittle -- a reworded
    Rust string silently reclassifies a customer-facing banner -- but the
    bindings collapse Invalid::Malformed and Invalid::BadSignature into the
    same PyValueError, so the text is the only signal there is. An unrecognised
    message is reported as UNKNOWN with the raw text rather than being forced
    into one of the two buckets: a wrong specific banner is worse than an
    honest vague one.
    """
    msg = str(exc)
    if msg.startswith(_MALFORMED_PREFIX):
        return MALFORMED, msg[len(_MALFORMED_PREFIX):]
    if msg == _BADSIG_TEXT:
        return BAD_SIGNATURE, msg
    return UNKNOWN, msg


def decode_payload(key):
    """The signed payload, decoded. Call ONLY on a key the wheel accepted.

    Returns a dict of what the key grants. The signature covers these exact
    bytes, so this is the same content the shop's account page renders.
    Never raises: a key the wheel verified but this cannot read yields
    {} rather than failing the paste -- the entitlement is live either way,
    and a display gap must not look like a bad key.
    """
    try:
        payload_b64 = key.split(".", 1)[0]
        pad = "=" * (-len(payload_b64) % 4)
        text = base64.urlsafe_b64decode(payload_b64 + pad).decode("utf-8")
    except Exception:  # noqa: BLE001 -- display only; the key is already valid
        return {}
    if text.lstrip().startswith("{"):
        return _decode_json(text)
    return _decode_legacy(text)


def _decode_json(text):
    try:
        d = json.loads(text)
    except ValueError:
        return {}
    if not isinstance(d, dict):
        return {}
    out = {"format": "json"}
    for name in ("customer", "tier", "action", "product"):
        v = d.get(name)
        if isinstance(v, str) and v:
            out[name] = v
    for name in ("issued", "expiry", "seats"):
        v = d.get(name)
        if isinstance(v, bool):
            continue
        if isinstance(v, (int, float)):
            out[name] = int(v)
    feats = d.get("features")
    if isinstance(feats, list):
        # Unknown names are kept verbatim, as licence.rs does -- an older
        # console must not drop a feature it has never heard of.
        out["features"] = [f for f in feats if isinstance(f, str)]
    return out


def _decode_legacy(text):
    """`customer|issued|expiry|action`. Not deprecated; still issued."""
    f = text.split("|")
    if len(f) < 3:
        return {}
    out = {"format": "legacy", "customer": f[0]}
    for name, raw in (("issued", f[1]), ("expiry", f[2])):
        try:
            out[name] = int(raw)
        except ValueError:
            pass
    if len(f) > 3 and f[3]:
        out["action"] = f[3]
    return out


def as_status(status):
    """Normalise a licence status into a dict, whichever shape arrived.

    TWO SHAPES ARE LIVE and they are easy to mix up, because the names match:

      faxl.licence_status()   -> (licensed, customer, expiry, remaining, action)
      Licence.status()        -> {"licensed", "customer", "expiry",
                                  "days_remaining", "on_expiry"}

    faxl_proxy injects the DICT (the console's overview screen already reads it
    that way). Callers that hold the wheel directly have the TUPLE. Accepting
    only one of them silently 500s the licence page on whichever host passes
    the other -- which is exactly what happened here: every test injected the
    tuple while the proxy sends the dict.

    Returns None for None, so "no status available" stays distinguishable from
    "unlicensed".
    """
    if status is None:
        return None
    if isinstance(status, dict):
        return status
    live, cust, exp, remaining, action = status
    return {"licensed": bool(live), "customer": cust, "expiry": exp,
            "days_remaining": round(remaining / 86400.0, 1),
            "on_expiry": action}


def grant(key, status=None, info=None):
    """What a validated key grants, for the read-only view.

    `info` is faxl.parse_licence()'s dict when the wheel has it. PREFER IT:
    those fields come from the same Rust reader that verifies the signature,
    so there is one parser rather than two that can drift. The Python decode
    below exists only for wheels without parse_licence, where tier/seats/
    features/issued are otherwise unreachable from Python.

    `status` is the licence status (either shape); its expiry and remaining
    come from the wheel's ratcheted clock, which is the one that decides
    entitlement, so it wins over the payload's own number.

    seats is carried through as a plain count. It is ADVISORY: verification is
    offline with no phone-home, so a key copied to a second machine counts from
    zero. It records what was bought. Callers must not render it as a limit --
    no "N of M used", no progress bar.
    """
    g = decode_payload(key)
    if info:
        # The Rust reader wins on every field it carries.
        for name in ("customer", "tier", "action", "product"):
            v = info.get(name)
            if isinstance(v, str) and v:
                g[name] = v
        for name in ("issued", "expiry", "seats"):
            v = info.get(name)
            if isinstance(v, int) and not isinstance(v, bool):
                g[name] = v
        feats = info.get("features")
        if isinstance(feats, (list, tuple)):
            g["features"] = [f for f in feats if isinstance(f, str)]
        if info.get("seconds_remaining") is not None:
            g["days_remaining"] = round(info["seconds_remaining"] / 86400.0, 1)
        g["licensed"] = not info.get("expired", False)
    st = as_status(status)
    if st is not None:
        g["licensed"] = bool(st.get("licensed"))
        if st.get("customer"):
            g["customer"] = st["customer"]
        if st.get("expiry"):
            g["expiry"] = int(st["expiry"])
        if st.get("days_remaining") is not None:
            g["days_remaining"] = st["days_remaining"]
        g["on_expiry"] = st.get("on_expiry", "")
    elif "expiry" in g:
        g["days_remaining"] = round((g["expiry"] - time.time()) / 86400.0, 1)
    g["seats_advisory"] = True
    return g


def write_key(key, path=None):
    """Persist a validated key: atomic, mode 600.

    Atomic because an interrupted write that left half a key would break the
    next boot -- the customer's cache would silently go cold and the file would
    look fine. 600 before any bytes are written, not after, so the key is never
    briefly world-readable.

    Raises OSError on failure. Callers must NOT treat that as a bad key: at
    that point the key is already live in the process, and the honest thing to
    report is "applied, but will not survive a restart".
    """
    path = path or licence_path()
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".faxl-licence-", suffix=".tmp")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(key + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path


def read_key(path=None):
    """The stored key, normalised, or "" when there is no readable file."""
    try:
        return normalise(open(path or licence_path()).read())
    except OSError:
        return ""


def apply_key(raw, set_licence, licence_status=None, path=None, persist=True,
              parse_licence=None):
    """Validate a pasted key, apply it live, then persist it. The whole flow.

    Returns (ok, result). On failure result is {"error": {"type", "message"}}
    where type is one of MALFORMED / BAD_SIGNATURE / EXPIRED / UNKNOWN -- the
    console turns that into a banner that says which thing went wrong.

    ORDERING: nothing is installed and nothing is written unless the key both
    verifies AND is in term. A key failing either must never reach the file the
    next boot reads.

    WHY parse_licence MATTERS. licence.rs::parse() verifies the signature and
    reads the fields; it never compares expiry to the clock. So an expired but
    genuinely signed key does NOT raise -- set_licence returns Ok and INSTALLS
    it, replacing whatever entitlement was live. A customer with a working
    licence who pasted an old key would turn their own cache off, in a UI that
    had just offered to check the key for them.

    `parse_licence` validates WITHOUT touching the entitlement and reports
    `expired` against the same ratcheted clock the gate uses, so a lapsed key
    is refused before anything is installed. That is the ordering the ticket
    asks for, and it is the path taken whenever the wheel provides it.

    Older wheels have no such call, so the fallback repairs after the fact:
    install, notice the lapse, put the previous key back. That leaves a window
    where the wrong entitlement is live and can fail outright if the stored key
    is unreadable -- hence `previous_licence_restored`, which reports whether
    the repair actually worked rather than assuming it did.
    """
    key = normalise(raw)
    if not key:
        return False, {"error": {
            "type": MALFORMED,
            "message": "No key was pasted. Copy the whole key from your "
                       "licence email, including the part after the dot."}}

    previous = read_key(path) if persist else ""

    # ---- preferred path: look before installing -----------------------------
    if parse_licence is not None:
        try:
            info = parse_licence(key)
        except ValueError as e:
            kind, detail = classify(e)
            return False, {"error": {"type": kind, "message": detail}}
        if info.get("expired"):
            # Nothing was installed and nothing displaced, so there is no
            # window to explain and nothing to restore.
            return False, {"error": {
                "type": EXPIRED,
                "message": "This key is genuine, but its term has ended.",
                "expiry": info.get("expiry"),
                "customer": info.get("customer", ""),
                "had_previous": False}}
        try:
            set_licence(key)
        except ValueError as e:      # verified a moment ago; belt and braces
            kind, detail = classify(e)
            return False, {"error": {"type": kind, "message": detail}}
        status = as_status(licence_status() if licence_status else None)
        return True, _persist(key, grant(key, status, info), path, persist)

    # ---- fallback: a wheel with no parse_licence, repaired after the fact ----
    try:
        set_licence(key)
    except ValueError as e:
        kind, detail = classify(e)
        return False, {"error": {"type": kind, "message": detail}}

    status = as_status(licence_status() if licence_status else None)
    if status is not None:
        lapsed = not status.get("licensed")
    else:
        # No probe to ask. Fall back to the expiry in the payload we just had
        # verified. Less authoritative than the wheel's ratcheted clock (it
        # cannot see a rolled-back system clock), but accepting an expired key
        # in silence because nothing was injected would be worse.
        exp = decode_payload(key).get("expiry")
        lapsed = bool(exp) and exp < time.time()
    if lapsed:
        # Genuine key, term ended. Put back what we displaced.
        restored = False
        if previous and previous != key:
            try:
                set_licence(previous)
                # Only claim the old licence is back if it is actually LIVE.
                # A previous key that lapsed yesterday re-applies without
                # error, and reporting that as "still active" would be a lie
                # the customer acts on.
                back = as_status(licence_status() if licence_status else None)
                if back is not None:
                    restored = bool(back.get("licensed"))
                else:
                    prev_exp = decode_payload(previous).get("expiry")
                    restored = bool(prev_exp) and prev_exp > time.time()
            except ValueError:
                restored = False
        decoded = decode_payload(key)
        expired_on = (status or {}).get("expiry") or decoded.get("expiry")
        return False, {"error": {
            "type": EXPIRED,
            "message": "This key is genuine, but its term has ended.",
            "expiry": expired_on,
            "customer": ((status or {}).get("customer")
                         or decoded.get("customer", "")),
            "previous_licence_restored": restored,
            "had_previous": bool(previous and previous != key)}}

    return True, _persist(key, grant(key, status), path, persist)


def _persist(key, granted, path, persist):
    """Write a key that has already been applied. Never fails the apply."""
    result = {"applied": True, "grant": granted}
    if persist:
        try:
            result["stored"] = write_key(key, path)
        except OSError as e:
            # Live but not durable. Surfaced, never swallowed.
            result["warning"] = (f"The key is active now, but could not be saved "
                                 f"({e}); it will not survive a restart.")
    return result

# Vendored engine module (faxl_telemetry.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl telemetry — the transaction event collection layer.

Every datum the console shows originates from ONE transaction: an inbound
/v1/chat/completions request. This module turns that transaction into the
designed, schema-versioned event stream (integration/telemetry/faxl_event.proto),
NOT the incidental JSONL the proxy writes today.

Design (docs/proxy-console-telemetry-plan.md, hardened through adversarial +
advisor + external review):

  * START is SYNCHRONOUS and durable-before-inference. v1 policy is FAIL-CLOSED
    at admission: if the start append cannot commit within a bounded timeout, the
    caller returns a retryable error BEFORE inference and /health fails loudly. A
    request that proceeds without a durable start cannot be honestly counted, so
    it is refused rather than served untracked. (A future fail-open mode is an
    explicit operator setting that labels the window `telemetry coverage
    unknown`; NOT implemented in v1.)

  * COMPLETION is ASYNC, off the serving hot path; its failure surfaces via the
    same LOG_FAILURES -> /health mechanism the proxy already uses.

  * Durability mirrors audit_trail.py: append + flush + fsync per record, refuse
    a volatile sink, never swallow a write failure.

  * The WAL is behind an interface. v1 ships FileWal (length-delimited protobuf,
    append-only). A Kafka/Redpanda arm is the later bake-off candidate — same
    interface, measured against the same p99 budget before either is chosen.

  * PII is enforced HERE, at emit: prompt identity is a TENANT-KEYED HMAC hash
    carrying its rotation epoch (epoch-scoped joins); raw prompt text, secrets,
    and raw User-Agent/X-Client never enter an event.

This module has NO Flask/serving dependencies so it stays testable in isolation.
"""
import hashlib
import hmac
import os
import struct
import threading
import time
import uuid

from faxl.engine.telemetry import faxl_event_pb2 as pb

SCHEMA_VERSION = "v1"

# Bounded budget for the synchronous start append (fail-closed timeout). A
# ~100-byte fsync on local NVMe is sub-millisecond; the bound is a backstop, and
# the real p99 is a Verification-section measurement, not a guess.
START_COMMIT_TIMEOUT_S = float(os.environ.get("FAXL_TELEMETRY_START_TIMEOUT_S", "0.25"))


def is_volatile_path(path):
    """True if the sink lives on a volatile filesystem (/tmp, /var/tmp, /dev/shm).
    The telemetry log is the product's evidence base, not scratch — a sink that
    evaporates on reboot is refused for durable use."""
    p = os.path.abspath(path)
    return any(p == v or p.startswith(v + os.sep)
               for v in ("/tmp", "/private/tmp", "/var/tmp", "/dev/shm"))


class TelemetryError(Exception):
    """Raised when a synchronous START cannot be made durable, OR committed but
    over the budget — the signal the proxy turns into a fail-closed, retryable
    pre-inference error. `.committed` says whether a durable START exists that
    must be closed with a REJECTED (True) or not (False)."""
    committed = False


# Bounded label: telemetry NEVER carries raw User-Agent/X-Client (linkable).
# A client label is a short, normalised, printable token only. Enforced here so
# the PII guarantee holds regardless of caller wiring.
_LABEL_MAX = 40


def _clamp_label(label):
    if not label:
        return ""
    s = "".join(c for c in str(label) if c.isprintable() and c not in "\t\r\n")
    return s[:_LABEL_MAX]


# ---- WAL interface ------------------------------------------------------

class Wal:
    """Append-only durable sink for serialized events. One interface; v1 = file,
    server = Kafka-class (same contract). partition_key is derived here
    (tenant/transaction_id), not carried on the event."""

    def append(self, record_bytes, partition_key, sync):
        raise NotImplementedError

    def close(self):
        pass


class FileWal(Wal):
    """Length-delimited protobuf records in an append-only file.

    Framing: 4-byte big-endian unsigned length, then the protobuf bytes. A
    reader can stream records back without a schema descriptor. `sync=True`
    (START) does flush+fsync before returning so the record is durable before
    the caller proceeds; `sync=False` (COMPLETION) still flushes but does not
    force fsync on the hot path.
    """

    def __init__(self, path):
        self.path = os.path.abspath(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.Lock()
        # RECOVERY-ON-OPEN: a crash can leave a torn (or invalid) frame. If we
        # simply appended after it, that garbage would sit MID-file and corrupt
        # every later read. Scan to the first bad frame and truncate there before
        # opening for append, so the log is always a clean prefix of good frames.
        self._recover(self.path)
        self._f = open(self.path, "ab", buffering=0)

    @staticmethod
    def _recover(path):
        if not os.path.exists(path):
            return
        good = 0
        with open(path, "rb") as f:
            while True:
                pos = f.tell()
                hdr = f.read(4)
                if len(hdr) < 4:
                    break
                (n,) = struct.unpack(">I", hdr)
                payload = f.read(n)
                if len(payload) < n:
                    break  # torn tail
                ev = pb.TelemetryEvent()
                try:
                    ev.ParseFromString(payload)
                except Exception:  # noqa: BLE001 — invalid frame ends the good prefix
                    break
                good = pos + 4 + n
        if good < os.path.getsize(path):
            print(f"!! telemetry WAL {path}: truncating {os.path.getsize(path)-good} "
                  f"trailing byte(s) from an incomplete/invalid frame (crash "
                  f"recovery)", flush=True)
            with open(path, "r+b") as f:
                f.truncate(good)

    def append(self, record_bytes, partition_key, sync):
        frame = struct.pack(">I", len(record_bytes)) + record_bytes
        # The append itself is serialized so concurrent COMPLETION emits from
        # worker threads never interleave frames. START holds this only for the
        # duration of one small write+fsync — it is NOT the serve lock.
        with self._lock:
            self._f.write(frame)
            self._f.flush()
            if sync:
                os.fsync(self._f.fileno())

    def close(self):
        with self._lock:
            try:
                self._f.flush()
                os.fsync(self._f.fileno())
            finally:
                self._f.close()


def iter_file_wal(path):
    """Read FileWal records back as TelemetryEvent messages (for the aggregator
    and tests). Tolerates a torn tail frame (a crash mid-write) by stopping."""
    with open(path, "rb") as f:
        while True:
            hdr = f.read(4)
            if len(hdr) < 4:
                return
            (n,) = struct.unpack(">I", hdr)
            payload = f.read(n)
            if len(payload) < n:
                return  # torn tail — crash during a non-synced append
            ev = pb.TelemetryEvent()
            ev.ParseFromString(payload)
            yield ev


# ---- tenant-keyed prompt hashing ---------------------------------------

class TenantKeyer:
    """Produces tenant-scoped keyed hashes (HMAC), carrying a rotation epoch.

    A bare content hash is linkable across tenants and time; a keyed hash is not,
    and the epoch makes joins epoch-scoped so a key rotation never silently
    yields a false non-match. v1 derives a per-tenant key from a process-held
    root secret; the server tier supplies real per-tenant keys + rotation.
    """

    def __init__(self, root_secret=None, epoch=0, secret_path=None):
        # The root secret MUST be stable across restarts, or the same
        # tenant+prompt hashes differently under one epoch — an undetectable
        # false non-match (the epoch guards rotation, not process restart).
        # Precedence: explicit arg > env override > persisted file > generate+persist.
        if root_secret:
            self._root = root_secret.encode()
        elif os.environ.get("FAXL_TELEMETRY_HASH_SECRET"):
            self._root = os.environ["FAXL_TELEMETRY_HASH_SECRET"].encode()
        else:
            self._root = self._load_or_create_secret(secret_path)
        self.epoch = int(epoch)

    @staticmethod
    def _load_or_create_secret(secret_path):
        path = os.path.abspath(secret_path or os.path.expanduser(
            os.environ.get("FAXL_TELEMETRY_SECRET_PATH", "~/.faxl/telemetry-secret")))
        try:
            with open(path, "rb") as f:
                data = f.read().strip()
                if data:
                    return data
        except OSError:
            pass
        secret = uuid.uuid4().hex.encode()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as f:
                f.write(secret)
        except OSError as e:
            # Persist failure is loud but not fatal: hashing still works this run,
            # cross-restart joins won't. Caller sees it via the print.
            print(f"!! telemetry hash secret not persisted ({path}: {e}) — "
                  f"cross-restart prompt joins will break", flush=True)
        return secret

    def _tenant_key(self, tenant):
        return hmac.new(self._root, f"{tenant}:{self.epoch}".encode(),
                        hashlib.sha256).digest()

    def keyed_hash(self, tenant, content_bytes):
        digest = hmac.new(self._tenant_key(tenant), content_bytes,
                          hashlib.sha256).digest()
        return pb.KeyedHash(digest=digest, rotation_epoch=self.epoch)


# ---- the emitter --------------------------------------------------------

class Telemetry:
    """Owns the WAL + keyer and the START/COMPLETION/REJECTED emit contract.

    The proxy holds one instance. START is called from the request handler
    BEFORE the serve lock (a stalled telemetry fsync must not serialize behind
    queued inference); COMPLETION is called at the metrics-rec site after the
    serve. Backend/model/boot_id are process constants set once.
    """

    def __init__(self, wal, keyer, *, backend, model, boot_id,
                 determinism_config_id="", enabled=True):
        self.wal = wal
        self.keyer = keyer
        self.backend = backend
        self.model = model
        self.boot_id = boot_id
        self.determinism_config_id = determinism_config_id
        self.enabled = bool(enabled)
        self.failures = []      # surfaced in /health; never swallowed

    # -- identity helpers --
    @staticmethod
    def new_event_id():
        return uuid.uuid4().hex

    def _base(self, transaction_id, event_type, seq, *, tenant, attempt_id=0,
              deadline_unix_ns=0):
        now = time.time()
        return pb.TelemetryEvent(
            schema_version=SCHEMA_VERSION,
            event_id=self.new_event_id(),
            transaction_id=transaction_id,
            attempt_id=attempt_id,
            event_type=event_type,
            seq=seq,
            emitted_at_unix_ns=int(now * 1e9),
            monotonic_ns=int(time.monotonic() * 1e9),
            deadline_unix_ns=deadline_unix_ns,
            tenant=tenant or "",
            boot_id=self.boot_id,
            backend=self.backend,
            model=self.model,
            determinism_config_id=self.determinism_config_id,
        )

    def emit_start(self, transaction_id, *, tenant, prompt_bytes, n_messages,
                   client_label="", deadline_unix_ns=0, attempt_id=0):
        """Synchronous, durable-before-inference. Raises TelemetryError if the
        record cannot be committed within the bounded timeout — the caller turns
        that into a fail-closed retryable error (v1). No-op when disabled.

        Only pre-tokenization facts are known here (bytes + message count); token
        counts arrive on COMPLETION after apply_chat_template runs under the lock.
        """
        if not self.enabled:
            return
        ev = self._base(transaction_id, pb.START, 0, tenant=tenant,
                        attempt_id=attempt_id, deadline_unix_ns=deadline_unix_ns)
        ev.prompt_bytes = int(prompt_bytes)
        ev.n_messages = int(n_messages)
        ev.client_label = _clamp_label(client_label)   # bounded ONLY, never raw UA
        try:
            self._durable_append(ev, transaction_id, tenant, sync=True)
        except TelemetryError as e:
            # The START may already be durable (budget-overrun case). Close the
            # transaction with a terminal REJECTED so the aggregator does NOT
            # materialise a false "incomplete" for a request we are refusing.
            if getattr(e, "committed", False):
                self.emit_rejected(transaction_id, tenant=tenant,
                                   reject_reason="telemetry_budget_overrun",
                                   client_label=client_label,
                                   attempt_id=attempt_id, _seq=1)
            raise

    def emit_completion(self, transaction_id, *, tenant, outcome, resume_pos,
                        hit_tier, ladder, cost, out_tokens, timings,
                        prompt_content=None, seq=1, attempt_id=0):
        """Async off the hot path. Best-effort durable; failure is surfaced via
        /health, never raised into the serving path. `prompt_content` (bytes) is
        hashed here (tenant-keyed) and discarded — it never enters the event."""
        if not self.enabled:
            return
        ev = self._base(transaction_id, pb.COMPLETION, seq, tenant=tenant,
                        attempt_id=attempt_id)
        ev.outcome = outcome
        ev.resume_pos = int(resume_pos)
        ev.hit_tier = hit_tier
        ev.out_tokens = int(out_tokens)
        for p in ladder:
            ev.ladder.add().CopyFrom(p)
        if cost is not None:
            ev.cost.CopyFrom(cost)
        if timings is not None:
            ev.timings.CopyFrom(timings)
        if prompt_content is not None:
            ev.prompt_key.CopyFrom(self.keyer.keyed_hash(tenant or "",
                                                         prompt_content))
        self._soft_append(ev, transaction_id, tenant)

    def emit_rejected(self, transaction_id, *, tenant, reject_reason,
                      client_label="", attempt_id=0, _seq=0):
        """A terminal, attributable rejection — still a tenant event (so coverage
        is honest), carrying no cost/lookup story. Used both for syntactic/
        validation rejections (_seq=0) and to CLOSE a transaction whose START was
        durable but refused (budget overrun, _seq=1) so no false 'incomplete' is
        materialised."""
        if not self.enabled:
            return
        ev = self._base(transaction_id, pb.REJECTED, _seq, tenant=tenant,
                        attempt_id=attempt_id)
        ev.reject_reason = reject_reason
        ev.client_label = _clamp_label(client_label)
        self._soft_append(ev, transaction_id, tenant)

    # -- durability paths --
    def _durable_append(self, ev, transaction_id, tenant, sync):
        # NOTE on "budget": this is a POST-COMMIT budget CHECK, not a bounded
        # wait. wal.append() blocks for its full duration — a stalled sink holds
        # the requesting thread (and queues concurrent requests behind
        # FileWal._lock). A genuinely bounded fsync wait is the WAL bake-off's
        # problem; v1 detects an over-budget commit and fails closed after it.
        blob = ev.SerializeToString()
        pk = f"{tenant or ''}/{transaction_id}"
        started = time.monotonic()
        try:
            self.wal.append(blob, partition_key=pk, sync=sync)
        except Exception as e:  # noqa: BLE001 — any sink failure is fail-closed
            msg = f"telemetry START append failed: {e}"
            self._record_failure(msg)
            print(f"!! {msg} — FAIL-CLOSED (request refused pre-inference)",
                  flush=True)
            err = TelemetryError(msg)
            err.committed = False   # nothing durable — no orphan to close
            raise err from e
        took = time.monotonic() - started
        if took > START_COMMIT_TIMEOUT_S:
            # It DID commit, but over budget — refuse rather than serve a request
            # whose telemetry path is unhealthy (v1 fail-closed). The caller
            # closes the durable START with a REJECTED so it is not a false
            # incomplete.
            msg = (f"telemetry START commit {took*1000:.0f}ms exceeded budget "
                   f"{START_COMMIT_TIMEOUT_S*1000:.0f}ms")
            self._record_failure(msg)
            print(f"!! {msg} — FAIL-CLOSED", flush=True)
            err = TelemetryError(msg)
            err.committed = True    # START is durable — caller must emit REJECTED
            raise err

    def _soft_append(self, ev, transaction_id, tenant):
        blob = ev.SerializeToString()
        pk = f"{tenant or ''}/{transaction_id}"
        try:
            self.wal.append(blob, partition_key=pk, sync=False)
        except Exception as e:  # noqa: BLE001
            # COMPLETION/REJECTED never blocks or fails serving; surfaced loud.
            msg = f"telemetry {pb.EventType.Name(ev.event_type)} append failed: {e}"
            self._record_failure(msg)
            print(f"!! {msg} — event lost, coverage reduced (surfaced in /health)",
                  flush=True)

    def _record_failure(self, msg):
        # Cap growth on a persistently broken sink: keep the first N + a count.
        if len(self.failures) < 64:
            self.failures.append(msg)
        self.n_failures = getattr(self, "n_failures", 0) + 1

    def health(self):
        return {"enabled": self.enabled, "failures": self.failures[:5],
                "n_failures": getattr(self, "n_failures", len(self.failures))}

    def close(self):
        try:
            self.wal.close()
        except Exception:  # noqa: BLE001
            pass

#!/usr/bin/env python3
"""faxl proxy MCP server — install/manage the cache proxy as typed agent tools.

Pure stdlib, stdio JSON-RPC (MCP 2024-11-05). Every tool shells out to the
same commands documented for humans (AGENTS.md in the distribution;
.claude/skills/faxl-proxy/SKILL.md in a vendor checkout), so nothing here is
load-bearing: an agent without MCP follows those instructions by hand.

Register:  claude mcp add faxl -- faxl-mcp
           (or: claude mcp add faxl -- python3 -m faxl.engine.faxl_mcp —
           the interpreter must be the one the faxl wheel is installed into)
faxl_start runs faxl_start.sh -- the same launcher the console's restart
button uses -- so the backend in ~/.faxl/config.json decides what comes up
(mlx in-process, or exo with faxl in front of the cluster). It does not spawn
faxl_proxy.py directly; on exo that would start a proxy with no cluster
behind it.

Env:       FAXL_PROXY_LOG (default ${FAXL_HOME:-~/.faxl}/logs/proxy.log, the
           path faxl_start.sh writes), FAXL_PYTHON (the interpreter the proxy
           runs under; defaults to the one running this server),
           FAXL_PROXY_SCRIPT (reported by faxl_status), FAXL_PORT, plus the
           proxy's own FAXL_* env.
"""
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request

_HERE = os.path.dirname(os.path.abspath(__file__))
def _find_proxy():
    """env override, then the wheel layout (faxl_proxy.py next to this file),
    then a vendor-repo checkout (integration/ above tools/)."""
    cands = [os.environ.get("FAXL_PROXY_SCRIPT"),
             os.path.join(_HERE, "faxl_proxy.py"),
             os.path.join(os.path.dirname(_HERE), "integration", "faxl_proxy.py")]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return cands[-1]  # best-effort; faxl_start reports the miss loudly
PROXY = _find_proxy()
REPO = os.path.dirname(os.path.dirname(PROXY))
# ONE HOME FOR THE PID AND THE LOG, shared with faxl_start.sh and the
# console (${FAXL_HOME:-~/.faxl}/logs). This server used to keep its own pair
# -- ~/.faxl-proxy.pid and ~/faxl-proxy.log -- so a proxy started by the
# launcher or the console was invisible to it: faxl_status reported pid null
# while the proxy was serving, and faxl_stop answered "not running" against a
# live process. Both files existed side by side on the same Mac.
def _faxl_home():
    return os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")


LOG = os.path.expanduser(
    os.environ.get("FAXL_PROXY_LOG",
                   os.path.join(_faxl_home(), "logs", "proxy.log")))
# The interpreter that runs the proxy must have mlx/mlx_lm/ultradim/faxl
# installed. FAXL_PYTHON overrides; default is the one running this server.
PYTHON = os.path.expanduser(os.environ.get("FAXL_PYTHON", sys.executable))
PIDFILE = os.path.join(_faxl_home(), "logs", "proxy.pid")
# Must track the proxy's own FAXL_PORT default (faxl_proxy.py): MCP talks to
# whatever the proxy bound, so a hardcoded port breaks every tool the moment
# someone sets FAXL_PORT.
BASE = "http://localhost:%s" % os.environ.get("FAXL_PORT", "8767")


def http_json(path, timeout=5):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
        return json.loads(r.read())


def _pid_on_port():
    """Whoever is LISTENING on the proxy's port, or None.

    The pidfile is written at start and is not cleaned up after a crash or a
    kill -9, so it both goes stale and misses a proxy someone else started.
    The port cannot lie about what is serving right now, which is the
    question every tool here is really asking.
    """
    port = os.environ.get("FAXL_PORT", "8767")
    try:
        out = subprocess.run(["lsof", "-t", "-nP", f"-iTCP:{port}",
                              "-sTCP:LISTEN"],
                             capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for tok in out.split():
        try:
            return int(tok)
        except ValueError:
            continue
    return None


def running_pid():
    """The live proxy's pid: the pidfile if it is alive, else the port.

    Falling back to the port is what lets faxl_stop act on a proxy started by
    faxl_start.sh or the console's restart button. Without it the tool
    answered "not running" while the proxy was serving -- measured, against a
    launcher-started proxy on pid 70983.
    """
    try:
        pid = int(open(PIDFILE).read().strip())
        os.kill(pid, 0)
        return pid
    except (OSError, ValueError):
        return _pid_on_port()


# ---- tools -----------------------------------------------------------------

def t_status(_args):
    out = {"proxy_script": PROXY, "pid": running_pid(), "serving": False}
    try:
        out["health"] = http_json("/health")
        out["serving"] = True
    except Exception as e:
        out["health_error"] = str(e)
    if out["serving"] and out["pid"] is None:
        out["note"] = ("proxy was started outside this server (no pidfile) — "
                       "faxl_stop cannot stop it; use kill on its real pid")
    return out


def t_start(args):
    if running_pid() and t_status({}).get("serving"):
        return {"already_running": True, "health": http_json("/health")}
    env = dict(os.environ)
    # explicit arg→env map; a rename once broke the string-derived version
    for arg, k in (("model", "FAXL_MODEL"), ("blobs", "FAXL_BLOBS"),
                   ("db", "FAXL_DB"), ("licence", "FAXL_LICENCE"),
                   ("nocache", "FAXL_NOCACHE")):
        v = args.get(arg)
        if v is not None:
            env[k] = str(v)
    # THE STORE COMES FROM config.json NOW, so demanding blobs= was refusing
    # to start a correctly configured machine. The old check tested for the
    # env var alone, which config.json does not set: on this Mac
    # faxl_config.store_dir("mlx") is ~/.faxl/photo-cache -- persistent, and
    # the tool still returned "refusing to start with the volatile /tmp
    # default store". An AI following faxl_start hit a dead end that was not
    # real.
    #
    # Ask the resolver instead of guessing. It reads config.json, then the
    # env, then falls back to /tmp -- so the refusal now fires only when the
    # store WOULD actually be volatile, which is the thing worth refusing.
    if "FAXL_BLOBS" not in env:
        try:
            from faxl.engine import faxl_config
            resolved = faxl_config.store_dir(faxl_config.backend())
        except Exception:  # noqa: BLE001 - no config module, keep the old guard
            resolved = None
        if resolved is None or resolved.startswith("/tmp/"):
            return {"error": "refusing to start with a volatile /tmp store — "
                             "pass blobs=<path>, or set blob_dir in "
                             "~/.faxl/config.json",
                    "resolved_store": resolved}
    # THE LAUNCHER STARTS THE STACK; THIS TOOL DOES NOT RE-IMPLEMENT IT.
    #
    # This used to Popen([PYTHON, PROXY]) -- the proxy alone, whatever the
    # configured backend was. On backend=exo that is wrong in a way nothing
    # reports: faxl_start.sh branches, and on exo it refuses a stale exo,
    # starts exo, publishes faxl's prefill endpoint on :52440 for exo to
    # read, and only then starts the proxy in tokenizer-only mode. Spawning
    # the proxy by itself produced a faxl with NO CLUSTER BEHIND IT -- which
    # answers /health perfectly and 500s on the first real request.
    #
    # faxl_start.sh is shipped in the wheel precisely so both the console's
    # restart button and this tool run the same sequence. One start path, one
    # set of failure modes, one log.
    launcher = os.path.join(_HERE, "faxl_start.sh")
    if not os.path.exists(launcher):
        return {"error": f"launcher not found at {launcher}"}
    # The launcher runs the proxy under FAXL_PYTHON and falls back to a bare
    # python3 from PATH, which is usually the wrong interpreter. This server
    # is already running in one that has faxl, so name it.
    env.setdefault("FAXL_PYTHON", PYTHON)
    env["PYTHONUNBUFFERED"] = "1"   # per-request lines must land as they happen
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    # A model named here is written to config.json by the launcher, so the
    # choice survives the next restart -- the same contract the command line
    # has. Passing it as an argument rather than only as FAXL_MODEL is what
    # makes that happen.
    cmd = ["/bin/bash", launcher]
    if args.get("model"):
        cmd.append(str(args["model"]))
    start_log = os.path.join(os.path.dirname(LOG), "mcp-start.log")
    with open(start_log, "a") as lf:
        p = subprocess.Popen(cmd, stdout=lf, stderr=lf, env=env,
                             cwd=REPO, start_new_session=True)

    # DO NOT RECORD p.pid: that is the launcher, which exits once the stack is
    # up. The proxy's own pid is written to PIDFILE by the launcher, and
    # running_pid() falls back to the port, so both paths find the same
    # process.
    deadline = time.time() + float(args.get("timeout_s", 600))  # model load is slow
    while time.time() < deadline:
        try:
            health = http_json("/health")
        except Exception:  # noqa: BLE001 - not up yet, or not up at all
            if p.poll() is not None and p.returncode != 0:
                return {"error": f"launcher exited code {p.returncode} before "
                                 f"the proxy answered",
                        "log_tail": tail(start_log, 20) + tail(LOG, 20)}
            time.sleep(3)
            continue
        return {"started": True, "pid": running_pid(), "health": health,
                "backend": (health or {}).get("backend"),
                "log_tail": tail(LOG, 8)}
    return {"error": "timed out waiting for /health (model still loading?)",
            "pid": running_pid(),
            "log_tail": tail(start_log, 10) + tail(LOG, 15)}


def t_stop(_args):
    pid = running_pid()
    if not pid:
        return {"stopped": False, "reason": "no proxy is listening on "
                                            + BASE}
    os.kill(pid, signal.SIGTERM)
    for _ in range(20):
        if running_pid() is None:
            break
        time.sleep(0.5)
    # Remove the pidfile only if it names the process we just stopped. It is
    # shared with faxl_start.sh and the console now, so deleting it blind
    # would throw away a live proxy's pid when running_pid() came from the
    # port instead.
    try:
        if int(open(PIDFILE).read().strip()) == pid:
            os.unlink(PIDFILE)
    except (OSError, ValueError):
        pass
    still = running_pid()
    # "still_running", not "forced": nothing here sends SIGKILL. The old key
    # was named for an escalation that does not happen, and an agent reading
    # forced=false on a proxy that refused to die would draw the opposite
    # conclusion to the truth.
    return {"stopped": still is None, "pid": pid, "still_running": still}


def t_install_licence(args):
    key = args.get("key", "").strip()
    if not key:
        return {"error": "pass key=<licence text from Gamakon>"}
    from faxl.engine import faxl_licence
    path = os.path.expanduser(args.get("path") or faxl_licence.licence_path())
    key = faxl_licence.normalise(key)

    # VALIDATE BEFORE WRITING, same ordering as the console's paste field.
    # Without this the tool happily persisted anything it was handed, and the
    # key only failed at the NEXT BOOT -- the proxy comes up unlicensed, every
    # prefill runs cold, and nothing connects that to the install that caused
    # it. A bad key must fail here, where the caller can still fix it.
    #
    # parse_licence validates WITHOUT installing and reports the term, so a
    # lapsed key is refused too; on wheels without it, parse-by-set_licence is
    # the best available check. Either way nothing is written unless the key
    # verifies.
    try:
        import faxl as _faxl
    except ImportError:
        _faxl = None
    checker = getattr(_faxl, "parse_licence", None) if _faxl else None
    if checker is not None:
        try:
            info = checker(key)
        except ValueError as e:
            kind, detail = faxl_licence.classify(e)
            return {"error": f"licence rejected ({kind}): {detail}",
                    "written": None}
        if info.get("expired"):
            return {"error": "licence rejected (expired): this key is genuine "
                             "but its term ended; renew at faxl.ai",
                    "customer": info.get("customer", ""),
                    "expiry": info.get("expiry"), "written": None}
    elif _faxl is not None:
        try:
            _, expiry, _action = _faxl.set_licence(key)
        except ValueError as e:
            kind, detail = faxl_licence.classify(e)
            return {"error": f"licence rejected ({kind}): {detail}",
                    "written": None}
        # set_licence does NOT check the term -- licence.rs::parse never
        # compares expiry to the clock -- so an expired key gets this far.
        # Check it against the wheel's ratcheted clock, which is what the gate
        # uses, rather than trusting the payload or the system clock.
        live = _faxl.licence_status()[0]
        if not live or (expiry and expiry < time.time()):
            return {"error": "licence rejected (expired): this key is genuine "
                             "but its term ended; renew at faxl.ai",
                    "expiry": expiry, "written": None}

    # One write helper, shared with the console's paste field: atomic (a half
    # key would break the next boot) and 600 before any bytes land, not after.
    faxl_licence.write_key(key, path)
    out = {"written": path, "note": "restart the proxy to load it"}
    if t_status({}).get("serving"):
        out["current_health_licence"] = http_json("/health").get("licence")
    return out


def t_metrics(_args):
    return http_json("/metrics")


def tail(path, n):
    try:
        return open(path, errors="replace").readlines()[-n:]
    except OSError:
        return []


def t_apps(_args):
    """What this faxl can actually do, read from the running proxy.

    AN AI DRIVING faxl NEEDS THIS FIRST. Without it the model knows there is
    a cache proxy and nothing else -- not that there are working apps, not
    which model reads images, not that the camera roll needs a photo
    selection before it will run. Every field here comes from the proxy, so
    it describes THIS install rather than a wish.
    """
    out = {"console": BASE + "/console"}
    try:
        st = http_json("/api/state")
        m = st.get("model") or {}
        out["model"] = m.get("id") if isinstance(m, dict) else m
        out["vision"] = bool(m.get("vision")) if isinstance(m, dict) else None
        out["backend"] = (st.get("backend") or {}).get("name")
        out["apps"] = [{"name": a.get("title"), "url": a.get("href"),
                        "job": bool(a.get("job"))}
                       for a in (st.get("apps") or [])]
    except Exception as exc:  # noqa: BLE001 - a stopped proxy is not an error
        out["error"] = f"proxy not answering ({exc}); start it with faxl_start"
    out["notes"] = [
        "Everything runs on this Mac. No photograph, recording or prompt "
        "leaves it, and there is no account or licence server.",
        "The apps share one long instruction preamble, so the first request "
        "pays for it and the rest reuse the cached state -- that reuse is "
        "what faxl sells, and /api/requests reports it per request.",
        "The camera roll needs photographs chosen first (the console's "
        "Choose button opens macOS's own picker); faxl can read only what "
        "the person selects.",
        "Voice-to-text needs ffmpeg on PATH (brew install ffmpeg).",
    ]
    return out


TOOLS = {
    # THE APP LIST IS NOT SPELLED OUT HERE. It was -- "camera-roll tagging,
    # voice to text, OCR, whiteboard to diagram" -- and whiteboard was parked
    # on 2026-09-22 (faxl_console.APPS_PARKED) without this string changing.
    # A tool description that names features is a second, stale copy of the
    # registry: an AI reads it and offers the user an app that is not there.
    # The names come from the running proxy, via t_apps, or not at all.
    "faxl_apps": (t_apps, "What this faxl install can do: the model it is "
                          "serving, whether that model reads images, and "
                          "which apps this install actually offers. Call "
                          "this FIRST when asked to help with faxl.", {}),
    "faxl_status": (t_status, "Proxy status: pid, /health (incl. licence block), serving or not.", {}),
    "faxl_start": (t_start, "Start the faxl stack in the background (via "
                            "faxl_start.sh, so the backend in config.json "
                            "decides whether that is mlx in-process or exo "
                            "with faxl in front) and wait for /health. Model "
                            "load can take minutes.",
                   {"blobs": {"type": "string", "description":
                              "persistent store dir. Optional: config.json "
                              "supplies it. Pass it only to override, or if "
                              "the store would otherwise land in /tmp"},
                    "model": {"type": "string", "description":
                              "MLX model id. Omit to use the configured "
                              "default. For the apps -- photo tagging, OCR, "
                              "whiteboard -- it MUST be a vision model: "
                              "mlx-community/Qwen3-VL-4B-Instruct-4bit is "
                              "the shipped one (2.9 GB, runs on any modern "
                              "Mac). A text-only model refuses images rather "
                              "than inventing an answer, so the apps will "
                              "not work on one."},
                    "db": {"type": "string", "description": "index dir (default <blobs>/ultradim_db)"},
                    "licence": {"type": "string", "description": "licence file path (optional)"},
                    "nocache": {"type": "string", "description": "'1' = bypass cache (A/B)"},
                    "timeout_s": {"type": "number", "description": "startup wait, default 600"}}),
    "faxl_stop": (t_stop, "Stop the proxy (SIGTERM). The store persists; restart warm-starts.", {}),
    "faxl_install_licence": (t_install_licence, "Write a Gamakon licence key to the key file (mode 600).",
                             {"key": {"type": "string", "description": "the licence text"},
                              "path": {"type": "string", "description": "key file (default ~/.faxl-licence)"}}),
    "faxl_metrics": (t_metrics, "Cache metrics: hits, hit_rate, prefill_skipped/paid.", {}),
}


# ---- MCP stdio loop --------------------------------------------------------

def reply(id_, result=None, error=None):
    msg = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        msg["error"] = {"code": -32000, "message": error}
    else:
        msg["result"] = result
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, id_ = req.get("method"), req.get("id")
        if method == "initialize":
            reply(id_, {"protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "faxl", "version": "0.1.0"}})
        elif method == "tools/list":
            reply(id_, {"tools": [
                {"name": n, "description": d,
                 "inputSchema": {"type": "object", "properties": props}}
                for n, (_f, d, props) in TOOLS.items()]})
        elif method == "tools/call":
            name = req["params"]["name"]
            args = req["params"].get("arguments") or {}
            if name not in TOOLS:
                reply(id_, error=f"unknown tool {name}")
                continue
            try:
                result = TOOLS[name][0](args)
            except Exception as e:  # a tool failure is a result, not a dead server
                result = {"error": f"{type(e).__name__}: {e}"}
            reply(id_, {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]})
        elif id_ is not None:  # unknown request — answer, don't hang the client
            reply(id_, {})


if __name__ == "__main__":
    main()

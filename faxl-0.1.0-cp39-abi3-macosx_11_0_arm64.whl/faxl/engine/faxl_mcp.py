#!/usr/bin/env python3
"""Halo proxy MCP server — install/manage the cache proxy as typed agent tools.

Pure stdlib, stdio JSON-RPC (MCP 2024-11-05). Every tool shells out to the
same commands documented in the skill file (HALO-AGENT-SKILL.md at the bundle
root; .claude/skills/faxl-proxy/SKILL.md in a vendor checkout), so nothing
here is load-bearing: an agent without MCP follows the skill file by hand.

Register:  claude mcp add faxl -- python3 faxl_mcp.py
Env:       FAXL_PROXY_SCRIPT (default integration/faxl_proxy.py, resolved
           relative to this repo), FAXL_PROXY_LOG (default ~/faxl-proxy.log),
           plus the proxy's own FAXL_* env which halo_start passes through.
"""
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request

_HERE = os.path.dirname(os.path.abspath(__file__))
def _find_proxy():
    """env override, then the bundle layout (proxy/ next to this file), then a
    vendor-repo checkout (integration/ above tools/)."""
    cands = [os.environ.get("FAXL_PROXY_SCRIPT"),
             os.path.join(_HERE, "proxy", "faxl_proxy.py"),
             os.path.join(os.path.dirname(_HERE), "integration", "faxl_proxy.py")]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return cands[-1]  # best-effort; halo_start reports the miss loudly
PROXY = _find_proxy()
REPO = os.path.dirname(os.path.dirname(PROXY))
LOG = os.path.expanduser(os.environ.get("FAXL_PROXY_LOG", "~/faxl-proxy.log"))
# The interpreter that runs the proxy must have mlx/mlx_lm/ultradim/faxl
# installed. FAXL_PYTHON overrides; default is the one running this server.
PYTHON = os.path.expanduser(os.environ.get("FAXL_PYTHON", sys.executable))
PIDFILE = os.path.expanduser("~/.faxl-proxy.pid")
BASE = "http://localhost:8080"


def http_json(path, timeout=5):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
        return json.loads(r.read())


def running_pid():
    """PID from the pidfile if that process is alive, else None."""
    try:
        pid = int(open(PIDFILE).read().strip())
        os.kill(pid, 0)
        return pid
    except (OSError, ValueError):
        return None


# ---- tools -----------------------------------------------------------------

def t_status(_args):
    out = {"proxy_script": PROXY, "pid": running_pid(), "serving": False}
    try:
        out["health"] = http_json("/health")
        out["serving"] = True
    except Exception as e:
        out["health_error"] = str(e)
    if out["serving"] and out["pid"] is None:
        out["note"] = ("proxy was started outside this server (no pidfile) — "
                       "halo_stop cannot stop it; use kill on its real pid")
    return out


def t_start(args):
    if running_pid() and t_status({}).get("serving"):
        return {"already_running": True, "health": http_json("/health")}
    env = dict(os.environ)
    for k in ("FAXL_MODEL", "FAXL_BLOBS", "FAXL_DB", "FAXL_LICENCE", "FAXL_NOCACHE"):
        v = args.get(k.lower().removeprefix("halo_"))
        if v is not None:
            env[k] = str(v)
    if "FAXL_BLOBS" not in env:
        return {"error": "refusing to start with the volatile /tmp default store — "
                         "pass blobs=<path> (persistent store directory)"}
    if not os.path.exists(PROXY):
        return {"error": f"proxy script not found at {PROXY} — set FAXL_PROXY_SCRIPT"}
    env["PYTHONUNBUFFERED"] = "1"   # per-request lines must land as they happen
    logf = open(LOG, "a")
    p = subprocess.Popen([PYTHON, PROXY], stdout=logf, stderr=logf,
                         env=env, cwd=REPO, start_new_session=True)
    open(PIDFILE, "w").write(str(p.pid))
    deadline = time.time() + float(args.get("timeout_s", 600))  # model load is slow
    while time.time() < deadline:
        if p.poll() is not None:
            return {"error": f"proxy exited code {p.returncode} during startup",
                    "log_tail": tail(LOG, 30)}
        try:
            return {"started": True, "pid": p.pid, "health": http_json("/health"),
                    "log_tail": tail(LOG, 8)}
        except Exception:
            time.sleep(3)
    return {"error": "timed out waiting for /health (model still loading?)",
            "pid": p.pid, "log_tail": tail(LOG, 15)}


def t_stop(_args):
    pid = running_pid()
    if not pid:
        return {"stopped": False, "reason": "not running (no live pidfile)"}
    os.kill(pid, signal.SIGTERM)
    for _ in range(20):
        if running_pid() is None:
            break
        time.sleep(0.5)
    try:
        os.unlink(PIDFILE)
    except OSError:
        pass
    return {"stopped": True, "pid": pid, "forced": running_pid() is not None}


def t_install_licence(args):
    key = args.get("key", "").strip()
    if not key:
        return {"error": "pass key=<licence text from Gamakon>"}
    path = os.path.expanduser(args.get("path") or
                              os.environ.get("FAXL_LICENCE", "~/.faxl-licence"))
    with open(path, "w") as f:
        f.write(key + "\n")
    os.chmod(path, 0o600)
    out = {"written": path, "note": "restart the proxy to load it"}
    if t_status({}).get("serving"):
        out["current_health_licence"] = http_json("/health").get("licence")
    return out


def t_metrics(_args):
    return http_json("/metrics")


def tail(path, n):
    try:
        return open(path, errors="replace").readlines()[-n:]
    except OSError:
        return []


TOOLS = {
    "halo_status": (t_status, "Proxy status: pid, /health (incl. licence block), serving or not.", {}),
    "halo_start": (t_start, "Start the Halo proxy in the background and wait for /health. "
                            "Requires blobs (persistent store dir). Model load can take minutes.",
                   {"blobs": {"type": "string", "description": "persistent store dir (required)"},
                    "model": {"type": "string", "description": "mlx_lm model id (optional)"},
                    "licence": {"type": "string", "description": "licence file path (optional)"},
                    "nocache": {"type": "string", "description": "'1' = bypass cache (A/B)"},
                    "timeout_s": {"type": "number", "description": "startup wait, default 600"}}),
    "halo_stop": (t_stop, "Stop the proxy (SIGTERM). The store persists; restart warm-starts.", {}),
    "halo_install_licence": (t_install_licence, "Write a Gamakon licence key to the key file (mode 600).",
                             {"key": {"type": "string", "description": "the licence text"},
                              "path": {"type": "string", "description": "key file (default ~/.faxl-licence)"}}),
    "halo_metrics": (t_metrics, "Cache metrics: hits, hit_rate, prefill_skipped/paid.", {}),
}


# ---- MCP stdio loop --------------------------------------------------------

def reply(id_, result=None, error=None):
    msg = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        msg["error"] = {"code": -32000, "message": error}
    else:
        msg["result"] = result
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, id_ = req.get("method"), req.get("id")
        if method == "initialize":
            reply(id_, {"protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "faxl", "version": "0.1.0"}})
        elif method == "tools/list":
            reply(id_, {"tools": [
                {"name": n, "description": d,
                 "inputSchema": {"type": "object", "properties": props}}
                for n, (_f, d, props) in TOOLS.items()]})
        elif method == "tools/call":
            name = req["params"]["name"]
            args = req["params"].get("arguments") or {}
            if name not in TOOLS:
                reply(id_, error=f"unknown tool {name}")
                continue
            try:
                result = TOOLS[name][0](args)
            except Exception as e:  # a tool failure is a result, not a dead server
                result = {"error": f"{type(e).__name__}: {e}"}
            reply(id_, {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]})
        elif id_ is not None:  # unknown request — answer, don't hang the client
            reply(id_, {})


if __name__ == "__main__":
    main()

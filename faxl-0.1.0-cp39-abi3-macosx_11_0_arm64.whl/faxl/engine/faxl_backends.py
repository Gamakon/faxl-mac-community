# Vendored engine module (faxl_backends.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""faxl_backends -- the registry of execution backends, as plain data.

WHY (2026-09-22, step 1 of the vLLM plan). The console, the panel and the
proxy each spelled "mlx" and "exo" out by hand: a label here, an `if name ==
"exo"` there, a two-entry tuple in faxl_config. A third backend (vLLM on the
nvidia line) would have meant editing every one of those places. Now each
backend is ONE descriptor, and everything that has to choose between them
asks the descriptor for the capability it is really asking about -- where
the memory figure comes from, where the model list comes from, whether it
takes images, which apps it can run -- rather than for the name.

A descriptor is DATA ONLY: no model loading, no imports beyond the standard
library, importable from anywhere (the launcher's config CLI, the console,
the proxy, a test). The execution classes stay per product line (mac-dev's
faxl/engine/backends.py); its make_backend() only asks this registry which
names exist.

    name             the id config.json, FAXL_BACKEND and /api/backend/switch use
    label            what a person reads ("this Mac (MLX)")
    kind             "in_process" (the model runs in the proxy) | "remote"
                     (faxl sits in front of another server)
    platforms        sys.platform values it runs on (["darwin"], ["linux"])
    accepts_images   the backend can be sent image content
    models_from      "local_dirs" (weights on this disk) | "exo_catalogue"
                     (exo's /v1/models) | "openai_models" (an OpenAI-style
                     /v1/models endpoint) | "hf_cache" (complete HF-format
                     snapshots in the HuggingFace cache on this machine --
                     what vLLM loads; MLX builds excluded)
    memory_from      "host_ram" (this machine x fit_ratio) | "cluster_ram"
                     (the online nodes' sum) | "gpu_vram"
    default_model    what a fresh install comes up on (faxl_config.DEFAULT_MODEL)
    switchable       the console may switch the proxy onto it
    launcher_branch  the faxl_start.sh branch that brings it up
    apps             the app slugs (console APPS) it can run
    available        False: listed so the shape is final, not offered yet
    note             why it is not available, or None

A product line adds or overrides one with register(desc).
"""
import os
import sys

# The Mac backends name NO default model (2026-09-22). They used to repeat
# faxl_config.DEFAULT_MODEL here -- this module stays a leaf, because
# faxl_config imports it and cannot be imported back. Now that the Mac
# default is a RAM-sized ladder (faxl_config.DEFAULT_MODEL_LADDER), a string
# here would outrank it: faxl_config.default_model() reads the descriptor
# FIRST and only falls through to the ladder when the descriptor is silent.
# So silence is deliberate, and it is what makes the ladder reachable.
# vLLM still names one: an MLX build does not load there.
_DEFAULT_MODEL = None
# The same model for vLLM: the HF bf16 repo (~8.9 GB). The MLX 4-bit build
# does not load in vLLM. Recorded in faxl_config.SHIPPED_DEFAULTS too.
# vLLM names no default either (2026-09-22): faxl_config.choose_vllm_model()
# sizes the GPU and picks, offering FP8 only where the card can execute it.
_VLLM_DEFAULT_MODEL = None
_VISION_APPS = ["ocr", "cameraroll"]  # whiteboard parked 2026-09-22
# Apps that need no vision: Voice2Text repairs text on the serving model.
_APPS = _VISION_APPS + ["voice2text"]

KINDS = ("in_process", "remote")
MODELS_FROM = ("local_dirs", "exo_catalogue", "openai_models", "hf_cache")
MEMORY_FROM = ("host_ram", "cluster_ram", "gpu_vram")
FIELDS = ("name", "label", "kind", "platforms", "accepts_images",
          "models_from", "memory_from", "default_model", "switchable",
          "launcher_branch", "apps", "available", "note")

_REGISTRY = {}


def _check(desc):
    d = dict(desc)
    d.setdefault("available", True)
    d.setdefault("note", None)
    # _DEFAULT_MODEL is None for the Mac backends: setdefault must still run
    # so the FIELDS check below passes, and None is the signal faxl_config
    # reads as "ask the ladder".
    d.setdefault("default_model", _DEFAULT_MODEL)
    d.setdefault("apps", [])
    missing = [f for f in FIELDS if f not in d]
    if missing:
        raise ValueError(f"backend descriptor missing {missing}")
    name = str(d["name"]).strip().lower()
    if not name:
        raise ValueError("backend descriptor has no name")
    if d["kind"] not in KINDS:
        raise ValueError(f"{name}: kind must be one of {KINDS}")
    if d["models_from"] not in MODELS_FROM:
        raise ValueError(f"{name}: models_from must be one of {MODELS_FROM}")
    if d["memory_from"] not in MEMORY_FROM:
        raise ValueError(f"{name}: memory_from must be one of {MEMORY_FROM}")
    d["name"] = name
    d["platforms"] = list(d["platforms"])
    d["apps"] = list(d["apps"])
    return d


def register(desc):
    """Add a backend, or replace the one with the same name. Returns the
    stored descriptor (a copy: later edits to `desc` do not leak in)."""
    d = _check(desc)
    _REGISTRY[d["name"]] = d
    return dict(d)


def unregister(name):
    """Remove a backend (tests; a product line dropping a shipped one)."""
    _REGISTRY.pop(str(name or "").strip().lower(), None)


def get(name):
    """The descriptor for `name` (a copy), or None."""
    d = _REGISTRY.get(str(name or "").strip().lower())
    return dict(d) if d else None


def names():
    """Every registered name, in registration order."""
    return list(_REGISTRY)


def all_backends():
    return [dict(d) for d in _REGISTRY.values()]


def current_platform():
    """FAXL_PLATFORM when set (a test suite standing in for a Mac, or a
    product line pinning its own), else sys.platform."""
    return (os.environ.get("FAXL_PLATFORM") or sys.platform).strip().lower()


def for_platform(platform=None, available_only=False):
    """The descriptors that run on `platform` (default: this one)."""
    p = (platform or current_platform()).lower()
    return [dict(d) for d in _REGISTRY.values()
            if p in d["platforms"] and (d["available"] or not available_only)]


def is_available(name):
    d = _REGISTRY.get(str(name or "").strip().lower())
    return bool(d and d["available"])


def public(desc):
    """The descriptor fields a page needs (no internals to leak today, but
    one place to decide that)."""
    return {k: desc.get(k) for k in FIELDS}


# ---- the shipped backends ----------------------------------------------------

register({"name": "mlx", "label": "this Mac (MLX)", "kind": "in_process",
          "platforms": ["darwin"], "accepts_images": True,
          "models_from": "local_dirs", "memory_from": "host_ram",
          "default_model": _DEFAULT_MODEL, "switchable": True,
          "launcher_branch": "mlx", "apps": _APPS})
register({"name": "exo", "label": "exo cluster", "kind": "remote",
          "platforms": ["darwin"], "accepts_images": True,
          "models_from": "exo_catalogue", "memory_from": "cluster_ram",
          "default_model": _DEFAULT_MODEL, "switchable": True,
          "launcher_branch": "exo", "apps": _APPS})
# vLLM on an NVIDIA GPU (2026-09-22, step 2). IN PROCESS, not `vllm serve`:
# the proven path (nvidia-dev faxl_proxy.py FAXL_BACKEND=vllm, the s0j.7 rung --
# docs/vllm-connector-t1t2.md) is vLLM's offline LLM() inside the proxy with
# VLLM_ENABLE_V1_MULTIPROCESSING=0, because the faxl connector's plan
# side-channel is module state shared between the proxy thread and the
# scheduler/worker connector; a separate `vllm serve` process cannot see it,
# and nothing was ever proven byte-identical on the online server.
register({"name": "vllm", "label": "this machine's GPU (vLLM)",
          "kind": "in_process", "platforms": ["linux"], "accepts_images": True,
          "models_from": "hf_cache", "memory_from": "gpu_vram",
          "default_model": _VLLM_DEFAULT_MODEL, "switchable": True,
          "launcher_branch": "vllm", "apps": _APPS})

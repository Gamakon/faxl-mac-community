# Vendored engine module (faxl_speculator.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""The cross-session n-gram store that drafts tokens for speculative decoding.

WHAT IT IS FOR. Decoding one token costs a full pass through every layer, and
on a big model most of that is fixed per-pass overhead rather than arithmetic:
measured on Qwen3.8-Flash-Next, ~190 ms of a 261 ms token. Verifying EIGHT
guessed tokens in one pass costs only 1.8x one token, so a guess that is right
even 10% of the time pays for itself. That is the whole economics.

Guesses come from here. If the model has written "def __init__(self" before and
has just written "def __init__(", the next token is probably "self". Feed the
guess in with the real token, and the model says whether it agrees. Agree and
the token was free; disagree and we keep the model's own token, so a wrong
guess costs a little time and NEVER changes the answer.

WHY THIS BELONGS IN faxl AND NOWHERE ELSE. Within one conversation there is not
enough history: measured, a drafter had a guess ready on only 10-23% of steps,
which is barely break-even. But faxl is a caching layer that already persists
across sessions. Harvesting n-grams from EVERY past generation lifted coverage
10% -> 32.8% and throughput to 1.45x -- from three past sessions. A stateless
inference server cannot do this; it forgets everything when the connection
closes. And like the prefix cache, it gets better the more it is used.

    (AM, 2026-10-03: "we are a caching layer, and so - can we not capture these
    across all sessions and build a ultraquick faxl lookup?")

KEYED BY TOKENIZER, NOT BY NAMESPACE. The obvious move is ns_identity's
canonical 7-tuple, and it is wrong here: config_hash carries the checkpoint
grid, so changing FAXL_CKPT_EVERY would orphan the entire speculation store for
no correctness gain. The precedent is faxl_proxy's token files, which are
deliberately UNSCOPED -- "same token ids = identical content". An n-gram means
what the TOKENIZER says it means, so that is the key. Tenant stays in it,
because one customer's text must never draft another's.

PRIVACY. These are token sequences, so they decode back to verbatim user text,
exactly like the token records faxl already writes 0600 inside a 0700
directory. Same discipline here, no exceptions.
"""

import hashlib
import json
import os
import threading
import time

# NOTE: store_lifecycle's usage_score/pick_victims kernel is NOT used here.
# It ranks BLOB FILES by hit recency against a byte cap; this table is a single
# in-memory dict persisted as one file, so eviction is insertion-order on the
# dict (re-inserting a gram moves it to the end, so the least recently LEARNED
# goes first). If the store ever becomes one file per gram, switch to that
# kernel rather than growing a second one.

# How many tokens of context identify a continuation, and how many we propose.
# Measured on real output: n=3 fires on 17.9% of steps at 69.4% precision; n=1
# fires on 58.2% but is only 35% right; n=4 is 92.6% right but fires half as
# often. All plateau near 1.45 tok/step WITHIN one context -- the win comes
# from the cross-session store, not from tuning n.
DEFAULT_N = 3
DEFAULT_K = 4

# Harvests between disk writes. See save_every().
DEFAULT_SAVE_EVERY = 10

_LOCK = threading.Lock()


def _bool(v, default=False):
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def learning():
    """Is the table being filled? ON by default, and separate from using it.

    The store is built from generations faxl has already served, so harvesting
    costs a dictionary insert and no inference. Keeping it always-on is what
    makes the feature worth switching on later: a user who enables speculation
    on a machine that has been running for a week gets a table that already
    knows their work, rather than starting cold.

    (AM, 2026-10-03: "speculative decoding will be Trained (database loaded)
    all the time, and if you chose to use it, your results could improve
    greatly".)
    """
    from faxl.engine import faxl_config
    return _bool(faxl_config.get("speculate_learn", "FAXL_SPECULATE_LEARN",
                                 "1"), True)


def enabled():
    """Is the table being USED to draft? OFF by default.

    Drafting trades exact reproducibility for speed. Every token still comes
    from the model's own forward pass, so quality is unaffected -- but where
    two continuations are near-equally likely the accelerated run may settle on
    the other one, so it is not guaranteed to reproduce an unaccelerated run
    word for word. The prefix cache IS lossless and stays on; this is the one
    part of faxl that is not, so the user decides.
    """
    from faxl.engine import faxl_config
    return _bool(faxl_config.get("speculate", "FAXL_SPECULATE", "0"), False)


def ngram_n():
    from faxl.engine import faxl_config
    return _clamp(faxl_config.get("speculate_n", "FAXL_SPECULATE_N", DEFAULT_N),
                  1, 8, DEFAULT_N)


def draft_k():
    from faxl.engine import faxl_config
    return _clamp(faxl_config.get("speculate_k", "FAXL_SPECULATE_K", DEFAULT_K),
                  1, 8, DEFAULT_K)


def save_every():
    """How many harvests between disk writes. 10 by default.

    The table lives in RAM and only reaches disk on save(), so a kill loses
    everything learned since the last write. Saving every request would mean
    rewriting the whole JSON file per answer -- the write is O(table), not
    O(new grams), so that cost grows as the asset becomes valuable. Ten is the
    compromise: a crash costs at most nine conversations of learning, and a
    clean stop costs none, because shutdown saves.

    (AM, 2026-10-03: "Include a backup to disk that makes it durable if we
    crash every 10 messages".)
    """
    from faxl.engine import faxl_config
    return _clamp(faxl_config.get("speculate_save_every",
                                  "FAXL_SPECULATE_SAVE_EVERY",
                                  DEFAULT_SAVE_EVERY),
                  1, 10000, DEFAULT_SAVE_EVERY)


def cap_gb():
    from faxl.engine import faxl_config
    try:
        return max(0.01, float(faxl_config.get(
            "speculate_cap_gb", "FAXL_SPECULATE_CAP_GB", 1.0)))
    except (TypeError, ValueError):
        return 1.0


def _clamp(v, lo, hi, default):
    """A bad setting falls to the default rather than breaking a request."""
    try:
        n = int(v)
    except (TypeError, ValueError):
        return default
    return default if n < lo or n > hi else n


def tokenizer_key(model, revision="", tenant=""):
    """What an n-gram store is scoped to: the tenant and the tokenizer.

    Token id 4721 means different things to different tokenizers, so replaying
    one model's grams for another is silent corruption. It means the SAME thing
    across quantizations, checkpoint grids and backends of one model, so those
    must not be in the key or the store is orphaned by an unrelated setting.
    """
    raw = "|".join(str(x or "") for x in (tenant, model, revision))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


class Speculator:
    """An n-gram table for one tokenizer, persisted across sessions.

    Hot path is a dict lookup -- O(1), no GPU work, no model. The benchmark
    version scanned the context backwards per step, which is O(context) python
    and would eat the win on a 54k-token agentic prompt.
    """

    def __init__(self, path, n=None, k=None, cap_bytes=None,
                 save_every_n=None):
        self.path = str(path)
        self.n = int(n or ngram_n())
        self.k = int(k or draft_k())
        self.save_every = int(save_every_n or save_every())
        self._unsaved = 0          # harvests since the last disk write
        self.cap_bytes = int(cap_bytes if cap_bytes is not None
                             else cap_gb() * (1 << 30))
        self.table = {}            # tuple(n tokens) -> [continuation tokens]
        self.sessions = 0
        # Observed, so the console can show the claim rather than assert it.
        self.drafted = 0           # steps where a guess was offered
        self.accepted = 0          # tokens the model agreed with
        self.proposed = 0          # tokens guessed
        self.steps = 0             # decode steps seen
        os.makedirs(os.path.dirname(self.path) or ".", mode=0o700,
                    exist_ok=True)
        self._load()

    # ---- persistence ------------------------------------------------------

    def _load(self):
        if not os.path.isfile(self.path):
            return
        try:
            with open(self.path) as fh:
                blob = json.load(fh)
        except (OSError, ValueError):
            return                 # a torn store is not worth a failed boot
        if blob.get("n") != self.n:
            return                 # built for a different n: start clean
        self.sessions = int(blob.get("sessions") or 0)
        for key, cont in (blob.get("grams") or {}).items():
            try:
                self.table[tuple(int(t) for t in key.split(","))] = list(cont)
            except (TypeError, ValueError):
                continue

    def save(self):
        """Write the table. 0600 inside a 0700 directory, atomically.

        The same discipline as faxl's token records, and for the same reason:
        these decode back to the user's own text. The write is tmp+replace so a
        crash cannot leave a half-table that the next boot would read.
        """
        with _LOCK:
            self._evict_to_cap()
            payload = {"n": self.n, "sessions": self.sessions,
                       "grams": {",".join(str(t) for t in key): cont
                                 for key, cont in self.table.items()}}
            tmp = self.path + f".tmp{os.getpid()}"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            try:
                with os.fdopen(fd, "w") as fh:
                    json.dump(payload, fh)
                    fh.flush()
                    os.fsync(fh.fileno())
                os.replace(tmp, self.path)
                self._unsaved = 0        # only once the bytes are really down
            except BaseException:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise

    def _evict_to_cap(self):
        """Keep the table under its cap, newest-first.

        A 54k-token agentic prompt yields ~54k grams, so this is not optional:
        an uncapped table becomes the next disk problem, and a thrashing one
        stops "improves with use" being true.
        """
        if self.cap_bytes <= 0:
            return
        # ~24 bytes per gram in the serialised form, measured on real tables.
        max_grams = max(1024, self.cap_bytes // 24)
        if len(self.table) <= max_grams:
            return
        drop = len(self.table) - max_grams
        for key in list(self.table)[:drop]:   # dict preserves insertion order
            del self.table[key]

    # ---- the two hot operations ------------------------------------------

    def draft(self, context):
        """Up to k tokens to try next, or [] when we have no opinion.

        O(1): one tuple build and one dict lookup. Never raises -- a drafter
        that throws would take down a request it was only meant to speed up.
        """
        try:
            if len(context) < self.n:
                return []
            return list(self.table.get(tuple(context[-self.n:]), ()))[:self.k]
        except Exception:                                  # noqa: BLE001
            return []

    def harvest(self, tokens):
        """Learn every n-gram -> continuation in one finished generation.

        Called once per request with prompt + output: it is a cache of the
        user's content either way, and the prompt is where the agentic
        repetition lives.
        """
        try:
            toks = [int(t) for t in tokens]
        except (TypeError, ValueError):
            return 0
        n, k = self.n, self.k
        if len(toks) <= n:
            return 0
        added = 0
        with _LOCK:
            for i in range(len(toks) - n):
                key = tuple(toks[i:i + n])
                cont = toks[i + n:i + n + k]
                if not cont:
                    break
                # Last writer wins: recent continuations beat stale ones, and
                # re-inserting moves the key to the end, which is what makes
                # insertion-order eviction drop the least recently learned.
                if key in self.table:
                    del self.table[key]
                self.table[key] = cont
                added += 1
            self.sessions += 1
            self._unsaved += 1
            due = self._unsaved >= self.save_every
        # SAVE OUTSIDE THE LOCK, DELIBERATELY. _LOCK is a plain threading.Lock,
        # not an RLock, and save() takes it too -- calling it from inside the
        # block above would deadlock the request thread permanently.
        if due:
            try:
                self.save()
            except OSError as exc:
                # A failed write must not fail the request that triggered it:
                # the table is still intact in RAM and the next harvest retries.
                print(f"[faxl] speculator save failed ({type(exc).__name__}: "
                      f"{exc}); the table is still in memory", flush=True)
        return added

    # ---- what the console shows ------------------------------------------

    def record(self, offered, accepted_count, proposed_count):
        self.steps += 1
        if offered:
            self.drafted += 1
            self.proposed += int(proposed_count)
            self.accepted += int(accepted_count)

    def stats(self):
        """Honest figures: None where nothing has been observed yet.

        A fresh install genuinely has no coverage, and the panel must say
        "learning" rather than render a zero that looks like a broken feature.
        """
        cov = (self.drafted / self.steps) if self.steps else None
        acc = (self.accepted / self.proposed) if self.proposed else None
        tok = (1 + self.accepted / self.steps) if self.steps else None
        return {"enabled": True,
                "n": self.n, "k": self.k,
                "grams": len(self.table),
                "sessions": self.sessions,
                "steps": self.steps,
                "coverage": cov,
                "acceptance": acc,
                "tokens_per_step": tok,
                "store_bytes": (os.path.getsize(self.path)
                                if os.path.isfile(self.path) else 0),
                "cap_bytes": self.cap_bytes}


def store_path(model, revision="", tenant="", base=None):
    """~/.faxl/speculator/<tokenizer key>.json, 0700 all the way down."""
    if base is None:
        base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    d = os.path.join(base, "speculator")
    os.makedirs(d, mode=0o700, exist_ok=True)
    try:
        os.chmod(d, 0o700)        # tighten a dir left 0755 by an older build
    except OSError:
        pass
    return os.path.join(d, tokenizer_key(model, revision, tenant) + ".json")


def for_model(model, revision="", tenant="", base=None):
    """The speculator for this model, or None when it is doing neither job.

    Returned whenever LEARNING is on, even if drafting is off: the table must
    fill while the feature is unused, or enabling it later starts from nothing.
    The caller checks `enabled()` before drafting from it.
    """
    if not learning() and not enabled():
        return None
    try:
        return Speculator(store_path(model, revision, tenant, base))
    except Exception as exc:                               # noqa: BLE001
        print(f"[faxl] speculator unavailable ({type(exc).__name__}: {exc})",
              flush=True)
        return None

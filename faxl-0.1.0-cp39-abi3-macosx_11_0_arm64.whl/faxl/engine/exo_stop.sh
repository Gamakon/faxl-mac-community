#!/bin/bash
# exo_stop.sh — stop exo COMPLETELY, including its worker subprocesses.
#
# Why this exists: `pkill -f exo` alone matches only the launcher. exo
# spawns runners via multiprocessing with different command lines, and each
# one holds the whole model resident (~40 GB for Kimi-Linear-48B). Killing
# the launcher alone leaves those orphans alive, the next start refuses with
# "daemon already running with PID ...", and a few rounds of that exhausts
# RAM. On 2026-09-14 it drove the machine into swap and a WindowServer
# watchdog kernel panic.
#
# Deliberately does NOT match the bare string "exo": that also hits
# faxl_exo_sidecar.py and anything under exo-workbench, including this repo's
# own tooling.
set -uo pipefail

before=$(ps -eo rss= -p $(pgrep -d, -f "exo" 2>/dev/null || echo $$) 2>/dev/null \
         | awk '{s+=$1} END {print int(s/1048576)}')

# Launcher, then the runner subprocesses it spawned.
pkill -f -- "-m exo"              2>/dev/null
pkill -f "exo.worker.runner"      2>/dev/null
pkill -f "multiprocessing.spawn"  2>/dev/null
sleep 3

# Anything still holding the API or prefill ports is an orphan: take it out.
for port in 52415 52414; do
  for pid in $(lsof -tiTCP:$port -sTCP:LISTEN 2>/dev/null); do
    echo "orphan on :$port -> pid $pid" >&2
    kill -9 "$pid" 2>/dev/null
  done
done
sleep 2

left=$(pgrep -f -- "-m exo" | wc -l | tr -d ' ')
port=$(lsof -tiTCP:52415 -sTCP:LISTEN 2>/dev/null | wc -l | tr -d ' ')
echo "exo processes left: $left | listeners on 52415: $port"
[ "$left" = "0" ] && [ "$port" = "0" ] && echo "CLEAN" || { echo "NOT CLEAN"; exit 1; }

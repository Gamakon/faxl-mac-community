#!/usr/bin/env python3
"""Halo proxy console — /console + /api/* served by the proxy itself.

ONE console across Mac/NVIDIA/local/server (docs/proxy-console-ui-spec.md). It is
a pure client of the telemetry aggregator: it reads folded events and shapes them
into the spec's typed payloads. It NEVER recomputes a number the aggregator owns.

Built as a Flask BLUEPRINT via a factory that takes everything injected — the
aggregator, the WAL path, and callables for live proxy state — so it imports
nothing from faxl_proxy (importing that loads the model) and is testable on a bare
Flask app with a synthetic WAL.

This module (commit 2) ships the READ-ONLY /api/* surface + the shaping layer.
Agent/Human HTML and verify/replay are later commits.
"""
import html
import os
import threading
import time

from flask import Blueprint, jsonify, request, Response

from faxl.engine.telemetry import faxl_event_pb2 as pb

# ---- mode selection (spec §2) -------------------------------------------------
# Priority: ?mode= > Accept header > User-Agent heuristic > default Human.
_AGENT_UA = ("lynx", "w3m", "curl", "wget", "python-requests", "agent",
             "claude", "openclaw", "hermes")


def select_mode(args, headers):
    m = args.get("mode")
    if m in ("human", "agent"):
        return m
    fmt = args.get("format")
    if fmt == "json":
        return "json"
    if fmt == "text":
        return "text"
    if fmt == "html":
        return "human"
    accept = (headers.get("Accept") or "").lower()
    if "application/json" in accept:
        return "json"
    if "text/plain" in accept:
        return "text"
    ua = (headers.get("User-Agent") or "").lower()
    if any(a in ua for a in _AGENT_UA):
        return "agent"
    return "human"


# Nav lists ONLY pages that exist this build (an agent reads the breadcrumb as the
# site map, §3 — advertising 404s is dishonest). cache/settings/human-view grow
# the nav as they land.
_NAV = "proxy › overview | requests | models | verify"

# ---- frozen unit vocabulary (spec §7.1): (unit -> (arity, base_unit)) ----------
# Renaming a unit is a breaking change to Agent-mode scrapers; adding one is free.
# gpu_s / req_s are RESERVED-UNPOPULATED: they must never appear on a default
# screen until the core measures them.
UNIT_VOCAB = {
    "s":        ("scalar", "seconds"),
    "ms":       ("scalar", "milliseconds"),
    "tok":      ("scalar", "tokens"),
    "ratio":    ("scalar", "unit_interval"),
    "GB":       ("scalar_or_pair", "gigabytes"),
    "count":    ("scalar", "count"),
    "currency": ("scalar", "minor_unit"),
    # reserved-unpopulated:
    "gpu_s":    ("scalar", "gpu_seconds"),
    "req_s":    ("scalar", "requests_per_second"),
}
RESERVED_UNITS = {"gpu_s", "req_s"}


# Unknown units seen at runtime — the "surfaced in diagnostics" promise (no
# silent degrade). Module-level so /api/diagnostics can report drift.
UNKNOWN_UNITS_SEEN = set()


def _entry(key, label, value, unit, basis, **extra):
    """One savings/tiles entry. Every entry carries `basis`. Flags an unknown
    unit (no silent degrade — surfaced in diagnostics)."""
    e = {"key": key, "label": label, "value": value, "unit": unit, "basis": basis}
    if unit not in UNIT_VOCAB:
        e["unit_unknown"] = True   # rendered raw + surfaced in /api/diagnostics
        UNKNOWN_UNITS_SEEN.add(unit)
    e.update(extra)
    return e


def shape_overview(ov, backend_name, model, bind, lossless=None, ttft=None,
                   cache=None):
    """Pure: aggregator overview -> the spec's /api/overview payload.

    Honesty rules made structural:
      * savings[0] = tokens_skipped (MEASURED on every backend) — the headline.
      * time_saved is SECONDARY, basis=estimated, carrying coverage + estimator;
        OMITTED entirely when there is no honest value (no completed rows).
      * every entry carries basis; aggregate entries carry coverage counts.
    Default tiles (spec §5.1): hit rate, median TTFT warm/cold (only where the
    backend emits TTFT), tokens skipped, cache size/limit (when injected).
    """
    savings = [
        _entry("tokens_skipped", "prefill tokens skipped",
               ov["tokens_skipped"], "tok", "measured"),
        _entry("hit_rate", "hit rate", ov["hit_rate"], "ratio", "measured"),
    ]
    # time saved: only when we have completed rows AND some saved-time basis.
    n_saved = ov["n_saved_measured"] + ov["n_saved_estimated"]
    if n_saved > 0 and ov["time_saved_ms_estimated"] > 0:
        savings.insert(1, _entry(
            "time_saved", "time saved (estimated)",
            round(ov["time_saved_ms_estimated"] / 1000.0, 1), "s", "estimated",
            coverage={"n_measured": ov["n_saved_measured"],
                      "n_estimated": ov["n_saved_estimated"],
                      "measured_fraction": ov["saved_time_measured_coverage"]},
            estimators=ov["estimators"]))

    tiles = [
        _entry("hit_rate", "hit rate", ov["hit_rate"], "ratio", "measured"),
    ]
    # median TTFT warm/cold — ONLY when the backend emits TTFT (absent != 0).
    if ttft and ttft.get("available") and ttft.get("warm_ms") is not None:
        tiles.append(_entry(
            "ttft", "median TTFT", [ttft["warm_ms"], ttft.get("cold_ms")], "ms",
            "measured", format="warm / cold"))
    tiles.append(_entry("tokens_skipped", "tokens skipped", ov["tokens_skipped"],
                        "tok", "measured"))
    # cache size / limit — only when the backend actually reports GB used+limit
    # (some index_stats expose only entry counts). A null-valued tile is never
    # shown; fall back to an entry-count tile when that's what's available.
    if cache and cache.get("available"):
        if cache.get("used_gb") is not None and cache.get("limit_gb") is not None:
            tiles.append(_entry(
                "cache_used", "cache", [cache["used_gb"], cache["limit_gb"]],
                "GB", "measured", format="used / limit"))
        elif cache.get("entries") is not None:
            tiles.append(_entry("cache_entries", "cache entries",
                                cache["entries"], "count", "measured"))

    return {
        "backend": {"name": backend_name},
        "savings": savings,
        "tiles": tiles,
        "counts": {"requests": ov["requests"], "hits": ov["hits"],
                   "misses": ov["misses"], "completed": ov["completed"],
                   "rejected": ov["rejected"], "incomplete": ov["incomplete"],
                   "pending": ov["pending"]},
        "lossless": lossless or {"status": "never", "verified_at": None},
        "model": model,
        "bind": bind,
    }


# ---- Agent-mode renderers (spec §6): semantic HTML, Lynx/curl-valid, no JS ----
_AGENT_CSS = ("body{font-family:monospace;max-width:80ch;margin:2em auto;padding:0 1em}"
              "table{border-collapse:collapse}td,th{border:1px solid #999;"
              "padding:2px 8px;text-align:left}dt{font-weight:bold}")


def _fmt_value(v):
    if isinstance(v, list):
        return " / ".join("—" if x is None else _fmt_num(x) for x in v)
    return _fmt_num(v)


def _fmt_num(x):
    if isinstance(x, float):
        return f"{x:.4f}".rstrip("0").rstrip(".") if x != int(x) else str(int(x))
    return str(x)


def _basis_mark(entry):
    # An estimated value is ALWAYS marked (structural honesty). Aggregate coverage
    # is shown when present.
    if entry.get("basis") != "estimated":
        return ""
    cov = entry.get("coverage")
    if cov:
        return f" (estimated; measured {cov['measured_fraction']:.0%})"
    return " (estimated)"


def _overview_text(p):
    lines = [_NAV, "", "# proxy — overview",
             f"backend          {p['backend']['name']}"]
    # savings + tiles both (§3: nothing in one mode unavailable in the other);
    # skip tile keys already emitted as a saving.
    seen = set()
    for s in p["savings"]:
        lines.append(f"{s['key']:<16} {_fmt_value(s['value'])} {s['unit']}"
                     f"{_basis_mark(s)}")
        seen.add(s["key"])
    for t in p["tiles"]:
        if t["key"] in seen:
            continue
        lines.append(f"{t['key']:<16} {_fmt_value(t['value'])} {t['unit']}"
                     f"{_basis_mark(t)}")
    c = p["counts"]
    lines.append(f"requests         {c['requests']}")
    lines.append(f"incomplete       {c['incomplete']}")
    lines.append(f"lossless         {p['lossless']['status']}")
    lines.append(f"model            {p['model']}")
    lines.append(f"bind             {p['bind']}")
    return "\n".join(lines) + "\n"


def _dt(key, value, unit="", mark=""):
    v = html.escape(_fmt_value(value))
    u = f" {html.escape(unit)}" if unit else ""
    return f"<dt>{html.escape(key)}</dt><dd>{v}{u}{html.escape(mark)}</dd>"


def _page(title, nav_html, h1, inner, alt_json):
    return (f"<!doctype html><title>faxl — {html.escape(title)}</title>"
            f'<link rel="alternate" type="application/json" href="{alt_json}">'
            f"<style>{_AGENT_CSS}</style><p>{nav_html}</p>"
            f"<h1>proxy — {html.escape(h1)}</h1>{inner}")


def _overview_html(p, backend_name, model, bind):
    rows = []
    seen = set()
    for s in p["savings"]:
        rows.append(_dt(s["key"], s["value"], s["unit"], _basis_mark(s)))
        seen.add(s["key"])
    for t in p["tiles"]:               # tiles too — Agent parity with Human
        if t["key"] in seen:
            continue
        rows.append(_dt(t["key"], t["value"], t["unit"], _basis_mark(t)))
    c = p["counts"]
    for k in ("requests", "hits", "misses", "incomplete"):
        rows.append(_dt(k, c[k]))
    rows.append(_dt("lossless", p["lossless"]["status"]))
    rows.append(_dt("model", p["model"]))
    rows.append(_dt("bind", p["bind"]))
    inner = (f"<dl>{''.join(rows)}</dl>"
             f'<p><a href="/console/requests">requests</a> · '
             f'<a href="/console/models">models</a> · '
             f'<a href="/console/verify">verify</a> · '
             f'<a href="/console?format=json">json</a></p>')
    return _page("overview", html.escape(_NAV), "overview", inner, "/console?format=json")


def _models_html(fields):
    rows = "".join(_dt(k, v) for k, v in fields)
    inner = (f"<dl>{rows}</dl><p><a href=\"/console\">overview</a> · "
             f'<a href="/console/models?format=json">json</a></p>')
    return _page("models", html.escape(_NAV), "models", inner,
                 "/console/models?format=json")


def _verify_html(status, condition):
    inner = (f"<dl>{_dt('status', status)}"
             f"{_dt('determinism condition', condition)}</dl>"
             f"<p>in-proxy replay is not available in this build.</p>"
             f'<p><a href="/console">overview</a></p>')
    return _page("verify", html.escape(_NAV), "verify", inner,
                 "/console/verify?format=json")


def _requests_html(rows):
    head = ("<tr><th>time</th><th>hit/miss</th><th>rung</th><th>reused</th>"
            "<th>prefill</th><th>ttft_ms</th><th>model</th><th>client</th></tr>")
    trs = []
    for r in rows:
        hm = (r["outcome"] or r.get("status") or "").lower()
        trs.append("<tr>"
                   f"<td>{html.escape(str(r.get('ts') or ''))}</td>"
                   f"<td>{html.escape(hm)}</td>"
                   f"<td>{r.get('resume_pos') if r.get('resume_pos') is not None else ''}</td>"
                   f"<td>{r.get('prefill_skipped') if r.get('prefill_skipped') is not None else ''}</td>"
                   f"<td>{r.get('prefill_paid') if r.get('prefill_paid') is not None else ''}</td>"
                   f"<td>{r['ttft_ms'] if r.get('ttft_ms') is not None else ''}</td>"
                   f"<td>{html.escape(r.get('model') or '')}</td>"
                   f"<td>{html.escape(r.get('client') or '')}</td></tr>")
    inner = (f"<table>{head}{''.join(trs)}</table>"
             f'<p><a href="/console">overview</a> · '
             f'<a href="/console/requests?format=json">json</a></p>')
    return _page("requests", html.escape(_NAV), "requests", inner,
                 "/console/requests?format=json")


def create_console(*, aggregator, wal_path, backend_name="mlx", model="",
                   bind="127.0.0.1:8080", index_stats=None, verify_condition=None,
                   config_dir="~/.faxl"):
    """Build the console Blueprint. Everything is injected; no faxl_proxy import.

    aggregator: a faxl_aggregator.Aggregator
    wal_path: path the aggregator refreshes from (refresh-on-read)
    index_stats: optional () -> dict for the cache screen (used/limit, entries)
    verify_condition: optional () -> str, the backend determinism condition
    """
    bp = Blueprint("faxl_console", __name__)
    _fold_lock = threading.Lock()   # the aggregator fold+read is not thread-safe
    _cfg = os.path.expanduser(config_dir)

    def _with_fold(fn):
        # Hold the lock across BOTH the refresh-on-read fold AND the read, because
        # the aggregator mutates dicts/deques a concurrent read would iterate
        # (threaded=True). At local scale serializing is free.
        with _fold_lock:
            try:
                aggregator.ingest_file_wal(wal_path)
            except Exception as e:  # noqa: BLE001 — surfaced, never 500 the console
                aggregator.data_bugs.append(f"console refresh: {e}")
            return fn()

    def _tenant():
        return request.args.get("tenant")   # None = unscoped (local single-tenant)

    def _int_arg(name, default, cap):
        try:
            return min(int(request.args.get(name, str(default))), cap)
        except (TypeError, ValueError):
            return None   # signals a 400

    @bp.route("/api/overview", methods=["GET"])
    def api_overview():
        def build():
            t = _tenant()
            ov = aggregator.overview(tenant=t)
            ttft = aggregator.ttft_stats(tenant=t)
            cache = index_stats() if index_stats else None
            return jsonify(shape_overview(ov, backend_name, model, bind,
                                          ttft=ttft, cache=cache))
        return _with_fold(build)

    @bp.route("/api/daily", methods=["GET"])
    def api_daily():
        days = _int_arg("days", 7, 90)
        if days is None:
            return jsonify({"error": {"type": "bad_request",
                                      "message": "days must be an integer"}}), 400
        return _with_fold(lambda: jsonify(
            {"days": aggregator.daily(tenant=_tenant(), days=days)}))

    @bp.route("/api/requests", methods=["GET"])
    def api_requests():
        limit = _int_arg("limit", 50, 500)
        if limit is None:
            return jsonify({"error": {"type": "bad_request",
                                      "message": "limit must be an integer"}}), 400
        return _with_fold(lambda: jsonify(
            {"requests": aggregator.recent(tenant=_tenant(), limit=limit)}))

    @bp.route("/api/requests/<txn_id>", methods=["GET"])
    def api_request_detail(txn_id):
        def build():
            d = aggregator.transaction(txn_id)
            if d is None:
                return jsonify({"error": {"type": "not_found",
                                          "message": f"no transaction {txn_id}"}}), 404
            return jsonify(d)
        return _with_fold(build)

    @bp.route("/api/cache", methods=["GET"])
    def api_cache():
        stats = index_stats() if index_stats else {"available": False}
        return jsonify(stats)

    @bp.route("/api/verify", methods=["POST"])
    def api_verify():
        # Replay is a later phase. Honest-unimplemented: 501, never a fake pass.
        cond = verify_condition() if verify_condition else "unknown"
        return jsonify({"error": {"type": "not_implemented",
                                  "message": "in-proxy verify/replay not in this build"},
                        "determinism_condition": cond}), 501

    # ---- /console (Agent mode HTML + content negotiation; Human HTML is a later
    # commit and currently falls back to the Agent view) ------------------------
    def _overview_payload():
        t = _tenant()
        ov = aggregator.overview(tenant=t)
        return shape_overview(ov, backend_name, model, bind,
                              ttft=aggregator.ttft_stats(tenant=t),
                              cache=(index_stats() if index_stats else None))

    @bp.route("/console", methods=["GET"])
    def console_overview():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            # single self-contained asset; it polls /api/* itself. No fold here.
            from faxl.engine.faxl_console_human import HUMAN_HTML
            resp = Response(HUMAN_HTML, mimetype="text/html")
            resp.headers["Content-Security-Policy"] = (
                "default-src 'none'; style-src 'unsafe-inline'; "
                "script-src 'unsafe-inline'; connect-src 'self'; img-src data:")
            return resp
        payload = _with_fold(_overview_payload)
        if mode == "json":
            return jsonify(payload)
        if mode == "text":
            return Response(_overview_text(payload), mimetype="text/plain")
        return Response(_overview_html(payload, backend_name, model, bind),
                        mimetype="text/html")

    @bp.route("/console/requests", methods=["GET"])
    def console_requests():
        mode = select_mode(request.args, request.headers)
        rows = _with_fold(lambda: aggregator.recent(tenant=_tenant(), limit=100))
        if mode == "json":
            return jsonify({"requests": rows})
        if mode == "text":
            hdr = "ts\toutcome\trung\treused\tprefill\tttft_ms\tmodel\tclient"
            body = "\n".join(
                "\t".join(str(x) for x in (
                    r.get("ts") or "", r.get("outcome") or r.get("status") or "",
                    r.get("resume_pos") if r.get("resume_pos") is not None else "",
                    r.get("prefill_skipped") if r.get("prefill_skipped") is not None else "",
                    r.get("prefill_paid") if r.get("prefill_paid") is not None else "",
                    r.get("ttft_ms") if r.get("ttft_ms") is not None else "",
                    r.get("model") or "", r.get("client") or ""))
                for r in rows)
            return Response(f"{_NAV}\n\n{hdr}\n{body}\n", mimetype="text/plain")
        return Response(_requests_html(rows), mimetype="text/html")

    def _model_fields():
        return [("model", model), ("backend", backend_name), ("bind", bind)]

    @bp.route("/console/models", methods=["GET"])
    def console_models():
        mode = select_mode(request.args, request.headers)
        fields = _model_fields()
        if mode == "json":
            return jsonify({"fields": [{"key": k, "label": k, "value": v}
                                       for k, v in fields]})
        if mode == "text":
            return Response(f"{_NAV}\n\n" + "\n".join(f"{k}\t{v}" for k, v in fields)
                            + "\n", mimetype="text/plain")
        return Response(_models_html(fields), mimetype="text/html")

    @bp.route("/console/verify", methods=["GET"])
    def console_verify():
        mode = select_mode(request.args, request.headers)
        cond = verify_condition() if verify_condition else "unknown"
        status = "never verified (replay not available in this build)"
        if mode == "json":
            return jsonify({"status": "never", "determinism_condition": cond,
                            "implemented": False})
        if mode == "text":
            return Response(f"{_NAV}\n\nstatus\t{status}\ncondition\t{cond}\n",
                            mimetype="text/plain")
        return Response(_verify_html(status, cond), mimetype="text/html")

    @bp.route("/api/diagnostics", methods=["GET"])
    def api_diagnostics():
        h = _with_fold(lambda: aggregator.health())
        return jsonify({
            "aggregator": h,
            "wal_path": wal_path,
            "unit_vocab": {u: {"arity": a, "base": b}
                           for u, (a, b) in UNIT_VOCAB.items()},
            "reserved_units": sorted(RESERVED_UNITS),
            "unknown_units_seen": sorted(UNKNOWN_UNITS_SEEN),  # no silent degrade
            "backend": backend_name, "model": model, "bind": bind,
        })

    return bp

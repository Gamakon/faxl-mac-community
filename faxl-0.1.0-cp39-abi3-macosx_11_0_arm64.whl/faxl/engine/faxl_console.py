# Vendored engine module (faxl_console.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl proxy console — /console + /api/* served by the proxy itself.

ONE console across Mac/NVIDIA/local/server (docs/proxy-console-ui-spec.md). It is
a pure client of the telemetry aggregator: it reads folded events and shapes them
into the spec's typed payloads. It NEVER recomputes a number the aggregator owns.

Built as a Flask BLUEPRINT via a factory that takes everything injected — the
aggregator, the WAL path, and callables for live proxy state — so it imports
nothing from faxl_proxy (importing that loads the model) and is testable on a bare
Flask app with a synthetic WAL.

This module (commit 2) ships the READ-ONLY /api/* surface + the shaping layer.
Agent/Human HTML and verify/replay are later commits.
"""
import html
import json
import os
import re
import shutil
import shlex
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from flask import (Blueprint, has_request_context, jsonify, redirect, request,
                   Response, send_file)

from faxl.engine import faxl_backends
from faxl.engine import faxl_config
from faxl.engine import faxl_licence
from faxl.engine import faxl_voice
from faxl.engine.telemetry import faxl_event_pb2 as pb

# ---- mode selection (spec §2) -------------------------------------------------
# Priority: ?mode= > Accept header > User-Agent heuristic > default Human.
_AGENT_UA = ("lynx", "w3m", "curl", "wget", "python-requests", "agent",
             "claude", "openclaw", "hermes")


# ---------------------------------------------------------------- launcher
# THE BIG RED BUTTON HAS TO WORK ON A MACHINE THAT IS NOT THIS ONE.
#
# These paths used to be "~/Dev/gamakon/faxl-mac-dev/tools/faxl_exo_up.sh" and
# "~/faxl-live/exo_stop.sh" -- a developer checkout in one person's home. On a
# customer's Mac every power and restart button answered 501 "launcher not
# found", which is the whole exo surface of the product dead on arrival: the
# console is how a non-technical owner drives their cluster, and these are the
# only controls it has.
#
# The scripts now SHIP IN THE WHEEL, beside this module, so the default is
# found wherever the package is installed. FAXL_LAUNCHER and FAXL_STOP_SCRIPT
# still override, for driving a working copy. On the nvidia line the scripts
# are absent and the 501 fires honestly -- there is no exo there to launch.
#
# ONE LAUNCHER (2026-09-21). There were two, faxl_up.sh (mlx) and
# faxl_exo_up.sh (exo), and every route picked one -- so the backend was
# "whichever script ran last", which support cannot see and a customer cannot
# be asked about. The backend and model now live in ~/.faxl/config.json
# (faxl_config). Every route that changes or restarts the stack does the same
# three things: validate, faxl_config.set_backend(backend, model), then stop
# and exec faxl_start.sh, which starts whatever the file says.


def _pkg_script(name, env_var):
    """Resolve a shipped script: the override, else the copy beside us."""
    override = os.environ.get(env_var)
    if override:
        return os.path.expanduser(override)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), name)


def _start_path():
    """faxl_start.sh: the one launcher, for both backends. FAXL_LAUNCHER
    overrides it, for driving a working copy."""
    return _pkg_script("faxl_start.sh", "FAXL_LAUNCHER")


def _local_models():
    """[(id, path)] -- one entry per model on this machine, with the directory
    its size is measured from.

    A model counts only when its WEIGHTS are here (faxl_config.
    weights_complete: config.json and every shard). A config.json alone is a
    part-finished download, or the tokenizer files the proxy fetches for an
    exo model -- and counting that as "on this Mac" is how a switch to mlx
    kept a 130 GB cluster model and started downloading it (2026-09-21).
    Whether a value may be RUN is the fit rule's question (_fits), which
    asks faxl_config.local_model_dir directly."""
    return faxl_config.local_models()


def _listdir(path):
    """os.listdir that answers [] for a directory that is not there.

    A machine with no exo and no HF cache is a legitimate state -- it is what
    a fresh install looks like -- and it must produce an empty catalogue, not
    a traceback out of a route.
    """
    try:
        return sorted(os.listdir(path))
    except OSError:
        return []


def _backend_is_exo():
    """Is the configured backend exo?

    Read from faxl_config -- the file the relaunched process will itself
    read, with FAXL_BACKEND overriding exactly as it does there -- rather
    than from the backend object, because the restart path runs before any
    backend is constructed. faxl_config's default ("mlx") is the proxy's
    default by construction: both read the same function.

    "exo" here is the CAPABILITY, not the name (faxl_backends): a backend
    whose memory is a cluster's, which faxl_start.sh brings up behind faxl
    and exo_stop.sh stops.
    """
    return _is_cluster(faxl_config.backend())


def _is_cluster(name):
    """Does backend `name` run on a cluster faxl sits in front of?"""
    return (faxl_backends.get(name) or {}).get("memory_from") == "cluster_ram"


def _env_override(backend=None, model=None):
    """(var, value) of an env override that would UNDO this choice, or None.

    The precedence is env > config.json, in this process and in the one the
    launcher starts. So when FAXL_BACKEND (or FAXL_MODEL) is set in this
    proxy's environment to something else, a console switch would write the
    file, restart, and come back on the env's value -- a button that
    "worked" and did nothing. Refused instead, naming the variable.

    The same value is not a conflict: a proxy started by the old launchers
    carries FAXL_BACKEND=<what it runs>, and restarting it on the same
    backend must keep working (the relaunch drops the variable; see
    _launch_env).
    """
    b = os.environ.get("FAXL_BACKEND", "")
    if backend and b.strip() and b.strip().lower() != backend:
        return "FAXL_BACKEND", b
    m = os.environ.get("FAXL_MODEL", "")
    if model and m.strip() and m.strip() != model \
            and faxl_config.hub_id(m.strip()) != faxl_config.hub_id(model):
        return "FAXL_MODEL", m
    return None


def _env_refusal(backend=None, model=None):
    """A 409 response when the environment would undo this choice, else None."""
    hit = _env_override(backend, model)
    if not hit:
        return None
    var, val = hit
    return jsonify({
        "ok": False, "env_override": var,
        "error": (f"{var}={val} is set in this proxy's environment, and the "
                  f"environment overrides {faxl_config.config_path()}: the "
                  f"proxy would come back on {val}. Restart the proxy once "
                  f"from the console on its current backend (the relaunch "
                  f"drops the variable), or unset {var} in the shell or "
                  f"service that starts faxl.")}), 409


def _stop_path():
    return _pkg_script("exo_stop.sh", "FAXL_STOP_SCRIPT")


def _config_block():
    """What the NEXT start will run, and where each value comes from.

        {"path": ~/.faxl/config.json,
         "backend": {"value", "source", "env_var"},
         "model":   {"value", "source", "env_var"}}

    source is "env" | "config" | "default". This is not what is running
    (state.backend.name / state.model.id say that); it is what a restart
    brings back. "env" is the one support needs to see first: the console
    cannot change a value the environment is pinning, and says so.
    """
    d = faxl_config.describe()
    return {"path": d["path"],
            "backend": {k: d["backend"][k] for k in ("value", "source",
                                                      "env_var")},
            "model": {k: d["model"][k] for k in ("value", "source",
                                                  "env_var")}}


def _log_path(name):
    """Logs live under ~/.faxl, beside the store and the telemetry, rather
    than the ~/faxl-live scratch directory this was developed out of."""
    base = os.path.join(
        os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl"), "logs")
    return os.path.join(base, name)


def _launch_env(config_written=False):
    """Environment for a launched script.

    EXO_SRC is dropped: this proxy is run with it pointing one level deeper
    (.../exo/src) so Python can import exo, and the launcher would follow it
    to a .venv that does not exist. FAXL_PYTHON is added because the launcher
    must not guess an interpreter -- the one running this console is by
    definition the one that has faxl and exo installed.

    config_written: the caller has JUST written the backend and model to
    config.json (faxl_config.set_backend). Then FAXL_BACKEND and FAXL_MODEL
    are dropped too. The env beats the file, so a value inherited from the
    shell that first started this proxy -- or put there by the old two
    launchers, which exported both on every start -- would silently win over
    the choice the console just saved. The routes refuse (409) when such a
    value DIFFERS from the choice, so what is dropped here is at most the
    same value, and dropping it is what lets the new proxy report its source
    as "config" -- and lets the NEXT switch work. When the console did NOT
    write the file (a migration, an app job), the variables are left alone:
    they are still the operator's standing instruction, and nothing the
    console saved stands in for them.
    """
    drop = {"EXO_SRC"}
    if config_written:
        drop |= {"FAXL_BACKEND", "FAXL_MODEL"}
    env = {k: v for k, v in os.environ.items() if k not in drop}
    env["FAXL_PYTHON"] = sys.executable
    return env


def select_mode(args, headers):
    m = args.get("mode")
    if m in ("human", "agent"):
        return m
    fmt = args.get("format")
    if fmt == "json":
        return "json"
    if fmt == "text":
        return "text"
    if fmt == "html":
        return "human"
    accept = (headers.get("Accept") or "").lower()
    if "application/json" in accept:
        return "json"
    if "text/plain" in accept:
        return "text"
    ua = (headers.get("User-Agent") or "").lower()
    if any(a in ua for a in _AGENT_UA):
        return "agent"
    return "human"


# Nav lists ONLY pages that exist this build (an agent reads the breadcrumb as the
# site map, §3 — advertising 404s is dishonest). cache/settings/human-view grow
# the nav as they land.
#
# ONE list, both modes. Until now the nav was a plain string rendered through
# html.escape(), so every item arrived as TEXT: register and licence were served
# on every page and reachable by nobody, because there was nothing to click. A
# separate hardcoded four-link footer carried the only real links and had drifted
# to a different, shorter set. Deriving both from this list is what stops the two
# from disagreeing again — adding a page here adds it everywhere, or nowhere.
_NAV_ITEMS = [("welcome",   "/console"),
              ("status",    "/console/status"),
              ("analytics", "/console/analytics"),
              ("log",       "/console/requests"),
              ("models",    "/console/models"),
              ("chat",      "/console/chat"),
              ("apps",      "/console/apps"),
              ("verify",    "/console/verify"),
              ("licence",   "/console/licence"),
              ("configure", "/console/configure"),
              ("upgrade",   "https://faxl.ai/shop.html")]

# Renamed 2026-09-18, because the old names described the CODE, not the job:
#   overview -> welcome     landing was the analytics dashboard; a new user
#                           needs the mark, the strapline and a way in.
#   (new)       status      model/backend/bind/uptime -- what the old "models"
#                           page actually showed, which was never about models.
#   (new)       analytics   the charts and tiles that used to occupy the
#                           landing page.
#   requests -> log         it is a log. The route stays /console/requests so
#                           nothing that linked it breaks.
#   register -> models      nobody is "registering" anything; they are choosing
#                           the model this machine serves. /console/register
#                           301s to /console/models.
#   (new)       upgrade     the only item that leaves the console, to the shop
#                           on the public site. The trial is 30 days, so the
#                           way to buy has to be visible from every page --
#                           not buried on the one page you visit when
#                           something has already gone wrong.

# Text/agent mode: the breadcrumb as a site map, no markup.
_NAV = "proxy › " + " | ".join(label for label, _ in _NAV_ITEMS)

# RETIRED PAGES (2026-09-21, plan: console-dashboard-rebuild "Retired pages").
# A person's /console is the desktop control panel now, and every old page it
# replaced has a drawer there or is the panel itself. In HUMAN mode those URLs
# redirect to the panel, opening the matching drawer; agent, json and text
# modes of every one are unchanged, because agents read them (spec §6).
#
# ONE map, used twice: by the redirects, and by _panel_href() for the hrefs in
# the panel's state -- so a notice can never send a person to a page that only
# bounces them back.
_PANEL_HREFS = {
    "/console/status":    "/console",
    "/console/analytics": "/console",
    "/console/requests":  "/console",
    "/console/chat":      "/console",
    "/console/models":    "/console?open=drawer-models",
    "/console/register":  "/console?open=drawer-models",
    "/console/verify":    "/console?open=drawer-verify",
    "/console/licence":   "/console?open=drawer-licence",
    "/console/configure": "/console?open=drawer-store",
}


def _panel_href(old):
    """Where a console href lands for a person using the panel.

    A retired page maps to the panel (with its drawer); anything else -- the
    apps, the shop, a drawer anchor, None -- comes back unchanged. The agent
    view never calls this, so it keeps the pages it documents."""
    if not old or not isinstance(old, str):
        return old
    path = old.split("#", 1)[0].split("?", 1)[0]
    return _PANEL_HREFS.get(path, old)


def _retired(path, txn=None):
    """The 302 a person gets from a retired page: the panel, with its drawer.
    An explicit ?mode=human is carried, like every other console link."""
    target = _PANEL_HREFS[path]
    extra = []
    if txn:
        target = "/console?open=drawer-request"
        extra.append("txn=" + urllib.parse.quote(str(txn), safe=""))
    if _explicit_mode() == "human":
        extra.append("mode=human")
    if extra:
        target += ("&" if "?" in target else "?") + "&".join(extra)
    return redirect(target, code=302)


# What a PERSON's shell pages list: only the apps pages and the fallback welcome
# page still wear the shell, so their nav is the way back to the panel, the apps,
# and (added by the shell's footer from agent_href) the agent view. A nav that
# listed the retired pages would be a row of links that all land on /console.
_HUMAN_NAV_ITEMS = [("welcome", "/console"),
                    ("apps",    "/console/apps")]


def _explicit_mode():
    """The mode the client ASKED for in the query string, or None.

    Only ?mode= counts. A mode that select_mode() inferred from Accept or the
    User-Agent is re-inferred on the next request for free, so it is never
    written into a link; an explicit one is lost on the first click unless the
    links carry it, which is exactly what used to happen."""
    if not has_request_context():
        return None
    m = request.args.get("mode")
    return m if m in ("human", "agent") else None


_CONSOLE_HREF = re.compile(r'href="(/console(?:/[^"#?]*)?)(\?[^"#]*)?(#[^"]*)?"')


def _carry_mode(page, mode):
    """Add ?mode= to every console link in a rendered page that does not
    already choose a view (mode= or format=). Done once on the finished HTML
    rather than at each of the ~40 places a link is written, so nav,
    breadcrumb, footer, brand mark and in-body links cannot drift apart."""
    def fix(m):
        path, query, frag = m.group(1), m.group(2) or "", m.group(3) or ""
        if "mode=" in query or "format=" in query:
            return m.group(0)
        query = f"{query}&mode={mode}" if query else f"?mode={mode}"
        return f'href="{path}{query}{frag}"'
    return _CONSOLE_HREF.sub(fix, page)


def _agent_href():
    """This page, in agent mode -- the human footer's "agent view" link."""
    return (request.path if has_request_context() else "/console") + "?mode=agent"


def _origin():
    """scheme://host:port as THIS client reached the console, for the curl
    lines agent pages print -- the configured bind is not always the address
    that works from where the agent is standing."""
    if has_request_context():
        return request.host_url.rstrip("/")
    return "http://127.0.0.1:8767"


def _nav_html(current=None):
    """The same site map, clickable. `current` is rendered as plain text so the
    page you are on is not a link to itself. Ends with [human view] (spec §2):
    the same URL in the other mode, so an agent page a person opened by
    accident is one click from the page meant for them."""
    parts = []
    for label, href in _NAV_ITEMS:
        if label == current:
            parts.append(f"<strong>{html.escape(label)}</strong>")
        else:
            parts.append(f'<a href="{href}">{html.escape(label)}</a>')
    here = request.path if has_request_context() else "/console"
    parts.append(f'<a href="{html.escape(here)}?mode=human">[human view]</a>')
    return "proxy › " + " | ".join(parts)

# The console blueprint is built once, at proxy start, so this is the proxy's
# own uptime -- the number a person means when they ask how long it has been up.
_STARTED_AT = time.time()


def _uptime_str(now=None):
    """Uptime as a person says it: '3d 4h', '5h 12m', '47s'."""
    sec = int(max(0.0, (now or time.time()) - _STARTED_AT))
    d, rem = divmod(sec, 86400)
    h, rem = divmod(rem, 3600)
    m, sec_r = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    if m:
        return f"{m}m {sec_r}s"
    return f"{sec_r}s"


# ---- frozen unit vocabulary (spec §7.1): (unit -> (arity, base_unit)) ----------
# Renaming a unit is a breaking change to Agent-mode scrapers; adding one is free.
# gpu_s / req_s are RESERVED-UNPOPULATED: they must never appear on a default
# screen until the core measures them.
UNIT_VOCAB = {
    "s":        ("scalar", "seconds"),
    "ms":       ("scalar", "milliseconds"),
    "tok":      ("scalar", "tokens"),
    "ratio":    ("scalar", "unit_interval"),
    "GB":       ("scalar_or_pair", "gigabytes"),
    "count":    ("scalar", "count"),
    "days":     ("scalar", "days"),
    "currency": ("scalar", "minor_unit"),
    # reserved-unpopulated:
    "gpu_s":    ("scalar", "gpu_seconds"),
    "req_s":    ("scalar", "requests_per_second"),
}
RESERVED_UNITS = {"gpu_s", "req_s"}


# Unknown units seen at runtime — the "surfaced in diagnostics" promise (no
# silent degrade). Module-level so /api/diagnostics can report drift.
UNKNOWN_UNITS_SEEN = set()


def _entry(key, label, value, unit, basis, **extra):
    """One savings/tiles entry. Every entry carries `basis`. Flags an unknown
    unit (no silent degrade — surfaced in diagnostics)."""
    e = {"key": key, "label": label, "value": value, "unit": unit, "basis": basis}
    if unit not in UNIT_VOCAB:
        e["unit_unknown"] = True   # rendered raw + surfaced in /api/diagnostics
        UNKNOWN_UNITS_SEEN.add(unit)
    e.update(extra)
    return e


def shape_overview(ov, backend_name, model, bind, lossless=None, ttft=None,
                   cache=None, licence=None):
    """Pure: aggregator overview -> the spec's /api/overview payload.

    Honesty rules made structural:
      * savings[0] = tokens_skipped (MEASURED on every backend) — the headline.
      * time_saved is SECONDARY, basis=estimated, carrying coverage + estimator;
        OMITTED entirely when there is no honest value (no completed rows).
      * every entry carries basis; aggregate entries carry coverage counts.
    Default tiles (spec §5.1): hit rate, median TTFT warm/cold (only where the
    backend emits TTFT), tokens skipped, cache size/limit (when injected).
    """
    _received = ov["tokens_skipped"] + ov["tokens_prefilled"]
    savings = [
        # headline: the measured token ratio — "served from cache, of received".
        # `total_received` is additive (key/unit unchanged for agent scrapers).
        _entry("tokens_skipped", "prompt tokens served from cache",
               ov["tokens_skipped"], "tok", "measured",
               total_received=_received),
        _entry("hit_rate", "hit rate", ov["hit_rate"], "ratio", "measured"),
    ]
    # time saved: only when we have completed rows AND some saved-time basis.
    n_saved = ov["n_saved_measured"] + ov["n_saved_estimated"]
    if n_saved > 0 and ov["time_saved_ms_estimated"] > 0:
        savings.insert(1, _entry(
            "time_saved", "time saved (estimated)",
            round(ov["time_saved_ms_estimated"] / 1000.0, 1), "s", "estimated",
            coverage={"n_measured": ov["n_saved_measured"],
                      "n_estimated": ov["n_saved_estimated"],
                      "measured_fraction": ov["saved_time_measured_coverage"]},
            estimators=ov["estimators"]))

    tiles = [
        _entry("hit_rate", "hit rate", ov["hit_rate"], "ratio", "measured"),
    ]
    # median TTFT warm/cold — ONLY when the backend emits TTFT (absent != 0).
    if ttft and ttft.get("available") and ttft.get("warm_ms") is not None:
        tiles.append(_entry(
            "ttft", "first reply, median", [ttft["warm_ms"], ttft.get("cold_ms")],
            "ms", "measured", format="warm / cold",
            # which number is which, and from how many rows: a median of two
            # requests and a median of two thousand must not look the same.
            parts=["cache hit", "cold (miss)"],
            n=[ttft.get("n_warm"), ttft.get("n_cold")]))
    tiles.append(_entry("tokens_received", "prompt tokens received", _received,
                        "tok", "measured"))
    tiles.append(_entry("tokens_skipped", "served from cache", ov["tokens_skipped"],
                        "tok", "measured"))
    # cache size / limit — only when the backend actually reports GB used+limit
    # (some index_stats expose only entry counts). A null-valued tile is never
    # shown; fall back to an entry-count tile when that's what's available.
    if cache and cache.get("available"):
        if cache.get("used_gb") is not None and cache.get("limit_gb") is not None:
            tiles.append(_entry(
                "cache_used", "cache", [cache["used_gb"], cache["limit_gb"]],
                "GB", "measured", format="used / limit"))
        elif cache.get("entries") is not None:
            tiles.append(_entry("cache_entries", "cache entries",
                                cache["entries"], "count", "measured"))
    # The licence countdown used to be a fifth tile here. Removed 2026-09-18:
    # four cache figures fill one row, and a fifth wrapped onto a second row of
    # its own, which is what made this read as scattered rather than as a set.
    # It is not lost -- it is on /console/status beside the other facts about
    # this machine, and the welcome page raises a notice when it runs low,
    # which is the moment it matters.

    return {
        "backend": {"name": backend_name},
        "savings": savings,
        "tiles": tiles,
        "counts": {"requests": ov["requests"], "hits": ov["hits"],
                   "misses": ov["misses"], "completed": ov["completed"],
                   "rejected": ov["rejected"], "incomplete": ov["incomplete"],
                   "pending": ov["pending"]},
        "lossless": lossless or {"status": "never", "verified_at": None},
        "model": model,
        "bind": bind,
    }


_BLOBS_CAP = 5000   # dots the scatter can sensibly draw; count reports the truth


def shape_blobs(raw):
    """Pure: backend blob rows -> the /api/blobs payload. One row per cached
    blob: phash (string), hits (times reused, blob++), last_used (unix
    seconds; the write time when never hit), bytes, pos (checkpoint depth in
    tokens). Rows missing last_used are dropped (they cannot be plotted);
    the payload's `count` is the true total before the cap."""
    rows = []
    for r in raw:
        if r.get("last_used") is None:
            continue
        rows.append({"phash": str(r.get("phash")),
                     "hits": int(r.get("hits") or 0),
                     "last_used": float(r["last_used"]),
                     "bytes": r.get("bytes"),
                     "pos": r.get("pos")})
    rows.sort(key=lambda r: -r["last_used"])
    return {"blobs": rows[:_BLOBS_CAP], "count": len(rows)}


# ---- Agent-mode renderers (spec §6): semantic HTML, Lynx/curl-valid, no JS ----
_AGENT_CSS = ("body{font-family:monospace;max-width:80ch;margin:2em auto;padding:0 1em}"
              "table{border-collapse:collapse}td,th{border:1px solid #999;"
              "padding:2px 8px;text-align:left}dt{font-weight:bold}")


def _fmt_value(v):
    if isinstance(v, list):
        return " / ".join("—" if x is None else _fmt_num(x) for x in v)
    return _fmt_num(v)


def _fmt_num(x):
    if isinstance(x, float):
        return f"{x:.4f}".rstrip("0").rstrip(".") if x != int(x) else str(int(x))
    return str(x)


def _basis_mark(entry):
    # An estimated value is ALWAYS marked (structural honesty). Aggregate coverage
    # is shown when present.
    if entry.get("basis") != "estimated":
        return ""
    cov = entry.get("coverage")
    if cov:
        return f" (estimated; measured {cov['measured_fraction']:.0%})"
    return " (estimated)"


def _overview_text(p):
    lines = [_NAV, "", "# proxy — overview",
             f"backend          {p['backend']['name']}"]
    # savings + tiles both (§3: nothing in one mode unavailable in the other);
    # skip tile keys already emitted as a saving.
    seen = set()
    for s in p["savings"]:
        lines.append(f"{s['key']:<16} {_fmt_value(s['value'])} {s['unit']}"
                     f"{_basis_mark(s)}")
        seen.add(s["key"])
    for t in p["tiles"]:
        if t["key"] in seen:
            continue
        lines.append(f"{t['key']:<16} {_fmt_value(t['value'])} {t['unit']}"
                     f"{_basis_mark(t)}")
    c = p["counts"]
    lines.append(f"requests         {c['requests']}")
    lines.append(f"incomplete       {c['incomplete']}")
    lines.append(f"lossless         {p['lossless']['status']}")
    lines.append(f"model            {p['model']}")
    lines.append(f"bind             {p['bind']}")
    return "\n".join(lines) + "\n"


def _dt(key, value, unit="", mark=""):
    v = html.escape(_fmt_value(value))
    u = f" {html.escape(unit)}" if unit else ""
    return f"<dt>{html.escape(key)}</dt><dd>{v}{u}{html.escape(mark)}</dd>"


# Gamakon mark, inlined as a data URI so the console needs no extra route
# and no asset on disk — it renders identically offline and off-box.
_FAVICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAeGVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAEgAAAABAAAASAAAAAEAAqACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAAAQdIdCAAAEVUlEQVR4nLXW3XMTVRQA8HPux35kN0nzWUgiHwUMIgNSB0anwwCOM/iET7754L/jH+P4B/jgk1NQeaAKyKcFS0NDkrbpprt39957fECRxpKakd7Hnd3z27vnnHsW2xeuwH4utq/R/yeAWlujzb4ABKhVvDCXXG6nWtu3DFhCYeNr5+z8cccSEODbBAjQRXW5rWdCLjj75YnlfFKQqQGTZWcayfGW15z1rt+JBsplSG8NMBYPlbJP5gvGYG89XU8kMDH5kekAsqaa02v9lHP0Xf54jTiblAAA2MP/F2BPtNx8IKLYZJoMiD3CT7sDxiBRpjtIJUdDaCwDmJSAqQEgKhXkkYbPOa6+UIB7bmC6T4SAMIr1KGbakBSM9np9mHIHRATFvESGhVBWi1wygoldNh1gCVONtx+NgMCVeP5UIXR0kpG2k5qZV5tH3xAOjAVAAEQANNrU/GShje8f9bShY60gH8g4GjWK1oEs2taJZmy3mt0d0IbqgT5WybgZJUnGGZ1rqS8uBh+fzq++SBJlm3XPdRhHKodw9Xz+o7Z0Qa10U01yLPG7AEabVrDVDLYdll36IKwG+uxhdvZ4TmW0FZtEWSlwfZg16p4jmDagMssZO3xA5oXqrJvY7DDGAWPobDO5+qEfxbZSdDYi7UhuDV04Uwp9rlJKM7r7e2QMFUI5k5czeVkruY+fbVvCeknef6Y3EskmAFrrzy84F+dLYU4kqW3UvMFmVik59bIb5nil6BRDGeREfzNb7SazZTfn841h1umpdw76959sX3+IxHa09zhAxCTFAozvcd/lpYLjSjbXyvkeR0BL4Lks8Hngc88Tq71kFJtRbBBxrZf8dE+tRL7YWZjjAGP4tI/Lq6paYIcPupWiLBcda8lzuOAYK3vr/nBr2wQ5OUps6LMjzWC24lqCTi+pzjiPOsaAmJQDAGBCbCTOzQfpjV83f7y92Rskh2a9aNs8H6i1vrIEZ97NE8CLfnKuXQSATi+5txz9cCe9tlCq5PStZcO4eCNgCW2mjpWTk7NZuynmGs7puTBWpruetmb9etnNtK3MOI/+GL03F6YZPXy69fPd6Pu7+HSYe96Nvvy0tNIZrWzwVy2Br/8XGQsFsb1wghoVUSu5pYL0PV4vu4tLG2FOZMaShe66Uqmda/qDzXTp4Wgtko/7LnDJEHSqvrrEGlXn628VCuflQfsPYAgOBOrKSaMNxZoPIhzGFHp4qMaTJK3NiGrJAYBMAxEtP08Xf0s7Qwelyxm+jEWELianDqRLHd+gxDHAGnPlRLza1yubbqQdA4whEhFZK9DkfaoVeOCYz+ad725GN5Y9x3U4g7F5QIBGG/FaJb3KBnJGiw8ohiLjjAvif18H4AAiymDQhZN1szUyS89cz3dwt7MagcTOOn0FEKFQvMCBdhtShAiCgU3VN4vCshz7D5NgDPjLn3ArZ7A8DAg5m2aITDf0kfG9h+TOte9/138Cpn0b0YvwAqwAAAAASUVORK5CYII="


# ---- BRAND STYLING --------------------------------------------------------
# The ramp, type and grounds are faxl.ai's, copied from
# faxl-website/site/css/style.css so the console and the site are visibly one
# product. Values are the authority there; keep them in step when the site
# moves. No webfont is loaded: the console must render with no network, so
# Latin Modern is named and the stack falls back to Georgia.
_BRAND_CSS = """
:root{
  --ramp-teal:#51b3aa; --ramp-olive:#6d9f40; --ramp-oxblood:#962729;
  --serif:"Latin Modern","Latin Modern Roman",Georgia,"Times New Roman",serif;
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  color-scheme:light;
  --bg:#bfe3dc; --bg-deep:#aed9d0; --card:#fffdf7;
  --text:#16212b; --muted:#3b4a55;
  --accent:#7c672f; --accent-strong:#5f4e20;
  --rule:rgba(22,33,43,.18); --rule-gold:rgba(124,103,47,.40);
  --btn-bg:#273641; --btn-fg:#fff; --btn-bg-hover:#1a242c;
  --good:#2f6b34; --warn:#962729;
}
@media (prefers-color-scheme:dark){
  :root{
    color-scheme:dark;
    --bg:#273641; --bg-deep:#1e2a33; --card:#1e2d36;
    --text:#e8ecff; --muted:#a8b3bc;
    --accent:#b8a160; --accent-strong:#d4bd7a;
    --rule:rgba(255,255,255,.20); --rule-gold:rgba(212,189,122,.38);
    --btn-bg:#d4bd7a; --btn-fg:#1a242c; --btn-bg-hover:#e8d48a;
    --good:#7bc47f; --warn:#e88f91;
  }
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font-family:var(--serif);
  font-size:clamp(1rem,.95rem+.3vw,1.0625rem);line-height:1.6;
  text-rendering:optimizeLegibility;
  padding:clamp(1.15rem,.6rem+2.4vw,2.5rem)}
h1,h2,h3{line-height:1.15;margin:0 0 .5em;font-weight:700}
h1{font-size:clamp(1.5rem,1.2rem+1.4vw,2rem)}
h2{font-size:1.2rem;margin-top:1.6em}
h2 small{font-weight:400;color:var(--muted);font-size:.8em}
p{max-width:34rem}
a{color:var(--accent);text-decoration-thickness:.06em;text-underline-offset:.15em}
a:hover{color:var(--accent-strong)}
nav,.nav{color:var(--muted);font-size:.9rem;margin:0 0 1.4em}
code,pre,input,.mono{font-family:var(--mono)}
pre{background:var(--card);border:1px solid var(--rule);border-radius:6px;
  padding:.7rem .9rem;overflow-x:auto;font-size:.88rem;max-width:34rem}
table{border-collapse:collapse;width:100%;font-size:.9rem}
th,td{text-align:left;padding:.45rem .9rem .45rem 0;
  border-top:1px solid var(--rule);vertical-align:top}
th{font-weight:700;color:var(--muted);font-size:.82rem;
  text-transform:uppercase;letter-spacing:.04em}
dl{display:grid;grid-template-columns:auto 1fr;gap:.2em 1.2em;max-width:34rem}
dt{color:var(--muted)} dd{margin:0}
input[type=text],input:not([type]){font-family:var(--mono);font-size:.9rem;
  padding:.5rem .6rem;border:1px solid var(--rule);border-radius:6px;
  background:var(--card);color:var(--text);max-width:100%}
button{font-family:var(--serif);font-size:.95rem;font-weight:700;
  padding:.5rem 1.1rem;border:0;border-radius:6px;cursor:pointer;
  background:var(--btn-bg);color:var(--btn-fg)}
button:hover{background:var(--btn-bg-hover)}
button.secondary{background:transparent;color:var(--accent);
  border:1px solid var(--rule-gold)}
.card{background:var(--card);border:1px solid var(--rule);border-radius:8px;
  padding:1rem 1.2rem;margin:1.2rem 0;max-width:42rem}
.muted{color:var(--muted)}
.good{color:var(--good);font-weight:700}
.warn{color:var(--warn);font-weight:700}
"""


# THE POWER PANEL. Fixed bottom-right on every console page.
#
# A backend that has died should say so before the user clicks something --
# the first sign used to be an alert box reading "Connection refused", which
# tells a user nothing except that software is broken. A lamp says UP or DOWN,
# and the button next to it does something about it.
#
# The button is a physical one: an Atari-stick red dome that depresses when
# pressed. This is a control panel for a machine, and it should read as one.
_STATUS_LIGHT = """
<style>
#svc{position:fixed;right:1.1rem;bottom:1.1rem;z-index:99;
  background:var(--card);border:1px solid var(--rule);border-radius:12px;
  padding:.7rem .9rem;box-shadow:0 2px 10px #0003;font-size:.82rem;
  display:flex;flex-direction:column;gap:.55rem}
#svc .row{display:flex;align-items:center;gap:.85rem}
#svc .row+.row{border-top:1px solid var(--rule);padding-top:.55rem}
#svc #pxnote{margin:0;font-size:.74rem;color:var(--muted);max-width:14rem}
#svc #pxnote:empty{display:none}
#pxbtn{width:2.5rem;height:2.5rem;font-size:.55rem;
  background:radial-gradient(circle at 34% 30%,#ffd166,#e0a021 62%,#9c6c09);
  box-shadow:0 4px 0 #6d4c06,0 6px 9px #0006,inset 0 2px 4px #ffffff66;
  color:#3a2800}
#pxbtn:hover{background:radial-gradient(circle at 34% 30%,#ffdb85,#eeae2c 62%,#a87708)}
#svc .lamp,#svc #pxlamp{width:.8rem;height:.8rem;border-radius:50%;flex:0 0 auto;
  background:#6b7280;transition:background .25s,box-shadow .25s}
#svc.up #exolamp,#svc .lamp.up{background:#3ddc6b;
  box-shadow:0 0 6px #3ddc6b,0 0 14px #3ddc6b99,inset 0 0 3px #fff8}
#svc.down #exolamp,#svc .lamp.down{background:#ff3b30;
  box-shadow:0 0 6px #ff3b30,0 0 14px #ff3b3099,inset 0 0 3px #fff8}
#svc .label{color:var(--muted);line-height:1.25;min-width:7.5rem}
#svc .label b{display:block;color:var(--text);font-size:.9rem}
#svc.down .label b{color:#ff3b30}
#pwr{width:3.1rem;height:3.1rem;border-radius:50%;border:0;cursor:pointer;
  padding:0;flex:0 0 auto;font:inherit;font-size:.62rem;font-weight:700;
  letter-spacing:.06em;color:#fff5f5;text-transform:uppercase;
  background:radial-gradient(circle at 34% 30%,#ff6b60,#d21f16 62%,#8e1009);
  box-shadow:0 5px 0 #6d0c06,0 7px 10px #0006,inset 0 2px 4px #ffffff55;
  transition:transform .06s,box-shadow .06s}
#pwr:hover{background:radial-gradient(circle at 34% 30%,#ff7d72,#e0251b 62%,#9c120a)}
#pwr:active,#pwr.pressed{transform:translateY(4px);
  box-shadow:0 1px 0 #6d0c06,0 2px 5px #0006,inset 0 2px 6px #00000055}
#pwr:disabled{opacity:.55;cursor:wait}
#svc .row[hidden]{display:none}
#xobtn{border:1px solid var(--rule);border-radius:6px;background:var(--card);
  color:var(--text);font:inherit;font-size:.74rem;padding:.25rem .6rem;
  cursor:pointer;flex:0 0 auto}
#xobtn:disabled{opacity:.55;cursor:default}
</style>
<div id="svc">
  <div class="row">
    <span class="lamp" id="exolamp"></span>
    <span class="label"><b id="svcstate">checking</b><span id="svcwhy">backend</span></span>
    <button id="pwr" title="turn the exo backend on or off" hidden>off</button>
  </div>
  <div class="row" id="xorow" hidden>
    <span class="lamp" id="xolamp"></span>
    <span class="label"><b id="xostate">exo cluster \u2014 not running</b><span id="xowhy">the cluster backend</span></span>
    <button id="xobtn" title="switch the backend: the proxy restarts onto it">switch to exo</button>
  </div>
  <div class="row">
    <span class="lamp up" id="pxlamp"></span>
    <span class="label"><b>RUNNING</b><span>faxl proxy</span></span>
    <button id="pxbtn" class="amber" title="restart the faxl proxy">cycle</button>
  </div>
  <p id="pxnote"></p>
</div>
<script>
(function () {
  const box = document.getElementById('svc');
  const state = document.getElementById('svcstate');
  const why = document.getElementById('svcwhy');
  const btn = document.getElementById('pwr');
  const xorow = document.getElementById('xorow');
  const xolamp = document.getElementById('xolamp');
  const xostate = document.getElementById('xostate');
  const xowhy = document.getElementById('xowhy');
  const xobtn = document.getElementById('xobtn');
  let busy = false;
  let xobusy = false;
  let xoerr = '';

  // THE OTHER BACKEND, AS A SWITCH. faxl runs one execution backend per
  // proxy: this Mac (MLX) or the exo cluster, with faxl in front either way.
  // So this row offers the one NOT serving, and its button restarts the
  // proxy onto it -- it never starts exo beside the model, where nothing
  // would put faxl in front of it. Grey when not running: not a fault.
  function paintExo(d) {
    if (xobusy) return;
    d = d || {};
    const x = d.exo || {};
    xorow.hidden = false;
    if (d.backend === 'exo') {
      xolamp.className = 'lamp';
      xostate.textContent = 'this Mac (MLX) \u2014 not serving';
      xowhy.textContent = xoerr || 'switching stops exo; the proxy restarts with the model in-process';
      xobtn.textContent = 'switch to mlx';
      xobtn.dataset.to = 'mlx';
      xobtn.disabled = false;
      xobtn.title = '';
      return;
    }
    xolamp.className = x.running ? 'lamp up' : 'lamp';
    xostate.textContent = x.running ? 'exo cluster \u2014 running, faxl not in front'
                                    : 'exo cluster \u2014 not running';
    xowhy.textContent = xoerr || (x.can_start
      ? 'switching restarts the proxy onto exo, about a minute'
      : (x.note || 'cannot be switched to from here'));
    xobtn.textContent = 'switch to exo';
    xobtn.dataset.to = 'exo';
    xobtn.disabled = !x.can_start;
    xobtn.title = x.endpoint || '';
  }

  function paint(up, detail) {
    box.className = up ? 'up' : 'down';
    state.textContent = up ? 'RUNNING' : 'DOWN';
    why.textContent = detail;
    btn.textContent = up ? 'off' : 'on';
  }

  async function poll() {
    if (busy) return;
    try {
      const r = await fetch('/api/backend/status', {cache: 'no-store'});
      const d = await r.json();
      // THE BACKEND THAT IS CONFIGURED, not always exo. On mlx the model is
      // in the proxy's own process, so the top lamp reports mlx and the red
      // button (which restarts the proxy onto exo) is not for this row. It
      // used to show exo DOWN in red on a machine serving perfectly well.
      // The exo cluster gets its own row below: a switch, never red.
      if (d.backend && d.backend !== 'exo') {
        btn.hidden = true;
        paint(d.up, d.backend + ' \u2014 model in this process');
        box.title = d.model || '';
        paintExo(d);
        return;
      }
      paintExo(d);
      btn.hidden = false;
      // "Connection refused" means the service is not running. Say that,
      // not the errno.
      paint(d.up, d.up ? ('exo \u2014 ' + d.models + ' models')
                       : 'exo is not running');
      box.title = d.error || d.endpoint || '';
    } catch (e) {
      paint(false, 'proxy unreachable');
    }
  }

  btn.addEventListener('click', async function () {
    const turningOn = btn.textContent === 'on';
    busy = true;
    btn.disabled = true;
    btn.classList.add('pressed');
    state.textContent = turningOn ? 'STARTING' : 'STOPPING';
    why.textContent = turningOn ? 'this takes a moment' : '';
    try {
      await fetch('/api/backend/power', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({state: turningOn ? 'on' : 'off'})
      });
    } catch (e) {
      // Turning it on restarts this proxy too, so a dropped connection here
      // is expected rather than a failure.
    }
    // Wait for reality to catch up rather than assuming the click worked.
    let n = 0;
    const tick = setInterval(async function () {
      n += 1;
      try {
        const r = await fetch('/api/backend/status', {cache: 'no-store'});
        const d = await r.json();
        if (d.up === turningOn) {
          clearInterval(tick);
          busy = false;
          btn.disabled = false;
          btn.classList.remove('pressed');
          if (turningOn) { location.reload(); } else { poll(); }
        }
      } catch (e) { /* proxy is restarting */ }
      // KEEP WATCHING. This used to clearInterval at 90 tries and leave a
      // dead page: if the proxy came back a moment later -- which a slow
      // model load does -- the console sat there saying nothing until it was
      // reloaded by hand. Say it is taking a while, free the button so
      // another attempt is possible, and go on watching for ever.
      if (n > 90) {
        busy = false;
        btn.disabled = false;
        btn.classList.remove('pressed');
        why.textContent = 'still waiting — see ~/.faxl/logs/power.log. This '
          + 'page keeps checking and will come back on its own.';
      }
    }, 2000);
  });

  xobtn.addEventListener('click', async function () {
    const to = xobtn.dataset.to === 'mlx' ? 'mlx' : 'exo';
    if (!confirm(to === 'exo'
        ? 'Switch the backend to the exo cluster? The proxy restarts onto exo, with faxl in front of it \u2014 about a minute. The cache store survives.'
        : 'Switch the backend back to this Mac (MLX)? exo stops, and the proxy restarts with the model in its own process.')) return;
    xobusy = true;
    xoerr = '';
    xobtn.disabled = true;
    xostate.textContent = 'switching to ' + to + '\u2026';
    xowhy.textContent = 'the proxy is restarting';
    try {
      const r = await fetch('/api/backend/switch', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({backend: to})
      });
      const d = await r.json();
      if (!r.ok || d.ok === false) xoerr = d.error || ('HTTP ' + r.status);
    } catch (e) {
      // The proxy stops itself to restart: a dropped socket is expected.
    }
    if (xoerr) { xobusy = false; poll(); return; }
    // Wait for the proxy to come back on the other backend, not the click.
    let n = 0;
    const tick = setInterval(async function () {
      n += 1;
      try {
        const r = await fetch('/api/backend/status', {cache: 'no-store'});
        const d = await r.json();
        if (d.backend === to) { clearInterval(tick); location.reload(); return; }
      } catch (e) { /* restarting */ }
      if (n > 90) {
        clearInterval(tick);
        xobusy = false;
        xoerr = 'no switch seen yet \u2014 see ~/.faxl/logs/power.log';
        poll();
      }
    }, 2000);
  });

  // ---- the proxy's own button -------------------------------------
  // Shift-click stops it outright; a plain click cycles it. Stopping is a
  // one-way door from a browser -- this process serves the page -- so it is
  // deliberately the harder gesture, and it asks first.
  const pxbtn = document.getElementById('pxbtn');
  const pxnote = document.getElementById('pxnote');
  const pxlamp = document.getElementById('pxlamp');

  pxbtn.addEventListener('click', async function (ev) {
    const stopping = ev.shiftKey;
    // DOUBLED backslashes: this is a Python string, and a single one put a REAL
    // newline inside the JS literal -- a SyntaxError that stopped this whole
    // script, so the lamp sat on "checking" forever and neither button worked.
    if (stopping && !confirm(
        // Newline escapes are DOUBLED in the Python source below: this is a
        // non-raw Python string, so a single backslash became a literal
        // newline inside the JS quotes -- "Invalid or unexpected token" --
        // and took the whole status widget down with it on every agent page.
        'Stop the faxl proxy?\\n\\nThis console stops with it, so you will ' +
        'need a terminal to start it again:\\n\\n' +
        '  faxl-proxy')) return;
    pxbtn.disabled = true;
    pxbtn.classList.add('pressed');
    pxlamp.className = 'lamp down';
    pxnote.textContent = stopping ? 'stopping\u2026' : 'cycling, back shortly\u2026';
    try {
      await fetch('/api/proxy/power', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: stopping ? 'stop' : 'restart'})
      });
    } catch (e) { /* the socket dies with the process; expected */ }
    if (stopping) {
      pxnote.textContent = 'stopped. Start it from a terminal: ' +
        'faxl_start.sh';
      return;
    }
    let n = 0;
    const tick = setInterval(async function () {
      n += 1;
      try {
        const r = await fetch('/api/backend/status', {cache: 'no-store'});
        if (r.ok) { clearInterval(tick); location.reload(); return; }
      } catch (e) { /* still down */ }
      if (n > 90) {
        clearInterval(tick);
        pxbtn.disabled = false;
        pxbtn.classList.remove('pressed');
        pxnote.textContent = 'still restarting — see ~/.faxl/logs/power.log';
      }
    }, 2000);
  });
  pxbtn.title = 'click to restart the proxy; shift-click to stop it';

  poll();
  setInterval(poll, 5000);
})();
</script>"""


def _page(title, nav_html, h1, inner, alt_json):
    return (f"<!doctype html><title>faxl — {html.escape(title)}</title>"
            f'<link rel="icon" type="image/png" href="{_FAVICON}">'
            f'<link rel="alternate" type="application/json" href="{alt_json}">'
            f"<style>{_BRAND_CSS}{_AGENT_CSS}</style>"
            f'<p class="nav">{nav_html}</p>'
            f"<h1>proxy — {html.escape(h1)}</h1>{inner}{_STATUS_LIGHT}")


def _overview_html(p, backend_name, model, bind):
    rows = []
    seen = set()
    for s in p["savings"]:
        rows.append(_dt(s["key"], s["value"], s["unit"], _basis_mark(s)))
        seen.add(s["key"])
    for t in p["tiles"]:               # tiles too — Agent parity with Human
        if t["key"] in seen:
            continue
        rows.append(_dt(t["key"], t["value"], t["unit"], _basis_mark(t)))
    c = p["counts"]
    for k in ("requests", "hits", "misses", "incomplete"):
        rows.append(_dt(k, c[k]))
    rows.append(_dt("lossless", p["lossless"]["status"]))
    rows.append(_dt("model", p["model"]))
    rows.append(_dt("bind", p["bind"]))
    # The human page also draws the request feed and a chart FROM that feed;
    # an agent gets the same data where it lives. ?model= scopes every one of
    # these the way the human caption describes ("all" pools every model).
    o = _origin()
    api = (f"curl -sS {o}/api/overview          # these numbers, typed, with basis\n"
           f"curl -sS {o}/api/daily?days=7      # per-day totals\n"
           f"curl -sS '{o}/api/requests?limit=200'  # the feed the human chart is drawn from\n"
           f"curl -sS {o}/api/models/summary    # a row per model plus the pooled total\n"
           f"curl -sS {o}/api/cache             # store used / cap, entries\n"
           f"curl -sS {o}/api/blobs             # per-blob reuse\n"
           f"curl -sS {o}/api/diagnostics       # aggregator health, WAL path")
    inner = (f"<dl>{''.join(rows)}</dl>"
             '<p>recent requests: <a href="/console/requests">log</a></p>'
             f"<pre>{html.escape(api)}</pre>"
             f'<p><a href="/console/analytics?format=json">json</a></p>')
    # Was titled "overview" and linked /console?format=json -- both left over
    # from when this page WAS the landing page. /console is the welcome page
    # now, so the json link returned notices, not these numbers.
    return _page("analytics", _nav_html("analytics"), "analytics", inner,
                 "/console/analytics?format=json")


# ---- ARCHITECTURE, THE THING THE CATALOGUE DOES NOT TELL YOU ---------------
# A model's NAME does not say whether its cache is a KV tensor or a rolled-up
# recurrent state, and the difference decides whether a prefix cache can serve
# it at all. Qwen3.5-35B-A3B is 30/40 linear-attention and says nothing;
# granite-4.2-30b sounds like its hybrid 4.0-h sibling and is pure attention.
#
# Only the config settles it, so the family is read from model_type -- the one
# field exo does carry -- against the families known to hold non-KV state.
# Unknown means unknown: a model we cannot place is reported as such rather
# than guessed into the wrong column, because a wrong "pure-KV" is the class
# of error that corrupts output rather than merely slowing it down.
_HYBRID_FAMILIES = {
    # linear attention / KDA
    "qwen3_5", "qwen3_5_moe", "qwen3_next", "kimi_linear", "bailing_hybrid",
    # mamba / SSM
    "granitemoehybrid", "nemotron_h", "jamba", "zamba", "mamba", "mamba2",
    "falcon_h1", "lfm2", "plamo2", "recurrentgemma",
}
# Name fragments, for cards whose model_type exo does not expose. Checked
# against the repo id, lowercased. Deliberately conservative.
_HYBRID_HINTS = (
    "qwen3.5", "qwen3-next", "qwen3.6", "kimi-linear", "ling-3", "granite-4.0-h",
    "nemotron-3-nano", "nemotron-nano", "jamba", "zamba", "falcon-h", "lfm2",
    "recurrentgemma", "mamba",
)


def _is_hybrid(model_id, family=""):
    """True if this model holds recurrent (non-KV) state.

    Returns None when we genuinely cannot tell.
    """
    fam = (family or "").strip().lower()
    if fam in _HYBRID_FAMILIES:
        return True
    low = str(model_id).lower()
    for frag in _HYBRID_HINTS:
        if frag in low:
            return True
    # Families we know are plain attention. Anything else: unknown.
    if fam in {"llama", "mistral", "gemma", "glm", "minimax", "deepseek",
               "gpt_oss", "qwen", "phi", "command-r", "moonshot"}:
        return False
    return None


def _register_html(running, rows, err, shell="agent", backend="exo"):
    """The choose-a-model page. Works with JavaScript off: the form POSTs to
    the same API the script calls, and the page re-renders with the result.

    shell="human" wraps the SAME body in the site shell (turtle, nav, footer).
    This page was the odd one out -- it rendered a bare document with a
    plain-text breadcrumb and no header, so landing on it felt like leaving the
    product. The body is identical either way; only the furniture differs."""
    e = html.escape
    # BACKEND-AWARE. This page was written against exo and asked exo for
    # everything, so on the mlx backend -- the shipped one, where the model is
    # in this process and there is no exo to ask -- it announced that nothing
    # could be served while a model was being served. On mlx the rows are the
    # models on this machine's disk, and what exo alone knows (its catalogue,
    # capabilities, sharding) is shown as unknown, never as "no".
    exo = (backend or "").strip().lower() == "exo"
    hy = [r for r in rows if r[4] is True]
    # A <select>, not a datalist: these are the models the backend can place,
    # which is a closed list. A free-text box implied you could type anything
    # here, and anything you can type that is not on this list has to be added
    # first -- which is what the dialog is for.
    options = "".join(
        f'<option value="{e(r[0])}"'
        + (" selected" if r[0] == running else "")
        + f">{e(r[0])}"
        + (" \u2014 serving now" if r[0] == running else "")
        + (f" ({r[2]} GB)" if r[2] else "")
        + "</option>"
        for r in rows)
    curated = sum(1 for r in rows if not r[1])
    custom = sum(1 for r in rows if r[1])

    listing = []
    # Tick columns rather than a sentence of tags. Nine words of prose per row
    # over 123 rows is not readable; a column you can run your eye down is.
    def _tick(on):
        # A dot for absent, not an empty cell: blank reads as missing data.
        # None is "nobody measured this" and must not read as a dot's "no".
        if on is None:
            return '<td class="no" aria-label="unknown">?</td>'
        return ('<td class="yes" aria-label="yes">&#10003;</td>' if on
                else '<td class="no" aria-label="no">&middot;</td>')

    for mid, is_custom, gb, shardable, hybrid, fam, quant, ctx, caps, have in rows:
        cls = "hy" if hybrid is True else ("unk" if hybrid is None else "kv")
        # Short labels: "hybrid / recurrent" wrapped to two lines in every one
        # of 123 rows, which doubled the table's height and stole the width the
        # tick columns needed.
        arch = ("hybrid" if hybrid is True
                else "?" if hybrid is None else "attention")
        here = "run " if mid == running else ""
        ctx_s = f"{ctx // 1024}k" if ctx else "&mdash;"
        # MLX = we can load it in-process with mlx_lm (an mlx-community build,
        # or one of the architectures mlx_models/ vendors a shim for). EXO =
        # exo's catalogue carries it. They are NOT the same question, which is
        # the point of showing both: a model we can serve on MLX that exo has
        # not carded yet ticks one and not the other.
        is_mlx = mid.startswith("mlx-community/") or (not exo and mid == running)
        # On exo every row came from exo's catalogue. On mlx nobody asked exo,
        # so whether it carries the model is unknown rather than false.
        is_exo = True if exo else None
        instruct = any(k in mid for k in ("Instruct", "instruct", "-it-")) \
            or mid.endswith("-it")
        listing.append(
            f'<tr class="{here}{cls}"><td class="mid">{e(mid)}'
            + (" &#9664; serving now" if mid == running else "")
            + f'</td><td>{arch}</td><td>{e(fam) or "&mdash;"}</td>'
            f'<td>{e(quant) or "&mdash;"}</td><td class="num">{gb or "?"} GB</td>'
            f'<td class="num">{ctx_s}</td>'
            + _tick(is_mlx) + _tick(is_exo) + _tick(instruct)
            + _tick(None if caps is None else "vision" in caps)
            + _tick(None if caps is None else "thinking" in caps)
            + _tick(shardable)
            + (f'<td>{"added here" if is_custom else "built in"}</td>' if exo
               else '<td>local</td>')
            + ('<td class="good">on disk</td></tr>' if have else
               f'<td><button class="secondary dl" data-id="{e(mid)}">'
               f'download</button></td></tr>'))
    # Vertical headers on the tick columns: six one-word labels across a table
    # this wide would set the column widths, and the ticks are 1ch.
    def _sh(label, idx, num=False):
        """A sortable column head. Every column sorts, because which one
        matters depends on what you came here for -- size if you are short of
        disk, context if you are feeding it a long document."""
        cls = ' class="num"' if num else ""
        return (f'<th{cls} data-col="{idx}"'
                + (' data-num="1"' if num else "")
                + f'><button type="button" class="sortbtn">{label}'
                '<span class="arrow" aria-hidden="true"></span></button></th>')

    def _vh(label, note=None, idx=None):
        """A vertical column head, with an optional note behind an (i).

        MLX and Exo are the two that need one: they look like the same
        question and are not, and a reader who does not know that will read a
        half-ticked row as a data error rather than as the real difference it
        is.
        """
        inner = (f'<button type="button" class="sortbtn vsort">'
                 f'<span>{label}</span>'
                 '<span class="arrow" aria-hidden="true"></span></button>')
        if note:
            inner += (f'<button type="button" class="ihint" aria-label="About '
                      f'the {label} column" data-note="{e(note)}">i</button>')
        attr = f' data-col="{idx}" data-num="1"' if idx is not None else ""
        return f'<th class="vert"{attr}>{inner}</th>'

    table = ('<div class="table-card"><div class="table-scroll">'
             '<table class="grid" id="mtable"><thead><tr>'
             + _sh("model", 0) + _sh("architecture", 1) + _sh("family", 2)
             + _sh("quant", 3) + _sh("size", 4, num=True)
             + _sh("context", 5, num=True)
             + _vh("MLX", idx=6, note="faxl loads the weights itself with mlx_lm, in the "
                          "proxy process, on this one machine. No exo, no "
                          "network. This is the shipped single-machine path, "
                          "and it ticks for mlx-community builds plus the "
                          "architectures faxl vendors its own shim for.")
             + _vh("Exo", idx=7, note="exo runs the model and faxl drives it. That is what "
                          "reaches models too large for one machine -- several "
                          "Macs over Thunderbolt, addressed as one engine -- "
                          "and exo's own prefix cache is switched off so faxl "
                          "owns reuse. A tick here means exo's catalogue "
                          "carries this model; it is a different question from "
                          "MLX, so a row can tick one and not the other.")
             + _vh("Instruct", idx=8) + _vh("Vision", idx=9)
             + _vh("Thinking", idx=10) + _vh("Multi-node", idx=11)
             + _sh("card", 12) + _sh("weights", 13)
             + "</tr></thead><tbody>"
             + "".join(listing) + "</tbody></table></div></div>"
             ) if listing else ""

    # "Connection refused" is not a message for a person. It means the
    # service is not running; say that, and point at the switch.
    if err and "refused" in str(err).lower():
        warn = ('<p class="warn"><strong>The exo backend is not running.</strong> '
                'Nothing can be downloaded or served until it is started &mdash; '
                'use the red button, bottom right.</p>')
    elif err:
        warn = f'<p class="warn"><strong>Backend unreachable.</strong> {e(str(err))}</p>'
    else:
        warn = ""

    if exo:
        add_btn = ('\n<button id="addbtn" type="button" class="secondary">'
                   'Add a HuggingFace\nmodel&hellip;</button>')
        how = ('A model the backend has not seen is registered first &mdash;\n'
               'that fetches its <em>card</em>, not its weights. Weights arrive '
               'on the first\nrequest that needs them: tens of GB for a large '
               'one, once, then it loads from\ndisk. Switching works from this '
               'Mac only.')
        heading = f"{len(rows)} models the backend can place"
    else:
        # Say exactly what is and is not available, and why. Switching does
        # NOT need exo here (the restart route checks the local stores);
        # registering a card and the download button are exo's.
        add_btn = ""
        how = ('This proxy runs the <strong>mlx</strong> backend: the model is '
               'loaded in this process, and the list below is what is already '
               'on this machine&rsquo;s disk (<code>~/.exo/models</code> and '
               'the HuggingFace cache). Adding a model card and downloading '
               'from this page use exo, which is not the configured backend '
               '&mdash; to bring in a new model, run <code>hf download '
               'org/name</code> and reload. Switching works from this Mac '
               'only.')
        heading = (f"{len(rows)} model{'' if len(rows) == 1 else 's'} "
                   "on this machine")

    css = """
    table{border-collapse:collapse;margin-top:.6em;font-size:.93em}
    th,td{text-align:left;padding:.22em .7em .22em 0;border-bottom:1px solid #8883}
    tr.hy td:first-child,tr.hy td:nth-child(2){color:#0a7d32;font-weight:600}
    tr.kv td:first-child{color:#556}
    tr.unk td:nth-child(2){color:#888;font-style:italic}
    tr.run{background:#0a7d3214}
    .key{margin:.8em 0;font-size:.93em}
    .key b{font-weight:600}
    .green{color:#0a7d32;font-weight:600}
    .grey{color:#556}
    .err{color:#a00}
    pre{background:#8881;padding:.6em .8em;overflow-x:auto}
    @media (prefers-color-scheme:dark){
      tr.hy td:first-child,tr.hy td:nth-child(2),.green{color:#4ade80}
      tr.kv td:first-child,.grey{color:#aab}
      tr.run{background:#4ade8018}
    }"""

    body = (
        f"""<style>{css}</style>{warn}
<p>This machine serves one model at a time. Switching restarts the proxy
&mdash; about a minute &mdash; and the cache store survives.</p>

<!-- READ-ONLY. It was an input with its own button, which looked like
     something to fill in when it was only reporting what is loaded. A box you
     cannot type in should not look like a box you can. -->
<p class="nowlabel">Now serving</p>
<p class="nowval">{e(running)}</p>

<!-- TWO different acts, so two controls. Picking something the backend
     already has is the common case and stays on the page; bringing in
     something new from HuggingFace is rare, needs an explanation, and can
     fail -- so it gets a dialog of its own rather than a second input on the
     page competing with the first. -->
<p><label for="sw">Switch to</label>
<select id="sw">
  <option value="">&mdash; pick a model &mdash;</option>
  {options}
</select></p>
<p><button id="go">Switch model</button>{add_btn}</p>
<p id="out" class="muted"></p>
<p id="rout" class="muted"></p>

<dialog id="addhf">
  <form method="dialog" id="addform">
    <h2>Add a HuggingFace model</h2>
    <p class="muted">This fetches the model&rsquo;s <em>card</em> so the
    backend can place it. It downloads <strong>no weights</strong> &mdash;
    those arrive on the first request that needs them.</p>
    <p><label for="mid">HuggingFace repo id</label>
    <input id="mid" size="46" placeholder="mlx-community/Qwen3.5-35B-A3B-8bit"></p>
    <p id="addmsg" class="muted"></p>
    <p class="dlg-actions">
      <button value="cancel" class="secondary" type="submit">Cancel</button>
      <button id="addgo" type="button">Add model</button></p>
  </form>
</dialog>
<p class="muted">{how}</p>

<div id="dl" class="card" hidden></div>

<h2>{heading}</h2>
<p class="key"><span class="green">&#9632; {len(hy)} hybrid / recurrent
&mdash; only faxl caches these correctly.</span><br>
Mamba, SSM and linear-attention models keep one rolled-up recurrent tensor
instead of a KV cache. Cached without handling that, they return a different
answer &mdash; plausible, not an error, so nothing tells you it happened.
faxl stores and replays the real state, and the output is byte-identical to
running uncached.<br>
<span class="grey">&#9632; {len(rows) - len(hy)} conventional attention</span>
&mdash; standard KV cache, cached correctly everywhere.</p>
{table}
<script>
// Progressive enhancement only: without this the form still POSTs and the
// browser shows the JSON. With it, the answer lands in place.
// The old handler registered a model and stopped there, leaving the person to
// press a second button to actually run it. Registering is a step towards
// switching, not a thing anybody wants for its own sake, so it is folded into
// the switch below and this form is gone.

// Start a download. exo returns at once and pulls in the background, so the
// button's job is to kick it off and let the poller do the talking.
document.querySelectorAll('button.dl').forEach(function (b) {{
  b.addEventListener('click', async function () {{
    const id = b.dataset.id;
    b.disabled = true; b.textContent = 'starting\u2026';
    try {{
      const r = await fetch('/api/models/download', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{model_id: id}})
      }});
      const d = await r.json();
      b.textContent = d.ok ? 'downloading' : 'failed';
      if (!d.ok) {{
        b.disabled = false;
        // Inline, not an alert: an alert blocks the page and says nothing
        // about which row it belongs to.
        const cell = b.parentElement;
        let note = cell.querySelector('.dlerr');
        if (!note) {{
          note = document.createElement('div');
          note.className = 'dlerr warn';
          note.style.cssText = 'font-size:.78rem;margin-top:.3rem;max-width:18rem';
          cell.appendChild(note);
        }}
        note.textContent = d.error;
      }}
    }} catch (err) {{ b.textContent = 'failed'; b.disabled = false; }}
  }});
}});

// One poller for every download in flight. Downloads are exo's, so on any
// other backend there is nothing to poll: the page does not start the timer,
// and if the API says "not applicable" the timer stops itself.
let dlTimer = null;
async function pollDownloads() {{
  try {{
    const r = await fetch('/api/models/progress', {{cache: 'no-store'}});
    const d = await r.json();
    const box = document.getElementById('dl');
    if (d.applicable === false) {{
      box.hidden = true;
      if (dlTimer) {{ clearInterval(dlTimer); dlTimer = null; }}
      return;
    }}
    if (!d.ok || !d.downloads.length) {{ box.hidden = true; return; }}
    box.hidden = false;
    box.innerHTML = '<h2 style="margin-top:0">downloading</h2>' +
      d.downloads.map(function (x) {{
        const eta = x.eta_ms > 0
          ? ' \u2014 about ' + Math.round(x.eta_ms / 60000) + ' min left' : '';
        const mb = x.speed ? ' at ' + (x.speed / 1e6).toFixed(0) + ' MB/s' : '';
        return '<p style="margin:.3em 0"><strong>' + x.model + '</strong><br>' +
          '<progress max="100" value="' + x.percent + '" style="width:100%"></progress><br>' +
          '<span class="muted">' + x.gb_done + ' of ' + x.gb + ' GB \u2014 ' +
          x.percent + '%' + mb + eta + '</span></p>';
      }}).join('');
  }} catch (err) {{ /* transient */ }}
}}
if ({json.dumps(exo)}) {{
  pollDownloads();
  dlTimer = setInterval(pollDownloads, 3000);
}}

// Column notes. Hover or keyboard focus, and Esc to dismiss -- a note you can
// only reach with a mouse is a note some readers never get.
(function () {{
  const tip = document.createElement('div');
  tip.id = 'coltip';
  tip.setAttribute('role', 'tooltip');
  document.body.appendChild(tip);

  function show(btn) {{
    tip.textContent = btn.dataset.note || '';
    tip.style.display = 'block';
    const r = btn.getBoundingClientRect();
    const w = tip.offsetWidth;
    // Keep it on screen: these columns sit far right on a wide table.
    let left = r.left + r.width / 2 - w / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    tip.style.left = left + 'px';
    tip.style.top = (r.bottom + 8) + 'px';
  }}
  function hide() {{ tip.style.display = 'none'; }}

  document.querySelectorAll('.ihint').forEach(function (b) {{
    b.addEventListener('mouseenter', function () {{ show(b); }});
    b.addEventListener('mouseleave', hide);
    b.addEventListener('focus', function () {{ show(b); }});
    b.addEventListener('blur', hide);
    b.addEventListener('click', function (ev) {{
      ev.preventDefault();
      tip.style.display === 'block' ? hide() : show(b);
    }});
  }});
  document.addEventListener('keydown', function (ev) {{
    if (ev.key === 'Escape') hide();
  }});
  window.addEventListener('scroll', hide, true);
}})();

// The add dialog. Registering is rare and can fail, so it happens here where
// the failure has somewhere to land -- rather than on the page, where an error
// under a second input would be competing with the switch control beside it.
(function () {{
  const dlg = document.getElementById('addhf');
  const open = document.getElementById('addbtn');
  const go = document.getElementById('addgo');
  const box = document.getElementById('mid');
  const msg = document.getElementById('addmsg');
  if (!dlg || !open) return;

  open.addEventListener('click', function () {{
    msg.textContent = ''; box.value = '';
    // showModal() gives the focus trap and Esc-to-close for free; the fallback
    // is for a browser without <dialog>, where the form still works.
    if (dlg.showModal) {{ dlg.showModal(); }} else {{ dlg.setAttribute('open', ''); }}
    box.focus();
  }});

  go.addEventListener('click', async function () {{
    const id = box.value.trim();
    if (!id) {{ msg.textContent = 'Paste a HuggingFace id first.'; return; }}
    if (id.split('/').length !== 2 || id !== id.replace(/[ \\t]/g, '')) {{
      msg.textContent = 'That is not a HuggingFace id \u2014 expected org/name.';
      return;
    }}
    go.disabled = true;
    msg.textContent = 'Checking ' + id + ' on HuggingFace\u2026';
    try {{
      const r = await fetch('/api/models/register', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{model_id: id}})
      }});
      const d = await r.json();
      if (!d.ok) {{
        msg.textContent = d.error || 'That model could not be added.';
        go.disabled = false;
        return;
      }}
      msg.textContent = 'Added ' + d.model.id + ' \u2014 ' + d.model.gb + ' GB' +
        (d.model.shardable ? ', shardable across nodes' : '') +
        '. Reloading so you can switch to it\u2026';
      setTimeout(function () {{ location.reload(); }}, 1100);
    }} catch (err) {{
      msg.textContent = 'Could not reach the proxy: ' + err;
      go.disabled = false;
    }}
  }});
}})();

document.getElementById('go').addEventListener('click', async function () {{
  const rout = document.getElementById('rout');
  const out = document.getElementById('out');
  const btn = document.getElementById('go');
  const id = document.getElementById('sw').value.trim();
  out.textContent = ''; rout.textContent = '';
  if (!id) {{ rout.textContent = 'Pick a model first.'; return; }}
  if (id === {json.dumps(running)}) {{
    rout.textContent = 'That model is already running.';
    return;
  }}
  // Everything in this list is already registered, so switching is one act:
  // restart against it. Bringing in something NEW is the dialog's job.
  btn.disabled = true;
  rout.textContent = 'Switching to ' + id + ' \u2026 this page will be '
    + 'unavailable for about a minute.';
  try {{
    const r = await fetch('/api/restart', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{model_id: id}})
    }});
    const d = await r.json();
    if (!d.ok) {{
      rout.textContent = 'Switch failed: ' + d.error;
      btn.disabled = false; return;
    }}
  }} catch (err) {{
    // The restart kills this server, so a dropped connection here is the
    // expected outcome, not a failure.
  }}
  // Poll until it answers again, then reload.
  let n = 0;
  const tick = setInterval(async function () {{
    n += 1;
    try {{
      const h = await fetch('/api/overview', {{cache: 'no-store'}});
      if (h.ok) {{ clearInterval(tick); location.reload(); return; }}
    }} catch (e) {{ /* still down */ }}
    if (n > 90) {{
      clearInterval(tick);
      rout.textContent = 'still restarting — see ~/.faxl/logs/restart.log';
    }}
  }}, 2000);
}});
</script>""")

    if shell == "human":
        from faxl.engine import faxl_shell as _shell
        # In the shell the page needs its own heading and form furniture: the
        # agent renderer supplied an <h1> and the bare-document CSS styled the
        # inputs, so without these the page opened mid-sentence with default
        # browser widgets inside the brand chrome.
        head = """<style>
          .modelform input[type=text],.modelform input:not([type]){
            width:min(30rem,100%);font:inherit;font-family:var(--mono);
            font-size:.95rem;padding:.55rem .7rem;border:1px solid var(--rule);
            background:var(--card);color:var(--text);box-sizing:border-box}
          .modelform input:focus{outline:2px solid var(--accent);
            outline-offset:1px}
          /* :not(.ihint) matters: this rule was painting the little (i) in the
             table head as a dark pill, because it is a <button> inside
             .modelform and this rule has the same specificity as the one
             styling it. Excluding it here is the fix that actually holds. */
          .modelform button:not(.ihint){font:inherit;font-size:.95rem;
            padding:.55rem 1.1rem;border:1px solid var(--rule);
            background:var(--btn-bg);color:var(--btn-fg);cursor:pointer;
            margin-left:.5rem}
          .modelform button:not(.ihint):hover{background:var(--btn-bg-hover)}
          .modelform label{display:block;color:var(--muted);
            font-size:.92rem;margin-bottom:.3rem}
          /* What is running is a FACT, so it reads as one: a label and a
             value, like every other fact on this console. It was an input
             with a button, which invited a click that did nothing. */
          .modelform .nowlabel{color:var(--muted);font-size:.92rem;
            margin:0 0 .2rem}
          .modelform .nowval{font-family:var(--mono);font-size:1.05rem;
            margin:0 0 1.8rem;overflow-wrap:anywhere}
          .modelform select{width:min(30rem,100%);font:inherit;
            font-family:var(--mono);font-size:.95rem;padding:.55rem .7rem;
            border:1px solid var(--rule);background:var(--card);
            color:var(--text);box-sizing:border-box}
          .modelform select:focus{outline:2px solid var(--accent);
            outline-offset:1px}
          .modelform button.secondary{background:transparent;
            color:var(--text);margin-left:.6rem}
          .modelform button.secondary:hover{background:var(--card)}
          dialog#addhf{border:1px solid var(--rule);background:var(--card);
            color:var(--text);padding:1.6rem 1.8rem;max-width:34rem;
            font-family:var(--serif)}
          dialog#addhf::backdrop{background:rgba(0,0,0,.35)}
          dialog#addhf h2{margin:0 0 .4rem}
          dialog#addhf .dlg-actions{margin:1.2rem 0 0;text-align:right}
          dialog#addhf .dlg-actions button{margin-left:.6rem}
          /* GRIDLINES. 123 rows of numbers with only horizontal rules is hard
             to track across -- the eye loses the row. A hairline in the page
             ground (not a heavier line) is enough to hold it, which is why
             this is colour-mix rather than --rule at full strength. */
          table.grid td, table.grid th{
            border-right:1px solid color-mix(in srgb,var(--rule) 45%,transparent)}
          table.grid td:last-child, table.grid th:last-child{border-right:0}
          table.grid tbody tr:nth-child(even){
            background:color-mix(in srgb,var(--rule) 12%,transparent)}
          table.grid td{padding:.5rem .55rem;vertical-align:middle}
          table.grid td:nth-child(2){font-size:.84rem;line-height:1.3}
          /* The model name wraps rather than forcing the table wider than the
             window. A sticky first column was tried and removed: it pinned a
             nowrap cell, which set a minimum width the window could not hold
             and pushed every other column off screen. */
          table.grid td.mid{font-family:var(--mono);font-size:.82rem;
            overflow-wrap:normal;word-break:normal;line-height:1.35}
          table.grid td.num{text-align:right;font-variant-numeric:tabular-nums;
            white-space:nowrap}
          /* VERTICAL HEADERS on the tick columns. Six one-word labels set
             across the table would each be wider than the tick beneath them
             and would drive the whole layout; turned on their side they cost
             one character of width. */
          /* The table is data, not prose, so it is not bound by the text
             measure the rest of the page reads on. Breaking out of .wrap lets
             the model name have the room it needs instead of stacking five
             characters to a line. */
          .modelform .table-card{width:calc(100vw - 3rem);
            max-width:96rem;
            margin-left:calc(50% - 50vw + 1.5rem);
            margin-right:calc(50% - 50vw + 1.5rem)}
          @media (max-width:70rem){
            /* Keep the full-window width -- collapsing back to the text
               measure here is what put the table back into overflow. Drop
               family and quant instead: both are readable from the model id,
               and losing two columns beats scrolling sideways away from the
               names. */
            table.grid th:nth-child(3),table.grid td:nth-child(3),
            table.grid th:nth-child(4),table.grid td:nth-child(4){display:none}
            table.grid td.mid{min-width:0}}
          @media (max-width:46rem){
            .modelform .table-card{width:auto;margin-left:0;margin-right:0}
            /* Phone: architecture and card go too. The name, the size and what
               it can do is what is left, and that is the useful minimum. */
            table.grid th:nth-child(2),table.grid td:nth-child(2),
            table.grid th:nth-child(13),table.grid td:nth-child(13){display:none}}
          table.grid{table-layout:auto;width:100%}
          table.grid td.mid{min-width:22rem}
          table.grid th.vert{height:5.2rem;padding:.3rem .1rem .45rem;
            vertical-align:bottom;text-align:center;width:1.9rem}
          table.grid th.vert span{writing-mode:vertical-rl;
            transform:rotate(180deg);display:inline-block;white-space:nowrap;
            font-weight:600;letter-spacing:.04em;text-transform:none}
          table.grid td.yes,table.grid td.no{text-align:center;width:1.9rem;
            padding:.5rem .15rem}
          table.grid td.yes{color:var(--good,#0a7d32);font-weight:700}
          table.grid td.no{color:var(--muted);opacity:.45}
          /* The header row was the one part of this table still wearing the
             old page's type: uppercase, letter-spaced and a different weight
             from every other table on the console. */
          table.grid thead th{font-size:.82rem;text-transform:none;
            letter-spacing:0;color:var(--muted);font-weight:600}
          /* The page's .modelform button rule was winning here and painting
             these as dark pills. Scoped to the table and reset explicitly so
             an (i) looks like an (i) in both themes. */
          table.grid th.vert .ihint{display:block;margin:.4rem auto 0;
            width:1.15rem;height:1.15rem;min-width:0;padding:0;
            box-sizing:border-box;line-height:1.05rem;text-align:center;
            border-radius:50%;cursor:help;border:1px solid var(--rule);
            background:var(--card);color:var(--muted);
            font:600 .72rem/1.05rem var(--serif);writing-mode:horizontal-tb;
            transform:none}
          table.grid th.vert .ihint:hover,table.grid th.vert .ihint:focus{
            color:var(--text);border-color:var(--accent);
            background:var(--bg);outline:none}
          /* Sort controls. The header IS the button, so the whole label is the
             target rather than a small arrow beside it. */
          table.grid th .sortbtn{all:unset;cursor:pointer;display:inline-flex;
            align-items:center;gap:.25rem;font:inherit;color:inherit}
          table.grid th .sortbtn:hover{color:var(--text)}
          table.grid th .sortbtn:focus-visible{outline:2px solid var(--accent);
            outline-offset:2px}
          table.grid th .arrow{opacity:0;font-size:.7em;line-height:1}
          table.grid th .sortbtn:hover .arrow{opacity:.45}
          table.grid th .arrow::after{content:"\\2195"}
          table.grid th[aria-sort] .arrow{opacity:1;color:var(--accent)}
          table.grid th[aria-sort="ascending"] .arrow::after{content:"\\2191"}
          table.grid th[aria-sort="descending"] .arrow::after{content:"\\2193"}
          table.grid th.vert .sortbtn.vsort{flex-direction:column-reverse;
            align-items:center}
          /* Fixed-position, not absolute: the table lives in a scroll
             container, and an absolutely-positioned tip would be clipped by
             its overflow. */
          #coltip{position:fixed;z-index:60;max-width:24rem;display:none;
            background:var(--card);border:1px solid var(--rule);
            padding:.7rem .85rem;font-size:.88rem;line-height:1.45;
            color:var(--text);box-shadow:0 2px 10px rgba(0,0,0,.14)}
        </style>"""
        wrapped = _shell.section(kicker="what this machine serves",
                                 heading="Choose your model",
                                 body=f'<div class="modelform">{body}</div>')
        return _human_page("Choose your model", "models", wrapped,
                           "/console/models?format=json", head_extra=head)
    # The buttons above are JavaScript; an agent gets the calls behind them.
    o = _origin()
    calls = (
        f"curl -sS {o}/api/models/catalogue        # every model the backend can place\n"
        f"curl -sS -X POST {o}/api/models/register -H 'Content-Type: application/json' \\\n"
        "  -d '{\"model_id\": \"org/name\"}'       # add a HuggingFace model (card only)\n"
        f"curl -sS -X POST {o}/api/models/download -H 'Content-Type: application/json' \\\n"
        "  -d '{\"model_id\": \"org/name\"}'       # fetch weights\n"
        f"curl -sS {o}/api/models/progress         # download progress\n"
        f"curl -sS -X POST {o}/api/restart -H 'Content-Type: application/json' \\\n"
        "  -d '{\"model_id\": \"org/name\"}'       # switch the served model (this machine only)")
    body += f"<h2>api</h2><pre>{html.escape(calls)}</pre>"
    return _page("models", _nav_html("models"), "models",
                 body, "/console/models?format=json")


# ---- HUMAN renderers ---------------------------------------------------
# Five of the six pages had no human branch at all: in a browser they fell
# through to the agent renderer, so a customer clicking "models" got a
# monospace <dl> in 80 columns. These put them in the same shell as the
# overview, using the site's own vocabulary -- dl.spec for label/value rows,
# .tag for a status, a bare table inside .table-scroll, never a card.


# ONE policy, applied where the response is built, so a page cannot be added
# without it. Measured: when only the overview route set this header, the other
# four human pages -- including the licence page, which carries an inline
# script and a paste box -- went out with no CSP at all. A policy that depends
# on each new route remembering it is not a policy.
# img-src ALSO 'self', and that is not a loosening worth worrying about: the
# only images this origin serves are the photo previews the camera-roll job
# wrote, on a loopback-bound proxy, behind a route that accepts a UUID and
# nothing else. Without it the browser blocks every preview SILENTLY -- no
# server log, no failed request, just broken-image icons on a page whose
# whole point is photographs. Measured: the route answered 200 to curl while
# the page showed nothing, which sent me looking at the JavaScript.
#
# data: stays for the single-picture app, which puts the chosen file straight
# into the request body rather than uploading it anywhere.
HUMAN_CSP = ("default-src 'none'; style-src 'unsafe-inline'; "
             "script-src 'unsafe-inline'; connect-src 'self'; "
             "img-src 'self' data:; font-src data:")


def _human_page(title, current, body, alt_json, head_extra="", frame_src=None):
    """A human page as a RESPONSE, headers included -- never a bare string.

    frame_src  an origin this ONE page is allowed to frame, appended to the
               shared policy. The base stays `default-src 'none'`, so a page
               that does not ask for a frame still cannot open one. The chat
               tab is the only caller: it frames the exo dashboard, whose
               origin is configurable, so the value is computed rather than
               written into the constant.
    """
    from faxl.engine import faxl_shell as _shell
    resp = Response(
        _shell.page(title=title, nav_items=_HUMAN_NAV_ITEMS, current=current,
                    agent_href=_agent_href(),
                    body=body, alt_json=alt_json, head_extra=head_extra),
        mimetype="text/html")
    csp = HUMAN_CSP
    if frame_src:
        # Kept for the signature, but nothing asks for it any more: the chat
        # tab framed exo's dashboard and needed this hole. A console that
        # frames another application is a console that cannot vouch for what
        # is inside the box.
        csp += f"; frame-src {frame_src}"
    resp.headers["Content-Security-Policy"] = csp
    return resp


def _human_register(running, rows, err, backend="exo"):
    """The choose-a-model page in the site shell. Same body, same script --
    the page simply stops being the one screen that looks like another
    product."""
    return _register_html(running, rows, err, shell="human", backend=backend)


# ---- welcome ------------------------------------------------------------
# What each page is FOR, in the words somebody arriving would use. The landing
# page is the only place these appear, so they carry the whole site map.
_WELCOME_CARDS = [
    ("status",    "/console/status",    "What is running right now \u2014 model, backend, uptime."),
    ("analytics", "/console/analytics", "How much work the cache saved you."),
    ("log",       "/console/requests",  "Every request, hit or miss, newest first."),
    ("models",    "/console/models",    "Choose the model this machine serves."),
    ("chat",      "/console/chat",      "Try the model and check it answers."),
    ("verify",    "/console/verify",    "Prove the cache returns byte-identical answers."),
    ("licence",   "/console/licence",   "Install your key and see what it covers."),
    ("configure", "/console/configure",
     "Where the cache lives and how big it may get."),
    ("upgrade",   "https://faxl.ai/shop.html",
     "Buy a licence when the trial runs out. Opens faxl.ai."),
]


def _bold_faxl(escaped):
    """Bold the product name in already-ESCAPED text.

    Runs after html.escape, never before: the input is data, and the only
    markup this introduces is its own. "faxl.ai" is left alone -- bolding half
    a domain looks like a typo.
    """
    import re as _re
    return _re.sub(r"\bfaxl\b(?!\.[a-z])", "<strong>faxl</strong>", escaped)


def _welcome_human(notices):
    from faxl.engine import faxl_shell as _shell
    from faxl.engine.faxl_brand import LOGO_SVG_URI
    esc = html.escape

    # Deliberately the SAME hero as faxl.ai/index.html: mark, wordmark,
    # byline, one plain line. A customer arriving at the console should see the
    # site they bought from, not a different product that happens to share a
    # logo. Classes and values are copied from the site stylesheet's .hero
    # block rather than re-invented, so the two stay in step.
    hero = ('<section class="hero">'
            f'<img class="hero-logo" src="{LOGO_SVG_URI}" alt="" '
            'width="132" height="142">'
            '<h1>faxl</h1>'
            '<p class="hero-byline">navigate the frontier</p>'
            # Two lines, not one sentence: the first says what this is, the
            # second says why the company exists. Run together they read as one
            # long claim and neither lands.
            '<p class="hero-lede">Your prefill cache, on your own machine.<br>'
            '<strong>faxl</strong> makes privately hosted sovereign AI easy '
            'and effective.</p>'
            '</section>')

    # This page is served only when the panel could not be, and the human
    # pages it used to link are redirects to that same panel now. So a card for
    # a retired page opens its agent view, the one that still renders without
    # the panel -- a card that bounced back here would be a dead end.
    def _alive(h):
        return h + "?mode=agent" if h in _PANEL_HREFS else h

    cards = "".join(
        f'<a class="card" href="{_alive(h)}"'
        + (' target="_blank" rel="noopener"' if h.startswith("http") else "")
        + f'><span class="cname">{esc(n)}'
        + (' \u2197' if h.startswith("http") else "")
        + f'</span><span class="cwhat">{_bold_faxl(esc(d))}</span></a>'
        for n, h, d in _WELCOME_CARDS)
    body = f'<section class="section"><div class="cards">{cards}</div></section>'

    # Notices go UNDER the way in, never above it: a person who has just
    # arrived needs the door first. Nothing wrong -> nothing here at all.
    if notices:
        items = "".join(
            f'<li class="n-{esc(n["level"])}"><strong>{esc(n["title"])}</strong> '
            f'{esc(n["text"])}'
            + (f' <a href="{_alive(n["href"])}">{esc(n["action"])}</a>' if n.get("href") else "")
            + "</li>" for n in notices)
        # The kicker follows the content: "needs attention" over a line that
        # only says the licence is fine would be crying wolf, and a page that
        # cries wolf gets ignored when it matters.
        urgent = any(n["level"] == "alert" for n in notices)
        body += _shell.section(
            kicker="needs attention" if urgent else "this machine",
            heading="Notices",
            body=f'<ul class="notices">{items}</ul>')

    head = """<style>
    /* Copied verbatim from faxl-website/site/css/style.css (.hero block).
       The console's _BRAND_CSS predates the site's hero, so these five rules
       are not in it yet; when it is next re-copied they can come out. */
    .hero{background:radial-gradient(ellipse at 50% 24%,
            var(--bg-deep) 0%, var(--bg) 72%);
          text-align:center;
          padding:clamp(2.2rem,1.4rem + 3vw,4rem) var(--gutter,clamp(1.15rem,.6rem + 2.4vw,2.5rem))
                  clamp(1.8rem,1.2rem + 2vw,3rem)}
    .hero-logo{display:block;width:min(30vw,132px);margin:0 auto .9rem}
    .hero h1{margin-bottom:.15em}
    .hero-byline{font-style:italic;color:var(--accent-strong);
                 font-size:clamp(1rem,.94rem + .4vw,1.2rem);
                 margin:0 auto 1.4rem;max-width:none}
    .hero-lede{max-width:38rem;margin:0 auto 1.7rem;
               font-size:clamp(1.08rem,1rem + .5vw,1.28rem)}
    /* Hairline grid: the 1px gap over --rule is what draws the lines between
       cards, so the card background must be opaque or the rules vanish and
       the cards read as floating text (which is what happened). */
    .cards{display:grid;gap:1px;background:var(--card);
           grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));
           border:1px solid var(--rule);margin:0}
    a.card{display:block;padding:1.15rem 1.25rem;background:var(--card);
           text-decoration:none;color:inherit;
           box-shadow:0 0 0 1px var(--rule)}
    /* auto-fit leaves a trailing empty track when the card count is not a
       multiple of the column count, and the grid background then paints it as
       a solid block. Filling the row from the container instead: the cards sit
       on their own background, so a short last row simply ends. */
    a.card:hover{background:var(--bg)}
    .cname{display:block;font-weight:600;margin-bottom:.15rem}
    .cwhat{display:block;color:var(--muted);font-size:.92rem;line-height:1.35}
    ul.notices{list-style:none;padding:0;margin:0}
    ul.notices li{padding:.55rem 0;border-bottom:1px solid var(--rule)}
    ul.notices li:last-child{border-bottom:0}
    .n-alert strong{color:var(--warn,#a33)}
    .n-info strong{font-weight:600}
    </style>"""

    resp = Response(
        _shell.page(title="faxl", nav_items=_HUMAN_NAV_ITEMS, current="welcome",
                    agent_href=_agent_href(),
                    body=body, hero=hero, head_extra=head,
                    alt_json="/console?format=json"),
        mimetype="text/html")
    resp.headers["Content-Security-Policy"] = HUMAN_CSP
    return resp


def _welcome_agent(notices):
    esc = html.escape
    rows = "".join(f'<li><a href="{h}">{esc(n)}</a> \u2014 {esc(d)}</li>'
                   for n, h, d in _WELCOME_CARDS)
    warn = ""
    if notices:
        warn = "<h2>needs attention</h2><ul>" + "".join(
            f'<li><strong>{esc(n["title"])}</strong> {esc(n["text"])}'
            + (f' <a href="{n["href"]}">{esc(n["action"])}</a>' if n.get("href") else "")
            + "</li>" for n in notices) + "</ul>"
    return _page("welcome", _nav_html("welcome"), "welcome",
                 f"<p>navigate the frontier</p><ul>{rows}</ul>{warn}",
                 "/console?format=json")


def _gb(n):
    return f"{(n or 0) / 1e9:.1f} GB"


def _configure_human(p):
    from faxl.engine import faxl_shell as _shell
    esc = html.escape
    st = p["store"]
    env = st["env_override"]

    used = _gb(st["used_bytes"])
    free = _gb(st["free_bytes"]) if st["free_bytes"] is not None else "unknown"
    facts = _shell.spec([
        ("backend", p["backend"]),
        ("cache store", _shell.raw(f'<code>{esc(st["path"])}</code>')),
        ("holding", f"{used} of a {p['cap_gb']:g} GB cap"),
        ("free where it sits", free),
        ("settings file", _shell.raw(f'<code>{esc(p["config_file"])}</code>')),
    ])

    # An environment variable outranks this page, so say so rather than
    # letting somebody save a value that will not be used.
    override = ""
    if env:
        override = ('<p class="warn"><strong>Set in the environment.</strong> '
                    f'<code>{esc(st["env_var"])}={esc(env)}</code> is set for '
                    'the running proxy and takes precedence over anything '
                    'saved here. Unset it to use this page.</p>')

    form = (
        '<p><label for="cfg-store">Cache store</label>'
        f'<input id="cfg-store" value="{esc(st["path"])}" size="46"></p>'
        '<p class="smallprint">A folder on any disk this machine can write '
        '&mdash; an external drive or a mounted share. On a network share, a '
        'write interrupted mid-blob can leave an entry that will not load; '
        'faxl detects those and removes them, so the cost is the space, never '
        'a wrong answer.</p>'
        '<p><label for="cfg-cap">Cap (GB)</label>'
        f'<input id="cfg-cap" type="number" min="1" step="1" '
        f'value="{p["cap_gb"]:g}" size="8"></p>'
        '<p class="smallprint">When the store passes this, the '
        'least-reused blobs are evicted first.</p>'
        '<p><label class="inline"><input type="checkbox" id="cfg-move" checked> '
        'Move the existing cache to the new location, and delete the old copy '
        'once the move is verified</label></p>'
        '<p class="smallprint">Unticked, the setting changes and the old cache '
        'is left where it is &mdash; faxl starts with an empty store.</p>'
        '<p><button class="cta" id="cfg-save" type="button">Save and '
        'restart</button></p>'
        '<p id="cfg-msg" class="muted"></p>'
        '<div id="cfg-prog" class="prog" hidden></div>')

    body = _shell.section(
        kicker="this machine", heading="Configure",
        body=facts + override
        + '<p class="smallprint">These are read when the proxy starts, so '
          'saving restarts it &mdash; about a minute. Nothing else is '
          'interrupted: the cache survives, and so do your conversations.</p>'
        + form)

    js = """
  (function(){
    var save=document.getElementById('cfg-save'),
        msg=document.getElementById('cfg-msg'),
        prog=document.getElementById('cfg-prog');
    if(!save) return;

    function poll(){
      // The proxy is DOWN for most of a move, so this only starts answering
      // once it is back. Until then the fetch simply fails, which is expected.
      fetch('/api/configure/migration',{cache:'no-store'})
        .then(function(r){return r.json();})
        .then(function(d){
          if(!d || d.phase==='none') return;
          prog.hidden=false;
          if(d.phase==='failed'){
            prog.className='prog bad';
            prog.textContent='Move failed: '+(d.detail||'')+
              ' \u2014 nothing was deleted and the setting is unchanged.';
            return;
          }
          if(d.phase==='done'){
            prog.className='prog ok';
            prog.textContent=d.detail||'Done.';
            return;
          }
          prog.className='prog';
          prog.textContent=d.phase+'\u2026 '+(d.detail||'');
          setTimeout(poll, 2000);
        })
        .catch(function(){ setTimeout(poll, 3000); });
    }

    save.addEventListener('click', function(){
      var body={store:document.getElementById('cfg-store').value.trim(),
                cap_gb:document.getElementById('cfg-cap').value,
                migrate:document.getElementById('cfg-move').checked};
      save.disabled=true; msg.className='muted'; msg.textContent='Checking\u2026';
      fetch('/api/configure',{method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(body)})
        .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d};});})
        .then(function(res){
          if(!res.ok || !res.d.ok){
            msg.className='warn';
            msg.textContent=(res.d && res.d.error) || 'Could not save.';
            save.disabled=false;
            return;
          }
          msg.textContent=(res.d.notes||[]).join(' ')+
            ' Restarting \u2014 this page will be unavailable for about a '+
            'minute.';
          if(res.d.migrating){ setTimeout(poll, 4000); }
          // Come back when it answers again.
          var n=0, tick=setInterval(function(){
            n+=1;
            fetch('/api/configure',{cache:'no-store'})
              .then(function(r){ if(r.ok){ clearInterval(tick);
                if(!res.d.migrating){ location.reload(); } } })
              .catch(function(){});
            if(n>150){ clearInterval(tick); }
          }, 2000);
        })
        .catch(function(err){
          msg.className='warn';
          msg.textContent='Could not reach the proxy: '+err;
          save.disabled=false;
        });
    });
    poll();
  })();"""

    head = """<style>
      #cfg-store,#cfg-cap{font:inherit;font-family:var(--mono);font-size:.95rem;
        padding:.55rem .7rem;border:1px solid var(--rule);background:var(--card);
        color:var(--text);box-sizing:border-box}
      #cfg-store{width:min(34rem,100%)}
      label.inline{display:inline;color:inherit}
      label.inline input{margin-right:.4rem}
      .prog{margin:1rem 0;padding:.7rem .9rem;border:1px solid var(--rule);
        background:var(--card);font-size:.92rem}
      .prog.ok{border-color:var(--good,#0a7d32)}
      .prog.bad{border-color:var(--warn,#a33)}
    </style>"""
    return _human_page("Configure", "configure", body + f"<script>{js}</script>",
                       "/console/configure?format=json", head_extra=head)


def _configure_agent(p):
    st = p["store"]
    used = f"{st['used_bytes'] / 1e9:.2f} GB"
    cap = f"{p['cap_gb']:g} GB"
    free = (f"{st['free_bytes'] / 1e9:.1f} GB"
            if st.get("free_bytes") is not None else "unknown")
    o = _origin()
    curl = (
        f"curl -X POST {o}/api/configure \\\n"
        "  -H 'Content-Type: application/json' \\\n"
        '  -d \'{"store": "/Volumes/big/faxl", "cap_gb": 200, '
        '"migrate": true}\'\n'
        f"curl -sS {o}/api/configure/migration   # progress of a move")
    return _page(
        "configure", _nav_html("configure"), "configure",
        "<dl>"
        + _dt("backend", p["backend"])
        + "".join(_dt(f"{k} at next start",
                      f"{c['value']} (from {c['source']}"
                      + (f": {c['env_var']} is set, and the console cannot "
                         f"change it" if c["source"] == "env" else "") + ")")
                  for k, c in (("backend", p["config"]["backend"]),
                               ("model", p["config"]["model"])))
        + _dt("store", st["path"])
        + _dt("used", used)
        + _dt("cap", cap)
        + _dt("free where it sits", free)
        + (_dt("env override", f"{st['env_var']}={st['env_override']}")
           if st.get("env_override") else "")
        + _dt("config", p["config_file"])
        + "</dl>"
        "<p>Change it with:</p>"
        f"<pre>{html.escape(curl)}</pre>"
        "<p>The proxy restarts to pick it up. With migrate, the cache is "
        "copied, verified, and the old copy removed ONLY after the verify "
        "passes \u2014 a failed copy deletes nothing and changes no "
        "setting.</p>"
        "<p>The backend and the model are read-only here: they are switched "
        f"with <code>POST {html.escape(o)}/api/backend/switch</code> "
        "(the top bar's backend control), which writes them to the config "
        "file and restarts onto them.</p>",
        "/console/configure?format=json")


def _status_human(fields):
    from faxl.engine import faxl_shell as _shell
    body = _shell.section(
        kicker="what is running", heading="Status",
        # The model is a path on a local backend; show the name, keep the path
        # on hover. Only the human rendering changes -- json/text stay verbatim.
        body=_shell.spec([(k, _model_cell(v) if k == "model" else v)
                          for k, v in fields])
        + '<p class="smallprint"><a href="/console/models">Choose a different '
          'model</a> &middot; <a href="/console/analytics">See the numbers</a>'
          '</p>')
    return _human_page("Status", "status", body, "/console/status?format=json")


def _models_human(fields):
    from faxl.engine import faxl_shell as _shell
    body = _shell.section(
        kicker="what is running", heading="Model",
        body=_shell.spec(fields)
        + '<p class="smallprint"><a href="/console/register">Register or '
          'download another model</a></p>')
    return _human_page("Models", "models", body, "/console/models?format=json")


# ---------------------------------------------------------------- apps
# THE APP STORE, SUCH AS IT IS TODAY.
#
# Every app here is the same shape: a picture goes in, the shipped vision
# model reads it, and well-formatted text comes out. They differ ONLY in the
# instruction preamble -- which is the point, because a shared preamble is
# exactly what the cache pays for. The photo-tagger run of 2026-09-15 got 103
# hits out of 103 photos and reused 158,208 tokens on precisely this shape.
#
# The preambles are long ON PURPOSE. faxl's ladder does not key anything below
# 1,024 tokens, so a short instruction never checkpoints and the second photo
# pays the same price as the first. tools/photo-tagger/tag_via_faxl.py learned
# this the hard way and its comment says so.
_APP_PREAMBLE = (
    "You are a careful document and image reader running privately on the "
    "owner's own computer. Nothing you are shown leaves this machine. Read "
    "what is actually present and never guess at what is likely: a plausible "
    "invention is worse than an honest gap, because the person reading your "
    "answer cannot tell the two apart. If part of the image is unreadable, "
    "say which part and why -- blur, glare, a fold, a crop, handwriting that "
    "cannot be made out. Numbers matter more than prose: report digits "
    "character by character, because a digit misread is worse than a digit "
    "omitted. Preserve the reading order a person would use, and keep the "
    "structure the page already has rather than imposing one of your own. ")

# HOW MANY TIMES THE PREAMBLE REPEATS, AND WHY IT IS NOT ONE.
#
# faxl does not key anything below 1,024 tokens: a shorter prompt never lays
# down a checkpoint, so every picture pays full price and the cache tile reads
# zero on the apps page -- the demo disproving its own pitch. At ~4 chars a
# token, one copy of the preamble is ~190 tokens, so it is repeated until the
# instruction block clears the gate with room to spare. Repetition (rather
# than padding with filler) keeps every token meaningful to the model, which
# is the same trick tools/photo-tagger/tag_via_faxl.py uses at x20.
_PREAMBLE_REPEATS = 20

APPS = [
    {"slug": "ocr",
     "name": "Image-to-Text OCR",
     "what": "Turn a photograph of a page, receipt or sign into clean text.",
     "icon": "\U0001F4C4",
     "task": "Transcribe every piece of text in this image as well-formatted "
             "plain text. Keep the reading order and the layout: headings as "
             "headings, lists as lists, tables as aligned rows. Do not "
             "summarise, do not explain, and do not add anything that is not "
             "written in the image. If there is no text at all, say so in "
             "one line.",
     "cta": "Read the image"},
    {"slug": "cameraroll",
     "name": "Tag your camera roll",
     "what": "Caption and keyword your photographs, in bulk, on your own Mac.",
     "icon": "\U0001F5BC",
     "task": "Catalogue this photograph under three headings. TEXT: every "
             "word visible in the image, or NONE. SCENE: one sentence "
             "describing what is happening, for someone who cannot see it. "
             "TAGS: five short keywords, lower case, comma separated.",
     "cta": "Catalogue the photo",
     "job": "cameraroll"},
    # Voice2Text (docs/plans/voice2text.md) is not a picture app: it has its
    # own page, faxl_panel_voice, routed at /console/apps/voice2text ahead of
    # the generic app page, so it carries no task and no cta.
    {"slug": "voice2text",
     "name": "Voice to text",
     "what": "Talk; get clean text. Private, on this machine.",
     "icon": "\U0001F3A4",
     "page": "voice2text"},
]

# PARKED 2026-09-22 (AM): whiteboard-to-diagram is off. On the 4B vision
# model it read the words but not the structure, and nothing rendered the
# Mermaid it produced. The definition is kept here, out of APPS, so it can
# come back as-is; the page code that handles it (the mermaid flag in the
# app page script) is untouched. To restore: move this entry back into APPS
# and its card back into faxl_panel_about.PRODUCTS.
APPS_PARKED = [
    {"slug": "whiteboard",
     "name": "Whiteboard to diagram",
     "what": "Photograph a drawing on a whiteboard; get a Mermaid diagram.",
     "icon": "\U0001F4CA",
     "task": "This image is a diagram drawn by hand, usually on a whiteboard "
             "or paper. Convert it into a Mermaid diagram. Choose the "
             "Mermaid type that matches what was drawn: flowchart for boxes "
             "and arrows, sequenceDiagram for messages between actors, "
             "erDiagram for entities and relations, stateDiagram-v2 for "
             "states. Use the labels exactly as written on the board, "
             "correcting only obvious letter-shapes. Output ONLY the Mermaid "
             "source in a ```mermaid fenced block, with no commentary before "
             "or after it.",
     "cta": "Make the diagram"},
]

# The preamble is the same for every app and is sent as a SYSTEM message, so
# it is byte-identical across apps and across runs -- which is precisely what
# lets the cache resume from it. Each app differs only in the task that
# follows the picture.
for _a in APPS:
    _a["preamble"] = _APP_PREAMBLE * _PREAMBLE_REPEATS

APPS_BY_SLUG = {a["slug"]: a for a in APPS}


def _apps_human():
    """The grid. Every tile is one job, not one feature."""
    from faxl.engine import faxl_shell as _shell
    esc = html.escape
    tiles = "".join(
        f'<a class="app" href="/console/apps/{esc(a["slug"])}">'
        f'<span class="app-icon" aria-hidden="true">{a["icon"]}</span>'
        f'<span class="app-name">{esc(a["name"])}</span>'
        f'<span class="app-what">{esc(a["what"])}</span></a>'
        for a in APPS)
    body = _shell.section(
        kicker="apps", heading="What you can do with this",
        body=('<p>Each of these sends a picture to the model running on this '
              'machine and gives you text back. Nothing is uploaded: with the '
              'network off, they all still work.</p>'
              f'<div class="app-grid">{tiles}</div>'))
    return _human_page("Apps", "apps", body, "/console/apps?format=json",
                       head_extra=_APPS_STYLE)


_APPS_STYLE = """<style>
.app-grid{display:grid;gap:14px;margin-top:1.4rem;
  grid-template-columns:repeat(auto-fill,minmax(210px,1fr))}
.app{display:flex;flex-direction:column;gap:.35rem;padding:1rem;
  border:1px solid var(--line);border-radius:3px;text-decoration:none;
  color:inherit;background:var(--paper)}
.app:hover{border-color:var(--ink-2);background:var(--paper-2)}
.app-icon{font-size:1.6rem;line-height:1}
.app-name{font-weight:600}
.app-what{font-size:13px;color:var(--ink-2)}
@media (max-width:420px){.app-grid{grid-template-columns:1fr}}
</style>"""


def _app_human(app):
    """One app: choose a picture, run it, read the answer.

    The whole thing is a POST to /v1/chat/completions on THIS proxy -- the
    same call tools/photo-tagger makes, the same call any client makes. The
    image travels as a data: URL, which the CSP already permits (img-src
    data:, connect-src 'self'), so the page needs no new policy and no upload
    endpoint: the bytes go straight into the request body.
    """
    from faxl.engine import faxl_shell as _shell
    esc = html.escape
    note = (f'<p class="smallprint">{esc(app["note"])}</p>'
            if app.get("note") else "")
    # A JOB APP HAS NO SINGLE-PICTURE FORM.
    #
    # AM: "this top part of the page is not really useful". It was a second
    # heading above the one the job surface already carries, and under it a
    # pick-one-file form -- which is the opposite of what this app is for. The
    # whole argument of the page is that you point faxl at your library and
    # watch an agent work through it; opening with "choose a picture" says the
    # reverse, in a bigger font.
    #
    # OCR and whiteboard-to-diagram keep it, because one picture IS the job
    # there. The shared runner script now checks for its own form and stops
    # when it is absent, so nothing here has to carry hidden markup to keep
    # it happy.
    if app.get("job"):
        return _human_page(
            app["name"], "apps",
            _shell.section(kicker="", heading="", body=_JOB_HTML),
            f"/console/apps/{app['slug']}?format=json",
            head_extra=_APPS_STYLE + _APP_STYLE + _JOB_STYLE +
            _app_script(app) + _JOB_RUNNER)
    body = _shell.section(
        kicker="app", heading=app["name"],
        body=(f'<p>{esc(app["what"])}</p>' + note +
              '<div class="drop" id="drop">'
              '<input type="file" id="pick" accept="image/*" hidden>'
              '<button class="cta" id="choose" type="button">Choose a '
              'picture</button>'
              '<span class="smallprint" id="picked">or drop one here</span>'
              '</div>'
              '<img id="preview" alt="" hidden>'
              '<div class="actions" id="runrow" hidden>'
              f'<button class="cta" id="run" type="button">'
              f'{esc(app["cta"])}</button>'
              '<span class="smallprint" id="runnote"></span></div>'
              '<div id="result" hidden>'
              '<h3>Result</h3>'
              '<pre id="out"></pre>'
              '<div id="mermaid-box" hidden></div>'
              '<p class="verdict" id="verdict"></p>'
              '<div class="actions">'
              '<button class="cta-quiet" id="copy" type="button">Copy the '
              'text</button></div></div>'))
    # AN APP WITH A `job` RUNS OVER THE WHOLE LIBRARY, not over one upload.
    # The single-picture form stays above it -- trying one photograph before
    # committing to five thousand is exactly what a person wants to do first.
    if app.get("job") == "cameraroll":
        # THE JOB SURFACE. Replaces the single-picture form's siblings with a
        # live view of the agent working through a library: photographs moving
        # through real stages, the picture currently in front of the model,
        # what it produced, and what the cache saved.
        #
        # THE STAGES ARE THE ONES THAT EXIST. The mockup showed six; the
        # backend has five real transitions and inventing "Captioned" and
        # "Tagged" as separate steps would be a lie -- the model returns the
        # caption, the scene and the keywords in ONE reply. So: Selected ->
        # Queued -> Analysing -> Catalogued -> Written to Photos, and the last
        # becomes "Done" when write-back is off.
        body += _shell.section(
            kicker="", heading="", body=_JOB_HTML)
    return _human_page(app["name"], "apps", body,
                       f"/console/apps/{app['slug']}?format=json",
                       head_extra=_APPS_STYLE + _APP_STYLE +
                       (_JOB_STYLE if app.get("job") == "cameraroll" else "") +
                       _app_script(app) +
                       (_JOB_RUNNER if app.get("job") == "cameraroll" else ""))


# The job panel. Separate from _APP_RUNNER because it is a different kind of
# thing: that one posts a request and shows a reply, this one starts a process
# that outlives the page and polls a status file. Loaded only on an app that
# has a `job`.
_JOB_RUNNER = r"""<script>
(function(){
function boot(){
  var start=document.getElementById("jobstart"), stop=document.getElementById("jobstop"),
      note=document.getElementById("jobnote"), count=document.getElementById("jobcount"),
      nowRadio=document.getElementById("jbnow"),
      laterRadio=document.getElementById("jblater"),
      rangeBox=document.getElementById("jbrange"),
      fromEl=document.getElementById("jbfrom"), toEl=document.getElementById("jbto"),
      whenHint=document.getElementById("jbwhenhint"),
      write=document.getElementById("jobwrite"),
      pipe=document.getElementById("jbpipe"), now=document.getElementById("jbnow"),
      arc=document.getElementById("jbarc"), cnt=document.getElementById("jbcount"),
      stats=document.getElementById("jbstats"), stateEl=document.getElementById("jbstate"),
      feed=document.getElementById("jbfeed"), strip=document.getElementById("jbstrip"),
      ofEl=document.getElementById("jbof");
  if(!start) return;
  var timer=null, slow=null, seen={}, log=[], pinned=null, lastCurrent=null;
  // The current poll interval. Starts brisk, eases out while idle, never
  // reaches zero -- see render().
  var gap=600;
  // Once the reader types a number it is theirs: a later poll must not
  // overwrite what they just chose.
  var countTouched=false;
  // Declared here because render() disables it while a job runs -- the pick
  // route refuses then anyway, and a button that 409s is worse than one that
  // is visibly unavailable.
  var pick=document.getElementById("jbpick");

  function esc(s){var d=document.createElement("div");d.textContent=s==null?"":s;return d.innerHTML;}
  function hhmm(t){var d=new Date((t||Date.now()/1000)*1000);
    return ("0"+d.getHours()).slice(-2)+":"+("0"+d.getMinutes()).slice(-2);}
  function prev(p){return p?("/api/apps/cameraroll/preview/"+encodeURIComponent(p)):null;}

  // THE MODEL ANSWERS IN ONE REPLY, so these three fields are parsed out of
  // the same text rather than arriving separately. Mirrors
  // apps/write_to_photos.parse_catalogue, which is what actually writes them
  // into the library -- if the two disagreed, the page would show something
  // different from what was saved.
  function parse(txt){
    var o={text:"",scene:"",tags:[]};
    if(!txt) return o;
    var m=txt.match(/TEXT\s*:\s*([\s\S]*?)(?=\n\s*(?:SCENE|TAGS)\s*:|$)/i);
    if(m){var v=m[1].trim(); if(!/^none\.?$/i.test(v)) o.text=v;}
    m=txt.match(/SCENE\s*:\s*([\s\S]*?)(?=\n\s*(?:TEXT|TAGS)\s*:|$)/i);
    if(m) o.scene=m[1].trim();
    m=txt.match(/TAGS\s*:\s*([\s\S]*?)(?=\n\s*(?:TEXT|SCENE)\s*:|$)/i);
    if(m) o.tags=m[1].split(",").map(function(t){return t.trim()})
                     .filter(function(t){return t&&t.length<40}).slice(0,10);
    return o;
  }

  function add(msg, cls, t){
    var k=msg+"|"+(t||"");
    if(seen[k]) return; seen[k]=1;
    log.unshift({m:msg,c:cls||"",t:t||Date.now()/1000});
    log=log.slice(0,40);
  }
  function paintFeed(){
    feed.innerHTML=log.map(function(e){
      return '<li><span class="jb-dot '+e.c+'"></span><time>'+hhmm(e.t)+
             "</time><span>"+esc(e.m)+"</span></li>";}).join("");
  }

  // FIVE STAGES, ALL OF THEM REAL. Selected and Queued come from the count
  // and what is left; Analysing is the tagger's own "current" marker;
  // Catalogued is a written row; Written is a row whose Photos write landed.
  function paintPipe(d, rows, done, target){
    var writing=!!write.checked;
    // THIS RUN'S ROWS ONLY. The feed carries 24 rows so the filmstrip can
    // fill, which means it reaches back into earlier jobs -- and counting all
    // of them showed "Written to Photos: 8" beside "Catalogued: 3". A stage
    // that claims more than the one feeding it reads as a broken pipeline.
    var mine=rows.filter(function(r){
      return !d.started || (r.ts||0)>=d.started;});
    var wrote=mine.filter(function(r){return r.photos_write==="written"}).length;
    var cur=d.current, running=!!d.running;
    var queued=Math.max(target-done-(cur?1:0),0);
    var st=[
      {k:"Selected", n:target, s:target?target+" photos":"none yet",
       img:mine.slice(-3).map(function(r){return prev(r.preview)}), done:!!target},
      {k:"Queued", n:queued, s:queued+" waiting", img:[], done:false},
      {k:"Analysing", n:cur?1:0, on:running&&!!cur,
       s:cur?("photo "+cur.index+" of "+cur.of):(running?"starting…":"idle"),
       img:[cur?prev(cur.preview):null], spin:true},
      {k:"Catalogued", n:done, s:done+(done===1?" photo":" photos"),
       img:mine.slice(-3).map(function(r){return prev(r.preview)}), done:done>0},
      writing?{k:"Written to Photos", n:wrote, s:wrote+(wrote===1?" photo":" photos"),
       img:mine.filter(function(r){return r.photos_write==="written"})
              .slice(-3).map(function(r){return prev(r.preview)}), done:wrote>0}
      :{k:"Done", n:done, s:"write-back off", img:[], done:done>0}
    ];
    pipe.innerHTML=st.map(function(x,i){
      var imgs=(x.img||[]).filter(Boolean).slice(-3);
      var stack=(imgs.length?imgs:[null,null,null]).map(function(u){
        return '<i style="'+(u?("background-image:url("+u+")"):"")+'"></i>';}).join("");
      var badge = x.spin&&x.on ? '<span class="jb-badge"><span class="jb-spin" '+
                   'style="border-color:#0f9d76;border-top-color:transparent">'+
                   '</span></span>'
                 : x.done ? '<span class="jb-badge tick">&#10003;</span>' : "";
      return '<div class="jb-stage'+(x.on?" on":"")+'">'+
        '<div class="jb-stack'+(imgs.length?"":" empty")+'">'+stack+badge+"</div>"+
        "<b>"+esc(x.k)+"</b><span>"+esc(x.s)+"</span></div>"+
        (i<st.length-1?'<div class="jb-arrow">&rarr;</div>':"");
    }).join("");
  }

  function paintNow(d, rows){
    // A PINNED PHOTOGRAPH WINS. Clicking a finished one in the filmstrip must
    // not be stolen back by the next poll, or inspecting a result while the
    // job runs is impossible.
    var show=pinned, badge="", cur=d.current;
    if(!show && cur && d.running)
      show={preview:cur.preview, photo:cur.photo, index:cur.index, of:cur.of,
            pending:true};
    if(!show && rows.length) show=rows[rows.length-1];
    if(!show){ return; }
    var p=parse(show.catalogue||"");
    var img=prev(show.preview);
    if(show.pending) badge='<span class="jb-chip"><span class="jb-spin"></span>'+
      'Analysing…</span>';
    else if(show.photos_write==="written")
      badge='<span class="jb-chip">&#10003; written to Photos</span>';
    else badge='<span class="jb-chip">&#10003; catalogued</span>';
    var meta=[];
    if(show.outcome) meta.push(show.outcome==="HIT"
      ? '<span class="jb-pill">cache hit · '+
        (show.served||0).toLocaleString()+" tokens reused</span>"
      : '<span class="jb-pill alt">cold · first photo pays for the '+
        "instructions</span>");
    if(show.secs) meta.push('<span class="jb-pill alt">'+show.secs+"s</span>");
    now.innerHTML=
      '<div class="jb-shot">'+(img?'<img src="'+img+'" alt="">':"")+badge+"</div>"+
      "<div>"+
        '<div style="display:flex;justify-content:space-between;align-items:baseline">'+
        '<h4 style="margin:0;font-size:.74rem;letter-spacing:.06em;'+
        'text-transform:uppercase;color:var(--jb-ink-2)">Current photo</h4>'+
        '<span style="font-size:.78rem;color:var(--jb-ink-2)">'+
        esc(show.photo||"")+(show.index?(" · "+show.index+" of "+show.of):"")+
        "</span></div>"+
        (show.pending
          ? '<p class="jb-cap" style="color:var(--jb-ink-2)">Reading this '+
            "photograph on your Mac…</p>"
          : '<p class="jb-cap jb-reveal">'+esc(p.scene||"(no description)")+"</p>")+
        (!show.pending&&p.text?'<div class="jb-field jb-reveal"><h4>Text in the '+
          "image</h4><p style=\"margin:0\">"+esc(p.text)+"</p></div>":
          (!show.pending?'<div class="jb-field"><h4>Text in the image</h4>'+
           '<p style="margin:0;color:var(--jb-ink-2)">none found</p></div>':""))+
        (!show.pending&&p.tags.length?'<div class="jb-field"><h4>Keywords</h4>'+
          '<div class="jb-pills">'+p.tags.map(function(t,i){
            return '<span class="jb-pill" style="animation-delay:'+(i*45)+
                   'ms">'+esc(t)+"</span>";}).join("")+"</div></div>":"")+
        (meta.length?'<div class="jb-field"><h4>What faxl did</h4>'+
          '<div class="jb-pills">'+meta.join("")+"</div></div>":"")+
      "</div>";
  }

  function paintProgress(d, rows, done, target){
    var pct=target?Math.min(done/target,1):0;
    arc.setAttribute("stroke-dashoffset", String(201*(1-pct)));
    cnt.textContent=done+" / "+(target||0);
    var c=d.cache||{}, bits=[];
    var el=d.started&&d.running?(Date.now()/1000-d.started):(d.elapsed||0);
    bits.push({b:(el<90?el.toFixed(0)+"s":(el/60).toFixed(1)+" min"),s:"elapsed"});
    if(c.tokens_reused) bits.push({b:c.tokens_reused.toLocaleString(),
      s:"tokens reused"});
    if(c.photos) bits.push({b:c.hits+" / "+c.photos, s:"cache hits"});
    if(c.secs_mean) bits.push({b:"~"+c.secs_mean+"s", s:"a photo"});
    if(c.ttft_ms_best) bits.push({b:(c.ttft_ms_best/1000).toFixed(1)+"s",
      s:"best first reply"});
    stats.innerHTML=bits.map(function(x){
      return '<div class="jb-stat"><b>'+esc(x.b)+"</b><span>"+esc(x.s)+
             "</span></div>";}).join("");
    if(d.running){
      stateEl.hidden=false;
      stateEl.innerHTML='<span class="jb-spin" style="border-color:#0c7a5c;'+
        'border-top-color:transparent"></span> '+
        (d.current?("Analysing photo "+d.current.index+" of "+d.current.of+
         "…"):"Fetching the next photograph…");
    } else if(done){
      stateEl.hidden=false;
      stateEl.innerHTML="&#10003; "+done+" photograph"+(done===1?"":"s")+
        " catalogued"+(c.tokens_reused?(" · "+
        c.tokens_reused.toLocaleString()+" tokens reused"):"");
    } else if(d.state==="finished"){
      // NOTHING LEFT IS NOT A FAILURE. A run whose photographs have all been
      // catalogued already finishes in a second with nothing done, and
      // "finished 0 of 3" reads as a broken job rather than as a resume
      // working exactly as intended.
      stateEl.hidden=false;
      stateEl.innerHTML="&#10003; These photographs are already catalogued. "+
        "Choose more to keep going.";
    } else stateEl.hidden=true;
  }

  function paintStrip(d, rows, done, target){
    var cur=d.current, out=[];
    rows.forEach(function(r){
      var u=prev(r.preview);
      out.push('<div class="jb-frame" data-i="'+rows.indexOf(r)+'">'+
        (u?'<img src="'+u+'" alt="">':"")+'<span class="ok">&#10003;</span></div>');
    });
    if(cur&&d.running){
      var cu=prev(cur.preview);
      out.push('<div class="jb-frame now">'+(cu?'<img src="'+cu+'" alt="">':"")+
        '<span class="ok" style="background:#3b82f6"><span class="jb-spin" '+
        'style="width:8px;height:8px"></span></span></div>');
    }
    var waiting=Math.max(target-done-(cur&&d.running?1:0),0);
    for(var i=0;i<Math.min(waiting,12);i++)
      out.push('<div class="jb-frame wait"></div>');
    if(waiting>12) out.push('<div class="jb-frame wait" style="display:flex;'+
      'align-items:center;justify-content:center;font-size:.72rem">+'+
      (waiting-12)+"</div>");
    strip.innerHTML=out.join("");
    Array.prototype.forEach.call(strip.querySelectorAll("[data-i]"),
      function(el){ el.addEventListener("click",function(){
        pinned=rows[parseInt(el.getAttribute("data-i"),10)];
        paintNow({running:false}, rows); });});
  }

  function render(d){
    var rows=(d.recent||[]).slice().reverse();   // status sends newest first
    var target=parseInt(count.value,10)||d.target||0;
    if(d.target) target=d.target;
    var done=(d.done_this_run!=null?d.done_this_run:(d.tagged||0));
    // Feed entries from real transitions only.
    if(d.current) add("Analysing "+d.current.photo, "blue", d.current.started_at);
    rows.forEach(function(r){
      if(r.error){ add(r.photo+" — "+r.error, "grey", r.ts); return; }
      var p=parse(r.catalogue||"");
      add("Catalogued "+r.photo+(r.secs?(" ("+r.secs+"s)"):""), "", r.ts);
      if(p.tags.length) add("Extracted "+p.tags.length+" keywords","",r.ts);
      if(r.photos_write==="written") add("Written to Photos","",r.ts);
    });
    if(!d.running && d.state==="finished" && done)
      add("Finished — "+done+" photographs", "", d.updated);
    paintFeed();
    paintPipe(d, rows, done, target);
    paintNow(d, rows);
    paintProgress(d, rows, done, target);
    paintStrip(d, rows, done, target);
    // THE LAMP IS THE ANSWER TO "IS IT RUNNING?", visible without reading
    // a number. `waiting` gets its own colour because a scheduled job IS
    // running, and a green light beside a page doing nothing is a lie.
    var lamp=document.getElementById("jblamp");
    if(lamp){
      var cls="", word="idle";
      if(d.state==="waiting"){ cls="wait"; word="waiting for its time"; }
      else if(d.running){ cls="run"; word="working"; }
      else if(d.state==="finished"){ word="finished"; }
      else if(d.state==="stopped"){ word="stopped"; }
      else if(d.state==="failed"){ word="failed"; }
      lamp.className="jb-lamp "+cls;
      lamp.innerHTML="<i></i><b>"+esc(word)+"</b>";
    }
    start.disabled=!!d.running;
    // Disabled, never hidden: a control that appears only when you need it
    // is one you cannot plan around, and this is the "stop now" handle.
    stop.disabled=!d.running;
    if(pick) pick.disabled=!!d.running;
    // FAST WHILE WORKING, SLOW WHEN IDLE (AM). 600ms keeps the pipeline and
    // the clock moving; an idle page has no reason to ask twice a second.
    // THE PAGE NEVER STOPS ASKING. (AM, 2026-09-22: "expect all pages to
    // always poll for ever always... if you want to back off on the poll
    // schedule then do that slowly".)
    //
    // Working: 600ms, so the pipeline and the clock move. Idle: ease out --
    // 1.5x each tick up to 15s -- rather than dropping to a fixed 5s and
    // rather than stopping. A job started from another tab, or a restart
    // finishing, is then picked up within seconds without this page being
    // touched. Any sign of life snaps it straight back to 600ms.
    var want = d.running ? 600 : Math.min(Math.round(gap * 1.5), 15000);
    if(d.running) want = 600;
    if(want !== gap){
      gap = want;
      if(timer) clearInterval(timer);
      timer = setInterval(poll, gap);
    }
  }

  function poll(){
    fetch("/api/apps/cameraroll/status",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(render).catch(function(){});
  }

  start.addEventListener("click",function(){
    note.textContent="starting…"; start.disabled=true; pinned=null;
    fetch("/api/apps/cameraroll/start",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({count:parseInt(count.value,10)||20,
                           // EMPTY MEANS NOW. cameraroll.parse_window treats
                           // "" as no window at all, so Start now sends
                           // nothing rather than a range covering the day --
                           // which would be a different thing that merely
                           // behaves the same most of the time.
                           window:when(),
                           write_photos:!!write.checked})})
      .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d}})})
      .then(function(x){
        // The API's refusal is the message -- permission, a bad window, a job
        // already running. "Failed" would hide the one thing worth reading.
        if(!x.ok){ note.textContent=x.d.error||"could not start";
                   start.disabled=false; return; }
        note.textContent="running — you can close this page, it keeps going";
        add("Started — "+x.d.count+" photographs","",Date.now()/1000);
        poll();
      }).catch(function(e){ note.textContent=String(e); start.disabled=false; });
  });

  stop.addEventListener("click",function(){
    stop.disabled=true;
    note.textContent="stopping — the photograph in flight finishes first, "+
      "then it stops (about 15 seconds)…";
    fetch("/api/apps/cameraroll/stop",{method:"POST"})
      .then(function(r){return r.json()})
      .then(function(d){ note.textContent=d.note||d.error||""; poll(); })
      .catch(function(e){ note.textContent=String(e); });
  });

  // THE SOURCE, AND WHAT faxl MAY ACTUALLY READ. Never asks for permission:
  // a dialog nobody pressed a button for is the behaviour customers hate, so
  // this reads the CURRENT grant and the Choose button is what requests one.
  function library(){
    fetch("/api/apps/cameraroll/library",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()}).then(function(d){
        var src=document.getElementById("jbsrc"),
            nm=document.getElementById("jbsrcname");
        if(!d.ok){ src.textContent="choose photographs to begin"; return; }
        if(d.selected){
          // THE SELECTION IS THE JOB. AM: "if they are selected, the feeling
          // is they must be done -- the user already told you the list of
          // things to do." Asking again was not merely odd, it silently did
          // LESS than asked: a 50-photograph selection against the default
          // of 20 tagged twenty and stopped, with nothing saying so.
          //
          // So the count follows the selection, and the box becomes a way to
          // do FEWER (a quick try before committing to the lot) rather than
          // a question that has to be answered.
          nm.textContent="Your selection";
          src.textContent=d.selected.toLocaleString()+" photographs chosen";
          var lab=document.getElementById("jbcountlabel");
          if(lab) lab.textContent="2. Tag how many?";
          if(!countTouched){
            count.value=d.selected;
            ofEl.textContent="all "+d.selected.toLocaleString()+" of them";
          } else {
            ofEl.textContent="of "+d.selected.toLocaleString()+" chosen";
          }
          count.max=Math.max(d.selected,1);
        } else if(d.status==="limited"){
          nm.textContent="Your selection";
          src.textContent=(d.photos||0).toLocaleString()+" photographs shared";
          ofEl.textContent="of "+(d.photos||0).toLocaleString();
        } else if(d.status==="authorized"){
          nm.textContent="Photos library";
          src.textContent=(d.photos||0).toLocaleString()+" photographs";
          ofEl.textContent="of "+(d.photos||0).toLocaleString()+" photographs";
        } else {
          nm.textContent="Photos library";
          src.textContent="no access yet \u2014 press Choose";
        }
      }).catch(function(){});
  }

  if(pick) pick.addEventListener("click",function(){
    pick.disabled=true;
    note.textContent="opening the Photos picker \u2014 choose the "+
      "photographs faxl may read\u2026";
    fetch("/api/apps/cameraroll/pick",{method:"POST"})
      .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d}})})
      .then(function(x){
        pick.disabled=false;
        if(!x.ok){ note.textContent=x.d.error||"nothing was chosen"; return; }
        note.textContent=x.d.picked.toLocaleString()+
          " photographs chosen \u2014 only these can be read.";
        // A NEW SELECTION IS A NEW JOB. Whatever number was in the box
        // belonged to the last one, so the count goes back to following the
        // selection rather than silently capping it.
        countTouched=false;
        add("Chose "+x.d.picked+" photographs","",Date.now()/1000);
        paintFeed(); library();
      }).catch(function(e){ pick.disabled=false; note.textContent=String(e); });
  });

  // NOW, OR A WINDOW. The backend has taken "HH:MM-HH:MM" or nothing since
  // the job was written (cameraroll.parse_window); this only stops asking a
  // person to type that format by hand. A native <input type=time> gives a
  // real picker, respects the reader's 12/24-hour setting, and cannot
  // produce a string the parser will reject.
  function when(){
    if(!laterRadio || !laterRadio.checked) return "";
    var a=(fromEl.value||"").trim(), b=(toEl.value||"").trim();
    if(!a || !b) return "";
    return a+"-"+b;
  }
  function paintWhen(){
    var later=laterRadio && laterRadio.checked;
    rangeBox.className = later ? "" : "off";
    if(!later){
      whenHint.textContent="Tagging begins as soon as you press the button.";
      return;
    }
    var a=fromEl.value, b=toEl.value;
    // A WINDOW THAT WRAPS MIDNIGHT IS THE NORMAL CASE -- the point is to run
    // while you are asleep -- so say so rather than letting it look wrong.
    whenHint.textContent = (a && b && a > b)
      ? "Runs overnight, from "+a+" until "+b+" the next morning. The job "+
        "waits until then."
      : "Runs between these times each day. The job waits until then.";
  }
  if(laterRadio){
    [nowRadio, laterRadio, fromEl, toEl].forEach(function(el){
      if(el) el.addEventListener("change", paintWhen);});
    paintWhen();
  }

  count.addEventListener("input",function(){
    countTouched=true;
    var n=parseInt(count.value,10)||0, max=parseInt(count.max,10)||0;
    ofEl.textContent = (max && n>=max)
      ? "all "+max.toLocaleString()+" of them"
      : (max ? "of "+max.toLocaleString()+" chosen"
             : n+" photographs this run");});

  library();
  poll();          // a job may already be running from a previous visit
  timer=setInterval(poll,gap);
}
if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",boot);
else boot();
})();
</script>"""


# The camera-roll job surface. Kept apart from _APP_STYLE because it is a
# different thing: that styles a one-picture form, this is a live view of an
# agent working through a library.
#
# LIGHT, CALM, MAC-LIKE. White cards on a soft mint ground, navy text, small
# radii, shadows you have to look for. The restraint is the point: this page
# is mostly photographs, and chrome that competes with them makes it worse.
# The job surface's markup. Rendered once and filled by _JOB_RUNNER from the
# status route: every number, photograph and line of text on it comes from
# work the backend actually did.
_JOB_HTML = """<div class="jb">
  <div class="jb-head">
    <div>
      <h2>Tag your camera roll</h2>
      <p>Captions and keywords for your photos &mdash; generated locally on
         your Mac.</p>
    </div>
    <div class="jb-trust">
      <div><i>&#128274;</i><b>100% local</b><span>Your photos stay on this Mac</span></div>
      <div><i>&#128683;</i><b>Private</b><span>No cloud. No uploads.</span></div>
      <div><i>&#10024;</i><b>Beautifully organised</b><span>Find your memories faster</span></div>
    </div>
  </div>

  <div class="jb-cfg">
    <div class="f">
      <label>1. Choose photos</label>
      <div class="jb-src">
        <span style="font-size:1.4rem">&#127748;</span>
        <div style="flex:1"><b id="jbsrcname">Photos library</b>
          <span id="jbsrc">checking&hellip;</span></div>
        <button class="jb-btn ghost" id="jbpick" type="button"
                style="padding:.45rem .8rem;font-size:.82rem">Choose&hellip;</button>
      </div>
    </div>
    <div class="f" id="jbhowmany">
      <label for="jobcount" id="jbcountlabel">2. How many?</label>
      <input id="jobcount" type="number" min="1" max="100000" value="20"
             style="width:7rem">
      <span class="hint" id="jbof">photographs this run</span>
    </div>
    <div class="f">
      <label>3. Options</label>
      <label for="jobwrite" style="font-weight:400;font-size:.82rem">
        <input id="jobwrite" type="checkbox" checked>
        Write captions into Photos</label>
      <span class="hint">Each photo gets a caption and keywords written back
        to your library.</span>
      <div class="jb-when">
        <label><input type="radio" name="jbwhen" id="jbnow" checked>
          Start now</label>
        <label><input type="radio" name="jbwhen" id="jblater">
          Only between</label>
        <span id="jbrange" class="off">
          <input id="jbfrom" type="time" value="23:00" step="300">
          <span aria-hidden="true">&ndash;</span>
          <input id="jbto" type="time" value="07:00" step="300">
        </span>
      </div>
      <span class="hint" id="jbwhenhint">Tagging begins as soon as you
        press the button.</span>
    </div>
    <div class="jb-go">
      <span class="jb-lamp" id="jblamp"><i></i><b>idle</b></span>
      <button class="jb-btn" id="jobstart" type="button">Start tagging
        &nbsp;&rarr;</button>
      <button class="jb-btn danger" id="jobstop" type="button" disabled>Stop</button>
    </div>
  </div>
  <p class="hint" id="jobnote" style="margin:-.9rem 0 1.1rem;
     color:var(--jb-ink-2);font-size:.8rem"></p>

  <div class="jb-pipe" id="jbpipe"></div>

  <div class="jb-grid">
    <div class="jb-card">
      <div class="jb-now" id="jbnow">
        <div class="jb-empty" style="grid-column:1/-1">
          Choose how many photographs to tag, then press
          <b>Start tagging</b>. You will see each one as it is read.
        </div>
      </div>
    </div>
    <div class="jb-card">
      <div class="jb-ring">
        <svg width="76" height="76" viewBox="0 0 76 76" aria-hidden="true">
          <circle cx="38" cy="38" r="32" fill="none" stroke="#eaf1f5"
                  stroke-width="8"/>
          <circle id="jbarc" cx="38" cy="38" r="32" fill="none"
                  stroke="#0f9d76" stroke-width="8" stroke-linecap="round"
                  stroke-dasharray="201" stroke-dashoffset="201"
                  transform="rotate(-90 38 38)"
                  style="transition:stroke-dashoffset .6s ease"/>
        </svg>
        <div>
          <div class="n" id="jbcount">0 / 0</div>
          <div class="l">photographs completed</div>
        </div>
      </div>
      <div class="jb-stats" id="jbstats"></div>
      <div class="jb-note" id="jbstate" hidden></div>
      <div class="jb-feed"><h4 style="font-size:.74rem;letter-spacing:.06em;
        text-transform:uppercase;color:var(--jb-ink-2);margin:.9rem 0 .3rem">
        Live activity</h4><ul id="jbfeed"></ul></div>
    </div>
  </div>

  <div class="jb-strip" id="jbstrip"></div>
  <div class="jb-legend">
    <span><span class="jb-dot"></span> completed</span>
    <span><span class="jb-dot blue"></span> processing</span>
    <span><span class="jb-dot grey"></span> waiting</span>
  </div>
</div>"""


_JOB_STYLE = """<style>
:root{
  --jb-ink:#16263a; --jb-ink-2:#5b6b7d; --jb-line:#e3eaf0;
  --jb-mint:#0f9d76; --jb-mint-soft:#e8f6f1; --jb-card:#fff;
  --jb-shadow:0 1px 2px rgba(20,40,60,.05), 0 8px 24px rgba(20,40,60,.06);
}
.jb{color:var(--jb-ink);}
.jb-head{display:flex;gap:1.5rem;align-items:flex-start;flex-wrap:wrap;
  margin:.2rem 0 1.4rem}
.jb-head h2{margin:0 0 .3rem;font-size:1.9rem;letter-spacing:-.02em}
.jb-head p{margin:0;color:var(--jb-ink-2)}
.jb-trust{display:flex;gap:1.4rem;margin-left:auto;flex-wrap:wrap}
.jb-trust div{max-width:13rem}
.jb-trust b{display:block;font-size:.82rem}
.jb-trust span{font-size:.76rem;color:var(--jb-ink-2);line-height:1.3;
  display:block}
.jb-trust i{font-style:normal;margin-right:.35rem}

/* ---- configuration ---- */
.jb-cfg{background:var(--jb-card);border:1px solid var(--jb-line);
  border-radius:14px;box-shadow:var(--jb-shadow);padding:1.1rem 1.3rem;
  display:flex;gap:2rem;align-items:flex-end;flex-wrap:wrap;
  margin-bottom:1.4rem}
.jb-cfg .f{display:flex;flex-direction:column;gap:.4rem}
.jb-cfg label{font-size:.78rem;font-weight:600;letter-spacing:.01em}
.jb-cfg .hint{font-size:.74rem;color:var(--jb-ink-2)}
.jb-when{display:flex;align-items:center;gap:.8rem;flex-wrap:wrap;
  margin-top:.35rem;font-size:.8rem}
.jb-when label{font-weight:400;display:flex;align-items:center;gap:.3rem}
.jb-when input[type=time]{font:inherit;font-size:.8rem;padding:.3rem .4rem;
  border:1px solid var(--jb-line);border-radius:8px;background:#fbfdfe;
  color:var(--jb-ink)}
/* Dimmed rather than removed: the times stay readable, so choosing the
   second option shows what it is about to do instead of making a control
   appear out of nowhere. */
.jb-when .off{opacity:.42;pointer-events:none}
.jb-cfg input[type=number],.jb-cfg input[type=text],
.jb-cfg input[type=time]{
  font:inherit;padding:.5rem .6rem;border:1px solid var(--jb-line);
  border-radius:9px;background:#fbfdfe;color:var(--jb-ink)}
.jb-src{display:flex;align-items:center;gap:.7rem;padding:.55rem .8rem;
  border:1px solid var(--jb-line);border-radius:10px;background:#fbfdfe;
  min-width:15rem}
.jb-src b{display:block;font-size:.9rem}
.jb-src span{font-size:.76rem;color:var(--jb-ink-2)}
.jb-go{margin-left:auto;display:flex;gap:.6rem;align-items:center}
.jb-btn{font:inherit;font-weight:650;border:0;border-radius:11px;
  padding:.8rem 1.4rem;background:#16263a;color:#fff;cursor:pointer;
  box-shadow:var(--jb-shadow);transition:transform .12s ease,opacity .12s}
.jb-btn:hover:not(:disabled){transform:translateY(-1px)}
.jb-btn:disabled{opacity:.45;cursor:default}
.jb-btn.ghost{background:#fff;color:var(--jb-ink);
  border:1px solid var(--jb-line);box-shadow:none}
/* STOP IS ALWAYS THERE, dimmed when there is nothing to stop. A button that
   appears only once a job is running is a button nobody can find in advance,
   and this one is the emergency handle. */
.jb-btn.danger{background:#fff;color:#a4342b;border:1px solid #f0d5d2;
  box-shadow:none}
.jb-btn.danger:hover:not(:disabled){background:#fdf3f2}
.jb-lamp{display:flex;align-items:center;gap:.45rem;font-size:.8rem;
  color:var(--jb-ink-2);margin-right:.3rem}
.jb-lamp i{width:9px;height:9px;border-radius:50%;background:#c3ced8;
  display:block}
.jb-lamp.run i{background:var(--jb-mint);
  animation:jblamp 1.4s ease-in-out infinite}
.jb-lamp.wait i{background:#d9a441;animation:jblamp 1.4s ease-in-out infinite}
.jb-lamp.run b,.jb-lamp.wait b{color:var(--jb-ink)}
@keyframes jblamp{0%,100%{box-shadow:0 0 0 0 rgba(15,157,118,.45)}
  70%{box-shadow:0 0 0 7px rgba(15,157,118,0)}}

/* ---- pipeline ---- */
.jb-pipe{display:flex;align-items:flex-start;gap:.2rem;margin:0 0 1.3rem;
  overflow-x:auto;padding:.4rem .1rem 0}
.jb-stage{flex:0 0 auto;text-align:center;width:9.4rem;padding:.7rem .3rem;
  border-radius:14px;transition:background .3s ease}
.jb-stage.on{background:var(--jb-mint-soft)}
.jb-stack{position:relative;height:74px;margin:0 auto .55rem;width:92px}
.jb-stack i{position:absolute;inset:0;border-radius:9px;background:#eef3f7
  center/cover no-repeat;border:2px solid #fff;
  box-shadow:0 1px 4px rgba(20,40,60,.14)}
.jb-stack i:nth-child(1){transform:translate(-9px,4px) rotate(-4deg);opacity:.5}
.jb-stack i:nth-child(2){transform:translate(-4px,2px) rotate(-2deg);opacity:.75}
.jb-stack i:nth-child(3){transform:none}
.jb-stack.empty i{background:#f2f6f9;box-shadow:none;opacity:.5}
.jb-badge{position:absolute;right:-6px;bottom:-6px;width:26px;height:26px;
  border-radius:50%;background:#fff;box-shadow:0 1px 5px rgba(20,40,60,.22);
  display:flex;align-items:center;justify-content:center;font-size:.8rem}
.jb-badge.tick{color:var(--jb-mint)}
.jb-stage.on .jb-stack i:nth-child(3){animation:jbpulse 2s ease-in-out infinite}
@keyframes jbpulse{0%,100%{box-shadow:0 1px 4px rgba(20,40,60,.14)}
  50%{box-shadow:0 0 0 6px rgba(15,157,118,.13)}}
.jb-stage b{display:block;font-size:.85rem}
.jb-stage span{font-size:.76rem;color:var(--jb-ink-2)}
.jb-arrow{flex:0 0 auto;align-self:center;margin-top:-2.2rem;color:#bcd3cb;
  font-size:1.1rem}

/* ---- current photo + progress ---- */
.jb-grid{display:grid;grid-template-columns:minmax(0,1fr) 21rem;gap:1.2rem;
  align-items:start}
@media (max-width:900px){.jb-grid{grid-template-columns:1fr}}
.jb-card{background:var(--jb-card);border:1px solid var(--jb-line);
  border-radius:14px;box-shadow:var(--jb-shadow);padding:1.1rem}
.jb-now{display:grid;grid-template-columns:minmax(0,17rem) minmax(0,1fr);
  gap:1.1rem}
@media (max-width:700px){.jb-now{grid-template-columns:1fr}}
.jb-shot{position:relative;border-radius:12px;overflow:hidden;background:#eef3f7;
  aspect-ratio:3/4}
.jb-shot img{width:100%;height:100%;object-fit:cover;display:block}
.jb-chip{position:absolute;left:.6rem;top:.6rem;background:rgba(18,32,48,.82);
  color:#fff;font-size:.76rem;padding:.35rem .7rem;border-radius:999px;
  display:flex;align-items:center;gap:.45rem;backdrop-filter:blur(6px)}
.jb-spin{width:11px;height:11px;border-radius:50%;border:2px solid #fff;
  border-top-color:transparent;animation:jbspin .8s linear infinite}
@keyframes jbspin{to{transform:rotate(360deg)}}
.jb-field{margin:.9rem 0 0}
.jb-field h4{margin:0 0 .25rem;font-size:.74rem;letter-spacing:.06em;
  text-transform:uppercase;color:var(--jb-ink-2)}
.jb-cap{font-size:1rem;line-height:1.45;margin:0;padding:.75rem .85rem;
  background:#fbfdfe;border:1px solid var(--jb-line);border-radius:10px}
.jb-pills{display:flex;flex-wrap:wrap;gap:.4rem}
.jb-pill{font-size:.78rem;padding:.3rem .65rem;border-radius:999px;
  background:var(--jb-mint-soft);color:#0c7a5c;
  animation:jbin .34s ease both}
.jb-pill.alt{background:#eef4fb;color:#37557a}
@keyframes jbin{from{opacity:0;transform:translateY(5px)}to{opacity:1}}
.jb-reveal{animation:jbin .4s ease both}

/* ---- progress panel ---- */
.jb-ring{display:flex;align-items:center;gap:1rem;margin-bottom:.9rem}
.jb-ring svg{flex:0 0 auto}
.jb-ring .n{font-size:1.7rem;font-weight:650;line-height:1}
.jb-ring .l{font-size:.78rem;color:var(--jb-ink-2)}
.jb-stats{display:flex;gap:.9rem;flex-wrap:wrap;border-top:1px solid
  var(--jb-line);padding-top:.75rem}
.jb-stat b{display:block;font-size:.95rem}
.jb-stat span{font-size:.72rem;color:var(--jb-ink-2)}
.jb-note{margin:.8rem 0 0;padding:.6rem .75rem;border-radius:10px;
  background:var(--jb-mint-soft);color:#0c7a5c;font-size:.82rem;
  display:flex;align-items:center;gap:.5rem}

/* ---- activity ---- */
.jb-feed{margin-top:.9rem;max-height:13rem;overflow-y:auto}
.jb-feed ul{list-style:none;margin:0;padding:0}
.jb-feed li{display:flex;gap:.6rem;align-items:baseline;padding:.22rem 0;
  font-size:.79rem;animation:jbin .3s ease both}
.jb-dot{flex:0 0 auto;width:7px;height:7px;border-radius:50%;
  background:var(--jb-mint);margin-top:.35rem}
.jb-dot.blue{background:#3b82f6}.jb-dot.grey{background:#c3ced8}
.jb-feed time{flex:0 0 auto;color:var(--jb-ink-2);font-variant-numeric:tabular-nums}

/* ---- filmstrip ---- */
.jb-strip{display:flex;gap:.55rem;overflow-x:auto;padding:.9rem .2rem .3rem;
  margin-top:1.1rem}
.jb-frame{position:relative;flex:0 0 auto;width:74px;height:74px;
  border-radius:10px;overflow:hidden;background:#eef3f7;cursor:pointer;
  border:2px solid transparent;transition:border-color .2s,transform .2s}
.jb-frame img{width:100%;height:100%;object-fit:cover;display:block}
.jb-frame.now{border-color:#3b82f6;transform:translateY(-2px)}
.jb-frame.wait{opacity:.45}
.jb-frame .ok{position:absolute;right:3px;bottom:3px;width:18px;height:18px;
  border-radius:50%;background:var(--jb-mint);color:#fff;font-size:.62rem;
  display:flex;align-items:center;justify-content:center}
.jb-legend{display:flex;gap:1.1rem;justify-content:center;font-size:.75rem;
  color:var(--jb-ink-2);margin-top:.2rem}
.jb-empty{padding:2.2rem 1rem;text-align:center;color:var(--jb-ink-2)}
</style>"""


_APP_STYLE = """<style>
.drop{display:flex;align-items:center;gap:.9rem;padding:1.1rem;margin:1.2rem 0;
  border:1px dashed var(--ink-2);border-radius:3px;background:#fff}
.drop.over{border-color:var(--hit,#0a7d32);background:#f3fbf5}
#preview{max-width:100%;max-height:320px;margin:.6rem 0;border:1px solid var(--line)}
#out{white-space:pre-wrap;overflow-wrap:anywhere;padding:.8rem;
  border:1px solid var(--line);background:var(--paper-2);max-height:460px;
  overflow-y:auto;font-size:13px}
.verdict{font-size:12px;color:var(--ink-2);font-family:var(--font-mono)}
.verdict .hit{color:var(--hit,#0a7d32);font-weight:600}
</style>"""


def _app_script(app):
    """The app runner. The prompt is baked in server-side: it is the product,
    not a field the page can edit, and it is what makes two runs share a
    prefix the cache can serve."""
    return ("<script>\nwindow.FAXL_APP=" + json.dumps({
        "slug": app["slug"], "preamble": app["preamble"],
        "task": app["task"],
        "mermaid": app["slug"] == "whiteboard"}) + ";\n</script>" +
        _APP_RUNNER)


_APP_RUNNER = r"""<script>
(function(){
function boot(){
  // A SCRIPT ERROR MUST NOT LOOK LIKE A SLOW MODEL. Without this, anything
  // thrown before the fetch resolves leaves the page showing "sending the
  // picture..." for ever, and the only evidence is a console the reader will
  // never open.
  window.addEventListener("error", function(ev){
    var v=document.getElementById("verdict");
    if(v) v.innerHTML='<span>the page hit an error: '+
      String(ev.message).replace(/[<>&]/g,"")+'</span>';
  });
  var app=window.FAXL_APP, pick=document.getElementById("pick"),
      choose=document.getElementById("choose"), drop=document.getElementById("drop"),
      picked=document.getElementById("picked"), prev=document.getElementById("preview"),
      runrow=document.getElementById("runrow"), run=document.getElementById("run"),
      runnote=document.getElementById("runnote"), result=document.getElementById("result"),
      out=document.getElementById("out"), verdict=document.getElementById("verdict"),
      copy=document.getElementById("copy"), mbox=document.getElementById("mermaid-box");
    // NOT EVERY APP HAS THIS FORM. A job app (the camera roll) renders the
  // pipeline alone -- "choose a picture" is the opposite of what it does --
  // so this script has nothing to attach to and stops here. Without the
  // guard the first addEventListener throws on null and takes the rest of
  // the page's scripts down with it, including the job panel's own error
  // reporting.
  if(!pick || !choose || !run) return;
var dataUrl=null;

  function esc(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML;}

  function take(file){
    if(!file || !/^image\//.test(file.type)){
      picked.textContent="that is not an image"; return; }
    var fr=new FileReader();
    fr.onload=function(){
      dataUrl=fr.result;
      prev.src=dataUrl; prev.hidden=false;
      picked.textContent=file.name+" ("+Math.round(file.size/1024)+" KB)";
      runrow.hidden=false; result.hidden=true;
    };
    // readAsDataURL, not an upload: the bytes go into the request body, so
    // there is no upload endpoint to secure and nothing is written to disk.
    fr.readAsDataURL(file);
  }

  choose.addEventListener("click",function(){pick.click()});
  pick.addEventListener("change",function(){take(pick.files[0])});
  ["dragenter","dragover"].forEach(function(e){
    drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.add("over")})});
  ["dragleave","drop"].forEach(function(e){
    drop.addEventListener(e,function(ev){ev.preventDefault();drop.classList.remove("over")})});
  drop.addEventListener("drop",function(ev){
    take(ev.dataTransfer && ev.dataTransfer.files[0])});

  function showVerdict(txn,tries){
    fetch("/api/requests?limit=8",{headers:{Accept:"application/json"}})
      .then(function(r){return r.json()})
      .then(function(d){
        var rows=(d&&d.requests)||[];
        var row=txn?rows.find(function(r){return r.transaction_id===txn}):rows[0];
        if((!row||row.status==="pending")&&tries>0)
          return setTimeout(function(){showVerdict(txn,tries-1)},700);
        if(!row) return;
        var hit=(row.outcome||"").toUpperCase()==="HIT", bits=[];
        bits.push('<span class="'+(hit?"hit":"")+'">'+(hit?"cache hit":"cache miss")+"</span>");
        if(row.prefill_skipped>0) bits.push(row.prefill_skipped.toLocaleString()+" tokens reused");
        if(row.prefill_paid!=null) bits.push(row.prefill_paid.toLocaleString()+" computed");
        if(row.ttft_ms!=null) bits.push(Math.round(row.ttft_ms)+" ms to first token");
        verdict.innerHTML=bits.join(" \u00b7 ");
      }).catch(function(){});
  }

  // A PERSON IS WATCHING A BLANK BOX FOR TWENTY SECONDS. Show the work.
  //
  // AM: "there is NOTHING to watch. I don't know if it's running, what it is
  // doing. Humans HATE that, we want to WATCH IT WORKING."
  //
  // Measured on the screenshot that prompted this: the page said "reading the
  // image..." at 16:14:31 and the request did not reach the proxy until
  // 16:15:30 -- FIFTY-NINE SECONDS of dead time before the network was even
  // touched, spent base64-encoding a 3.4 MB photograph and building a 14,000
  // character prompt on the main thread. Then another ~15s of model time with
  // the same frozen line. A reader cannot tell that from a hang.
  //
  // So each stage says what it is, and the elapsed clock never stops moving.
  // The proxy's SSE path is NOT incremental (it keepalives through the whole
  // serve and sends the text in one frame -- see faxl_proxy _gen), so there
  // are no tokens to stream; what we can honestly show is which stage we are
  // in and how long it has taken.
  var tick=null;
  function stage(msg, since){
    if(tick){clearInterval(tick); tick=null;}
    if(!since){ runnote.textContent=msg; return; }
    var t0=Date.now();
    function paint(){
      runnote.textContent=msg+" \u00b7 "+((Date.now()-t0)/1000).toFixed(1)+"s";
    }
    paint(); tick=setInterval(paint,100);
  }

  run.addEventListener("click",function(){
    if(!dataUrl) return;
    run.disabled=true;
    result.hidden=false; out.textContent=""; verdict.textContent="";
    if(mbox){mbox.hidden=true; mbox.innerHTML="";}
    // The picture is already a data: URL (FileReader did that when it was
    // chosen), so the size is known here and worth saying: a 3.4 MB photo is
    // ~4.6 MB of base64 and the browser has to hand all of it to the proxy.
    var mb=(dataUrl.length/1048576).toFixed(1);
    stage("sending the picture ("+mb+" MB)", true);
    out.textContent="Reading the photograph on this Mac. Nothing is "+
      "uploaded.\n\nThe first picture pays for the instructions; every one "+
      "after it resumes from the cache.";
    fetch("/v1/chat/completions",{
      method:"POST", headers:{"Content-Type":"application/json"},
      // THE SHAPE IS tools/photo-tagger/tag_via_faxl.py's, VERBATIM.
      //
      //   system:  the preamble, identical on every request
      //   user:    [ the question, the picture ]
      //
      // That script has catalogued several hundred photographs from the real
      // library. It is the working template and this page must not invent a
      // different arrangement: the preamble is what checkpoints, the grid
      // boundary lands well inside it (1536 of 1763 tokens), and every photo
      // resumes from there.
      body:JSON.stringify({messages:[
        {role:"system",content:app.preamble},
        {role:"user",content:[
          {type:"text",text:app.task},
          {type:"image_url",image_url:{url:dataUrl}}]}],
        max_tokens:1024, temperature:0})})
    .then(function(r){
      // The bytes are across; from here the model is thinking. Naming the
      // change is the difference between "it is working" and "it is stuck".
      stage("the model is reading the picture", true);
      if(!r.ok) return r.text().then(function(t){
        throw new Error("HTTP "+r.status+" "+t.slice(0,300));});
      return r.json();})
    .then(function(d){
      var msg=(d.choices&&d.choices[0]&&d.choices[0].message)||{};
      var text=msg.content||"(the model returned nothing)";
      out.textContent=text;
      // A mermaid app returns a fenced block; artifacts and many viewers
      // render <pre class="mermaid"> natively, so surface it as well as the
      // source rather than instead of it.
      if(app.mermaid && mbox){
        var m=text.match(/```mermaid\s*([\s\S]*?)```/);
        if(m){ mbox.innerHTML='<pre class="mermaid">'+esc(m[1].trim())+"</pre>";
               mbox.hidden=false; }
      }
      showVerdict(d.id,6);
    })
    .catch(function(e){
      out.textContent=String(e.message||e);
      verdict.innerHTML='<span>the request failed \u2014 this is the error, '+
        'not a result</span>';
    })
    .then(function(){
      run.disabled=false;
      if(tick){clearInterval(tick); tick=null;}
      runnote.textContent="";});
  });

  copy.addEventListener("click",function(){
    var t=out.textContent||"";
    if(navigator.clipboard) navigator.clipboard.writeText(t).then(function(){
      copy.textContent="Copied"; setTimeout(function(){
        copy.textContent="Copy the text"},1400);});
  });
}
if(document.readyState==="loading")
  document.addEventListener("DOMContentLoaded",boot);
else boot();
})();
</script>"""


def _chat_human(up, err, models, origin, local, endpoint):
    """A REAL chat, through the proxy.

    What was here before was an <iframe> pointing at exo's own dashboard on
    :52415, and it carried a caveat admitting the problem: "it does not pass
    through the proxy, so the cache is not exercised and nothing here reaches
    the request feed."

    That is backwards. EVERYTHING GOES THROUGH THE PROXY, ALWAYS. The proxy is
    the product -- the licence gate, the ladder, the byte-confirm, the store
    and the telemetry all sit on its path -- so a chat that routes around it
    tests nothing a customer cares about. It answered "is the model working?"
    when the only question worth asking is "is faxl working?".

    It also framed another application's UI inside ours and punched a
    frame-src hole in the CSP to do it, and it could only ever work on the exo
    backend, which is not the one the wheel ships.

    This posts to /v1/chat/completions -- the same endpoint any client uses --
    and then reads the request feed for the row it just created, so every
    message shows what faxl actually did with it: hit or miss, tokens skipped,
    where it resumed, time to first token. That is the demo and the test at
    once.
    """
    from faxl.engine import faxl_shell as _shell

    body = _shell.section(
        kicker="try it", heading="Chat",
        body=(
            '<p>Messages go through the proxy, exactly as a client would send '
            'them. Each reply shows what faxl did with it.</p>'
            '<div id="chatlog" role="log" aria-live="polite"></div>'
            '<form id="chatform" autocomplete="off">'
            '<textarea id="chatin" rows="3" spellcheck="false" '
            'placeholder="Ask the model something, then ask a follow-up — '
            'the second turn is where the cache earns its keep." '
            'aria-label="Message"></textarea>'
            '<div class="actions">'
            '<button class="cta" id="chatsend" type="submit">Send</button>'
            '<button class="cta-quiet" id="chatnew" type="button">New '
            'conversation</button>'
            '<span class="smallprint" id="chatnote"></span>'
            '</div></form>'))
    return _human_page("Chat", "chat", body, "/console/chat?format=json",
                       head_extra=_CHAT_STYLE + _CHAT_SCRIPT)


# Kept apart from the markup so the page reads as structure, and so the script
# is one thing to find when the request-feed shape changes.
_CHAT_STYLE = """<style>
#chatlog{margin:1.2rem 0;display:flex;flex-direction:column;gap:.9rem}
.msg{padding:.7rem .9rem;border:1px solid var(--line);border-radius:2px;
  white-space:pre-wrap;overflow-wrap:anywhere}
.msg.you{background:var(--paper-2)}
.msg.them{background:transparent}
.msg .who{display:block;font-size:11px;text-transform:uppercase;
  letter-spacing:.06em;color:var(--ink-2);margin-bottom:.35rem}
.verdict{font-size:12px;color:var(--ink-2);margin:.45rem 0 0;
  font-family:var(--font-mono)}
.verdict .hit{color:var(--hit,#0a7d32);font-weight:600}
.verdict .miss{color:var(--ink-2)}
.msg.pending{color:var(--ink-2)}
.msg.failed{border-color:var(--warn,#b3261e)}
.msg .err{color:var(--warn,#b3261e)}
/* The composer must read as somewhere you TYPE. On var(--paper) it was the
   same ground as the page and disappeared into it -- a box you had to know
   was there. Lifted to white, with a stronger border and a focus ring. */
#chatin{width:100%;font:inherit;padding:.65rem .75rem;
  border:1px solid var(--ink-2);border-radius:2px;
  background:#fff;color:#111;resize:vertical}
#chatin::placeholder{color:#6b7280}
#chatin:focus{outline:2px solid var(--hit,#0a7d32);outline-offset:1px;
  border-color:var(--hit,#0a7d32)}
:root[data-theme="dark"] #chatin{background:#f7f7f5;color:#111}
@media (prefers-color-scheme:dark){
  :root:not([data-theme="light"]) #chatin{background:#f7f7f5;color:#111}
}
#chatform .actions{margin-top:.6rem;display:flex;align-items:center;gap:.8rem}
</style>"""

_CHAT_SCRIPT = """<script>
// DEFERRED, because this is injected into <head> via head_extra and therefore
// runs BEFORE the body exists. Without the wrapper every getElementById
// returned null, no listener was ever attached, and Send and New conversation
// were dead buttons on a page that otherwise looked completely correct --
// the failure mode of a script that runs too early is silence, not an error.
(function(){
function boot(){
  var log=document.getElementById("chatlog"),
      form=document.getElementById("chatform"),
      input=document.getElementById("chatin"),
      send=document.getElementById("chatsend"),
      note=document.getElementById("chatnote"),
      fresh=document.getElementById("chatnew");
  // The whole conversation is resent every turn. That is not a workaround --
  // it is what every OpenAI-compatible client does, and it is precisely the
  // shape faxl exists to make cheap: turn two repeats turn one's prompt, so
  // the prefix is already in the store and only the new tokens are paid for.
  var history=[];

  function esc(s){var d=document.createElement("div");d.textContent=s;
    return d.innerHTML;}

  function bubble(who,text,cls){
    var el=document.createElement("div");
    el.className="msg "+cls;
    el.innerHTML='<span class="who">'+esc(who)+'</span>'+esc(text);
    log.appendChild(el); el.scrollIntoView({block:"end"}); return el;
  }

  function num(n){return n==null?null:n.toLocaleString();}

  // What faxl DID with the message, read from the request feed rather than
  // guessed: the proxy records one row per request, and it is the same row
  // the log page shows. Absent fields stay absent -- an unmeasured number is
  // never rendered as a measured one.
  // `how` says how the row was tied to this message: "id" is certain, "only"
  // and "tokens" are inferences and are labelled as such. No row at all is
  // SAID, not skipped: the page promises a verdict under every reply, and an
  // empty space there is indistinguishable from a broken page.
  function verdict(el,row,how,why){
    var p=document.createElement("p"); p.className="verdict";
    if(!row){
      p.innerHTML='<span class="miss">'+esc(why||"no verdict available")+
        '</span> · <a href="/console/requests">open the request log</a>';
      el.appendChild(p); return;
    }
    var bits=[];
    var oc=(row.outcome||"").toUpperCase();
    var hit=oc==="HIT";
    // No outcome means no completion event was folded for this row. That is
    // NOT a miss -- a miss is a measurement -- so it is not painted as one.
    if(!oc) bits.push('<span class="miss">logged ('+esc(row.status||"?")+
                      "), outcome not recorded</span>");
    else bits.push('<span class="'+(hit?"hit":"miss")+'">'+
              (hit?"cache hit":"cache miss")+"</span>");
    if(row.prefill_skipped!=null && row.prefill_skipped>0)
      bits.push(num(row.prefill_skipped)+" tokens reused");
    if(row.prefill_paid!=null)
      bits.push(num(row.prefill_paid)+" computed");
    if(row.resume_pos!=null && row.resume_pos>0)
      bits.push("resumed at "+num(row.resume_pos));
    if(row.ttft_ms!=null) bits.push(Math.round(row.ttft_ms)+" ms to first token");
    if(row.status==="rejected")
      bits=['<span class="miss">rejected: '+esc(row.reject_reason||"")+"</span>"];
    if(how==="tokens") bits.push("matched to this message by prompt size");
    // the ordinary case; said on hover rather than under every reply
    if(how==="only") p.title="matched as the only new request in the feed";
    if(how==="odd") bits.push("the only new request, but its prompt size "+
      "differs from the reply's — treat as unconfirmed");
    p.innerHTML=bits.join(" · ");
    el.appendChild(p);
  }

  // WHY THE VERDICT NEVER APPEARED. This used to look for a feed row whose
  // transaction_id equalled the completion's `id`. They are different
  // namespaces: the proxy answers with a fresh "chatcmpl-<12 hex>" and logs
  // the request under its own 16-hex transaction id, and nothing in the
  // response carries the latter. The find() could not succeed, the retries
  // ran out, and verdict(undefined) returned without a word.
  //
  // So the row is identified by DIFFERENCE instead: snapshot the feed's ids
  // before sending; afterwards the rows that were not there are the
  // candidates. One candidate is ours. Several (another client was busy) are
  // narrowed by the prompt-token count the completion itself reported. If
  // that still does not single one out we say so rather than guess -- a
  // verdict pinned to somebody else's request is worse than none. An exact id
  // match is still tried first, so a proxy that starts returning its
  // transaction id is picked up without touching this again.
  function feed(limit){
    return fetch("/api/requests?limit="+limit,
                 {headers:{Accept:"application/json"}})
      .then(function(r){if(!r.ok) throw new Error("HTTP "+r.status);
        return r.json()})
      .then(function(d){return (d&&d.requests)||[];});
  }
  function snapshot(){
    return feed(50).then(function(rows){
      var seen={}; rows.forEach(function(r){seen[r.transaction_id]=1});
      return seen;
    }).catch(function(){return null;});
  }
  function pick(rows,seen,d){
    var ids=[d&&d.id,d&&d.faxl&&d.faxl.transaction_id];
    var exact=rows.filter(function(r){return ids.indexOf(r.transaction_id)>=0});
    if(exact.length) return {row:exact[0],how:"id"};
    if(!seen) return {row:null,why:"logged, but could not be matched to this "+
      "message (the request feed could not be read before sending)"};
    var fresh=rows.filter(function(r){return !seen[r.transaction_id]});
    if(!fresh.length) return {row:null,retry:true,why:"no new row appeared in "+
      "the request feed for this message"};
    var pt=d&&d.usage&&d.usage.prompt_tokens;
    if(fresh.length===1){
      // Both counts known and different: still the likeliest row, but the
      // doubt is shown rather than swallowed.
      var r1=fresh[0], odd=pt!=null&&r1.prompt_tokens!=null&&
        r1.prompt_tokens!==pt;
      return {row:r1,how:odd?"odd":"only"};
    }
    var same=pt==null?[]:fresh.filter(function(r){return r.prompt_tokens===pt});
    if(same.length===1) return {row:same[0],how:"tokens"};
    // Still waiting on completions? Then prompt_tokens is not there to compare.
    var waiting=fresh.some(function(r){return r.status==="pending"});
    return {row:null,retry:waiting,why:"logged, but could not be matched: "+
      fresh.length+" requests arrived at the same time"};
  }

  // The row is written when the request completes, which can land just after
  // the response reaches us, so give it a moment before giving up. Silence is
  // better than a wrong number.
  function fetchVerdict(el,seen,d,tries){
    feed(50)
      .then(function(rows){
        var m=pick(rows,seen,d);
        var again=m.row?m.row.status==="pending":m.retry;
        if(again&&tries>0)
          return setTimeout(function(){fetchVerdict(el,seen,d,tries-1)},600);
        verdict(el,m.row,m.how,m.why);
      })
      .catch(function(e){
        verdict(el,null,null,"could not read the request feed ("+
          String(e.message||e)+")");
      });
  }

  function ask(text){
    history.push({role:"user",content:text});
    bubble("you",text,"you");
    var el=bubble("faxl","…","them");
    el.classList.add("pending");
    var seen=null, t0=Date.now();
    // Not streamed, so the only honest progress signal is elapsed time.
    var tick=setInterval(function(){
      note.textContent="waiting for the reply… "+
        Math.round((Date.now()-t0)/1000)+" s";},1000);
    send.disabled=true; fresh.disabled=true; note.textContent="sending…";
    snapshot().then(function(s){
      seen=s;
      return fetch("/v1/chat/completions",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({messages:history,max_tokens:512})
      });
    })
    .then(function(r){
      if(!r.ok) return r.text().then(function(t){
        // Prefer the message the proxy wrote (a licence rejection explains
        // itself there) over a slab of JSON.
        var m=t;
        try{var j=JSON.parse(t);
          m=(j.error&&(j.error.message||j.error))||j.message||t;
          if(typeof m!=="string") m=JSON.stringify(m);}catch(_){}
        throw new Error("HTTP "+r.status+" — "+String(m).slice(0,300));});
      return r.json();
    })
    .then(function(d){
      var msg=(d.choices&&d.choices[0]&&d.choices[0].message)||{};
      var out=msg.content||"(empty reply)";
      history.push({role:"assistant",content:out});
      el.innerHTML='<span class="who">faxl</span>'+esc(out);
      fetchVerdict(el,seen,d,5);
    })
    .catch(function(e){
      // The error is the useful thing here: this page exists to tell you
      // whether the stack is working, so a failure must be legible.
      // The failed turn is also taken back out of the history: left in, the
      // next message would resend a question that never got an answer.
      if(history.length&&history[history.length-1].role==="user")
        history.pop();
      el.className="msg them failed";
      el.innerHTML='<span class="who">faxl</span>'+
        '<span class="err">The request failed: '+esc(String(e.message||e))+
        "</span>";
      // A rejection is logged too, and its row carries the reason.
      if(seen) fetchVerdict(el,seen,null,2);
    })
    .then(function(){clearInterval(tick); el.classList.remove("pending");
      send.disabled=false; fresh.disabled=false; note.textContent="";
      input.focus();});
  }

  form.addEventListener("submit",function(ev){
    ev.preventDefault();
    var t=input.value.trim(); if(!t) return;
    input.value=""; ask(t);
  });
  input.addEventListener("keydown",function(ev){
    if((ev.metaKey||ev.ctrlKey)&&ev.key==="Enter") form.requestSubmit();
  });
  fresh.addEventListener("click",function(){
    history=[]; log.innerHTML="";
    note.textContent="new conversation — the next message is a cold prompt";
  });
}
if(document.readyState==="loading")
  document.addEventListener("DOMContentLoaded",boot);
else boot();
})();
</script>"""


def _chat_html(up, err, models, endpoint):
    """Agent mode: the endpoint an agent should POST to -- which is the proxy,
    the same one a browser uses. This used to hand out the BACKEND address and
    say the cache would not be exercised; that was the console advertising a
    way to bypass the product."""
    esc = html.escape
    # endpoint is None when the backend is in this process (mlx): there is no
    # second address to name, and naming exo's would be naming a service this
    # proxy does not use.
    where = f" at <code>{esc(endpoint)}</code>" if endpoint else ""
    state = (f"<p>Backend up, {models} model{'' if models == 1 else 's'} "
             f"available.</p>") if up else (
        f"<p>The backend is not answering{where}.</p>"
        f"<pre>{esc(str(err))}</pre>")
    return (f"<!doctype html><title>Chat — faxl</title><p>{_nav_html('chat')}</p>"
            f"<h1>Chat</h1>{state}"
            "<p>POST to <code>/v1/chat/completions</code> on this proxy, "
            "OpenAI-compatible. Any api key is accepted; requests are cached, "
            "gated by the licence, and recorded in the request feed.</p>"
            '<p><a href="/console/chat?format=json">json</a> · '
            '<a href="/console">overview</a></p>')

def _verify_human(status, condition, model="", bind="127.0.0.1:8767"):
    """Losslessness you can press, not a status line you cannot change.

    The old page reported "never verified" and offered nothing to verify with,
    on a build where in-proxy replay does not exist -- a claim about the
    product with no way to check it, which is worse than no page.

    The tests run in the BROWSER, against the proxy's own /v1 endpoint. That
    is deliberate: the console and /v1 share a port, so a server-side test
    would have the proxy calling itself. connect-src 'self' already allows it.

    Both tests send a long STATIC prefix plus a short changing tail. The prefix
    has to clear the first checkpoint (position 250, geometric schedule in
    ckpt_schedule.py) or there is nothing for a later run to resume from, and
    every run would honestly report a miss.
    """
    from faxl.engine import faxl_shell as _shell
    esc = html.escape

    intro = ("<p>A cache that returns a different answer than a cold run is "
             "worth nothing, however fast it is. These tests check that "
             "claim on the model you are actually running, right now.</p>"
             '<p class="smallprint">Each test sends real requests through '
             f"this proxy at <code>{esc(bind)}</code>"
             + (f" to <code>{esc(model)}</code>" if model else "")
             + ". Answers are compared byte for byte, and the resume position "
               "comes from the proxy's own request log &mdash; not from the "
               "browser's opinion of what happened.</p>")

    tests = (
        '<div class="vtests">'
        '<div class="vtest"><h3>Same prompt, three times</h3>'
        '<p>Run 1 fills the cache. Runs 2 and 3 should resume from it and '
        'return <strong>byte-identical</strong> answers.</p>'
        '<button class="cta" id="t-repeat" type="button">Test byte-for-byte '
        'caching</button></div>'
        '<div class="vtest"><h3>Shared prefix, different questions</h3>'
        '<p>Three questions over one long shared preamble, then the first '
        'question again. The repeat must match run 1 exactly, and runs 2&ndash;4 '
        'should resume from the shared prefix.</p>'
        '<button class="cta" id="t-prefix" type="button">Test shared-prefix '
        'caching</button></div>'
        "</div>"
        '<div id="vout" class="vout" hidden></div>'
        + _shell.spec([("determinism condition", condition)]))

    js = """
  // Everything here runs in the page, against this proxy's /v1. temperature 0
  // and a small max_tokens: a sampled answer would differ between runs for
  // reasons that have nothing to do with the cache, and the test would be
  // measuring the sampler.
  (function(){
    var MODEL = %MODEL%;
    // Long enough to clear the first checkpoint (250 tokens) with room to
    // spare, so runs after the first have something to resume from.
    var STATIC = (
      "You are reading a fixed technical preamble that does not change between " +
      "requests. It exists so that the prefill cache has a long, stable prefix " +
      "to store and reuse. ").repeat(14);
    var out = document.getElementById('vout');

    function esc(s){ var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
    function line(h){ out.hidden=false; out.innerHTML += h; }

    function ask(q){
      return fetch('/v1/chat/completions', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          model: MODEL, temperature: 0, max_tokens: 24, stream: false,
          messages:[{role:'user', content: STATIC + "\\n\\nQuestion: " + q}]
        })
      }).then(function(r){
        if(!r.ok) return r.text().then(function(t){ throw new Error(r.status+' '+t.slice(0,160)); });
        return r.json();
      }).then(function(d){
        return ((d.choices||[{}])[0].message||{}).content || '';
      });
    }

    // The proxy's own log is the source of truth for hit/resume -- the browser
    // cannot see inside the cache, and a test that reported its own opinion of
    // a hit would be worthless.
    function recent(n){
      return fetch('/api/requests?limit='+n, {cache:'no-store'})
        .then(function(r){ return r.json(); })
        .then(function(d){ return (d.requests||[]).slice(0, n); });
    }

    function report(title, answers, rows){
      var allSame = answers.every(function(a){ return a === answers[0]; });
      var h = '<h3>'+esc(title)+'</h3>';
      h += '<p class="'+(allSame?'pass':'fail')+'"><strong>'+
           (allSame ? '\u2713 byte-identical' : '\u2717 answers differ')+
           '</strong> across '+answers.length+' runs '+
           '('+answers[0].length+' characters each).</p>';
      if(rows && rows.length){
        h += '<table><tr><th>run</th><th>outcome</th><th>prompt tokens</th>'+
             '<th>resumed at</th><th>skipped</th></tr>';
        rows.forEach(function(r,i){
          h += '<tr><td>'+(i+1)+'</td><td>'+esc(String(r.outcome||'-'))+'</td>'+
               '<td>'+(r.prompt_tokens||0)+'</td>'+
               '<td>'+(r.resume_pos||0)+'</td>'+
               '<td>'+(r.prefill_skipped||0)+'</td></tr>';
        });
        h += '</table>';
        var reused = rows.filter(function(r){ return (r.prefill_skipped||0) > 0; }).length;
        if(reused){
          var sk = rows.find(function(r){ return (r.prefill_skipped||0)>0; });
          h += '<p class="smallprint">'+reused+' of '+rows.length+
               ' runs resumed from the cache at token '+sk.resume_pos+
               ', skipping '+sk.prefill_skipped+' tokens of prefill.</p>';
        } else {
          h += '<p class="smallprint">No run resumed from the cache. If this '+
               'is the first time this prompt has been seen, that is expected '+
               'for run 1 only.</p>';
        }
      }
      line('<div class="vres">'+h+'</div>');
    }

    function run(btn, title, questions){
      var b = document.getElementById(btn);
      b.disabled = true; var label = b.textContent; b.textContent = 'running\u2026';
      out.hidden = false; out.innerHTML = '<p class="smallprint">Sending '+
        questions.length+' requests through the proxy\u2026 the first is a cold '+
        'run and may take a moment.</p>';
      var answers = [];
      var chain = Promise.resolve();
      questions.forEach(function(q){
        chain = chain.then(function(){
          return ask(q).then(function(a){ answers.push(a); });
        });
      });
      chain.then(function(){
        return recent(questions.length);
      }).then(function(rows){
        out.innerHTML = '';
        report(title, answers, rows.slice().reverse());
      }).catch(function(e){
        // out.hidden is set at the start of a run, but a failure before the
        // first paint left it hidden with the message inside it -- the button
        // re-enabled and the page said nothing, which is the one outcome a
        // test page must never produce.
        out.hidden = false;
        var m = String(e.message||e);
        var hint = /\b404\b/.test(m)
          ? '<p class="smallprint">A 404 from the backend usually means no '+
            'instance is loaded for this model. Load it from '+
            '<a href="/console/chat">chat</a>, then run the test again.</p>'
          : '';
        out.innerHTML = '<div class="vres"><p class="fail"><strong>Could not '+
          'complete.</strong> '+esc(m)+'</p>'+hint+'</div>';
      }).then(function(){
        b.disabled = false; b.textContent = label;
      });
    }

    document.getElementById('t-repeat').addEventListener('click', function(){
      run('t-repeat', 'Same prompt, three times',
          ['Name one primary colour.','Name one primary colour.','Name one primary colour.']);
    });
    document.getElementById('t-prefix').addEventListener('click', function(){
      run('t-prefix', 'Shared prefix, different questions',
          ['Name one primary colour.','Name one metal.','Name one river.',
           'Name one primary colour.']);
    });
  })();"""
    js = js.replace("%MODEL%", json.dumps(model or ""))

    style = """<style>
      .vtests{display:grid;gap:1px;background:var(--rule);
        grid-template-columns:repeat(auto-fit,minmax(18rem,1fr));
        border:1px solid var(--rule);margin:1.4rem 0}
      .vtest{background:var(--card);padding:1.1rem 1.2rem}
      .vtest h3{margin:0 0 .3rem;font-size:1rem}
      .vtest p{color:var(--muted);font-size:.92rem;margin:0 0 .9rem}
      .vout{margin:1.2rem 0}
      .vres h3{margin:0 0 .4rem;font-size:1rem}
      .vres table{border-collapse:collapse;margin:.6rem 0;font-size:.92rem}
      .vres th,.vres td{text-align:left;padding:.25em 1.2em .25em 0;
        border-bottom:1px solid var(--rule)}
      .pass{color:#0a7d32}
      .fail{color:#a33}
    </style>"""

    body = _shell.section(kicker="losslessness", heading="Verify",
                          body=intro + tests) + f"<script>{js}</script>" + style
    return _human_page("Verify", "verify", body, "/console/verify?format=json")


def _requests_human(rows):
    from faxl.engine import faxl_shell as _shell
    trs = []
    for r in rows:
        hm = (r["outcome"] or r.get("status") or "").lower()
        trs.append([
            _shell.raw(f'<span class="mono">{_when(r.get("ts"))}</span>'),
            _shell.tag(hm or "?", warn=(hm == "miss")),
            _num(r.get("prefill_skipped")), _num(r.get("prefill_paid")),
            _num(r.get("resume_pos")), _ms(r.get("ttft_ms")),
            _model_cell(r.get("model")), r.get("client") or ""])
    body = _shell.section(
        kicker="every request", heading="Requests",
        body=_shell.table(
            ["time", "hit/miss", "from cache", "prefilled", "resumed at",
             "first reply (ms)", "model", "client"], trs,
            empty="No requests recorded yet. Send one through the proxy and it "
                  "will appear here."))
    return _human_page("Requests", "requests", body,
                       "/console/requests?format=json",
                       head_extra=_REQUESTS_STYLE)


# The card must be the thing that scrolls, not the page. A table's min-content
# width otherwise pushes .table-card wider than the column it sits in; min-width
# 0 + max-width 100% keep the card in its container and hand the overflow to
# .table-scroll. nowrap so a timestamp or a number never breaks mid-cell.
_REQUESTS_STYLE = """<style>
.table-card{max-width:100%;min-width:0}
.table-scroll{overflow-x:auto}
.table-card td,.table-card th{white-space:nowrap}
</style>"""


# _short_model lives with the log helpers below: one definition, both views.


def _model_cell(m):
    """Short model name, full id/path on hover."""
    from faxl.engine import faxl_shell as _shell
    if not m:
        return ""
    short = _short_model(m)
    if short == str(m):
        return _shell.raw('<span class="mono">%s</span>' % html.escape(short))
    return _shell.raw('<span class="mono" title="%s">%s</span>'
                      % (html.escape(str(m), quote=True), html.escape(short)))


def _ms(v):
    """Milliseconds for a person: one decimal, or an em dash when unmeasured.

    The feed value is a float straight off the clock (93.81508827209473); the
    trailing digits are noise, not precision. Rounding is display only -- the
    JSON alternate keeps the raw value. None stays a dash, never 0 (see _num).
    """
    if v is None:
        return _num(None)
    try:
        return _num("%.1f" % float(v))
    except (TypeError, ValueError):
        return _num(v)


def _when(ts):
    """A wall-clock time a person can match against their own day.

    The feed carried a raw Unix timestamp -- "1789485188.4808378" -- which is
    the right value and the wrong rendering for a page whose reader is not a
    programmer. Local time, because they are looking at their own machine.
    """
    try:
        return html.escape(time.strftime("%d %b %H:%M:%S",
                                         time.localtime(float(ts))))
    except (TypeError, ValueError):
        return "&mdash;"


def _num(v):
    """A number for a table cell, or an em dash when there is none.

    NOT ZERO. A missing measurement and a measured zero are different facts,
    and printing 0 for "we did not measure it" is the failure this console
    exists to avoid.
    """
    from faxl.engine import faxl_shell as _shell
    return _shell.raw('<span class="mono">%s</span>' % html.escape(str(v))
                      if v is not None
                      else '<span class="mono">&mdash;</span>')


def _status_html(fields):
    # Was _models_html, titled "models" and linking /console/models?format=json:
    # the page moved to /console/status in the 2026-09-18 rename and its agent
    # renderer kept the old name, heading and json link.
    rows = "".join(_dt(k, v) for k, v in fields)
    inner = (f"<dl>{rows}</dl>"
             '<p><a href="/console/models">choose a different model</a> · '
             '<a href="/console/analytics">see the numbers</a> · '
             '<a href="/console/status?format=json">json</a></p>')
    return _page("status", _nav_html("status"), "status", inner,
                 "/console/status?format=json")


# Written as a plain template, not an f-string: the previous f-string version
# mixed f and non-f lines, so the non-f ones printed their doubled braces
# literally ({{role: ...}}) and escaped quotes inside a single-quoted jq filter.
# Neither jq command could run. BIND and MODEL are substituted below.
_VERIFY_SCRIPT = r"""PRE=$(python3 -c "print('You are reading a fixed technical preamble that does not change between requests. It exists so that the prefill cache has a long, stable prefix to store and reuse. ' * 14)")
ask() {  # one question over the fixed preamble; prints a hash of the answer
  jq -n --arg m MODEL --arg p "$PRE

Question: $1" \
      '{model:$m,temperature:0,max_tokens:24,stream:false,messages:[{role:"user",content:$p}]}' \
    | curl -sS http://BIND/v1/chat/completions -H 'Content-Type: application/json' -d @- \
    | jq -r '.choices[0].message.content' | shasum
}

# 1. same prompt three times -- three identical hashes = byte-identical
for i in 1 2 3; do ask 'Name one primary colour.'; done

# 2. shared prefix, different questions -- the 4th hash must equal the 1st
for q in 'Name one primary colour.' 'Name one metal.' 'Name one river.' \
         'Name one primary colour.'; do ask "$q"; done

# 3. what the cache did -- every run after the first should resume (resume_pos > 0)
curl -sS 'http://BIND/api/requests?limit=7' \
  | jq '.requests[] | {outcome, prompt_tokens, resume_pos, prefill_skipped}'
"""


def _verify_curl(model, bind):
    """The same two tests an agent can actually run: it cannot press a button,
    so it gets the commands. Same endpoint, same temperature 0, same static
    preamble and the same questions as the browser tests."""
    return (_VERIFY_SCRIPT.replace("BIND", bind)
            .replace("MODEL", shlex.quote(model or "")))


def _verify_text(condition, model, bind):
    return ("status\ton_demand (the console runs these in the browser; the\n"
            "\tcommands below are the same test for an agent)\n"
            f"condition\t{condition}\n"
            f"model\t{model}\n"
            f"endpoint\thttp://{bind}/v1\n\n"
            + _verify_curl(model, bind))


def _verify_html(status, condition, model="", bind="127.0.0.1:8767"):
    e = html.escape
    return _page(
        "verify", _nav_html("verify"), "verify",
        "<p>A cache that returns a different answer than a cold run is worth "
        "nothing, however fast it is.</p>"
        f"<dl>{_dt('determinism condition', condition)}"
        f"{_dt('model', model)}{_dt('endpoint', 'http://' + bind + '/v1')}</dl>"
        "<p>The human console runs these tests on a button. An agent runs "
        "them directly:</p>"
        f"<pre>{e(_verify_curl(model, bind))}</pre>",
        "/console/verify?format=json")


# ONE column list for the request feed, so the agent table, the text view and
# the human table cannot name the same number three ways. The labels are the
# human page's; the second item is the /api/requests key each column is read
# from, which the agent page prints as a legend -- the API keeps the precise
# values (epoch float, unrounded ms, full model path), the pages do not.
_REQUEST_COLUMNS = [("time", "ts"), ("hit/miss", "outcome"),
                    ("from cache", "prefill_skipped"),
                    ("prefilled", "prefill_paid"),
                    ("resumed at", "resume_pos"),
                    ("first reply (ms)", "ttft_ms"),
                    ("model", "model"), ("client", "client")]


def _iso(ts):
    """Epoch seconds -> ISO-8601, local time WITH its offset: the same clock
    the human page shows, and still unambiguous to a program."""
    try:
        import datetime
        return (datetime.datetime.fromtimestamp(float(ts)).astimezone()
                .isoformat(timespec="seconds"))
    except (TypeError, ValueError, OverflowError, OSError):
        return ""


def _short_model(m):
    """'granite-4.0-h-tiny' from an HF id, a hub cache path or a plain folder.

    .../models--mlx-community--X/snapshots/<hash> -> X;  org/X -> X;
    mlx-community--X -> X. The full value stays in /api/requests."""
    parts = [x for x in str(m or "").replace("\\", "/").split("/") if x]
    if not parts:
        return ""
    name = parts[-1]
    if "snapshots" in parts[1:]:
        name = parts[parts.index("snapshots", 1) - 1]
    if name.startswith("models--"):
        name = name[len("models--"):]
    if "--" in name:                       # org--name: drop the org only
        name = name.split("--", 1)[1]
    return name


def _request_cells(r):
    """One feed row as display strings, in _REQUEST_COLUMNS order. Absent is
    the empty string, never 0 -- an unmeasured number is not a measured zero."""
    def n(k):
        return "" if r.get(k) is None else str(r[k])
    ttft = r.get("ttft_ms")
    return [_iso(r.get("ts")) if r.get("ts") else "",
            (r.get("outcome") or r.get("status") or "").lower(),
            n("prefill_skipped"), n("prefill_paid"), n("resume_pos"),
            "" if ttft is None else f"{float(ttft):.1f}",
            _short_model(r.get("model")), r.get("client") or ""]


def _requests_html(rows):
    e = html.escape
    head = "<tr>" + "".join(f"<th>{e(l)}</th>" for l, _ in _REQUEST_COLUMNS) + "</tr>"
    trs = ["<tr>" + "".join(f"<td>{e(c)}</td>" for c in _request_cells(r)) + "</tr>"
           for r in rows]
    legend = ", ".join(f"{l} = {k}" for l, k in _REQUEST_COLUMNS)
    o = _origin()
    inner = (f"<table>{head}{''.join(trs)}</table>"
             + ("" if rows else "<p>No requests recorded yet. Send one through "
                                "the proxy and it will appear here.</p>")
             + f"<p>Newest first, last 100. Exact values (epoch seconds, "
               f"unrounded ms, full model path) are in the API; its keys: "
               f"{e(legend)}.</p>"
             f"<pre>{e(f'curl -sS {chr(39)}{o}/api/requests?limit=100{chr(39)}')}\n"
             f"{e(f'curl -sS {o}/api/requests/<transaction_id>   # one request in full')}</pre>"
             f'<p><a href="/console/requests?format=json">json</a></p>')
    # Heading and nav label are "log": that is what the nav has called this
    # page since the rename, and "requests" matched no nav item, so the agent
    # nav never marked the current page here.
    return _page("log", _nav_html("log"), "log", inner,
                 "/console/requests?format=json")


# ---- licence (T-0004) ---------------------------------------------------------
# WHAT WENT WRONG, not "invalid key". The three cases are genuinely different
# situations for the person reading them, and collapsing them is the failure this
# page exists to avoid:
#
#   malformed     — a paste accident. RECOVERABLE: say so, and say how.
#   bad_signature — not a faxl key, or altered. Re-pasting the same text will not
#                   help, but a key mangled MID-payload also lands here (the
#                   bytes still base64-decode, the signature just does not
#                   verify), so the wording must not rule out trying again.
#   expired       — a genuine key whose term ended. NEVER the word "invalid":
#                   this is a renewal, not a mistake.
_BANNER = {
    "malformed":
        "That does not look like a complete key. Licence keys are one long line "
        "with a dot in the middle — copy the whole thing from your licence "
        "email, including the part after the dot.",
    "bad_signature":
        "This key did not verify. It is either not a faxl licence key, or its "
        "text was altered on the way here. If you copied it by hand, try again "
        "with the whole key selected; otherwise contact support@faxl.ai.",
    "expired":
        "This licence has expired. The key is genuine — its term has simply "
        "ended. Renew at faxl.ai to switch the cache back on.",
    "unknown":
        "This key could not be applied.",
}


def banner_for(err):
    """The customer-facing sentence for a failure, plus what it means.

    `severity` is what the UI should colour: "error" for the two that need a
    different key, "lapsed" for expiry, which is a billing state rather than a
    broken paste and should not be dressed as a failure of the customer's.
    """
    kind = err.get("type", "unknown")
    text = _BANNER.get(kind, _BANNER["unknown"])
    if kind == "unknown" and err.get("message"):
        text = f"{text} ({err['message']})"
    out = {"type": kind, "severity": "lapsed" if kind == "expired" else "error",
           "message": text}
    if kind == "expired":
        out["renew_url"] = "https://faxl.ai"
        if err.get("customer"):
            out["customer"] = err["customer"]
        if err.get("expiry"):
            out["expiry"] = err["expiry"]
        # If we displaced a working licence to discover this, say what happened.
        if err.get("had_previous"):
            out["previous_licence_restored"] = bool(
                err.get("previous_licence_restored"))
            out["message"] += (
                " Your previous licence has been kept and is still active."
                if err.get("previous_licence_restored") else
                " WARNING: your previous licence could not be restored — the "
                "cache tier is off until the proxy restarts.")
    elif kind == "malformed" and err.get("message"):
        out["detail"] = err["message"]
    return out


def _licence_rows(grant):
    """The read-only 'what this key grants' rows, in reading order.

    seats is rendered as a plain count with an explicit advisory note. It is NOT
    a limit: verification is offline with no phone-home, so a key copied to a
    second machine counts from zero. No "N of M used", no progress bar — a
    limit that looks enforced but is not is worse than one that is plainly
    advisory.
    """
    rows = []
    if grant.get("customer"):
        rows.append(("licensed to", grant["customer"], ""))
    if grant.get("product"):
        rows.append(("product", grant["product"], ""))
    if grant.get("tier"):
        rows.append(("tier", grant["tier"], ""))
    if grant.get("issued"):
        rows.append(("issued", _date(grant["issued"]), ""))
    if grant.get("expiry"):
        rows.append(("expires", _date(grant["expiry"]), ""))
    if grant.get("days_remaining") is not None:
        # Whole days. "361.3 days" invites the question of what .3 of a day
        # means to somebody deciding whether to renew; it means nothing.
        d = grant["days_remaining"]
        rows.append(("days remaining",
                     int(d) if isinstance(d, (int, float)) else d, ""))
    if grant.get("seats"):
        rows.append(("seats", grant["seats"], "advisory — what was bought, "
                                              "not a limit the proxy enforces"))
    if grant.get("features"):
        rows.append(("features", ", ".join(grant["features"]), ""))
    if grant.get("format"):
        rows.append(("key format", grant["format"], ""))
    return rows


def _date(epoch):
    try:
        return time.strftime("%Y-%m-%d", time.gmtime(int(epoch)))
    except (ValueError, OSError, OverflowError):
        return str(epoch)


def shape_licence(status, grant=None, stored_path=None):
    """The /api/licence GET payload: what is live right now."""
    # Accepts either shape: faxl_proxy injects Licence.status() (a dict), a
    # bare wheel host has the licence_status() tuple. See faxl_licence.as_status.
    st = faxl_licence.as_status(status) or {
        "licensed": False, "customer": "", "expiry": 0,
        "days_remaining": 0.0, "on_expiry": "unlicensed"}
    out = {"licensed": bool(st.get("licensed")), "customer": st.get("customer", ""),
           "expiry": st.get("expiry", 0),
           "days_remaining": st.get("days_remaining", 0.0),
           "on_expiry": st.get("on_expiry", "unlicensed"),
           "seats_advisory": True, "installed": bool(stored_path)}
    if grant:
        out["grant"] = grant
    return out


# The key is one long unbroken line. A 183px box for it was a joke at the
# customer's expense: it showed about four characters of a key they cannot
# check by eye. Full width, monospace, and it wraps rather than scrolling
# sideways so a paste can be seen whole.
LICENCE_STYLE = """<style>
  textarea.lickey{width:100%;min-height:7.5rem;box-sizing:border-box;
    font-family:var(--font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);
    font-size:.92rem;line-height:1.45;padding:.7rem .8rem;
    border:1px solid var(--rule);background:var(--card);color:var(--text);
    word-break:break-all;resize:vertical}
  textarea.lickey:focus{outline:2px solid var(--accent);outline-offset:1px}
</style>"""


def _licence_human(payload, banner=None):
    """Where a customer puts the key that came in their email.

    The agent page says to POST JSON to /api/licence. That is the exact
    experience this product exists to remove -- "setting env variables is
    TERRIBLE EXPERIENCE, saving licence files is terrible experience". Assume
    the reader has never opened a terminal and never will.
    """
    from faxl.engine import faxl_shell as _shell
    rows = _licence_rows(payload.get("grant") or {})
    if banner:
        state = ("<p><strong>" + html.escape(banner["message"]) + "</strong></p>")
    elif rows:
        state = _shell.spec([
            (k, _shell.raw(html.escape(str(v))
                           + (f' <span class="smallprint">{html.escape(n)}</span>'
                              if n else "")))
            for k, v, n in rows])
    else:
        state = ('<p>' + _shell.tag("no licence", warn=True) + '</p>'
                 "<p>The proxy still answers every request. What is off is the "
                 "cache tier &mdash; so every prefill runs cold, which is the "
                 "part you are paying for.</p>"
                 '<p class="actions"><a class="cta" '
                 'href="https://faxl.ai/shop.html">Get a free licence key</a></p>')

    paste = (
        '<form id="licform" class="signup" onsubmit="return false">'
        '<div class="field"><label for="lic-key">Paste your licence key</label>'
        '<textarea id="lic-key" class="lickey" rows="5" spellcheck="false" autocapitalize="off" '
        'autocorrect="off" autocomplete="off" '
        'placeholder="It is one long line with a dot in the middle &mdash; '
        'paste the whole thing"></textarea></div>'
        '<p class="actions"><button class="cta" id="lic-save" type="button">'
        'Save licence</button></p>'
        '<p class="form-msg" id="lic-msg"></p></form>')

    js = """
  // Same endpoint the agent page documents, driven from a box instead of a
  // terminal. Loopback-gated server side; nothing here is trusted.
  (function(){
    var btn=document.getElementById('lic-save'),
        box=document.getElementById('lic-key'),
        msg=document.getElementById('lic-msg');
    if(!btn) return;
    btn.addEventListener('click', function(){
      var key=(box.value||'').trim();
      if(!key){ msg.className='form-msg err'; msg.textContent='Paste the key first.'; return; }
      btn.disabled=true; msg.className='form-msg pending'; msg.textContent='Checking\u2026';
      fetch('/api/licence',{method:'POST',headers:{'Content-Type':'application/json'},
                            body:JSON.stringify({key:key})})
        .then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d};});})
        .then(function(res){
          if(res.ok && !res.d.error){
            msg.className='form-msg ok';
            msg.textContent='Saved. Reloading\u2026';
            setTimeout(function(){location.reload();}, 900);
          } else {
            msg.className='form-msg err';
            msg.textContent=(res.d && (res.d.error && (res.d.error.message||res.d.error)))
                            || 'That key was not accepted.';
            btn.disabled=false;
          }
        })
        .catch(function(){
          msg.className='form-msg err';
          msg.textContent='Could not reach the proxy. The key was not saved.';
          btn.disabled=false;
        });
    });
  })();"""

    # Install FIRST, details SECOND. The old order led with a details table
    # that is empty on first open -- the one moment this page matters most --
    # and buried the box you came here to use underneath it. Once a key is in,
    # the details sit directly under the box that produced them.
    body = (_shell.section(kicker="your licence", heading="Install the key",
                           body=paste)
            + _shell.section(heading="What your licence covers", body=state)
            + f"<script>{js}</script>"
            + LICENCE_STYLE)
    return _human_page("Licence", "licence", body,
                       "/console/licence?format=json")


def _licence_html(payload, banner=None):
    rows = _licence_rows(payload.get("grant") or {})
    if banner:
        inner = (f"<p><strong>{html.escape(banner['message'])}</strong></p>")
    elif rows:
        inner = f"<dl>{''.join(_dt(k, v, '', (' — ' + n) if n else '') for k, v, n in rows)}</dl>"
    else:
        inner = ("<p>No licence is installed. The proxy still serves every "
                 "request; the cache tier is off, so each prefill runs cold.</p>")
    curl = (f"curl -sS -X POST {_origin()}/api/licence \\\n"
            "  -H 'Content-Type: application/json' \\\n"
            "  -d '{\"key\": \"<your key>\"}'")
    inner += ("<p>To install a key, POST it to <code>/api/licence</code>, or "
              "paste it into the licence page in the human console.</p>"
              f"<pre>{html.escape(curl)}</pre>"
              '<p>No key? <a href="https://faxl.ai/shop.html">Get a free '
              'licence key</a> (leaves this machine, opens faxl.ai).</p>'
              '<p><a href="/console/licence?format=json">json</a></p>')
    return _page("licence", _nav_html("licence"), "licence", inner,
                 "/console/licence?format=json")


# ---- /api/state: one state, and every panel reads it ------------------------
# docs/plans/console-dashboard-rebuild.md §D. Eleven pages each probing their
# own source is how the console came to say "backend is not answering" while
# it served, and "nothing served yet" over 275 logged requests. Every panel,
# the agent view and the JSON now read ONE payload built in ONE place.
#
# Two rules carry the product's honesty and are enforced here, not in the
# renderers: null means "not measured" (never 0), and nothing estimated goes
# in. A fresh install is cold and the payload says cold.

# First reply is only ever compared like with like: a 5k-token image prompt
# that hit set against a 21-token prompt that missed is two true numbers and
# a false comparison. So medians live inside prompt-size bands, each with n.
# Decimal thousands, matching how the contract writes them.
_BANDS = [("<1k", 0, 1000), ("1k–4k", 1000, 4000),
          ("4k–16k", 4000, 16000), ("16k+", 16000, None)]


def _median(xs):
    xs = sorted(xs)
    n = len(xs)
    if not n:
        return None
    mid = n // 2
    return xs[mid] if n % 2 else (xs[mid - 1] + xs[mid]) / 2.0


def first_reply_bands(rows):
    """Median time-to-first-token per prompt-size band, hits and misses apart.

    Rows are /api/requests rows. Only completed HIT/MISS rows that carried a
    measured TTFT count; a row without one is skipped, not counted as 0. The
    band is chosen from prompt_tokens, or, on events written before that field
    existed, from skipped + prefilled -- the same two counts, summed. A side
    with no rows is null, so an empty band reads "—" rather than "0 ms".
    """
    acc = {label: {"HIT": [], "MISS": []} for label, _lo, _hi in _BANDS}
    for r in rows or []:
        side = r.get("outcome")
        ttft = r.get("ttft_ms")
        if side not in ("HIT", "MISS") or ttft is None:
            continue
        size = r.get("prompt_tokens") or 0
        if not size:
            size = (r.get("prefill_skipped") or 0) + (r.get("prefill_paid") or 0)
        if not size:
            continue            # no size recorded: cannot be placed honestly
        for label, lo, hi in _BANDS:
            if size >= lo and (hi is None or size < hi):
                acc[label][side].append(float(ttft))
                break

    def side(xs):
        if not xs:
            return None
        return {"n": len(xs), "median_ms": round(_median(xs), 1)}

    return [{"label": label, "lo": lo, "hi": hi,
             "hit": side(acc[label]["HIT"]), "miss": side(acc[label]["MISS"])}
            for label, lo, hi in _BANDS]


def _exo_installed():
    """Can this interpreter run `python -m exo`? Looked up, never imported:
    importing exo starts nothing but costs seconds, on every poll."""
    try:
        import importlib.util
        return importlib.util.find_spec("exo") is not None
    except (ImportError, ValueError):
        return False


# A HuggingFace repo id, as exo names models: org/name, one slash, no spaces.
# faxl_config owns it (the proxy and faxl_start.sh name models the same way).
_HUB_ID_RE = faxl_config.HUB_ID_RE


def _hub_id(model):
    """The HuggingFace id for a model the proxy may know by a PATH -- see
    faxl_config.hub_id, the one implementation (exo cannot take a path)."""
    return faxl_config.hub_id(model)


def _exo_startable():
    """(ok, why_not) -- can this machine bring the stack up on exo?

    exo is the CLUSTER BACKEND, not a side service: coming up on exo means
    stopping this proxy and exec'ing faxl_start.sh on exo, which starts exo with its
    own cache off and faxl in front of it. So this checks what that launcher
    itself checks before it will start anything -- the launcher is shipped,
    the stop script is shipped (the panel must be able to stop what it
    starts), and the interpreter it is handed (FAXL_PYTHON = this one) can
    import both exo and faxl. When it cannot, the reason goes to the panel in
    words, and the power route answers 501 with the same words.
    """
    if not os.path.isfile(_start_path()):
        return False, (f"the launcher is not in this build "
                       f"({_start_path()}; set FAXL_LAUNCHER)")
    if not os.path.isfile(_stop_path()):
        return False, "exo is not part of this build (no exo_stop.sh)"
    if not _exo_installed():
        return False, f"exo is not installed for {sys.executable}"
    if not _faxl_installed():
        return False, (f"{sys.executable} cannot import faxl, and the exo "
                       f"launcher runs the proxy with it")
    return True, None


def _faxl_installed():
    try:
        import importlib.util
        return importlib.util.find_spec("faxl") is not None
    except (ImportError, ValueError):
        return False


def _dash(v, fmt="{}"):
    return "—" if v is None else fmt.format(v)


def state_controls(origin):
    """(what it does, curl) for every control the panel has.

    The agent view prints these beside the state, so an agent can do anything
    a person can -- and reads, in the same place, what each one costs.
    """
    j = "-H 'Content-Type: application/json'"

    def post(path, body=None):
        data = f" {j} -d '{json.dumps(body)}'" if body is not None else ""
        return f"curl -X POST {origin}{path}{data}"
    return [
        ("restart the proxy (the console goes away for a few seconds)",
         post("/api/proxy/power", {"action": "restart"})),
        ("stop the proxy (one-way: it needs a terminal to start again)",
         post("/api/proxy/power", {"action": "stop"})),
        ("switch the backend to the exo cluster: exo executes across the "
         "cluster's machines and faxl stays in front, so the cache still "
         "applies (the proxy restarts onto exo, about a minute; the store "
         "survives). model_id is optional -- a cluster can serve a model "
         "too large for this Mac",
         post("/api/backend/switch", {"backend": "exo",
                                      "model_id": "<org/name>"})),
        ("switch the backend back to this Mac (MLX): exo stops and the proxy "
         "restarts with the model in its own process",
         post("/api/backend/switch", {"backend": "mlx"})),
        ("bring the stack up on exo with the model now serving (same as "
         "switching to exo)", post("/api/backend/power", {"state": "on"})),
        ("stop exo (on the exo backend nothing will serve until it is "
         "started again)", post("/api/backend/power", {"state": "off"})),
        ("switch model (restarts the proxy onto a model already on disk)",
         post("/api/restart", {"model_id": "<id from models>"})),
        ("configure the store and its cap (takes effect on restart)",
         post("/api/configure", {"store": "/path/to/store", "cap_gb": 60})),
        ("install a licence key", post("/api/licence", {"key": "<key>"})),
        ("run verify", post("/api/verify")),
        ("start tagging the camera roll",
         post("/api/apps/cameraroll/start", {"count": 20})),
        ("stop tagging the camera roll", post("/api/apps/cameraroll/stop")),
    ]


def _state_rows(s):
    """The state as (key, value) display pairs -- shared by the text and the
    agent HTML so the two cannot drift. Absent is "—", never 0."""
    px, be, m, c = s["proxy"], s["backend"], s["model"], s["cache"]
    ex = be.get("exo") or {}
    k, t, lic = s["counts"], s["tokens"], s["licence"]
    if be.get("name") == "exo":
        exo = "the serving backend, " + ("answering" if ex.get("running")
                                          else "NOT answering")
    elif ex.get("running"):
        exo = "running WITHOUT faxl in front of it (switch to exo, or stop it)"
    else:
        exo = ("not running; switch the backend to exo cluster to use it"
               if ex.get("can_start") else
               "not running" + (f" ({ex['note']})" if ex.get("note") else ""))
    if ex.get("nodes") is not None:
        exo += f", {ex['nodes']} node(s)"
    avail = "; ".join(
        f"{a.get('label')}" + (" (serving)" if a.get("serving") else
                               (" (can switch)" if a.get("can_switch") else
                                " (cannot switch" + (f": {a['note']}" if a.get("note") else "") + ")"))
        for a in (be.get("available") or []))
    cl = s.get("cluster")
    hr = s.get("hit_rate")
    rows = [
        ("proxy", (f"running on {px.get('bind')}, up {_dash(px.get('uptime_s'), '{:.0f}')} s"
                   if px.get("running") else "not running")),
        ("backend", f"{_dash(be.get('name'))} "
                    + ("up" if be.get("up") else
                       ("down" if be.get("up") is False else "—"))
                    + (" (model in this process)" if be.get("in_process") else "")),
        ("backends", avail or "—"),
        ("exo cluster", f"{exo} — {_dash(ex.get('endpoint'))}"),
        ("model", f"{_dash(m.get('short') or None)}"
                  + (" (vision)" if m.get("vision") else "")),
        ("cache", ("cold" if c.get("cold") else
                   ("warm" if c.get("cold") is False else "—"))
                  + f", {_dash(c.get('entries'))} entries"),
        ("store", f"{_dash(c.get('used_bytes'))} of {_dash(c.get('cap_bytes'))} bytes"
                  f" at {_dash(c.get('path'))}"),
        ("requests", f"{_dash(k.get('requests'))} ({_dash(k.get('hits'))} hit,"
                     f" {_dash(k.get('misses'))} miss, {_dash(k.get('incomplete'))}"
                     f" incomplete, {_dash(k.get('rejected'))} rejected)"),
        ("prefill skipped", f"{_dash(t.get('skipped'))} of"
                            f" {_dash(t.get('received'))} prompt tokens"),
        ("hit rate", "—" if hr is None else f"{hr * 100:.1f}%"),
        ("lossless", _dash(s["lossless"].get("status"))),
        ("licence", f"{_dash(lic.get('state'))}"
                    + (f", {lic['days_remaining']} days left"
                       if lic.get("days_remaining") is not None else "")),
    ]
    if cl:
        pf = cl.get("prefill") or {}
        rows.append(("cluster", f"{_dash(cl.get('nodes'))} node(s); prefill server "
                     + (f"{_dash(pf.get('requests'))} requests, {_dash(pf.get('hits'))} hits, "
                        f"{_dash(pf.get('stored'))} stored" if cl.get("prefill")
                        else "counts not exposed to the console")))
        for d in cl.get("downloads") or []:
            rows.append((f"downloading {d.get('model')}",
                         f"{_dash(d.get('percent'))}% of {_dash(d.get('gb'))} GB"))
    for b in s["first_reply"]["bands"]:
        def side(x):
            return "—" if not x else f"{x['median_ms']} ms (n={x['n']})"
        rows.append((f"first reply {b['label']}",
                     f"hit {side(b['hit'])}, miss {side(b['miss'])}"))
    for a in s["apps"]:
        jb = a.get("job")
        rows.append((f"app {a['slug']}",
                     a["title"] + ("" if not jb else
                                   f" — {'running' if jb.get('running') else 'idle'},"
                                   f" {_dash(jb.get('done'))}/{_dash(jb.get('total'))}")))
    return rows


def state_text(s, origin):
    lines = [_NAV, ""]
    lines += [f"{k}\t{v}" for k, v in _state_rows(s)]
    for n in s["notices"]:
        lines.append(f"{n['level']}\t{n['title']} {n['text']}".rstrip())
    lines.append("")
    lines += [f"# {what}\n{cmd}" for what, cmd in state_controls(origin)]
    lines.append("")
    lines.append(f"full state: {origin}/api/state")
    return "\n".join(lines) + "\n"


def state_agent_html(s, origin):
    """Agent mode of /console: the SAME state as plain semantic HTML (spec §6)
    -- a <dl> of facts, a table of first-reply bands, the notices, and the curl
    for every control. Everything is escaped: model ids and notice text can
    carry anything."""
    esc = html.escape
    dl = "".join(f"<dt>{esc(k)}</dt><dd>{esc(str(v))}</dd>"
                 for k, v in _state_rows(s))
    bands = "".join(
        f"<tr><td>{esc(b['label'])}</td>"
        + "".join(f"<td>{'&mdash;' if not x else esc(str(x['median_ms']))}</td>"
                  f"<td>{'&mdash;' if not x else x['n']}</td>"
                  for x in (b["hit"], b["miss"])) + "</tr>"
        for b in s["first_reply"]["bands"])
    table = ("<h2>first reply, like with like</h2><table><thead><tr>"
             "<th>prompt tokens</th><th>hit median ms</th><th>hit n</th>"
             "<th>miss median ms</th><th>miss n</th></tr></thead>"
             f"<tbody>{bands}</tbody></table>")
    notes = ""
    if s["notices"]:
        notes = "<h2>notices</h2><ul>" + "".join(
            f"<li>{esc(n['level'])}: <strong>{esc(n['title'])}</strong> "
            f"{esc(n['text'])}"
            + (f' <a href="{esc(n["href"])}">{esc(n["href"])}</a>'
               if n.get("href") else "") + "</li>"
            for n in s["notices"]) + "</ul>"
    ctl = "<h2>controls</h2><dl>" + "".join(
        f"<dt>{esc(what)}</dt><dd><pre>{esc(cmd)}</pre></dd>"
        for what, cmd in state_controls(origin)) + "</dl>"
    inner = (f"<dl>{dl}</dl>{table}{notes}{ctl}"
             f'<p>full state: <a href="/api/state">/api/state</a> '
             f'(also <a href="/console?format=json">?format=json</a>, '
             f'<a href="/console?format=text">?format=text</a>); the exo '
             f'cluster: <a href="/console/exo?mode=agent">/console/exo</a></p>')
    return _page("console", _nav_html("welcome"), "state", inner,
                 "/console?format=json")


# ---------------------------------------------------------------- the exo page
# /console/exo and GET /api/exo (plan: console-dashboard-rebuild, "The exo
# page"). exo is the backend a model too large for one Mac runs on, and the
# owner calls it the product's most important feature -- so it gets a page of
# its own: the nodes and their memory, exo's catalogue, the links between the
# machines, where the serving model's shards sit, and exo's log.
#
# WHAT IS CONFIRMED, AND WHAT IS NOT. faxl talks to four exo routes it has
# always used: /v1/models, /state/downloads (keyed by node id), /models/add and
# /place_instance. exo's own dashboard reads the whole cluster from a state
# endpoint; no copy of exo's source is in these repos to pin its name, so the
# candidates below are tried ONCE per exo address and the one that answered is
# remembered. Everything read from it is parsed defensively -- camelCase or
# snake_case, tagged unions ({"TagName": {...}}) or plain dicts -- and a fact
# exo does not report is null (rendered "—"), with ONE line saying exo does
# not expose it. Nothing is inferred from a name, and nothing is ever 0 for
# "not reported".
EXO_STATE_PATHS = ("/state", "/topology")


def _k(d, *names):
    """The first of several spellings of a key that is present and not null."""
    if not isinstance(d, dict):
        return None
    for n in names:
        v = d.get(n)
        if v is not None:
            return v
    return None


def _untag(v):
    """exo serialises a union as {"TagName": {...}}: (tag, body). Anything
    else comes back as (None, v)."""
    if isinstance(v, dict) and len(v) == 1:
        (k, b), = v.items()
        if isinstance(k, str) and k[:1].isupper() and isinstance(b, dict):
            return k, b
    return None, v


def _nbytes(v):
    """Bytes from a number or from exo's {"inBytes": n} memory type."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return int(v) if v >= 0 else None
    if isinstance(v, dict):
        return _nbytes(_k(v, "inBytes", "in_bytes", "bytes"))
    return None


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _addr(v):
    """An address as text: a string, or the address field of a dict."""
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        a = _k(v, "address", "ipAddress", "ip_address", "multiaddr", "addr")
        return a if isinstance(a, str) else None
    return None


def _link_kind(*texts):
    """Thunderbolt / RDMA / ethernet / Wi-Fi as exo labels the link, or None.
    Read from exo's own tag or type field -- never from an IP range."""
    low = " ".join(t for t in texts if isinstance(t, str)).lower()
    if not low:
        return None
    for key, label in (("rdma", "RDMA"), ("jaccl", "RDMA"),
                       ("thunderbolt", "Thunderbolt"), ("ethernet", "ethernet"),
                       ("wifi", "Wi-Fi"), ("wi-fi", "Wi-Fi"), ("socket", "socket"),
                       ("tcp", "socket")):
        if key in low:
            return label
    return None


def _node_ids(v):
    """Node ids from a list of ids, a list of {nodeId: …} dicts, or a dict
    keyed by id."""
    out = []
    if isinstance(v, dict):
        out = [str(k) for k in v]
    elif isinstance(v, list):
        for x in v:
            if isinstance(x, str):
                out.append(x)
            elif isinstance(x, dict):
                i = _k(x, "nodeId", "node_id", "id")
                if isinstance(i, str):
                    out.append(i)
    return out


def _seen_age(v, now):
    """Seconds since a last-seen value (epoch seconds, ms, or ISO text)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        t = v / 1000.0 if v > 1e12 else float(v)
        return max(0.0, now - t)
    if isinstance(v, str):
        try:
            from datetime import datetime
            t = datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            return max(0.0, now - t)
        except ValueError:
            return None
    return None


def parse_exo_state(st, downloads=None, serving=None, now=None):
    """exo's cluster state -> what the exo page shows.

    `st` is the body of exo's state endpoint (or None when exo does not expose
    one), `downloads` the body of /state/downloads, `serving` the hub id this
    proxy serves. Returns {nodes, links, placement, exposes}; every value exo
    did not report is None.
    """
    now = time.time() if now is None else now
    st = st if isinstance(st, dict) else {}
    dl = downloads if isinstance(downloads, dict) else {}
    topo = _k(st, "topology") if isinstance(_k(st, "topology"), dict) else (
        st if ("nodes" in st or "connections" in st) and "instances" not in st
        else {})
    profiles = _k(st, "nodeProfiles", "node_profiles") or {}
    idents = _k(st, "nodeIdentities", "node_identities") or {}
    memory = _k(st, "nodeMemory", "node_memory") or {}
    system = _k(st, "nodeSystem", "node_system") or {}
    network = _k(st, "nodeNetwork", "node_network") or {}
    seen = _k(st, "lastSeen", "last_seen") or {}
    topo_nodes = _node_ids(_k(topo, "nodes"))
    order = []
    for src in (topo_nodes, _node_ids(idents), _node_ids(profiles),
                _node_ids(memory), _node_ids(seen), [str(k) for k in dl]):
        for i in src:
            if i not in order:
                order.append(i)
    topo_node_dicts = {}
    if isinstance(_k(topo, "nodes"), list):
        for x in _k(topo, "nodes"):
            if isinstance(x, dict):
                i = _k(x, "nodeId", "node_id", "id")
                if isinstance(i, str):
                    topo_node_dicts[i] = x
    elif isinstance(_k(topo, "nodes"), dict):
        topo_node_dicts = {str(k): v for k, v in _k(topo, "nodes").items()
                           if isinstance(v, dict)}

    # -- placement: instances -> (node -> shards)
    placement = None
    shards_by_node = {}
    insts = _k(st, "instances")
    runners = _k(st, "runners") or {}
    if isinstance(insts, dict):
        placement = []
        for iid, raw in insts.items():
            itag, body = _untag(raw)
            sa = _k(body, "shardAssignments", "shard_assignments") or {}
            mid = _k(sa, "modelId", "model_id")
            r2s = _k(sa, "runnerToShard", "runner_to_shard") or {}
            n2r = _k(sa, "nodeToRunner", "node_to_runner") or {}
            shards = []
            for node, runner in (n2r.items() if isinstance(n2r, dict) else []):
                stag, sh = _untag(r2s.get(runner) if isinstance(r2s, dict) else None)
                sh = sh if isinstance(sh, dict) else {}
                card = _k(sh, "modelCard", "model_card") or {}
                mid = mid or _k(card, "modelId", "model_id")
                rtag, _rb = _untag(runners.get(runner)) if isinstance(runners, dict) else (None, None)
                kind = ("pipeline" if stag and "pipeline" in stag.lower() else
                        "tensor" if stag and "tensor" in stag.lower() else stag)
                row = {"node": str(node), "runner": str(runner), "kind": kind,
                       "rank": _num(_k(sh, "deviceRank", "device_rank")),
                       "world": _num(_k(sh, "worldSize", "world_size")),
                       "start_layer": _num(_k(sh, "startLayer", "start_layer")),
                       "end_layer": _num(_k(sh, "endLayer", "end_layer")),
                       "n_layers": _num(_k(sh, "nLayers", "n_layers")),
                       "runner_status": rtag}
                shards.append(row)
            shards.sort(key=lambda r: (r["rank"] is None, r["rank"] or 0))
            inst = {"id": str(iid), "kind": itag, "model": mid,
                    "serving": bool(serving) and mid == serving,
                    "shards": shards}
            placement.append(inst)
            for r in shards:
                shards_by_node.setdefault(r["node"], []).append(
                    dict(r, instance=str(iid), model=mid))
        placement.sort(key=lambda p: (not p["serving"], str(p["model"])))

    # -- downloads per node
    done_by_node, live_by_node = {}, {}
    for node, entries in dl.items():
        for entry in entries or []:
            tag, body = _untag(entry)
            if not tag or not isinstance(body, dict):
                continue
            sm = _k(body, "shardMetadata", "shard_metadata") or {}
            _t, smb = _untag(sm)
            card = _k(smb if isinstance(smb, dict) else {}, "modelCard", "model_card") or {}
            mid = _k(card, "modelId", "model_id")
            if not mid:
                continue
            if tag == "DownloadCompleted":
                done_by_node.setdefault(str(node), []).append(mid)
            elif tag != "DownloadPending":
                prog = _k(body, "downloadProgress", "progress", "data") or {}
                tot = _nbytes(_k(prog, "total")) if isinstance(prog, dict) else None
                got = _nbytes(_k(prog, "downloaded")) if isinstance(prog, dict) else None
                live_by_node.setdefault(str(node), []).append({
                    "model": mid, "state": tag,
                    "percent": (round(100.0 * got / tot, 1) if tot and got is not None else None),
                    "bytes": tot, "bytes_done": got})

    nodes = []
    any_detail = any_mem = False
    for nid in order:
        ident = {}
        for src in (topo_node_dicts.get(nid), profiles.get(nid) if isinstance(profiles, dict) else None,
                    idents.get(nid) if isinstance(idents, dict) else None):
            if isinstance(src, dict):
                inner = _k(src, "nodeProfile", "node_profile")
                ident.update(inner if isinstance(inner, dict) else {})
                ident.update(src)
        mem = (memory.get(nid) if isinstance(memory, dict) else None) or \
            _k(ident, "memory", "memoryProfile", "memory_profile") or {}
        sysd = (system.get(nid) if isinstance(system, dict) else None) or \
            _k(ident, "system", "systemProfile", "system_profile") or {}
        net = (network.get(nid) if isinstance(network, dict) else None) or \
            _k(ident, "networkInterfaces", "network_interfaces", "interfaces")
        if isinstance(net, dict):
            net = _k(net, "interfaces", "networkInterfaces", "network_interfaces") or []
        addrs = None
        if isinstance(net, list):
            addrs = []
            for itf in net:
                if isinstance(itf, dict):
                    ip = _k(itf, "ipAddress", "ip_address", "address", "ip")
                    if isinstance(ip, str):
                        name = _k(itf, "name", "interface")
                        addrs.append(f"{name} {ip}" if isinstance(name, str) else ip)
                elif isinstance(itf, str):
                    addrs.append(itf)
        ram_total = _nbytes(_k(mem, "ramTotal", "ram_total", "total"))
        ram_free = _nbytes(_k(mem, "ramAvailable", "ram_available", "available", "free"))
        name = _k(ident, "friendlyName", "friendly_name", "hostname", "name")
        chip = _k(ident, "chipId", "chip_id", "chip")
        device = _k(ident, "modelId", "model_id", "deviceModel", "device_model")
        if nid in topo_nodes:
            reachable = True
        else:
            age = _seen_age(seen.get(nid), now) if isinstance(seen, dict) else None
            reachable = None if age is None else age < 30
        if any(v is not None for v in (name, chip, device)) or addrs:
            any_detail = True
        if ram_total is not None:
            any_mem = True
        nodes.append({
            "id": nid,
            "name": name if isinstance(name, str) else None,
            "reachable": reachable,
            "chip": chip if isinstance(chip, str) else None,
            "device": device if isinstance(device, str) else None,
            "ram_total": ram_total, "ram_free": ram_free,
            "gpu_usage": _num(_k(sysd, "gpuUsage", "gpu_usage")),
            "gpu_memory": _nbytes(_k(mem, "gpuTotal", "gpu_total", "vramTotal",
                                     "vram_total")),
            "addresses": addrs,
            "shards": shards_by_node.get(nid, []),
            "downloading": live_by_node.get(nid, []),
            "on_disk": sorted(set(done_by_node.get(nid, []))),
        })

    # -- links between nodes
    links = None
    conns = _k(topo, "connections", "edges", "links")
    if isinstance(conns, (list, dict)):
        links = []
        items = []
        if isinstance(conns, list):
            items = [(None, None, c) for c in conns]
        else:
            for a, sinks in conns.items():
                if isinstance(sinks, dict):
                    for b, e in sinks.items():
                        for c in (e if isinstance(e, list) else [e]):
                            items.append((str(a), str(b), c))
                elif isinstance(sinks, list):
                    for c in sinks:
                        items.append((str(a), None, c))
        for a, b, c in items:
            tag, body = _untag(c)
            body = body if isinstance(body, dict) else {}
            edge = _k(body, "edge", "connection")
            etag, ebody = _untag(edge)
            ebody = ebody if isinstance(ebody, dict) else {}
            merged = dict(body)
            merged.update(ebody)
            prof = _k(merged, "connectionProfile", "connection_profile", "profile") or {}
            src = a or _k(merged, "localNodeId", "local_node_id", "source",
                          "sourceNodeId", "source_node_id", "from")
            dst = b or _k(merged, "sendBackNodeId", "send_back_node_id", "sink",
                          "sinkNodeId", "sink_node_id", "to")
            raw_kind = _k(merged, "kind", "type", "linkType", "link_type")
            links.append({
                "from": str(src) if src is not None else None,
                "to": str(dst) if dst is not None else None,
                "kind": _link_kind(tag, etag, raw_kind if isinstance(raw_kind, str) else None),
                "as_reported": etag or tag or (raw_kind if isinstance(raw_kind, str) else None),
                "address": _addr(_k(merged, "sendBackMultiaddr", "send_back_multiaddr",
                                    "sinkMultiaddr", "sink_multiaddr", "multiaddr",
                                    "address", "sinkAddr", "sink_addr")),
                "latency": _num(_k(prof, "latency", "latencyMs", "latency_ms")),
                "throughput": _num(_k(prof, "throughput", "bandwidth")),
            })

    return {"nodes": nodes, "links": links, "placement": placement,
            "exposes": {"nodes": any_detail, "memory": any_mem,
                        "links": links is not None,
                        "placement": placement is not None}}


def _gb_text(b):
    return "—" if b is None else f"{b / 1e9:.1f} GB"


def exo_rows(p):
    """The exo payload as (key, value) display pairs, for the agent HTML and
    the text view -- one list, so the two cannot drift. Absent is "—"."""
    ex = p.get("exo") or {}
    t = p.get("totals") or {}
    pf = p.get("prefill") or {}
    if ex.get("running"):
        state = "running"
    elif ex.get("running") is False:
        state = "not answering"
    else:
        state = "—"
    front = ("yes — exo is the serving backend" if ex.get("faxl_in_front")
             else "no")
    rows = [("exo", f"{state} at {_dash(ex.get('endpoint'))}"),
            ("exo version", _dash(ex.get("version"))),
            ("serving backend", _dash(ex.get("serving_backend"))),
            ("faxl in front", front)]
    if ex.get("warn"):
        rows.append(("warning", ex["warn"]))
    rows += [("cluster state from", _dash(ex.get("state_endpoint"))),
             ("nodes online", f"{_dash(t.get('nodes_online'))} of "
                              f"{_dash(t.get('nodes_known'))} known"),
             ("RAM online", f"{_gb_text(t.get('ram_total'))} total, "
                            f"{_gb_text(t.get('ram_free'))} free")]
    for n in p.get("nodes") or []:
        sh = "; ".join(
            f"{s.get('model') or '—'} {s.get('kind') or ''} rank "
            f"{_dash(s.get('rank'))}/{_dash(s.get('world'))} layers "
            f"{_dash(s.get('start_layer'))}–{_dash(s.get('end_layer'))}"
            for s in n.get("shards") or []) or "no shards"
        rows.append((f"node {n.get('name') or n.get('id')}",
                     f"id {n.get('id')}; "
                     + ("reachable" if n.get("reachable") else
                        "not reachable" if n.get("reachable") is False else
                        "reachability —")
                     + f"; {_dash(n.get('chip'))} {_dash(n.get('device'))}; RAM "
                     f"{_gb_text(n.get('ram_total'))} total, "
                     f"{_gb_text(n.get('ram_free'))} free; "
                     f"{', '.join(n.get('addresses') or []) or 'address —'}; {sh}"))
    rows.append(("prefill server",
                 f"{_dash(pf.get('endpoint'))} (from {_dash(pf.get('file'))}); "
                 f"{_dash(pf.get('requests'))} requests, {_dash(pf.get('hits'))} hits, "
                 f"{_dash(pf.get('stored'))} stored"))
    for d in p.get("downloads") or []:
        rows.append((f"downloading {d.get('model')}",
                     f"{_dash(d.get('percent'))}% of {_dash(d.get('gb'))} GB"))
    for ln in p.get("links") or []:
        rows.append((f"link {_dash(ln.get('from'))} → {_dash(ln.get('to'))}",
                     f"{_dash(ln.get('kind') or ln.get('as_reported'))}, latency "
                     f"{_dash(ln.get('latency'))}, throughput "
                     f"{_dash(ln.get('throughput'))} (as exo reports them)"))
    for inst in p.get("placement") or []:
        rows.append((f"instance {inst.get('id')}",
                     f"{_dash(inst.get('model'))}" + (" (serving)" if inst.get("serving") else "")
                     + f", {_dash(inst.get('kind'))}, {len(inst.get('shards') or [])} shard(s)"))
    ms = p.get("models")
    rows.append(("models in exo's catalogue",
                 "—" if ms is None else
                 f"{len(ms)} ({sum(1 for m in ms if m.get('on_disk'))} on disk, "
                 f"{sum(1 for m in ms if m.get('hybrid') is True)} hybrid / recurrent)"))
    return rows


def exo_controls(origin):
    j = "-H 'Content-Type: application/json'"

    def post(path, body=None):
        data = f" {j} -d '{json.dumps(body)}'" if body is not None else ""
        return f"curl -X POST {origin}{path}{data}"
    return [
        ("the exo page's facts as JSON (polled every 3 s by the page)",
         f"curl {origin}/api/exo"),
        ("the last lines of exo's log (this machine only)",
         f"curl '{origin}/api/exo/log?lines=60'"),
        ("exo's catalogue, with what is on disk",
         f"curl '{origin}/api/models/catalogue?source=exo'"),
        ("download progress, per node", f"curl {origin}/api/models/progress"),
        ("switch the backend to the exo cluster (the proxy restarts onto exo, "
         "faxl in front; about a minute; the store survives)",
         post("/api/backend/switch", {"backend": "exo", "model_id": "<org/name>"})),
        ("serve another model on exo, already the backend (the proxy restarts)",
         post("/api/restart", {"model_id": "<id from exo's catalogue>"})),
        ("download a model onto the cluster (exo backend only)",
         post("/api/models/download", {"model_id": "<id from exo's catalogue>"})),
        ("add a HuggingFace model to exo's catalogue (fetches the card, no weights)",
         post("/api/models/register", {"model_id": "<org/name>"})),
        ("start exo, with faxl in front (same as switching to exo)",
         post("/api/backend/power", {"state": "on"})),
        ("stop exo", post("/api/backend/power", {"state": "off"})),
        ("switch back to this Mac (MLX)", post("/api/backend/switch", {"backend": "mlx"})),
    ]


def exo_text(p, origin):
    lines = [_NAV, ""] + [f"{k}\t{v}" for k, v in exo_rows(p)]
    for n in p.get("notices") or []:
        lines.append(f"{n.get('level')}\t{n.get('title')} {n.get('text') or ''}".rstrip())
    lines.append("")
    lines += [f"# {what}\n{cmd}" for what, cmd in exo_controls(origin)]
    return "\n".join(lines) + "\n"


def exo_agent_html(p, origin):
    """Agent mode of /console/exo: the same facts as /api/exo, as a <dl>, the
    catalogue as a table, and the curl for every control. All escaped."""
    esc = html.escape
    dl = "".join(f"<dt>{esc(k)}</dt><dd>{esc(str(v))}</dd>" for k, v in exo_rows(p))
    notes = ""
    if p.get("notices"):
        notes = "<h2>notices</h2><ul>" + "".join(
            f"<li>{esc(str(n.get('level')))}: <strong>{esc(str(n.get('title')))}</strong> "
            f"{esc(str(n.get('text') or ''))}</li>" for n in p["notices"]) + "</ul>"
    ms = p.get("models") or []
    table = ""
    if ms:
        def tick(v):
            return "yes" if v is True else ("no" if v is False else "—")
        table = ("<h2>exo's catalogue</h2><p>Hybrid / recurrent models keep a "
                 "recurrent state, not a KV cache: only faxl caches these "
                 "correctly.</p><table><thead><tr><th>model</th><th>arch</th>"
                 "<th>family</th><th>quant</th><th>GB</th><th>context</th>"
                 "<th>vision</th><th>thinking</th><th>multi-node</th>"
                 "<th>card</th><th>on disk (nodes)</th><th>serving</th></tr>"
                 "</thead><tbody>" + "".join(
                     f"<tr><td>{esc(str(m.get('id')))}</td>"
                     f"<td>{'hybrid' if m.get('hybrid') is True else 'attention' if m.get('hybrid') is False else '—'}</td>"
                     f"<td>{esc(m.get('family') or '—')}</td><td>{esc(m.get('quantization') or '—')}</td>"
                     f"<td>{esc(_dash(m.get('gb')))}</td><td>{esc(_dash(m.get('context') or None))}</td>"
                     f"<td>{tick(m.get('vision'))}</td><td>{tick(m.get('thinking'))}</td>"
                     f"<td>{tick(m.get('multi_node'))}</td>"
                     f"<td>{'added here' if m.get('custom') else 'built in'}</td>"
                     f"<td>{esc(', '.join(m.get('on_disk_nodes') or []) or tick(m.get('on_disk')))}</td>"
                     f"<td>{'serving' if m.get('serving') else ''}</td></tr>"
                     for m in ms) + "</tbody></table>")
    ctl = "<h2>controls</h2><dl>" + "".join(
        f"<dt>{esc(what)}</dt><dd><pre>{esc(cmd)}</pre></dd>"
        for what, cmd in exo_controls(origin)) + "</dl>"
    inner = (f"<dl>{dl}</dl>{notes}{table}{ctl}"
             f'<p>as JSON: <a href="/api/exo">/api/exo</a> (also '
             f'<a href="/console/exo?format=json">?format=json</a>, '
             f'<a href="/console/exo?format=text">?format=text</a>); the '
             f'console: <a href="/console?mode=agent">/console</a></p>')
    return _page("exo", _nav_html(), "exo cluster", inner, "/console/exo?format=json")


def create_console(*, aggregator, wal_path, backend_name="mlx", model="",
                   bind="127.0.0.1:8767", index_stats=None, verify_condition=None,
                   licence_status=None, blob_stats=None, config_dir="~/.faxl",
                   licence_apply=None, licence_file=None, licence_parse=None,
                   prefill_counts=None, backend_stats=None):
    """Build the console Blueprint. Everything is injected; no faxl_proxy import.

    aggregator: a faxl_aggregator.Aggregator
    wal_path: path the aggregator refreshes from (refresh-on-read)
    index_stats: optional () -> dict for the cache screen (used/limit, entries)
    verify_condition: optional () -> str, the backend determinism condition
    blob_stats: optional () -> [{phash, hits, last_used, bytes, pos}], one
                row per cached blob (the blob++ usage data) for /api/blobs
    licence_apply: optional (key) -> (customer, expiry, action), the wheel's
                set_licence. Injected rather than imported so this module still
                imports nothing that loads the model; without it the licence
                page is read-only and POST /api/licence reports that.
    licence_file: optional path the startup path reads, for write-through.
                Injected because the proxy may have seen a FAXL_LICENCE
                override that recomputing the default here would miss.
    licence_parse: optional (key) -> dict, the wheel's parse_licence. When the
                wheel has it, a key is validated and its term checked BEFORE
                anything is installed, so a lapsed key never displaces a
                working entitlement. Absent on older wheels, where apply_key
                falls back to repairing after the fact.
    prefill_counts: optional () -> dict, the exo prefill server's counters
                (faxl_proxy.EXO_COUNTS: requests, hits, stored). When not
                injected, the console reads EXO_COUNTS off the proxy module
                if it is loaded in this process; otherwise the cluster card
                says the counts are not exposed (null), never 0.
    backend_stats: optional () -> dict, whatever the execution engine counts
                (the vLLM connector's restores/saves, say). Shown as-is on
                the engine card (state.engine.stats); null when not injected.
                Generic: the console never interprets the keys.
    """
    bp = Blueprint("faxl_console", __name__)
    _fold_lock = threading.Lock()   # the aggregator fold+read is not thread-safe

    @bp.after_request
    def _keep_explicit_mode(resp):
        # A client that said ?mode=human (or agent) keeps that view as it
        # clicks around. Header/UA-selected modes are left alone: they select
        # themselves again on every request.
        mode = _explicit_mode()
        if (mode and resp.status_code == 200 and not resp.direct_passthrough
                and not resp.is_streamed
                and (resp.mimetype or "") == "text/html"):
            resp.set_data(_carry_mode(resp.get_data(as_text=True), mode))
        return resp
    _cfg = os.path.expanduser(config_dir)

    def _with_fold(fn):
        # Hold the lock across BOTH the refresh-on-read fold AND the read, because
        # the aggregator mutates dicts/deques a concurrent read would iterate
        # (threaded=True). At local scale serializing is free.
        with _fold_lock:
            try:
                aggregator.ingest_file_wal(wal_path)
            except Exception as e:  # noqa: BLE001 — surfaced, never 500 the console
                aggregator.data_bugs.append(f"console refresh: {e}")
            return fn()

    def _tenant():
        return request.args.get("tenant")   # None = unscoped (local single-tenant)

    def _model_scope():
        """Which model's numbers this page is about.

        SCOPE, NOT A FILTER. The page has always CAPTIONED itself with the model
        the proxy is configured for, while the numbers were folded across every
        model the WAL had ever seen. Measured on the live stack: a "first reply,
        median 31 ms / 617 ms" tile, stamped `measured`, computed from TWO rows
        of a 0.5B model and printed over a 316-row run of a vision model that
        emitted no TTFT at all. The caption was right and the number was from
        somewhere else.

        So the default is the running model -- what the caption already claims --
        and `?model=` overrides it. `?model=all` deliberately pools everything,
        for the one page whose job is to compare models.
        """
        want = request.args.get("model")
        if want == "all":
            return None
        return want or (model or None)

    def _caption(scope):
        """What to print as `model` beside numbers folded at `scope`."""
        return scope if scope is not None else "all models"

    def _int_arg(name, default, cap):
        try:
            return min(int(request.args.get(name, str(default))), cap)
        except (TypeError, ValueError):
            return None   # signals a 400

    @bp.route("/api/overview", methods=["GET"])
    def api_overview():
        def build():
            t = _tenant()
            m = _model_scope()
            ov = aggregator.overview(tenant=t, model=m)
            ttft = aggregator.ttft_stats(tenant=t, model=m)
            cache = index_stats() if index_stats else None
            # THE CAPTION NAMES WHERE THE NUMBERS CAME FROM. Passing the
            # configured model while folding a different one is the original
            # defect exactly, and ?model= would have walked straight back into
            # it. "all models" when deliberately pooled, never a single name
            # over a total.
            return jsonify(shape_overview(ov, backend_name, _caption(m), bind,
                                          ttft=ttft, cache=cache,
                                          licence=(licence_status()
                                                   if licence_status else None)))
        return _with_fold(build)

    @bp.route("/api/daily", methods=["GET"])
    def api_daily():
        days = _int_arg("days", 7, 90)
        if days is None:
            return jsonify({"error": {"type": "bad_request",
                                      "message": "days must be an integer"}}), 400
        return _with_fold(lambda: jsonify(
            {"days": aggregator.daily(tenant=_tenant(), days=days,
                                      model=_model_scope())}))

    @bp.route("/api/requests", methods=["GET"])
    def api_requests():
        limit = _int_arg("limit", 50, 500)
        if limit is None:
            return jsonify({"error": {"type": "bad_request",
                                      "message": "limit must be an integer"}}), 400
        return _with_fold(lambda: jsonify(
            {"requests": aggregator.recent(tenant=_tenant(), limit=limit,
                                           model=_model_scope())}))

    @bp.route("/api/requests/<txn_id>", methods=["GET"])
    def api_request_detail(txn_id):
        def build():
            d = aggregator.transaction(txn_id)
            if d is None:
                return jsonify({"error": {"type": "not_found",
                                          "message": f"no transaction {txn_id}"}}), 404
            return jsonify(d)
        return _with_fold(build)

    @bp.route("/api/models/summary", methods=["GET"])
    def api_models_summary():
        """Per-model rollups, plus the all-models total.

        The page a customer looks at is scoped to the model that is running, so
        the work done by every OTHER model they have used would simply vanish --
        and on this machine that is 56 GB of cache and three hundred requests.
        This is where it stays visible: one row per model, and a total that is
        the honest sum rather than a number lifted from whichever model happened
        to be folded last.
        """
        def build():
            t = _tenant()
            rows = aggregator.models(tenant=t)
            total = aggregator.overview(tenant=t)          # every model pooled
            cache = index_stats() if index_stats else None
            return jsonify({"models": rows,
                            "total": {
                                "requests": total["counts"]["requests"]
                                if "counts" in total else total.get("requests"),
                                "hits": total.get("hits"),
                                "tokens_skipped": total.get("tokens_skipped"),
                                "tokens_prefilled": total.get("tokens_prefilled"),
                            },
                            "cache": cache,
                            "running": model})
        return _with_fold(build)

    @bp.route("/api/cache", methods=["GET"])
    def api_cache():
        stats = index_stats() if index_stats else {"available": False}
        return jsonify(stats)

    @bp.route("/api/blobs", methods=["GET"])
    def api_blobs():
        """One row per cached blob: reuse count + last-used time (the blob++
        data), for the recency/frequency scatter. Empty when the backend
        injects no blob_stats."""
        raw = blob_stats() if blob_stats else []
        return jsonify(shape_blobs(raw))

    @bp.route("/api/verify", methods=["POST"])
    def api_verify():
        # Replay is a later phase. Honest-unimplemented: 501, never a fake pass.
        cond = verify_condition() if verify_condition else "unknown"
        return jsonify({"error": {"type": "not_implemented",
                                  "message": "in-proxy verify/replay not in this build"},
                        "determinism_condition": cond}), 501

    # ---- /console (Agent mode HTML + content negotiation; Human HTML is a later
    # commit and currently falls back to the Agent view) ------------------------
    def _overview_payload():
        t = _tenant()
        m = _model_scope()
        ov = aggregator.overview(tenant=t, model=m)
        return shape_overview(ov, backend_name, _caption(m), bind,
                              ttft=aggregator.ttft_stats(tenant=t, model=m),
                              cache=(index_stats() if index_stats else None),
                              licence=(licence_status() if licence_status else None))

    def _welcome_notices():
        """Only things a person should act on. Empty is the good case, and the
        page then shows nothing but the mark and the way in -- a landing page
        that always has a panel trains people to ignore the panel.

        Each notice is {level, title, text, href, action}. level is "alert"
        (something is wrong or nearly wrong) or "setup" (first run).
        """
        out = []

        lic = faxl_licence.as_status(licence_status() if licence_status else None)
        if not (lic and lic.get("licensed")):
            out.append({"level": "setup", "title": "No licence installed.",
                        "text": "Paste the key from your licence email to start.",
                        "href": "/console/licence", "action": "install a key \u2192"})
        else:
            # Always stated, not only when it is nearly up: the countdown left
            # the tiles, and somebody on a 30-day trial should be able to see
            # where they are without going looking. Under 30 days it becomes an
            # alert and says what to do about it.
            days = int(lic.get("days_remaining", 0))
            if days <= 30:
                out.append({"level": "alert",
                            "title": f"Licence expires in {days} days.",
                            "text": "Renew before it lapses, or the cache "
                                    "switches off and every prompt runs cold.",
                            "href": "https://faxl.ai/shop.html",
                            "action": "upgrade \u2192"})
            else:
                out.append({"level": "info",
                            "title": "Licence active.",
                            "text": f"{days} days remaining.",
                            "href": "/console/licence",
                            "action": "see what it covers \u2192"})

        # Never served anything: say how to point a client at it, because the
        # proxy is useless until something talks to it.
        try:
            # aggregator.overview() is FLAT ({"requests": n, ...}); "counts"
            # exists only in shape_overview's payload. Reading ov["counts"]
            # here always gave 0, so this notice showed on a proxy that had
            # served hundreds of requests. Folded first, like /api/overview,
            # or a fresh process reads an aggregator nobody has refreshed yet.
            ov = _with_fold(lambda: aggregator.overview(
                tenant=_tenant(), model=_model_scope()))
            served = int(ov.get("requests", 0) or 0)
        except Exception:  # noqa: BLE001 -- a cold WAL is not an error here
            served = 0
        if not served:
            out.append({"level": "setup", "title": "Nothing served yet.",
                        "text": f"Point a client at http://{bind}/v1 and send a request.",
                        "href": "/console/chat", "action": "try the model \u2192"})

        # A full store evicts on every write, which is a real condition and the
        # one a person can actually do something about.
        try:
            cache = index_stats() if index_stats else None
            used = (cache or {}).get("used_gb")
            cap = (cache or {}).get("limit_gb")
            if used is not None and cap and cap > 0 and used / cap >= 0.95:
                out.append({"level": "alert", "title": "Cache store is nearly full.",
                            "text": f"{used:.1f} of {cap:.0f} GB used; the oldest "
                                    "least-reused blobs are being evicted.",
                            "href": "/console/analytics", "action": "see the store \u2192"})
        except Exception:  # noqa: BLE001 -- stats are advisory here
            pass

        return out

    def _panel_page():
        """The desktop control panel, or None to fall back to the old page.

        faxl_panel is built on its own branch and vendored separately; until it
        lands -- or if it ever fails to render -- a person gets the welcome
        page rather than an error, because the console is how they would find
        out what is wrong. Imported the way this module imports faxl_shell, so
        tools/sync_engine.py rewrites it for the flat nvidia layout.
        """
        try:
            from faxl.engine import faxl_panel
        except ImportError as exc:
            # Never silent. The first live run fell back to the old welcome
            # page with no word of why, which is the console lying by
            # omission. Say what failed and where this module was loaded from,
            # so a half-installed package is visible in /api/diagnostics.
            msg = (f"panel import: {type(exc).__name__}: {exc} "
                   f"(console loaded from {os.path.dirname(os.path.abspath(__file__))})")
            if msg not in aggregator.data_bugs:
                aggregator.data_bugs.append(msg)
            return None
        try:
            body = faxl_panel.render_panel(build_state(panel=True))
        except Exception as exc:  # noqa: BLE001 -- fall back, and say so
            aggregator.data_bugs.append(
                f"panel render: {type(exc).__name__}: {exc}")
            return None
        resp = Response(body, mimetype="text/html")
        # The panel is one self-contained page: inline script and style, the
        # faces and the mark as data: URIs, and fetch to this origin only
        # (/api/*, /v1/*). HUMAN_CSP already says exactly that.
        resp.headers["Content-Security-Policy"] = HUMAN_CSP
        return resp

    @bp.route("/console", methods=["GET"])
    def console_welcome():
        """The console: one page for a person, one state for everyone.

        A person gets the control panel (faxl_panel), rendered from
        build_state(). An agent gets the SAME state as plain HTML with the curl
        for every control; ?format=json is the state itself and ?format=text a
        compact rendering of it. The old welcome page survives only as the
        fallback when the panel module is absent.
        """
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            page = _panel_page()
            if page is not None:
                return page
            return _welcome_human(_welcome_notices())
        state = build_state()
        if mode == "json":
            return jsonify(state)
        if mode == "text":
            return Response(state_text(state, _origin()), mimetype="text/plain")
        return Response(state_agent_html(state, _origin()), mimetype="text/html")

    @bp.route("/console/analytics", methods=["GET"])
    def console_overview():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            # Retired: the panel's left rail and chart are the analytics now.
            return _retired("/console/analytics")
        payload = _with_fold(_overview_payload)
        if mode == "json":
            return jsonify(payload)
        if mode == "text":
            return Response(_overview_text(payload), mimetype="text/plain")
        return Response(_overview_html(payload, backend_name, model, bind),
                        mimetype="text/html")

    @bp.route("/console/requests", methods=["GET"])
    def console_requests():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            # Retired: the log is the panel's centre; one request is its
            # drawer-request, which ?txn= opens.
            return _retired("/console/requests",
                            txn=request.args.get("txn") or None)
        rows = _with_fold(lambda: aggregator.recent(tenant=_tenant(), limit=100))
        if mode == "json":
            return jsonify({"requests": rows})
        if mode == "text":
            # Same columns, same rendering as the agent table; precise
            # values are ?format=json / /api/requests.
            hdr = "\t".join(l for l, _ in _REQUEST_COLUMNS)
            body = "\n".join("\t".join(_request_cells(r)) for r in rows)
            return Response(f"{_NAV}\n\n{hdr}\n{body}\n", mimetype="text/plain")
        if mode == "human":
            return _requests_human(rows)
        return Response(_requests_html(rows), mimetype="text/html")

    def _model_fields():
        return [("model", model), ("backend", backend_name), ("bind", bind)]

    @bp.route("/console/status", methods=["GET"])
    def console_status():
        """What is running: model, backend, bind, uptime, licence.

        This is what the page called "models" always showed -- three rows that
        were never about models. Named for its job, plus the uptime a person
        actually asks for, and the licence countdown so it is not only on the
        page you go to when something is wrong.
        """
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/status")     # the panel's top bar
        fields = _model_fields() + [("uptime", _uptime_str())]
        lic = faxl_licence.as_status(licence_status() if licence_status else None)
        if lic and lic.get("licensed"):
            fields.append(("licence", f"{int(lic.get('days_remaining', 0))} days left"))
        if mode == "json":
            return jsonify({"fields": [{"key": k, "label": k, "value": v}
                                       for k, v in fields],
                            "uptime_s": round(time.time() - _STARTED_AT, 1)})
        if mode == "text":
            return Response(f"{_NAV}\n\n" + "\n".join(f"{k}\t{v}" for k, v in fields)
                            + "\n", mimetype="text/plain")
        if mode == "human":
            return _status_human(fields)
        return Response(_status_html(fields), mimetype="text/html")

    # /console/models now means "choose the model this machine serves" -- the
    # page that was at /console/register. The old paths keep working because
    # links, bookmarks and agent transcripts already point at them.
    @bp.route("/console/register", methods=["GET"])
    def console_register_moved():
        if select_mode(request.args, request.headers) == "human":
            return _retired("/console/register")
        m = _explicit_mode()        # an explicit view survives the redirect
        return redirect("/console/models" + (f"?mode={m}" if m else ""), code=301)

    # ---- MODEL REGISTRATION -------------------------------------------
    # exo ships a curated catalogue. Anything outside it -- a new release, a
    # community quant, a hybrid exo has not carded -- has to be registered
    # before it can be placed, and the only way to do that was a hand-written
    # curl. That is a step the console can own.
    #
    # Registration fetches a model CARD from HuggingFace. It downloads no
    # weights: exo places those on first request.

    def _exo_base():
        # config.json's exo.endpoint; FAXL_EXO_ENDPOINT overrides, as before.
        return faxl_config.exo_settings()["endpoint"]

    # WHICH BACKEND IS BEHIND THIS CONSOLE. Every route below used to ask exo
    # unconditionally, so on mlx -- the shipped backend, model in this process,
    # no exo anywhere -- the models page, the chat status and the status lamp
    # all reported a dead backend while completions were being served. The
    # name is the one the proxy was built with (the same value /api/overview
    # reports), so the pages cannot disagree with each other about it.
    # Asked of the descriptor (faxl_backends), not the name: "_exo" is "the
    # serving backend is a cluster behind faxl" -- the exo probe, the exo
    # catalogue, the cluster card.
    _SERVING = faxl_backends.get(backend_name)
    _exo = _is_cluster(backend_name)
    # The in-process backend a restart comes back on: the one serving when
    # the registry knows it (mlx on a Mac, vllm on Linux), else mlx -- what
    # every non-exo proxy always was.
    _LOCAL = backend_name if (_SERVING and not _exo) else "mlx"
    _NOT_EXO = (f"this uses exo, and this proxy runs the {backend_name} "
                f"backend with the model in its own process")

    def _backend_health():
        """(up, detail, n_models, endpoint) for the CONFIGURED backend.

        exo is a separate service and is probed. Anything else runs inside
        this process, which loads the model before it serves the console: if
        this code is answering, the backend is up and serves the one model it
        was started with. endpoint is None then -- there is no second address.
        """
        if _exo:
            ok, out = _exo_json("/v1/models", timeout=6)
            return (ok, out, len(out.get("data", [])) if ok else 0,
                    _exo_base())
        return True, None, (1 if model else 0), None

    def _local_rows():
        """Model rows for a backend with no catalogue service: what is on
        disk. Size is measured from the directory; everything only exo's
        card knows (context, capabilities, sharding) is None/0 -- unknown."""
        rows = []
        for mid, path in _local_models():
            rows.append({"id": mid, "path": path,
                         "gb": round(_du(path) / 1024.0 ** 3, 1)})
        if model and not any(model in (r["id"], r["path"]) for r in rows):
            rows.insert(0, {"id": model, "path": model,
                            "gb": (round(_du(model) / 1024.0 ** 3, 1)
                                   if os.path.isdir(model) else 0)})
        return rows

    def _running_id(rows):
        """The running model as the list spells it. FAXL_MODEL holds a path
        on this machine while the list shows org/repo; comparing the two raw
        meant the model being served was never marked as serving."""
        for r in rows:
            if model in (r["id"], r["path"]):
                return r["id"]
        return model

    def _exo_json(path, payload=None, timeout=120):
        """Call exo. Returns (ok, parsed_or_error_string)."""
        url = _exo_base().rstrip("/") + path
        data = None
        headers = {"Accept": "application/json"}
        if payload is not None:
            data = json.dumps(payload).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return True, json.loads(r.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")[:300]
            try:
                body = json.loads(body).get("detail", body)
            except Exception:  # noqa: BLE001 — body is not JSON; use it raw
                pass
            return False, f"exo returned {e.code}: {body}"
        except Exception as e:  # noqa: BLE001 — connection refused, timeout
            return False, f"cannot reach exo at {_exo_base()} ({type(e).__name__}: {e})"

    def _exo_catalogue(timeout=15):
        """(True, rows) | (False, error text): exo's catalogue as the console
        shows it -- ids EXACTLY as exo reports them, on_disk from
        /state/downloads (null when exo does not say), and which nodes hold
        each model.

        ONE builder for the models drawer, the picker in /api/state on exo,
        /api/exo and restart's allow-list. The picker used to list HF ids
        derived from ~/.exo/models directory names while restart checked
        exo's /v1/models, so the owner picked 'inclusionAI/Ling-3.0-tiny' and
        was told it was "not one of the models on this machine" (2026-09-21).
        Two catalogues, two spellings; now there is one.
        """
        ok, out = _cached("exo_models", 2.0,
                          lambda: _exo_json("/v1/models", timeout=timeout))
        if not ok:
            return False, out
        dok, dl = _exo_downloads()
        done = _downloads_of(dl)[1] if dok else None
        nodes = _disk_nodes(dl) if dok else {}
        rows = []
        for m in (out.get("data") or []) if isinstance(out, dict) else []:
            if not isinstance(m, dict) or not m.get("id"):
                continue
            caps = m.get("capabilities") or []
            mb = m.get("storage_size_megabytes")
            rows.append({"id": m.get("id"),
                         "on_disk": (None if done is None
                                     else m.get("id") in done),
                         "on_disk_nodes": sorted(nodes.get(m.get("id"), ())),
                         "vision": "vision" in caps,
                         "thinking": "thinking" in caps,
                         "multi_node": bool(m.get("supports_tensor")),
                         "custom": bool(m.get("is_custom")),
                         "gb": round((mb or 0) / 1024.0, 1),
                         "size_bytes": (int(mb * 1024 * 1024)
                                        if isinstance(mb, (int, float)) and mb > 0
                                        else None),
                         "context": m.get("context_length") or 0,
                         "capabilities": caps,
                         "family": m.get("family") or "",
                         "quantization": m.get("quantization") or "",
                         "hybrid": _is_hybrid(m.get("id"), m.get("family")),
                         "shardable": bool(m.get("supports_tensor"))})
        return True, rows

    @bp.route("/api/models/catalogue", methods=["GET"])
    def api_models_catalogue():
        """What the backend can place right now.

        ?source=exo asks exo on EVERY backend: the panel shows the cluster's
        catalogue beside this Mac's models, because the cluster is the backend
        a person switches to for a model this Mac cannot hold.
        """
        want_exo = (request.args.get("source") or "").strip().lower() == "exo"
        if not _exo and not want_exo:
            local = _local_rows()
            out = []
            for r in local:
                v = _fits(r["path"] if os.path.isabs(r["path"]) else r["id"],
                          _LOCAL)
                out.append({"id": r["id"], "gb": r["gb"],
                            "hybrid": _is_hybrid(r["id"], None),
                            "on_disk": True, "size_bytes": v["need_bytes"],
                            "fits": v["ok"], "fit_reason": v["reason"]})
            return jsonify({"ok": True, "running": model,
                            "backend": backend_name, "models": out})
        ok, rows = _exo_catalogue(timeout=15)
        if not ok:
            return jsonify({"ok": False, "exo_running": False,
                            "backend": backend_name, "error": rows}), 502
        mem = _exo_memory()
        for r in rows:
            f = _exo_fit(r["id"], mem, rows)
            r["fits"], r["fit_reason"] = f["ok"], f["reason"]
        serving = _hub_id(model) if _exo else None
        rows.sort(key=lambda r: (r["id"] != serving, r["on_disk"] is not True,
                                 r["hybrid"] is not True, not r["custom"],
                                 str(r["id"]).lower()))
        return jsonify({"ok": True, "exo_running": True,
                        "backend": backend_name, "running": model,
                        "serving": serving, "models": rows})

    @bp.route("/api/models/register", methods=["POST"])
    def api_models_register():
        body = request.get_json(silent=True) or {}
        repo = (body.get("model_id") or request.form.get("model_id") or "").strip()
        if not repo:
            return jsonify({"ok": False, "error": "no model id given"}), 400
        # A HuggingFace repo is org/name. Reject anything else before we hand
        # it to exo, so the error names the real problem.
        if repo.count("/") != 1 or any(c.isspace() for c in repo):
            return jsonify({"ok": False, "error":
                            f"{repo!r} is not a HuggingFace repo id "
                            f"(expected org/name)"}), 400
        if not _exo and not _exo_probe()[0]:
            return jsonify({"ok": False, "applicable": False, "error":
                            f"exo is not running, and the cluster's catalogue "
                            f"is exo's — switch the backend to exo cluster to "
                            f"register {repo} there. For this Mac alone, put "
                            f"the weights on disk (hf download {repo}) and it "
                            f"appears among the models on this Mac"}), 409
        ok, out = _exo_json("/models/add", {"model_id": repo})
        if not ok:
            return jsonify({"ok": False, "error": out}), 502
        return jsonify({"ok": True, "model": {
            "id": out.get("id", repo),
            "gb": round((out.get("storage_size_megabytes") or 0) / 1024.0, 1),
            "shardable": bool(out.get("supports_tensor")),
            "custom": bool(out.get("is_custom")),
            "context": out.get("context_length") or 0,
        }})

    # ---- RESTART -------------------------------------------------------
    # This is the control panel for a proxy running on the user's own Mac, so
    # restarting it from here is the user operating their own machine -- the
    # same act as typing the command, minus the terminal.
    #
    # It is gated on the CALLER being loopback, not on how the proxy is bound.
    # With FAXL_HOST set the console is reachable from the network, and a
    # stranger being able to stop the service is a different thing entirely
    # from the owner clicking a button. Localhost only, no exceptions.
    #
    # The model is not taken from the request. The caller sends an id, and it
    # must already be in the backend's catalogue -- so the only reachable
    # values are ones the backend itself vouches for, and nothing a caller
    # types reaches a shell.

    def _caller_is_local():
        addr = (request.remote_addr or "").strip()
        return addr in ("127.0.0.1", "::1", "localhost")

    @bp.route("/api/restart", methods=["POST"])
    def api_restart():
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "restart is available from this machine only"}), 403
        body = request.get_json(silent=True) or {}
        want = (body.get("model_id") or request.form.get("model_id") or "").strip()

        # Restart the stack that is running. The backend this console was
        # built with and the configured one name the same thing in a running
        # proxy; either one saying exo means exo. See _start_path: ONE
        # launcher, which starts whatever config.json says -- so the choice
        # is written first, and the launcher cannot bring back a different
        # stack than the one asked for.
        exo = _exo or _backend_is_exo()
        launcher = _start_path()
        if not os.path.isfile(launcher):
            return jsonify({"ok": False, "error":
                            f"launcher not found at {launcher} — set "
                            f"FAXL_LAUNCHER"}), 501

        target = want or model
        if want:
            # ALLOW-LIST: the id must be one this machine already has. A value
            # that never came from a catalogue never reaches the launcher, so
            # this cannot become a way to run something else.
            #
            # The two backends have different catalogues, and asking exo on an
            # mlx machine 502s on a connection refused -- which reads as "the
            # backend is broken" when in fact there is no backend to ask.
            #
            # On exo the list is exo's catalogue -- the SAME builder the
            # picker is filled from (_exo_catalogue), ids as exo spells them.
            # The error names the catalogue it checked.
            if exo:
                ok, rows = _exo_catalogue(timeout=15)
                if not ok:
                    return jsonify({"ok": False, "error": rows}), 502
                if want not in {r["id"] for r in rows}:
                    return jsonify({"ok": False, "error":
                                    f"{want!r} is not in exo's catalogue — "
                                    f"add it on the exo page (Add a "
                                    f"HuggingFace model) first"}), 400
            # On mlx the allow-list is the fit rule below: fits_mlx requires
            # the weights on this disk, so anything else is a 409 naming the
            # download, and never reaches the launcher.

        # THE FIT RULE, with or without a model_id: a restart writes the
        # model to config.json like any switch, so it is held to the same
        # rule (see _fits).
        _v, refused = _check("exo" if exo else _LOCAL, target,
                             confirmed=_confirmed(body))
        if refused is not None:
            return refused

        # Stop the backend (if there is a separate one), stop ourselves (by
        # pid, never by pattern), then start again: the launcher will not
        # start while this proxy holds :8767. See _switch.
        stop = _stop_path() if exo else ""
        log, err = _switch("restart", "exo" if exo else _LOCAL, target, stop)
        if err:
            return err
        return jsonify({"ok": True, "model": target, "log": log})

    # ---- DOWNLOAD ------------------------------------------------------
    # Registering a model fetches its CARD, not its weights: exo pulls those
    # on the first request that needs them. That is a sensible default and a
    # poor first experience -- the user registers a 70 GB model, sees it
    # appear in the list, asks it something, and waits half an hour with no
    # indication that a download is what they are waiting for.
    #
    # place_instance is exo's own "put this model on the nodes" command. It
    # returns at once and downloads in the background, so the button starts
    # the work and the page watches /state/downloads.

    def _nodes_of(out):
        """Nodes exo knows: /state/downloads is keyed by node id, one key per
        machine in the cluster -- how the original console counted them."""
        return len(out) if isinstance(out, dict) else None

    def _downloads_of(out):
        """([in-flight download rows], {model ids complete on some node})
        from exo's /state/downloads.

        exo reports one entry per model per node, tagged by state. Every model
        in the catalogue has an entry, so the DownloadPending rows are
        placeholders, not work in flight -- reporting them as downloads would
        put a progress bar against everything.
        """
        def _model_of(body):
            sm = body.get("shardMetadata") or {}
            for v in sm.values():
                if isinstance(v, dict):
                    return (v.get("modelCard") or {}).get("modelId")
            return None

        live, done = {}, set()
        for _node, entries in (out if isinstance(out, dict) else {}).items():
            for entry in entries or []:
                if not isinstance(entry, dict) or not entry:
                    continue
                tag = next(iter(entry))
                body = entry[tag] or {}
                if not isinstance(body, dict):
                    continue
                mid = _model_of(body)
                if not mid:
                    continue
                if tag == "DownloadCompleted":
                    done.add(mid)
                    continue
                if tag == "DownloadPending":
                    continue        # a placeholder, not work in flight
                prog = (body.get("downloadProgress") or body.get("progress")
                        or body.get("data") or {})
                if not isinstance(prog, dict):
                    prog = {}
                tot = float((prog.get("total") or {}).get("inBytes")
                            if isinstance(prog.get("total"), dict)
                            else prog.get("total") or 0)
                got = float((prog.get("downloaded") or {}).get("inBytes")
                            if isinstance(prog.get("downloaded"), dict)
                            else prog.get("downloaded") or 0)
                r = live.setdefault(mid, {"model": mid, "total": 0.0,
                                          "downloaded": 0.0, "speed": 0.0,
                                          "eta_ms": 0, "per_node": []})
                # Each node pulls its own shard: the exo page draws one bar
                # per node, the drawer one per model.
                r["per_node"].append({
                    "node": str(_node), "state": tag,
                    "percent": (round(100.0 * got / tot, 1) if tot else None),
                    "gb": round(tot / 1e9, 1), "gb_done": round(got / 1e9, 1)})
                r["total"] += tot
                r["downloaded"] += got
                r["speed"] += float(prog.get("speed") or 0)
                r["eta_ms"] = max(r["eta_ms"], int(prog.get("eta_ms") or 0))
        for r in live.values():
            r["percent"] = (round(100.0 * r["downloaded"] / r["total"], 1)
                            if r["total"] else 0.0)
            r["gb"] = round(r["total"] / 1e9, 1)
            r["gb_done"] = round(r["downloaded"] / 1e9, 1)
        return list(live.values()), done

    def _disk_nodes(out):
        """{model id: {node ids}} with a DownloadCompleted entry: which
        machines of the cluster hold each model."""
        held = {}
        for node, entries in (out if isinstance(out, dict) else {}).items():
            for entry in entries or []:
                if not isinstance(entry, dict) or len(entry) != 1:
                    continue
                tag, body = next(iter(entry.items()))
                if tag != "DownloadCompleted" or not isinstance(body, dict):
                    continue
                for v in (body.get("shardMetadata") or {}).values():
                    if isinstance(v, dict):
                        mid = (v.get("modelCard") or {}).get("modelId")
                        if mid:
                            held.setdefault(mid, set()).add(str(node))
        return held

    def _on_disk():
        """Model ids whose weights the backend already holds.

        exo reports a DownloadCompleted entry per model per node; a model is
        on disk if any node has one.
        """
        ok, out = _exo_json("/state/downloads", timeout=10)
        if not ok:
            return set()
        return _downloads_of(out)[1]

    @bp.route("/api/models/download", methods=["POST"])
    def api_models_download():
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "downloads start from this machine only"}), 403
        body = request.get_json(silent=True) or {}
        want = (body.get("model_id") or request.form.get("model_id") or "").strip()
        if not want:
            return jsonify({"ok": False, "error": "no model id given"}), 400
        if not _exo:
            # place_instance downloads AND loads the model on exo. With this
            # proxy on mlx nothing is in front of that exo: it would serve
            # with no cache. So the cluster download waits for the switch.
            return jsonify({"ok": False, "applicable": False, "error":
                            f"a cluster download places {want} on exo, and "
                            f"this proxy is serving on this Mac (MLX) — switch "
                            f"the backend to exo cluster first, so faxl is in "
                            f"front of it. For this Mac alone: hf download "
                            f"{want}"}), 409
        ok, cat = _exo_json("/v1/models", timeout=15)
        if not ok:
            return jsonify({"ok": False, "error": cat}), 502
        if want not in {m.get("id") for m in cat.get("data", [])}:
            return jsonify({"ok": False, "error":
                            f"{want!r} is not registered — register it "
                            f"first"}), 400
        if want in _on_disk():
            return jsonify({"ok": True, "model": want, "already": True,
                            "note": "already downloaded — nothing to do"})
        # DO NOT DOWNLOAD WHAT CANNOT RUN (2026-09-22). The owner:
        # "downloading models that cant run is a total waste of time. error
        # with a question for the user to override if it they want." This
        # endpoint had NO fit check at all, so a click could spend an hour
        # fetching 130 GB that would never load. Size it first, say what
        # would happen, and let them override -- the answer is theirs, but
        # they get to hear the question BEFORE the download, not after.
        _v = _fits(want, "exo")
        _too_big = (_v.get("need_bytes") is not None
                    and _v.get("have_bytes") is not None
                    and _v["need_bytes"] > _v["have_bytes"])
        if _too_big and not _confirmed(body):
            return _refuse_fit(_v, want, confirmable=True)
        ok, out = _exo_json("/place_instance", {"model_id": want}, timeout=60)
        if not ok:
            # A gated repo is the common failure and reads as a wall of
            # traceback. Name it, and say what to do.
            low = str(out).lower()
            if "authentication" in low or "401" in low or "gated" in low:
                out = (f"{want} is gated on HuggingFace and needs a token. "
                       f"Run `hf auth login`, or set HF_TOKEN, then restart "
                       f"the backend.")
            return jsonify({"ok": False, "error": out}), 502
        return jsonify({"ok": True, "model": want,
                        "note": "downloading in the background"})

    @bp.route("/api/models/progress", methods=["GET"])
    def api_models_progress():
        """What is downloading, and how far along.

        exo reports one entry per model per node, tagged by state. Every model
        in the catalogue has an entry, so the 121 DownloadPending rows are
        placeholders, not work in flight -- reporting them as downloads would
        put a progress bar against everything. Only in-flight states count,
        and completed ones are surfaced separately so the page can say a model
        is already on disk.
        """
        ok, out = _exo_json("/state/downloads", timeout=10)
        if not ok and not _exo:
            # 200, not a 502 about a service this proxy does not use: nothing
            # is wrong. `applicable` tells the page to stop asking.
            return jsonify({"ok": True, "applicable": False,
                            "exo_running": False,
                            "backend": backend_name, "downloads": [],
                            "on_disk": [r["id"] for r in _local_rows()],
                            "note": "exo is not running; download progress "
                                    "is the cluster's"})
        if not ok:
            return jsonify({"ok": False, "error": out}), 502
        live, done = _downloads_of(out)
        return jsonify({"ok": True, "exo_running": True,
                        "nodes": _nodes_of(out),
                        "downloads": live, "on_disk": sorted(done)})

    # ---- chat (the exo dashboard, framed) --------------------------------
    # "Is the AI actually working?" had no answer on this console. Every other
    # page reports ON inference; this one lets you TRY it.
    #
    # It used to frame exo's own dashboard on :52415 and carried a caveat
    # admitting the flaw: the frame talked to the backend direct, so the cache
    # was not exercised and nothing typed here reached the request feed.
    #
    # EVERYTHING GOES THROUGH THE PROXY, ALWAYS. The proxy is the product --
    # licence gate, ladder, byte-confirm, store, telemetry -- so a chat that
    # routes around it proves only that somebody else's model answers. This
    # posts to /v1/chat/completions on THIS proxy, like any client, and reads
    # back the row the proxy recorded, so the page answers the question a
    # customer actually has: is faxl working, and did it save me anything.
    #
    # It also no longer depends on exo: the mlx backend is the shipped path,
    # and a chat tab that only works on a cluster is a chat tab most customers
    # never see working.

    # ---- about (faxl_panel_about) -------------------------------------
    # Who we are, what to try, how to hire us. The words live in
    # faxl_panel_about so the human page, this agent page and the JSON share
    # one copy. The photos are the only files it reads: fixed names under
    # $FAXL_HOME/about, never a path built from the URL.
    @bp.route("/console/about", methods=["GET"])
    def console_about():
        from faxl.engine import faxl_panel_about as _about
        mode = select_mode(request.args, request.headers)
        photos = _about.photo_state()
        if mode == "json":
            return jsonify(_about.about_payload(photos))
        if mode == "text":
            p = _about.about_payload(photos)
            lines = [_NAV, "", p["company"]["name"] + ", " + p["company"]["place"],
                     p["company"]["about"], ""]
            lines += [f"{x['name']}\t{x['href']}\t{x['line']}" for x in p["products"]]
            lines += ["", "contact\t" + p["contact"]["email"]]
            return Response("\n".join(lines) + "\n", mimetype="text/plain")
        if mode == "human":
            try:
                resp = Response(_about.render_about({"photos": photos}),
                                mimetype="text/html")
                resp.headers["Content-Security-Policy"] = HUMAN_CSP
                return resp
            except Exception as exc:  # noqa: BLE001 -- fall back, and say so
                aggregator.data_bugs.append(
                    f"about render: {type(exc).__name__}: {exc}")
        return Response(
            _page("about", _nav_html(), "about",
                  _about.render_about_agent(photos), "/console/about?format=json"),
            mimetype="text/html")

    @bp.route("/console/about/photo/<int:n>.jpg", methods=["GET"])
    def console_about_photo(n):
        from faxl.engine import faxl_panel_about as _about
        path = _about.photo_path(n)
        try:
            with open(path, "rb") as f:
                data = f.read()
        except (OSError, TypeError):
            return jsonify({"error": f"no photo {n}",
                            "put it at": f"~/.faxl/about/photo-{n}.jpg"}), 404
        resp = Response(data, mimetype="image/jpeg")
        # Long-lived: the page adds ?v=<mtime>, so a replaced photo is a new URL.
        resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        return resp

    @bp.route("/console/apps", methods=["GET"])
    def console_apps():
        """The grid. Three output modes like every other page."""
        mode = select_mode(request.args, request.headers)
        rows = [{"slug": a["slug"], "name": a["name"], "what": a["what"],
                 "url": f"/console/apps/{a['slug']}"} for a in APPS]
        if mode == "json":
            return jsonify({"apps": rows})
        if mode == "text":
            lines = [_NAV, ""]
            for a in rows:
                lines.append(f"{a['slug']}\t{a['name']}\t{a['what']}")
            return Response("\n".join(lines) + "\n", mimetype="text/plain")
        if mode == "human":
            return _apps_human()
        # Each app, the page that documents it, and the call an agent makes
        # instead of pressing the human page's button. A list, so the three
        # survive a text extraction as three items with their links.
        inner = ("<p>Each of these sends a picture to the model running on "
                 "this machine and gives you text back. Nothing is "
                 "uploaded.</p><ul>" + "".join(
            f'<li><a href="{a["url"]}">{html.escape(a["name"])}</a> — '
            f'{html.escape(a["what"])} '
            f'Prompt and call: <a href="{a["url"]}?format=json">'
            f'{a["url"]}?format=json</a>; runs as '
            f'<code>POST /v1/chat/completions</code>.</li>' for a in rows)
            + '</ul><p><a href="/console/apps?format=json">json</a></p>')
        return Response(
            _page("apps", _nav_html("apps"), "apps", inner,
                  "/console/apps?format=json"), mimetype="text/html")

    # Voice2Text's own page (faxl_panel_voice). A fixed route, so it wins over
    # /console/apps/<slug>: the generic picture-app page is never used for it.
    @bp.route("/console/apps/voice2text", methods=["GET"])
    def console_voice2text():
        from faxl.engine import faxl_panel_voice as _pv
        mode = select_mode(request.args, request.headers)
        p = _pv.voice_payload(model, backend_name, _cfg)
        if mode == "json":
            return jsonify(p)
        if mode == "text":
            return Response(_pv.render_voice_text(p, _origin()),
                            mimetype="text/plain")
        if mode == "human":
            try:
                resp = Response(_pv.render_voice(build_state(panel=True)),
                                mimetype="text/html")
                resp.headers["Content-Security-Policy"] = HUMAN_CSP
                return resp
            except Exception as exc:  # noqa: BLE001 -- fall back, and say so
                msg = f"voice2text page: {type(exc).__name__}: {exc}"
                if msg not in aggregator.data_bugs:
                    aggregator.data_bugs.append(msg)
        return Response(
            _page("Voice2Text", _nav_html("apps"), "Voice2Text",
                  _pv.render_voice_agent(p, _origin()),
                  "/console/apps/voice2text?format=json"),
            mimetype="text/html")

    @bp.route("/console/apps/<slug>", methods=["GET"])
    def console_app(slug):
        """One app. The slug is looked up in a fixed registry, never used to
        build a path or a command -- an unknown one is a 404, not an attempt
        to find something."""
        app = APPS_BY_SLUG.get(slug)
        if app is None:
            return jsonify({"error": f"no app {slug!r}",
                            "apps": sorted(APPS_BY_SLUG)}), 404
        mode = select_mode(request.args, request.headers)
        if mode == "json":
            return jsonify({"slug": app["slug"], "name": app["name"],
                            "what": app["what"],
                            "preamble": app["preamble"], "task": app["task"],
                            "endpoint": "/v1/chat/completions",
                            "how": ("POST an OpenAI-compatible body: the "
                                    "preamble as a system message, then a "
                                    "user message whose parts are the task "
                                    "text FIRST and the image_url (a data: "
                                    "URL) second. That is the shape "
                                    "tools/photo-tagger/tag_via_faxl.py uses, "
                                    "which has catalogued several hundred "
                                    "photographs from a real library.")})
        if mode == "text":
            return Response(
                f"{_NAV}\n\n{app['name']}\n{app['what']}\n\n"
                f"POST /v1/chat/completions: preamble as a system message, "
                f"then a user message of [task, image_url] IN THAT ORDER.\n\n"
                f"--- system ---\n{app['preamble']}\n\n"
                f"--- task (before the image) ---\n{app['task']}\n",
                mimetype="text/plain")
        if mode == "human":
            return _app_human(app)
        # The human page is a button and a file picker; this is the same
        # request written out. The preamble is fetched rather than printed --
        # it is long and must be sent byte-identical, or nothing is cached.
        o = _origin()
        me = f"{o}/console/apps/{app['slug']}?format=json"
        call = (
            f"curl -sS '{me}' -o app.json\n"
            "base64 < photo.jpg | tr -d '\\n' > photo.b64\n"
            "# files, not arguments: a photograph is megabytes of base64\n"
            "jq -n --slurpfile a app.json --rawfile b64 photo.b64 \\\n"
            "  '{max_tokens:1024,temperature:0,messages:[\n"
            "     {role:\"system\",content:$a[0].preamble},\n"
            "     {role:\"user\",content:[{type:\"text\",text:$a[0].task},\n"
            "       {type:\"image_url\",image_url:{url:(\"data:image/jpeg;base64,\"+$b64)}}]}]}' \\\n"
            f"  | curl -sS {o}/v1/chat/completions "
            "-H 'Content-Type: application/json' -d @- \\\n"
            "  | jq -r '.choices[0].message.content'")
        inner = (f'<p>{html.escape(app["what"])}</p>'
                 f'<p>POST <code>/v1/chat/completions</code>: the preamble as '
                 f'a system message, then a user message whose parts are the '
                 f'task first and the <code>image_url</code> second.</p>'
                 f'<h2>task</h2><pre>{html.escape(app["task"])}</pre>'
                 f'<h2>call</h2><pre>{html.escape(call)}</pre>')
        if app.get("job") == "cameraroll":
            job = (
                f"curl -sS {o}/api/apps/cameraroll/library            # albums and counts\n"
                f"curl -sS -X POST {o}/api/apps/cameraroll/pick       # opens the Mac's photo picker\n"
                f"curl -sS -X POST {o}/api/apps/cameraroll/start \\\n"
                "  -H 'Content-Type: application/json' \\\n"
                "  -d '{\"count\": 20, \"window\": \"22:00-06:00\", \"write_photos\": false}'\n"
                f"curl -sS {o}/api/apps/cameraroll/status             # progress, results\n"
                f"curl -sS -X POST {o}/api/apps/cameraroll/stop")
            inner += ("<h2>bulk job</h2><p>The human page runs this over the "
                      "Photos library as a background job. Same controls; "
                      "jobs are accepted from this machine only. "
                      "<code>window</code> is optional (HH:MM-HH:MM); "
                      "<code>count</code> is 1\u2013100000.</p>"
                      f"<pre>{html.escape(job)}</pre>")
        inner += (f'<p><a href="/console/apps">all apps</a> · <a href='
                  f'"/console/apps/{app["slug"]}?format=json">json</a></p>')
        return Response(
            _page(app["name"], _nav_html("apps"), app["name"], inner,
                  f"/console/apps/{app['slug']}?format=json"),
            mimetype="text/html")

    @bp.route("/console/chat", methods=["GET"])
    def console_chat():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/chat")       # chat is in the panel
        # Health of the backend that is CONFIGURED -- see _backend_health.
        up, out, models, where = _backend_health()

        if mode == "json":
            return jsonify({"up": up, "endpoint": "/v1/chat/completions",
                            "backend": backend_name,
                            "backend_endpoint": where, "models": models,
                            "error": None if up else out,
                            "proxied": True})
        if mode == "text":
            lines = [_NAV, "", f"backend\t{'up' if up else 'down'}",
                     "post to\t/v1/chat/completions"]
            if up:
                lines.append(f"models\t{models}")
            else:
                lines.append(f"error\t{out}")
            lines.append("proxied\tyes (cached, gated, recorded)")
            return Response("\n".join(lines) + "\n", mimetype="text/plain")
        if mode == "human":
            return _chat_human(up, out, models, None, True, where)
        return Response(_chat_html(up, out, models, where),
                        mimetype="text/html")

    # ---- configure -------------------------------------------------------
    # Every setting here is read at IMPORT time by the engine, so every change
    # needs a restart. The page says so rather than pretending otherwise.

    def _du(path):
        """Bytes on disk under `path`. Walks rather than shelling out to du,
        so the number is the same on every platform."""
        total = 0
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total

    def _config_payload():
        store = faxl_config.store_dir(backend_name)
        env_key = ("FAXL_EXO_STORE" if backend_name == "exo" else "FAXL_BLOBS")
        exists = os.path.isdir(store)
        used = _du(store) if exists else 0
        free = None
        try:
            free = shutil.disk_usage(store if exists
                                     else os.path.dirname(store) or "/").free
        except OSError:
            pass
        return {
            "backend": backend_name,
            "store": {"path": store, "key": faxl_config.store_key(backend_name),
                      "env_var": env_key,
                      "env_override": os.environ.get(env_key),
                      "exists": exists, "used_bytes": used,
                      "free_bytes": free},
            "cap_gb": faxl_config.cap_gb(),
            "cap_env_override": os.environ.get("FAXL_STORE_CAP_GB"),
            "config_file": faxl_config.config_path(),
            # Read-only here: the backend switch lives in the top bar
            # (POST /api/backend/switch), which writes these.
            "config": _config_block(),
            "restart_required": True,
        }

    @bp.route("/console/configure", methods=["GET"])
    def console_configure():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/configure")  # drawer-store
        p = _config_payload()
        if mode == "json":
            return jsonify(p)
        if mode == "text":
            st = p["store"]
            cb, cm = p["config"]["backend"], p["config"]["model"]
            lines = [_NAV, "",
                     f"backend\t{p['backend']}",
                     f"next start\t{cb['value']} (from {cb['source']})",
                     f"model\t{cm['value']} (from {cm['source']})",
                     f"store\t{st['path']}",
                     f"used\t{st['used_bytes'] / 1e9:.2f} GB",
                     f"cap\t{p['cap_gb']:g} GB",
                     f"config\t{p['config_file']}",
                     "",
                     "POST /api/configure {\"store\": \"/path\", "
                     "\"cap_gb\": 60, \"migrate\": true}",
                     "POST /api/backend/switch {\"backend\": \"mlx\"|"
                     "\"exo\", \"model_id\": \"org/name\"} changes the "
                     "backend and model (written to the config file).",
                     "A change needs a proxy restart to take effect."]
            if st["env_override"]:
                lines.insert(6, f"override\t{st['env_var']}={st['env_override']}")
            for c in (cb, cm):
                if c["source"] == "env":
                    lines.append(f"override\t{c['env_var']} is set in the "
                                 f"environment; the console cannot change it")
            return Response("\n".join(lines) + "\n", mimetype="text/plain")
        if mode == "human":
            return _configure_human(p)
        return Response(_configure_agent(p), mimetype="text/html")

    @bp.route("/api/configure", methods=["GET"])
    def api_configure():
        return jsonify(_config_payload())

    def _preflight(dest, src):
        """Everything that can be known BEFORE stopping the proxy.

        A migration that fails halfway has already taken the proxy down and
        may have copied tens of GB. Each check here turns one of those into an
        error message and no downtime at all.
        """
        if not dest:
            return "Give a path."
        dest = os.path.expanduser(dest)
        if not os.path.isabs(dest):
            return f"{dest} is not an absolute path."
        src_r = os.path.realpath(src)
        dest_r = os.path.realpath(dest)
        if dest_r == src_r:
            return "That is already the store location."
        # Copying a directory into itself is an infinite walk; refuse it here
        # rather than discovering it with the proxy stopped.
        if dest_r.startswith(src_r.rstrip("/") + "/"):
            return "The new location cannot be inside the current store."
        parent = dest if os.path.isdir(dest) else os.path.dirname(dest) or "/"
        if not os.path.isdir(parent):
            return f"{parent} does not exist."
        # Writable? Find out now, with a real file.
        try:
            os.makedirs(dest, exist_ok=True)
            probe = os.path.join(dest, ".faxl-write-test")
            with open(probe, "w") as fh:
                fh.write("x")
            os.remove(probe)
        except OSError as exc:
            return f"Cannot write to {dest}: {exc}"
        need = _du(src) if os.path.isdir(src) else 0
        try:
            free = shutil.disk_usage(dest).free
        except OSError as exc:
            return f"Cannot check free space on {dest}: {exc}"
        # 5% headroom: a copy that fills the disk exactly is a copy that fails
        # on the last blob, having already stopped the proxy.
        if need and free < need * 1.05:
            return (f"Not enough room: {need / 1e9:.1f} GB to copy, "
                    f"{free / 1e9:.1f} GB free at {dest}.")
        return None

    def _migration_state_path():
        return _log_path("migrate.json")

    def _start_migration(src, dest):
        """Move the cache, then restart onto it. True, or an error string.

        WHY THIS IS A RESTART AND NOT A COPY. The store is live: blobs are
        written as requests land and evicted when the cap is reached. Copying
        underneath that either misses what arrives mid-copy or catches a blob
        between its write and its rename. So the proxy stops first, exactly as
        a model switch does, and the copy happens in the window where nothing
        is writing.

        THE ORDER IS THE SAFETY. copy -> verify -> write config -> start ->
        delete. The delete is last and runs ONLY when the verify passed; a
        failed verify leaves both copies and changes no setting, so the
        machine comes back exactly as it was.

        Progress goes to a FILE, not to this process: the console is not
        running for most of this.
        """
        # faxl_start.sh, which comes back on the configured backend -- this
        # used to be the exo launcher unconditionally, which on an mlx Mac
        # started exo nobody asked for. The backend/model are NOT rewritten
        # here (only the store key is), so the env is passed through as is.
        launcher = _start_path()
        if not os.path.isfile(launcher):
            return f"launcher not found at {launcher}"
        state = _migration_state_path()
        os.makedirs(os.path.dirname(state), exist_ok=True)
        log = _log_path("migrate.log")

        # Same-filesystem: a rename is instant and atomic, and there is
        # nothing left behind to delete. Most "move it to another folder on
        # this disk" cases land here.
        same_fs = False
        try:
            same_fs = (os.stat(src).st_dev ==
                       os.stat(os.path.dirname(dest.rstrip("/")) or "/").st_dev)
        except OSError:
            pass

        cfg = faxl_config.config_path()
        key = faxl_config.store_key(backend_name)
        helper = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "faxl_migrate.py")
        if not os.path.isfile(helper):
            return f"migration helper not found at {helper}"

        # argv, never a shell string -- the paths are user input.
        script = ('sleep 2\n'
                  '[ -x "$1" ] && bash "$1" >/dev/null 2>&1\n'
                  'kill "$7" 2>/dev/null\n'
                  'for _ in $(seq 1 20); do kill -0 "$7" 2>/dev/null || break; '
                  'sleep 0.5; done\n'
                  '"$2" "$3" "$4" "$5" "$6" "$8" "$9" || exit 1\n'
                  'exec bash "${10}" "${11}"\n')
        env = _launch_env()
        try:
            with open(log, "ab") as fh:
                subprocess.Popen(
                    ["/bin/bash", "-c", script, "migrate",
                     sys.executable, helper, src, dest, cfg,
                     str(os.getpid()), key, "1" if same_fs else "0",
                     _start_path(), model],
                    stdout=fh, stderr=fh, start_new_session=True, env=env)
        except Exception as exc:  # noqa: BLE001 — report, never crash
            return f"{type(exc).__name__}: {exc}"
        return True

    @bp.route("/api/configure/migration", methods=["GET"])
    def api_migration_status():
        """Where the move got to. Written by the helper, which runs while this
        console is down, so this is read from a file rather than from memory."""
        try:
            with open(_migration_state_path()) as fh:
                return jsonify(json.load(fh))
        except FileNotFoundError:
            return jsonify({"phase": "none"})
        except Exception as exc:  # noqa: BLE001
            return jsonify({"phase": "unknown", "error": str(exc)})

    @bp.route("/api/configure", methods=["POST"])
    def api_configure_save():
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "configuration is changed from this machine "
                            "only"}), 403
        body = request.get_json(silent=True) or {}
        updates = {}
        notes = []

        if "cap_gb" in body:
            try:
                cap = float(body["cap_gb"])
            except (TypeError, ValueError):
                return jsonify({"ok": False,
                                "error": "The cap must be a number."}), 400
            if cap <= 0:
                return jsonify({"ok": False,
                                "error": "The cap must be greater than 0."}), 400
            updates["store_cap_gb"] = cap

        dest = (body.get("store") or "").strip()
        migrate = bool(body.get("migrate"))
        src = faxl_config.store_dir(backend_name)
        if dest and os.path.realpath(os.path.expanduser(dest)) != \
                os.path.realpath(src):
            problem = _preflight(dest, src)
            if problem:
                return jsonify({"ok": False, "error": problem}), 400
            dest = os.path.expanduser(dest)
            if migrate:
                started = _start_migration(src, dest)
                if started is not True:
                    return jsonify({"ok": False, "error": started}), 500
                notes.append("Moving the cache in the background.")
            else:
                updates[faxl_config.store_key(backend_name)] = dest
                notes.append("The old cache is still at " + src +
                             " — nothing was copied or deleted.")

        if updates:
            faxl_config.write(updates)
        return jsonify({"ok": True, "saved": updates, "notes": notes,
                        "migrating": bool(dest and migrate),
                        "restart_required": bool(updates)})

    @bp.route("/api/backend/status", methods=["GET"])
    def api_backend_status():
        """Is the execution backend up? Polled by the console's status light.

        exo can die under the console -- a gated model raising an unhandled
        HuggingFaceAuthenticationError has taken the whole process down -- and
        the first a user knew of it was an alert box on their next click. A
        light says it before they click.

        `backend` names what was checked, so the lamp can label itself. On a
        backend that lives in this process there is no exo to probe.
        """
        # `exo` rides along on EVERY backend: on mlx it is the cluster backend
        # the panel offers to switch to, and the lamp needs to know whether it
        # is running without mistaking "off" for "broken".
        if not _exo:
            up, _err, n, _where = _backend_health()
            return jsonify({"ok": True, "up": up, "backend": backend_name,
                            "in_process": True, "endpoint": None,
                            "model": model, "models": n,
                            "exo": _exo_block()})
        ok, out = _exo_json("/v1/models", timeout=6)
        if not ok:
            return jsonify({"ok": False, "up": False, "error": out,
                            "backend": "exo", "endpoint": _exo_base(),
                            "exo": _exo_block(running=False)})
        return jsonify({"ok": True, "up": True, "endpoint": _exo_base(),
                        "backend": "exo",
                        "models": len(out.get("data", [])),
                        "exo": _exo_block(running=True)})

    # ---- THE BACKEND SWITCH ----------------------------------------------
    # faxl runs ONE execution backend per proxy process (FAXL_BACKEND): mlx,
    # the model in this process on this Mac, or exo, the cluster -- many
    # machines running one model, with faxl in front as the front door and
    # its prefill server answering exo's runner for hits (R1) and taking the
    # state back after a cold prefill (R2). Changing backend is therefore a
    # RESTART of this proxy onto the other launcher, never a second service
    # started beside it: an exo with faxl not in front of it has no cache and
    # serves nothing through the product. (2026-09-21: a "start exo beside
    # mlx" button did exactly that, and hid the cluster behind it.)

    # ---- THE FIT RULE --------------------------------------------------
    # "When you click to switch models, it should NOT allow you to configure
    # things that don't fit." Every route that writes a backend or model --
    # /api/backend/switch, /api/backend/power on, /api/restart -- asks
    # _fits() first and answers 409 {error, need_bytes, have_bytes} on a no.
    # The page disables what does not fit, but the page is a convenience:
    # this is the rule. The arithmetic is faxl_config.judge (one place).

    def _exo_memory():
        """{ram_bytes, usable_bytes, nodes} over exo's ONLINE nodes (not
        known to be unreachable -- the exo page's own totals), or None when
        exo is not answering. ram_bytes None: exo does not report memory."""
        def build():
            ok, _rows = _exo_catalogue(timeout=4)
            if not ok:
                return None
            _path, st = _exo_cluster_state()
            dok, dl = _exo_downloads()
            parsed = parse_exo_state(st, dl if dok else None, None,
                                     time.time())
            online = [n for n in parsed["nodes"] if n["reachable"] is not False]
            tot = [n["ram_total"] for n in online if n["ram_total"] is not None]
            ram = int(sum(tot)) if tot else None
            r = faxl_config.fit_ratio()
            return {"ram_bytes": ram,
                    "usable_bytes": int(ram * r) if ram else None,
                    "nodes": len(online)}
        return _cached("exo_memory", 2.0, build)

    def _exo_fit(model_id, mem, rows):
        """judge() for the cluster. need: exo's catalogue size; have: the
        online nodes' RAM x fit_ratio. The shipped default (under the 6 GB
        budget) is the one model allowed while exo cannot be sized -- it is
        what a cluster comes up on, and the only way to START exo from the
        console is to come up on something."""
        hub = _hub_id(model_id)
        row = next((r for r in rows or [] if r.get("id") == hub), None)
        need = (row or {}).get("size_bytes") or faxl_config.shipped_size(hub)
        on_disk = (row or {}).get("on_disk")
        shipped = faxl_config.shipped_size(hub) is not None
        if mem is None:
            v = faxl_config.judge(hub, need, None, "the cluster",
                                  down_reason="exo is not running — start it "
                                              "to size the cluster")
            if shipped:
                v.update(ok=True, reason=None)
        else:
            v = faxl_config.judge(hub, need, mem.get("usable_bytes"),
                                  "the cluster")
            if not v["ok"] and shipped and mem.get("usable_bytes") is None:
                v.update(ok=True, reason=None)
        v["on_disk"] = on_disk
        return v

    def _fits(model_id, backend):
        """{ok, need_bytes, have_bytes, reason, on_disk} -- may `model_id`
        be configured on `backend`?

        mlx: faxl_config.fits_mlx -- bytes on disk of the directory the proxy
        would load vs this Mac's RAM x fit_ratio, and the weights MUST be on
        this Mac: faxl never downloads as a side effect of a switch.
        exo: exo's catalogue size vs the online nodes' RAM x fit_ratio; exo
        not running is a refusal (except the shipped default, see _exo_fit).

        Dispatches on the descriptor's memory_from (faxl_backends), never
        the name. A name the registry does not know is judged as this
        machine's RAM, as every non-exo backend always was. A memory source
        this build cannot measure yet (gpu_vram until step 2) is a refusal
        that says so -- unknown memory is never a yes.
        """
        d = faxl_backends.get(backend) or {}
        src = d.get("memory_from", "host_ram")
        if src == "host_ram":
            return faxl_config.fits_mlx(model_id)
        if src == "gpu_vram":
            # weights (HF snapshot on disk) vs total VRAM x fit_ratio; no
            # nvidia-smi is a refusal. See faxl_config.fits_gpu.
            return faxl_config.fits_gpu(model_id)
        if src != "cluster_ram":
            hub = _hub_id(model_id)
            return faxl_config.judge(
                hub, faxl_config.shipped_size(hub), None,
                d.get("label") or backend,
                down_reason=(f"{d.get('label') or backend} cannot be sized "
                             f"yet ({src} is not measured in this build)"))
        mem = _exo_memory()
        rows = []
        if mem is not None:
            ok, got = _exo_catalogue(timeout=4)
            rows = got if ok else []
        return _exo_fit(model_id, mem, rows)

    def _confirmed(body=None):
        """Did the caller say yes to running something that does not fit?

        A person clicking "run it anyway" in the console; never a default.
        Accepts the JSON body's confirmed flag, and the same as a form field
        so a no-JS page can override too."""
        if body is None:
            body = request.get_json(silent=True) or {}
        raw = body.get("confirmed")
        if raw is None:
            raw = request.form.get("confirmed")
        return str(raw).strip().lower() in ("1", "true", "yes", "on")

    def _check(backend, target, confirmed=False):
        """(verdict, response): the environment first (a switch the env
        would undo is refused naming the variable -- the more useful answer
        when both apply), then the fit rule. response None: go ahead.

        TOO BIG is a question, not a veto (2026-09-22): with confirmed=True
        the caller has been shown what would happen and said yes, and faxl
        proceeds -- it is their Mac. NOT HERE and the other verdicts are not
        confirmable: no amount of clicking makes absent weights present, and
        an MLX build will not load under vLLM whoever insists."""
        refusal = _env_refusal(backend, target)
        if refusal is not None:
            return None, refusal
        v = _fits(target, backend)
        if v["ok"]:
            return v, None
        too_big = (v.get("need_bytes") is not None
                   and v.get("have_bytes") is not None
                   and v["need_bytes"] > v["have_bytes"])
        if too_big and confirmed:
            return dict(v, ok=True, confirmed=True), None
        return v, _refuse_fit(v, target, confirmable=too_big)

    def _refuse_fit(v, model_id, confirmable=True):
        """A 409 that ASKS rather than forbids (2026-09-22).

        The owner: "it's not my decision it's always the user decision."
        faxl says what would happen and offers the override; it does not
        decide what may run on someone's own Mac. The page turns this into a
        confirm dialog and re-POSTs with confirmed:true.

        It stays a 409 when unconfirmed so that a SILENT caller -- a script,
        a stale API client -- cannot start a 130 GB download by accident,
        which is the 2026-09-21 incident. A person clicking through is not
        that caller.

        confirmable=False for a refusal no confirm can fix (a missing model,
        an MLX build under vLLM): asking would be a dialog with no good
        answer."""
        body = {"ok": False, "error": v["reason"], "fits": False,
                "model": model_id, "need_bytes": v["need_bytes"],
                "have_bytes": v["have_bytes"],
                "on_disk": v.get("on_disk"),
                "confirmable": bool(confirmable)}
        if confirmable:
            body["confirm"] = {
                "question": f"Run {_short_model(model_id)} anyway?",
                "detail": (f"{v['reason']}. It will still run, but expect "
                           f"swapping and long pauses -- and on a long "
                           f"session it may stall."),
                "retry_with": {"confirmed": True}}
        return jsonify(body), 409

    def _plan(backend):
        """(model, verdict): what a switch to `backend` comes up on when no
        model is named. The backend's REMEMBERED model (config "models"),
        else DEFAULT_MODEL -- the first that fits. Never the model the other
        backend is running: that carry is the 2026-09-21 incident. Neither
        fits: the remembered one, with its refusal."""
        remembered = faxl_config.model(backend)
        if (faxl_backends.get(backend) or {}).get("models_from") not in (
                None, "local_dirs"):
            # a catalogue backend names models by hub id, never a path
            remembered = _hub_id(remembered)
        # the remembered model first, then the ladder best-first: a rung
        # already on disk beats a refusal about a rung that is not (see
        # faxl_config.default_model_candidates)
        cands = [remembered]
        for dflt in faxl_config.default_model_candidates(backend):
            if _hub_id(dflt) not in {_hub_id(c) for c in cands}:
                cands.append(dflt)
        first = None
        for c in cands:
            v = _fits(c, backend)
            if v["ok"]:
                if first is not None:
                    v = dict(v, note=(
                        f"{_short_model(remembered)} cannot be used "
                        f"({first[1]['reason']}); coming up on "
                        f"{_short_model(c)} instead"))
                return c, v
            if first is None:
                first = (c, v)
        return first

    def _relaunch(tag, stop, target):
        """Answer, stop exo (when a stop script is given), stop THIS proxy by
        pid, then exec faxl_start.sh with the model. Detached, logged to
        power.log. The launcher refuses while :8767 is held -- by this very
        process -- so the self-stop is the step that makes the start work.

        Only ever called by _switch, AFTER the choice is in config.json: the
        launcher reads the backend from the file, and the model argument is
        belt and braces (it writes the same value again).

        argv, never a shell string: the model id is its own argument and
        cannot become a command. `-f`, not `-x`: a stop script unpacked
        without its execute bit is still run with bash, never skipped.
        """
        log = _log_path("power.log")
        os.makedirs(os.path.dirname(log), exist_ok=True)
        script = ('sleep 1\n'
                  '[ -n "$1" ] && [ -f "$1" ] && bash "$1" >/dev/null 2>&1\n'
                  'kill "$4" 2>/dev/null\n'
                  'for _ in $(seq 1 20); do kill -0 "$4" 2>/dev/null || break; '
                  'sleep 0.5; done\n'
                  'exec bash "$2" "$3"\n')
        # EXO_SRC must not be inherited (the launcher would look for its
        # interpreter in …/exo/src/.venv); FAXL_PYTHON is this interpreter;
        # FAXL_BACKEND/FAXL_MODEL are dropped because the config was just
        # written (see _launch_env for why only then).
        env = _launch_env(config_written=True)
        with open(log, "ab") as fh:
            subprocess.Popen(["/bin/bash", "-c", script, tag,
                              stop, _start_path(), target, str(os.getpid())],
                             stdout=fh, stderr=fh, start_new_session=True,
                             env=env)
        return log

    # A TEST HARNESS HAS NO WEIGHTS. The fit check reads this machine's disk,
    # so a suite driving the route with a fixture path would get 409 for every
    # switch. FAXL_SKIP_FIT=1 turns it off for those tests ONLY -- it is not a
    # documented setting and nothing in the product sets it.
    _SKIP_FIT = os.environ.get("FAXL_SKIP_FIT") == "1"
    # The last model fault seen by a switch, so the page can say "it came back
    # but the model will not load" instead of the person discovering it at the
    # first request. Cleared by the next clean switch.
    _LAST_FAULT = {"model": None}

    def _switch(tag, backend, target, stop):
        """The one sequence every backend/model change and restart runs:
        refuse if the environment would undo it (409), write the choice to
        config.json, then _relaunch. -> (log, None) or (None, response).

        The WRITE COMES FIRST, and a failed write stops everything: a proxy
        that kills itself and then starts on whatever the file used to say
        is the exact "restart brought back a different stack" failure this
        replaces.
        """
        refusal = _env_refusal(backend, target)
        if refusal is not None:
            return None, refusal
        # ASK BEFORE KILLING. _relaunch stops THIS process and hands over to
        # the launcher, and the launcher then runs its own fit check -- so a
        # model it refuses leaves the machine with nothing running at all.
        #
        # Measured: the restart button killed a healthy proxy and the launcher
        # refused the replacement with "not on this Mac" for a model that had
        # been serving all day (a stale safetensors index; see
        # faxl_config.weights_complete). The console came back dead and the
        # only evidence was in power.log.
        #
        # Refusing here costs nothing -- the same check, a second earlier, on
        # a machine still serving requests.
        try:
            faxl_config.set_backend(backend, target or None)
        except ValueError:
            return None, (jsonify({
                "ok": False, "error":
                f"{target!r} cannot be saved as the model in "
                f"{faxl_config.config_path()}: expected org/name or an "
                f"absolute path"}), 400)
        except OSError as exc:
            return None, (jsonify({
                "ok": False, "error":
                f"could not write {faxl_config.config_path()}: {exc}"}), 500)
        # A RESTART ALWAYS COMES BACK UP. (AM, 2026-09-22.)
        #
        # This block used to REFUSE the switch when the model did not fit,
        # which was the right instinct and the wrong answer: it was added
        # because the launcher killed the proxy and then exited, leaving
        # nothing running. The launcher no longer does that -- it starts the
        # console with no model and the proxy answers 503 naming the fault --
        # so refusing here only blocks a restart that would now succeed.
        #
        # The fault is still reported, because a console that comes back
        # silently crippled is its own trap: it rides along in the response
        # and the panel shows it. What it does NOT do is stop the restart.
        _want = (target or "").strip() or faxl_config.model(backend)
        _fault = None
        if _want and backend in (_LOCAL, "mlx") and not _SKIP_FIT:
            try:
                _v = faxl_config.fits_mlx(_want)
                if not _v.get("ok"):
                    _fault = (f"{_want} cannot load: "
                              f"{_v.get('reason') or 'it does not fit'}. The "
                              f"console is up; pick a model that fits.")
            except Exception:  # noqa: BLE001 — never block a restart on this
                _fault = None
        try:
            # The contract stays (log, None): four routes read it. The fault,
            # when there is one, is stashed for whichever of them wants to
            # show it -- a restart is never blocked by it.
            _LAST_FAULT["model"] = _fault
            return _relaunch(tag, stop, target), None
        except Exception as exc:  # noqa: BLE001 — report, never crash
            return None, (jsonify({"ok": False, "error":
                                   f"{type(exc).__name__}: {exc}"}), 500)

    def _exo_target(want):
        """(hub id, error) for coming up on exo. No model_id: the model this
        proxy serves, by its hub id. A model_id: any well-formed hub id -- a
        cluster exists to serve a model bigger than this Mac -- and, when exo
        is answering, one its catalogue carries."""
        if not want:
            hub = _hub_id(model)
            if not _HUB_ID_RE.match(hub or ""):
                return None, (f"{model!r} has no HuggingFace id that exo "
                              f"could load — pass model_id (org/name) of a "
                              f"cluster model")
            return hub, None
        hub = _hub_id(want)
        if not _HUB_ID_RE.match(hub or ""):
            return None, (f"{want!r} is not a HuggingFace repo id "
                          f"(expected org/name)")
        ok, cat = _exo_json("/v1/models", timeout=6)
        if ok and hub not in {m.get("id") for m in cat.get("data", [])}:
            return None, (f"{hub} is not in exo's catalogue — register it "
                          f"first")
        return hub, None

    def _go_exo(want):
        can, why = _exo_startable()
        if not can:
            return jsonify({"ok": False, "error": why}), 501
        if want:
            target, err = _exo_target(want)
            if err:
                return jsonify({"ok": False, "error": err}), 400
            _v = {}
        else:
            # Not this proxy's model: the exo backend's own (see _plan).
            target, _v = _plan("exo")
        v, refused = _check("exo", target, confirmed=_confirmed())
        if refused is not None:
            return refused
        v = dict(v, note=_v.get("note"))
        log, err = _switch("power", "exo", target, _stop_path())
        if err:
            return err
        return jsonify({"ok": True, "state": "starting", "backend": "exo",
                        "model": target, "log": log,
                        "need_bytes": v["need_bytes"],
                        "have_bytes": v["have_bytes"],
                        "note": (v.get("note") or
                                 "the proxy restarts onto exo with faxl in "
                                 "front — about a minute; the cache store "
                                 "survives")})

    def _go_local(name, want):
        """An in-process backend (mlx on a Mac, vllm on Linux): validate, the
        fit rule, write config, stop exo if this platform has one, relaunch
        faxl_start.sh -- which starts the proxy with the model inside it."""
        launcher = _start_path()
        if not os.path.isfile(launcher):
            return jsonify({"ok": False, "error":
                            f"launcher not found at {launcher} — set "
                            f"FAXL_LAUNCHER"}), 501
        if want:
            # The allow-list is the fit rule itself: fits_mlx requires the
            # weights on this disk (faxl_config.local_model_dir), so a value
            # that is not a model here is a 409 with the download command,
            # and never reaches the launcher.
            target, _v = want, {}
        else:
            # The mlx backend's own model, never the cluster's (see _plan).
            target, _v = _plan(name)
        v, refused = _check(name, target, confirmed=_confirmed())
        if refused is not None:
            return refused
        v = dict(v, note=_v.get("note"))
        # exo is stopped only where exo exists (a Linux box has none to stop)
        has_cluster = any(_is_cluster(a["name"]) for a in
                          faxl_backends.for_platform(available_only=True))
        stop = (_stop_path() if has_cluster and os.path.isfile(_stop_path())
                else "")
        log, err = _switch("switch", name, target, stop)
        if err:
            return err
        return jsonify({"ok": True, "state": "starting", "backend": name,
                        "model": target, "log": log,
                        "need_bytes": v["need_bytes"],
                        "have_bytes": v["have_bytes"],
                        "note": (v.get("note") or
                                 ("exo stops and " if stop else "") +
                                 "the proxy restarts with the model in its "
                                 "own process")})

    # launcher_branch (faxl_backends) -> the sequence that brings it up. The
    # keys are faxl_start.sh's branch names; a registered backend whose branch
    # is not here is listed but refused with a 501 that says so.
    _GO = {"exo": _go_exo,
           "mlx": lambda want: _go_local("mlx", want),
           "vllm": lambda want: _go_local("vllm", want)}

    @bp.route("/api/backend/switch", methods=["POST"])
    def api_backend_switch():
        """Change the execution backend: {"backend": <a registered,
        available, switchable faxl_backends name -- mlx|exo today>,
        "model_id": optional}. Both: write the backend and model to
        config.json, then exo = the power-on sequence (stop exo, stop this
        proxy, exec faxl_start.sh with the hub id); mlx = run exo_stop.sh,
        stop this proxy, exec faxl_start.sh. 409 when FAXL_BACKEND /
        FAXL_MODEL in this proxy's environment would undo the switch.
        Loopback only."""
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "the backend is switched from this machine "
                            "only"}), 403
        body = request.get_json(silent=True) or {}
        to = str(body.get("backend") or "").strip().lower()
        want = str(body.get("model_id") or "").strip()
        d = faxl_backends.get(to)
        offered = [a["name"] for a in faxl_backends.for_platform(
            available_only=True)
            if a["switchable"] and a["launcher_branch"] in _GO]
        if d is None:
            return jsonify({"ok": False, "error":
                            f"{to or 'backend'!r} is not a backend faxl "
                            f"knows — one of {', '.join(offered) or 'none'}",
                            "backends": offered}), 400
        here = faxl_backends.current_platform()
        if d["available"] and here not in d["platforms"]:
            return jsonify({"ok": False, "error":
                            f"{d['label']} does not run on this platform "
                            f"({here}) — one of "
                            f"{', '.join(offered) or 'none'}",
                            "backends": offered}), 400
        if not d["available"] or not d["switchable"]:
            return jsonify({"ok": False, "error":
                            f"{d['label']} cannot be switched to"
                            + (f" — {d['note']}" if d.get("note") else ""),
                            "backends": offered}), 400
        go = _GO.get(d["launcher_branch"])
        if go is None:
            return jsonify({"ok": False, "error":
                            f"{d['label']}: this build has no switch route "
                            f"for launcher branch {d['launcher_branch']!r}"}), 501
        return go(want)

    @bp.route("/api/backend/power", methods=["POST"])
    def api_backend_power():
        """Turn exo on or off.

        ON brings the STACK up on exo, on any backend: stop exo, stop this
        proxy by pid, exec faxl_start.sh <hub id> on exo -- exo with its own prefix
        cache off, and faxl in front of it. That is the only shape in which
        exo is part of the product; there is no "exo beside mlx".
        OFF runs exo_stop.sh. On the exo backend nothing serves after that.

        Loopback only, like restart: the owner flipping a switch on their own
        Mac is not the same act as a stranger on the network stopping the
        service.
        """
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "power is controlled from this machine only"}), 403
        body = request.get_json(silent=True) or {}
        want = str(body.get("state") or "").strip().lower()
        if want not in ("on", "off"):
            return jsonify({"ok": False, "error": "state must be on or off"}), 400

        stop = _stop_path()
        log = _log_path("power.log")
        os.makedirs(os.path.dirname(log), exist_ok=True)

        if want == "off":
            if not os.path.isfile(stop):
                return jsonify({"ok": False, "error":
                                f"stop script not found at {stop}"}), 501
            try:
                with open(log, "ab") as fh:
                    subprocess.Popen(["/bin/bash", stop], stdout=fh, stderr=fh,
                                     start_new_session=True)
            except Exception as exc:  # noqa: BLE001
                return jsonify({"ok": False, "error": f"{type(exc).__name__}: {exc}"}), 500
            return jsonify({"ok": True, "state": "stopping"})

        # ON = bring the STACK up on exo, with faxl in front: on ANY backend.
        # From mlx this is the switch to the cluster; on exo it brings a dead
        # exo back. body.model_id (optional) comes up on a different model.
        return _go_exo(str(body.get("model_id") or "").strip())

    @bp.route("/api/proxy/power", methods=["POST"])
    def api_proxy_power():
        """Stop or restart the proxy itself.

        Asymmetric with the exo button, and the asymmetry is the whole point:
        this process serves the page holding the button. Stopping it ends the
        console, so nothing in a browser can start it again -- that takes a
        terminal, or launchd. The UI must say so before the click, not after.

        "restart" is therefore the safe verb and the default: the proxy goes
        away and comes back, and the page polls until it answers. "stop" is
        offered because stopping a service you are running is a legitimate
        thing to want, but it is a one-way door from here.
        """
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "the proxy is controlled from this machine only"}), 403
        body = request.get_json(silent=True) or {}
        want = (body.get("action") or "").strip().lower()
        if want not in ("stop", "restart"):
            return jsonify({"ok": False, "error":
                            "action must be stop or restart"}), 400

        log = _log_path("power.log")
        os.makedirs(os.path.dirname(log), exist_ok=True)
        me = str(os.getpid())

        if want == "stop":
            # Answer first, die a moment later: the response has to reach the
            # browser before the socket goes away.
            script = 'sleep 1\nkill "$1" 2>/dev/null\n'
            try:
                with open(log, "ab") as fh:
                    subprocess.Popen(["/bin/bash", "-c", script, "stop", me],
                                     stdout=fh, stderr=fh, start_new_session=True)
            except Exception as exc:  # noqa: BLE001
                return jsonify({"ok": False, "error": f"{type(exc).__name__}: {exc}"}), 500
            return jsonify({"ok": True, "action": "stopping", "final": True,
                            "note": "the console ends with the proxy; start it "
                                    "again from a terminal"})

        # RESTART THE STACK THAT IS RUNNING, NOT A DIFFERENT ONE. On mlx the
        # model lives in this process: there is no exo to stop and none to
        # start, and calling the exo launcher here started one nobody asked
        # for and then died handing it an absolute model path it cannot
        # parse. The console came back dead with the evidence in a log file.
        exo = _exo or _backend_is_exo()
        launcher = _start_path()
        if not os.path.isfile(launcher):
            return jsonify({"ok": False, "error":
                            f"launcher not found at {launcher} — set "
                            f"FAXL_LAUNCHER"}), 501
        # Only the exo shape has something else to stop. "" makes the
        # `[ -f "$1" ]` test fail, so the step is skipped rather than special
        # cased in the script. The launcher refuses while :8767 is held, so
        # this process must be gone before it runs -- see _switch.
        stop = _stop_path() if exo else ""
        log, err = _switch("proxy", "exo" if exo else _LOCAL, model, stop)
        if err:
            return err
        return jsonify({"ok": True, "action": "restarting", "model": model,
                        "backend": "exo" if exo else _LOCAL})

    @bp.route("/console/models", methods=["GET"])
    def console_register():
        """Register a model with the backend, and see what it can already place.

        Deliberately a normal HTML form with a small progressive-enhancement
        script: the console is served to agents and curl as well as browsers,
        so the page must say what it does without running any JavaScript.
        """
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/models")     # drawer-models
        rows = []
        err = None
        running = model
        if not _exo:
            # No catalogue service: list what is on disk. None = unknown, for
            # the columns only exo's model card can answer.
            ok, out, disk = True, {}, set()
            local = _local_rows()
            running = _running_id(local)
            for r in local:
                rows.append((r["id"], False, r["gb"], None,
                             _is_hybrid(r["id"], None), "", "", None, None,
                             True))
            rows.sort(key=lambda r: (r[0] != running, r[4] is not True,
                                     r[0].lower()))
        else:
            ok, out = _exo_json("/v1/models", timeout=15)
            disk = _on_disk()
        if ok and _exo:
            for m in out.get("data", []):
                mid = m.get("id", "")
                rows.append((mid, bool(m.get("is_custom")),
                             round((m.get("storage_size_megabytes") or 0) / 1024.0, 1),
                             bool(m.get("supports_tensor")),
                             _is_hybrid(mid, m.get("family")),
                             m.get("family") or "", m.get("quantization") or "",
                             m.get("context_length") or 0,
                             m.get("capabilities") or [],
                             mid in disk))
            # THE RUNNING MODEL FIRST. It was highlighted but left in
            # alphabetical position, which on a 123-row table put it hundreds
            # of rows down -- a highlight nobody scrolls far enough to see is
            # not a highlight. Then models already on disk, because those are
            # the ones that can be switched to without a download. Then
            # hybrids, which are what this cache exists for.
            rows.sort(key=lambda r: (r[0] != model, not r[9],
                                     r[4] is not True, not r[1], r[0].lower()))
        elif not ok:
            err = out
        if mode == "json":
            return jsonify({"ok": ok, "error": err, "running": model,
                            "backend": backend_name,
                            "models": [{"id": i, "custom": c, "gb": g,
                                        "shardable": sh, "hybrid": hyb,
                                        "family": fam, "quantization": q,
                                        "context": ctx, "capabilities": caps,
                                        "on_disk": have}
                                       for i, c, g, sh, hyb, fam, q, ctx, caps,
                                       have in rows]})
        if mode == "text":
            body = [f"running\t{model}", f"backend\t{backend_name}"]
            if _exo:    # registering a card is exo's; do not advertise it on mlx
                body.append("register\tPOST /api/models/register  "
                            "{\"model_id\": \"org/name\"}")
            if err:
                body.append(f"error\t{err}")
            for i, c, g, sh, hyb, fam, q, ctx, caps, have in rows:
                arch = ("hybrid" if hyb is True
                        else "unknown" if hyb is None else "attention")
                body.append(f"{arch}\t{i}\t{g} GB\t{q or '-'}"
                            + (f"\t{ctx // 1024}k" if ctx else "")
                            + ("\tmulti-node" if sh else "")
                            + ("\tregistered-here" if c else "")
                            + ("\ton-disk" if have else ""))
            return Response(f"{_NAV}\n\n" + "\n".join(body) + "\n",
                            mimetype="text/plain")
        if mode == "human":
            return _human_register(running, rows, err, backend=backend_name)
        return Response(_register_html(running, rows, err,
                                       backend=backend_name),
                        mimetype="text/html")

    @bp.route("/console/verify", methods=["GET"])
    def console_verify():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/verify")     # drawer-verify
        cond = verify_condition() if verify_condition else "unknown"
        # The condition arrives prefixed with whichever backend the proxy was
        # built against -- it said "mlx:" on a box running exo. The backend is
        # injected; use it rather than trusting a string's prefix.
        if cond and ":" in cond and backend_name:
            head, _, tail = cond.partition(":")
            if head.strip().lower() != backend_name.strip().lower():
                cond = f"{backend_name}:{tail}"
        status = "press a button below"
        if mode == "json":
            return jsonify({"status": "on_demand", "determinism_condition": cond,
                            "implemented": True, "runs_in": "browser",
                            "model": model, "endpoint": f"http://{bind}/v1"})
        if mode == "text":
            return Response(f"{_NAV}\n\n" + _verify_text(cond, model, bind),
                            mimetype="text/plain")
        if mode == "human":
            return _verify_human(status, cond, model=model, bind=bind)
        return Response(_verify_html(status, cond, model, bind),
                        mimetype="text/html")

    # ---- licence (T-0004) ----------------------------------------------------
    def _lic_path():
        return licence_file or faxl_licence.licence_path()

    def _lic_payload():
        status = licence_status() if licence_status else None
        stored = faxl_licence.read_key(_lic_path())
        # The grant is decoded from the STORED SIGNED BYTES, never from anything
        # this console kept separately -- so what is displayed is what was
        # signed. An unreadable file simply yields no grant.
        info = None
        if stored and licence_parse is not None:
            try:
                info = licence_parse(stored)
            except ValueError:
                # A stored key that no longer parses is a real condition (an
                # edited file); report no grant rather than a partial one.
                stored = ""
        grant = faxl_licence.grant(stored, status, info) if stored else None
        return shape_licence(status, grant, stored_path=_lic_path() if stored else None)

    @bp.route("/api/licence", methods=["GET"])
    def api_licence():
        return jsonify(_lic_payload())

    @bp.route("/api/licence", methods=["POST"])
    def api_licence_set():
        if licence_apply is None:
            return jsonify({"error": {
                "type": "unavailable",
                "message": "This build cannot install a key from the console "
                           "(the licence core is not loaded)."}}), 501
        body = request.get_json(silent=True) or {}
        raw = body.get("key")
        if raw is None:
            raw = request.form.get("key", "")
        ok, result = faxl_licence.apply_key(
            raw, licence_apply, licence_status, path=_lic_path(),
            parse_licence=licence_parse)
        if not ok:
            banner = banner_for(result["error"])
            # 200 for expiry: the request was understood and the key is real.
            # 400 only for a key that cannot be used at all.
            code = 200 if banner["type"] == "expired" else 400
            return jsonify({"ok": False, "banner": banner}), code
        out = {"ok": True, "licence": _lic_payload()}
        if result.get("warning"):
            out["warning"] = result["warning"]
        return jsonify(out)

    @bp.route("/console/licence", methods=["GET"])
    def console_licence():
        mode = select_mode(request.args, request.headers)
        if mode == "human":
            return _retired("/console/licence")    # drawer-licence
        payload = _lic_payload()
        if mode == "json":
            return jsonify(payload)
        if mode == "text":
            rows = _licence_rows(payload.get("grant") or {})
            if not rows:
                body = ("status\tno licence installed\n"
                        "effect\tcache tier off; every prefill runs cold")
            else:
                body = "\n".join(f"{k}\t{v}" + (f"\t({n})" if n else "")
                                 for k, v, n in rows)
            return Response(f"{_NAV}\n\n{body}\n", mimetype="text/plain")
        if mode == "human":
            return _licence_human(payload)
        return Response(_licence_html(payload), mimetype="text/html")

    # ---- THE CAMERA-ROLL JOB -------------------------------------------
    # AM: "people dont need help uploading photos, they need help automating
    # workflows." The tagger has always been able to run over thousands of
    # photographs; until now it could only be started from a terminal, which
    # is the one thing the customer this is built for will not open. The APPS
    # entry has carried `"job": "cameraroll"` since it was written and nothing
    # ever read it. These three routes are what read it.
    #
    # A JOB, NOT A REQUEST. It outlives this console (start_new_session=True,
    # so a proxy restart does not kill it), writes its own status file, and is
    # stopped by a signal rather than by closing a browser tab. The console
    # only starts it, reports it and stops it.

    def _job_status_path():
        from faxl.engine.apps import cameraroll
        return os.path.join(cameraroll.job_dir(), "status.json")

    def _job_read_status():
        try:
            with open(_job_status_path()) as fh:
                return json.load(fh)
        except FileNotFoundError:
            return {"state": "none"}
        except Exception as exc:  # noqa: BLE001
            return {"state": "unknown", "error": str(exc)}

    def _job_running(st):
        """Is the pid in the status file actually alive?

        A status of "running" is only a claim: a job killed with SIGKILL, or
        lost to a reboot, never gets to write "stopped" and the page would
        show it running forever with a Stop button that does nothing. Signal 0
        asks the kernel instead of trusting the file.
        """
        if st.get("state") not in ("running", "waiting"):
            return False
        pid = st.get("pid")
        if not pid:
            return False
        try:
            os.kill(int(pid), 0)
            return True
        except (OSError, ValueError, TypeError):
            return False

    @bp.route("/api/apps/cameraroll/start", methods=["POST"])
    def api_cameraroll_start():
        """Start the tagging job.

        EVERY VALUE IS BOUNDED OR REFUSED. count and batch are cast to int,
        the window is parsed by the job's own parser (which refuses anything
        that is not HH:MM-HH:MM), and write_photos is a boolean. argv, never a
        shell string -- and nothing here reaches a shell at all.
        """
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "jobs are started from this machine only"}), 403
        st = _job_read_status()
        if _job_running(st):
            return jsonify({"ok": False, "error":
                            "a tagging job is already running",
                            "status": st}), 409

        body = request.get_json(silent=True) or {}
        try:
            count = int(body.get("count", 20))
        except (TypeError, ValueError):
            return jsonify({"ok": False,
                            "error": "count must be a number"}), 400
        if count < 1 or count > 100000:
            return jsonify({"ok": False, "error":
                            "count must be between 1 and 100,000"}), 400
        window = (body.get("window") or "").strip()
        if window:
            from faxl.engine.apps import cameraroll
            try:
                cameraroll.parse_window(window)
            except ValueError as exc:
                return jsonify({"ok": False, "error": str(exc)}), 400
        write_photos = bool(body.get("write_photos"))

        # THE LIBRARY MUST BE READABLE BEFORE WE START, or the job dies on its
        # first batch and the page shows "failed" with no cause. macOS blocks
        # this until Full Disk Access is granted, and the message says so.
        from faxl.engine.apps import cameraroll
        ok, detail = cameraroll.check_access()
        if not ok:
            return jsonify({"ok": False, "error": detail}), 400

        log = _log_path("cameraroll.log")
        cmd = [sys.executable, "-m", "faxl.engine.apps.cameraroll",
               "--count", str(count),
               "--endpoint", f"http://127.0.0.1:{os.environ.get('FAXL_PORT', '8767')}"]
        if window:
            cmd += ["--window", window]
        if write_photos:
            cmd.append("--write-photos")
        try:
            with open(log, "ab") as fh:
                proc = subprocess.Popen(cmd, stdout=fh, stderr=fh,
                                        start_new_session=True,
                                        env=_launch_env())
        except Exception as exc:  # noqa: BLE001 — report, never crash
            return jsonify({"ok": False,
                            "error": f"{type(exc).__name__}: {exc}"}), 500
        return jsonify({"ok": True, "pid": proc.pid, "count": count,
                        "window": window or None,
                        "write_photos": write_photos, "log": log})

    @bp.route("/api/apps/cameraroll/status", methods=["GET"])
    def api_cameraroll_status():
        """Where the job has got to, and the captions so far.

        Read from FILES, not from memory: the job is a separate process and
        outlives this console, so nothing about it is in scope here. The
        recent rows come from the same append-per-photo JSONL the job uses as
        its resume point, so the page can be opened mid-run and show real work.
        """
        from faxl.engine.apps import cameraroll
        st = _job_read_status()
        st["running"] = _job_running(st)
        if st.get("state") in ("running", "waiting") and not st["running"]:
            # The pid is gone without a final status: say so rather than
            # showing a Stop button that cannot work.
            st["state"] = "interrupted"
        out = os.path.join(cameraroll.job_dir(), "catalogue.jsonl")
        rows, total = [], 0
        try:
            with open(out) as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    total += 1
                    try:
                        rows.append(json.loads(line))
                    except ValueError:
                        continue      # a torn final line; the next write fixes it
        except FileNotFoundError:
            pass
        st["catalogued"] = total
        # PROGRESS PER PHOTOGRAPH, NOT PER BATCH.
        #
        # status.json is written by the job BETWEEN batches, so `tagged` sits
        # at 0 for the several minutes a 20-photo batch takes and the panel
        # looks frozen -- the complaint that prompted this. The JSONL is
        # appended and fsynced as EACH photograph completes
        # (tag_via_faxl.record), so the row count is the live figure.
        #
        # `started` is the job's own start time, so rows written after it are
        # this run's. That is exact for a fresh run and safe for a resumed one:
        # the earlier rows are older than `started` and are not counted twice.
        t0 = float(st.get("started") or 0)
        # NEVER MORE THAN THE TARGET. Rows are attributed to this run by
        # timestamp, and a previous job's last photograph can land AFTER this
        # one started -- its model call was already in flight. Measured: a
        # target of 3 reporting "4 of 3 done", which reads as a bug in the
        # counting rather than as two jobs overlapping. The job's own `tagged`
        # is the authority on its total; this only makes progress visible
        # BETWEEN its batch writes, so it is capped by it.
        _mine = sum(1 for r in rows if float(r.get("ts") or 0) >= t0) if t0 else total
        _target = int(st.get("target") or 0)
        st["done_this_run"] = min(_mine, _target) if _target else _mine
        # Newest first, and only a handful: this is a progress view, not an
        # export. The JSONL is the record.
        # EVERY FIELD THE PAGE DRAWS. `preview` was missing here while the
        # rows on disk carried it, so the pipeline, the filmstrip and the
        # large panel all rendered empty frames from a feed that reported
        # None -- with the preview route answering 200 to curl the whole
        # time. `secs` and `ttft_ms` are what the per-photo readout shows.
        st["recent"] = [{"photo": r.get("photo"),
                         "preview": r.get("preview"),
                         "uuid": r.get("uuid"),
                         "catalogue": r.get("catalogue"),
                         "served": r.get("served"),
                         "outcome": r.get("outcome"),
                         "secs": r.get("secs"),
                         "ttft_ms": r.get("ttft_ms"),
                         "ts": r.get("ts"),
                         "photos_write": r.get("photos_write"),
                         "error": r.get("error")}
                        for r in rows[-24:][::-1]]
        st["out"] = out

        # WHICH PHOTOGRAPH IS IN FRONT OF THE MODEL RIGHT NOW.
        #
        # The catalogue row is only written when the model answers, ~17s
        # later, so rows alone can say "photo N finished" and never "photo
        # N+1 started". The tagger publishes this immediately before it sends
        # a picture, which is what gives the page a real QUEUED -> ANALYSING
        # transition and the actual image to put on screen -- inferred from
        # the work, not invented by the UI.
        st["current"] = None
        if st.get("running"):
            try:
                from faxl.engine.apps import tag_via_faxl as _tvf
                with open(_tvf.current_path()) as fh:
                    cur = json.load(fh)
                # Only if it is THIS run's, and not already finished: a stale
                # marker from a previous job would pin the wrong photograph
                # on screen for ever.
                if float(cur.get("started_at") or 0) >= float(
                        st.get("started") or 0):
                    if not any(r.get("uuid") and r.get("uuid") == cur.get("uuid")
                               and float(r.get("ts") or 0)
                               >= float(cur.get("started_at") or 0)
                               for r in rows[-4:]):
                        st["current"] = cur
            except (OSError, ValueError):
                pass

        # WHAT THE CACHE SAVED THIS RUN, from the rows themselves. Real
        # figures only: `served` is what the ladder resumed, `outcome` is the
        # proxy's own verdict, `secs` and `ttft_ms` are measured. Nothing here
        # is modelled or estimated.
        mine = [r for r in rows if float(r.get("ts") or 0) >= t0] if t0 else rows
        done = [r for r in mine if not r.get("error")]
        st["cache"] = {
            "hits": sum(1 for r in done if r.get("outcome") == "HIT"),
            "photos": len(done),
            "tokens_reused": sum(int(r.get("served") or 0) for r in done),
            "tokens_paid": sum(max(int(r.get("prompt_tokens") or 0)
                                   - int(r.get("served") or 0), 0)
                               for r in done),
            "secs_mean": (round(sum(float(r.get("secs") or 0) for r in done)
                                / len(done), 1) if done else None),
            "ttft_ms_best": (min([float(r["ttft_ms"]) for r in done
                                  if r.get("ttft_ms")], default=None)),
        }
        return jsonify(st)

    def _photo_app():
        """The .app the PhotoKit helper runs inside, built on demand.

        IT HAS TO BE A BUNDLE. macOS attributes a photo-library request to the
        RESPONSIBLE process, so a helper exec'd straight from this proxy would
        make the prompt say "Python wants to access your photos" and grant
        access to everything that interpreter ever runs. And a bundle without
        NSPhotoLibraryUsageDescription is TERMINATED by TCC rather than
        prompted, which presents as a crash.

        Built here rather than shipped ready-made because it must point at
        the interpreter faxl is actually running under, which is only known
        on the machine. The script is idempotent.
        """
        import shutil as _sh
        app = os.path.expanduser("~/.faxl/faxl-photos.app")
        builder = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "build_photo_helper.sh")
        if os.path.isdir(app):
            return app, None
        if not os.path.isfile(builder):
            return None, "the photo helper is not installed in this build"
        env = _launch_env()
        env["FAXL_PYTHON"] = sys.executable
        try:
            r = subprocess.run(["/bin/bash", builder, app], env=env,
                               capture_output=True, text=True, timeout=120)
        except Exception as exc:  # noqa: BLE001
            return None, f"{type(exc).__name__}: {exc}"
        if r.returncode != 0 or not os.path.isdir(app):
            return None, (r.stderr or r.stdout or "could not build the "
                          "photo helper").strip()[:300]
        return app, None

    def _run_helper(args, timeout=300):
        """Run the helper as the BUNDLE and hand back what it wrote.

        `open -W -a` rather than exec: LaunchServices is what gives the bundle
        its own TCC identity, so the prompt names faxl and the grant covers
        faxl alone.
        """
        app, err = _photo_app()
        if err:
            return None, err
        try:
            subprocess.run(["/usr/bin/open", "-W", "-a", app, "--args"] + args,
                           capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return None, "the Photos helper did not finish in time"
        except Exception as exc:  # noqa: BLE001
            return None, f"{type(exc).__name__}: {exc}"
        return True, None

    @bp.route("/api/apps/cameraroll/library", methods=["GET"])
    def api_cameraroll_library():
        """How many photographs faxl can see, and under what permission.

        NEVER ASKS. This runs on page load, and a permission dialog nobody
        pressed a button for is the behaviour customers hate -- the helper's
        `status` reads the current grant without requesting one. "limited"
        means the user picked a set; "authorized" means they shared the lot.
        """
        from faxl.engine.apps import tag_via_faxl
        out = os.path.join(tag_via_faxl.preview_dir(), "..", "library.json")
        out = os.path.abspath(out)
        ok, err = _run_helper(["status", "--out", out], timeout=60)
        if err:
            return jsonify({"ok": False, "error": err})
        try:
            with open(out) as fh:
                d = json.load(fh)
        except (OSError, ValueError) as exc:
            return jsonify({"ok": False, "error": str(exc)})
        return jsonify({"ok": True, "status": d.get("name"),
                        "photos": d.get("visible"),
                        # A selection made earlier survives a restart: the
                        # page should offer to reuse it rather than make the
                        # customer pick again.
                        "selected": _selection_count()})

    def _selection_path():
        from faxl.engine.apps import tag_via_faxl
        return os.path.join(os.path.dirname(tag_via_faxl.current_path()),
                            "selection.json")

    def _selection_count():
        try:
            with open(_selection_path()) as fh:
                return len(json.load(fh).get("ids") or [])
        except (OSError, ValueError):
            return 0

    @bp.route("/api/apps/cameraroll/pick", methods=["POST"])
    def api_cameraroll_pick():
        """Show the system picker; remember what was chosen.

        THE PICKER IS THE PERMISSION. What the customer selects here is what
        faxl can read, and nothing else in the library is reachable -- which
        is the whole reason this exists instead of asking for Full Disk
        Access, a grant that covers Mail, Messages and every backup on the
        machine.

        Blocking, deliberately: a person is looking at a window, and the page
        has nothing useful to do until they finish. The timeout is generous
        because choosing photographs is not a fast operation.
        """
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "photos are chosen on this machine only"}), 403
        st = _job_read_status()
        if _job_running(st):
            return jsonify({"ok": False, "error":
                            "stop the running job before choosing new "
                            "photographs"}), 409
        path = _selection_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        ok, err = _run_helper(["pick", "--out", path], timeout=900)
        if err:
            return jsonify({"ok": False, "error": err}), 500
        try:
            with open(path) as fh:
                sel = json.load(fh)
        except (OSError, ValueError) as exc:
            return jsonify({"ok": False, "error": f"no selection: {exc}"}), 500
        if not sel.get("ok"):
            return jsonify({"ok": False,
                            "error": sel.get("error") or "nothing chosen"}), 400
        return jsonify({"ok": True, "picked": sel.get("picked"),
                        "status": sel.get("status")})

    @bp.route("/api/apps/cameraroll/preview/<name>", methods=["GET"])
    def api_cameraroll_preview(name):
        """One photograph's preview, for the pipeline, the filmstrip and the
        large current-photo panel.

        THE NAME IS NOT A PATH. It is checked against the exact shape the
        tagger writes -- a UUID and a .jpg suffix -- and then joined to the
        preview directory, so there is nothing a caller can send that escapes
        it. send_from_directory would refuse a traversal anyway; refusing it
        here means an odd name is a 404 rather than a lookup.

        ONE SIZE, SCALED BY THE BROWSER. These are ~800px on the longest edge:
        sharp for the big panel on a Retina display, and the filmstrip uses
        the same file at 64px rather than a second physical thumbnail.
        """
        from faxl.engine.apps import cameraroll  # noqa: F401  (path only)
        from faxl.engine.apps import tag_via_faxl
        if not re.fullmatch(r"[0-9A-Fa-f-]{36}\.jpg", name or ""):
            return jsonify({"error": "not a preview name"}), 404
        path = os.path.join(tag_via_faxl.preview_dir(), name)
        if not os.path.isfile(path):
            return jsonify({"error": "no such preview"}), 404
        resp = send_file(path, mimetype="image/jpeg", conditional=True)
        # A preview never changes once written (it is named by content
        # identity), so let the browser keep it for the session -- the
        # filmstrip re-renders on every poll and would otherwise refetch
        # every thumbnail twice a second.
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    @bp.route("/api/apps/cameraroll/stop", methods=["POST"])
    def api_cameraroll_stop():
        """Ask the job to stop at the end of the batch it is in.

        SIGTERM, NOT SIGKILL. cameraroll installs a handler and finishes the
        batch in hand (~2 minutes) before exiting: killing mid-batch leaves a
        half-fetched staging directory and a photograph tagged but not
        recorded. The JSONL is appended per photograph, so nothing already
        done is ever lost either way -- this is about not leaving mess.
        """
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "jobs are stopped from this machine only"}), 403
        st = _job_read_status()
        if not _job_running(st):
            return jsonify({"ok": False, "error": "no job is running",
                            "status": st}), 409
        try:
            os.kill(int(st["pid"]), signal.SIGTERM)
        except (OSError, ValueError, TypeError) as exc:
            return jsonify({"ok": False,
                            "error": f"could not signal the job: {exc}"}), 500
        return jsonify({"ok": True, "stopping": st.get("pid"),
                        "note": "the job finishes the batch it is in, "
                                "then exits"})

    @bp.route("/api/diagnostics", methods=["GET"])
    def api_diagnostics():
        h = _with_fold(lambda: aggregator.health())
        return jsonify({
            "aggregator": h,
            "wal_path": wal_path,
            "unit_vocab": {u: {"arity": a, "base": b}
                           for u, (a, b) in UNIT_VOCAB.items()},
            "reserved_units": sorted(RESERVED_UNITS),
            "unknown_units_seen": sorted(UNKNOWN_UNITS_SEEN),  # no silent degrade
            "backend": backend_name, "model": model, "bind": bind,
        })

    # ---- /api/state ------------------------------------------------------
    # ONE function gathers every fact the panel shows, from the sources the
    # old routes each read separately. Each source is tried on its own: a
    # source that fails leaves its fields null and adds an "error" notice
    # naming it. The state route must never 500 -- it is what tells a person
    # something is wrong, so it cannot be the thing that breaks.

    _slow = {}    # key -> (expires_at, value): directory walks, not per poll

    def _cached(key, ttl, fn):
        hit = _slow.get(key)
        now = time.time()
        if hit and hit[0] > now:
            return hit[1]
        val = fn()
        _slow[key] = (now + ttl, val)
        return val

    def _exo_probe(timeout=1.5):
        """(running, detail). A refused connection answers at once, so the
        short timeout only bounds a hung exo, not the normal off case."""
        ok, out = _exo_json("/v1/models", timeout=timeout)
        return ok, out

    def _exo_nodes(running):
        """Node count from /state/downloads (one key per machine), or None
        when exo is not answering or does not say."""
        if not running:
            return None
        ok, out = _exo_downloads()
        return _nodes_of(out) if ok else None

    def _exo_downloads():
        """/state/downloads, shared by the node count and the cluster card
        within one poll: one call to exo per state build, not two."""
        return _cached("exo_downloads", 2.0,
                       lambda: _exo_json("/state/downloads", timeout=2))

    def _exo_block(running=None):
        if running is None:
            running, _ = _exo_probe()
        can, why = _exo_startable()
        # can_start: would power-on / switch-to-exo work. On the exo backend
        # with exo answering there is nothing to start. On mlx a running exo
        # does not block it: the sequence stops that exo first.
        return {"running": bool(running), "endpoint": _exo_base(),
                "can_start": bool(can and not (running and _exo)),
                "note": (None if can else why),
                "nodes": _exo_nodes(running)}

    def _live_local(d, exo_block):
        """The live bits of an in-process backend whose models are
        directories on this disk (models_from "local_dirs"): it needs the
        solo launcher and -- the fit rule -- a model that is on this disk and
        fits this machine: the one a switch comes up on (_plan: the backend's
        own model, else the default). `model` / size_bytes are what the
        confirm names."""
        name, size = d["name"], None
        if backend_name == name:
            can, note, m = False, "serving now", model or None
        else:
            m, v = _cached(name + "_plan", 10, lambda: _plan(name))
            size = v.get("need_bytes")
            if not os.path.isfile(_start_path()):
                can, note = False, (f"the launcher is not in this "
                                    f"build ({_start_path()})")
            elif not v["ok"]:
                can, note = False, f"{_short_model(m)}: {v['reason']}"
            else:
                can, note = True, v.get("note")
        return {"serving": backend_name == name, "can_switch": can,
                "note": note, "model": m, "size_bytes": size}

    def _live_cluster(d, exo_block):
        """The live bits of the exo cluster (models_from "exo_catalogue")."""
        name, size = d["name"], None
        serving = backend_name == name
        plan = lambda: _cached(name + "_plan", 2.0, lambda: _plan(name))
        if serving and (exo_block or {}).get("running") is not False:
            can, note, m = False, "serving now", _hub_id(model)
        elif serving:
            # the cluster is the backend and is down: what "start exo"
            # (power on) comes up on -- the same _plan the route runs.
            m, v = plan()
            size = v.get("need_bytes")
            can = False
            note = ("serving now" if v["ok"] else
                    f"{_short_model(m)}: {v['reason']}")
            if v["ok"] and v.get("note"):
                note = v["note"]
        else:
            ok, why = _exo_startable()
            can, note = bool(ok), (None if ok else why)
            m, v = plan()
            size = v.get("need_bytes")
            if can and not v["ok"]:
                can, note = False, f"{_short_model(m)}: {v['reason']}"
            elif can:
                note = v.get("note")
        return {"serving": serving, "can_switch": can, "note": note,
                "model": m if _HUB_ID_RE.match(m or "") else None,
                "size_bytes": size}

    def _live_other(d, exo_block):
        """A registered backend this build has no live probe for (a product
        line's own, or one being wired): listed from its descriptor, sized
        by _fits (memory_from), switchable only if _GO has its launcher."""
        name = d["name"]
        if backend_name == name:
            return {"serving": True, "can_switch": False, "note": "serving now",
                    "model": model or None, "size_bytes": None}
        m, v = _cached(name + "_plan", 10, lambda: _plan(name))
        can, note = False, d.get("note")
        if not d.get("switchable"):
            note = note or "switching to it is not wired in this build"
        elif not v["ok"]:
            note = f"{_short_model(m)}: {v['reason']}"
        elif d.get("launcher_branch") not in _GO:
            note = f"this build has no switch route for {d['label']}"
        else:
            can, note = True, v.get("note")
        return {"serving": False, "can_switch": can, "note": note,
                "model": m, "size_bytes": v.get("need_bytes")}

    _LIVE = {"local_dirs": _live_local, "hf_cache": _live_local,
             "exo_catalogue": _live_cluster}

    def _available(exo_block):
        """Every backend this proxy offers, as a first-class choice: the
        registry's descriptors for this platform that are available
        (faxl_backends.for_platform), each with its descriptor fields and
        the live bits (serving, can_switch, note, model, size_bytes)."""
        descs = faxl_backends.for_platform(available_only=True)
        out = []
        if not any(d["name"] == backend_name for d in descs):
            d = faxl_backends.get(backend_name)
            if d is not None:
                descs.insert(0, d)   # serving, though not offered here
            else:
                out.append({"name": backend_name, "label": backend_name,
                            "serving": True, "can_switch": False,
                            "note": "serving now", "model": model or None})
        for d in descs:
            live = _LIVE.get(d["models_from"], _live_other)(d, exo_block)
            row = faxl_backends.public(d)
            row.update(live)
            out.append(row)
        return out

    def _memory_skeleton():
        empty = {"host_ram": {"ram_bytes": None, "usable_bytes": None},
                 "cluster_ram": None,
                 "gpu_vram": {"gpus": [], "vram_bytes": None,
                              "used_bytes": None, "usable_bytes": None,
                              "error": None}}
        mem = dict(empty, fit_ratio=None)
        for d in faxl_backends.for_platform(available_only=True):
            mem[d["name"]] = empty.get(d["memory_from"])
        return mem

    def _backend_apps():
        """The app slugs the serving backend runs; None = every app (a
        backend the registry does not know keeps what it always had)."""
        return None if _SERVING is None else set(_SERVING["apps"])

    def _prefill_counts():
        """The prefill server's counters, or None when not exposed."""
        raw = None
        if prefill_counts is not None:
            raw = prefill_counts()
        else:
            for name in ("faxl.engine.faxl_proxy", "__main__"):
                mod = sys.modules.get(name)
                c = getattr(mod, "EXO_COUNTS", None) if mod else None
                if isinstance(c, dict):
                    raw = c
                    break
        if not isinstance(raw, dict):
            return None
        req = raw.get("requests")
        hits = raw.get("hits")
        return {"requests": req, "hits": hits, "stored": raw.get("stored"),
                "hit_rate": (round(hits / req, 4)
                             if isinstance(req, (int, float)) and req
                             and isinstance(hits, (int, float)) else None)}

    def _vision(path):
        """True/False from the model's own config.json (a vision model
        carries a vision_config); None when there is no config to read --
        unknown, never guessed from the name."""
        try:
            with open(os.path.join(path, "config.json")) as fh:
                cfg = json.load(fh)
        except (OSError, ValueError, TypeError):
            return None
        return bool(cfg.get("vision_config"))

    def build_state(panel=False):
        notices = []
        # A RESTART THAT CAME BACK CRIPPLED MUST SAY SO. The switch no longer
        # refuses a model that will not load -- it restarts anyway, because a
        # console that is up beats one that is right -- so the reason has to
        # reach the page or the person meets it at their first request.
        if _LAST_FAULT.get("model"):
            notices.append({"level": "alert", "text": _LAST_FAULT["model"]})
        now = time.time()

        def attempt(source, fn, default=None):
            try:
                return fn()
            except Exception as exc:  # noqa: BLE001 -- surfaced, never a 500
                notices.append({"level": "error",
                                "title": f"{source} could not be read.",
                                "text": f"{type(exc).__name__}: {exc}",
                                "href": None})
                return default

        state = {
            "ts": round(now, 1),
            "proxy": {"running": True, "bind": bind,
                      "uptime_s": round(now - _STARTED_AT, 1),
                      # Only if the wheel is already loaded: importing it
                      # here would load the licence core on a console poll.
                      "version": getattr(sys.modules.get("faxl"),
                                         "__version__", None)},
            "backend": {"name": backend_name, "up": None,
                        # the serving backend's faxl_backends descriptor
                        # (label, kind, models_from, memory_from, apps...);
                        # null for a backend the registry does not know.
                        "descriptor": (faxl_backends.public(_SERVING)
                                       if _SERVING else None),
                        # env | config | default: where the configured
                        # backend comes from (see "config" below).
                        "source": None,
                        "in_process": not _exo,
                        "endpoint": _exo_base() if _exo else None,
                        "available": [],
                        "exo": {"running": False, "endpoint": _exo_base(),
                                "can_start": False, "note": None,
                                "nodes": None}},
            # The cluster card: exo is the backend. null on mlx.
            "cluster": None,
            # The engine card: an in-process engine with settings of its own
            # (faxl_config.backend_settings) or counters it exposes
            # (backend_stats). null when there is neither (mlx today).
            "engine": None,
            "model": {"id": model, "short": _short_model(model),
                      "vision": None, "source": None},
            # The settings file: the backend and model a restart comes back
            # on, and whether the environment is overriding them.
            "config": {"path": None,
                       "backend": {"value": None, "source": None,
                                   "env_var": "FAXL_BACKEND"},
                       "model": {"value": None, "source": None,
                                 "env_var": "FAXL_MODEL"}},
            "models": [],
            # What a model may take: this Mac's RAM x fit_ratio, and the
            # cluster's (online nodes) when exo answers. See _fits.
            # Keyed by memory SOURCE (host_ram, cluster_ram) and, for the
            # pages that read it that way, by each offered backend's name.
            "memory": _memory_skeleton(),
            "cache": {"cold": None, "entries": None, "used_bytes": None,
                      "cap_bytes": None, "free_bytes": None, "path": None},
            "counts": {"requests": None, "hits": None, "misses": None,
                       "incomplete": None, "rejected": None, "pending": None},
            "tokens": {"received": None, "skipped": None, "prefilled": None},
            "hit_rate": None,
            "first_reply": {"bands": first_reply_bands([])},
            # Verify is not built yet (POST /api/verify answers 501), so
            # nothing has ever been verified here -- and the state says so.
            "lossless": {"status": "never", "verified_at": None},
            "licence": {"state": None, "licensed_to": None, "expires": None,
                        "days_remaining": None},
            "apps": [],
            "notices": notices,
        }

        # -- where the backend and the model come from.
        def config():
            c = _config_block()
            state["config"] = c
            state["backend"]["source"] = c["backend"]["source"]
            state["model"]["source"] = c["model"]["source"]
        attempt("the settings file", config)

        # -- backend and exo. On exo the backend probe IS the exo probe.
        def backend():
            up, _detail, _n, _where = _backend_health()
            state["backend"]["up"] = bool(up)
            state["backend"]["exo"] = _exo_block(running=up if _exo else None)
        attempt("the backend", backend)
        attempt("the backend choices", lambda: state["backend"].__setitem__(
            "available", _available(state["backend"]["exo"])))

        # -- the cluster, when exo is the backend.
        def cluster():
            ex = state["backend"]["exo"]
            c = {"nodes": ex.get("nodes"), "downloads": [], "prefill": None}
            state["cluster"] = c
            if ex.get("running"):
                ok, out = _exo_downloads()
                if ok:
                    c["nodes"] = _nodes_of(out)
                    c["downloads"] = _downloads_of(out)[0]
            c["prefill"] = _prefill_counts()
        if _exo:
            attempt("the exo cluster", cluster)

        # -- the engine, when the serving backend has one to describe.
        def engine():
            settings = faxl_config.backend_settings(backend_name)
            stats = backend_stats() if backend_stats is not None else None
            if settings is None and stats is None:
                return
            d = _SERVING or {}
            state["engine"] = {
                "label": d.get("label") or backend_name,
                "kind": d.get("kind"),
                "memory_from": d.get("memory_from"),
                "endpoint": state["backend"]["endpoint"],
                "up": state["backend"]["up"],
                "model": model or None,
                "settings": settings,
                "stats": stats if isinstance(stats, dict) else None}
        if not _exo:
            attempt("the engine", engine)

        # -- telemetry: counts, tokens, bands. ONE fold for all three, so the
        # headline and the bands are the same instant of the same WAL.
        def telemetry():
            bugs_before = len(aggregator.data_bugs)
            scope = _model_scope() if has_request_context() else (model or None)
            ov, rows = _with_fold(lambda: (
                aggregator.overview(model=scope,
                                    tenant=_tenant() if has_request_context() else None),
                aggregator.recent(limit=100000, model=scope,
                                  tenant=_tenant() if has_request_context() else None)))
            if len(aggregator.data_bugs) > bugs_before:
                # _with_fold swallows a failed refresh into data_bugs so pages
                # still render; here it is also SAID, because the numbers below
                # are then from an older read of the log.
                notices.append({"level": "error",
                                "title": "The telemetry log could not be read.",
                                "text": str(aggregator.data_bugs[-1]),
                                "href": "/api/diagnostics"})
            state["counts"] = {k: int(ov.get(k, 0) or 0) for k in
                               ("requests", "hits", "misses", "incomplete",
                                "rejected", "pending")}
            skipped = int(ov.get("tokens_skipped", 0) or 0)
            paid = int(ov.get("tokens_prefilled", 0) or 0)
            # Received is the sum of the two measured counts: every prompt
            # token was either served from the cache or prefilled.
            state["tokens"] = {"received": skipped + paid, "skipped": skipped,
                               "prefilled": paid}
            decided = state["counts"]["hits"] + state["counts"]["misses"]
            # The aggregator answers 0.0 for "no requests"; a cold proxy has
            # no hit rate, which is not the same fact as a 0% one.
            state["hit_rate"] = (round(state["counts"]["hits"] / decided, 4)
                                 if decided else None)
            state["first_reply"] = {"bands": first_reply_bands(rows)}
        attempt("the telemetry log", telemetry)

        # -- models on disk, and which one is serving. On exo the list is
        # exo's catalogue, ids as exo spells them, on_disk from its downloads
        # -- the same list /api/restart checks -- so the picker never offers
        # a model the switch then refuses.
        def memory():
            mem = state["memory"]
            mem["fit_ratio"] = faxl_config.fit_ratio()
            ex = state["backend"]["exo"] or {}
            # by SOURCE (faxl_backends memory_from), then per backend name
            # (the shape the page has always read). gpu_vram: step 2.
            by = {"host_ram": faxl_config.mlx_memory(mem["fit_ratio"]),
                  "cluster_ram": (_exo_memory() if (ex.get("running") or _exo)
                                  else None)}
            # nvidia-smi only where a GPU backend is offered or serving
            if any(d["memory_from"] == "gpu_vram" for d in
                   faxl_backends.for_platform(available_only=True)) or \
                    (_SERVING or {}).get("memory_from") == "gpu_vram":
                by["gpu_vram"] = faxl_config.gpu_memory(mem["fit_ratio"])
            mem.update(by)
            for d in faxl_backends.for_platform(available_only=True):
                mem[d["name"]] = by.get(d["memory_from"])
        attempt("the memory budget", memory)

        def exo_models():
            serving = _hub_id(model)
            ok, rows = _exo_catalogue(timeout=3)
            mem = state["memory"]["cluster_ram"]
            out = []
            if ok:
                for r in rows:
                    here = r["id"] == serving
                    v = _exo_fit(r["id"], mem, rows)
                    out.append({"id": r["id"], "short": _short_model(r["id"]),
                                "serving": here,
                                # serving means its weights are loaded
                                "on_disk": True if here else r["on_disk"],
                                "size_bytes": r["size_bytes"],
                                "fits": v["ok"], "fit_reason": v["reason"],
                                "hybrid": r["hybrid"]})
                    if here:
                        state["model"]["vision"] = r["vision"]
            if model and not any(m["serving"] for m in out):
                out.insert(0, {"id": serving or model,
                               "short": _short_model(model), "serving": True,
                               "on_disk": None, "size_bytes": None,
                               "fits": None, "fit_reason": None,
                               "hybrid": _is_hybrid(serving or model, None)})
            state["models"] = out

        def models():
            # where the list comes from is the serving descriptor's
            # models_from; anything but a catalogue is directories here.
            if (_SERVING or {}).get("models_from") == "exo_catalogue":
                return exo_models()
            rows = _cached("models", 60, _local_rows_bytes)
            serving = _running_id(rows) if rows else model
            src = (_SERVING or {}).get("memory_from", "host_ram")
            mem = state["memory"].get(src) or {}
            usable = mem.get("usable_bytes")
            gpu = src == "gpu_vram"
            out = []
            for r in rows:
                v = faxl_config.judge(
                    r["id"], r["bytes"], usable,
                    faxl_config.GPU_PLACE if gpu else "this Mac",
                    on_disk=r["on_disk"],
                    down_reason=mem.get("error") if gpu else None,
                    disk_where="this machine" if gpu else "this Mac")
                out.append({"id": r["id"], "short": _short_model(r["id"]),
                            "serving": r["id"] == serving,
                            "on_disk": r["on_disk"],
                            "size_bytes": r["bytes"],
                            "fits": v["ok"], "fit_reason": v["reason"],
                            "hybrid": _is_hybrid(r["id"], None)})
                if r["id"] == serving and r["on_disk"]:
                    state["model"]["vision"] = _vision(r["path"])
            state["models"] = out
        attempt("the model list", models)

        # -- the cache store.
        def cache():
            c = state["cache"]
            st = (index_stats() if index_stats else None) or {}
            if st.get("available") and st.get("entries") is not None:
                c["entries"] = int(st["entries"])
                c["cold"] = c["entries"] == 0
            path = faxl_config.store_dir(backend_name)
            c["path"] = path
            c["cap_bytes"] = int(float(faxl_config.cap_gb()) * 1e9)
            # The cap is enforced over the whole store (exo_store: cap_gb *
            # 1e9 against live bytes), so the gauge measures the whole store
            # too: the store-wide figure when the backend reports one, else
            # the bytes actually on disk under the path.
            used_gb = st.get("store_used_gb", st.get("used_gb"))
            if used_gb is not None:
                c["used_bytes"] = int(float(used_gb) * 1e9)
            elif os.path.isdir(path):
                c["used_bytes"] = _cached("du:" + path, 30, lambda: _du(path))
            elif not os.path.exists(path):
                # A fresh install has not created its store yet: nothing is on
                # disk, which is a measured 0, not an unknown.
                c["used_bytes"] = 0
            try:
                c["free_bytes"] = shutil.disk_usage(
                    path if os.path.isdir(path)
                    else (os.path.dirname(path) or "/")).free
            except OSError:
                pass
        attempt("the cache store", cache)

        # -- licence.
        def licence():
            if licence_status is None:
                return                      # not wired: unknown, all null
            lic = faxl_licence.as_status(licence_status())
            if lic is None:
                return
            exp = lic.get("expiry") or None
            days = lic.get("days_remaining")
            if lic.get("licensed"):
                st = "active"
            elif exp:
                st = "expired"
            else:
                st = "missing"
            state["licence"] = {
                "state": st,
                "licensed_to": lic.get("customer") or None,
                "expires": _date(exp) if exp else None,
                "days_remaining": (int(float(days)) if days is not None
                                   and (lic.get("licensed") or exp) else None)}
        attempt("the licence", licence)

        # -- apps, with the one that runs a job carrying its job state.
        def apps():
            out = []
            runs = _backend_apps()
            for a in APPS:
                # only what the serving backend can run (descriptor "apps")
                if runs is not None and a["slug"] not in runs:
                    continue
                job = None
                if a.get("job") == "cameraroll":
                    job = attempt("the camera-roll job", _cameraroll_job)
                out.append({"slug": a["slug"], "title": a["name"],
                            "href": f"/console/apps/{a['slug']}", "job": job})
            state["apps"] = out
        attempt("the apps", apps)

        # -- the notices a person should act on (welcome's list, same rules).
        def welcome():
            for n in _welcome_notices():
                notices.append({"level": {"alert": "warn"}.get(n["level"],
                                                               n["level"]),
                                "title": n["title"], "text": n["text"],
                                # The panel gets its own drawers; the agent
                                # view keeps the pages it documents.
                                "href": (_panel_href(n.get("href")) if panel
                                         else n.get("href"))})
        attempt("the notices", welcome)
        return state

    def _local_rows_bytes():
        """_local_rows with bytes, not rounded GB, and None -- not 0 -- for a
        model that is not on this disk (exo may place it elsewhere)."""
        src = (_SERVING or {}).get("models_from", "local_dirs")
        rows = [{"id": mid, "path": path, "on_disk": True,
                 "bytes": faxl_config.dir_bytes(path)}
                for mid, path in faxl_config.local_models(src)]
        if model and not any(model in (r["id"], r["path"]) for r in rows):
            d = faxl_config.local_model_dir(model,
                                            hf_only=src == "hf_cache")
            rows.insert(0, {"id": model, "path": d or model,
                            "on_disk": d is not None,
                            "bytes": faxl_config.dir_bytes(d) if d else None})
        return rows

    def _cameraroll_job():
        """{running, done, total, state} from the job's status file, or None
        when no job has ever run. Read, never inferred: done is what the job
        wrote it had tagged."""
        try:
            from faxl.engine.apps import cameraroll  # noqa: F401
        except ImportError:
            return None     # the app is not in this build (nvidia): no job
        st = _job_read_status()
        if st.get("state") in (None, "none"):
            return None
        running = _job_running(st)
        state = st.get("state")
        if state in ("running", "waiting") and not running:
            state = "interrupted"
        return {"running": running, "done": st.get("tagged"),
                "total": st.get("target"), "state": state}

    # ---- THE EXO PAGE ---------------------------------------------------
    # /console/exo (a person: faxl_panel_exo, in the panel's shell), its agent
    # and JSON views, GET /api/exo (the page's 3 s poll) and GET /api/exo/log.
    # See parse_exo_state for what is confirmed about exo's API and what is
    # probed.

    _state_probe = {}     # exo base url -> (path that answered | None, when)

    def _exo_cluster_state():
        """(path, body) from exo's cluster-state endpoint, or (None, None)
        when exo exposes none of the candidates. Probed once per exo address;
        the answer is remembered, and a miss is re-tried after 5 minutes (an
        upgraded exo may have gained it)."""
        base, now = _exo_base(), time.time()
        known = _state_probe.get(base)
        if known and known[0]:
            ok, out = _cached("exo_state:" + base, 2.0,
                              lambda: _exo_json(known[0], timeout=3))
            if ok and isinstance(out, dict):
                return known[0], out
            _state_probe.pop(base, None)       # answered before, not now
            return None, None
        if known and now - known[1] < 300:
            return None, None
        for path in EXO_STATE_PATHS:
            ok, out = _exo_json(path, timeout=3)
            if ok and isinstance(out, dict) and out:
                _state_probe[base] = (path, now)
                _slow["exo_state:" + base] = (now + 2.0, (ok, out))
                return path, out
        _state_probe[base] = (None, now)
        return None, None

    def _prefill_endpoint():
        """Where faxl's prefill server listens, as the proxy PUBLISHED it for
        exo to read (faxl_proxy: FAXL_PREFILL_STATE, default
        ~/.faxl/prefill-endpoint.json, one entry per model)."""
        path = os.path.expanduser(os.environ.get(
            "FAXL_PREFILL_STATE", "~/.faxl/prefill-endpoint.json"))
        out = {"file": path, "endpoint": None, "pid": None, "pid_alive": None,
               "written_at": None, "models": None}
        try:
            with open(path) as fh:
                raw = json.load(fh)
        except (OSError, ValueError):
            return out
        if not isinstance(raw, dict):
            return out
        out["models"] = {str(k): (v.get("endpoint") if isinstance(v, dict) else None)
                         for k, v in raw.items()}
        entry = raw.get(model) or raw.get(_hub_id(model))
        if entry is None and len(raw) == 1:
            entry = next(iter(raw.values()))
        if isinstance(entry, dict):
            out["endpoint"] = entry.get("endpoint")
            out["written_at"] = entry.get("written_at")
            pid = entry.get("pid")
            if isinstance(pid, int) and pid > 0:
                out["pid"] = pid
                try:
                    os.kill(pid, 0)
                    out["pid_alive"] = True
                except ProcessLookupError:
                    out["pid_alive"] = False
                except OSError:
                    out["pid_alive"] = None       # exists, not ours to signal
        return out

    def _exo_payload():
        now = time.time()
        notices = []
        ok, cat = _exo_catalogue(timeout=4)
        running = bool(ok)
        block = _exo_block(running=running)
        serving = _hub_id(model) if _exo else None
        warn = None
        if running and not _exo:
            warn = ("exo is running without faxl in front of it: nothing it "
                    "serves goes through the cache. Switch the backend to exo "
                    "cluster, or stop exo.")
        elif _exo and not running:
            warn = ("exo is the serving backend and is not answering: nothing "
                    "is being served. Start exo, or switch to this Mac (MLX).")
        p = {"ts": round(now, 1),
             "exo": {"running": running, "endpoint": _exo_base(),
                     "version": None, "serving_backend": backend_name,
                     "faxl_in_front": bool(_exo and running),
                     "can_start": block.get("can_start"),
                     "note": block.get("note"), "warn": warn,
                     "state_endpoint": None},
             "backend": {"name": backend_name, "model": model or None,
                         "serving_hub_id": serving,
                         "available": _available(block)},
             "nodes": None, "links": None, "placement": None,
             "totals": {"nodes_known": None, "nodes_online": None,
                        "ram_total": None, "ram_free": None,
                        "ram_nodes_reporting": None},
             "prefill": dict(_prefill_endpoint(), requests=None, hits=None,
                             stored=None, hit_rate=None),
             "models": None, "downloads": None,
             "exposes": {"state": False, "nodes": False, "memory": False,
                         "links": False, "placement": False,
                         "version": False},
             "notices": notices}
        pc = _prefill_counts()
        if pc:
            p["prefill"].update(pc)
        if not running:
            notices.append({"level": "warn" if _exo else "info",
                            "title": "exo is not answering.",
                            "text": f"{_exo_base()}: {cat}", "href": None})
            return p
        dok, dl = _exo_downloads()
        p["downloads"] = _downloads_of(dl)[0] if dok else None
        path, st = _exo_cluster_state()
        p["exo"]["state_endpoint"] = path
        parsed = parse_exo_state(st, dl if dok else None, serving, now)
        ver = _k(st, "version", "exoVersion", "exo_version") if st else None
        if isinstance(ver, str):
            p["exo"]["version"] = ver
        p["exposes"] = dict(parsed["exposes"], state=path is not None,
                            version=isinstance(ver, str))
        p["nodes"] = parsed["nodes"]
        p["links"] = parsed["links"]
        p["placement"] = parsed["placement"]
        nodes = parsed["nodes"]
        t = p["totals"]
        t["nodes_known"] = len(nodes)
        if any(n["reachable"] is not None for n in nodes):
            t["nodes_online"] = sum(1 for n in nodes if n["reachable"] is True)
        online = [n for n in nodes if n["reachable"] is not False]
        tot = [n["ram_total"] for n in online if n["ram_total"] is not None]
        free = [n["ram_free"] for n in online if n["ram_free"] is not None]
        t["ram_nodes_reporting"] = len(tot) if st else None
        t["ram_total"] = sum(tot) if tot else None
        t["ram_free"] = sum(free) if free else None
        if path is None:
            notices.append({"level": "info",
                            "title": "exo does not expose its cluster state.",
                            "text": "None of " + ", ".join(EXO_STATE_PATHS)
                                    + " answered, so node details, links and "
                                      "placement are not available; the nodes "
                                      "listed are the ones /state/downloads "
                                      "names.", "href": None})
        rows = cat
        live = {d["model"]: d for d in (p["downloads"] or [])}
        # The fit rule, against the online nodes' memory: what the serve
        # button may offer (see _fits).
        r_ = faxl_config.fit_ratio()
        mem = {"ram_bytes": t["ram_total"],
               "usable_bytes": (int(t["ram_total"] * r_)
                                if t["ram_total"] else None),
               "nodes": len(online)}
        t["usable_for_model"] = mem["usable_bytes"]
        t["fit_ratio"] = r_
        for r in rows:
            r["serving"] = bool(serving) and r["id"] == serving
            r["download"] = live.get(r["id"])
            f = _exo_fit(r["id"], mem, rows)
            r["fits"], r["fit_reason"] = f["ok"], f["reason"]
        p["models"] = rows
        return p

    def _exo_payload_safe():
        try:
            return _exo_payload()
        except Exception as exc:  # noqa: BLE001 -- never a 500
            return {"ts": round(time.time(), 1),
                    "exo": {"running": None, "endpoint": _exo_base(),
                            "version": None, "serving_backend": backend_name,
                            "faxl_in_front": None, "can_start": None,
                            "note": None, "warn": None, "state_endpoint": None},
                    "backend": {"name": backend_name, "model": model or None,
                                "serving_hub_id": None, "available": []},
                    "nodes": None, "links": None, "placement": None,
                    "totals": {"nodes_known": None, "nodes_online": None,
                               "ram_total": None, "ram_free": None,
                               "ram_nodes_reporting": None},
                    "prefill": None, "models": None, "downloads": None,
                    "exposes": {"state": False, "nodes": False,
                                "memory": False, "links": False,
                                "placement": False, "version": False},
                    "notices": [{"level": "error",
                                 "title": "The exo page could not be built.",
                                 "text": f"{type(exc).__name__}: {exc}",
                                 "href": None}]}

    @bp.route("/api/exo", methods=["GET"])
    def api_exo():
        return jsonify(_exo_payload_safe())

    _ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

    @bp.route("/api/exo/log", methods=["GET"])
    def api_exo_log():
        """The last lines of ~/.faxl/logs/exo.log (faxl_start.sh writes it on exo).
        This machine only: a log carries paths, model ids and tracebacks."""
        if not _caller_is_local():
            return jsonify({"ok": False, "error":
                            "exo's log is readable from this machine only"}), 403
        n = _int_arg("lines", 60, 500)
        if n is None or n < 1:
            return jsonify({"ok": False, "error": "lines must be 1-500"}), 400
        path = _log_path("exo.log")
        try:
            st = os.stat(path)
            with open(path, "rb") as fh:
                size = st.st_size
                fh.seek(max(0, size - 256 * 1024))
                data = fh.read()
        except OSError:
            return jsonify({"ok": True, "path": path, "exists": False,
                            "lines": [], "size": None, "mtime": None,
                            "note": "no exo log yet: faxl_start.sh writes it "
                                    "when it starts exo"})
        lines = data.decode("utf-8", errors="replace").splitlines()
        if size > len(data) and lines:
            lines = lines[1:]            # the first line was cut by the seek
        return jsonify({"ok": True, "path": path, "exists": True,
                        "size": size, "mtime": st.st_mtime,
                        "lines": [_ANSI.sub("", ln) for ln in lines[-n:]]})

    def _exo_page(payload):
        """The exo page for a person, or None to fall back to the agent view
        (said in /api/diagnostics, never silent)."""
        try:
            from faxl.engine import faxl_panel_exo
            body = faxl_panel_exo.render_exo(build_state(panel=True), payload)
        except Exception as exc:  # noqa: BLE001
            msg = f"exo page: {type(exc).__name__}: {exc}"
            if msg not in aggregator.data_bugs:
                aggregator.data_bugs.append(msg)
            return None
        resp = Response(body, mimetype="text/html")
        resp.headers["Content-Security-Policy"] = HUMAN_CSP
        return resp

    @bp.route("/console/exo", methods=["GET"])
    def console_exo():
        """The exo cluster: a page for a person, the same facts as HTML for an
        agent, ?format=json = /api/exo, ?format=text a compact rendering."""
        mode = select_mode(request.args, request.headers)
        p = _exo_payload_safe()
        if mode == "json":
            return jsonify(p)
        if mode == "text":
            return Response(exo_text(p, _origin()), mimetype="text/plain")
        if mode == "human":
            page = _exo_page(p)
            if page is not None:
                return page
        return Response(exo_agent_html(p, _origin()), mimetype="text/html")

    @bp.route("/api/state", methods=["GET"])
    def api_state():
        try:
            # The panel's poll feed, so the panel's hrefs: a poll that handed
            # back /console/licence would undo the drawer link on the first tick.
            # The agent's copy of the state is /console?format=json.
            return jsonify(build_state(panel=True))
        except Exception as exc:  # noqa: BLE001 -- the last line of defence
            return jsonify({"ts": round(time.time(), 1), "notices": [{
                "level": "error", "title": "The state could not be built.",
                "text": f"{type(exc).__name__}: {exc}", "href": None}]})

    # ---- VOICE2TEXT (docs/plans/voice2text.md) ----------------------------
    # The /api/voice/* routes live in faxl_voice; this is the one hook. The
    # repair step posts to this proxy's own /v1/chat/completions (from
    # `bind`), so the cache and the request log see it; every POST is
    # loopback-only through the same _caller_is_local as restart.
    faxl_voice.register_voice_routes(
        bp, caller_is_local=_caller_is_local, serving_model=lambda: model,
        bind=bind, backend_name=backend_name, config_dir=_cfg)

    return bp

# Vendored engine module (faxl_proxy.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl caching proxy — an OpenAI-compatible /v1/chat/completions endpoint that
sits between an agent (OpenClaw, or any OpenAI client) and Granite, and does the
prefill caching in the middle.

EXACT-TIER LOOKUP (docs/plan-exact-tier-productionisation.md, implements the
boxcar decision docs/boxcar-ladder-result.md §7): a hit requires IDENTITY,
similarity is RETRIEVAL. Per request:
  1. Build the prompt (chat template) from the messages.
  2. Compute the prompt's polynomial prefix-hash array (one O(N) pass,
     ~0.031µs/token measured — no ESN on the lookup path).
  3. For each scheduled checkpoint position, deepest first: look up the
     exact-tier index by prefix hash; on a hit, CONFIRM by comparing the
     stored token prefix byte-for-byte (collision belt-and-braces; outcome
     logged per hit).
     - CONFIRMED: load that checkpoint's recurrent state, prefill ONLY the
       tail beyond it. (identical prefix -> identical state, F3)
     - no confirmed hit: prefill the whole prompt cold. NO cosine fallback —
       near-dup resume serves stale output (semantic-reuse falsification).
  4. CHECKPOINT the resulting state at scheduled positions (blob on disk),
     registering: prefix hash + token prefix (content-addressed, write-once)
     always; an ESN/UltraDim similarity key ONLY at >= KEY_MIN_TOKENS=1025
     (c4 alive, 4-band key complete) — similarity keys serve retrieval and
     near-miss telemetry, never the hit decision.
  5. Return an OpenAI-shaped response.

The old cosine walk (SNAP + tail floors) was REMOVED 2026-08-15 (audit D9):
dead code with no caller. Measured record: wrong-prefix hits 308/420 at SNAP
0.6 (157 at 0.96), rejects 31/135 byte-identical replays
(docs/boxcar-e3.jsonl). It lives in git history.

So: kill the agent, restart it, give it a similar task -> the proxy finds the
prior state and resumes warm instead of cold. That is the cost win, and the
service.

Run:   python3 integration/faxl_proxy.py            (serves on :8767)
Point an OpenAI client at http://faxl.localhost:8767/v1 with any api key.
Console: http://faxl.localhost:8767/console  (FAXL_PORT overrides the port).
Requires: MLX, and the faxl + ultradim wheels (see QUICKSTART.md).
"""
import base64
import hashlib
import json
import re
import os
from dataclasses import asdict
import threading
import time
import uuid

from flask import Flask, Response, request, jsonify
# The compiled cache core. Absent = the proxy cannot cache; fail LOUD at import
# rather than silently degrading to a pass-through nobody notices.
try:
    import faxl
except ImportError as _e:
    faxl = None
    print(f"[faxl] FATAL: the 'faxl' wheel is not installed ({_e})", flush=True)

# Imported here, not with the other faxl.engine imports below: BLOB_DIR
# and STORE_CAP_GB are module-level constants evaluated further down, and the
# backend name has to be known BEFORE the mlx imports, which are gated on it.
from faxl.engine import faxl_config

# THE BACKEND AND THE MODEL ARE RESOLVED ONCE, HERE, and every later use reads
# these names -- never os.environ again. They live in ~/.faxl/config.json
# (written by the console, read by faxl_start.sh); FAXL_BACKEND / FAXL_MODEL
# still override, and the boot line says which one won, because "why is it
# on exo" is a support question whose answer is usually "the env".
_CFG = faxl_config.describe()
_BACKEND_NAME = _CFG["backend"]["value"]

# MLX IS IMPORTED ONLY FOR THE BACKENDS WHOSE PROXY PATH USES IT (2026-09-22,
# stage 2 chunk 1: this module is vendored from faxl-core to the Mac AND the
# Linux wheel). mlx runs the model; exo runs it on the cluster but this
# process still loads the tokenizer and derives the cache family through
# mlx_lm. Any other backend (vllm) must import this module on a machine that
# has no mlx at all, so the names below are bound to _mlx_only guards there:
# reaching one is a RuntimeError naming the path and the backend, never an
# ImportError three frames from the cause and never a silent substitute.
_MLX_BACKENDS = ("mlx", "exo")


def _mlx_only(what):
    """A callable that refuses: `what` is an mlx-only path on this backend."""
    def _refuse(*_a, **_kw):
        raise RuntimeError(
            f"faxl_proxy: {what} is an mlx-only path, reached on backend "
            f"{_BACKEND_NAME!r}. This backend has no implementation of it yet "
            f"-- route it through the execution backend.")
    _refuse.__name__ = _refuse.__qualname__ = f"mlx_only[{what}]"
    return _refuse


class _MlxOnlyModule:
    """Stands in for `mx` off mlx: any attribute access refuses, loudly."""

    def __getattr__(self, attr):
        _mlx_only(f"mlx.core.{attr}")()


if _BACKEND_NAME in _MLX_BACKENDS:
    import mlx.core as mx
    # Register out-of-tree mlx_lm model loaders faxl carries (e.g. Ling's
    # bailing_hybrid = KDA+MLA+MoE). No-op for models mlx_lm already knows;
    # injects into sys.modules so `mlx_lm.load` resolves them without patching
    # site-packages.
    try:
        from faxl.engine import mlx_models as _faxl_mlx_models
        _faxl_mlx_models.register()
    except Exception as _e:  # never block startup on an optional loader
        print(f"[faxl] mlx_models.register skipped: {_e}", flush=True)
    from mlx_lm import load
    from mlx_lm.models.cache import (make_prompt_cache, save_prompt_cache,
                                     load_prompt_cache, can_trim_prompt_cache,
                                     trim_prompt_cache)
    from mlx_lm.generate import generate_step
    from mlx_lm.sample_utils import make_sampler
else:
    mx = _MlxOnlyModule()
    load = _mlx_only("mlx_lm.load")
    # The mlx_lm cache functions stay bound to refusals for any code that
    # still reaches for them by name. The REQUEST PATH does not: it goes
    # through CACHE (below), which every backend implements.
    make_prompt_cache = _mlx_only("mlx_lm make_prompt_cache")
    save_prompt_cache = _mlx_only("mlx_lm save_prompt_cache")
    load_prompt_cache = _mlx_only("mlx_lm load_prompt_cache")
    can_trim_prompt_cache = _mlx_only("mlx_lm can_trim_prompt_cache")
    trim_prompt_cache = _mlx_only("mlx_lm trim_prompt_cache")
    generate_step = _mlx_only("mlx_lm generate_step")
    make_sampler = _mlx_only("mlx_lm make_sampler")


# ------------------------------------------------------------------ CACHE SEAM
# THE REQUEST PATH TALKS TO `CACHE`, NOT TO mlx_lm (2026-09-25, stage B of
# docs/plans/linux-wheel-handoff.md).
#
# Until now the eight cache operations in the request path were mlx_lm
# functions imported at module top, bound to loud refusals on any other
# backend. That made the shared proxy importable off mlx but not USABLE off
# mlx: FAXL_BACKEND=vllm booted and then raised on the first request, which is
# a stub in the sense docs/Rules.md forbids.
#
# Everything the request path needs from a cache engine is named here. The
# generic path passes and receives PLAIN PYTHON LISTS of token ids; a backend
# that wants framework arrays (mlx) wraps them itself, so no `mx.array` is
# left in the shared path.
class CacheOps:
    """What the request path needs of a cache engine. One subclass per line."""

    #: directory name under the faxl store for this backend's blobs
    store_name = "mlx"
    #: recorded in the telemetry identity; a blob written by one format is
    #: never loadable by another, so it is part of the store's identity
    cache_format = "mlx_safetensors_v1"
    #: whether this backend can answer a request carrying images
    supports_images = True

    def make(self, model):
        raise NotImplementedError

    def load(self, blob):
        raise NotImplementedError

    def save(self, blob, cache):
        raise NotImplementedError

    def can_trim(self, cache):
        raise NotImplementedError

    def trim(self, cache, n):
        raise NotImplementedError

    def prefill(self, ids, cache, start=0, images=None):
        """Fold ids[start:] into `cache`. `ids` is a plain list."""
        raise NotImplementedError

    def generate(self, ids, cache, max_tokens):
        """Return (out_ids, t_first_token). `ids` is the FULL prompt as a
        list; a backend that only needs the last token takes it itself."""
        raise NotImplementedError

MODEL = _CFG["model"]["value"]
if _BACKEND_NAME == "exo":
    # exo knows models by hub id only; a path here (an mlx model directory
    # left in the config) is how a proxy died on boot with "Repo id must be
    # in the form 'namespace/repo_name'". Name it, if it can be named.
    _hub = faxl_config.hub_id(MODEL)
    if _hub != MODEL:
        print(f"model {MODEL} -> {_hub} (exo takes a hub id)", flush=True)
        MODEL = _hub
EXO = faxl_config.exo_settings()
print(f"backend={_BACKEND_NAME} ({_CFG['backend']['source']}) "
      f"model={MODEL} ({_CFG['model']['source']}) "
      f"config={_CFG['path']}", flush=True)

# ON MLX THE WEIGHTS MUST ALREADY BE ON THIS MAC (2026-09-21). mlx_lm.load and
# mlx_vlm.load treat a hub id they cannot find locally as "download it", and
# they say nothing while they do: a switch left MiniMax-M2.7 (~130 GB)
# configured on mlx and this process spent the afternoon fetching it onto one
# Mac, the console dark the whole time. So the model is resolved HERE to the
# directory it loads from (faxl_config.local_model_dir: the HF cache, then
# exo's ~/.exo/models copy, weights complete), and the loaders are handed
# that path -- a hub id whose weights only exo's directory holds used to be
# fetched again into the HF cache. Not here at all: a loud line and exit 3,
# unless FAXL_ALLOW_DOWNLOAD=1 (a developer) or it is the shipped default
# (under 6 GB, fetched once on a fresh install).
_LOAD_FROM = MODEL
if _BACKEND_NAME == "mlx":
    _here = faxl_config.local_model_dir(MODEL)
    if _here:
        _LOAD_FROM = _here
        if _here != MODEL:
            print(f"model {MODEL} -> {_here} (on this Mac)", flush=True)
    elif os.environ.get("FAXL_ALLOW_DOWNLOAD") == "1":
        print(f"!! FAXL_ALLOW_DOWNLOAD=1: {MODEL} is not on this Mac and IS "
              f"BEING DOWNLOADED now -- the proxy answers when it is done",
              flush=True)
    else:
        # BATTERIES NOT INCLUDED (2026-09-22). faxl ships without weights, and
        # a fresh install has none -- not even the smallest rung, which is
        # still a 2.9 GB download. This used to be two branches: fetch the
        # shipped default unasked (a 64 GB Mac would now pull 36 GB before
        # the console appeared), or exit 3. Both were wrong, and exit 3 was
        # the worse of the two: the CONSOLE IS SERVED BY THIS PROCESS, so
        # exiting here takes down the very page the person would use to
        # choose a model. That is the 2026-09-21 incident's "console dark"
        # symptom arriving by a different road.
        #
        # So: come up WITHOUT a model. The proxy serves the console, the
        # welcome page shows what this Mac should run and what each option
        # would download (faxl_config.recommend_models), and the person
        # picks. /v1 answers 503 with that same sentence until they do.
        # Nothing is downloaded as a side effect of starting, ever.
        _LOAD_FROM = None
        print(f"no model yet: {MODEL} is not on this Mac. faxl does not "
              f"download one as a side effect of starting -- open the "
              f"console and pick one (it will say what fits and what it "
              f"costs). Config: {_CFG['path']}", flush=True)
# THE STORE FOLLOWS THE BACKEND (2026-09-25). This was hardcoded "mlx", so a
# vllm proxy would have written its blobs into the mlx store and then failed to
# load them: a blob's format is part of its identity. The name is resolved from
# the backend here because BLOB_DIR is needed long before the cache engine is
# built; CacheOps.store_name carries the same value and is asserted against
# this at boot (see the CACHE selection below).
_STORE_NAMES = {"mlx": "mlx", "exo": "mlx", "vllm": "vllm"}
if _BACKEND_NAME not in _STORE_NAMES:
    raise RuntimeError(
        f"faxl_proxy: backend {_BACKEND_NAME!r} has no store name. A store "
        f"name is part of a checkpoint's identity, so it is declared here "
        f"rather than defaulted: add it to _STORE_NAMES.")
STORE_NAME = _STORE_NAMES[_BACKEND_NAME]
# Trimming means shortening a stored cache to a shallower position. mlx can
# (mlx_lm's can_trim_prompt_cache decides per model family); the vllm seam
# cannot -- it records a plan and the connector restores at one confirmed
# position, so there is nothing to shorten. Declared, and checked against the
# cache engine's own can_trim() at boot.
_TRIMMABLE_BY_BACKEND = {"mlx": None, "exo": None, "vllm": False}
BLOB_DIR = faxl_config.store_dir(STORE_NAME)
# FAXL_DB: the user-managed directory for the PERSISTENT UltraDim key store + the
# key→blob index. A cache is not a database if the user cannot say where it lives.
# Default is a stable named dir (NOT a temp dir) so restarts reload the same store.
DB_DIR = os.environ.get("FAXL_DB", os.path.join(BLOB_DIR, "ultradim_db"))
META_PATH = os.path.join(DB_DIR, "meta.json")
# TOKENS_DIR: content-addressed token prefixes for the exact tier — tokens/<phash>.json
# holds ids[:cpos] for every checkpoint with that prefix hash. Identical prefixes across
# requests/sessions share one file (write-once); ~4 B/token, negligible vs blobs.
TOKENS_DIR = os.environ.get("FAXL_TOKENS", os.path.join(BLOB_DIR, "tokens"))
# FIX D5 (CODE-TRUTH): the defaults above live under /tmp and vanish on reboot.
# A cache whose store silently evaporates is a correctness trap for its operator.
def _volatile(p):
    return os.path.realpath(p).startswith(("/tmp", "/private/tmp", "/var/folders"))
if _volatile(BLOB_DIR) or _volatile(DB_DIR):
    print(f"!! VOLATILE STORE: blobs={BLOB_DIR} db={DB_DIR} are under /tmp and "
          f"will NOT survive a reboot. Set FAXL_BLOBS/FAXL_DB to persistent "
          f"paths for production.", flush=True)
SEG = 256
# ESN keys are written only for checkpoints at >= this depth (AM directive): below
# 1025 the stride-1024 c4 band has never fired, so the 4-band key is incomplete and
# measured-bad as an embedding. Sub-1025 checkpoints are exact-tier-only entries.
KEY_MIN_TOKENS = int(os.environ.get("FAXL_KEY_MIN_TOKENS", "1025"))

# Polynomial prefix hash (the exact tier's key; same constants as
# integration/boxcar_ladder.py, measured 570/570 correct, 0 collisions).


# Schedule + prefix hash extracted to ckpt_schedule.py (phase 0, plan v1.5)
# so the simulator and tests import them without loading a model. Schedule v2
# (plan §1): base 250 so short prompts (the translation class, 262–280
# tokens) get a reusable checkpoint — safe because a hit requires an exact
# match. FAXL_CKPT_EVERY / FAXL_CKPT_RATIO env pins are read there.
from faxl.engine.ckpt_schedule import (CKPT_EVERY, CKPT_RATIO, ckpt_positions,  # noqa: F401
                           ckpt_set as _CKPT_SET)
# Prefix hashing moves to the compiled core: same values (verified 0/300
# mismatches vs ckpt_schedule.prefix_hashes), one implementation, and the
# lookup path stays inside the wheel.
prefix_hashes = faxl.prefix_hashes if faxl is not None else None
from faxl.engine.media_regions import (ImageDecodeError, MediaRegion,
                                       entry_key, hash_image_bytes)
# entry_key is imported unconditionally (2026-09-25): it moved INTO
# media_regions, which imports no mlx, so every backend keys its store by the
# same rule. It used to be refused off mlx because it lived in exo_store --
# that refusal meant a non-mlx backend could not key a checkpoint at all.
from faxl.engine.store_lifecycle import (STRATEGIES, ScheduleContext,  # noqa: F401
                                         usage_score,
                             make_policy, append_usage, load_usage,
                             compact_usage)
# LICENCE: a signed key file. Absent or lapsed = the cache tier serves misses
# (every prefill cold) while the proxy keeps answering — a lapsed licence must
# never take an inference endpoint down mid-request.
LICENCE_FILE = os.environ.get("FAXL_LICENCE",
                              os.path.expanduser("~/.faxl-licence"))
GATE_TOKENS = int(os.environ.get("FAXL_GATE_TOKENS", "64"))  # skip cache below this
# PLACEMENT STRATEGY SEAM: the write path consumes
# POLICY.decide(ScheduleContext) -> [Placement]. Strategies are named and
# selectable; see store_lifecycle.STRATEGIES for the registry, the measured
# per-workload costs, and how to add another.
#
#   FAXL_STRATEGY=tail_anchor  (DEFAULT) checkpoint at the next turn's resume
#                              point. Measured +25.7% (journal) / +37.8%
#                              (endurance) net cost vs grid; no change on
#                              one-shot traffic.
#   FAXL_STRATEGY=grid         the previous default: geometric ladder only.
#   FAXL_STRATEGY=none         write nothing (control arm).
#
# Tuning: FAXL_TAIL_MARGIN (>=3, a correctness floor — see the class
# docstring), FAXL_TAIL_WITH_GRID=1 to keep the ladder alongside the anchor,
# FAXL_TAIL_MIN_ARRIVALS=N to write the anchor only for chains seen N times
# before (suppresses useless writes on one-shot traffic).
STRATEGY = os.environ.get("FAXL_STRATEGY", "tail_anchor")
_STRAT_KW = {"gate_tokens": GATE_TOKENS}
if STRATEGY in ("grid", "tail_anchor"):
    _STRAT_KW.update(base=CKPT_EVERY, ratio=CKPT_RATIO)
if STRATEGY == "grid":
    _STRAT_KW = {"base": CKPT_EVERY, "ratio": CKPT_RATIO,
                 "gate_tokens": GATE_TOKENS}
elif STRATEGY == "tail_anchor":
    _STRAT_KW.update(
        margin=int(os.environ.get("FAXL_TAIL_MARGIN", "3")),
        with_grid=os.environ.get("FAXL_TAIL_WITH_GRID", "0") == "1",
        min_arrivals=int(os.environ.get("FAXL_TAIL_MIN_ARRIVALS", "0")),
        # continuation evidence: how many EARLIER requests carried the
        # prefix we resumed from. The fork index already counts exactly
        # this (match_counts), so the gate needs no new bookkeeping.
        count_of=lambda ctx: (forkidx.match_counts.get(str(ctx.d_star_hash), 0)
                              if FORK and ctx.d_star_hash else 0))
elif STRATEGY == "none":
    _STRAT_KW = {}
POLICY = make_policy(STRATEGY, **_STRAT_KW)
print(f"placement strategy: {STRATEGY} "
      f"({ {k: v for k, v in _STRAT_KW.items() if k != 'count_of'} })",
      flush=True)
# A/B CONTROL: FAXL_NOCACHE=1 turns the cache OFF (no walk/resume, no checkpoint
# write) while STILL running through the proxy — so we can measure the same task
# with and without faxl and diff the ROI. Everything else (model, tool parsing,
# metrics logging) is identical, isolating the cache's effect.
NOCACHE = os.environ.get("FAXL_NOCACHE", "0") == "1"
# ---- TURN SETTLE (2026-10-01) -- checkpoint the ANSWER, not just the prompt.
# Checkpoints are written during PREFILL only (decode state is produced
# token-by-token, a chunk decomposition the cold path would never use, so
# persisting it breaks the hybrid grid rule -- see backends.py). The model's
# reply therefore used to enter the store one turn LATE: turn N+1 re-prefilled
# all of turn N's answer, and a two-turn chat showed hit_rate 0. After each
# reply is delivered the proxy now sends ITSELF one prefill-only request
# (header X-Faxl-Settle, loopback only) carrying the conversation plus the
# reply. That request walks the ordinary lookup -> on-grid prefill ->
# checkpoint path bit-for-bit, landing a checkpoint at the last SEG multiple
# inside the answer -- the 256 pulse, the last good offset (AM). It decodes
# nothing and is excluded from TOTALS, the metrics JSONL, telemetry and AUDIT
# outcome rows, so the console never shows phantom traffic. It serialises
# behind live requests on _SERVE_LOCK and runs while the user is reading the
# answer, so its cost is idle time. FAXL_SETTLE=0 disables.
SETTLE = os.environ.get("FAXL_SETTLE", "1") == "1"
# ---- FORK-POINT CHECKPOINTING (docs/plan-fork-point-checkpointing.md rev 5) --
FORK = os.environ.get("FAXL_FORK", "0") == "1"
FORK_TIME_RATIO = float(os.environ.get("FAXL_FORK_TIME_RATIO", "5"))
FORK_AMORT = float(os.environ.get("FAXL_FORK_AMORT", "4"))
FORK_MAX_LIVE_GB = float(os.environ.get("FAXL_FORK_MAX_LIVE_GB", "20"))
# TOTAL blob-store cap (2026-08-19 ENOSPC incident: only forks were
# capped; grid/anchor checkpoints filled 88 GB in one campaign).
#
# At cap we EVICT, we do not skip. Writes always land and scored eviction
# makes room after (store_lifecycle.evict_scored: oldest unpopular first, by
# time-since-last-hit over popularity; nothing is permanent under this cap,
# grid included). The earlier skip-at-cap behaviour was removed on AM's
# directive 2026-09-01 after a full store starved live traffic behind stale
# blobs — 21 consecutive hourly cold misses. A store sitting at its cap is
# therefore NORMAL, not degraded.
STORE_CAP_GB = faxl_config.cap_gb()
_STORE_BYTES = [0]     # maintained incrementally after boot scan
FORK_GATES_OFF = os.environ.get("FAXL_FORK_GATES_OFF", "0") == "1"  # config (d) demo
STREAMS_DIR = os.environ.get("FAXL_STREAMS", os.path.join(BLOB_DIR, "streams"))
METRICS = os.environ.get("FAXL_METRICS", "/tmp/faxl_metrics.jsonl")  # durable per-request ROI log
# ---- M0 AUDIT TRAIL (master plan v4.1; register rows 55/56/62/76/130) ------
# FAXL_AUDIT_DIR set => per-request audit events (ns identity, full
# prefix-hash arrays, lookup probes, decisions with raw signals, lifecycle,
# outcome) through audit_trail.AuditTrail — the SAME schema the calibrated
# simulator emits, validated by audit_replay.py. Unset => byte-identical
# legacy behaviour. FAXL_COLLECT=1 = corpus-collection mode: audit REQUIRED,
# volatile sinks refused, any logging failure fails /health loudly (an
# apparently-valid incomplete corpus is the worst outcome).
AUDIT_DIR = os.environ.get("FAXL_AUDIT_DIR")
COLLECT = os.environ.get("FAXL_COLLECT", "0") == "1"
if COLLECT and not AUDIT_DIR:
    raise SystemExit("!! FAXL_COLLECT=1 requires FAXL_AUDIT_DIR (durable, "
                     "non-/tmp) — collection without an audit sink is the "
                     "incomplete-corpus trap M0 exists to close")
WORKLOAD = os.environ.get("FAXL_WORKLOAD", "unlabelled")
SESSION_LABEL = os.environ.get("FAXL_SESSION") or f"session-{uuid.uuid4().hex[:8]}"
TENANT = os.environ.get("FAXL_TENANT", "gamakon-dev")
REVISION = os.environ.get("FAXL_MODEL_REVISION", "unpinned")
DTYPE = os.environ.get("FAXL_DTYPE", "as-published")
LOG_FAILURES = []   # loud logging failures; surfaced by /health (M0/F11)
WIDTH = 1 << 16
D_PROJ = 2048
# Projection seeds are Rust-owned config (single source: faxl-probe's resolve_seeds,
# FAXL_SEEDS-overridable). The proxy READS them from the Rust CLI at startup (see
# `SEEDS = probe.seeds()` below) and NEVER declares its own — so the seeds faxl
# computes keys under and the seeds the UltraDim collection is created with are one
# value by construction. SEEDS is bound after `probe` is built.
SEEDS = None
SOURCE_DIM = 4 * WIDTH
FAMILY = "faxl-live"

app = Flask(__name__)

# ---- running ROI totals (across all requests since boot) ----
# Hit/miss on the exo path is decided by the PrefillServer thread, not by this
# handler -- the ladder runs there, where exo's runner asks for a prefix. These
# counters are how the answer gets back to /metrics and the console. Written by
# that thread, read by the request handler; ints under the GIL, no lock needed.
EXO_COUNTS = {"requests": 0, "hits": 0, "last_served": 0, "stored": 0}

# PER-PROJECT breakdown, so two pipelines sharing one proxy can be told apart:
# which team's traffic is hitting the cache, and which is paying for prefill.
# {project: {"requests","hits","prompt_tokens","prefill_skipped","wall_s"}}
BY_PROJECT = {}


def _bump_project(project, *, hit, prompt_tokens, skipped, secs, paid=0):
    """Attribute one served request to a project tag ('' = untagged)."""
    p = BY_PROJECT.setdefault(project or "(untagged)", {
        "requests": 0, "hits": 0, "prompt_tokens": 0,
        "prefill_skipped": 0, "prefill_paid": 0, "wall_s": 0.0})
    p["requests"] += 1
    p["hits"] += 1 if hit else 0
    p["prompt_tokens"] += int(prompt_tokens)
    p["prefill_skipped"] += int(skipped)
    p["prefill_paid"] += int(paid)
    p["wall_s"] += float(secs)

TOTALS = {"requests": 0, "prompt_tokens": 0, "prefill_paid": 0, "prefill_skipped": 0,
          "hits": 0, "ckpts_written": 0, "ckpts_deduped": 0, "wall_s": 0.0}


# ---- faxl probe (Rust) ----
class Probe:
    """The compiled cache core (faxl wheel).

    Was a subprocess speaking line-JSON to faxl_probe_cli; the reservoir and
    the projection now live in the wheel, so there is no process boundary and
    no pipe to keep in sync. Verified identical to the CLI: same indices,
    cosine 1.0 (the wheel-distribution plan (research archive)).
    """

    def __init__(self):
        if faxl is None:
            raise RuntimeError(
                "the 'faxl' wheel is not installed — pip install the faxl and "
                "ultradim wheels (see QUICKSTART.md)")

    def seeds(self):
        """The Rust-resolved projection seeds (FAXL_SEEDS-overridable). The single
        source; the proxy passes THESE to CreateCollection."""
        return list(faxl.seeds())

    def key(self, tokens):
        return faxl.probe_key(list(tokens))


# ---- UltraDim (embedded wheel) ----
class Licence:
    """Entitlement for the cache tier.

    Enforcement lives in the compiled wheel (faxl.ExactIndex), not here — a
    check in this file is a one-line patch to remove. This class only loads the
    key and reports status.

    On lapse the proxy DEGRADES: it keeps serving, the cache tier stops
    hitting, every prefill runs cold. It never refuses a request — an expired
    licence must not take an inference endpoint down.
    """

    def __init__(self, path=LICENCE_FILE):
        self.customer, self.expiry, self.action = "", 0, "unlicensed"
        # Module-level: the wheel's prefix_hashes/probe_key refuse without it,
        # so deleting this class would not re-enable caching.
        self._gate = faxl
        hw_file = os.path.join(BLOB_DIR, ".faxl-hw")
        try:  # restore the clock high-water mark (anti-rollback)
            if self._gate is not None and os.path.exists(hw_file):
                self._gate.set_high_water(int(open(hw_file).read().strip()))
        except (ValueError, OSError):
            pass
        self._hw_file = hw_file
        if self._gate is None:
            return
        try:
            key = open(path).read().strip()
            key = "".join(ln for ln in key.splitlines() if not ln.startswith("#"))
            self.customer, self.expiry, self.action = self._gate.set_licence(key)
        except FileNotFoundError:
            live, cust, exp, _rem, act = self._gate.licence_status()
            if live:
                # time-limited build (tester wheel): entitled without a key
                self.customer, self.expiry, self.action = cust, exp, act
                days = (exp - time.time()) / 86400.0
                print(f"[faxl] {cust}: cache tier enabled without a key; "
                      f"this build stops accelerating in {days:.0f} days",
                      flush=True)
                return
            print(f"!! NO LICENCE at {path} — cache tier DISABLED (every prefill "
                  f"runs cold). Contact andrew@gamakon.ai.", flush=True)
            return
        except ValueError as e:
            print(f"!! INVALID LICENCE at {path}: {e} — cache tier DISABLED.",
                  flush=True)
            return
        left = (self.expiry - time.time()) / 86400.0
        if left <= 0:
            print(f"!! LICENCE EXPIRED ({self.customer}) — cache tier DISABLED; "
                  f"the proxy still serves, every prefill runs cold.", flush=True)
        else:
            note = "  ** RENEW SOON **" if left < 30 else ""
            print(f"[faxl] licensed to {self.customer}; {left:.0f} days remaining"
                  f"{note}", flush=True)

    def entitled(self):
        """True while the cache tier may serve hits. Checked per request."""
        if self._gate is None:
            return False
        live = self._gate.licence_status()[0]
        try:  # persist the ratchet so a clock rollback cannot revive a lapse
            os.makedirs(os.path.dirname(self._hw_file), exist_ok=True)
            with open(self._hw_file, "w") as f:
                f.write(str(self._gate.high_water()))
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            pass
        return live

    def status(self):
        live, cust, exp, remaining, action = (
            self._gate.licence_status() if self._gate else (False, "", 0, 0, "unlicensed"))
        return {"licensed": live, "customer": cust, "expiry": exp,
                "days_remaining": round(remaining / 86400.0, 1), "on_expiry": action}


class _AlreadyThere(Exception):
    """The collection is already on disk; skip CreateCollection.

    A private control-flow signal, not an error: it keeps the "do not create"
    decision in one place instead of duplicating the reopen bookkeeping in
    both the probe and the exception handler.
    """


class Index:
    def __init__(self):
        import ultradim
        # PERSISTENT store in the user-managed FAXL_DB dir (not a temp dir), so a
        # restart reloads the same keys+blobs. meta.json holds row_id -> (blob, cpos,
        # key) so we can re-upsert every key into a fresh collection on startup.
        os.makedirs(DB_DIR, exist_ok=True)
        self.db = ultradim.UltraDim(DB_DIR)
        # LOOKUP VIA ULTRADIM (CR EXACT_IDENTITY_GET, wheel 0.3.5): a keyed
        # checkpoint carries its lookup digest as a `content_key` keyword facet, and
        # the lookup is GetUltradimV23RowByContentKey — a walk-free, pre-settle
        # identity get, so the shared DB owns the lookup (not a node-local dict) and
        # the analytics arms see live cache traffic. If the wheel predates the RPC,
        # warn loudly and serve from the local index (resilience over refusal);
        # a clean DB not-found still consults the local dict (sub-1025 entries).
        self._has_identity_get = "GetUltradimV23RowByContentKey" in set(self.db.capabilities())
        if not self._has_identity_get:
            print("!! ULTRADIM WHEEL LACKS GetUltradimV23RowByContentKey — need "
                  ">=0.3.5; lookups fall back to the LOCAL exact dict (node-local, "
                  "no cross-machine share, no analytics). Upgrade the wheel.", flush=True)
        self.built = False
        self.rows = 0        # next UltraDim row id — KEYED entries only (the CSR
                             # requires contiguous row_ids, so exact-only entries
                             # must never consume one)
        self.meta = {}       # UltraDim row_id -> (blob path, cpos)
        self.rid_tok = {}    # UltraDim row_id -> tok file (for byte-confirm on an
                             # identity-get hit; rid comes back from the RPC, tok
                             # is what confirm needs)
        self.fork_blobs = {} # phash -> {blob, cpos, bytes, last_resume} (FORK blobs only)
        self.exact = {}      # prefix hash -> (blob, cpos, tok_file) — LOCAL fallback
                             # + sub-KEY_MIN_TOKENS exact-only lookups (v1 has no
                             # decoupled id space, so those can't move to UltraDim)
        # BLOB++ (AM 2026-09-01): durable per-blob usage — {phash(str):
        # [hits, last_hit_ts]} replayed from an append-only fsync'd JSONL,
        # compacted at boot. Feeds scored eviction (evict_scored_over_cap):
        # never-hit blobs score by file mtime, so stale demo blobs rank
        # first the moment the store fills.
        self.usage_path = os.path.join(BLOB_DIR, "usage.jsonl")
        self.usage = load_usage(self.usage_path)
        if self.usage:
            compact_usage(self.usage_path, self.usage)
        # PERSISTENCE (VERIFIED 2026-08-10): UltraDim persists points AND the trellis
        # index to disk (udv23_csr/keys/registry/trellis). A discriminating probe on
        # the reopened Canada store returned score 1.000 on a stored key with NO
        # re-upsert and NO rebuild (candidates_pooled=34, trellis phase=done). So a
        # reopen must NOT re-run CreateCollection (errors "already registered") and
        # must NOT re-upsert (would duplicate every persisted row). It restores only
        # the row->blob map from meta.json and marks the index already built.
        # REOPEN IS A STATE QUESTION, NOT AN EXCEPTION-MESSAGE ONE.
        #
        # This used to be decided purely by whether CreateCollection raised
        # "already registered". It does raise that, correctly (verified on a
        # scratch store: boot 1 creates, boot 2 raises) -- but the registry
        # JSON it checks is one small file among several, and a store can
        # reach a state where the registry is gone while the CSR, keys and
        # payloads are all intact. Create then SUCCEEDS over 11 committed CSR
        # rows, reopened stays False, and the repair path below re-upserts at
        # the old row ids -- which the CSR refuses:
        #
        #   row_ids must extend the CSR contiguously from n_committed=11
        #   (expected row_ids[0]=11, got Some(3))
        #
        # The proxy then cannot start at all. Measured on the live store
        # 2026-09-20; every other file was 09:40 and the registry alone 09:59,
        # written by the very boot that died.
        #
        # So ask the store what it holds FIRST. CollectionInfo is already
        # consulted two lines further down for the seed-drift guard; calling
        # it up here costs one RPC and makes the answer come from persisted
        # state rather than from the wording of an error.
        reopened = False
        try:
            info0 = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
            if info0.get("registered") or info0.get("success"):
                reopened = True
        except RuntimeError:
            pass          # not there, or the RPC is absent: fall through to Create
        try:
            if reopened:
                raise _AlreadyThere()
            self._call("CreateUltradimV23Collection", {
                "name": FAMILY, "source_dim": SOURCE_DIM, "projection_dim": D_PROJ, "seeds": SEEDS,
                "sparse_substrate": True, "max_nnz_per_row": 4 * 512 + 400,
                "matrix_type": "rademacher_hash_v1", "projection_mode": "formula", "trellis_only": True,
                # NB: `window` is NOT a CreateCollection field (0.3.4 rejects it) — it
                # lives on the build/settle path only. See `_ensure_built`.
            })
        except _AlreadyThere:
            pass                 # CollectionInfo already told us; Create skipped
        except RuntimeError as e:
            msg = str(e).lower()
            if "already" in msg or "registered" in msg or "exist" in msg:
                reopened = True  # collection + its points already persisted on disk
            else:
                raise
        if reopened:
            # DRIFT GUARD: the persisted family's seeds are the source of truth for
            # an existing collection (UltraDim hashes them into family identity). If
            # the configured SEEDS no longer match what this store was created with,
            # every key we compute would silently mismatch — fail loud, never serve.
            try:
                info = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
                stored = list(info.get("seeds") or [])
                if stored and stored != list(SEEDS):
                    raise SystemExit(
                        f"!! SEED DRIFT: collection {FAMILY!r} was created with "
                        f"seeds {stored} but configured seeds are {list(SEEDS)}. A "
                        f"mismatch silently invalidates every key. Set FAXL_SEEDS to "
                        f"{stored} to serve this store, or use a fresh FAXL_DB.")
            except RuntimeError as e:
                # FIX D7: don't block startup on the guard itself, but say so — a
                # skipped guard means seed drift would go undetected this run.
                print(f"!! SEED-DRIFT GUARD SKIPPED (CollectionInfo unavailable: {e}) "
                      f"— serving without drift protection", flush=True)
        self._reload(reopened)

    def _reload(self, reopened):
        """Restore the row_id -> (blob, cpos) map from a prior run's meta.json.

        UltraDim persists the vectors + trellis itself (VERIFIED), so we do NOT
        re-upsert on a reopen — we only rebuild the in-process meta map keyed by the
        SAME row ids the store persisted (meta rows carry their `row`). On a FRESH
        collection (no persisted points) meta.json shouldn't exist; if it does (e.g.
        the store dir was cleared but meta.json left behind) we re-upsert to repair."""
        if not os.path.exists(META_PATH):
            return
        try:
            saved = json.load(open(META_PATH))
        except Exception:
            return
        # NAMESPACE BOOT FILTER: only rows stamped with THIS namespace load.
        # Legacy (pre-namespace) rows load only under FAXL_NS_ADOPT=1, which
        # stamps them once (meta rewrite + resolve-record rename below) —
        # after that boot they are ordinary `mine` rows. Foreign rows are
        # skipped untouched: they belong to another model/config sharing the
        # store, which is now the supported shape.
        mine, legacy, foreign = split_meta_rows(saved, NS)
        if foreign:
            print(f"namespace: {len(foreign)} row(s) belong to OTHER "
                  f"namespaces sharing this store — not loaded here", flush=True)
        adopted = []
        if legacy and NS_ADOPT:
            adopted = legacy
            print(f"namespace: ADOPTING {len(legacy)} legacy row(s) into "
                  f"{NS.digest_hex()[:16]} (FAXL_NS_ADOPT=1, one-time stamp)",
                  flush=True)
        elif legacy:
            print(f"!! namespace: {len(legacy)} legacy (pre-namespace) row(s) "
                  f"NOT loaded — set FAXL_NS_ADOPT=1 on ONE boot to stamp them "
                  f"as {NS.digest_hex()[:16]} if this store was written by "
                  f"exactly this model+config", flush=True)
        loaded, maxrid = 0, -1
        # Repair bookkeeping: the CSR takes row ids only in an unbroken run, so
        # track the next id it will accept and record what had to be left out.
        repair_next, repair_skipped = 0, []
        for row in sorted(mine + adopted,
                          key=lambda r: (r.get("row") is None, r.get("row") or 0)):
            blob, cpos, rid = row["blob"], row["cpos"], row["row"]
            if not os.path.exists(blob):
                continue  # blob gone: leave the persisted point, just don't map it
            # EXACT TIER: rows written by this version carry phash+tok; restore the
            # hash index. Pre-exact-tier rows (no phash) stay retrieval-only — they
            # can never hit, because a hit requires the token confirm.
            if row.get("phash") and row.get("tok") and os.path.exists(row["tok"]):
                self.exact[row["phash"]] = (blob, cpos, row["tok"])
                if row.get("fork"):
                    self.fork_blobs[row["phash"]] = {
                        "blob": blob, "cpos": cpos,
                        "bytes": os.path.getsize(blob), "last_resume": 0.0}
            if rid is not None:
                # keyed entry: a persisted UltraDim point exists at this rid
                if not reopened and row.get("idx") is not None:
                    # FRESH COLLECTION BUT META PRESENT -> repopulate at their rid.
                    #
                    # THIS ONLY WORKS FOR A CONTIGUOUS 0..n RUN. The CSR requires
                    # row_ids to extend it contiguously, and eviction leaves holes
                    # (measured: rids [3, 6, 7, 10] after four evictions), so a
                    # store that has ever evicted cannot be repaired this way. It
                    # is skipped rather than attempted, because attempting it
                    # raises out of __init__ and the proxy does not start at all
                    # -- losing the whole cache to repair part of it.
                    #
                    # The blobs are NOT lost by skipping: the exact tier above is
                    # keyed by phash in-process and still resumes. What is lost is
                    # the fuzzy retrieval arm for these rows, which is why it says
                    # so out loud rather than failing silently.
                    if rid == repair_next:
                        self._call("UpsertUltradimV23Points", {
                            "name": FAMILY, "batch": {"row_ids": [rid],
                                "sparse_vectors": [{"indices": row["idx"],
                                                    "values": row["val"]}]}})
                        repair_next += 1
                    else:
                        repair_skipped.append(rid)
                self.meta[rid] = (blob, cpos)
                if row.get("tok"):
                    self.rid_tok[rid] = row["tok"]
                maxrid = max(maxrid, rid)
            loaded += 1
        if repair_skipped:
            print(f"!! REPAIR PARTIAL: {len(repair_skipped)} row(s) at "
                  f"non-contiguous ids {repair_skipped[:8]}"
                  f"{'…' if len(repair_skipped) > 8 else ''} could not be "
                  f"restored to the retrieval index — the CSR only takes an "
                  f"unbroken run and eviction left holes. Their blobs still "
                  f"serve exact hits; only fuzzy retrieval is reduced. A fresh "
                  f"FAXL_DB rebuilds cleanly.", flush=True)
        # A ROW ID BELONGS TO THE CSR, NOT TO A NAMESPACE.
        #
        # maxrid above is computed only from `mine + adopted`, because those
        # are the rows this namespace maps. But the UltraDim collection is
        # SHARED by every namespace in the store, and its CSR accepts a new
        # row only as a contiguous extension of what it already holds. A row
        # written by another model still occupies its id.
        #
        # So a store whose rows belong to a PREVIOUS namespace restored zero
        # checkpoints, set next_rid=0, and the first keyed write asked the CSR
        # for row 0 while it held five:
        #
        #   faxl index restored 0 checkpoints … next_rid=0, ns=43eb1b47
        #   RuntimeError: row_ids must extend the CSR contiguously from
        #     n_committed=5 (expected row_ids[0]=5, got Some(0))
        #
        # It surfaced as "the whiteboard app crashes the proxy": the failure
        # is on the checkpoint WRITE, after a correct answer was generated, so
        # only requests long enough to earn a keyed entry (>= KEY_MIN_TOKENS)
        # hit it -- chat was short enough to escape, and camera-roll writes
        # deduped against entries that already existed.
        #
        # Counting every persisted row, foreign included, is what keeps the
        # next id ahead of the CSR. Foreign rows are still NOT loaded or
        # mapped -- this only reserves the ids they occupy.
        for _row in foreign:
            _rid = _row.get("row")
            if _rid is not None:
                maxrid = max(maxrid, int(_rid))
        # next new row must not collide with a persisted id
        self.rows = maxrid + 1
        self.built = reopened  # persisted trellis is already built; fresh needs settle
        if adopted:
            # ONE-TIME adoption rewrite: stamp the rows in meta.json and move
            # each legacy resolve record to its scoped name with ns fields —
            # the next boot sees ordinary `mine` rows and no legacy path runs.
            # (Legacy UltraDim facet rows keep their bare content key and are
            # no longer findable via the scoped RPC — the local dict and the
            # renamed resolve records carry single-node serving; new writes
            # re-key normally. Honest cost, logged here once.)
            for row in adopted:
                row["ns_digest"] = NS.digest_hex()
                row["ns"] = NS.as_dict()
                ph = row.get("phash")
                old = os.path.join(TOKENS_DIR, f"{ph}.meta.json")
                if ph and os.path.exists(old):
                    try:
                        m = json.load(open(old))
                        m["ns"] = NS.as_dict()
                        m["ns_digest"] = NS.digest_hex()
                        new = os.path.join(TOKENS_DIR, _rec_name(ph))
                        tmpf = new + ".tmp"
                        with open(tmpf, "w") as fo:
                            json.dump(m, fo)
                        os.replace(tmpf, new)
                        os.remove(old)
                    except Exception as e:  # noqa: BLE001
                        print(f"!! NS ADOPT: resolve record {ph} not "
                              f"migrated ({e})", flush=True)
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(saved, fo)
            os.replace(tmp, META_PATH)
            print(f"namespace: adoption complete — {len(adopted)} row(s) "
                  f"stamped; legacy shared-DB facet rows are superseded by "
                  f"local serving", flush=True)
        print(f"faxl index restored {loaded} checkpoints from {META_PATH} "
              f"(reopened={reopened}, next_rid={self.rows}, built={self.built}, "
              f"ns={NS.digest_hex()[:16]})")

    def _persist(self, rid, idx, val, blob, cpos, phash=None, tok=None, fork=False):
        """Append one checkpoint to meta.json (rewrite whole file — small, JSON).
        idx/val may be None (exact-tier-only entry below KEY_MIN_TOKENS)."""
        cur = []
        if os.path.exists(META_PATH):
            try:
                cur = json.load(open(META_PATH))
            except Exception:
                cur = []
        cur.append({"row": rid, "idx": idx, "val": val, "blob": blob, "cpos": cpos,
                    "phash": phash, "tok": tok, "fork": bool(fork),
                    "ns_digest": NS.digest_hex(), "ns": NS.as_dict()})
        tmp = META_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cur, f)
        os.replace(tmp, META_PATH)

    def _call(self, rpc, obj):
        r = self.db.call_json(rpc, json.dumps(obj))
        o = json.loads(r) if isinstance(r, str) and r.strip()[:1] in "{[" else r
        if isinstance(o, dict) and o.get("error_message"):
            raise RuntimeError(f"{rpc}: {o['error_message']}")
        return o

    def add(self, idx, val, blob_path, cpos, phash=None, tok=None, fork=False):
        """Register one checkpoint. idx/val may be None: an exact-tier-only entry
        (checkpoint below KEY_MIN_TOKENS — no similarity key is written, the lookup
        needs only phash+tok). MEASURED (2026-08-09): in the EMBEDDED wheel a
        post-settle upsert is NOT searchable until a re-settle (the doc flags
        embedded-vs-gRPC parity as ungraded; verified: a row added after settle is
        invisible to search). So a keyed add marks the index dirty; `_ensure_built`
        re-settles once, lazily, before the next search — but callers should BATCH
        their adds so only ONE settle runs per request, not one per checkpoint."""
        rid = None
        if idx is not None:
            # keyed entry: consumes the next CONTIGUOUS UltraDim row id
            rid = self.rows
            batch = {"row_ids": [rid], "sparse_vectors": [{"indices": idx, "values": val}]}
            # LOOKUP DIGEST as a `content_key` keyword facet (CR EXACT_IDENTITY_GET):
            # GetUltradimV23RowByContentKey matches this exactly, walk-free and
            # pre-settle, so the lookup lives in the shared DB. Written only on keyed
            # (>= KEY_MIN_TOKENS) rows — v1 has no decoupled id space, so a
            # content_key point IS a cosine row; sub-1025 exact-only lookups stay
            # local (see plan-ultradim-lookup-restore.md, CR Q2).
            if phash is not None:
                # NAMESPACE-SCOPED content key: ns_hash + prefix hash, so one
                # shared DB serves many models/configs without same-tokenizer
                # collisions. (We deliberately do NOT seed the polynomial hash
                # with the namespace — that would break audit-row comparability
                # and every existing store; the scope is a routing prefix.)
                batch["facets"] = [{"fields": {"content_key": {"kind": {"KeywordValue": scoped_key(NS, phash)}}}}]
            self._call("UpsertUltradimV23Points", {"name": FAMILY, "batch": batch})
            self.meta[rid] = (blob_path, cpos)
            if tok is not None:
                self.rid_tok[rid] = tok
            self.rows += 1
            self.built = False  # dirty until re-settled (embedded-wheel requirement)
        if phash is not None:
            self.exact[phash] = (blob_path, cpos, tok)
            if fork:
                self.fork_blobs[phash] = {"blob": blob_path, "cpos": cpos,
                                          "bytes": (os.path.getsize(blob_path)
                                                    if os.path.exists(blob_path) else 0),
                                          "last_resume": time.time()}
            # FIX D2 (CODE-TRUTH): content-addressed resolve record on the STORE, so
            # a checkpoint written by one node is resolvable by any node that shares
            # the store — the lookup no longer depends on the writer's in-memory maps.
            # Write-once. NAMESPACE-SCOPED filename + the full canonical tuple and
            # digest inside, so a cross-store load can run verify_before_load.
            # (Token files stay UNSCOPED: same token ids = identical content,
            # deliberately shared across namespaces — write-once property kept.)
            rec = os.path.join(TOKENS_DIR, _rec_name(phash))
            if not os.path.exists(rec):
                tmp = rec + ".tmp"
                # PRIVACY: `tok` is the verbatim token-id prefix (system message
                # included) and decodes straight back to the prompt. It is
                # REQUIRED — the byte-confirm compares against it, which is what
                # makes a hit exact rather than a hash guess. So it cannot be
                # removed, but it MUST NOT be world-readable: 0600, written via
                # an fd opened with that mode (never chmod-after-write, which
                # leaves a readable window). Reported by a tester, 2026-09-11:
                # these files shipped 0644.
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w") as f:
                    json.dump({"blob": blob_path, "cpos": cpos, "tok": tok,
                               "ns": NS.as_dict(),
                               "ns_digest": NS.digest_hex()}, f)
                os.replace(tmp, rec)
        self._persist(rid, idx, val, blob_path, cpos, phash, tok, fork=fork)  # survive restart
        return rid

    def known_positions(self):
        """Sorted set of every position where this node knows a blob exists —
        grid AND fork (rev-2 fix: fork blobs must be findable by the lookup
        probe or they are write-only)."""
        out = {cpos for (_b, cpos, _t) in self.exact.values()}
        out.update(cpos for (_b, cpos) in self.meta.values())
        return sorted(out, reverse=True)

    def live_fork_gb(self):
        return sum(f["bytes"] for f in self.fork_blobs.values()) / 1e9

    def touch_resume(self, phash):
        f = self.fork_blobs.get(phash)
        if f:
            f["last_resume"] = time.time()

    def record_hit(self, phash):
        """blob++ (AM 2026-09-01): count every confirmed resume, durably.
        One fsync'd line per warm request (~ms on a ~1 s request)."""
        now = time.time()
        p = str(phash)
        hits, _ = self.usage.get(p, (0, 0.0))
        self.usage[p] = [hits + 1, now]
        try:
            append_usage(self.usage_path, p, now)
        except OSError as e:
            LOG_FAILURES.append(f"usage append {p}: {e}")
            print(f"!! USAGE LOG APPEND FAILED ({e}) — hit counts will "
                  f"under-count after a restart", flush=True)

    def _usage_score(self, phash, blob, now):
        """Eviction score = time-since-last-hit / (1 + hits): oldest
        unpopular first. A never-hit blob's 'last hit' is its file mtime.

        The formula lives in store_lifecycle.usage_score so the exo-line
        store scores identically — two copies of a retention rule drift, and
        a store that evicts by a different rule from the one the console
        reports is a store nobody can reason about.
        """
        return usage_score(self.usage, phash, blob, now)

    def evict_scored_over_cap(self, cap_gb, protect=frozenset()):
        """STORE-WIDE scored eviction (AM 2026-09-01, replacing the refuse-
        writes-at-cap guard that froze out live traffic behind stale blobs).
        Runs AFTER a write lands: evict highest-score blobs until the store
        fits the cap. NOTHING is permanent — grid blobs included. `protect`
        holds phashes never to evict (this request's writes + its resume
        point). Returns the victim list."""
        now = time.time()
        victims = []
        while _STORE_BYTES[0] > cap_gb * 1e9:
            pool = [(ph, ent[0]) for ph, ent in self.exact.items()
                    if ph not in protect]
            if not pool:
                print(f"!! STORE over {cap_gb} GB cap but nothing evictable "
                      f"(all {len(self.exact)} entries protected) — "
                      f"overshoot accepted", flush=True)
                break
            ph, blob = max(pool, key=lambda t: self._usage_score(t[0], t[1], now))
            self.remove_blob(ph)
            victims.append(ph)
        return victims

    def remove_blob(self, phash):
        """Supersession/eviction delete: index rows FIRST, then the blob file
        (a raced request falls cold via the guarded load, never 500s). Token
        files stay (content-addressed, shared). Handles ANY blob — fork,
        grid, anchor (grid lost its permanence when scored store-wide
        eviction landed, AM 2026-09-01)."""
        f = self.fork_blobs.pop(phash, None)
        ent = self.exact.pop(phash, None)
        # Purge the UltraDim rid bookkeeping too: a stale meta[rid] makes
        # identity_get return None WITHOUT falling back to the live maps
        # (:642-648), so an evicted-then-rewritten prefix would miss forever.
        # The persisted UltraDim row itself stays (no delete RPC); with the
        # rid unmapped, a found-row lookup falls through to the resolve
        # record / exact dict, which the rewrite repopulates.
        _blob_now = f["blob"] if f else (ent[0] if ent else None)
        for rid in [r for r, (b, _c) in self.meta.items() if b == _blob_now]:
            self.meta.pop(rid, None)
            self.rid_tok.pop(rid, None)
        self.usage.pop(str(phash), None)
        rec = os.path.join(TOKENS_DIR, _rec_name(phash))
        _legacy_rec = os.path.join(TOKENS_DIR, f"{phash}.meta.json")
        if not os.path.exists(rec) and os.path.exists(_legacy_rec):
            rec = _legacy_rec   # pre-namespace record: same delete discipline
        # M0 loud-failure sweep (F11): store mutations must never fail
        # silently — a stale record/blob/meta row resurrects deleted state
        # or leaks bytes, and silence hides it (Rules: fail-open is design,
        # a swallowed bug is not). Removal proceeds (the delete itself is
        # still wanted) but every failure is printed and surfaced in /health.
        try:
            if os.path.exists(rec):
                os.remove(rec)
        except OSError as e:
            LOG_FAILURES.append(f"remove resolve record {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: resolve record {rec} not "
                  f"removed ({e}) — a shared-store node may still serve the "
                  f"deleted checkpoint", flush=True)
        blob = f["blob"] if f else (ent[0] if ent else None)
        if blob:
            try:
                _STORE_BYTES[0] -= (os.path.getsize(blob)
                                    if os.path.exists(blob) else 0)
                os.remove(blob)
            except OSError as e:
                LOG_FAILURES.append(f"remove blob {phash}: {e}")
                print(f"!! STORE MUTATION FAILED: blob {blob} not removed "
                      f"({e}) — orphan bytes leak against the cap", flush=True)
        # meta.json: rewrite without this row
        try:
            cur = [r for r in json.load(open(META_PATH))
                   if r.get("phash") != phash]
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(cur, fo)
            os.replace(tmp, META_PATH)
        except Exception as e:
            LOG_FAILURES.append(f"meta rewrite on remove {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: meta.json rewrite ({e}) — a "
                  f"restart will RESURRECT removed row {phash}", flush=True)

    def evict_forks_over_cap(self, cap_gb):
        """FAXL_FORK_MAX_LIVE_GB: evict least-recently-RESUMED fork blobs
        (fork blobs only; grid blobs untouched). Returns the VICTIM phash
        list (M0: the audit trail records each eviction; len() is the
        count callers report)."""
        evicted = []
        while self.live_fork_gb() > cap_gb and self.fork_blobs:
            victim = min(self.fork_blobs, key=lambda k: self.fork_blobs[k]["last_resume"])
            self.remove_blob(victim)
            evicted.append(victim)
        return evicted

    def resolve_from_store(self, phash):
        """FIX D2: resolve phash -> (blob, cpos, tok) from the shared store's
        content-addressed record, independent of this node's in-memory maps.
        Returns None if no record, or if the blob/token files are missing.
        This is the CROSS-STORE path, so verify_before_load runs here — P1's
        caller: a record from another namespace is refused loudly, never
        served (the C3 test's per-row digest + tuple check)."""
        rec = os.path.join(TOKENS_DIR, _rec_name(phash))
        try:
            with open(rec) as f:
                m = json.load(f)
        except Exception:
            return None
        try:
            _ns_verify(NS, m.get("ns"), m.get("ns_digest"))
        except Exception as e:
            print(f"!! NAMESPACE REFUSED on resolve record "
                  f"{os.path.basename(rec)}: {e} — serving cold", flush=True)
            return None
        blob, cpos, tokf = m.get("blob"), m.get("cpos"), m.get("tok")
        if not blob or not tokf or not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def exact_lookup(self, phash):
        """Exact-tier candidate: (blob, cpos, tok_file) for this prefix hash, or None.
        The CALLER must confirm by token compare before resuming (belt and braces
        against the ~2^-61 hash collision; confirm outcome is logged per hit)."""
        ent = self.exact.get(phash)
        if ent is None:
            return None
        blob, cpos, tokf = ent
        if not os.path.exists(blob) or not tokf or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def identity_get(self, content_key):
        """Exact identity lookup via UltraDim (CR EXACT_IDENTITY_GET, wheel 0.3.5):
        GetUltradimV23RowByContentKey is a walk-free, pre-settle keyword-facet get.
        Returns (blob, cpos, tok_file) for an exact hit, else None — same shape as
        exact_lookup, so the caller's byte-confirm is unchanged. Falls back to the
        local exact dict when the wheel lacks the RPC. The rid->tok/(blob,cpos) maps
        are the proxy's own row bookkeeping (the RPC returns only the row id)."""
        if not self._has_identity_get:
            return self.exact_lookup(content_key)
        try:
            # Callers pass the RAW prefix hash; the namespace scope is applied
            # HERE (and only here) so every fallback below keeps using the raw
            # hash against the process-local maps — a scoped key leaking into
            # exact_lookup would silently miss on every fallback.
            r = self._call("GetUltradimV23RowByContentKey",
                           {"name": FAMILY, "content_key": scoped_key(NS, content_key)})
        except RuntimeError as e:
            # FIX D8: never fail the request on a get error, but never be silent either.
            print(f"!! IDENTITY-GET RPC ERROR ({e}) — falling back to the local "
                  f"exact dict for this lookup", flush=True)
            return self.exact_lookup(content_key)
        if not r.get("found"):
            # FIX D1 (CODE-TRUTH): sub-KEY_MIN_TOKENS checkpoints are exact-tier-only
            # (no content_key row in UltraDim), so a clean not-found MUST still
            # consult the local dict or those checkpoints are write-only forever.
            # FIX D2: then the shared store's resolve record (another node's write).
            return self.exact_lookup(content_key) or self.resolve_from_store(content_key)
        rid = r.get("row_id")
        ent = self.meta.get(rid)
        tokf = self.rid_tok.get(rid)
        if ent is None or not tokf:
            # rid known to the shared DB but not to this node: FIX D2 — resolve from
            # the store's content-addressed record (cross-node hit), then local dict.
            return self.resolve_from_store(content_key) or self.exact_lookup(content_key)
        blob, cpos = ent
        if not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    # (cosine walk / trellis search surface removed 2026-08-15 — dead code on
    #  the serving path, audit D9; measured wrong-prefix hits 308/420 at
    #  SNAP 0.6. Record: git history + docs/boxcar-ladder-result.md.)



def _image_digest(url, _cache={}):
    """One image's identity: sha256 of its DECODED RGB PIXELS, truncated.

    Falls back to hashing the URL text when the bytes cannot be decoded --
    which covers the two cases the proxy must not treat as an image:

      * A REMOTE URL. exo fetches http(s) image urls itself
        (api/adapters/chat_completions.py:49); this proxy deliberately does
        NOT. Fetching an attacker-supplied URL from inside the proxy is a
        request-forgery vector, and the proxy sits in front of a cluster. The
        url text is then the only identity available, which is honest: two
        requests naming the same url share a key, and nothing is claimed
        about the picture.
      * An UNDECODABLE or oversized image. Refusing the request outright
        would be worse than caching conservatively -- the backend may well
        handle a format Pillow does not.

    Either fallback can only cause a MISS, never a wrong hit: a different
    identity string simply keys elsewhere.

    Memoised because a client that sends the same photo in several turns of
    one conversation would otherwise decode it once per turn.
    """
    if url in _cache:
        return _cache[url]
    digest = None
    if url.startswith("data:"):
        # data:image/jpeg;base64,<payload> — the same prefix exo strips.
        _, _, payload = url.partition(",")
        if payload:
            try:
                digest = hash_image_bytes(base64.b64decode(payload,
                                                           validate=False))
            except (ImageDecodeError, ValueError, TypeError) as e:
                print(f"faxl: image not decodable ({e}) — keying on the "
                      f"request text instead", flush=True)
    if digest is None:
        digest = hashlib.sha256(url.encode()).hexdigest()
    out = digest[:16]
    if len(_cache) < 512:      # bounded: this is a per-process convenience
        _cache[url] = out
    return out


def _flatten_multimodal(messages):
    """Make OpenAI multimodal content templatable, and say what was in it.

    A multimodal message carries a LIST of parts -- text and image_url -- where
    a chat template expects a string. Passed through as-is the template
    stringifies the list, the image is silently discarded, and the model is
    handed the wreckage: measured, a 30,000-character base64 JPEG arrived at
    exo as 21 tokens and the model answered "1234567890" from nothing.

    Returns (messages_for_template, n_images). The images themselves are NOT
    dropped -- on the exo path the ORIGINAL body is forwarded, images intact,
    and this projection exists only so the ladder has token ids to hash. An
    image is represented by a stable placeholder so two requests with the same
    picture hash alike and a different picture does not.
    """
    out, n_images = [], 0
    for m in messages:
        c = m.get("content")
        if not isinstance(c, list):
            out.append(m)
            continue
        parts = []
        for part in c:
            if not isinstance(part, dict):
                parts.append(str(part))
                continue
            kind = part.get("type")
            if kind == "text":
                parts.append(part.get("text", ""))
            elif kind in ("image_url", "input_image", "image"):
                n_images += 1
                url = ""
                if isinstance(part.get("image_url"), dict):
                    url = part["image_url"].get("url", "")
                else:
                    url = str(part.get("image_url") or part.get("url") or "")
                # Identify the image by a digest, never by its bytes: the
                # ladder hashes this text, and a megabyte of base64 in the
                # prefix would be hashed on every request for nothing.
                #
                # THE DIGEST IS OF DECODED PIXELS where we can decode them.
                # The same photograph as HEIC and as JPG, or re-encoded at a
                # different quality, is the SAME PICTURE to the model and must
                # be the same cache key; hashing the container makes that a
                # miss. This is the one definition of image identity across
                # every backend -- exo computes the same hash the same way
                # (engines/mlx/vision.py:712), which is asserted by
                # tests/test_media_regions.py against exo's own decoder.
                digest = _image_digest(url)
                parts.append(f"<image:{digest}>")
            else:
                parts.append(json.dumps(part, sort_keys=True))
        mm = dict(m)
        mm["content"] = "\n".join(x for x in parts if x)
        out.append(mm)
    return out, n_images


_IMAGE_ATOM_RE = re.compile(r"<image:[0-9a-f]{8,}>")


def _image_regions(tok, ids):
    """The pictures this prompt carries, as MediaRegions.

    The mlx line's counterpart to media_regions.find_regions. That function
    looks for a run of PAD ids, which is the shape exo sees because exo
    expands the picture before faxl reads the stream. Here the ladder hashes
    the image to an <image:digest> text atom and the expansion happens later,
    inside the backend, so the run to find is textual -- but the RESULT is the
    same type, carrying the same pixel digest, so everything downstream
    (entry_key, truncate_to_first_mismatch) is shared with exo rather than
    reimplemented.

    The digest in the atom IS the content hash: _image_digest computes it from
    decoded RGB pixels, by the same definition exo uses, so the two backends
    agree on what "the same picture" means.
    """
    spans = _atom_spans(tok, ids)
    out = []
    for (a, b), digest in spans:
        out.append(MediaRegion(digest, a, b))
    return out


def _atom_spans(tok, ids):
    """[start, end) of every <image:digest> atom in the token stream.

    THE LADDER'S OWN RULE, FINALLY ENFORCED. Every comment and test in this
    codebase says a checkpoint boundary may fall before or after a picture
    but never inside it -- "half an image is not a smaller image, it is a
    different one". Nothing enforced it on the write path.

    Measured on the camera roll: the atom occupied tokens 1780..1798 and the
    grid snap put a checkpoint at 1792, twelve tokens INSIDE it. The stored
    blob therefore contained one photograph's digest, and the NEXT photograph
    resumed from it: 13 tokens prefilled, the vision tower never run, and a
    confident description of a picture nobody had looked at. That is a wrong
    answer served fast, which is the worst thing a cache can do.

    Found by decoding, not by scanning for a token id: the atom is not one
    token and not a fixed id run ("<image:a07175b9b60dc5b2>" is 18 ids on
    Qwen3-VL and the pieces change with the digest), so the only reliable
    way to locate it is to decode token by token and track offsets.
    """
    try:
        pieces = [tok.decode([int(t)]) for t in ids]
    except Exception:                                    # noqa: BLE001
        return []          # cannot decode: caller keeps the plain grid
    text = "".join(pieces)
    # character offset -> token index
    starts, off = [], 0
    for piece in pieces:
        starts.append(off)
        off += len(piece)
    spans = []
    for m in _IMAGE_ATOM_RE.finditer(text):
        a, b = m.start(), m.end()
        # first token whose text begins at or before `a`, and the token after
        # the one containing b-1
        i = 0
        while i + 1 < len(starts) and starts[i + 1] <= a:
            i += 1
        j = i
        while j < len(starts) and starts[j] < b:
            j += 1
        # ((start_token, end_token), the digest inside the atom)
        spans.append(((i, j), m.group(0)[len("<image:"):-1]))
    return spans


def _clear_of_atoms(pos, spans):
    """Move `pos` back to the start of any image atom it lands inside.

    Before the picture, never through it -- see the call site for why the
    atom specifically, and why this is not safe_depth(). The atom's start is
    also the position that pays: preamble and question are identical across
    photographs, so a checkpoint there is shared by every one of them.
    """
    for (a, b), _digest in spans:
        if a < pos < b:
            return a
    return pos


def _resolve_model_dir(model_id):
    """Where this model's TOKENIZER files live — HF cache, else exo's own dir.

    Two stores exist on a machine running both: faxl loads through the
    HuggingFace cache, while exo downloads into ~/.exo/models and names the
    directory `org--repo`. A model exo fetched itself is therefore invisible to
    hf_repo_to_path, which raises LocalEntryNotFoundError rather than looking
    further — measured on Qwen3-VL, which exo had and the HF cache did not.

    Only the small files are needed here (tokenizer, chat template, config):
    the WEIGHTS stay where they are and run in exo's engine, never in this
    process. Checking both places costs nothing and means faxl can front any
    model exo can run.
    """
    try:
        return hf_repo_to_path(model_id)
    except Exception as hf_err:   # noqa: BLE001 — try exo's dir before giving up
        alt = os.path.expanduser(os.path.join(
            os.environ.get("EXO_MODELS", "~/.exo/models"),
            str(model_id).replace("/", "--")))
        if os.path.isfile(os.path.join(alt, "config.json")):
            print(f"   (not in the HF cache; using exo's copy at {alt})",
                  flush=True)
            # A Path, not a str: mlx_lm joins with `/` on whatever it is given.
            from pathlib import Path as _Path
            return _Path(alt)
        # THIRD: fetch the tokenizer ourselves. On a remote backend the
        # weights belong to exo and may not be placed yet (exo downloads on
        # first request), but faxl needs the small files NOW to start. Making
        # the operator pre-fetch by hand is a step a machine can do: it is a
        # handful of JSON files, seconds, and no weights. Explicitly
        # ignore_patterns the weights so a stray glob can never pull 70 GB
        # into this process's cache.
        #
        # Opt out with FAXL_NO_TOKENIZER_FETCH=1 for a strictly offline box,
        # where the right answer is to fail loudly rather than reach out.
        if os.environ.get("FAXL_NO_TOKENIZER_FETCH") != "1":
            try:
                from huggingface_hub import snapshot_download
                print(f"   (tokenizer not local; fetching the small files for "
                      f"{model_id} — weights stay with the backend)", flush=True)
                got = snapshot_download(
                    str(model_id),
                    allow_patterns=["*.json", "tokenizer*", "*.txt", "*.model",
                                    "merges.txt", "vocab*"],
                    ignore_patterns=["*.safetensors", "*.bin", "*.gguf", "*.pt"],
                )
                if os.path.isfile(os.path.join(got, "config.json")):
                    from pathlib import Path as _Path
                    print(f"   (tokenizer at {got})", flush=True)
                    return _Path(got)
            except Exception as fetch_err:  # noqa: BLE001 — fall through
                print(f"!! tokenizer fetch failed ({type(fetch_err).__name__}: "
                      f"{fetch_err})", flush=True)
        raise RuntimeError(
            f"cannot find {model_id!r} in the HuggingFace cache ({hf_err}) or "
            f"at {alt}, and could not fetch its tokenizer. faxl needs the "
            f"tokenizer files only — the weights stay with the backend — so "
            f"fetch the model, or point EXO_MODELS at the directory holding "
            f"it.") from hf_err


def _trimmable_from_config(cfg, model_path):
    """Is this model's cache trimmable (pure-KV), without loading weights?

    `can_trim_prompt_cache` is `all(c.is_trimmable())` over cache INSTANCES,
    and make_prompt_cache builds those from the model's structure alone. So a
    skeleton model instantiated from config.json gives the same answer as the
    real thing at a fraction of the cost.

    FAILS CLOSED. Any doubt returns False, because the two errors are not
    symmetric: a wrong True runs trim_prompt_cache against a hybrid's
    ArraysCache -- one rolled-up recurrent tensor with no position to trim to
    -- which is the corruption class this project has been bitten by twice. A
    wrong False merely forgoes the trim-on-load optimisation.
    """
    try:
        from mlx_lm.utils import _get_classes
        mc, ma = _get_classes(config=cfg)
        skeleton = mc(ma.from_dict(cfg))
        trimmable = can_trim_prompt_cache(make_prompt_cache(skeleton))
        del skeleton
        return bool(trimmable)
    except Exception as e:  # noqa: BLE001 — never fatal, never optimistic
        print(f"!! could not determine the cache family without weights "
              f"({type(e).__name__}: {e}) — assuming HYBRID (not trimmable), "
              f"which is the safe answer", flush=True)
        return False


# trust_remote_code: Kimi ships a custom tiktoken tokenizer (tokenization_kimi.py) that
# must execute to load. This means ANY model repo loaded here runs its own tokenizer
# code — only point the model at repos you trust. Off by default on mlx; opt in
# via FAXL_TRUST_REMOTE_CODE=1 (Granite doesn't need it). On exo it follows the
# config's exo.trust_remote_code (on by default, as faxl_exo_up.sh always set
# it: Kimi's tokenizer is code), which FAXL_TRUST_REMOTE_CODE also overrides.
_TRUST = (EXO["trust_remote_code"] if _BACKEND_NAME == "exo"
          else os.environ.get("FAXL_TRUST_REMOTE_CODE", "0") == "1")
if _BACKEND_NAME in _MLX_BACKENDS:
    from mlx_lm.utils import hf_repo_to_path
else:
    hf_repo_to_path = _mlx_only("mlx_lm.utils.hf_repo_to_path")

# VISION MODELS LOAD THROUGH mlx_vlm, AND THE CHOICE IS MADE BY THE MODEL.
#
# mlx_lm.load will happily load Qwen3-VL and give you a working TEXT model: it
# binds the language half and never touches the vision tower. Nothing fails, so
# an image arrives as a placeholder and the reply is invented rather than read.
# For OCR that is the worst failure available -- confident, well formatted, and
# entirely fabricated.
#
# So the loader is selected by config.json's model_type, not by an env var. A
# customer who installs faxl and runs the shipped Qwen3-VL gets vision because
# the model has it, without knowing that mlx_lm and mlx_vlm are different
# libraries. That is the whole point of the console.
def _is_vision_model(model_id):
    """True when the repo declares a vision tower. Read from config.json
    rather than guessed from the name: 'VL' in a repo id is a convention, and
    a convention is not a contract."""
    try:
        import json as _json
        import pathlib
        # load_config() divides its argument as a Path, so a str raises
        # TypeError -- and this used to swallow that and return False, which
        # meant a LOCAL vision model silently loaded as a text model and
        # invented its answers. Read config.json directly: it is one file, and
        # failing to detect vision must never be the quiet outcome.
        # An absolute path to a model directory is already the answer.
        # _resolve_model_dir maps a HUB ID into the cache, and given a path it
        # mangles it into "--Users--andrewmorgan--..." and then fails -- which
        # this used to swallow, loading a vision model as text.
        d = pathlib.Path(os.path.expanduser(str(model_id)))
        if not (d / "config.json").is_file():
            d = pathlib.Path(_resolve_model_dir(model_id))
        cfg = _json.loads((d / "config.json").read_text())
    except Exception as e:  # noqa: BLE001
        print(f"!! could not read config.json for {model_id} ({e}); "
              f"assuming text-only — images will be REFUSED, not invented",
              flush=True)
        return False
    return bool(cfg.get("vision_config")
                or str(cfg.get("model_type", "")).endswith("_vl")
                or any("ForConditionalGeneration" in a
                       for a in (cfg.get("architectures") or [])))


VISION = False
# NO MODEL YET (2026-09-22, "batteries not included"). _LOAD_FROM is None when
# the weights are not on this Mac: the proxy still comes up, because it serves
# the console -- the page where the person chooses a model and starts the
# download. model/tok/PROCESSOR stay None and /v1 answers 503 saying so; the
# console does not touch them.
model = tok = PROCESSOR = None
if _LOAD_FROM is None:
    print("serving the console only: no model loaded. Pick one in the "
          "console and faxl will fetch it.", flush=True)
elif _BACKEND_NAME == "mlx":
    VISION = _is_vision_model(_LOAD_FROM)
    if VISION:
        # The processor carries the tokenizer AND the image preprocessing. The
        # rest of this proxy only ever wants the tokenizer -- apply_chat_template
        # for the ladder, stop ids for the decode -- so it is unwrapped here and
        # the processor kept beside it for the pixels.
        print(f"loading {MODEL} (vision) ...")
        from mlx_vlm import load as _vlm_load
        model, PROCESSOR = _vlm_load(_LOAD_FROM)
        tok = getattr(PROCESSOR, "tokenizer", PROCESSOR)
        print(f"vision model ready: images are read, not placeheld", flush=True)
    else:
        print(f"loading {MODEL} ...")
        model, tok = load(_LOAD_FROM,
                          tokenizer_config={"trust_remote_code": _TRUST})
        PROCESSOR = None
else:
    # NO WEIGHTS ON THIS PATH. Execution happens on the backend, so loading the
    # model here would mean holding a second copy of it — and for a 700GB Kimi
    # K3 across a Thunderbolt cluster it defeats the entire point: the reason
    # to use a cluster is that the model does NOT fit on one machine.
    #
    # The TOKENIZER is still required: this proxy applies the chat template,
    # derives the stop ids, and hands token ids to the ladder.
    print(f"loading {MODEL} tokenizer only (backend={_BACKEND_NAME}) ...")
    if _BACKEND_NAME not in _MLX_BACKENDS:
        # NON-MLX TOKENIZER (2026-09-25, stage B). This used to raise: the
        # tokenizer-only path below is mlx_lm's, so a vllm proxy could not get
        # a tokenizer at all and refused at boot. transformers is the loader
        # every non-mlx backend already depends on (vLLM requires it), and the
        # STOP-ID RULE IS THE SAME ONE the mlx path uses -- the union of the
        # model's eos ids, read from the tokenizer and from config.json --
        # because a missing eos runs every reply to max_tokens.
        from transformers import AutoConfig, AutoTokenizer
        _mpath = _resolve_model_dir(MODEL)
        tok = AutoTokenizer.from_pretrained(_mpath,
                                           trust_remote_code=_TRUST)
        _hf_cfg = AutoConfig.from_pretrained(_mpath,
                                             trust_remote_code=_TRUST)
        # eos_token_id is an int on most families and a LIST on some (Qwen3
        # ships [151645, 151643]). Both shapes are folded into the same set
        # the mlx branch builds, and tok.faxl_eos_ids is set so the shared
        # STOP_IDS block below reads one field on every backend.
        _eos = set()
        for _src in (getattr(tok, "eos_token_id", None),
                     getattr(_hf_cfg, "eos_token_id", None)):
            if _src is None:
                continue
            _eos.update(int(x) for x in
                        (_src if isinstance(_src, (list, tuple, set)) else [_src]))
        if not _eos:
            raise RuntimeError(
                f"faxl_proxy: {MODEL} exposes no eos token id through "
                f"transformers (tokenizer or config). Serving would run every "
                f"reply to max_tokens, so boot refuses instead.")
        # NOT `tok.eos_token_ids = ...`: transformers intercepts writes to any
        # eos_token* attribute and raises "Cannot set a non-string value as the
        # eos_token" for a list (transformers 5.17, measured 2026-09-26 -- the
        # proxy would not boot at all on a bare install). The shared STOP_IDS
        # block below reads faxl_eos_ids first, then mlx_lm's own
        # eos_token_ids, so one field name per line and no write to a guarded
        # attribute.
        tok.faxl_eos_ids = sorted(_eos)
        model = None
        PROCESSOR = None
        # TRIM CAPABILITY follows the cache engine, not the model family: the
        # mlx probe below builds a skeleton mlx model, which does not exist
        # here. CACHE.can_trim() is the authority (see the CACHE seam).
        TRIMMABLE = False
    else:
        from mlx_lm.utils import hf_repo_to_path, load_config, load_tokenizer
        _mpath = _resolve_model_dir(MODEL)
        _cfg = load_config(_mpath)
        # eos_token_ids MUST be passed. mlx_lm's load() does
        #   load_tokenizer(path, cfg, eos_token_ids=config.get("eos_token_id"))
        # and that kwarg is the ONLY source of tok.eos_token_ids. Omitting it
        # silently drops Kimi's <|im_end|> (163586) and every reply then runs to
        # max_tokens — the exact failure the STOP_IDS comment below records.
        tok = load_tokenizer(_mpath, {"trust_remote_code": _TRUST},
                             eos_token_ids=_cfg.get("eos_token_id", None))
        # THE CHAT TEMPLATE MAY LIVE IN ITS OWN FILE, and load_tokenizer does
        # not look there.
        #
        # Qwen3-VL ships `chat_template.json` beside `tokenizer_config.json`
        # rather than inside it -- both the 4B and the 32B do. On the mlx path
        # mlx_vlm.load() picks it up, so single-machine works; the exo path
        # loads the tokenizer ALONE, gets no template, and every request died
        # in apply_chat_template with "Cannot use chat template functions
        # because tokenizer.chat_template is not set". Measured: eight
        # photographs, eight HTTP 500s, on a cluster that was serving fine.
        #
        # Read it ourselves when it is missing. A template is the model's own
        # prompt format -- getting it wrong is silent corruption, not an
        # error -- so this only ever FILLS AN ABSENCE and never overrides a
        # template the tokenizer already carries.
        _inner = getattr(tok, "_tokenizer", tok)
        if not getattr(_inner, "chat_template", None):
            for _name in ("chat_template.json", "chat_template.jinja"):
                _tpl = os.path.join(str(_mpath), _name)
                if not os.path.isfile(_tpl):
                    continue
                try:
                    _raw = open(_tpl).read()
                    _val = (json.loads(_raw).get("chat_template")
                            if _name.endswith(".json") else _raw)
                except (OSError, ValueError) as _e:
                    print(f"!! {_name} unreadable ({_e}) — the chat template "
                          f"is still missing", flush=True)
                    continue
                if _val:
                    _inner.chat_template = _val
                    print(f"chat template loaded from {_name}", flush=True)
                    break
            else:
                print("!! NO CHAT TEMPLATE for this model: neither the "
                      "tokenizer config nor chat_template.json carries one, "
                      "so every request will fail in apply_chat_template",
                      flush=True)
        model = None
        # No pixels are processed here: on the cluster path the ORIGINAL body is
        # forwarded with its images intact and exo's runner does the vision work.
        PROCESSOR = None
# STOP IDS: stop on the UNION of the model's eos ids. Granite terminates on
# tok.eos_token_id; Kimi's chat turns end on <|im_end|> (163586), exposed via
# tok.eos_token_ids, NOT tok.eos_token_id ([EOS]=163585). Missing it runs every
# reply to max_tokens. Union is correct for both families.
STOP_IDS = set()
# NO TOKENIZER ON THE NO-MODEL PATH. _LOAD_FROM is None when the weights are
# not on this Mac ("batteries not included"): model/tok/PROCESSOR stay None by
# design, the console comes up, and /v1 answers 503. Everything below reads the
# tokenizer, so it has to be skipped rather than run against None -- it was
# crashing three lines after printing "serving the console only", which meant
# the proxy could not start AT ALL on a machine with no model. Measured 2026-09-22:
# a bare `import faxl_proxy` with no weights raised
# AttributeError: 'NoneType' object has no attribute 'eos_token_id'.
if tok is None:
    print("no tokenizer: stop ids stay empty until a model is chosen.",
          flush=True)
elif tok.eos_token_id is not None:
    STOP_IDS.add(int(tok.eos_token_id))
# eos_token_ids is a COLLECTION on mlx_lm's tokenizer and sometimes a bare int
# on the one a VLM processor carries. Iterating an int raises, and it raised at
# import -- the proxy would not start at all on the shipped vision model.
# faxl_eos_ids is what the transformers branch above sets (it may not write to
# eos_token_ids -- transformers guards that name); eos_token_ids is mlx_lm's.
_eos_extra = (getattr(tok, "faxl_eos_ids", None)
              or getattr(tok, "eos_token_ids", None))
if isinstance(_eos_extra, int):
    _eos_extra = [_eos_extra]
STOP_IDS |= {int(x) for x in (_eos_extra or ())}
# AND THE MODEL'S OWN config.json, WHICH IS THE ONLY COMPLETE SOURCE ON THE
# VISION PATH. `eos_token_ids` is an mlx_lm tokenizer field; a VLM processor
# carries a plain HuggingFace tokenizer, which has eos_token_id (one id) and
# not eos_token_ids (the set). Qwen3-VL declares [151645, 151643] -- <|im_end|>
# AND <|endoftext|> -- and the union above saw only the first.
#
# The cost of missing one is not a slow reply, it is a WRONG one: generation
# runs past the end of the answer, and the replies that came back were pure
# newlines, or the model's next turn talking to itself. Measured on the camera
# roll: "None of the above." and 200 tokens of "\n" where the model had in
# fact answered correctly and then kept going.
# generation_config.json FIRST: it is where a Qwen3-VL keeps its stop ids.
# config.json's eos_token_id is null on this model, so reading only that finds
# nothing. And take the directory straight from MODEL when MODEL already IS a
# directory -- _resolve_model_dir only speaks repo ids and raises on a path,
# which is how this lookup silently found no config at all.
_mdir = (MODEL if os.path.isdir(str(MODEL)) else
         _LOAD_FROM if os.path.isdir(str(_LOAD_FROM)) else None)
if _mdir is None:
    try:
        _mdir = str(_resolve_model_dir(MODEL))
    except Exception:                                    # noqa: BLE001
        _mdir = None
for _fname in ("generation_config.json", "config.json"):
    if not _mdir:
        break
    try:
        with open(os.path.join(_mdir, _fname)) as _fh:
            _cfg_eos = json.load(_fh).get("eos_token_id")
    except OSError:
        continue
    if isinstance(_cfg_eos, int):
        _cfg_eos = [_cfg_eos]
    if _cfg_eos:
        STOP_IDS |= {int(x) for x in _cfg_eos}
if not STOP_IDS and tok is not None:
    # Only fatal when a model IS loaded: with no stop ids every reply would run
    # to max_tokens, which is a broken serve rather than a slow one. With NO
    # model there is nothing to serve yet -- /v1 answers 503 and the console is
    # the point -- so exiting here would take the console down with it, and the
    # console is where the person picks the model that fixes this.
    raise SystemExit(
        "!! NO STOP IDS. Every reply would run to max_tokens. Check the "
        "model's config.json eos_token_id and its tokenizer.")
print(f"stop ids: {sorted(STOP_IDS)}")
# THE SAMPLER IS THE mlx BACKEND'S, so it is built only there. This was a
# module-level call for every backend and therefore a hard refusal at boot on
# vllm (measured 2026-09-26 on a bare Linux install: "mlx_lm make_sampler is an
# mlx-only path"). Both consumers are mlx-only too -- the warmup below and
# LocalMlxBackend's constructor -- so a vllm process needs no sampler at all:
# vLLM takes its sampling from SamplingParams inside the engine.
sampler = make_sampler(temp=0.0) if _BACKEND_NAME in _MLX_BACKENDS else None
# Phase A (plan-kv-model-support rev 4.1): capability detection at boot —
# pure-KV models (KVCache) are trimmable, hybrids (ArraysCache) are not;
# can_trim_prompt_cache detects the family automatically.
if model is not None:
    _cap_probe = make_prompt_cache(model)
    TRIMMABLE = can_trim_prompt_cache(_cap_probe)
    del _cap_probe
elif _LOAD_FROM is None:
    # NO MODEL AT ALL. _cfg and _mpath are never bound on this path -- they are
    # set by the tokenizer-only branch -- so the skeleton probe below cannot
    # run. Nothing reads TRIMMABLE until a request arrives, and none can be
    # served until a model is chosen, so the safe default stands until restart.
    TRIMMABLE = False
elif _BACKEND_NAME in _MLX_BACKENDS:
    # No weights loaded, but the ladder still branches on this. The cache
    # FAMILY is fixed by the architecture, not the parameters:
    # make_prompt_cache only asks the model for make_cache()/len(layers), so a
    # skeleton built from config.json alone answers identically. mlx allocates
    # lazily, so nothing is materialised.
    #
    # GUARDED BY BACKEND (2026-09-26): _cfg and _mpath are set only by the mlx
    # tokenizer branch, and the skeleton probe builds an mlx model, so this
    # raised NameError at boot on vllm -- measured on a bare Linux install.
    TRIMMABLE = _trimmable_from_config(_cfg, _mpath)
else:
    # Off mlx, trimmability is a property of the cache ENGINE, not of the
    # model's architecture. It is declared per backend here rather than read
    # from CACHE, because CACHE is built further down (it needs prefill and
    # generate, which are defined after this point) and TRIMMABLE is read by
    # the ladder at boot. The two are asserted against each other where CACHE
    # is chosen, so a disagreement cannot survive startup.
    TRIMMABLE = _TRIMMABLE_BY_BACKEND[_BACKEND_NAME]

# ---- MAIN-THREAD WARM-UP — REQUIRED, DO NOT REMOVE.
# mlx_lm binds lazy per-module state to a THREAD-LOCAL MLX stream on the first
# forward pass. Werkzeug hands every request a fresh thread, so without this the
# first forward runs on an arbitrary worker thread and llama-family models raise
# "RuntimeError: There is no Stream(gpu, 1) in current thread" on EVERY request
# (100% reproducible, and reproducible outside faxl). Hybrid archs (granite-4.0-h,
# the default) happen not to trip it, which is why it hid for so long.
# One real forward pass here binds that state on the main thread, and every
# worker thread afterwards succeeds. Reported by a tester on llama arch,
# 2026-09-11.
def _warmup():
    t0 = time.time()
    try:
        # THE LANGUAGE HALF, not the wrapper. A vision model's __call__ returns
        # a LanguageModelOutput, which generate_step subscripts and cannot --
        # so the warm-up failed, the GPU stream was never bound on the main
        # thread, and EVERY request then died with "no Stream(gpu, N) in
        # current thread". The warm-up exists precisely to prevent that, and
        # its own error message said so; it just could not run.
        # Same wrapper the backend uses, for the same reason: a VLM's language
        # model returns LanguageModelOutput and generate_step subscripts it.
        _m = getattr(model, "language_model", model)
        if _m is not model:
            from faxl.engine.backends import LocalMlxBackend as _LMB
            _m = _LMB._logits_only(_m)
        _c = make_prompt_cache(_m)
        for _t, _ in zip(generate_step(mx.array([1]), _m, prompt_cache=_c,
                                       sampler=sampler), range(1)):
            pass
        mx.eval([_x.state for _x in _c if hasattr(_x, "state")])
        del _c
        print(f"warm-up: main-thread forward pass ok "
              f"({(time.time()-t0)*1000:.0f} ms)", flush=True)
    except Exception as e:
        # Loud, never fatal: a warm-up failure must not stop the proxy serving,
        # but a silent skip would re-hide the thread-local-stream bug.
        print(f"!! warm-up forward pass FAILED ({type(e).__name__}: {e}) — "
              f"llama-family models may raise 'no Stream(gpu, N) in current "
              f"thread' on every request", flush=True)


if model is not None:
    _warmup()
else:
    # No local forward pass on this path, so the thread-local-stream binding
    # the warm-up exists to force cannot matter here.
    print("warm-up skipped: no local model on this backend", flush=True)
licence = Licence()
probe = Probe()
SEEDS = probe.seeds()   # single source: Rust resolve_seeds() (FAXL_SEEDS-overridable)
# ---- Namespace identity — BEFORE the index, which keys the store with it.
# (KV plan rev 4.1 register #76/130: recorded on every metrics row from day
# one — unretrofittable.) config_hash covers every namespace-defining knob:
# the SKILL's "NOT safe to change" list (seeds + the checkpoint grid) IS this
# hash's field list — a changed knob is a different namespace, so it can
# never silently serve a store written under the old one.
from faxl.engine.ns_identity import NamespaceIdentity, scoped_key, split_meta_rows
_cfg_hash = hashlib.sha256(json.dumps(
    {"seeds": list(SEEDS), "width": WIDTH, "d_proj": D_PROJ,
     "family": FAMILY, "ckpt_every": CKPT_EVERY, "ckpt_ratio": CKPT_RATIO},
    sort_keys=True).encode()).hexdigest()[:16]
NS = NamespaceIdentity(
    tenant_domain=TENANT, model=MODEL, revision=REVISION, backend="mlx",
    dtype=DTYPE, cache_format="mlx_safetensors_v1", config_hash=_cfg_hash)
NS_ADOPT = os.environ.get("FAXL_NS_ADOPT", "0") == "1"


def _rec_name(phash):
    """Namespace-scoped resolve-record filename (colon → underscore: the
    canonical scoped key is a facet string, filenames stay portable)."""
    return scoped_key(NS, phash).replace(":", "_") + ".meta.json"


def _ns_verify(expected, stored_tuple, stored_digest):
    """verify_before_load with hard-missing fields treated as refusal (a
    record with no recorded identity must never load across the store)."""
    from faxl.engine.ns_identity import verify_before_load, NamespaceError
    if not stored_tuple or not stored_digest:
        raise NamespaceError("resolve record carries no namespace identity")
    return verify_before_load(expected, stored_tuple, stored_digest)
print(f"projection seeds (from Rust): {SEEDS}", flush=True)
index = Index()
# boot scan for the total-store cap (one pass; then incremental)
try:
    os.makedirs(BLOB_DIR, exist_ok=True)
    _STORE_BYTES[0] = sum(
        os.path.getsize(os.path.join(BLOB_DIR, f))
        for f in os.listdir(BLOB_DIR) if f.endswith(".safetensors"))
    print(f"store bytes at boot: {_STORE_BYTES[0]/1e9:.2f} GB "
          f"(cap {STORE_CAP_GB} GB)", flush=True)
except OSError as _e:
    print(f"!! store-cap boot scan failed: {_e}", flush=True)

forkidx = None
NVME_BPS = float(os.environ.get("FAXL_NVME_BPS", "0")) or None
PREFILL_TPS = {"ewma": float(os.environ.get("FAXL_PREFILL_TPS", "250"))}
OBSERVED = {"max_blob": 0}
# ---- TRIM-ON-LOAD (KV plan Phase B; pure-KV models only) -------------------
# Under TRIMMABLE the stream index runs for D* discovery even with fork off
# (B.3: the trim path needs D*), fork BLOB WRITES are suppressed (the anchor
# dominates every fork write), and the chain's live tail anchor supersedes
# its ancestor every turn (B.4) — chain identity via trim_lookup.AnchorRegistry
# (inherited on every extension turn, i.e. head migration is UNCONDITIONAL).
ANCHORS = None
LOAD_FIT = {"intercept_ms": 8.4, "slope_ms_per_gb": 38.7}
try:
    LOAD_FIT = json.load(open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data", "write-cost.json")))["fits"]["load"]
except Exception as _e:
    print(f"!! load-fit table unreadable ({_e}) — using committed defaults",
          flush=True)
if TRIMMABLE:
    from faxl.engine.trim_lookup import AnchorRegistry, economic_gate as trim_economic_gate, resolve_candidate
    ANCHORS = AnchorRegistry(os.path.join(DB_DIR, "anchor_state.json"))
if FORK or TRIMMABLE:
    from faxl.engine.fork_index import ForkIndex as _FI
    if forkidx is None:
        forkidx = _FI(STREAMS_DIR, os.path.join(DB_DIR, "fork_state.json"))
if FORK:
    from faxl.engine.fork_index import (extension_gate, divergence_gate,
                            blob_bytes_predicted, model_slope)
    # BOOT VALIDATION (plan v1.5): an unmeasured model must fail HERE, not
    # mid-request — blob_bytes_predicted/model_slope now raise for unknowns.
    from faxl.engine.fork_index import model_slope as _ms_check
    _ms_check(MODEL)   # raises UnknownModelCurve with instructions if unmeasured
    if NVME_BPS is None:
        # measure the store's write bandwidth once (32 MB, fsync'd) — the
        # extension gate's write-cost side uses a MEASURED number, not a guess.
        _probe_path = os.path.join(BLOB_DIR, ".nvme_probe")
        _t0 = time.time()
        with open(_probe_path, "wb") as _f:
            _f.write(b"\0" * (32 << 20))
            _f.flush(); os.fsync(_f.fileno())
        NVME_BPS = (32 << 20) / max(time.time() - _t0, 1e-6)
        os.remove(_probe_path)
        print(f"fork: measured store write bandwidth {NVME_BPS/1e9:.2f} GB/s", flush=True)
    print(f"fork-point checkpointing ON (gates {'OFF — demo' if FORK_GATES_OFF else 'rev-5'}; "
          f"ratio={FORK_TIME_RATIO} amort={FORK_AMORT} cap={FORK_MAX_LIVE_GB}GB)", flush=True)
# ---- M0 audit trail construction (after SEEDS/index so identity is real) ---
AUDIT = None
STRAT_CFG = {k: v for k, v in _STRAT_KW.items() if k != "count_of"}
# Namespace identity: constructed above, BEFORE the index (it keys the store).
if AUDIT_DIR:
    from faxl.engine.audit_trail import AuditTrail
    try:
        from faxl.engine.fork_index import _curve as _m0_curve
        _m0_flat, _m0_slope = _m0_curve(MODEL)
        _curve_meta = {"flat": _m0_flat, "slope": _m0_slope}
    except Exception:
        _curve_meta = None   # unmeasured model: FORK boot check governs
    AUDIT = AuditTrail(AUDIT_DIR, SESSION_LABEL, NS, collect=COLLECT, meta={
        "emitter": "proxy", "dstar_semantics": "fork_only",
        "strategy": {"name": STRATEGY, "config": STRAT_CFG},
        "fork_enabled": FORK, "gates_off": FORK_GATES_OFF,
        "fork_cap_gb": FORK_MAX_LIVE_GB, "evict_cap_bytes": None,
        "workload": WORKLOAD, "model_curve": _curve_meta,
        "gate_constants": {"time_ratio": FORK_TIME_RATIO, "amort": FORK_AMORT},
        "nocache": NOCACHE, "store_fresh": len(index.exact) == 0,
        "trimmable": TRIMMABLE, "load_fit": LOAD_FIT,
        "collect": COLLECT})
    print(f"M0 audit trail ON -> {AUDIT.path} (collect={COLLECT}, "
          f"session={SESSION_LABEL}, ns={NS.digest_hex()[:16]})", flush=True)

# ---- TELEMETRY (the collection contract; docs/proxy-console-telemetry-plan.md) --
# One transaction -> one designed protobuf event stream (START sync/fail-closed,
# COMPLETION async). The console reads this, NOT the incidental metrics JSONL.
# FAXL_TELEMETRY=0 opts out (byte-identical legacy behaviour otherwise).
from faxl.engine import faxl_telemetry as _tel
_BACKEND_ENUM = {"mlx": _tel.pb.MLX, "hf": _tel.pb.HF,
                 "vllm": _tel.pb.VLLM, "exo": _tel.pb.EXO}.get(
                     _BACKEND_NAME, _tel.pb.MLX)
TELEMETRY = None
if os.environ.get("FAXL_TELEMETRY", "1") == "1":
    _tpath = os.environ.get("FAXL_TELEMETRY_WAL",
                            os.path.expanduser("~/.faxl/telemetry/events.bin"))
    if _tel.is_volatile_path(_tpath):
        # The collection log is the product's evidence base, not scratch.
        print(f"!! FAXL_TELEMETRY_WAL {_tpath} is a VOLATILE path — history "
              f"will evaporate on reboot; set a durable path", flush=True)
    TELEMETRY = _tel.Telemetry(
        _tel.FileWal(_tpath), _tel.TenantKeyer(),
        backend=_BACKEND_ENUM, model=MODEL,
        boot_id=os.environ.get("FAXL_BOOT_ID", uuid.uuid4().hex[:12]),
        determinism_config_id=os.environ.get("FAXL_DETERMINISM_CONFIG", ""))
    print(f"telemetry ON -> {_tpath} (backend="
          f"{_tel.pb.Backend.Name(_BACKEND_ENUM)}, model={MODEL})", flush=True)
    # Console: the aggregator reads the SAME WAL (refresh-on-read), and the
    # blueprint serves /console + /api/* from it. index_stats is injected so the
    # console never imports serving internals.
    from faxl.engine import faxl_aggregator as _agg
    from faxl.engine import faxl_console as _console
    _AGGREGATOR = _agg.Aggregator()

    def _index_stats():
        """What the console reports as the cache.

        WHICH STORE depends on the backend, and getting it wrong is not
        cosmetic. On the exo path the checkpoints live in ExoStore; the
        mlx-line `index.exact` is empty by construction, so reading it showed
        "CACHE ENTRIES 0" on a page that simultaneously reported an 84% hit
        rate, with 50 checkpoints and 39 GB on disk. A console that
        contradicts itself is worse than one that says nothing.
        """
        try:
            store = getattr(PREFILL_SERVER, "faxl_store", None)
            if store is not None:
                out = {"available": True, "entries": len(store),
                       "used_gb": round(store.live_bytes() / 1e9, 2),
                       "limit_gb": round(float(store.cap_gb), 2)}
                # STORE-WIDE, in a nested try of its own. The namespace hash
                # folds in the model id, so blobs written by another model
                # match 0 of this store's entries and vanish from the numbers
                # above — 56 GB on disk reported as "0 / 60 GB". These keys
                # let the console say "this model" and "all models"
                # separately. A failure here must cost only the extra keys:
                # the tile still has to show the per-model figures rather than
                # collapsing to available:false.
                try:
                    rows = store.store_rows()
                    out["store_entries"] = sum(r["entries"] for r in rows)
                    out["store_used_gb"] = round(
                        sum(r["bytes"] for r in rows) / 1e9, 2)
                    out["namespaces"] = [
                        {"ns_hash": r["ns_hash"], "model": r["model"],
                         "entries": r["entries"],
                         "used_gb": round(r["bytes"] / 1e9, 2)}
                        for r in rows]
                except Exception:  # noqa: BLE001
                    pass
                return out
            return {"available": True, "entries": len(index.exact),
                    "rows": index.rows, "live_fork_gb": round(index.live_fork_gb(), 3)}
        except Exception:  # noqa: BLE001
            return {"available": False}

    def _blob_stats():
        """One row per cached blob for the console's recency/frequency
        scatter: hits + last_used from the durable blob++ usage log; a
        never-hit blob reports its file mtime (same convention as the
        eviction score, so the plot shows exactly what eviction sees).

        WHICH STORE, exactly as _index_stats decides it. On the exo path the
        blobs live in ExoStore and `index.exact` is EMPTY BY CONSTRUCTION, so
        reading it returned {"blobs":[],"count":0} under a heading promising
        one dot per stored blob. The identical bug _index_stats was fixed for;
        the row shape is the same either way, so shape_blobs is unchanged.
        """
        out = []
        try:
            store = getattr(PREFILL_SERVER, "faxl_store", None)
            if store is not None:
                return store.blob_rows()
            for ph, (blob, cpos, _tok) in list(index.exact.items()):
                hits, last = index.usage.get(str(ph), (0, 0.0))
                try:
                    st = os.stat(blob)
                except OSError:
                    continue   # blob gone mid-iteration (eviction race)
                nbytes = st.st_size
                if not last:
                    last = st.st_mtime
                out.append({"phash": str(ph), "hits": hits, "last_used": last,
                            "bytes": nbytes, "pos": cpos})
        except Exception:  # noqa: BLE001 — console must never 500 the proxy
            pass
        return out

    _host_for_bind = os.environ.get("FAXL_HOST", "127.0.0.1")
    app.register_blueprint(_console.create_console(
        aggregator=_AGGREGATOR, wal_path=_tpath, backend_name=_tel.pb.Backend.Name(
            _BACKEND_ENUM).lower(), model=MODEL,
        bind=f"{_host_for_bind}:{os.environ.get('FAXL_PORT', '8767')}",
        index_stats=_index_stats, licence_status=lambda: licence.status(),
        blob_stats=_blob_stats,
        # T-0004: let the console install a pasted key. The wheel's set_licence
        # is passed in rather than imported by the console, which imports
        # nothing from this module; LICENCE_FILE goes with it so a FAXL_LICENCE
        # override this process saw is the one the console writes through to.
        licence_apply=(faxl.set_licence if faxl is not None else None),
        licence_file=LICENCE_FILE,
        # The exo path's hits and stores are counted by the PrefillServer
        # thread, not the WAL. Handed over so the cluster card reads the
        # proxy's own numbers instead of reaching into this module for them.
        prefill_counts=lambda: dict(EXO_COUNTS),
        # parse_licence validates WITHOUT installing, so a lapsed key is
        # refused before it can displace a working entitlement. getattr because
        # older wheels do not have it; apply_key falls back to repairing after
        # the fact when it is None.
        licence_parse=(getattr(faxl, "parse_licence", None)
                       if faxl is not None else None),
        verify_condition=lambda: ("mlx: byte-identical, greedy (unconditional on "
                                  "this backend)")))
    print(f"console ON -> /console + /api/* (reads {_tpath})", flush=True)
else:
    # Loud, not silent: with telemetry off there is no collection, so /console
    # and /api/* are not registered and will 404 — say so at boot.
    print("console OFF — telemetry disabled (FAXL_TELEMETRY=0); /console and "
          "/api/* are not served", flush=True)

# Normalised client label — NEVER the raw UA/X-Client (linkable PII). A small
# allowlist maps known clients to a coarse category; everything else is "other".
_CLIENT_LABELS = ("openclaw", "hermes", "curl", "wget", "python-requests",
                  "claude", "lynx", "w3m")

_PROJECT_RE = __import__("re").compile(r"[^a-z0-9._-]+")


def _project_tag(raw):
    """Normalise a caller-supplied project/team tag, or "" for none.

    A caller controls this string and it lands in DURABLE analytics, so it is
    bounded and normalised at the edge exactly as client_label is: unbounded
    caller text in a telemetry column turns the analytics store into a log of
    whatever anyone felt like sending, and a tag is for grouping, not for
    carrying payload.

    Lowercased, anything outside [a-z0-9._-] collapsed to '-', 48 chars.
    """
    if not raw:
        return ""
    tag = _PROJECT_RE.sub("-", str(raw).strip().lower()).strip("-.")
    return tag[:48]


def _client_label(ua):
    if not ua:
        return ""
    low = ua.lower()
    for name in _CLIENT_LABELS:
        if name in low:
            return name
    return "other"

# ---- fork-point singletons (plan rev 5) ----
os.makedirs(BLOB_DIR, exist_ok=True)
# 0700: the token records inside decode back to verbatim prompts (see the
# write site) — the directory must not be traversable by other local users.
os.makedirs(TOKENS_DIR, mode=0o700, exist_ok=True)
try:
    os.chmod(TOKENS_DIR, 0o700)   # tighten a dir left 0755 by an older build
except OSError as e:
    print(f"!! could not tighten {TOKENS_DIR} to 0700 ({e}) — token records "
          f"may be readable by other local users", flush=True)


def _tighten_existing_tokens():
    """Re-mode token records written 0644 by an older build. A store built
    before this fix is full of world-readable verbatim prompts; tightening new
    writes alone would leave that history exposed. Cheap (a stat per file) and
    idempotent."""
    fixed = failed = 0
    try:
        with os.scandir(TOKENS_DIR) as it:
            for e in it:
                if not e.is_file():
                    continue
                try:
                    if e.stat().st_mode & 0o077:
                        os.chmod(e.path, 0o600)
                        fixed += 1
                except OSError:
                    failed += 1
    except OSError:
        return
    if fixed or failed:
        print(f"token records re-moded to 0600: {fixed} tightened"
              + (f", {failed} FAILED" if failed else ""), flush=True)


_tighten_existing_tokens()
print(f"faxl proxy ready (exact-tier lookup; ckpt base {CKPT_EVERY}, "
      f"keys >= {KEY_MIN_TOKENS} tok; exact entries: {len(index.exact)}).")


# Kimi tool-call grammar (special tokens; ids 163595-163599 in the Kimi tokenizer;
# decode round-trip verified). Call id looks like "functions.read_file:0" — the
# function name sits between "functions." and the trailing ":<idx>".
_KIMI_CALL = re.compile(
    r"<\|tool_call_begin\|>\s*(?P<id>[^<]+?)\s*<\|tool_call_argument_begin\|>"
    r"\s*(?P<args>\{.*?\})\s*<\|tool_call_end\|>", re.DOTALL)
_KIMI_SECTION = re.compile(
    r"<\|tool_calls_section_begin\|>.*?(?:<\|tool_calls_section_end\|>|\Z)", re.DOTALL)
_GRANITE_CALL = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
# Ling / bailing_hybrid family: one call per `<tool_call>` block, NOT json —
#   <tool_call>NAME\n<arg_key>k</arg_key>\n<arg_value>v</arg_value>...</tool_call>
# (values are bare strings; there may be several key/value pairs, and several
# <tool_call> blocks in one turn). Distinguished from Granite's `<tool_call>{json}`
# by the leading NAME token before any '{' — checked in parse_tool_calls order.
_LING_CALL = re.compile(r"<tool_call>\s*([^\s<{][^\n<]*?)\s*\n(.*?)</tool_call>", re.DOTALL)
_LING_ARG = re.compile(r"<arg_key>\s*(.*?)\s*</arg_key>\s*<arg_value>\s*(.*?)\s*</arg_value>", re.DOTALL)
# Nemotron family: a JSON ARRAY of {name, arguments} inside <TOOLCALL> tags
# (rendered exemplar verified from the chat template's own instructions).
_NEMOTRON_CALL = re.compile(r"<TOOLCALL>\s*(\[.*?\])\s*</TOOLCALL>", re.DOTALL)


def parse_tool_calls(text):
    """(tool_calls, content) from any known family's markup; empty if none."""
    m = _NEMOTRON_CALL.search(text)
    if m:
        calls = []
        try:
            arr = json.loads(m.group(1))
        except json.JSONDecodeError:
            arr = []
        for tc in arr if isinstance(arr, list) else []:
            args = tc.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"_raw": args}
            calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                          "function": {"name": tc.get("name", ""),
                                       "arguments": json.dumps(args)}})
        if calls:
            content = _NEMOTRON_CALL.sub("", text).strip()
            return calls, content
    calls = []
    for m in _KIMI_CALL.finditer(text):
        raw_id = m.group("id").strip()
        name = raw_id.split("functions.")[-1].rsplit(":", 1)[0] if "functions." in raw_id \
            else raw_id.rsplit(":", 1)[0]
        try:
            args = json.loads(m.group("args"))
        except json.JSONDecodeError:
            continue
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _KIMI_SECTION.sub("", text).strip()
        return calls, content
    # Ling: <tool_call>NAME <arg_key>k</arg_key><arg_value>v</arg_value>...</tool_call>.
    # Must run BEFORE Granite (both use <tool_call>) — Ling's first token is a bare
    # NAME, Granite's is '{', so a block whose body has arg_key pairs is Ling's.
    for m in _LING_CALL.finditer(text):
        name, body = m.group(1).strip(), m.group(2)
        pairs = _LING_ARG.findall(body)
        if not pairs:
            continue  # not the Ling shape (e.g. a Granite json block) — leave to Granite
        args = {k.strip(): v for k, v in pairs}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _LING_CALL.sub("", text).strip()
        return calls, content
    for m in _GRANITE_CALL.finditer(text):
        try:
            tc = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        # ARGUMENTS MAY ARRIVE ALREADY ENCODED. Granite emits `"arguments"` as an
        # object most of the time, but sometimes as a JSON STRING; dumping that
        # again produced a JSON string wrapping a JSON string, so a correct
        # client's json.loads() returned a str instead of a dict. It then stored
        # the malformed call and replayed it as history, which surfaced in mcode
        # as "Conversation history could not be safely updated" -- a turn-state
        # error with no hint that the cause was our encoding. Decode-then-dump,
        # exactly as the Nemotron branch above does. (Reported with a sniff
        # capture, 2026-10-01.)
        args = tc.get("arguments", {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {"_raw": args}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": tc.get("name", ""),
                                   "arguments": json.dumps(args)}})
    content = re.sub(r"<tool_call>.*?</tool_call>", "", text, flags=re.DOTALL).strip()
    return calls, content


# ---- EXECUTION BACKEND ----------------------------------------------------
# Everything above this line — chat template, ladder lookup, byte-confirm,
# checkpoint placement, store, telemetry, console, licence — is where the
# product lives and is backend-independent. BACKEND is only the part that runs
# the model: mlx_lm in this process (one Mac, the shipped path) or an exo
# cluster (many Macs over Thunderbolt, which is how a model too large for one
# machine becomes runnable at all). Selected by _BACKEND_NAME (config.json's
# "backend", FAXL_BACKEND overriding), resolved once at the top.
#
# The ABSOLUTE GRID is not a backend detail: every backend must chunk prefill
# on multiples of SEG, or hybrid recurrent state diverges from the cold path
# and a warm serve returns a plausible wrong answer (see backends.py).
from faxl.engine.backends import make_backend
BACKEND = make_backend(
    _BACKEND_NAME,
    **({"model": model, "tokenizer": tok, "sampler": sampler,
        "stop_ids": STOP_IDS, "seg": SEG, "trimmable": TRIMMABLE,
        "processor": PROCESSOR}
       if _BACKEND_NAME == "mlx"
       else {"model_id": MODEL, "seg": SEG, "endpoint": EXO["endpoint"]}))
print(f"execution backend: {BACKEND.name}", flush=True)

# ---- THE PREFILL SERVER. On the exo path this thread is where the ladder
# actually runs: exo's runner dials FAXL_PREFILL_ENDPOINT when it needs a
# prefix (R1) and pushes state back after a cold one (R2). It needs no model
# -- load_prompt_cache rebuilds an mlx cache from the safetensors metadata
# alone -- so it never contends with inference.
# ONE OWNER. faxl binds the socket, so faxl decides the port and PUBLISHES it;
# exo reads that file rather than a second environment variable of its own.
#
# Both sides used to read their own env var (FAXL_PREFILL_PORT here,
# FAXL_PREFILL_ENDPOINT there) with nothing connecting them, so they could
# disagree and neither could tell: measured, exo dialled 52441 while faxl
# listened on 52440, and every request died with ConnectionRefusedError after
# taking the runner down with it. A value two processes must agree on cannot
# be configured twice.
PREFILL_STATE = os.path.expanduser(
    os.environ.get("FAXL_PREFILL_STATE", "~/.faxl/prefill-endpoint.json"))
PREFILL_SERVER = None
if BACKEND.name == "exo":
    _pf_port = EXO["prefill_port"]
    _pf_host = os.environ.get("FAXL_PREFILL_HOST", "127.0.0.1")
    try:
        from faxl.engine.exo_prefill_server import start_prefill_server
        PREFILL_SERVER = start_prefill_server(
            _pf_port, MODEL, host=_pf_host, counts=EXO_COUNTS)
        # Publish what was ACTUALLY bound, keyed by model: one proxy serves one
        # model, and a cluster running two has one entry per model. Written
        # after the bind succeeds, so the file never advertises a dead port.
        try:
            os.makedirs(os.path.dirname(PREFILL_STATE), exist_ok=True)
            _state = {}
            if os.path.exists(PREFILL_STATE):
                with open(PREFILL_STATE) as _fh:
                    _state = json.load(_fh) or {}
            _state[str(MODEL)] = {"endpoint": f"{_pf_host}:{_pf_port}",
                                  "pid": os.getpid(),
                                  "written_at": time.time()}
            _tmp = PREFILL_STATE + f".tmp{os.getpid()}"
            with open(_tmp, "w") as _fh:
                json.dump(_state, _fh, indent=2)
                _fh.flush()
                os.fsync(_fh.fileno())
            os.replace(_tmp, PREFILL_STATE)      # atomic publish
            print(f"published prefill endpoint -> {PREFILL_STATE}", flush=True)
        except OSError as _e:
            # Not fatal: exo can still be pointed by env var. But say so,
            # because the whole point of the file is that it cannot drift.
            print(f"!! could not publish the prefill endpoint ({_e}) — exo "
                  f"will need FAXL_PREFILL_ENDPOINT set by hand", flush=True)
    except Exception as e:   # noqa: BLE001
        # Loud and fatal: FAXL_BACKEND=exo without this thread is a proxy that
        # forwards to a cluster with no cache behind it — a silent no-op of
        # the entire product.
        raise SystemExit(
            f"FATAL: the prefill server did not start ({type(e).__name__}: {e}). "
            f"With FAXL_BACKEND=exo this is the cache; refusing to serve "
            f"without it.")


def _images_from_body(body):
    """Every image in the request, as bytes, in the order they appear.

    _flatten_multimodal deliberately does NOT carry these: it builds the text
    the ladder hashes, where a picture is one <image:digest> atom, because a
    megabyte of base64 in the prefix would be re-hashed on every request for
    nothing. The pixels are still in the body, and the vision path needs them.
    """
    out = []
    for m in (body.get("messages") or []):
        c = m.get("content")
        if not isinstance(c, list):
            continue
        for part in c:
            if not isinstance(part, dict):
                continue
            if part.get("type") not in ("image_url", "input_image", "image"):
                continue
            iu = part.get("image_url")
            url = (iu.get("url", "") if isinstance(iu, dict)
                   else str(iu or part.get("url") or ""))
            if url.startswith("data:"):
                try:
                    out.append(base64.b64decode(url.split(",", 1)[1],
                                                validate=False))
                except Exception:  # noqa: BLE001 -- a bad paste is not a crash
                    pass
    return out


def prefill(ids, cache, start=0, images=None):
    """Fold tokens into `cache` on the absolute grid (see backends.py)."""
    if images and getattr(BACKEND, "accepts_images", False):
        return BACKEND.prefill_with_images(ids, cache, images, start)
    return BACKEND.prefill(ids, cache, start)


def generate(seed, cache, max_tokens):
    """Returns (out_ids, t_first): t_first is the wall-clock time the FIRST
    token was decoded (None if none) — TTFT is measured directly against the
    request start, never reconstructed (plan v1.5 phase 0)."""
    return BACKEND.generate(seed, cache, max_tokens)


class MlxCacheOps(CacheOps):
    """mlx/exo: delegate to mlx_lm exactly as the request path always did.

    Every method here is the call that used to sit inline in chat(), moved
    behind the seam and nothing else. That is deliberate: the Mac suite is the
    only gate that can prove the seam changed no behaviour, so the mlx side
    must be a pure forward.
    """

    store_name = "mlx"
    cache_format = "mlx_safetensors_v1"
    supports_images = True

    def make(self, model):
        return make_prompt_cache(model)

    def load(self, blob):
        return load_prompt_cache(blob)

    def save(self, blob, cache):
        return save_prompt_cache(blob, cache)

    def can_trim(self, cache):
        return can_trim_prompt_cache(cache)

    def trim(self, cache, n):
        # F8: trim returns the FIRST layer's count only -- never a total.
        return trim_prompt_cache(cache, n)

    def prefill(self, ids, cache, start=0, images=None):
        # mx.array lives HERE, not in the generic path: the shared proxy hands
        # every backend a plain list.
        return prefill(mx.array(ids), cache, start, images=images)

    def generate(self, ids, cache, max_tokens):
        # The mlx decode seeds from the last token only.
        return generate(mx.array(ids[-1:]), cache, max_tokens)


# WHICH CACHE ENGINE THIS PROCESS USES. Chosen once, by backend, like the model
# and the backend itself. A line that has no implementation fails HERE, at
# boot, naming the backend -- not on the first request.
if _BACKEND_NAME in _MLX_BACKENDS:
    CACHE = MlxCacheOps()
else:
    # Per-line execution: backends.py is NOT shared (tools/sync_engine.py's
    # MODULES excludes it by design), so the Linux wheel supplies its own
    # vllm CacheOps and hands it over here.
    from faxl.engine.backends import make_cache_ops as _make_cache_ops
    CACHE = _make_cache_ops(_BACKEND_NAME)

# The store name is resolved twice -- once early for BLOB_DIR, once by the
# cache engine itself -- so they are checked against each other rather than
# trusted. A mismatch means blobs would be written where nothing looks for
# them.
_declared_trim = _TRIMMABLE_BY_BACKEND[_BACKEND_NAME]
if _declared_trim is not None and CACHE.can_trim(None) != _declared_trim:
    raise RuntimeError(
        f"faxl_proxy: trimmability disagreement -- the boot table says "
        f"{_declared_trim} for {_BACKEND_NAME!r} but "
        f"{type(CACHE).__name__}.can_trim() says {CACHE.can_trim(None)}")
if CACHE.store_name != STORE_NAME:
    raise RuntimeError(
        f"faxl_proxy: store name disagreement -- BLOB_DIR uses "
        f"{STORE_NAME!r} but {type(CACHE).__name__} declares "
        f"{CACHE.store_name!r}")


SNIFF = os.environ.get("FAXL_SNIFF")   # path to dump full request/response traffic for inspection


def _sniff(kind, obj):
    """Append a pretty JSON record of one request or response to FAXL_SNIFF, for
    testing/inspection. Off unless FAXL_SNIFF is set. Records the FULL messages,
    tools, raw model text, and parsed tool calls — so you can see exactly what
    OpenClaw sent and what the model did with it."""
    if not SNIFF:
        return
    try:
        with open(SNIFF, "a") as f:
            f.write(json.dumps({"t": time.time(), "kind": kind, **obj}, default=str) + "\n")
            f.flush(); os.fsync(f.fileno())
    except Exception:
        pass


# FIX D6 (CODE-TRUTH): the server now runs threaded so /health, /metrics and
# /v1/models answer during a long generation; MODEL INFERENCE AND STORE WRITES
# stay strictly serialized under this lock (MLX and the Index are not
# thread-safe; per-request behavior is unchanged).
_SERVE_LOCK = threading.Lock()


def _spawn_settle(messages, assistant_msg):
    """Fire-and-forget: POST the conversation + the reply just delivered back
    to THIS proxy as a prefill-only settle request (see SETTLE). It queues on
    _SERVE_LOCK behind any live request, so a user who replies instantly waits
    at most one answer-length prefill; typically it runs while they read."""
    import urllib.request

    def _go():
        try:
            payload = json.dumps({
                "model": MODEL,
                "messages": messages + [assistant_msg],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{os.environ.get('FAXL_PORT', '8767')}"
                "/v1/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json",
                         "X-Faxl-Settle": "1"})
            urllib.request.urlopen(req, timeout=600).read()
        except Exception as e:  # noqa: BLE001 -- settle must never hurt a serve
            print(f"!! settle failed ({type(e).__name__}: {e}) -- the answer "
                  f"stays uncached until the next turn re-prefills it",
                  flush=True)
    threading.Thread(target=_go, daemon=True, name="faxl-settle").start()


@app.route("/v1/chat/completions", methods=["POST"])
def chat():
    # NO MODEL YET: say so in one plain sentence and point at the console,
    # before any telemetry or locking. 503 is the honest code -- the service
    # is real, it just has nothing loaded until the person chooses.
    if model is None and _LOAD_FROM is None:
        return jsonify({"error": {
            "message": ("faxl has no model loaded yet. Open the console "
                        "and pick one -- it will show what fits this Mac "
                        "and what each option downloads. faxl ships without "
                        "weights and never downloads one without being "
                        "asked."),
            "type": "no_model"}}), 503
    # FIX D6: one request at a time through inference + store writes; the lock is
    # what makes threaded=True safe.
    body = request.get_json(silent=True) or {}
    # A settle request (see SETTLE above) is the proxy talking to itself over
    # loopback: no telemetry transaction is opened for it (emit_start without
    # the completion _chat_impl skips would log a false incomplete).
    _settle_req = (request.headers.get("X-Faxl-Settle") == "1"
                   and request.remote_addr in ("127.0.0.1", "::1"))
    # TELEMETRY START — SYNCHRONOUS + fail-closed, and BEFORE _SERVE_LOCK so a
    # stalled telemetry fsync never serialises behind queued inference. One hook
    # covers both the non-stream and SSE paths below. The txn id threads down to
    # become req_id (one id per request; AUDIT unchanged).
    txn_id = uuid.uuid4().hex[:16]
    # PROJECT TAG: X-Faxl-Project header, or `faxl_project` in the body for
    # clients that cannot set headers. Attributes spend and hit rate to the
    # team that caused them.
    _project = _project_tag(request.headers.get("X-Faxl-Project")
                            or body.get("faxl_project"))
    if TELEMETRY is not None and not _settle_req:
        try:
            _raw = request.get_data(cache=True) or b""
            TELEMETRY.emit_start(
                txn_id,
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")),  # "" = unattributed
                prompt_bytes=len(_raw), n_messages=len(body.get("messages", [])),
                client_label=_client_label(request.headers.get("User-Agent", "")),
                project=_project)
        except _tel.TelemetryError:
            # v1 fail-closed: refuse before inference; retryable. Never a silent
            # untracked serve. (Loud failure already surfaced + in /health.)
            return jsonify({"error": {"type": "telemetry_unavailable",
                                      "message": "telemetry sink unavailable; retry",
                                      "retryable": True}}), 503
    def _serve_error(reason):
        if _settle_req:        # no transaction was opened; nothing to close
            return
        # A request that errored after START is a FAILED request, not a vanished
        # search — close the transaction so the aggregator sees a terminal event
        # (REJECTED serve_error), never a false "incomplete".
        if TELEMETRY is not None:
            TELEMETRY.emit_rejected(
                txn_id, reject_reason=f"serve_error:{reason}"[:60],
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")), _seq=99)

    if not body.get("stream"):
        with _SERVE_LOCK:
            try:
                return _chat_impl(txn_id=txn_id)
            except ModelMismatch as e:
                # A request for a model this proxy does not serve is the
                # CLIENT's error, not a server fault: answer 400 and name both
                # models, rather than 500 or (far worse) a plausible reply
                # generated by the wrong one.
                _serve_error("model_mismatch")
                return jsonify({"error": {
                    "type": "model_not_found",
                    "message": (f"this proxy serves {MODEL!r}, not {str(e)!r}; "
                                f"point the client at the proxy for that model"),
                    "param": "model"}}), 400
            except Exception as e:   # emit terminal event, then let Flask 500
                _serve_error(type(e).__name__)
                raise
    # SSE streaming (2026-08-19): the proxy previously IGNORED
    # stream:true and hung streaming clients — OpenClaw's embedded
    # runner idle-watchdogged every turn at 120 s (OUR bug, isolated
    # after first being misattributed to the gateway). Contract: emit
    # the role frame IMMEDIATELY, SSE keepalive comments while the
    # serve (prefill included) runs, then content/finish frames and
    # [DONE]. Generation itself is unchanged (single-shot under the
    # serve lock) — this is protocol compliance, not incremental
    # decoding; byte-identity of message content is preserved.
    from flask import copy_current_request_context
    result = {}

    @copy_current_request_context
    def _work():
        with _SERVE_LOCK:
            try:
                resp = _chat_impl(txn_id=txn_id)
                result["payload"] = resp.get_json()
                result["status"] = resp.status_code
            except Exception as e:          # surfaced in-stream below
                result["error"] = f"{type(e).__name__}: {e}"
                _serve_error(type(e).__name__)   # close txn (not a false incomplete)

    th = threading.Thread(target=_work, daemon=True)
    th.start()

    def _gen():
        rid = f"chatcmpl-{uuid.uuid4().hex[:12]}"
        first = {"id": rid, "object": "chat.completion.chunk",
                 "created": int(time.time()), "model": MODEL,
                 "choices": [{"index": 0,
                              "delta": {"role": "assistant"},
                              "finish_reason": None}]}
        yield f"data: {json.dumps(first)}\n\n"
        while th.is_alive():
            th.join(timeout=5)
            if th.is_alive():
                yield ": keepalive\n\n"
        if "payload" not in result or result["payload"] is None:
            err = result.get("error", f"status {result.get('status')}")
            yield ("data: " + json.dumps(
                {"id": rid, "object": "chat.completion.chunk",
                 "error": {"message": err}}) + "\n\n")
            yield "data: [DONE]\n\n"
            return
        p = result["payload"]
        msg = p["choices"][0]["message"]

        def _frame(delta):
            return ("data: " + json.dumps(
                {"id": p["id"], "object": "chat.completion.chunk",
                 "created": p["created"], "model": p["model"],
                 "choices": [{"index": 0, "delta": delta,
                              "finish_reason": None}]}) + "\n\n")

        if msg.get("content"):
            yield _frame({"content": msg["content"]})
        # OpenAI streaming convention, STRICT: fragment 1 = id+name with
        # EMPTY arguments; fragment 2 = the arguments string. A complete
        # tool call in one fragment double-buffers in real accumulators
        # (measured: OpenClaw stringified it → "root: must be object"
        # validation loops).
        for i, tc in enumerate(msg.get("tool_calls") or []):
            fn = tc.get("function", {})
            yield _frame({"tool_calls": [
                {"index": i, "id": tc.get("id"), "type": "function",
                 "function": {"name": fn.get("name", ""),
                              "arguments": ""}}]})
            yield _frame({"tool_calls": [
                {"index": i,
                 "function": {"arguments": fn.get("arguments", "")}}]})
        yield ("data: " + json.dumps(
            {"id": p["id"], "object": "chat.completion.chunk",
             "created": p["created"], "model": p["model"],
             "choices": [{"index": 0, "delta": {},
                          "finish_reason":
                          p["choices"][0]["finish_reason"]}],
             "usage": p.get("usage"), "faxl": p.get("faxl")}) + "\n\n")
        yield "data: [DONE]\n\n"

    return Response(_gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})



class ModelMismatch(ValueError):
    """A request named a model this proxy does not serve."""


def _forward_to_exo(body, ids, txn_id, treq0, n_images=0, project=""):
    """Serve this request on the exo cluster. R1 and R2 both happen off to the
    side, on the prefill wire, while this function only moves the request.

    THE DIVISION. exo executes; this proxy remains the front door and the
    operating layer -- licence gate, telemetry, console, analytics all still
    hang off the request arriving here. What does NOT happen here is the
    ladder: exo's runner asks this process's PrefillServer thread for a
    prefix, and that thread decides and counts the hit. Running the ladder
    again in this handler would load a blob into a process with no model to
    use it with, and double-count every request.

    WHAT IS HONESTLY MEASURED. Wall time and token counts are real. Prefill
    and decode spans belong to exo and are not visible from here, so they are
    left UNSET rather than written as plausible zeros -- proto3 cannot
    distinguish 0 from absent, and a fabricated zero is worse than a gap.
    Hit/miss comes from the prefill server's own counters.
    """
    import urllib.error
    import urllib.request

    url = f"{BACKEND.endpoint}/v1/chat/completions"
    payload = dict(body)
    # MODEL NAME: accept an ALIAS for the model this proxy serves, refuse any
    # other model outright.
    #
    # A client may legitimately address this model by a short local name
    # ("granite-4.0-h-small-8bit") while exo knows only the full repo id and
    # answers 404 for anything else -- so a name that is a suffix of, or
    # identical to, this proxy's model is normalised to the full id.
    #
    # A name that is NOT this model is a DIFFERENT model, and this proxy has
    # exactly one: one tokenizer, one ladder, one store keyed to one model_id.
    # Rewriting that name would answer a request for model B with model A, at
    # HTTP 200, with no warning -- measured: a request for Qwen3-VL came back
    # answered by Granite. Silent, plausible and wrong is the worst failure
    # this codebase has, so it is a 400 instead.
    _asked = str(body.get("model") or "").strip()
    _short = MODEL.split("/")[-1]
    if _asked and _asked not in (MODEL, _short) and not MODEL.endswith("/" + _asked):
        raise ModelMismatch(_asked)
    payload["model"] = MODEL
    payload["stream"] = False        # the SSE wrapper above re-frames it
    raw = json.dumps(payload).encode()

    _hits_before = int(EXO_COUNTS.get("hits", 0))
    _reqs_before = int(EXO_COUNTS.get("requests", 0))

    try:
        req = urllib.request.Request(
            url, data=raw, method="POST",
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=BACKEND.timeout_s) as r:
            body_bytes = r.read()
        if not body_bytes.strip():
            # exo answers 200 with an EMPTY body when its runner raised: the
            # exception is logged on its side and swallowed on the wire.
            # Reporting "expecting value at line 1 column 1" here would send
            # the reader hunting a JSON bug in faxl instead of a crash in the
            # engine, so name it for what it is.
            raise RuntimeError(
                f"exo returned an empty body (HTTP 200) — its runner almost "
                f"certainly raised; check the exo log for a traceback")
        reply = json.loads(body_bytes.decode())
    except (urllib.error.URLError, OSError, ValueError) as e:
        # No failover: a cluster that cannot answer is an error, not a quiet
        # fallback to a local model this process may not even have loaded.
        print(f"!! exo backend failed at {url}: {type(e).__name__}: {e}",
              flush=True)
        raise

    dt = time.time() - treq0
    usage = reply.get("usage") or {}
    out_tokens = int(usage.get("completion_tokens", 0))
    # The prefill server counted this request while exo was serving it; the
    # difference is whether THIS request hit.
    hit = int(EXO_COUNTS.get("hits", 0)) > _hits_before
    served = int(EXO_COUNTS.get("last_served", 0)) if hit else 0

    # ONE TOKEN SPACE, THE MODEL'S. `served` is model POSITIONS resumed, so
    # the prompt it is compared against must be model positions too.
    #
    # len(ids) is not that. It counts what THIS process templated, where an
    # image is a single <image:digest> placeholder of about ten tokens; the
    # vision encoder then expands that one placeholder into ~4,200 pad
    # positions before the model sees it. Measured on the photo workload:
    # len(ids)=1785 against a real prompt of 5987. Charting `served` against
    # len(ids) therefore drew "served from cache" ABOVE "received from users"
    # -- 531k of 569k -- which reads as though the cache invented tokens.
    # It did not; the two lines were in different units.
    #
    # exo reports the real count in usage.prompt_tokens, so use it and fall
    # back to len(ids) only when it is absent (a text prompt, where the two
    # agree anyway).
    n_prompt = int(usage.get("prompt_tokens") or 0) or len(ids)

    _bump_project(project, hit=hit, prompt_tokens=n_prompt, skipped=served,
                  paid=max(n_prompt - served, 0), secs=dt)
    TOTALS["requests"] += 1
    TOTALS["prompt_tokens"] += n_prompt
    TOTALS["prefill_paid"] += max(n_prompt - served, 0)
    TOTALS["prefill_skipped"] += served
    TOTALS["hits"] += 1 if hit else 0
    TOTALS["wall_s"] += dt

    if TELEMETRY is not None:
        _pb = _tel.pb
        _tenant = licence.status().get("customer", "") or os.environ.get(
            "FAXL_TENANT", "")
        _cost = _pb.Cost(
            prompt_tokens=n_prompt,
            prefill_paid=max(n_prompt - served, 0),
            prefill_skipped=served,
            warm_wall_ms=dt * 1000.0,
            cold_basis=_pb.ESTIMATED,
            cold_prefill_ms_est=(served / max(PREFILL_TPS["ewma"], 1e-6)) * 1000.0,
            estimator_id="prefill_tps_ewma",
            estimator_version=str(round(PREFILL_TPS["ewma"], 1)))
        # prefill_ms/decode_ms deliberately UNSET: they happened on exo.
        _tim = _pb.Timings()
        TELEMETRY.emit_completion(
            txn_id or uuid.uuid4().hex[:16], tenant=_tenant,
            outcome=(_pb.HIT if hit else _pb.MISS),
            resume_pos=served,
            hit_tier=(_pb.EXACT if hit else _pb.HIT_TIER_UNSPECIFIED),
            ladder=[], cost=_cost, out_tokens=out_tokens, timings=_tim,
            prompt_content=hashlib.sha256(str(ids).encode()).digest(),
            project=project)

    status = "warm" if hit else "cold"
    _img = f" | {n_images} image(s)" if n_images else ""
    _proj = f" | {project}" if project else ""
    print(f"[{status}/exo]{_proj} {len(ids)} tok{_img} | served {served} | "
          f"{out_tokens} out | {dt:.2f}s | {BACKEND.endpoint}", flush=True)
    return jsonify(reply)


def _chat_impl(txn_id=None):
    treq0 = time.time()   # request start — TTFT anchor (direct measurement)
    body = request.get_json(force=True)
    messages = body.get("messages", [])
    _settle = (request.headers.get("X-Faxl-Settle") == "1"
               and request.remote_addr in ("127.0.0.1", "::1"))
    _sniff("request", {
        "n_messages": len(messages),
        "tools": [t.get("function", {}).get("name") for t in (body.get("tools") or [])],
        "max_tokens": body.get("max_tokens"),
        "messages": messages,   # full text — this is a debug/inspection mode
    })
    # Default raised from 256: agentic edit tool calls carry whole hunks/files as
    # JSON arguments — at 256 the call truncates mid-argument, fails to parse, and
    # the harness sees dead text (measured: every OpenClaw edit turn cut at 256).
    # Default to effectively-unlimited when the client sends no max_tokens: let the
    # model run until its own end token. Clipping only serves as a runaway backstop,
    # and a low default silently truncates reasoning models mid-<think>. A client
    # that WANTS a cap still sends one and it is honoured. Override via
    # FAXL_MAX_TOKENS_DEFAULT if a hard ceiling is ever wanted.
    max_tokens = int(body.get("max_tokens", int(os.environ.get("FAXL_MAX_TOKENS_DEFAULT", "1000000"))))
    # FORWARD TOOLS: OpenClaw (and any agent) sends OpenAI-shape `tools`. Granite's
    # chat template renders them into a <tools>…</tools> block and instructs the
    # model to reply with <tool_call>{...}</tool_call>. Without this the model is
    # told nothing about the tools and correctly declines (that was the NO_REPLY).
    tools = body.get("tools") or None
    tmpl_kw = {"add_generation_prompt": True}
    if _settle:
        # The checkpoint must be a byte-prefix of the NEXT real prompt. A
        # generation prompt here would plant settle-only tokens inside the
        # stored prefix and fail its confirm (a harmless miss, a wasted settle).
        tmpl_kw["add_generation_prompt"] = False
    if tools:
        tmpl_kw["tools"] = tools
    # THINKING TOGGLE: reasoning models (Ling, Qwen3, ...) open a <think> block by
    # default; for terse/structured-output tasks that just burns the token budget
    # before the answer. Honour an OpenAI-compat `enable_thinking` (or `chat_template_kwargs`)
    # from the request, else the FAXL_ENABLE_THINKING env default (unset = leave the
    # template's own default). Templates without the flag ignore the kwarg harmlessly.
    _think = body.get("enable_thinking")
    if _think is None:
        _think = (body.get("chat_template_kwargs") or {}).get("enable_thinking")
    if _think is None and "FAXL_ENABLE_THINKING" in os.environ:
        _think = os.environ["FAXL_ENABLE_THINKING"].lower() in ("1", "true", "yes")
    if _think is not None:
        tmpl_kw["enable_thinking"] = bool(_think)
    # CANONICALIZE TOOL-CALL IDS before templating (measured failure, run 3 of the
    # OpenClaw commenting task): we return OpenAI-style ids ("call_xxx"); the client
    # echoes them back in history; Kimi's template renders them verbatim and the
    # model then MIMICS that id shape instead of its native "functions.NAME:IDX" —
    # its next call carries an id-shaped tool NAME the harness cannot resolve, and
    # the session loops on an unavailable tool. Rewriting history ids to the native
    # form (consistently across the assistant call and its tool-result message)
    # keeps the model's exemplar format correct. Name-linkage is preserved because
    # the id embeds the function name; Granite's template ignores ids entirely.
    idmap = {}
    canon = []
    for m in messages:
        m = dict(m)
        # Nemotron's Jinja template calls string methods on content and crashes
        # on the two non-string shapes OpenAI clients legally send: None (pure
        # tool-call turns) and multi-part lists [{"type":"text","text":...}]
        # (OpenClaw). Normalize both to plain strings; harmless for every family.
        c = m.get("content")
        if c is None:
            m["content"] = ""
        elif isinstance(c, list):
            # DO NOT FLATTEN A LIST THAT CONTAINS AN IMAGE.
            #
            # This join keeps only the "text" of each part, so an image_url
            # part became the empty string and the picture was GONE before
            # _flatten_multimodal ever ran. n_images was therefore 0, the
            # images-on-a-text-backend guard never fired, no pixels reached
            # the model, and the reply was invented from the words alone --
            # measured: a photograph of a man by the water came back as "a
            # close-up of a single vibrant red rose", then as a strawberry.
            #
            # _flatten_multimodal is the one place that understands these
            # parts: it hashes each image to a stable <image:digest> atom so
            # the ladder can key on it. Leave multimodal content alone here
            # and let it do its job.
            if any(isinstance(p, dict)
                   and p.get("type") in ("image_url", "input_image", "image")
                   for p in c):
                m["content"] = c
            else:
                m["content"] = "\n".join(
                    p.get("text", "") if isinstance(p, dict) else str(p)
                    for p in c)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            tcs = []
            for i, tc in enumerate(m["tool_calls"]):
                tc = json.loads(json.dumps(tc))
                new_id = f"functions.{tc.get('function', {}).get('name', 'tool')}:{i}"
                idmap[tc.get("id")] = new_id
                tc["id"] = new_id
                # arguments: OpenAI history carries a JSON STRING; Ling's Jinja
                # template calls .items() on it and crashes ("str has no attribute
                # items"). Coerce a JSON-object string to a dict — the OpenAI-internal
                # shape every family's template accepts (dict-consumers need it,
                # string-consumers re-serialize it fine).
                fn = tc.get("function", {})
                a = fn.get("arguments")
                if isinstance(a, str):
                    try:
                        parsed = json.loads(a)
                        if isinstance(parsed, dict):
                            fn["arguments"] = parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                tcs.append(tc)
            m["tool_calls"] = tcs
        if m.get("role") == "tool" and m.get("tool_call_id") in idmap:
            m["tool_call_id"] = idmap[m["tool_call_id"]]
        canon.append(m)
    # IMAGES: flatten multimodal parts so the template sees strings. The real
    # images are not lost -- the exo path forwards the ORIGINAL body below --
    # this is only what the ladder hashes.
    canon, _n_images = _flatten_multimodal(canon)
    try:
        ids = tok.apply_chat_template(canon, **tmpl_kw)
    except TypeError:
        # a template that doesn't accept enable_thinking (most) — drop it and retry
        tmpl_kw.pop("enable_thinking", None)
        ids = tok.apply_chat_template(canon, **tmpl_kw)
    # A VLM PROCESSOR'S TOKENIZER RETURNS AN Encoding, NOT A LIST.
    # mlx_lm's tokenizer hands back plain ints, so everything downstream --
    # mx.array(ids[a:b]), len(ids), the prompt hash -- assumed a sequence.
    # Given an Encoding it failed with "Invalid type tokenizers.Encoding
    # received in array initialization" at the first prefill.
    # Three shapes seen in the wild, and the two new ones both came from the
    # VLM processor's tokenizer:
    #   list[int]      mlx_lm's tokenizer, what everything downstream assumes
    #   Encoding       has .ids
    #   BatchEncoding  a dict-like carrying "input_ids", possibly batched
    # A str means the template did not tokenise at all; tokenise it rather
    # than hand a string to mx.array, which fails with a type error three
    # frames away from the cause.
    if isinstance(ids, str):
        ids = tok.encode(ids)
    if hasattr(ids, "ids"):
        ids = list(ids.ids)
    elif hasattr(ids, "get") and ids.get("input_ids") is not None:
        ids = ids["input_ids"]
    if ids and isinstance(ids[0], (list, tuple)):
        ids = ids[0]              # unbatch
    ids = [int(t) for t in ids]

    # ---- EXO BACKEND: the cluster executes, this proxy stays the front door.
    #
    # The ladder does NOT run here on this path. exo's runner asks for a
    # prefix over the prefill wire (FAXL_PREFILL_ENDPOINT -> this process's
    # PrefillServer thread), which is where a hit or miss is decided and
    # counted; running the ladder a second time in the handler would load the
    # same blob into a process that has no model to use it with.
    #
    # Everything above still applied: the chat template, tool canonicalisation
    # and the thinking toggle shape the messages, and telemetry has already
    # opened the transaction. Only execution moves.
    if BACKEND.name == "exo":
        return _forward_to_exo(body, ids, txn_id, treq0, n_images=_n_images,
                               project=_project_tag(
                                   request.headers.get("X-Faxl-Project")
                                   or body.get("faxl_project")))

    # IMAGES ON A TEXT BACKEND: REFUSE, DO NOT PRETEND.
    #
    # _flatten_multimodal replaces each image with a text placeholder so the
    # chat template has a string and the ladder has something stable to hash.
    # On the exo path that is harmless -- the ORIGINAL body, pixels intact, is
    # forwarded above. On this path there is nothing downstream to forward to:
    # LocalMlxBackend runs mlx_lm, which loads a vision model as a TEXT model
    # and never sees the vision tower.
    #
    # So the request would have been served 200 with an answer invented from a
    # placeholder. Measured on the exo path before this was understood: a
    # 30,000-character base64 JPEG arrived as 21 tokens and the model answered
    # "1234567890" from nothing. For OCR that is the worst possible failure --
    # confident, well-formatted, and entirely fabricated.
    #
    # A refusal is a limit the caller can see and act on. A fabrication is a
    # lie with a 200 on it.
    # Keep the pixels: _flatten_multimodal built the hash text, not the image.
    _req_images = _images_from_body(body) if _n_images else None
    if _n_images and not BACKEND.accepts_images:
        return jsonify({"error": {
            "message": (
                f"This backend serves text only, and the request carried "
                f"{_n_images} image(s). faxl will not answer from a "
                f"placeholder: the reply would be invented rather than read "
                f"from the picture. Images need a vision-capable backend."),
            "type": "unsupported_content",
            "code": "images_not_supported_on_this_backend",
            "backend": BACKEND.name}}), 400

    t0 = time.time()
    cache_status = "cold"
    prefilled = len(ids)
    resume_pos = 0
    resumed_blob = None   # REPRO DEBUG: the blob actually loaded (None = cold/miss)
    resumed_phash = None  # protected from scored eviction this request
    prompt_hash = hashlib.sha256(str(ids).encode()).hexdigest()[:16]  # exact prompt id
    req_id = txn_id or uuid.uuid4().hex[:16]   # M0: stable request id; == telemetry txn
    aud_probes = []   # ladder walk — always collected (AUDIT + telemetry read it)

    # EXACT-TIER LOOKUP: one O(N) prefix-hash pass, then deepest-first hash lookup +
    # token confirm at each scheduled position. NO ESN probe, NO cosine on this path.
    # Skipped entirely in NOCACHE mode (the A/B control).
    confirm = None      # None = no exact hit; "pass"/"fail" = confirm outcome
    qhash = None
    _regions = []
    hash_build_ms = 0.0
    confirm_ms = 0.0
    # Phase-0 exclusive child spans + one inclusive outer accumulator.
    # cache_blocked_ms totals every cache-path segment the serialised handler
    # spends OUTSIDE prefill/decode; residual_ms = outer − Σ children.
    cache_blocked_ms = 0.0
    probe_rpc_ms = 0.0      # identity_get RPCs (lookup probes + write dedup)
    blob_load_ms = 0.0      # load_prompt_cache on a hit (lazy mmap open)
    fork_discovery_ms = 0.0  # D* search + classify + gate evaluation
    ckpt_write_ms = 0.0     # ALL save_prompt_cache (grid + fork)
    tokfile_ms = 0.0        # token-prefix file writes
    esn_key_ms = 0.0        # probe.key (similarity key)
    upsert_ms = 0.0         # index.add (UltraDim upsert + row bookkeeping)
    evict_ms = 0.0          # supersession delete + fork LRU eviction
    # LICENCE GATE: unentitled behaves exactly like NOCACHE — the request is
    # still served, the prefill just runs cold. Degrade, never refuse.
    _entitled = licence.entitled()
    if not NOCACHE and not _entitled:
        cache_status = "unlicensed"
    elif not NOCACHE and len(ids) >= GATE_TOKENS:
        tcb0 = time.time()
        th0 = time.time()
        qhash = prefix_hashes(ids)
        hash_build_ms = (time.time() - th0) * 1000
        # Where this request's pictures sit, so a probe never resumes from a
        # position inside one. Computed once, not per probe.
        _regions = _image_regions(tok, ids) if _n_images else []
        # Plan v1.5 phase 0: probe PERSISTED positions only — every position
        # where a blob is known to exist (grid AND fork). Schedule
        # recomputation is REMOVED from the lookup (it probed positions with
        # no stored blob; regression-tested equal hit sets in
        # test_lookup_regression.py). ckpt_positions stays write-path-only.
        probe_positions = index.known_positions()   # sorted desc
        for pos in probe_positions:
            if pos % SEG and not TRIMMABLE:
                # OFF-GRID IS PROBED ONLY ON A PURE-KV MODEL.
                #
                # What this guard protects is HYBRIDS: a recurrent layer's
                # state at a position depends on the chunk decomposition that
                # produced it, so resuming from a boundary the cold path would
                # never have cut at changes the answer. That rule stays.
                #
                # It does not apply to a pure-KV model, where a KV entry is a
                # function of its own position alone -- and this proxy already
                # relies on that, because the TRIM tier resumes off-grid on
                # every warm request ("warm(trimmed,resume@1774,from@1792)").
                #
                # Without this, the image-atom checkpoints the write path now
                # produces are stored and never read: an atom starting at 1780
                # is not a multiple of 256, so every probe skipped it and the
                # run resumed from 256 instead -- 14% reused where the same
                # photographs should reuse ~98%.
                continue
            if pos >= len(ids) - 1:
                continue   # need >=1 tail token to seed generation
            # A BLOB STORED INSIDE THE <image:digest> ATOM IS NOT SERVABLE.
            #
            # THIS IS NOT safe_depth(), and it is not what 2d0fdfb removed.
            # That guard was described as refusing "any depth at or past an
            # image start"; what it actually tested was `a < pos < b` --
            # strictly INSIDE -- and removing it was a misreading. The writer
            # clamp above states the rationale and the reader must agree with
            # it: on the ATOM stream a depth mid-atom is character twelve of a
            # hex digest, so the remainder text-prefills, no chunk carries the
            # marker, the vision tower never runs, and the model answers from
            # the preamble alone.
            #
            # Measured today on the live store, which still holds 20 such
            # blobs written before the clamp existed: three photographs served
            # resume@1792 against an atom at 1780..1798, no vision call in the
            # log, and three confident captions of "a plain white surface with
            # no discernible objects". A wrong answer served in 0.8s, which is
            # the worst thing this cache can do.
            #
            # On the EXPANDED pad stream exo reads, a mid-image depth remains
            # correct and this guard never fires: _regions there are ~1,200
            # pad tokens carrying real embeddings (media_regions.py deletes
            # safe_depth by name, and dad06fb records why). The two lines
            # differ in what a region IS, not in the rule.
            if any(r.start_pos < pos < r.end_pos for r in _regions):
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "inside_atom"})
                continue
            tpr0 = time.time()
            cand = index.identity_get(entry_key(qhash[pos], _regions, pos))
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if cand is None:
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "miss"})
                continue
            blob, cpos, tokf = cand
            # CONFIRM (belt and braces): token-compare the stored prefix.
            # A fail here is a hash collision or store corruption — logged loudly and
            # NEVER resumed. FIX D3 (CODE-TRUTH): a corrupted DEEP entry must not
            # forfeit a valid SHALLOWER hit — continue down the ladder; the request
            # only runs cold if no rung confirms.
            tcf0 = time.time()
            try:
                stored_prefix = json.load(open(tokf))
            except Exception:
                confirm_ms += (time.time() - tcf0) * 1000
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_unreadable"})
                continue
            if stored_prefix != list(ids[:pos]):
                confirm_ms += (time.time() - tcf0) * 1000
                confirm = "fail"
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_fail"})
                print(f"!! EXACT-TIER CONFIRM FAIL @pos={pos} phash={qhash[pos]} "
                      f"tok={os.path.basename(tokf)} — skipping this rung, trying "
                      f"shallower", flush=True)
                continue
            confirm = "pass"
            confirm_ms += (time.time() - tcf0) * 1000
            tbl0 = time.time()
            try:
                cache = CACHE.load(blob)
                blob_load_ms += (time.time() - tbl0) * 1000
            except Exception as e:
                # supersession/eviction race or corrupt blob: fall to shallower
                # rungs, never 500 (plan rev 5 §safety).
                blob_load_ms += (time.time() - tbl0) * 1000
                print(f"!! BLOB LOAD FAILED @pos={pos} ({e}) — trying shallower",
                      flush=True)
                cache = None
                confirm = None
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "load_fail"})
                continue
            if aud_probes is not None:
                aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                   "outcome": "confirm_pass"})
            # KEYED THE WAY THE INDEX IS KEYED -- entry_key, the tokens AND
            # the pictures. This is T-0008 on the mlx line: `index.add` stores
            # under entry_key while these three recorded the bare phash, and
            # for a text-only entry the two strings are identical, so the
            # mismatch is invisible until a prompt carries an image below the
            # checkpoint. Then every hit is recorded against a key the index
            # does not hold, a reused blob scores as never-used, and eviction
            # ranks the most-valuable blobs first. Measured on the exo store:
            # 62 real hits scoring 0, an eviction score of ~160,000 against
            # 645. The camera roll hides it (at 1780 no region starts below
            # pos, so entry_key == phash); an insurance prompt does not.
            _hit_key = entry_key(qhash[pos], _regions, pos)
            index.touch_resume(_hit_key)
            index.record_hit(_hit_key)     # blob++ (durable usage log)
            resume_pos = cpos
            resumed_blob = blob
            # The protect-set for this request's eviction sweep. It is matched
            # against index keys, which are entry_keys, so protecting the bare
            # phash would protect nothing and the blob just served could be
            # evicted by its own request's write.
            resumed_phash = _hit_key
            prefilled = len(ids) - cpos       # only the tail beyond the checkpoint
            cache_status = f"warm(exact,confirmed,resume@{cpos},delta={prefilled})"
            break
    if qhash is not None:
        cache_blocked_ms += (time.time() - tcb0) * 1000
    # ---- TRIM-ON-LOAD branch (KV plan B.2, TRIMMABLE models only): a
    # divergence at d below an anchor's depth P is served by loading the
    # anchor and trimming P-d tokens. Runs AFTER the exact ladder; engages
    # only when it beats the exact resume. EXEMPT from the ladder's
    # pos >= len-1 guard (a trim candidate legitimately has P >= len-1);
    # its own cap is d = min(D_raw, len-1) [F2].
    trim_rec = None
    if TRIMMABLE and not NOCACHE and qhash is not None:
        ttr0 = time.time()
        _d_raw_t = forkidx.deepest_shared(qhash, len(ids))
        d_t = min(_d_raw_t, len(ids) - 1)
        # THE TRIM TIER IS A SECOND DOOR INTO THE SAME POISON. Two photographs
        # share the preamble, the question AND the literal "<image:" prefix of
        # the atom, so deepest_shared lands a few tokens INSIDE it (~1782 of an
        # atom at 1780..1798). The byte confirm then passes -- those really are
        # the same ids -- and the trim resumes mid-atom, which is exactly the
        # state the reader guard above refuses. Same failure, different path:
        # no marker in the remainder, no vision call, a caption of the
        # preamble. Move back to the atom's start, which is a real boundary
        # and is also the position every photograph shares.
        if _n_images:
            d_t = _clear_of_atoms(d_t, _atom_spans(tok, ids))
        if d_t > resume_pos:
            cand = resolve_candidate(ANCHORS, forkidx.pos_hashes, qhash, d_t)
            if cand is not None:
                ent = index.identity_get(int(cand["phash"]))
                if ent is not None:
                    tblob, tP, ttokf = ent
                    tbytes = os.path.getsize(tblob)
                    gok, save_ms, load_ms = trim_economic_gate(
                        d_t, PREFILL_TPS["ewma"], tbytes,
                        LOAD_FIT["intercept_ms"], LOAD_FIT["slope_ms_per_gb"])
                    trim_rec = {"d_star": _d_raw_t, "d": d_t,
                                "owner": str(cand["owner"]),
                                "anchor_phash": cand["phash"],
                                "anchor_P": tP, "bytes": tbytes,
                                "tps": PREFILL_TPS["ewma"],
                                "save_ms": round(save_ms, 2),
                                "load_ms": round(load_ms, 2),
                                "gate_ok": gok, "outcome": None}
                    if not gok:
                        trim_rec["outcome"] = "gated_out"
                    else:
                        try:
                            stored_prefix = json.load(open(ttokf))
                        except Exception:
                            stored_prefix = None
                        if stored_prefix is None or                                 stored_prefix[:d_t] != list(ids[:d_t]):
                            trim_rec["outcome"] = "trim_confirm_fail"
                            print(f"!! TRIM CONFIRM FAIL @d={d_t} anchor@"
                                  f"{tP} — serving without trim", flush=True)
                        else:
                            try:
                                cache = CACHE.load(tblob)
                                # F8: trim returns the FIRST layer's count
                                # only — never asserted as a total.
                                CACHE.trim(cache, tP - d_t)
                                resume_pos = d_t
                                resumed_blob = tblob
                                # a trim serve is a real reuse of the anchor:
                                # blob++ and protect it from this request's
                                # eviction sweep, same as an exact resume
                                index.record_hit(int(cand["phash"]))
                                resumed_phash = int(cand["phash"])
                                prefilled = len(ids) - d_t
                                cache_status = (f"warm(trimmed,resume@{d_t},"
                                                f"from@{tP})")
                                trim_rec["outcome"] = "served"
                            except Exception as e:
                                trim_rec["outcome"] = "load_fail"
                                print(f"!! TRIM LOAD FAILED ({e}) — falling "
                                      f"back", flush=True)
        cache_blocked_ms += (time.time() - ttr0) * 1000
    if resume_pos == 0:
        cache = CACHE.make(model)
        cache_status = "nocache" if NOCACHE else "cold"
    if AUDIT:
        # #55: prefix-hash arrays for ALL traffic — computed here even for
        # NOCACHE/below-gate requests the lookup skipped (0.031 µs/token).
        _aud_qhash = qhash if qhash is not None else prefix_hashes(ids)
        AUDIT.request(req_id, prompt_len=len(ids), prompt_sha=prompt_hash,
                      prefix_hashes=_aud_qhash, workload=WORKLOAD)
        AUDIT.lookup(req_id, probes=aud_probes, resume_pos=resume_pos,
                     resume_phash=(qhash[resume_pos]
                                   if (resume_pos and qhash) else None),
                     trim=trim_rec)

    # ---- FORK DISCOVERY (plan rev 5): find the proven divergence position D*
    # and gate a checkpoint write there. Runs on EVERY request (warm or cold).
    fork_pos = fork_kind = fork_matched = None
    fork_gate = None
    fork_rec = None   # M0 audit: gate evaluation with RAW inputs (#56)
    fork_write_ms = 0.0
    index_maint_ms = 0.0
    fork_written = False
    trim_matched = None   # extension-matched stream (chain identity, B.4)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tfd0 = time.time()
        D_raw = forkidx.deepest_shared(qhash, len(ids))
        _fd_probe0 = probe_rpc_ms   # identity_gets inside discovery counted there
        D = min(D_raw, len(ids) - 2)
        # An EXACT re-arrival (the whole query is already a stored stream) has
        # no divergence point inside it — nothing to fork.
        if 0 < D and D_raw < len(ids):
            kind, matched_stream = forkidx.classify(qhash, D, len(ids))
            forkidx.observe_match(qhash[D])
            if kind == "extension":
                trim_matched = matched_stream
            marginal = D - resume_pos   # deepest existing blob on this prefix
            tpr0 = time.time()
            d_star_stored = index.identity_get(qhash[D]) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            # B.3 [F7]: under TRIMMABLE the anchor dominates every fork
            # write — D* is still computed (the trim path needs it), fork
            # BLOB WRITES and their gates are suppressed entirely.
            if FORK and not TRIMMABLE and marginal > 0 and not d_star_stored:
                pb = blob_bytes_predicted(MODEL, D, OBSERVED["max_blob"])
                if FORK_GATES_OFF:
                    fork_ok, fork_gate = True, "gates-off(demo)"
                    fork_rec = {"kind": kind, "d_star": D,
                                "family": "gates_off", "ok": True}
                elif kind == "extension":
                    ch = forkidx.chain_for(matched_stream)
                    ewma_inc = ch["ewma_inc"] if ch else max(len(ids) - D, 1)
                    repaid_tail = len(ids) - resume_pos
                    fork_ok, saved_ms, wr_ms = extension_gate(
                        repaid_tail, ewma_inc, PREFILL_TPS["ewma"], pb,
                        NVME_BPS, FORK_TIME_RATIO)
                    fork_gate = (f"ext saved~{saved_ms:.0f}ms write~{wr_ms:.0f}ms "
                                 f"inc~{ewma_inc:.0f}")
                    fork_rec = {"kind": kind, "d_star": D, "family": "ext",
                                "pb": pb, "inc": ewma_inc,
                                "tps": PREFILL_TPS["ewma"],
                                "repaid": repaid_tail,
                                "kappa": forkidx.kappa,
                                "time_ratio": FORK_TIME_RATIO, "ok": fork_ok}
                    # head must track the conversation EVERY turn, forking or
                    # not, or supersession loses its ancestor (measured: 14.9 GB
                    # of un-superseded fork blobs before this line existed).
                    forkidx.migrate_chain(matched_stream, qhash[len(ids)],
                                          len(ids) - D)
                else:
                    fork_ok, exp_extra, budget = divergence_gate(
                        pb, forkidx.kappa, marginal, model_slope(MODEL), FORK_AMORT)
                    fork_gate = (f"div k={forkidx.kappa:.2f} pred={pb/1e6:.0f}MB "
                                 f"budget={budget/1e6:.0f}MB")
                    fork_rec = {"kind": kind, "d_star": D, "family": "div",
                                "pb": pb, "kappa": forkidx.kappa,
                                "marginal": marginal,
                                "tps": PREFILL_TPS["ewma"],
                                "slope": model_slope(MODEL),
                                "amort": FORK_AMORT, "ok": fork_ok}
                if fork_ok:
                    # GRID SNAP: fork blobs obey the same rule as scheduled
                    # checkpoints — persist only at grid positions (raw D stays
                    # in fork_rec for the audit trail).
                    _D_grid = (D // SEG) * SEG
                    if _D_grid > 0:
                        fork_pos, fork_kind, fork_matched = _D_grid, kind, matched_stream
        _fd_block = (time.time() - tfd0) * 1000
        # discovery span excludes the identity_get RPC counted in probe_rpc_ms
        fork_discovery_ms += _fd_block - (probe_rpc_ms - _fd_probe0)
        cache_blocked_ms += _fd_block

    # Prefill ONLY the tail beyond the resume point, checkpointing at the
    # placements the selected STRATEGY returns (see store_lifecycle
    # STRATEGIES; FAXL_STRATEGY=grid restores the legacy geometric
    # schedule byte-identically). ScheduleContext is constructed AFTER hash
    # + lookup + fork discovery — everything in it is pre-arrival.
    _dstar = (D_raw if ((FORK or TRIMMABLE) and not NOCACHE
                        and qhash is not None) else 0)
    ctx = ScheduleContext(
        prompt_len=len(ids), resume_pos=resume_pos,
        d_star=_dstar,
        fork_kind=fork_kind,
        kappa=(forkidx.kappa if (FORK or TRIMMABLE) else 0.5),
        chain_ewma_inc=None,
        live_bytes=int(index.live_fork_gb() * 1e9) if FORK else 0,
        observed_max=OBSERVED["max_blob"],
        arrivals_at_dstar=0, model=MODEL,
        d_star_hash=(qhash[_dstar] if (_dstar and qhash) else None))
    # GRID SNAP (losslessness fix): states are only ever persisted at absolute
    # multiples of SEG, so a later resume re-enters the same canonical boundary
    # decomposition the cold path uses. Costs at most SEG-1 tokens of skip.
    placements = {(p.pos // SEG) * SEG for p in POLICY.decide(ctx)} - {0}
    # NEVER CUT A BOUNDARY THROUGH THE <image:digest> ATOM.
    #
    # THIS IS NOT safe_depth(). media_regions.py deletes that function by
    # name and is right to: on the EXPANDED stream exo hands faxl, one image
    # is ~1,200 pad tokens, a depth at 6144 is a real position carrying real
    # embeddings, and refusing such depths would leave the five constant
    # reference photographs of an insurance prompt permanently uncacheable.
    # That reasoning stands and applies unchanged to the exo line.
    #
    # The mlx atom stream is a different object. The picture is 18 TEXT tokens
    # spelling "<image:5d56f67f7b365ebd>", whose only purpose is to be swapped
    # for the model's <|vision_start|><|image_pad|><|vision_end|> marker in
    # backends.prefill_with_images. A depth in the middle of that is character
    # twelve of a hex digest. There is no state it could describe.
    #
    # And the swap is per chunk, so a boundary inside the atom destroys it.
    # Measured on a fresh store today, a checkpoint at 1792 against an atom
    # occupying 1780..1798:
    #
    #   vision SKIPPED: no marker in chunk [0:1792]
    #       tail='...three headings.\n<image:2cb8c7bd7a6'
    #   vision SKIPPED: no marker in chunk [1792:1800]
    #       tail='d5faf><|im_end|>\n<|im_start|>assistant'
    #
    # Neither half matches the marker regex, both text-prefill, the vision
    # tower never runs, and the model answers from the preamble alone -- with
    # no cache involved at all. 0820469 said this invariant held "by
    # construction" because the image is one atom; it is 18 tokens, and
    # nothing enforced it.
    #
    # The cost is bounded and small: a placement moves back at most 18
    # positions, and five images is 90 tokens of exclusion rather than the
    # 6,000 safe_depth() would have cost.
    _spans = _atom_spans(tok, ids) if _n_images else []
    if _spans:
        placements = {_clear_of_atoms(p, _spans) for p in placements} - {0}
    if AUDIT:
        _cnt = _STRAT_KW.get("count_of")
        AUDIT.decision(req_id, ctx=asdict(ctx),
                       strategy={"name": STRATEGY, "config": STRAT_CFG},
                       placements=sorted(placements),
                       anchor_count=(_cnt(ctx) if callable(_cnt) else None),
                       fork=fork_rec)
        if fork_rec is not None and not fork_rec["ok"]:
            # register #56: REJECTED write decision with raw signals;
            # predicted_ev stays NULL until M3b's ev_model_version exists.
            AUDIT.lifecycle(req_id, "rejected_write",
                            phash=qhash[fork_rec["d_star"]],
                            pos=fork_rec["d_star"], signals=fork_rec)
    n = len(ids) - 1
    bounds = sorted(placements)
    if fork_pos is not None and fork_pos > resume_pos:
        # rev-3 fix: the fork write is exempt from the schedule; D* is inserted
        # into the prefill bounds so the state materializes exactly there.
        bounds = sorted(set(bounds) | {fork_pos})
    if not bounds or bounds[-1] != n:
        bounds.append(n)   # always prefill through to the end
    pos = resume_pos
    stored, deduped = 0, 0
    written_phashes = set()   # this request's writes: never its own victims
    tpf0 = time.time()
    # PICTURES GO IN ON THE FIRST CHUNK, ONCE.
    #
    # The vision tower turns pixels into embeddings that sit inline in the
    # prompt; running it again on a later chunk would splice the same picture
    # in twice. The ladder's own atom rule means an image never straddles a
    # boundary, so handing the images to the first chunk that is actually
    # prefilled is both sufficient and correct. A resumed request has the
    # image already folded into the checkpoint it resumed from -- that IS the
    # saving, ~6,929 tokens for one photograph on Qwen3-VL-4B.
    # Hand the pictures to EVERY chunk and let the backend decide: a chunk
    # whose text carries no <image:...> marker text-prefills itself, and the
    # one that does carries the vision work. Handing them only to the first
    # chunk broke as soon as the preamble grew long enough to checkpoint --
    # which it must, or nothing is ever cached.
    # ALWAYS offer the pictures, resumed or not.
    #
    # This used to be `if resume_pos == 0 else None`, on the reasoning that a
    # resumed request already had the image folded into its checkpoint. That
    # is true only when the checkpoint covers the image, and with a long
    # shared preamble it never does: the preamble checkpoints, the photograph
    # sits in the chunk AFTER it, and that chunk then prefilled the
    # <image:digest> text as literal tokens. The model dutifully read it back
    # -- "<image:a07175b9b60dc5b2>" -- instead of the receipt.
    #
    # The backend decides per chunk: no marker in this chunk's text means
    # text-prefill it, a marker means run the vision tower. That is the only
    # place with the information to make the call.
    _pending_images = _req_images
    for end in bounds:
        if end <= pos:
            continue
        CACHE.prefill(ids[pos:end], cache, pos, images=_pending_images)
        pos = end
        # NOCACHE: still prefill (the model needs it) but write NO checkpoints.
        # Only checkpoint at a SCHEDULED position (not the ragged final end).
        # (The old refuse-writes-at-cap guard stood here; it starved live
        # traffic behind stale blobs — 21 consecutive hourly cold misses.
        # Writes now always land; scored eviction after the loop makes room.)
        is_fork_here = (fork_pos is not None and pos == fork_pos)
        # Unlicensed also stops WRITING: growing a store for a cache that can
        # never serve from it costs the customer disk for nothing.
        if not NOCACHE and _entitled and (is_fork_here or pos in placements):
            tck0 = time.time()
            ph = qhash[pos] if qhash else prefix_hashes(ids[:pos])[pos]
            # THE KEY THIS ENTRY IS STORED UNDER: tokens AND pictures. One
            # spelling, used by the dedup probe, the write, the protect-set
            # and the hit recorder alike -- see the hit site above for what
            # two spellings cost.
            _ekey = entry_key(ph, _regions, pos)
            # DEDUP, exact: if this precise prefix is already stored, skip the
            # write. Correct by construction (identity, not cosine similarity —
            # the old cosine dedup could merge different prefixes). The invariant
            # agent preamble is thus stored ONCE, ever, across all sessions.
            # FIX D4 (CODE-TRUTH): consult the SAME store the lookup uses (shared DB
            # first, local fallback) — dedup vs the local dict alone re-wrote blobs
            # that the shared DB already holds.
            #
            # PROBED BY entry_key, NOT THE BARE PHASH. Two different
            # photographs at the same offsets share a token prefix and so a
            # phash; probing that, the second photo's write saw the first
            # photo's entry, said "already stored", and nothing was kept --
            # the exact silent discard 14c3cec fixed on the exo store.
            tpr0 = time.time()
            dedup_hit = index.identity_get(_ekey) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if dedup_hit:
                deduped += 1
                if TRIMMABLE and placements and pos == max(placements):
                    # exact repeat: the anchor already exists — keep the
                    # chain registry pointed at it (same phash => no
                    # supersession; record_anchor returns None).
                    _cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                  trim_matched)
                    ANCHORS.record_anchor(_cid, ph, pos, qhash[len(ids)])
                if AUDIT:
                    AUDIT.lifecycle(req_id, "deduped", phash=ph, pos=pos,
                                    ckpt_kind=("extension-fork" if (is_fork_here and fork_kind == "extension")
                                               else "divergence-fork" if is_fork_here
                                               else "grid"))
                cache_blocked_ms += (time.time() - tck0) * 1000
                continue
            # TOKEN PREFIX: content-addressed, write-once (same hash = same file).
            ttk0 = time.time()
            tokf = os.path.join(TOKENS_DIR, f"{ph}.json")
            if not os.path.exists(tokf):
                tmpf = tokf + f".tmp{uuid.uuid4().hex[:8]}"
                # PRIVACY: this is the verbatim token-id prefix (system message
                # included) and decodes straight back to the prompt text. It is
                # REQUIRED — the byte-confirm compares against it, which is what
                # makes a hit exact rather than a hash guess. It MUST NOT be
                # world-readable: 0600 via an fd opened with that mode (never
                # chmod-after-write, which leaves a readable window). Reported by
                # a tester, 2026-09-11: these shipped 0644.
                _fd = os.open(tmpf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(_fd, "w") as tf:
                    json.dump(list(ids[:pos]), tf)
                os.replace(tmpf, tokf)
            tokfile_ms += (time.time() - ttk0) * 1000
            # SIMILARITY KEY: only at >= KEY_MIN_TOKENS (c4 alive; 4-band key
            # complete). Below that the entry is exact-tier-only — the lookup
            # doesn't need a key, and a 3-band key is measured-bad as an embedding.
            ki = kv = None
            # Fork blobs are EXACT-TIER-ONLY (rev 4): the key would be dead
            # weight (~seconds at depth) — skip regardless of KEY_MIN_TOKENS.
            if pos >= KEY_MIN_TOKENS and not is_fork_here:
                tek0 = time.time()
                ki, kv = probe.key(ids[:pos])
                esn_key_ms += (time.time() - tek0) * 1000
            # BLOB NAME: uuid, NOT index.rows — on restart _reload() skips rows whose
            # blob is gone so `rows` shrinks, and a "{rows}.safetensors" name would
            # then collide with a filename a still-live meta row points at (overwrite
            # + two rows aiming at one file). uuid is collision-free across restarts.
            blob = os.path.join(BLOB_DIR, f"ckpt_{uuid.uuid4().hex}.safetensors")
            tw0 = time.time()
            CACHE.save(blob, cache)
            wrote_ms = (time.time() - tw0) * 1000
            ckpt_write_ms += wrote_ms   # grid writes measured AND KEPT (phase 0)
            tup0 = time.time()
            # Keyed on the tokens AND the pictures covered at this depth --
            # see exo_store.entry_key. Without it four different photographs
            # produced ONE store entry and photos 2-4 were discarded silently
            # (measured through the live stack), because write-once saw a
            # directory that already existed.
            # A FAILED CHECKPOINT MUST NOT DISCARD A GOOD ANSWER.
            #
            # The reply has ALREADY been generated by this point; storing it
            # is an optimisation for the NEXT request. Letting the store's
            # exception propagate turned a correct answer into a Flask HTML
            # 500 -- the customer lost the work and got an error page for a
            # request the model had answered.
            #
            # Measured: a CSR row-id collision (see Index._reload) 500'd every
            # sufficiently long request while the model was answering them
            # perfectly. The cache is allowed to fail; the request is not.
            #
            # LOUD, NOT SILENT: a store that stops storing makes every later
            # request cold, so it is recorded for /api/diagnostics rather than
            # swallowed. Narrow to the write itself -- an error anywhere else
            # in this block is still a real fault.
            try:
                index.add(ki, kv, blob, pos, phash=_ekey,
                          tok=tokf, fork=is_fork_here)
            except Exception as _e:  # noqa: BLE001 - see above
                LOG_FAILURES.append(
                    f"checkpoint write at {pos}: {type(_e).__name__}: {_e}")
                print(f"!! CHECKPOINT WRITE FAILED at {pos} "
                      f"({type(_e).__name__}: {_e}) — the reply is unaffected, "
                      f"but this prefix will not be cached", flush=True)
                try:
                    os.remove(blob)      # nothing points at it now
                except OSError:
                    pass
                cache_blocked_ms += (time.time() - tck0) * 1000
                continue
            upsert_ms += (time.time() - tup0) * 1000
            blob_bytes = None
            try:
                blob_bytes = os.path.getsize(blob)
                _STORE_BYTES[0] += blob_bytes
                OBSERVED["max_blob"] = max(OBSERVED["max_blob"], blob_bytes)
            except OSError as e:
                # M0 loud-failure sweep: a blob we JUST wrote but cannot stat
                # is store corruption, not noise.
                LOG_FAILURES.append(f"stat fresh blob {os.path.basename(blob)}: {e}")
                print(f"!! FRESH BLOB UNSTATTABLE ({blob}: {e}) — store "
                      f"corruption suspected", flush=True)
            stored += 1
            # The protect-set is matched against INDEX keys, so it holds
            # entry_keys. Adding the bare phash protected nothing, and a
            # store at its cap could evict the blob this request had just
            # written, on the same request.
            written_phashes.add(_ekey)
            _kind = ("extension-fork" if (is_fork_here and fork_kind == "extension")
                     else "divergence-fork" if is_fork_here else "grid")
            # B.4: under TRIMMABLE the DEEPEST placement of this request is
            # the chain's live tail ANCHOR — registered per chain, and the
            # chain's previous anchor is superseded (write new -> re-point
            # index -> delete old; ordering per the shipped supersession
            # rule). Shallower placements (with_grid) stay 'grid'.
            _anchor_cid = None
            if TRIMMABLE and placements and pos == max(placements):
                _kind = "anchor"
                _anchor_cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                     trim_matched)
            if AUDIT:
                # per-band summary of the key ALREADY computed above —
                # c1..c4 features for the online learner, zero extra
                # model/reservoir work (None when this write is unkeyed)
                _esn = None
                if ki is not None:
                    _esn = {}
                    for _c in range(4):
                        _pairs = [(i - _c * WIDTH, v)
                                  for i, v in zip(ki, kv)
                                  if _c * WIDTH <= i < (_c + 1) * WIDTH]
                        _pairs.sort(key=lambda t: -abs(t[1]))
                        _esn[f"c{_c+1}"] = {
                            "nnz": len(_pairs),
                            "norm": round(sum(v * v
                                              for _, v in _pairs) ** 0.5,
                                          6),
                            "top": [[i, round(v, 5)]
                                    for i, v in _pairs[:8]]}
                AUDIT.lifecycle(req_id, "stored", phash=ph, pos=pos,
                                ckpt_kind=_kind,
                                blob_id=os.path.basename(blob),
                                nbytes=blob_bytes, chain_id=_anchor_cid,
                                esn=_esn)
            if _anchor_cid is not None:
                tev0 = time.time()
                _old_anchor = ANCHORS.record_anchor(_anchor_cid, ph, pos,
                                                    qhash[len(ids)])
                if _old_anchor is not None:
                    index.remove_blob(int(_old_anchor))
                    if AUDIT:
                        AUDIT.lifecycle(req_id, "superseded",
                                        phash=_old_anchor, by_phash=ph,
                                        chain_id=_anchor_cid)
                evict_ms += (time.time() - tev0) * 1000
            if is_fork_here:
                fork_written = True
                fork_write_ms += wrote_ms
                tev0 = time.time()
                if fork_kind == "extension":
                    # SUPERSESSION: this chain's ancestor FORK blob dies (index
                    # row first; grid blobs never touched). The head was migrated
                    # to this stream during discovery.
                    prev_phash = forkidx.set_chain_fork(qhash[len(ids)], ph, fork_pos)
                    if prev_phash and prev_phash != ph:
                        index.remove_blob(prev_phash)
                        if AUDIT:
                            AUDIT.lifecycle(req_id, "superseded",
                                            phash=prev_phash, by_phash=ph)
                else:
                    ev = index.evict_forks_over_cap(FORK_MAX_LIVE_GB)
                    if ev:
                        print(f"fork LRU: evicted {len(ev)} blob(s) over "
                              f"{FORK_MAX_LIVE_GB} GB cap", flush=True)
                        if AUDIT:
                            for _v in ev:
                                AUDIT.lifecycle(req_id, "evicted", phash=_v)
                evict_ms += (time.time() - tev0) * 1000
            cache_blocked_ms += (time.time() - tck0) * 1000
    pf_secs = time.time() - tpf0
    # STORE-WIDE scored eviction (AM 2026-09-01): after this request's writes
    # land, shrink back under the cap — oldest unpopular blobs first (score =
    # time-since-last-hit / (1 + hits)). Replaces the refuse-writes guard.
    # Sits AFTER pf_secs so housekeeping never pollutes the prefill timing.
    if not NOCACHE and _STORE_BYTES[0] > STORE_CAP_GB * 1e9:
        _protect = set(written_phashes)
        if resumed_phash is not None:
            _protect.add(resumed_phash)
        tev0 = time.time()
        _victims = index.evict_scored_over_cap(STORE_CAP_GB, protect=_protect)
        evict_ms += (time.time() - tev0) * 1000
        if _victims:
            print(f"store eviction: {len(_victims)} blob(s) removed "
                  f"(oldest-unpopular first) — {_STORE_BYTES[0]/1e9:.1f} GB "
                  f"of {STORE_CAP_GB} GB cap", flush=True)
            if AUDIT:
                for _v in _victims:
                    AUDIT.lifecycle(req_id, "evicted", phash=_v)
    pf_tokens = pos - resume_pos
    if pf_tokens > 512 and pf_secs > 0.5:   # update only on meaningful prefills
        PREFILL_TPS["ewma"] = 0.7 * PREFILL_TPS["ewma"] + 0.3 * (pf_tokens / pf_secs)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tas0 = time.time()
        index_maint_ms += forkidx.add_stream(ids, qhash)
        cache_blocked_ms += (time.time() - tas0) * 1000
    if stored or deduped:
        cache_status += f" [ckpt +{stored}/dedup {deduped}]"
    if fork_pos is not None:
        cache_status += f" [fork {fork_kind}@{fork_pos}{'+w' if fork_written else ''}]"
    prefill_skipped = resume_pos       # tokens we did NOT re-prefill thanks to resume
    if _settle:
        # Prefill-only: the answer was already delivered by the request that
        # spawned this settle. Everything below the write loop -- TOTALS, the
        # metrics JSONL, AUDIT.outcome, telemetry completion -- is skipped so
        # the console and the ROI log never count the proxy's own traffic.
        _sdt = time.time() - t0
        # The audit trail stays self-consistent: the writes above logged
        # lifecycle events under this req_id, so the trail gets its outcome
        # row too (honest store work, just never TOTALS/metrics/telemetry).
        if AUDIT:
            AUDIT.outcome(req_id, hit=resume_pos > 0, resume_pos=resume_pos,
                          prompt_len=len(ids), paid=pos - resume_pos,
                          stored=stored, deduped=deduped,
                          fork_written=fork_written, confirm=confirm,
                          wall_s=round(_sdt, 3), ttft_ms=None,
                          cache_blocked_ms=round(cache_blocked_ms, 2))
        print(f"[settle] {len(ids)} tok | resume@{resume_pos} "
              f"paid {pos - resume_pos} | ckpt +{stored}/dedup {deduped} "
              f"| {_sdt:.2f}s | lib={index.rows}", flush=True)
        return jsonify({"faxl": {"settle": True, "cache": cache_status,
                                 "ckpts_written": stored,
                                 "ckpts_deduped": deduped}})
    out_ids, t_first_tok = CACHE.generate(ids, cache, max_tokens)
    text = tok.decode(out_ids)
    dt = time.time() - t0
    ttft_ms = (t_first_tok - treq0) * 1000 if t_first_tok else None

    # PARSE TOOL CALLS — family dispatch (the last Granite-coupled seam, now dual):
    #  Granite: <tool_call>{"name":..,"arguments":{..}}</tool_call> (text tags).
    #  Kimi:    <|tool_calls_section_begin|> <|tool_call_begin|> functions.NAME:IDX
    #           <|tool_call_argument_begin|> {json} <|tool_call_end|> ... — special
    #           tokens, VERIFIED to survive tok.decode round-trip, so text-level
    #           parsing is sound. Lift into OpenAI `tool_calls`; content is what
    #           remains outside the call markup.
    tool_calls, content = parse_tool_calls(text)
    _sniff("response", {
        "raw_model_text": text,          # exactly what the model emitted (incl. any <think>)
        "parsed_tool_calls": tool_calls, # what the parser lifted into OpenAI form
        "content": content,
        "cache_status": cache_status,
    })
    msg = {"role": "assistant", "content": content or None}
    finish = "stop"
    if tool_calls:
        msg["tool_calls"] = tool_calls
        finish = "tool_calls"

    # ---- ROI instrumentation (durable JSONL, one line per request) ----
    hit = resume_pos > 0
    TOTALS["requests"] += 1
    TOTALS["prompt_tokens"] += len(ids)
    TOTALS["prefill_paid"] += prefilled          # tokens actually prefilled this req
    TOTALS["prefill_skipped"] += prefill_skipped  # tokens skipped via resume
    TOTALS["hits"] += 1 if hit else 0
    TOTALS["ckpts_written"] += stored
    TOTALS["ckpts_deduped"] += deduped
    TOTALS["wall_s"] += dt
    tot_prompt = TOTALS["prompt_tokens"] or 1
    rec = {
        "ts": t0, "mode": "nocache" if NOCACHE else "cache",
        # ns identity on EVERY metrics row (KV plan rev 4.1, day one)
        "ns_digest": NS.digest_hex(), "ns_hash": NS.ns_hash(),
        "trimmable": TRIMMABLE,
        "prompt_tokens": len(ids), "out_tokens": len(out_ids),
        "prefill_paid": prefilled, "prefill_skipped": prefill_skipped,
        "hit": hit, "resume_pos": resume_pos,
        # EXACT TIER: hit tier + per-hit confirm outcome + the O(N) hash cost.
        "hit_tier": (("trim" if (trim_rec and trim_rec.get("outcome") == "served")
                      else "exact") if hit else None), "confirm": confirm,
        # KV plan B.2 metrics: trim outcome + costs (gated-out candidates
        # logged with predicted costs, [F5])
        "trim_gate": (trim_rec or {}).get("outcome"),
        "trim_from": ((trim_rec or {}).get("anchor_P")
                      if (trim_rec or {}).get("outcome") == "served" else None),
        "trim_tokens": ((trim_rec["anchor_P"] - trim_rec["d"])
                        if (trim_rec and trim_rec.get("outcome") == "served")
                        else None),
        "hash_build_ms": round(hash_build_ms, 2),
        # REPRO DEBUG: exact prompt id + which blob was loaded, to tell apart
        # "different tail" from "different blob at same cpos" from "true non-determinism".
        "prompt_hash": prompt_hash,
        "resumed_blob": os.path.basename(resumed_blob) if resumed_blob else None,
        "ckpts_written": stored, "ckpts_deduped": deduped,
        "confirm_ms": round(confirm_ms, 2),
        # Phase-0 cache-path spans: cache_blocked_ms is the INCLUSIVE outer
        # accumulator (all cache work in the serialised handler, never
        # prefill/decode); the children below are EXCLUSIVE; residual_ms is
        # the unexplained remainder. index_maint_ms is now add_stream only
        # (D* discovery moved to fork_discovery_ms). ttft_ms is measured
        # directly: request start -> first decoded token.
        "cache_blocked_ms": round(cache_blocked_ms, 2),
        # the extension gate's own EWMA state, recorded so future traces
        # calibrate the simulator exactly (no reconstruction needed)
        "prefill_tps_ewma": round(PREFILL_TPS["ewma"], 1),
        "probe_rpc_ms": round(probe_rpc_ms, 2),
        "blob_load_ms": round(blob_load_ms, 2),
        "fork_discovery_ms": round(fork_discovery_ms, 2),
        "ckpt_write_ms": round(ckpt_write_ms, 1),
        "tokfile_ms": round(tokfile_ms, 2),
        "esn_key_ms": round(esn_key_ms, 2),
        "upsert_ms": round(upsert_ms, 2),
        "evict_ms": round(evict_ms, 2),
        "residual_ms": round(cache_blocked_ms - (
            hash_build_ms + probe_rpc_ms + confirm_ms + blob_load_ms +
            fork_discovery_ms + ckpt_write_ms + tokfile_ms + esn_key_ms +
            upsert_ms + evict_ms + index_maint_ms), 2),
        "ttft_ms": round(ttft_ms, 1) if ttft_ms is not None else None,
        "fork_pos": fork_pos, "fork_kind": fork_kind,
        "fork_gate": fork_gate, "fork_ckpt_written": fork_written,
        "fork_write_ms": round(fork_write_ms, 1),
        "index_maint_ms": round(index_maint_ms, 2),
        "live_fork_gb": round(index.live_fork_gb(), 3),
        "tool_calls": len(tool_calls), "n_tools_offered": len(tools) if tools else 0,
        "wall_s": round(dt, 3), "cache_status": cache_status,
        # running ROI: fraction of ALL prefill tokens we've skipped so far
        "cum_prefill_skipped": TOTALS["prefill_skipped"],
        "cum_prefill_paid": TOTALS["prefill_paid"],
        "cum_skip_frac": round(TOTALS["prefill_skipped"] / (TOTALS["prefill_skipped"] + TOTALS["prefill_paid"] or 1), 4),
        "cum_wall_s": round(TOTALS["wall_s"], 1), "lib_size": index.rows,
    }
    try:
        with open(METRICS, "a") as mf:
            mf.write(json.dumps(rec) + "\n")
    except OSError as e:
        # M0 (ER4/F11): NEVER silent — an apparently-valid incomplete log is
        # the worst outcome. Surfaced in /health; fails collection loudly.
        LOG_FAILURES.append(f"metrics write: {e}")
        print(f"!! METRICS WRITE FAILED ({METRICS}: {e}) — ROI log "
              f"INCOMPLETE{'; COLLECTION INVALID' if COLLECT else ''}",
              flush=True)
    if AUDIT:
        AUDIT.outcome(req_id, hit=hit, resume_pos=resume_pos,
                      prompt_len=len(ids), paid=prefilled, stored=stored,
                      deduped=deduped, fork_written=fork_written,
                      confirm=confirm, wall_s=rec["wall_s"],
                      ttft_ms=rec["ttft_ms"],
                      cache_blocked_ms=rec["cache_blocked_ms"])

    # TELEMETRY COMPLETION — async, off the hot path; mirrors AUDIT.outcome. Only
    # HONESTLY MEASURED spans are set (proto3 can't tell 0 from unset, so an unset
    # span means "not measured", never a plausible zero). saved = cold − warm is
    # left to the aggregator with its basis; here cold is ESTIMATED from the
    # measured prefill EWMA (a global rate — NOT a paired twin).
    if TELEMETRY is not None:
        _pb = _tel.pb
        _tenant = licence.status().get("customer", "") or os.environ.get(
            "FAXL_TENANT", "")   # "" = unattributed; never a fabricated default
        # cold counterfactual: what a cold prefill of the skipped tokens would
        # have cost, at the measured prefill rate. ESTIMATED (rate, not twin).
        # On a MISS prefill_skipped==0, so cold-est==0 and saved==0 by
        # construction — the aggregator needs no miss special-case.
        _cold_ms = (prefill_skipped / max(PREFILL_TPS["ewma"], 1e-6)) * 1000.0
        _cost = _pb.Cost(
            prompt_tokens=len(ids), prefill_paid=prefilled,
            prefill_skipped=prefill_skipped, warm_wall_ms=dt * 1000.0,
            cold_basis=_pb.ESTIMATED, cold_prefill_ms_est=_cold_ms,
            estimator_id="prefill_tps_ewma",
            estimator_version=str(round(PREFILL_TPS["ewma"], 1)))
        if ttft_ms is not None:      # mlx: present; some backends omit → unset
            _cost.has_ttft = True
            _cost.ttft_ms = ttft_ms
        _tim = _pb.Timings(
            hash_build_ms=hash_build_ms, confirm_ms=confirm_ms,
            blob_load_ms=blob_load_ms, prefill_ms=pf_secs * 1000.0,
            decode_ms=max(dt * 1000.0 - pf_secs * 1000.0, 0.0),
            cache_blocked_ms=cache_blocked_ms)
        _tier = (_pb.EXACT if hit and rec["hit_tier"] == "exact"
                 else _pb.TRIM if hit and rec["hit_tier"] == "trim"
                 else _pb.HIT_TIER_UNSPECIFIED)
        # Real ladder WALK (not a one-rung reconstruction): the probes actually
        # tried, deepest-first, each with its confirm outcome — powers the
        # request-detail explainability view (§5.3). phash carried as a
        # tenant-keyed hash (never raw).
        _confirm_map = {"confirm_pass": _pb.CONFIRM_PASS,
                        "confirm_fail": _pb.CONFIRM_FAIL}
        _ladder = []
        for _p in aud_probes:
            _lp = _pb.LadderProbe(
                position=_p["pos"],
                confirm=_confirm_map.get(_p["outcome"],
                                         _pb.CONFIRM_OUTCOME_UNSPECIFIED))
            _lp.rung_key.CopyFrom(TELEMETRY.keyer.keyed_hash(
                _tenant, _p["phash"].encode()))
            _ladder.append(_lp)
        TELEMETRY.emit_completion(
            req_id, tenant=_tenant,
            outcome=(_pb.HIT if hit else _pb.MISS), resume_pos=resume_pos,
            hit_tier=_tier, ladder=_ladder, cost=_cost, out_tokens=len(out_ids),
            timings=_tim, prompt_content=prompt_hash.encode(),
            project=_project_tag(request.headers.get("X-Faxl-Project")
                                 or body.get("faxl_project")))

    print(f"[{cache_status}] {len(ids)} tok | paid {prefilled} skip {prefill_skipped} "
          f"| {len(tool_calls)} tool_call(s) | {dt:.2f}s | lib={index.rows} "
          f"| cum_skip={rec['cum_skip_frac']*100:.0f}%", flush=True)
    # TURN SETTLE: now that the reply exists, get it into the store so the
    # NEXT turn starts warm instead of the one after. Text path only (_n_images
    # settles would re-run the vision tower; their atoms already checkpoint on
    # the write path above). Tool-call turns settle too: the next real prompt
    # extends history + this assistant message, tool results and all.
    if (SETTLE and not _settle and not NOCACHE and _entitled
            and not _n_images
            and (msg.get("content") or msg.get("tool_calls"))):
        _spawn_settle(messages, msg)
    return jsonify({
        "id": f"chatcmpl-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "created": int(t0),
        "model": MODEL,
        "choices": [{"index": 0, "message": msg, "finish_reason": finish}],
        "usage": {"prompt_tokens": len(ids), "completion_tokens": len(out_ids),
                  "total_tokens": len(ids) + len(out_ids)},
        "faxl": {"cache": cache_status, "prefilled_tokens": prefilled,
                 "library_size": index.rows, "latency_s": dt},
    })


@app.route("/v1/models", methods=["GET"])
def models():
    return jsonify({"object": "list", "data": [{"id": MODEL, "object": "model", "owned_by": "faxl"}]})


@app.route("/health", methods=["GET"])
def health():
    # M0: logging/audit failures surface here (never silent). In collection
    # mode they FAIL health (503) — a corpus with holes must not look green.
    problems = list(LOG_FAILURES)
    if AUDIT and AUDIT.failed:
        problems.append(AUDIT.failed)
    _tel_health = TELEMETRY.health() if TELEMETRY is not None else None
    if _tel_health:
        problems.extend(_tel_health["failures"])
    body = {"status": "ok" if not problems else "logging-failure",
            "model": MODEL, "library_size": index.rows, "nocache": NOCACHE,
            "collect": COLLECT, "log_failures": problems[:5],
            "n_log_failures": len(problems), "licence": licence.status(),
            "telemetry": _tel_health}
    return jsonify(body), (503 if (problems and COLLECT) else 200)


@app.route("/metrics", methods=["GET"])
def metrics():
    t = dict(TOTALS)
    denom = (t["prefill_skipped"] + t["prefill_paid"]) or 1
    t["skip_frac"] = round(t["prefill_skipped"] / denom, 4)
    t["hit_rate"] = round(t["hits"] / (t["requests"] or 1), 4)
    t["mode"] = "nocache" if NOCACHE else "cache"
    t["backend"] = BACKEND.name
    t["model"] = MODEL
    if BY_PROJECT:
        # skip_frac is served / (served + paid), NOT served / prompt_tokens.
        #
        # Those are two different measures and dividing one by the other gives
        # nonsense: prompt_tokens here counts the token ids the LADDER hashed,
        # while `served` is what the cache handed back — and on a vision
        # request the model expands one image atom into hundreds of positions,
        # so served can exceed the id count outright. Measured: 11,776/5,355
        # reported as "219.9% skipped".
        t["by_project"] = {
            k: dict(v,
                    hit_rate=round(v["hits"] / (v["requests"] or 1), 4),
                    skip_frac=round(
                        v["prefill_skipped"] /
                        ((v["prefill_skipped"] + v["prefill_paid"]) or 1), 4))
            for k, v in BY_PROJECT.items()}
    if BACKEND.name == "exo":
        # On this path the ladder runs in the prefill server thread, so these
        # are the authoritative hit counts -- the handler never probes the
        # store. Reported alongside TOTALS rather than instead of it, so a
        # disagreement is visible rather than hidden.
        t["exo"] = dict(EXO_COUNTS)
        t["exo"]["hit_rate"] = round(
            EXO_COUNTS["hits"] / (EXO_COUNTS["requests"] or 1), 4)
    return jsonify(t)


def main():
    port = int(os.environ.get("FAXL_PORT", "8767"))
    # Loopback by default: the console (and its unauthenticated loopback GETs)
    # assume the proxy is not reachable off-box. Binding elsewhere is an explicit
    # opt-in and prints a loud warning (the console also shows a persistent
    # banner + requires auth on reads when non-loopback — server topology).
    host = os.environ.get("FAXL_HOST", "127.0.0.1")
    if host not in ("127.0.0.1", "localhost", "::1"):
        print(f"!! FAXL_HOST={host} is NOT loopback — the proxy and its /console "
              f"are reachable off-box; ensure auth is configured (the console's "
              f"loopback-GET-no-auth assumption does NOT hold here)", flush=True)
    print(f"faxl proxy on http://{host}:{port}/v1  (model {MODEL})")
    app.run(host=host, port=port, threaded=True)  # FIX D6 (lock serializes inference)


if __name__ == "__main__":
    main()

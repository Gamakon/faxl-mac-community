#!/usr/bin/env python3
"""Halo caching proxy — an OpenAI-compatible /v1/chat/completions endpoint that
sits between an agent (OpenClaw, or any OpenAI client) and Granite, and does the
prefill caching in the middle.

EXACT-TIER LOOKUP (docs/plan-exact-tier-productionisation.md, implements the
boxcar decision docs/boxcar-ladder-result.md §7): a hit requires IDENTITY,
similarity is RETRIEVAL. Per request:
  1. Build the prompt (chat template) from the messages.
  2. Compute the prompt's polynomial prefix-hash array (one O(N) pass,
     ~0.18µs/token — no ESN on the lookup path).
  3. For each scheduled checkpoint position, deepest first: look up the
     exact-tier index by prefix hash; on a hit, CONFIRM by comparing the
     stored token prefix byte-for-byte (collision belt-and-braces; outcome
     logged per hit).
     - CONFIRMED: load that checkpoint's recurrent state, prefill ONLY the
       tail beyond it. (identical prefix -> identical state, F3)
     - no confirmed hit: prefill the whole prompt cold. NO cosine fallback —
       near-dup resume serves stale output (semantic-reuse falsification).
  4. CHECKPOINT the resulting state at scheduled positions (blob on disk),
     registering: prefix hash + token prefix (content-addressed, write-once)
     always; an ESN/UltraDim similarity key ONLY at >= KEY_MIN_TOKENS=1025
     (c4 alive, 4-band key complete) — similarity keys serve retrieval and
     near-miss telemetry, never the hit decision.
  5. Return an OpenAI-shaped response.

The old cosine walk (SNAP + tail floors) was REMOVED 2026-08-15 (audit D9):
dead code with no caller. Measured record: wrong-prefix hits 308/420 at SNAP
0.6 (157 at 0.96), rejects 31/135 byte-identical replays
(docs/boxcar-e3.jsonl). It lives in git history.

So: kill the agent, restart it, give it a similar task -> the proxy finds the
prior state and resumes warm instead of cold. That is the cost win, and the
service.

Run:   python3 integration/faxl_proxy.py            (serves on :8080)
Point an OpenAI client at http://localhost:8080/v1 with any api key.
Requires: MLX, and the faxl + ultradim wheels (see QUICKSTART.md).
"""
import hashlib
import json
import re
import os
from dataclasses import asdict
import threading
import time
import uuid

import mlx.core as mx
from flask import Flask, Response, request, jsonify
# The compiled cache core. Absent = the proxy cannot cache; fail LOUD at import
# rather than silently degrading to a pass-through nobody notices.
try:
    import faxl
except ImportError as _e:
    faxl = None
    print(f"[faxl] FATAL: the 'faxl' wheel is not installed ({_e})", flush=True)
# Register out-of-tree mlx_lm model loaders Halo carries (e.g. Ling's
# bailing_hybrid = KDA+MLA+MoE). No-op for models mlx_lm already knows; injects
# into sys.modules so `mlx_lm.load` resolves them without patching site-packages.
try:
    from faxl.engine import mlx_models as _faxl_mlx_models
    _faxl_mlx_models.register()
except Exception as _e:  # never block startup on an optional loader
    print(f"[faxl] mlx_models.register skipped: {_e}", flush=True)
from mlx_lm import load
from mlx_lm.models.cache import (make_prompt_cache, save_prompt_cache,
                                 load_prompt_cache, can_trim_prompt_cache,
                                 trim_prompt_cache)
from mlx_lm.generate import generate_step
from mlx_lm.sample_utils import make_sampler

MODEL = os.environ.get("FAXL_MODEL", "mlx-community/granite-4.0-h-small-8bit")
BLOB_DIR = os.environ.get("FAXL_BLOBS", "/tmp/faxl_proxy_blobs")
# FAXL_DB: the user-managed directory for the PERSISTENT UltraDim key store + the
# key→blob index. A cache is not a database if the user cannot say where it lives.
# Default is a stable named dir (NOT a temp dir) so restarts reload the same store.
DB_DIR = os.environ.get("FAXL_DB", os.path.join(BLOB_DIR, "ultradim_db"))
META_PATH = os.path.join(DB_DIR, "meta.json")
# TOKENS_DIR: content-addressed token prefixes for the exact tier — tokens/<phash>.json
# holds ids[:cpos] for every checkpoint with that prefix hash. Identical prefixes across
# requests/sessions share one file (write-once); ~4 B/token, negligible vs blobs.
TOKENS_DIR = os.environ.get("FAXL_TOKENS", os.path.join(BLOB_DIR, "tokens"))
# FIX D5 (CODE-TRUTH): the defaults above live under /tmp and vanish on reboot.
# A cache whose store silently evaporates is a correctness trap for its operator.
def _volatile(p):
    return os.path.realpath(p).startswith(("/tmp", "/private/tmp", "/var/folders"))
if _volatile(BLOB_DIR) or _volatile(DB_DIR):
    print(f"!! VOLATILE STORE: blobs={BLOB_DIR} db={DB_DIR} are under /tmp and "
          f"will NOT survive a reboot. Set FAXL_BLOBS/FAXL_DB to persistent "
          f"paths for production.", flush=True)
SEG = 256
# ESN keys are written only for checkpoints at >= this depth (AM directive): below
# 1025 the stride-1024 c4 band has never fired, so the 4-band key is incomplete and
# measured-bad as an embedding. Sub-1025 checkpoints are exact-tier-only entries.
KEY_MIN_TOKENS = int(os.environ.get("FAXL_KEY_MIN_TOKENS", "1025"))

# Polynomial prefix hash (the exact tier's key; same constants as
# integration/boxcar_ladder.py, measured 570/570 correct, 0 collisions).


# Schedule + prefix hash extracted to ckpt_schedule.py (phase 0, plan v1.5)
# so the simulator and tests import them without loading a model. Schedule v2
# (plan §1): base 250 so short prompts (the translation class, 262–280
# tokens) get a reusable checkpoint — safe because a hit requires an exact
# match. FAXL_CKPT_EVERY / FAXL_CKPT_RATIO env pins are read there.
from faxl.engine.ckpt_schedule import (CKPT_EVERY, CKPT_RATIO, ckpt_positions,  # noqa: F401
                           ckpt_set as _CKPT_SET)
# Prefix hashing moves to the compiled core: same values (verified 0/300
# mismatches vs ckpt_schedule.prefix_hashes), one implementation, and the
# lookup path stays inside the wheel.
prefix_hashes = faxl.prefix_hashes if faxl is not None else None
from faxl.engine.store_lifecycle import (STRATEGIES, ScheduleContext,  # noqa: F401
                             make_policy)
# LICENCE: a signed key file. Absent or lapsed = the cache tier serves misses
# (every prefill cold) while the proxy keeps answering — a lapsed licence must
# never take an inference endpoint down mid-request.
LICENCE_FILE = os.environ.get("FAXL_LICENCE",
                              os.path.expanduser("~/.faxl-licence"))
GATE_TOKENS = int(os.environ.get("FAXL_GATE_TOKENS", "64"))  # skip cache below this
# PLACEMENT STRATEGY SEAM: the write path consumes
# POLICY.decide(ScheduleContext) -> [Placement]. Strategies are named and
# selectable; see store_lifecycle.STRATEGIES for the registry, the measured
# per-workload costs, and how to add another.
#
#   FAXL_STRATEGY=tail_anchor  (DEFAULT) checkpoint at the next turn's resume
#                              point. Measured +25.7% (journal) / +37.8%
#                              (endurance) net cost vs grid; no change on
#                              one-shot traffic.
#   FAXL_STRATEGY=grid         the previous default: geometric ladder only.
#   FAXL_STRATEGY=none         write nothing (control arm).
#
# Tuning: FAXL_TAIL_MARGIN (>=3, a correctness floor — see the class
# docstring), FAXL_TAIL_WITH_GRID=1 to keep the ladder alongside the anchor,
# FAXL_TAIL_MIN_ARRIVALS=N to write the anchor only for chains seen N times
# before (suppresses useless writes on one-shot traffic).
STRATEGY = os.environ.get("FAXL_STRATEGY", "tail_anchor")
_STRAT_KW = {"gate_tokens": GATE_TOKENS}
if STRATEGY in ("grid", "tail_anchor"):
    _STRAT_KW.update(base=CKPT_EVERY, ratio=CKPT_RATIO)
if STRATEGY == "grid":
    _STRAT_KW = {"base": CKPT_EVERY, "ratio": CKPT_RATIO,
                 "gate_tokens": GATE_TOKENS}
elif STRATEGY == "tail_anchor":
    _STRAT_KW.update(
        margin=int(os.environ.get("FAXL_TAIL_MARGIN", "3")),
        with_grid=os.environ.get("FAXL_TAIL_WITH_GRID", "0") == "1",
        min_arrivals=int(os.environ.get("FAXL_TAIL_MIN_ARRIVALS", "0")),
        # continuation evidence: how many EARLIER requests carried the
        # prefix we resumed from. The fork index already counts exactly
        # this (match_counts), so the gate needs no new bookkeeping.
        count_of=lambda ctx: (forkidx.match_counts.get(str(ctx.d_star_hash), 0)
                              if FORK and ctx.d_star_hash else 0))
elif STRATEGY == "none":
    _STRAT_KW = {}
POLICY = make_policy(STRATEGY, **_STRAT_KW)
print(f"placement strategy: {STRATEGY} "
      f"({ {k: v for k, v in _STRAT_KW.items() if k != 'count_of'} })",
      flush=True)
# A/B CONTROL: FAXL_NOCACHE=1 turns the cache OFF (no walk/resume, no checkpoint
# write) while STILL running through the proxy — so we can measure the same task
# with and without Halo and diff the ROI. Everything else (model, tool parsing,
# metrics logging) is identical, isolating the cache's effect.
NOCACHE = os.environ.get("FAXL_NOCACHE", "0") == "1"
# ---- FORK-POINT CHECKPOINTING (docs/plan-fork-point-checkpointing.md rev 5) --
FORK = os.environ.get("FAXL_FORK", "0") == "1"
FORK_TIME_RATIO = float(os.environ.get("FAXL_FORK_TIME_RATIO", "5"))
FORK_AMORT = float(os.environ.get("FAXL_FORK_AMORT", "4"))
FORK_MAX_LIVE_GB = float(os.environ.get("FAXL_FORK_MAX_LIVE_GB", "20"))
# TOTAL blob-store cap (2026-08-19 ENOSPC incident: only forks were
# capped; grid/anchor checkpoints filled 88 GB in one campaign). At
# cap, NEW checkpoint writes are SKIPPED loudly (serve-only for new
# content; existing warm entries keep serving; no deletion semantics).
STORE_CAP_GB = float(os.environ.get("FAXL_STORE_CAP_GB", "60"))
_STORE_BYTES = [0]     # maintained incrementally after boot scan
FORK_GATES_OFF = os.environ.get("FAXL_FORK_GATES_OFF", "0") == "1"  # config (d) demo
STREAMS_DIR = os.environ.get("FAXL_STREAMS", os.path.join(BLOB_DIR, "streams"))
METRICS = os.environ.get("FAXL_METRICS", "/tmp/faxl_metrics.jsonl")  # durable per-request ROI log
# ---- M0 AUDIT TRAIL (master plan v4.1; register rows 55/56/62/76/130) ------
# FAXL_AUDIT_DIR set => per-request audit events (ns identity, full
# prefix-hash arrays, lookup probes, decisions with raw signals, lifecycle,
# outcome) through audit_trail.AuditTrail — the SAME schema the calibrated
# simulator emits, validated by audit_replay.py. Unset => byte-identical
# legacy behaviour. FAXL_COLLECT=1 = corpus-collection mode: audit REQUIRED,
# volatile sinks refused, any logging failure fails /health loudly (an
# apparently-valid incomplete corpus is the worst outcome).
AUDIT_DIR = os.environ.get("FAXL_AUDIT_DIR")
COLLECT = os.environ.get("FAXL_COLLECT", "0") == "1"
if COLLECT and not AUDIT_DIR:
    raise SystemExit("!! FAXL_COLLECT=1 requires FAXL_AUDIT_DIR (durable, "
                     "non-/tmp) — collection without an audit sink is the "
                     "incomplete-corpus trap M0 exists to close")
WORKLOAD = os.environ.get("FAXL_WORKLOAD", "unlabelled")
SESSION_LABEL = os.environ.get("FAXL_SESSION") or f"session-{uuid.uuid4().hex[:8]}"
TENANT = os.environ.get("FAXL_TENANT", "gamakon-dev")
REVISION = os.environ.get("FAXL_MODEL_REVISION", "unpinned")
DTYPE = os.environ.get("FAXL_DTYPE", "as-published")
LOG_FAILURES = []   # loud logging failures; surfaced by /health (M0/F11)
WIDTH = 1 << 16
D_PROJ = 2048
# Projection seeds are Rust-owned config (single source: faxl-probe's resolve_seeds,
# FAXL_SEEDS-overridable). The proxy READS them from the Rust CLI at startup (see
# `SEEDS = probe.seeds()` below) and NEVER declares its own — so the seeds Halo
# computes keys under and the seeds the UltraDim collection is created with are one
# value by construction. SEEDS is bound after `probe` is built.
SEEDS = None
SOURCE_DIM = 4 * WIDTH
FAMILY = "faxl-live"

app = Flask(__name__)

# ---- running ROI totals (across all requests since boot) ----
TOTALS = {"requests": 0, "prompt_tokens": 0, "prefill_paid": 0, "prefill_skipped": 0,
          "hits": 0, "ckpts_written": 0, "ckpts_deduped": 0, "wall_s": 0.0}


# ---- Halo probe (Rust) ----
class Probe:
    """The compiled cache core (faxl wheel).

    Was a subprocess speaking line-JSON to faxl_probe_cli; the reservoir and
    the projection now live in the wheel, so there is no process boundary and
    no pipe to keep in sync. Verified identical to the CLI: same indices,
    cosine 1.0 (the wheel-distribution plan (research archive)).
    """

    def __init__(self):
        if faxl is None:
            raise RuntimeError(
                "the 'faxl' wheel is not installed — pip install the faxl and "
                "ultradim wheels (see QUICKSTART.md)")

    def seeds(self):
        """The Rust-resolved projection seeds (FAXL_SEEDS-overridable). The single
        source; the proxy passes THESE to CreateCollection."""
        return list(faxl.seeds())

    def key(self, tokens):
        return faxl.probe_key(list(tokens))


# ---- UltraDim (embedded wheel) ----
class Licence:
    """Entitlement for the cache tier.

    Enforcement lives in the compiled wheel (faxl.ExactIndex), not here — a
    check in this file is a one-line patch to remove. This class only loads the
    key and reports status.

    On lapse the proxy DEGRADES: it keeps serving, the cache tier stops
    hitting, every prefill runs cold. It never refuses a request — an expired
    licence must not take an inference endpoint down.
    """

    def __init__(self, path=LICENCE_FILE):
        self.customer, self.expiry, self.action = "", 0, "unlicensed"
        # Module-level: the wheel's prefix_hashes/probe_key refuse without it,
        # so deleting this class would not re-enable caching.
        self._gate = faxl
        hw_file = os.path.join(BLOB_DIR, ".faxl-hw")
        try:  # restore the clock high-water mark (anti-rollback)
            if self._gate is not None and os.path.exists(hw_file):
                self._gate.set_high_water(int(open(hw_file).read().strip()))
        except (ValueError, OSError):
            pass
        self._hw_file = hw_file
        if self._gate is None:
            return
        try:
            key = open(path).read().strip()
            key = "".join(ln for ln in key.splitlines() if not ln.startswith("#"))
            self.customer, self.expiry, self.action = self._gate.set_licence(key)
        except FileNotFoundError:
            live, cust, exp, _rem, act = self._gate.licence_status()
            if live:
                # time-limited build (tester wheel): entitled without a key
                self.customer, self.expiry, self.action = cust, exp, act
                days = (exp - time.time()) / 86400.0
                print(f"[faxl] {cust}: cache tier enabled without a key; "
                      f"this build stops accelerating in {days:.0f} days",
                      flush=True)
                return
            print(f"!! NO LICENCE at {path} — cache tier DISABLED (every prefill "
                  f"runs cold). Contact andrew@gamakon.ai.", flush=True)
            return
        except ValueError as e:
            print(f"!! INVALID LICENCE at {path}: {e} — cache tier DISABLED.",
                  flush=True)
            return
        left = (self.expiry - time.time()) / 86400.0
        if left <= 0:
            print(f"!! LICENCE EXPIRED ({self.customer}) — cache tier DISABLED; "
                  f"the proxy still serves, every prefill runs cold.", flush=True)
        else:
            note = "  ** RENEW SOON **" if left < 30 else ""
            print(f"[faxl] licensed to {self.customer}; {left:.0f} days remaining"
                  f"{note}", flush=True)

    def entitled(self):
        """True while the cache tier may serve hits. Checked per request."""
        if self._gate is None:
            return False
        live = self._gate.licence_status()[0]
        try:  # persist the ratchet so a clock rollback cannot revive a lapse
            os.makedirs(os.path.dirname(self._hw_file), exist_ok=True)
            with open(self._hw_file, "w") as f:
                f.write(str(self._gate.high_water()))
                f.flush()
                os.fsync(f.fileno())
        except OSError:
            pass
        return live

    def status(self):
        live, cust, exp, remaining, action = (
            self._gate.licence_status() if self._gate else (False, "", 0, 0, "unlicensed"))
        return {"licensed": live, "customer": cust, "expiry": exp,
                "days_remaining": round(remaining / 86400.0, 1), "on_expiry": action}


class Index:
    def __init__(self):
        import ultradim
        # PERSISTENT store in the user-managed FAXL_DB dir (not a temp dir), so a
        # restart reloads the same keys+blobs. meta.json holds row_id -> (blob, cpos,
        # key) so we can re-upsert every key into a fresh collection on startup.
        os.makedirs(DB_DIR, exist_ok=True)
        self.db = ultradim.UltraDim(DB_DIR)
        # LOOKUP VIA ULTRADIM (CR EXACT_IDENTITY_GET, wheel 0.3.5): a keyed
        # checkpoint carries its lookup digest as a `content_key` keyword facet, and
        # the lookup is GetUltradimV23RowByContentKey — a walk-free, pre-settle
        # identity get, so the shared DB owns the lookup (not a node-local dict) and
        # the analytics arms see live cache traffic. If the wheel predates the RPC,
        # warn loudly and serve from the local index (resilience over refusal);
        # a clean DB not-found still consults the local dict (sub-1025 entries).
        self._has_identity_get = "GetUltradimV23RowByContentKey" in set(self.db.capabilities())
        if not self._has_identity_get:
            print("!! ULTRADIM WHEEL LACKS GetUltradimV23RowByContentKey — need "
                  ">=0.3.5; lookups fall back to the LOCAL exact dict (node-local, "
                  "no cross-machine share, no analytics). Upgrade the wheel.", flush=True)
        self.built = False
        self.rows = 0        # next UltraDim row id — KEYED entries only (the CSR
                             # requires contiguous row_ids, so exact-only entries
                             # must never consume one)
        self.meta = {}       # UltraDim row_id -> (blob path, cpos)
        self.rid_tok = {}    # UltraDim row_id -> tok file (for byte-confirm on an
                             # identity-get hit; rid comes back from the RPC, tok
                             # is what confirm needs)
        self.fork_blobs = {} # phash -> {blob, cpos, bytes, last_resume} (FORK blobs only)
        self.exact = {}      # prefix hash -> (blob, cpos, tok_file) — LOCAL fallback
                             # + sub-KEY_MIN_TOKENS exact-only lookups (v1 has no
                             # decoupled id space, so those can't move to UltraDim)
        # PERSISTENCE (VERIFIED 2026-08-10): UltraDim persists points AND the trellis
        # index to disk (udv23_csr/keys/registry/trellis). A discriminating probe on
        # the reopened Canada store returned score 1.000 on a stored key with NO
        # re-upsert and NO rebuild (candidates_pooled=34, trellis phase=done). So a
        # reopen must NOT re-run CreateCollection (errors "already registered") and
        # must NOT re-upsert (would duplicate every persisted row). It restores only
        # the row->blob map from meta.json and marks the index already built.
        reopened = False
        try:
            self._call("CreateUltradimV23Collection", {
                "name": FAMILY, "source_dim": SOURCE_DIM, "projection_dim": D_PROJ, "seeds": SEEDS,
                "sparse_substrate": True, "max_nnz_per_row": 4 * 512 + 400,
                "matrix_type": "rademacher_hash_v1", "projection_mode": "formula", "trellis_only": True,
                # NB: `window` is NOT a CreateCollection field (0.3.4 rejects it) — it
                # lives on the build/settle path only. See `_ensure_built`.
            })
        except RuntimeError as e:
            msg = str(e).lower()
            if "already" in msg or "registered" in msg or "exist" in msg:
                reopened = True  # collection + its points already persisted on disk
            else:
                raise
        if reopened:
            # DRIFT GUARD: the persisted family's seeds are the source of truth for
            # an existing collection (UltraDim hashes them into family identity). If
            # the configured SEEDS no longer match what this store was created with,
            # every key we compute would silently mismatch — fail loud, never serve.
            try:
                info = self._call("GetUltradimV23CollectionInfo", {"name": FAMILY})
                stored = list(info.get("seeds") or [])
                if stored and stored != list(SEEDS):
                    raise SystemExit(
                        f"!! SEED DRIFT: collection {FAMILY!r} was created with "
                        f"seeds {stored} but configured seeds are {list(SEEDS)}. A "
                        f"mismatch silently invalidates every key. Set FAXL_SEEDS to "
                        f"{stored} to serve this store, or use a fresh FAXL_DB.")
            except RuntimeError as e:
                # FIX D7: don't block startup on the guard itself, but say so — a
                # skipped guard means seed drift would go undetected this run.
                print(f"!! SEED-DRIFT GUARD SKIPPED (CollectionInfo unavailable: {e}) "
                      f"— serving without drift protection", flush=True)
        self._reload(reopened)

    def _reload(self, reopened):
        """Restore the row_id -> (blob, cpos) map from a prior run's meta.json.

        UltraDim persists the vectors + trellis itself (VERIFIED), so we do NOT
        re-upsert on a reopen — we only rebuild the in-process meta map keyed by the
        SAME row ids the store persisted (meta rows carry their `row`). On a FRESH
        collection (no persisted points) meta.json shouldn't exist; if it does (e.g.
        the store dir was cleared but meta.json left behind) we re-upsert to repair."""
        if not os.path.exists(META_PATH):
            return
        try:
            saved = json.load(open(META_PATH))
        except Exception:
            return
        loaded, maxrid = 0, -1
        for row in saved:
            blob, cpos, rid = row["blob"], row["cpos"], row["row"]
            if not os.path.exists(blob):
                continue  # blob gone: leave the persisted point, just don't map it
            # EXACT TIER: rows written by this version carry phash+tok; restore the
            # hash index. Pre-exact-tier rows (no phash) stay retrieval-only — they
            # can never hit, because a hit requires the token confirm.
            if row.get("phash") and row.get("tok") and os.path.exists(row["tok"]):
                self.exact[row["phash"]] = (blob, cpos, row["tok"])
                if row.get("fork"):
                    self.fork_blobs[row["phash"]] = {
                        "blob": blob, "cpos": cpos,
                        "bytes": os.path.getsize(blob), "last_resume": 0.0}
            if rid is not None:
                # keyed entry: a persisted UltraDim point exists at this rid
                if not reopened and row.get("idx") is not None:
                    # fresh collection but meta present -> repopulate at their rid
                    self._call("UpsertUltradimV23Points", {
                        "name": FAMILY, "batch": {"row_ids": [rid],
                            "sparse_vectors": [{"indices": row["idx"], "values": row["val"]}]}})
                self.meta[rid] = (blob, cpos)
                if row.get("tok"):
                    self.rid_tok[rid] = row["tok"]
                maxrid = max(maxrid, rid)
            loaded += 1
        # next new row must not collide with a persisted id
        self.rows = maxrid + 1
        self.built = reopened  # persisted trellis is already built; fresh needs settle
        print(f"Halo index restored {loaded} checkpoints from {META_PATH} "
              f"(reopened={reopened}, next_rid={self.rows}, built={self.built})")

    def _persist(self, rid, idx, val, blob, cpos, phash=None, tok=None, fork=False):
        """Append one checkpoint to meta.json (rewrite whole file — small, JSON).
        idx/val may be None (exact-tier-only entry below KEY_MIN_TOKENS)."""
        cur = []
        if os.path.exists(META_PATH):
            try:
                cur = json.load(open(META_PATH))
            except Exception:
                cur = []
        cur.append({"row": rid, "idx": idx, "val": val, "blob": blob, "cpos": cpos,
                    "phash": phash, "tok": tok, "fork": bool(fork)})
        tmp = META_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cur, f)
        os.replace(tmp, META_PATH)

    def _call(self, rpc, obj):
        r = self.db.call_json(rpc, json.dumps(obj))
        o = json.loads(r) if isinstance(r, str) and r.strip()[:1] in "{[" else r
        if isinstance(o, dict) and o.get("error_message"):
            raise RuntimeError(f"{rpc}: {o['error_message']}")
        return o

    def add(self, idx, val, blob_path, cpos, phash=None, tok=None, fork=False):
        """Register one checkpoint. idx/val may be None: an exact-tier-only entry
        (checkpoint below KEY_MIN_TOKENS — no similarity key is written, the lookup
        needs only phash+tok). MEASURED (2026-08-09): in the EMBEDDED wheel a
        post-settle upsert is NOT searchable until a re-settle (the doc flags
        embedded-vs-gRPC parity as ungraded; verified: a row added after settle is
        invisible to search). So a keyed add marks the index dirty; `_ensure_built`
        re-settles once, lazily, before the next search — but callers should BATCH
        their adds so only ONE settle runs per request, not one per checkpoint."""
        rid = None
        if idx is not None:
            # keyed entry: consumes the next CONTIGUOUS UltraDim row id
            rid = self.rows
            batch = {"row_ids": [rid], "sparse_vectors": [{"indices": idx, "values": val}]}
            # LOOKUP DIGEST as a `content_key` keyword facet (CR EXACT_IDENTITY_GET):
            # GetUltradimV23RowByContentKey matches this exactly, walk-free and
            # pre-settle, so the lookup lives in the shared DB. Written only on keyed
            # (>= KEY_MIN_TOKENS) rows — v1 has no decoupled id space, so a
            # content_key point IS a cosine row; sub-1025 exact-only lookups stay
            # local (see plan-ultradim-lookup-restore.md, CR Q2).
            if phash is not None:
                # content_key is a KEYWORD facet -> must be a STRING; prefix_hashes()
                # returns an int, so stringify (identity_get stringifies the query key
                # the same way).
                batch["facets"] = [{"fields": {"content_key": {"kind": {"KeywordValue": str(phash)}}}}]
            self._call("UpsertUltradimV23Points", {"name": FAMILY, "batch": batch})
            self.meta[rid] = (blob_path, cpos)
            if tok is not None:
                self.rid_tok[rid] = tok
            self.rows += 1
            self.built = False  # dirty until re-settled (embedded-wheel requirement)
        if phash is not None:
            self.exact[phash] = (blob_path, cpos, tok)
            if fork:
                self.fork_blobs[phash] = {"blob": blob_path, "cpos": cpos,
                                          "bytes": (os.path.getsize(blob_path)
                                                    if os.path.exists(blob_path) else 0),
                                          "last_resume": time.time()}
            # FIX D2 (CODE-TRUTH): content-addressed resolve record on the STORE, so
            # a checkpoint written by one node is resolvable by any node that shares
            # the store — the lookup no longer depends on the writer's in-memory maps.
            # Write-once, like the token file (same hash = same record).
            rec = os.path.join(TOKENS_DIR, f"{phash}.meta.json")
            if not os.path.exists(rec):
                tmp = rec + ".tmp"
                with open(tmp, "w") as f:
                    json.dump({"blob": blob_path, "cpos": cpos, "tok": tok}, f)
                os.replace(tmp, rec)
        self._persist(rid, idx, val, blob_path, cpos, phash, tok, fork=fork)  # survive restart
        return rid

    def known_positions(self):
        """Sorted set of every position where this node knows a blob exists —
        grid AND fork (rev-2 fix: fork blobs must be findable by the lookup
        probe or they are write-only)."""
        out = {cpos for (_b, cpos, _t) in self.exact.values()}
        out.update(cpos for (_b, cpos) in self.meta.values())
        return sorted(out, reverse=True)

    def live_fork_gb(self):
        return sum(f["bytes"] for f in self.fork_blobs.values()) / 1e9

    def touch_resume(self, phash):
        f = self.fork_blobs.get(phash)
        if f:
            f["last_resume"] = time.time()

    def remove_blob(self, phash):
        """Supersession/eviction delete: index rows FIRST, then the blob file
        (a raced request falls cold via the guarded load, never 500s). Token
        files stay (content-addressed, shared). FORK blobs only."""
        f = self.fork_blobs.pop(phash, None)
        ent = self.exact.pop(phash, None)
        rec = os.path.join(TOKENS_DIR, f"{phash}.meta.json")
        # M0 loud-failure sweep (F11): store mutations must never fail
        # silently — a stale record/blob/meta row resurrects deleted state
        # or leaks bytes, and silence hides it (Rules: fail-open is design,
        # a swallowed bug is not). Removal proceeds (the delete itself is
        # still wanted) but every failure is printed and surfaced in /health.
        try:
            if os.path.exists(rec):
                os.remove(rec)
        except OSError as e:
            LOG_FAILURES.append(f"remove resolve record {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: resolve record {rec} not "
                  f"removed ({e}) — a shared-store node may still serve the "
                  f"deleted checkpoint", flush=True)
        blob = f["blob"] if f else (ent[0] if ent else None)
        if blob:
            try:
                _STORE_BYTES[0] -= (os.path.getsize(blob)
                                    if os.path.exists(blob) else 0)
                os.remove(blob)
            except OSError as e:
                LOG_FAILURES.append(f"remove blob {phash}: {e}")
                print(f"!! STORE MUTATION FAILED: blob {blob} not removed "
                      f"({e}) — orphan bytes leak against the cap", flush=True)
        # meta.json: rewrite without this row
        try:
            cur = [r for r in json.load(open(META_PATH))
                   if r.get("phash") != phash]
            tmp = META_PATH + ".tmp"
            with open(tmp, "w") as fo:
                json.dump(cur, fo)
            os.replace(tmp, META_PATH)
        except Exception as e:
            LOG_FAILURES.append(f"meta rewrite on remove {phash}: {e}")
            print(f"!! STORE MUTATION FAILED: meta.json rewrite ({e}) — a "
                  f"restart will RESURRECT removed row {phash}", flush=True)

    def evict_forks_over_cap(self, cap_gb):
        """FAXL_FORK_MAX_LIVE_GB: evict least-recently-RESUMED fork blobs
        (fork blobs only; grid blobs untouched). Returns the VICTIM phash
        list (M0: the audit trail records each eviction; len() is the
        count callers report)."""
        evicted = []
        while self.live_fork_gb() > cap_gb and self.fork_blobs:
            victim = min(self.fork_blobs, key=lambda k: self.fork_blobs[k]["last_resume"])
            self.remove_blob(victim)
            evicted.append(victim)
        return evicted

    def resolve_from_store(self, phash):
        """FIX D2: resolve phash -> (blob, cpos, tok) from the shared store's
        content-addressed record, independent of this node's in-memory maps.
        Returns None if no record, or if the blob/token files are missing."""
        rec = os.path.join(TOKENS_DIR, f"{phash}.meta.json")
        try:
            with open(rec) as f:
                m = json.load(f)
        except Exception:
            return None
        blob, cpos, tokf = m.get("blob"), m.get("cpos"), m.get("tok")
        if not blob or not tokf or not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def exact_lookup(self, phash):
        """Exact-tier candidate: (blob, cpos, tok_file) for this prefix hash, or None.
        The CALLER must confirm by token compare before resuming (belt and braces
        against the ~2^-61 hash collision; confirm outcome is logged per hit)."""
        ent = self.exact.get(phash)
        if ent is None:
            return None
        blob, cpos, tokf = ent
        if not os.path.exists(blob) or not tokf or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    def identity_get(self, content_key):
        """Exact identity lookup via UltraDim (CR EXACT_IDENTITY_GET, wheel 0.3.5):
        GetUltradimV23RowByContentKey is a walk-free, pre-settle keyword-facet get.
        Returns (blob, cpos, tok_file) for an exact hit, else None — same shape as
        exact_lookup, so the caller's byte-confirm is unchanged. Falls back to the
        local exact dict when the wheel lacks the RPC. The rid->tok/(blob,cpos) maps
        are the proxy's own row bookkeeping (the RPC returns only the row id)."""
        if not self._has_identity_get:
            return self.exact_lookup(content_key)
        try:
            # content_key is stored as a keyword (string) facet; the digest is an int
            # from prefix_hashes(), so query with the same str() form we wrote.
            r = self._call("GetUltradimV23RowByContentKey",
                           {"name": FAMILY, "content_key": str(content_key)})
        except RuntimeError as e:
            # FIX D8: never fail the request on a get error, but never be silent either.
            print(f"!! IDENTITY-GET RPC ERROR ({e}) — falling back to the local "
                  f"exact dict for this lookup", flush=True)
            return self.exact_lookup(content_key)
        if not r.get("found"):
            # FIX D1 (CODE-TRUTH): sub-KEY_MIN_TOKENS checkpoints are exact-tier-only
            # (no content_key row in UltraDim), so a clean not-found MUST still
            # consult the local dict or those checkpoints are write-only forever.
            # FIX D2: then the shared store's resolve record (another node's write).
            return self.exact_lookup(content_key) or self.resolve_from_store(content_key)
        rid = r.get("row_id")
        ent = self.meta.get(rid)
        tokf = self.rid_tok.get(rid)
        if ent is None or not tokf:
            # rid known to the shared DB but not to this node: FIX D2 — resolve from
            # the store's content-addressed record (cross-node hit), then local dict.
            return self.resolve_from_store(content_key) or self.exact_lookup(content_key)
        blob, cpos = ent
        if not os.path.exists(blob) or not os.path.exists(tokf):
            return None
        return blob, cpos, tokf

    # (cosine walk / trellis search surface removed 2026-08-15 — dead code on
    #  the serving path, audit D9; measured wrong-prefix hits 308/420 at
    #  SNAP 0.6. Record: git history + docs/boxcar-ladder-result.md.)


print(f"loading {MODEL} ...")
# trust_remote_code: Kimi ships a custom tiktoken tokenizer (tokenization_kimi.py) that
# must execute to load. This means ANY model repo loaded here runs its own tokenizer
# code — only point FAXL_MODEL at repos you trust. Off by default; opt in via
# FAXL_TRUST_REMOTE_CODE=1 (Granite doesn't need it).
_TRUST = os.environ.get("FAXL_TRUST_REMOTE_CODE", "0") == "1"
model, tok = load(MODEL, tokenizer_config={"trust_remote_code": _TRUST})
# STOP IDS: stop on the UNION of the model's eos ids. Granite terminates on
# tok.eos_token_id; Kimi's chat turns end on <|im_end|> (163586), exposed via
# tok.eos_token_ids, NOT tok.eos_token_id ([EOS]=163585). Missing it runs every
# reply to max_tokens. Union is correct for both families.
STOP_IDS = set()
if tok.eos_token_id is not None:
    STOP_IDS.add(int(tok.eos_token_id))
STOP_IDS |= {int(x) for x in (getattr(tok, "eos_token_ids", None) or set())}
print(f"stop ids: {sorted(STOP_IDS)}")
sampler = make_sampler(temp=0.0)
# Phase A (plan-kv-model-support rev 4.1): capability detection at boot —
# pure-KV models (KVCache) are trimmable, hybrids (ArraysCache) are not;
# can_trim_prompt_cache detects the family automatically.
_cap_probe = make_prompt_cache(model)
TRIMMABLE = can_trim_prompt_cache(_cap_probe)
del _cap_probe
print(f"trimmable (pure-KV family): {TRIMMABLE}", flush=True)
licence = Licence()
probe = Probe()
SEEDS = probe.seeds()   # single source: Rust resolve_seeds() (FAXL_SEEDS-overridable)
print(f"projection seeds (from Rust): {SEEDS}", flush=True)
index = Index()
# boot scan for the total-store cap (one pass; then incremental)
try:
    os.makedirs(BLOB_DIR, exist_ok=True)
    _STORE_BYTES[0] = sum(
        os.path.getsize(os.path.join(BLOB_DIR, f))
        for f in os.listdir(BLOB_DIR) if f.endswith(".safetensors"))
    print(f"store bytes at boot: {_STORE_BYTES[0]/1e9:.2f} GB "
          f"(cap {STORE_CAP_GB} GB)", flush=True)
except OSError as _e:
    print(f"!! store-cap boot scan failed: {_e}", flush=True)

forkidx = None
NVME_BPS = float(os.environ.get("FAXL_NVME_BPS", "0")) or None
PREFILL_TPS = {"ewma": float(os.environ.get("FAXL_PREFILL_TPS", "250"))}
OBSERVED = {"max_blob": 0}
# ---- TRIM-ON-LOAD (KV plan Phase B; pure-KV models only) -------------------
# Under TRIMMABLE the stream index runs for D* discovery even with fork off
# (B.3: the trim path needs D*), fork BLOB WRITES are suppressed (the anchor
# dominates every fork write), and the chain's live tail anchor supersedes
# its ancestor every turn (B.4) — chain identity via trim_lookup.AnchorRegistry
# (inherited on every extension turn, i.e. head migration is UNCONDITIONAL).
ANCHORS = None
LOAD_FIT = {"intercept_ms": 8.4, "slope_ms_per_gb": 38.7}
try:
    LOAD_FIT = json.load(open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "data", "write-cost.json")))["fits"]["load"]
except Exception as _e:
    print(f"!! load-fit table unreadable ({_e}) — using committed defaults",
          flush=True)
if TRIMMABLE:
    from faxl.engine.trim_lookup import AnchorRegistry, economic_gate as trim_economic_gate, resolve_candidate
    ANCHORS = AnchorRegistry(os.path.join(DB_DIR, "anchor_state.json"))
if FORK or TRIMMABLE:
    from faxl.engine.fork_index import ForkIndex as _FI
    if forkidx is None:
        forkidx = _FI(STREAMS_DIR, os.path.join(DB_DIR, "fork_state.json"))
if FORK:
    from faxl.engine.fork_index import (extension_gate, divergence_gate,
                            blob_bytes_predicted, model_slope)
    # BOOT VALIDATION (plan v1.5): an unmeasured model must fail HERE, not
    # mid-request — blob_bytes_predicted/model_slope now raise for unknowns.
    from faxl.engine.fork_index import model_slope as _ms_check
    _ms_check(MODEL)   # raises UnknownModelCurve with instructions if unmeasured
    if NVME_BPS is None:
        # measure the store's write bandwidth once (32 MB, fsync'd) — the
        # extension gate's write-cost side uses a MEASURED number, not a guess.
        _probe_path = os.path.join(BLOB_DIR, ".nvme_probe")
        _t0 = time.time()
        with open(_probe_path, "wb") as _f:
            _f.write(b"\0" * (32 << 20))
            _f.flush(); os.fsync(_f.fileno())
        NVME_BPS = (32 << 20) / max(time.time() - _t0, 1e-6)
        os.remove(_probe_path)
        print(f"fork: measured store write bandwidth {NVME_BPS/1e9:.2f} GB/s", flush=True)
    print(f"fork-point checkpointing ON (gates {'OFF — demo' if FORK_GATES_OFF else 'rev-5'}; "
          f"ratio={FORK_TIME_RATIO} amort={FORK_AMORT} cap={FORK_MAX_LIVE_GB}GB)", flush=True)
# ---- M0 audit trail construction (after SEEDS/index so identity is real) ---
AUDIT = None
STRAT_CFG = {k: v for k, v in _STRAT_KW.items() if k != "count_of"}
# Namespace identity is UNCONDITIONAL (KV plan rev 4.1 / register #76/130:
# recorded on every metrics row from day one — unretrofittable).
from faxl.engine.ns_identity import NamespaceIdentity
_cfg_hash = hashlib.sha256(json.dumps(
    {"seeds": list(SEEDS), "width": WIDTH, "d_proj": D_PROJ,
     "family": FAMILY}, sort_keys=True).encode()).hexdigest()[:16]
NS = NamespaceIdentity(
    tenant_domain=TENANT, model=MODEL, revision=REVISION, backend="mlx",
    dtype=DTYPE, cache_format="mlx_safetensors_v1", config_hash=_cfg_hash)
if AUDIT_DIR:
    from faxl.engine.audit_trail import AuditTrail
    try:
        from faxl.engine.fork_index import _curve as _m0_curve
        _m0_flat, _m0_slope = _m0_curve(MODEL)
        _curve_meta = {"flat": _m0_flat, "slope": _m0_slope}
    except Exception:
        _curve_meta = None   # unmeasured model: FORK boot check governs
    AUDIT = AuditTrail(AUDIT_DIR, SESSION_LABEL, NS, collect=COLLECT, meta={
        "emitter": "proxy", "dstar_semantics": "fork_only",
        "strategy": {"name": STRATEGY, "config": STRAT_CFG},
        "fork_enabled": FORK, "gates_off": FORK_GATES_OFF,
        "fork_cap_gb": FORK_MAX_LIVE_GB, "evict_cap_bytes": None,
        "workload": WORKLOAD, "model_curve": _curve_meta,
        "gate_constants": {"time_ratio": FORK_TIME_RATIO, "amort": FORK_AMORT},
        "nocache": NOCACHE, "store_fresh": len(index.exact) == 0,
        "trimmable": TRIMMABLE, "load_fit": LOAD_FIT,
        "collect": COLLECT})
    print(f"M0 audit trail ON -> {AUDIT.path} (collect={COLLECT}, "
          f"session={SESSION_LABEL}, ns={NS.digest_hex()[:16]})", flush=True)

# ---- TELEMETRY (the collection contract; docs/proxy-console-telemetry-plan.md) --
# One transaction -> one designed protobuf event stream (START sync/fail-closed,
# COMPLETION async). The console reads this, NOT the incidental metrics JSONL.
# FAXL_TELEMETRY=0 opts out (byte-identical legacy behaviour otherwise).
from faxl.engine import faxl_telemetry as _tel
_BACKEND_ENUM = {"mlx": _tel.pb.MLX, "hf": _tel.pb.HF,
                 "vllm": _tel.pb.VLLM}.get(
                     os.environ.get("FAXL_BACKEND", "mlx"), _tel.pb.MLX)
TELEMETRY = None
if os.environ.get("FAXL_TELEMETRY", "1") == "1":
    _tpath = os.environ.get("FAXL_TELEMETRY_WAL",
                            os.path.expanduser("~/.faxl/telemetry/events.bin"))
    if _tel.is_volatile_path(_tpath):
        # The collection log is the product's evidence base, not scratch.
        print(f"!! FAXL_TELEMETRY_WAL {_tpath} is a VOLATILE path — history "
              f"will evaporate on reboot; set a durable path", flush=True)
    TELEMETRY = _tel.Telemetry(
        _tel.FileWal(_tpath), _tel.TenantKeyer(),
        backend=_BACKEND_ENUM, model=MODEL,
        boot_id=os.environ.get("FAXL_BOOT_ID", uuid.uuid4().hex[:12]),
        determinism_config_id=os.environ.get("FAXL_DETERMINISM_CONFIG", ""))
    print(f"telemetry ON -> {_tpath} (backend="
          f"{_tel.pb.Backend.Name(_BACKEND_ENUM)}, model={MODEL})", flush=True)
    # Console: the aggregator reads the SAME WAL (refresh-on-read), and the
    # blueprint serves /console + /api/* from it. index_stats is injected so the
    # console never imports serving internals.
    from faxl.engine import faxl_aggregator as _agg
    from faxl.engine import faxl_console as _console
    _AGGREGATOR = _agg.Aggregator()

    def _index_stats():
        try:
            return {"available": True, "entries": len(index.exact),
                    "rows": index.rows, "live_fork_gb": round(index.live_fork_gb(), 3)}
        except Exception:  # noqa: BLE001
            return {"available": False}

    _host_for_bind = os.environ.get("FAXL_HOST", "127.0.0.1")
    app.register_blueprint(_console.create_console(
        aggregator=_AGGREGATOR, wal_path=_tpath, backend_name=_tel.pb.Backend.Name(
            _BACKEND_ENUM).lower(), model=MODEL,
        bind=f"{_host_for_bind}:{os.environ.get('FAXL_PORT', '8080')}",
        index_stats=_index_stats,
        verify_condition=lambda: ("mlx: byte-identical, greedy (unconditional on "
                                  "this backend)")))
    print(f"console ON -> /console + /api/* (reads {_tpath})", flush=True)
else:
    # Loud, not silent: with telemetry off there is no collection, so /console
    # and /api/* are not registered and will 404 — say so at boot.
    print("console OFF — telemetry disabled (FAXL_TELEMETRY=0); /console and "
          "/api/* are not served", flush=True)

# Normalised client label — NEVER the raw UA/X-Client (linkable PII). A small
# allowlist maps known clients to a coarse category; everything else is "other".
_CLIENT_LABELS = ("openclaw", "hermes", "curl", "wget", "python-requests",
                  "claude", "lynx", "w3m")

def _client_label(ua):
    if not ua:
        return ""
    low = ua.lower()
    for name in _CLIENT_LABELS:
        if name in low:
            return name
    return "other"

# ---- fork-point singletons (plan rev 5) ----
os.makedirs(BLOB_DIR, exist_ok=True)
os.makedirs(TOKENS_DIR, exist_ok=True)
print(f"faxl proxy ready (exact-tier lookup; ckpt base {CKPT_EVERY}, "
      f"keys >= {KEY_MIN_TOKENS} tok; exact entries: {len(index.exact)}).")


# Kimi tool-call grammar (special tokens; ids 163595-163599 in the Kimi tokenizer;
# decode round-trip verified). Call id looks like "functions.read_file:0" — the
# function name sits between "functions." and the trailing ":<idx>".
_KIMI_CALL = re.compile(
    r"<\|tool_call_begin\|>\s*(?P<id>[^<]+?)\s*<\|tool_call_argument_begin\|>"
    r"\s*(?P<args>\{.*?\})\s*<\|tool_call_end\|>", re.DOTALL)
_KIMI_SECTION = re.compile(
    r"<\|tool_calls_section_begin\|>.*?(?:<\|tool_calls_section_end\|>|\Z)", re.DOTALL)
_GRANITE_CALL = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
# Ling / bailing_hybrid family: one call per `<tool_call>` block, NOT json —
#   <tool_call>NAME\n<arg_key>k</arg_key>\n<arg_value>v</arg_value>...</tool_call>
# (values are bare strings; there may be several key/value pairs, and several
# <tool_call> blocks in one turn). Distinguished from Granite's `<tool_call>{json}`
# by the leading NAME token before any '{' — checked in parse_tool_calls order.
_LING_CALL = re.compile(r"<tool_call>\s*([^\s<{][^\n<]*?)\s*\n(.*?)</tool_call>", re.DOTALL)
_LING_ARG = re.compile(r"<arg_key>\s*(.*?)\s*</arg_key>\s*<arg_value>\s*(.*?)\s*</arg_value>", re.DOTALL)
# Nemotron family: a JSON ARRAY of {name, arguments} inside <TOOLCALL> tags
# (rendered exemplar verified from the chat template's own instructions).
_NEMOTRON_CALL = re.compile(r"<TOOLCALL>\s*(\[.*?\])\s*</TOOLCALL>", re.DOTALL)


def parse_tool_calls(text):
    """(tool_calls, content) from any known family's markup; empty if none."""
    m = _NEMOTRON_CALL.search(text)
    if m:
        calls = []
        try:
            arr = json.loads(m.group(1))
        except json.JSONDecodeError:
            arr = []
        for tc in arr if isinstance(arr, list) else []:
            args = tc.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"_raw": args}
            calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                          "function": {"name": tc.get("name", ""),
                                       "arguments": json.dumps(args)}})
        if calls:
            content = _NEMOTRON_CALL.sub("", text).strip()
            return calls, content
    calls = []
    for m in _KIMI_CALL.finditer(text):
        raw_id = m.group("id").strip()
        name = raw_id.split("functions.")[-1].rsplit(":", 1)[0] if "functions." in raw_id \
            else raw_id.rsplit(":", 1)[0]
        try:
            args = json.loads(m.group("args"))
        except json.JSONDecodeError:
            continue
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _KIMI_SECTION.sub("", text).strip()
        return calls, content
    # Ling: <tool_call>NAME <arg_key>k</arg_key><arg_value>v</arg_value>...</tool_call>.
    # Must run BEFORE Granite (both use <tool_call>) — Ling's first token is a bare
    # NAME, Granite's is '{', so a block whose body has arg_key pairs is Ling's.
    for m in _LING_CALL.finditer(text):
        name, body = m.group(1).strip(), m.group(2)
        pairs = _LING_ARG.findall(body)
        if not pairs:
            continue  # not the Ling shape (e.g. a Granite json block) — leave to Granite
        args = {k.strip(): v for k, v in pairs}
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": name, "arguments": json.dumps(args)}})
    if calls:
        content = _LING_CALL.sub("", text).strip()
        return calls, content
    for m in _GRANITE_CALL.finditer(text):
        try:
            tc = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        calls.append({"id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
                      "function": {"name": tc.get("name", ""),
                                   "arguments": json.dumps(tc.get("arguments", {}))}})
    content = re.sub(r"<tool_call>.*?</tool_call>", "", text, flags=re.DOTALL).strip()
    return calls, content


def prefill(ids, cache, start=0):
    """GRID PREFILL (losslessness fix): chunk ends sit on the ABSOLUTE token
    grid (multiples of SEG), regardless of where this segment starts.

    Hybrid (recurrent) models' chunked prefill is boundary-dependent — measured
    state max|diff| 67 vs one-pass on granite-4.0-h, with a BIT-EXACT save/load
    round-trip (docs/isolation-granite-3arm.txt). The only way cold and warm
    agree bit-for-bit is an identical boundary decomposition, so every state we
    ever persist or recompute is reached via the same absolute grid. Standard-KV
    models are exact under ANY chunking (Qwen: 0.0 across all arms) — the grid
    costs them nothing. Validated: cold==warm(grid) state diff 0.0, tokens
    identical; misaligned control diff 72.25 (scratch grid_validate.log)."""
    n = int(ids.shape[0])
    pos = 0
    while pos < n:
        nxt = min(pos + SEG - ((start + pos) % SEG), n)
        model(ids[None, pos:nxt], cache=cache)
        mx.eval([c.state for c in cache])
        pos = nxt


def generate(seed, cache, max_tokens):
    """Returns (out_ids, t_first): t_first is the wall-clock time the FIRST
    token was decoded (None if none) — TTFT is measured directly against the
    request start, never reconstructed (plan v1.5 phase 0)."""
    out = []
    t_first = None
    for i, (t, _) in enumerate(generate_step(seed, model, prompt_cache=cache, max_tokens=max_tokens, sampler=sampler)):
        if t_first is None:
            t_first = time.time()
        if int(t) in STOP_IDS:
            break
        out.append(int(t))
        if i + 1 >= max_tokens:
            break
    return out, t_first


SNIFF = os.environ.get("FAXL_SNIFF")   # path to dump full request/response traffic for inspection


def _sniff(kind, obj):
    """Append a pretty JSON record of one request or response to FAXL_SNIFF, for
    testing/inspection. Off unless FAXL_SNIFF is set. Records the FULL messages,
    tools, raw model text, and parsed tool calls — so you can see exactly what
    OpenClaw sent and what the model did with it."""
    if not SNIFF:
        return
    try:
        with open(SNIFF, "a") as f:
            f.write(json.dumps({"t": time.time(), "kind": kind, **obj}, default=str) + "\n")
            f.flush(); os.fsync(f.fileno())
    except Exception:
        pass


# FIX D6 (CODE-TRUTH): the server now runs threaded so /health, /metrics and
# /v1/models answer during a long generation; MODEL INFERENCE AND STORE WRITES
# stay strictly serialized under this lock (MLX and the Index are not
# thread-safe; per-request behavior is unchanged).
_SERVE_LOCK = threading.Lock()


@app.route("/v1/chat/completions", methods=["POST"])
def chat():
    # FIX D6: one request at a time through inference + store writes; the lock is
    # what makes threaded=True safe.
    body = request.get_json(silent=True) or {}
    # TELEMETRY START — SYNCHRONOUS + fail-closed, and BEFORE _SERVE_LOCK so a
    # stalled telemetry fsync never serialises behind queued inference. One hook
    # covers both the non-stream and SSE paths below. The txn id threads down to
    # become req_id (one id per request; AUDIT unchanged).
    txn_id = uuid.uuid4().hex[:16]
    if TELEMETRY is not None:
        try:
            _raw = request.get_data(cache=True) or b""
            TELEMETRY.emit_start(
                txn_id,
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")),  # "" = unattributed
                prompt_bytes=len(_raw), n_messages=len(body.get("messages", [])),
                client_label=_client_label(request.headers.get("User-Agent", "")))
        except _tel.TelemetryError:
            # v1 fail-closed: refuse before inference; retryable. Never a silent
            # untracked serve. (Loud failure already surfaced + in /health.)
            return jsonify({"error": {"type": "telemetry_unavailable",
                                      "message": "telemetry sink unavailable; retry",
                                      "retryable": True}}), 503
    def _serve_error(reason):
        # A request that errored after START is a FAILED request, not a vanished
        # search — close the transaction so the aggregator sees a terminal event
        # (REJECTED serve_error), never a false "incomplete".
        if TELEMETRY is not None:
            TELEMETRY.emit_rejected(
                txn_id, reject_reason=f"serve_error:{reason}"[:60],
                tenant=(licence.status().get("customer", "")
                        or os.environ.get("FAXL_TENANT", "")), _seq=99)

    if not body.get("stream"):
        with _SERVE_LOCK:
            try:
                return _chat_impl(txn_id=txn_id)
            except Exception as e:   # emit terminal event, then let Flask 500
                _serve_error(type(e).__name__)
                raise
    # SSE streaming (2026-08-19): the proxy previously IGNORED
    # stream:true and hung streaming clients — OpenClaw's embedded
    # runner idle-watchdogged every turn at 120 s (OUR bug, isolated
    # after first being misattributed to the gateway). Contract: emit
    # the role frame IMMEDIATELY, SSE keepalive comments while the
    # serve (prefill included) runs, then content/finish frames and
    # [DONE]. Generation itself is unchanged (single-shot under the
    # serve lock) — this is protocol compliance, not incremental
    # decoding; byte-identity of message content is preserved.
    from flask import copy_current_request_context
    result = {}

    @copy_current_request_context
    def _work():
        with _SERVE_LOCK:
            try:
                resp = _chat_impl(txn_id=txn_id)
                result["payload"] = resp.get_json()
                result["status"] = resp.status_code
            except Exception as e:          # surfaced in-stream below
                result["error"] = f"{type(e).__name__}: {e}"
                _serve_error(type(e).__name__)   # close txn (not a false incomplete)

    th = threading.Thread(target=_work, daemon=True)
    th.start()

    def _gen():
        rid = f"chatcmpl-{uuid.uuid4().hex[:12]}"
        first = {"id": rid, "object": "chat.completion.chunk",
                 "created": int(time.time()), "model": MODEL,
                 "choices": [{"index": 0,
                              "delta": {"role": "assistant"},
                              "finish_reason": None}]}
        yield f"data: {json.dumps(first)}\n\n"
        while th.is_alive():
            th.join(timeout=5)
            if th.is_alive():
                yield ": keepalive\n\n"
        if "payload" not in result or result["payload"] is None:
            err = result.get("error", f"status {result.get('status')}")
            yield ("data: " + json.dumps(
                {"id": rid, "object": "chat.completion.chunk",
                 "error": {"message": err}}) + "\n\n")
            yield "data: [DONE]\n\n"
            return
        p = result["payload"]
        msg = p["choices"][0]["message"]

        def _frame(delta):
            return ("data: " + json.dumps(
                {"id": p["id"], "object": "chat.completion.chunk",
                 "created": p["created"], "model": p["model"],
                 "choices": [{"index": 0, "delta": delta,
                              "finish_reason": None}]}) + "\n\n")

        if msg.get("content"):
            yield _frame({"content": msg["content"]})
        # OpenAI streaming convention, STRICT: fragment 1 = id+name with
        # EMPTY arguments; fragment 2 = the arguments string. A complete
        # tool call in one fragment double-buffers in real accumulators
        # (measured: OpenClaw stringified it → "root: must be object"
        # validation loops).
        for i, tc in enumerate(msg.get("tool_calls") or []):
            fn = tc.get("function", {})
            yield _frame({"tool_calls": [
                {"index": i, "id": tc.get("id"), "type": "function",
                 "function": {"name": fn.get("name", ""),
                              "arguments": ""}}]})
            yield _frame({"tool_calls": [
                {"index": i,
                 "function": {"arguments": fn.get("arguments", "")}}]})
        yield ("data: " + json.dumps(
            {"id": p["id"], "object": "chat.completion.chunk",
             "created": p["created"], "model": p["model"],
             "choices": [{"index": 0, "delta": {},
                          "finish_reason":
                          p["choices"][0]["finish_reason"]}],
             "usage": p.get("usage"), "faxl": p.get("faxl")}) + "\n\n")
        yield "data: [DONE]\n\n"

    return Response(_gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


def _chat_impl(txn_id=None):
    treq0 = time.time()   # request start — TTFT anchor (direct measurement)
    body = request.get_json(force=True)
    messages = body.get("messages", [])
    _sniff("request", {
        "n_messages": len(messages),
        "tools": [t.get("function", {}).get("name") for t in (body.get("tools") or [])],
        "max_tokens": body.get("max_tokens"),
        "messages": messages,   # full text — this is a debug/inspection mode
    })
    # Default raised from 256: agentic edit tool calls carry whole hunks/files as
    # JSON arguments — at 256 the call truncates mid-argument, fails to parse, and
    # the harness sees dead text (measured: every OpenClaw edit turn cut at 256).
    # Default to effectively-unlimited when the client sends no max_tokens: let the
    # model run until its own end token. Clipping only serves as a runaway backstop,
    # and a low default silently truncates reasoning models mid-<think>. A client
    # that WANTS a cap still sends one and it is honoured. Override via
    # FAXL_MAX_TOKENS_DEFAULT if a hard ceiling is ever wanted.
    max_tokens = int(body.get("max_tokens", int(os.environ.get("FAXL_MAX_TOKENS_DEFAULT", "1000000"))))
    # FORWARD TOOLS: OpenClaw (and any agent) sends OpenAI-shape `tools`. Granite's
    # chat template renders them into a <tools>…</tools> block and instructs the
    # model to reply with <tool_call>{...}</tool_call>. Without this the model is
    # told nothing about the tools and correctly declines (that was the NO_REPLY).
    tools = body.get("tools") or None
    tmpl_kw = {"add_generation_prompt": True}
    if tools:
        tmpl_kw["tools"] = tools
    # THINKING TOGGLE: reasoning models (Ling, Qwen3, ...) open a <think> block by
    # default; for terse/structured-output tasks that just burns the token budget
    # before the answer. Honour an OpenAI-compat `enable_thinking` (or `chat_template_kwargs`)
    # from the request, else the FAXL_ENABLE_THINKING env default (unset = leave the
    # template's own default). Templates without the flag ignore the kwarg harmlessly.
    _think = body.get("enable_thinking")
    if _think is None:
        _think = (body.get("chat_template_kwargs") or {}).get("enable_thinking")
    if _think is None and "FAXL_ENABLE_THINKING" in os.environ:
        _think = os.environ["FAXL_ENABLE_THINKING"].lower() in ("1", "true", "yes")
    if _think is not None:
        tmpl_kw["enable_thinking"] = bool(_think)
    # CANONICALIZE TOOL-CALL IDS before templating (measured failure, run 3 of the
    # OpenClaw commenting task): we return OpenAI-style ids ("call_xxx"); the client
    # echoes them back in history; Kimi's template renders them verbatim and the
    # model then MIMICS that id shape instead of its native "functions.NAME:IDX" —
    # its next call carries an id-shaped tool NAME the harness cannot resolve, and
    # the session loops on an unavailable tool. Rewriting history ids to the native
    # form (consistently across the assistant call and its tool-result message)
    # keeps the model's exemplar format correct. Name-linkage is preserved because
    # the id embeds the function name; Granite's template ignores ids entirely.
    idmap = {}
    canon = []
    for m in messages:
        m = dict(m)
        # Nemotron's Jinja template calls string methods on content and crashes
        # on the two non-string shapes OpenAI clients legally send: None (pure
        # tool-call turns) and multi-part lists [{"type":"text","text":...}]
        # (OpenClaw). Normalize both to plain strings; harmless for every family.
        c = m.get("content")
        if c is None:
            m["content"] = ""
        elif isinstance(c, list):
            m["content"] = "\n".join(
                p.get("text", "") if isinstance(p, dict) else str(p) for p in c)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            tcs = []
            for i, tc in enumerate(m["tool_calls"]):
                tc = json.loads(json.dumps(tc))
                new_id = f"functions.{tc.get('function', {}).get('name', 'tool')}:{i}"
                idmap[tc.get("id")] = new_id
                tc["id"] = new_id
                # arguments: OpenAI history carries a JSON STRING; Ling's Jinja
                # template calls .items() on it and crashes ("str has no attribute
                # items"). Coerce a JSON-object string to a dict — the OpenAI-internal
                # shape every family's template accepts (dict-consumers need it,
                # string-consumers re-serialize it fine).
                fn = tc.get("function", {})
                a = fn.get("arguments")
                if isinstance(a, str):
                    try:
                        parsed = json.loads(a)
                        if isinstance(parsed, dict):
                            fn["arguments"] = parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                tcs.append(tc)
            m["tool_calls"] = tcs
        if m.get("role") == "tool" and m.get("tool_call_id") in idmap:
            m["tool_call_id"] = idmap[m["tool_call_id"]]
        canon.append(m)
    try:
        ids = tok.apply_chat_template(canon, **tmpl_kw)
    except TypeError:
        # a template that doesn't accept enable_thinking (most) — drop it and retry
        tmpl_kw.pop("enable_thinking", None)
        ids = tok.apply_chat_template(canon, **tmpl_kw)

    t0 = time.time()
    cache_status = "cold"
    prefilled = len(ids)
    resume_pos = 0
    resumed_blob = None   # REPRO DEBUG: the blob actually loaded (None = cold/miss)
    prompt_hash = hashlib.sha256(str(ids).encode()).hexdigest()[:16]  # exact prompt id
    req_id = txn_id or uuid.uuid4().hex[:16]   # M0: stable request id; == telemetry txn
    aud_probes = []   # ladder walk — always collected (AUDIT + telemetry read it)

    # EXACT-TIER LOOKUP: one O(N) prefix-hash pass, then deepest-first hash lookup +
    # token confirm at each scheduled position. NO ESN probe, NO cosine on this path.
    # Skipped entirely in NOCACHE mode (the A/B control).
    confirm = None      # None = no exact hit; "pass"/"fail" = confirm outcome
    qhash = None
    hash_build_ms = 0.0
    confirm_ms = 0.0
    # Phase-0 exclusive child spans + one inclusive outer accumulator.
    # cache_blocked_ms totals every cache-path segment the serialised handler
    # spends OUTSIDE prefill/decode; residual_ms = outer − Σ children.
    cache_blocked_ms = 0.0
    probe_rpc_ms = 0.0      # identity_get RPCs (lookup probes + write dedup)
    blob_load_ms = 0.0      # load_prompt_cache on a hit (lazy mmap open)
    fork_discovery_ms = 0.0  # D* search + classify + gate evaluation
    ckpt_write_ms = 0.0     # ALL save_prompt_cache (grid + fork)
    tokfile_ms = 0.0        # token-prefix file writes
    esn_key_ms = 0.0        # probe.key (similarity key)
    upsert_ms = 0.0         # index.add (UltraDim upsert + row bookkeeping)
    evict_ms = 0.0          # supersession delete + fork LRU eviction
    # LICENCE GATE: unentitled behaves exactly like NOCACHE — the request is
    # still served, the prefill just runs cold. Degrade, never refuse.
    _entitled = licence.entitled()
    if not NOCACHE and not _entitled:
        cache_status = "unlicensed"
    elif not NOCACHE and len(ids) >= GATE_TOKENS:
        tcb0 = time.time()
        th0 = time.time()
        qhash = prefix_hashes(ids)
        hash_build_ms = (time.time() - th0) * 1000
        # Plan v1.5 phase 0: probe PERSISTED positions only — every position
        # where a blob is known to exist (grid AND fork). Schedule
        # recomputation is REMOVED from the lookup (it probed positions with
        # no stored blob; regression-tested equal hit sets in
        # test_lookup_regression.py). ckpt_positions stays write-path-only.
        probe_positions = index.known_positions()   # sorted desc
        for pos in probe_positions:
            if pos % SEG:
                # Legacy non-grid checkpoint (pre grid-fix store): resuming it
                # would reintroduce the boundary-mismatch divergence on hybrid
                # models. Skip — it can still be superseded/evicted normally.
                continue
            if pos >= len(ids) - 1:
                continue   # need >=1 tail token to seed generation
            tpr0 = time.time()
            cand = index.identity_get(qhash[pos])
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if cand is None:
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "miss"})
                continue
            blob, cpos, tokf = cand
            # CONFIRM (belt and braces): token-compare the stored prefix.
            # A fail here is a hash collision or store corruption — logged loudly and
            # NEVER resumed. FIX D3 (CODE-TRUTH): a corrupted DEEP entry must not
            # forfeit a valid SHALLOWER hit — continue down the ladder; the request
            # only runs cold if no rung confirms.
            tcf0 = time.time()
            try:
                stored_prefix = json.load(open(tokf))
            except Exception:
                confirm_ms += (time.time() - tcf0) * 1000
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_unreadable"})
                continue
            if stored_prefix != list(ids[:pos]):
                confirm_ms += (time.time() - tcf0) * 1000
                confirm = "fail"
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "confirm_fail"})
                print(f"!! EXACT-TIER CONFIRM FAIL @pos={pos} phash={qhash[pos]} "
                      f"tok={os.path.basename(tokf)} — skipping this rung, trying "
                      f"shallower", flush=True)
                continue
            confirm = "pass"
            confirm_ms += (time.time() - tcf0) * 1000
            tbl0 = time.time()
            try:
                cache = load_prompt_cache(blob)
                blob_load_ms += (time.time() - tbl0) * 1000
            except Exception as e:
                # supersession/eviction race or corrupt blob: fall to shallower
                # rungs, never 500 (plan rev 5 §safety).
                blob_load_ms += (time.time() - tbl0) * 1000
                print(f"!! BLOB LOAD FAILED @pos={pos} ({e}) — trying shallower",
                      flush=True)
                cache = None
                confirm = None
                if aud_probes is not None:
                    aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                       "outcome": "load_fail"})
                continue
            if aud_probes is not None:
                aud_probes.append({"pos": pos, "phash": str(qhash[pos]),
                                   "outcome": "confirm_pass"})
            index.touch_resume(qhash[pos])
            resume_pos = cpos
            resumed_blob = blob
            prefilled = len(ids) - cpos       # only the tail beyond the checkpoint
            cache_status = f"warm(exact,confirmed,resume@{cpos},delta={prefilled})"
            break
    if qhash is not None:
        cache_blocked_ms += (time.time() - tcb0) * 1000
    # ---- TRIM-ON-LOAD branch (KV plan B.2, TRIMMABLE models only): a
    # divergence at d below an anchor's depth P is served by loading the
    # anchor and trimming P-d tokens. Runs AFTER the exact ladder; engages
    # only when it beats the exact resume. EXEMPT from the ladder's
    # pos >= len-1 guard (a trim candidate legitimately has P >= len-1);
    # its own cap is d = min(D_raw, len-1) [F2].
    trim_rec = None
    if TRIMMABLE and not NOCACHE and qhash is not None:
        ttr0 = time.time()
        _d_raw_t = forkidx.deepest_shared(qhash, len(ids))
        d_t = min(_d_raw_t, len(ids) - 1)
        if d_t > resume_pos:
            cand = resolve_candidate(ANCHORS, forkidx.pos_hashes, qhash, d_t)
            if cand is not None:
                ent = index.identity_get(int(cand["phash"]))
                if ent is not None:
                    tblob, tP, ttokf = ent
                    tbytes = os.path.getsize(tblob)
                    gok, save_ms, load_ms = trim_economic_gate(
                        d_t, PREFILL_TPS["ewma"], tbytes,
                        LOAD_FIT["intercept_ms"], LOAD_FIT["slope_ms_per_gb"])
                    trim_rec = {"d_star": _d_raw_t, "d": d_t,
                                "owner": str(cand["owner"]),
                                "anchor_phash": cand["phash"],
                                "anchor_P": tP, "bytes": tbytes,
                                "tps": PREFILL_TPS["ewma"],
                                "save_ms": round(save_ms, 2),
                                "load_ms": round(load_ms, 2),
                                "gate_ok": gok, "outcome": None}
                    if not gok:
                        trim_rec["outcome"] = "gated_out"
                    else:
                        try:
                            stored_prefix = json.load(open(ttokf))
                        except Exception:
                            stored_prefix = None
                        if stored_prefix is None or                                 stored_prefix[:d_t] != list(ids[:d_t]):
                            trim_rec["outcome"] = "trim_confirm_fail"
                            print(f"!! TRIM CONFIRM FAIL @d={d_t} anchor@"
                                  f"{tP} — serving without trim", flush=True)
                        else:
                            try:
                                cache = load_prompt_cache(tblob)
                                # F8: trim returns the FIRST layer's count
                                # only — never asserted as a total.
                                trim_prompt_cache(cache, tP - d_t)
                                resume_pos = d_t
                                resumed_blob = tblob
                                prefilled = len(ids) - d_t
                                cache_status = (f"warm(trimmed,resume@{d_t},"
                                                f"from@{tP})")
                                trim_rec["outcome"] = "served"
                            except Exception as e:
                                trim_rec["outcome"] = "load_fail"
                                print(f"!! TRIM LOAD FAILED ({e}) — falling "
                                      f"back", flush=True)
        cache_blocked_ms += (time.time() - ttr0) * 1000
    if resume_pos == 0:
        cache = make_prompt_cache(model)
        cache_status = "nocache" if NOCACHE else "cold"
    if AUDIT:
        # #55: prefix-hash arrays for ALL traffic — computed here even for
        # NOCACHE/below-gate requests the lookup skipped (0.18 µs/token).
        _aud_qhash = qhash if qhash is not None else prefix_hashes(ids)
        AUDIT.request(req_id, prompt_len=len(ids), prompt_sha=prompt_hash,
                      prefix_hashes=_aud_qhash, workload=WORKLOAD)
        AUDIT.lookup(req_id, probes=aud_probes, resume_pos=resume_pos,
                     resume_phash=(qhash[resume_pos]
                                   if (resume_pos and qhash) else None),
                     trim=trim_rec)

    # ---- FORK DISCOVERY (plan rev 5): find the proven divergence position D*
    # and gate a checkpoint write there. Runs on EVERY request (warm or cold).
    fork_pos = fork_kind = fork_matched = None
    fork_gate = None
    fork_rec = None   # M0 audit: gate evaluation with RAW inputs (#56)
    fork_write_ms = 0.0
    index_maint_ms = 0.0
    fork_written = False
    trim_matched = None   # extension-matched stream (chain identity, B.4)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tfd0 = time.time()
        D_raw = forkidx.deepest_shared(qhash, len(ids))
        _fd_probe0 = probe_rpc_ms   # identity_gets inside discovery counted there
        D = min(D_raw, len(ids) - 2)
        # An EXACT re-arrival (the whole query is already a stored stream) has
        # no divergence point inside it — nothing to fork.
        if 0 < D and D_raw < len(ids):
            kind, matched_stream = forkidx.classify(qhash, D, len(ids))
            forkidx.observe_match(qhash[D])
            if kind == "extension":
                trim_matched = matched_stream
            marginal = D - resume_pos   # deepest existing blob on this prefix
            tpr0 = time.time()
            d_star_stored = index.identity_get(qhash[D]) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            # B.3 [F7]: under TRIMMABLE the anchor dominates every fork
            # write — D* is still computed (the trim path needs it), fork
            # BLOB WRITES and their gates are suppressed entirely.
            if FORK and not TRIMMABLE and marginal > 0 and not d_star_stored:
                pb = blob_bytes_predicted(MODEL, D, OBSERVED["max_blob"])
                if FORK_GATES_OFF:
                    fork_ok, fork_gate = True, "gates-off(demo)"
                    fork_rec = {"kind": kind, "d_star": D,
                                "family": "gates_off", "ok": True}
                elif kind == "extension":
                    ch = forkidx.chain_for(matched_stream)
                    ewma_inc = ch["ewma_inc"] if ch else max(len(ids) - D, 1)
                    repaid_tail = len(ids) - resume_pos
                    fork_ok, saved_ms, wr_ms = extension_gate(
                        repaid_tail, ewma_inc, PREFILL_TPS["ewma"], pb,
                        NVME_BPS, FORK_TIME_RATIO)
                    fork_gate = (f"ext saved~{saved_ms:.0f}ms write~{wr_ms:.0f}ms "
                                 f"inc~{ewma_inc:.0f}")
                    fork_rec = {"kind": kind, "d_star": D, "family": "ext",
                                "pb": pb, "inc": ewma_inc,
                                "tps": PREFILL_TPS["ewma"],
                                "repaid": repaid_tail,
                                "kappa": forkidx.kappa,
                                "time_ratio": FORK_TIME_RATIO, "ok": fork_ok}
                    # head must track the conversation EVERY turn, forking or
                    # not, or supersession loses its ancestor (measured: 14.9 GB
                    # of un-superseded fork blobs before this line existed).
                    forkidx.migrate_chain(matched_stream, qhash[len(ids)],
                                          len(ids) - D)
                else:
                    fork_ok, exp_extra, budget = divergence_gate(
                        pb, forkidx.kappa, marginal, model_slope(MODEL), FORK_AMORT)
                    fork_gate = (f"div k={forkidx.kappa:.2f} pred={pb/1e6:.0f}MB "
                                 f"budget={budget/1e6:.0f}MB")
                    fork_rec = {"kind": kind, "d_star": D, "family": "div",
                                "pb": pb, "kappa": forkidx.kappa,
                                "marginal": marginal,
                                "tps": PREFILL_TPS["ewma"],
                                "slope": model_slope(MODEL),
                                "amort": FORK_AMORT, "ok": fork_ok}
                if fork_ok:
                    # GRID SNAP: fork blobs obey the same rule as scheduled
                    # checkpoints — persist only at grid positions (raw D stays
                    # in fork_rec for the audit trail).
                    _D_grid = (D // SEG) * SEG
                    if _D_grid > 0:
                        fork_pos, fork_kind, fork_matched = _D_grid, kind, matched_stream
        _fd_block = (time.time() - tfd0) * 1000
        # discovery span excludes the identity_get RPC counted in probe_rpc_ms
        fork_discovery_ms += _fd_block - (probe_rpc_ms - _fd_probe0)
        cache_blocked_ms += _fd_block

    # Prefill ONLY the tail beyond the resume point, checkpointing at the
    # placements the selected STRATEGY returns (see store_lifecycle
    # STRATEGIES; FAXL_STRATEGY=grid restores the legacy geometric
    # schedule byte-identically). ScheduleContext is constructed AFTER hash
    # + lookup + fork discovery — everything in it is pre-arrival.
    _dstar = (D_raw if ((FORK or TRIMMABLE) and not NOCACHE
                        and qhash is not None) else 0)
    ctx = ScheduleContext(
        prompt_len=len(ids), resume_pos=resume_pos,
        d_star=_dstar,
        fork_kind=fork_kind,
        kappa=(forkidx.kappa if (FORK or TRIMMABLE) else 0.5),
        chain_ewma_inc=None,
        live_bytes=int(index.live_fork_gb() * 1e9) if FORK else 0,
        observed_max=OBSERVED["max_blob"],
        arrivals_at_dstar=0, model=MODEL,
        d_star_hash=(qhash[_dstar] if (_dstar and qhash) else None))
    # GRID SNAP (losslessness fix): states are only ever persisted at absolute
    # multiples of SEG, so a later resume re-enters the same canonical boundary
    # decomposition the cold path uses. Costs at most SEG-1 tokens of skip.
    placements = {(p.pos // SEG) * SEG for p in POLICY.decide(ctx)} - {0}
    if AUDIT:
        _cnt = _STRAT_KW.get("count_of")
        AUDIT.decision(req_id, ctx=asdict(ctx),
                       strategy={"name": STRATEGY, "config": STRAT_CFG},
                       placements=sorted(placements),
                       anchor_count=(_cnt(ctx) if callable(_cnt) else None),
                       fork=fork_rec)
        if fork_rec is not None and not fork_rec["ok"]:
            # register #56: REJECTED write decision with raw signals;
            # predicted_ev stays NULL until M3b's ev_model_version exists.
            AUDIT.lifecycle(req_id, "rejected_write",
                            phash=qhash[fork_rec["d_star"]],
                            pos=fork_rec["d_star"], signals=fork_rec)
    n = len(ids) - 1
    bounds = sorted(placements)
    if fork_pos is not None and fork_pos > resume_pos:
        # rev-3 fix: the fork write is exempt from the schedule; D* is inserted
        # into the prefill bounds so the state materializes exactly there.
        bounds = sorted(set(bounds) | {fork_pos})
    if not bounds or bounds[-1] != n:
        bounds.append(n)   # always prefill through to the end
    pos = resume_pos
    stored, deduped = 0, 0
    tpf0 = time.time()
    for end in bounds:
        if end <= pos:
            continue
        prefill(mx.array(ids[pos:end]), cache, pos)
        pos = end
        # NOCACHE: still prefill (the model needs it) but write NO checkpoints.
        # Only checkpoint at a SCHEDULED position (not the ragged final end).
        is_fork_here = (fork_pos is not None and pos == fork_pos)
        if (not NOCACHE and (is_fork_here or pos in placements)
                and _STORE_BYTES[0] > STORE_CAP_GB * 1e9):
            print(f"!! STORE CAP {STORE_CAP_GB} GB reached "
                  f"({_STORE_BYTES[0]/1e9:.1f} GB) — checkpoint write "
                  f"SKIPPED at pos {pos}", flush=True)
            continue
        # Unlicensed also stops WRITING: growing a store for a cache that can
        # never serve from it costs the customer disk for nothing.
        if not NOCACHE and _entitled and (is_fork_here or pos in placements):
            tck0 = time.time()
            ph = qhash[pos] if qhash else prefix_hashes(ids[:pos])[pos]
            # DEDUP, exact: if this precise prefix is already stored, skip the
            # write. Correct by construction (identity, not cosine similarity —
            # the old cosine dedup could merge different prefixes). The invariant
            # agent preamble is thus stored ONCE, ever, across all sessions.
            # FIX D4 (CODE-TRUTH): consult the SAME store the lookup uses (shared DB
            # first, local fallback) — dedup vs the local dict alone re-wrote blobs
            # that the shared DB already holds.
            tpr0 = time.time()
            dedup_hit = index.identity_get(ph) is not None
            probe_rpc_ms += (time.time() - tpr0) * 1000
            if dedup_hit:
                deduped += 1
                if TRIMMABLE and placements and pos == max(placements):
                    # exact repeat: the anchor already exists — keep the
                    # chain registry pointed at it (same phash => no
                    # supersession; record_anchor returns None).
                    _cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                  trim_matched)
                    ANCHORS.record_anchor(_cid, ph, pos, qhash[len(ids)])
                if AUDIT:
                    AUDIT.lifecycle(req_id, "deduped", phash=ph, pos=pos,
                                    ckpt_kind=("extension-fork" if (is_fork_here and fork_kind == "extension")
                                               else "divergence-fork" if is_fork_here
                                               else "grid"))
                cache_blocked_ms += (time.time() - tck0) * 1000
                continue
            # TOKEN PREFIX: content-addressed, write-once (same hash = same file).
            ttk0 = time.time()
            tokf = os.path.join(TOKENS_DIR, f"{ph}.json")
            if not os.path.exists(tokf):
                tmpf = tokf + f".tmp{uuid.uuid4().hex[:8]}"
                with open(tmpf, "w") as tf:
                    json.dump(list(ids[:pos]), tf)
                os.replace(tmpf, tokf)
            tokfile_ms += (time.time() - ttk0) * 1000
            # SIMILARITY KEY: only at >= KEY_MIN_TOKENS (c4 alive; 4-band key
            # complete). Below that the entry is exact-tier-only — the lookup
            # doesn't need a key, and a 3-band key is measured-bad as an embedding.
            ki = kv = None
            # Fork blobs are EXACT-TIER-ONLY (rev 4): the key would be dead
            # weight (~seconds at depth) — skip regardless of KEY_MIN_TOKENS.
            if pos >= KEY_MIN_TOKENS and not is_fork_here:
                tek0 = time.time()
                ki, kv = probe.key(ids[:pos])
                esn_key_ms += (time.time() - tek0) * 1000
            # BLOB NAME: uuid, NOT index.rows — on restart _reload() skips rows whose
            # blob is gone so `rows` shrinks, and a "{rows}.safetensors" name would
            # then collide with a filename a still-live meta row points at (overwrite
            # + two rows aiming at one file). uuid is collision-free across restarts.
            blob = os.path.join(BLOB_DIR, f"ckpt_{uuid.uuid4().hex}.safetensors")
            tw0 = time.time()
            save_prompt_cache(blob, cache)
            wrote_ms = (time.time() - tw0) * 1000
            ckpt_write_ms += wrote_ms   # grid writes measured AND KEPT (phase 0)
            tup0 = time.time()
            index.add(ki, kv, blob, pos, phash=ph, tok=tokf, fork=is_fork_here)
            upsert_ms += (time.time() - tup0) * 1000
            blob_bytes = None
            try:
                blob_bytes = os.path.getsize(blob)
                _STORE_BYTES[0] += blob_bytes
                OBSERVED["max_blob"] = max(OBSERVED["max_blob"], blob_bytes)
            except OSError as e:
                # M0 loud-failure sweep: a blob we JUST wrote but cannot stat
                # is store corruption, not noise.
                LOG_FAILURES.append(f"stat fresh blob {os.path.basename(blob)}: {e}")
                print(f"!! FRESH BLOB UNSTATTABLE ({blob}: {e}) — store "
                      f"corruption suspected", flush=True)
            stored += 1
            _kind = ("extension-fork" if (is_fork_here and fork_kind == "extension")
                     else "divergence-fork" if is_fork_here else "grid")
            # B.4: under TRIMMABLE the DEEPEST placement of this request is
            # the chain's live tail ANCHOR — registered per chain, and the
            # chain's previous anchor is superseded (write new -> re-point
            # index -> delete old; ordering per the shipped supersession
            # rule). Shallower placements (with_grid) stay 'grid'.
            _anchor_cid = None
            if TRIMMABLE and placements and pos == max(placements):
                _kind = "anchor"
                _anchor_cid = ANCHORS.observe_stream(qhash[len(ids)],
                                                     trim_matched)
            if AUDIT:
                # per-band summary of the key ALREADY computed above —
                # c1..c4 features for the online learner, zero extra
                # model/reservoir work (None when this write is unkeyed)
                _esn = None
                if ki is not None:
                    _esn = {}
                    for _c in range(4):
                        _pairs = [(i - _c * WIDTH, v)
                                  for i, v in zip(ki, kv)
                                  if _c * WIDTH <= i < (_c + 1) * WIDTH]
                        _pairs.sort(key=lambda t: -abs(t[1]))
                        _esn[f"c{_c+1}"] = {
                            "nnz": len(_pairs),
                            "norm": round(sum(v * v
                                              for _, v in _pairs) ** 0.5,
                                          6),
                            "top": [[i, round(v, 5)]
                                    for i, v in _pairs[:8]]}
                AUDIT.lifecycle(req_id, "stored", phash=ph, pos=pos,
                                ckpt_kind=_kind,
                                blob_id=os.path.basename(blob),
                                nbytes=blob_bytes, chain_id=_anchor_cid,
                                esn=_esn)
            if _anchor_cid is not None:
                tev0 = time.time()
                _old_anchor = ANCHORS.record_anchor(_anchor_cid, ph, pos,
                                                    qhash[len(ids)])
                if _old_anchor is not None:
                    index.remove_blob(int(_old_anchor))
                    if AUDIT:
                        AUDIT.lifecycle(req_id, "superseded",
                                        phash=_old_anchor, by_phash=ph,
                                        chain_id=_anchor_cid)
                evict_ms += (time.time() - tev0) * 1000
            if is_fork_here:
                fork_written = True
                fork_write_ms += wrote_ms
                tev0 = time.time()
                if fork_kind == "extension":
                    # SUPERSESSION: this chain's ancestor FORK blob dies (index
                    # row first; grid blobs never touched). The head was migrated
                    # to this stream during discovery.
                    prev_phash = forkidx.set_chain_fork(qhash[len(ids)], ph, fork_pos)
                    if prev_phash and prev_phash != ph:
                        index.remove_blob(prev_phash)
                        if AUDIT:
                            AUDIT.lifecycle(req_id, "superseded",
                                            phash=prev_phash, by_phash=ph)
                else:
                    ev = index.evict_forks_over_cap(FORK_MAX_LIVE_GB)
                    if ev:
                        print(f"fork LRU: evicted {len(ev)} blob(s) over "
                              f"{FORK_MAX_LIVE_GB} GB cap", flush=True)
                        if AUDIT:
                            for _v in ev:
                                AUDIT.lifecycle(req_id, "evicted", phash=_v)
                evict_ms += (time.time() - tev0) * 1000
            cache_blocked_ms += (time.time() - tck0) * 1000
    pf_secs = time.time() - tpf0
    pf_tokens = pos - resume_pos
    if pf_tokens > 512 and pf_secs > 0.5:   # update only on meaningful prefills
        PREFILL_TPS["ewma"] = 0.7 * PREFILL_TPS["ewma"] + 0.3 * (pf_tokens / pf_secs)
    if (FORK or TRIMMABLE) and not NOCACHE and qhash is not None:
        tas0 = time.time()
        index_maint_ms += forkidx.add_stream(ids, qhash)
        cache_blocked_ms += (time.time() - tas0) * 1000
    if stored or deduped:
        cache_status += f" [ckpt +{stored}/dedup {deduped}]"
    if fork_pos is not None:
        cache_status += f" [fork {fork_kind}@{fork_pos}{'+w' if fork_written else ''}]"
    prefill_skipped = resume_pos       # tokens we did NOT re-prefill thanks to resume
    seed = mx.array(ids[-1:])

    out_ids, t_first_tok = generate(seed, cache, max_tokens)
    text = tok.decode(out_ids)
    dt = time.time() - t0
    ttft_ms = (t_first_tok - treq0) * 1000 if t_first_tok else None

    # PARSE TOOL CALLS — family dispatch (the last Granite-coupled seam, now dual):
    #  Granite: <tool_call>{"name":..,"arguments":{..}}</tool_call> (text tags).
    #  Kimi:    <|tool_calls_section_begin|> <|tool_call_begin|> functions.NAME:IDX
    #           <|tool_call_argument_begin|> {json} <|tool_call_end|> ... — special
    #           tokens, VERIFIED to survive tok.decode round-trip, so text-level
    #           parsing is sound. Lift into OpenAI `tool_calls`; content is what
    #           remains outside the call markup.
    tool_calls, content = parse_tool_calls(text)
    _sniff("response", {
        "raw_model_text": text,          # exactly what the model emitted (incl. any <think>)
        "parsed_tool_calls": tool_calls, # what the parser lifted into OpenAI form
        "content": content,
        "cache_status": cache_status,
    })
    msg = {"role": "assistant", "content": content or None}
    finish = "stop"
    if tool_calls:
        msg["tool_calls"] = tool_calls
        finish = "tool_calls"

    # ---- ROI instrumentation (durable JSONL, one line per request) ----
    hit = resume_pos > 0
    TOTALS["requests"] += 1
    TOTALS["prompt_tokens"] += len(ids)
    TOTALS["prefill_paid"] += prefilled          # tokens actually prefilled this req
    TOTALS["prefill_skipped"] += prefill_skipped  # tokens skipped via resume
    TOTALS["hits"] += 1 if hit else 0
    TOTALS["ckpts_written"] += stored
    TOTALS["ckpts_deduped"] += deduped
    TOTALS["wall_s"] += dt
    tot_prompt = TOTALS["prompt_tokens"] or 1
    rec = {
        "ts": t0, "mode": "nocache" if NOCACHE else "cache",
        # ns identity on EVERY metrics row (KV plan rev 4.1, day one)
        "ns_digest": NS.digest_hex(), "ns_hash": NS.ns_hash(),
        "trimmable": TRIMMABLE,
        "prompt_tokens": len(ids), "out_tokens": len(out_ids),
        "prefill_paid": prefilled, "prefill_skipped": prefill_skipped,
        "hit": hit, "resume_pos": resume_pos,
        # EXACT TIER: hit tier + per-hit confirm outcome + the O(N) hash cost.
        "hit_tier": (("trim" if (trim_rec and trim_rec.get("outcome") == "served")
                      else "exact") if hit else None), "confirm": confirm,
        # KV plan B.2 metrics: trim outcome + costs (gated-out candidates
        # logged with predicted costs, [F5])
        "trim_gate": (trim_rec or {}).get("outcome"),
        "trim_from": ((trim_rec or {}).get("anchor_P")
                      if (trim_rec or {}).get("outcome") == "served" else None),
        "trim_tokens": ((trim_rec["anchor_P"] - trim_rec["d"])
                        if (trim_rec and trim_rec.get("outcome") == "served")
                        else None),
        "hash_build_ms": round(hash_build_ms, 2),
        # REPRO DEBUG: exact prompt id + which blob was loaded, to tell apart
        # "different tail" from "different blob at same cpos" from "true non-determinism".
        "prompt_hash": prompt_hash,
        "resumed_blob": os.path.basename(resumed_blob) if resumed_blob else None,
        "ckpts_written": stored, "ckpts_deduped": deduped,
        "confirm_ms": round(confirm_ms, 2),
        # Phase-0 cache-path spans: cache_blocked_ms is the INCLUSIVE outer
        # accumulator (all cache work in the serialised handler, never
        # prefill/decode); the children below are EXCLUSIVE; residual_ms is
        # the unexplained remainder. index_maint_ms is now add_stream only
        # (D* discovery moved to fork_discovery_ms). ttft_ms is measured
        # directly: request start -> first decoded token.
        "cache_blocked_ms": round(cache_blocked_ms, 2),
        # the extension gate's own EWMA state, recorded so future traces
        # calibrate the simulator exactly (no reconstruction needed)
        "prefill_tps_ewma": round(PREFILL_TPS["ewma"], 1),
        "probe_rpc_ms": round(probe_rpc_ms, 2),
        "blob_load_ms": round(blob_load_ms, 2),
        "fork_discovery_ms": round(fork_discovery_ms, 2),
        "ckpt_write_ms": round(ckpt_write_ms, 1),
        "tokfile_ms": round(tokfile_ms, 2),
        "esn_key_ms": round(esn_key_ms, 2),
        "upsert_ms": round(upsert_ms, 2),
        "evict_ms": round(evict_ms, 2),
        "residual_ms": round(cache_blocked_ms - (
            hash_build_ms + probe_rpc_ms + confirm_ms + blob_load_ms +
            fork_discovery_ms + ckpt_write_ms + tokfile_ms + esn_key_ms +
            upsert_ms + evict_ms + index_maint_ms), 2),
        "ttft_ms": round(ttft_ms, 1) if ttft_ms is not None else None,
        "fork_pos": fork_pos, "fork_kind": fork_kind,
        "fork_gate": fork_gate, "fork_ckpt_written": fork_written,
        "fork_write_ms": round(fork_write_ms, 1),
        "index_maint_ms": round(index_maint_ms, 2),
        "live_fork_gb": round(index.live_fork_gb(), 3),
        "tool_calls": len(tool_calls), "n_tools_offered": len(tools) if tools else 0,
        "wall_s": round(dt, 3), "cache_status": cache_status,
        # running ROI: fraction of ALL prefill tokens we've skipped so far
        "cum_prefill_skipped": TOTALS["prefill_skipped"],
        "cum_prefill_paid": TOTALS["prefill_paid"],
        "cum_skip_frac": round(TOTALS["prefill_skipped"] / (TOTALS["prefill_skipped"] + TOTALS["prefill_paid"] or 1), 4),
        "cum_wall_s": round(TOTALS["wall_s"], 1), "lib_size": index.rows,
    }
    try:
        with open(METRICS, "a") as mf:
            mf.write(json.dumps(rec) + "\n")
    except OSError as e:
        # M0 (ER4/F11): NEVER silent — an apparently-valid incomplete log is
        # the worst outcome. Surfaced in /health; fails collection loudly.
        LOG_FAILURES.append(f"metrics write: {e}")
        print(f"!! METRICS WRITE FAILED ({METRICS}: {e}) — ROI log "
              f"INCOMPLETE{'; COLLECTION INVALID' if COLLECT else ''}",
              flush=True)
    if AUDIT:
        AUDIT.outcome(req_id, hit=hit, resume_pos=resume_pos,
                      prompt_len=len(ids), paid=prefilled, stored=stored,
                      deduped=deduped, fork_written=fork_written,
                      confirm=confirm, wall_s=rec["wall_s"],
                      ttft_ms=rec["ttft_ms"],
                      cache_blocked_ms=rec["cache_blocked_ms"])

    # TELEMETRY COMPLETION — async, off the hot path; mirrors AUDIT.outcome. Only
    # HONESTLY MEASURED spans are set (proto3 can't tell 0 from unset, so an unset
    # span means "not measured", never a plausible zero). saved = cold − warm is
    # left to the aggregator with its basis; here cold is ESTIMATED from the
    # measured prefill EWMA (a global rate — NOT a paired twin).
    if TELEMETRY is not None:
        _pb = _tel.pb
        _tenant = licence.status().get("customer", "") or os.environ.get(
            "FAXL_TENANT", "")   # "" = unattributed; never a fabricated default
        # cold counterfactual: what a cold prefill of the skipped tokens would
        # have cost, at the measured prefill rate. ESTIMATED (rate, not twin).
        # On a MISS prefill_skipped==0, so cold-est==0 and saved==0 by
        # construction — the aggregator needs no miss special-case.
        _cold_ms = (prefill_skipped / max(PREFILL_TPS["ewma"], 1e-6)) * 1000.0
        _cost = _pb.Cost(
            prompt_tokens=len(ids), prefill_paid=prefilled,
            prefill_skipped=prefill_skipped, warm_wall_ms=dt * 1000.0,
            cold_basis=_pb.ESTIMATED, cold_prefill_ms_est=_cold_ms,
            estimator_id="prefill_tps_ewma",
            estimator_version=str(round(PREFILL_TPS["ewma"], 1)))
        if ttft_ms is not None:      # mlx: present; some backends omit → unset
            _cost.has_ttft = True
            _cost.ttft_ms = ttft_ms
        _tim = _pb.Timings(
            hash_build_ms=hash_build_ms, confirm_ms=confirm_ms,
            blob_load_ms=blob_load_ms, prefill_ms=pf_secs * 1000.0,
            decode_ms=max(dt * 1000.0 - pf_secs * 1000.0, 0.0),
            cache_blocked_ms=cache_blocked_ms)
        _tier = (_pb.EXACT if hit and rec["hit_tier"] == "exact"
                 else _pb.TRIM if hit and rec["hit_tier"] == "trim"
                 else _pb.HIT_TIER_UNSPECIFIED)
        # Real ladder WALK (not a one-rung reconstruction): the probes actually
        # tried, deepest-first, each with its confirm outcome — powers the
        # request-detail explainability view (§5.3). phash carried as a
        # tenant-keyed hash (never raw).
        _confirm_map = {"confirm_pass": _pb.CONFIRM_PASS,
                        "confirm_fail": _pb.CONFIRM_FAIL}
        _ladder = []
        for _p in aud_probes:
            _lp = _pb.LadderProbe(
                position=_p["pos"],
                confirm=_confirm_map.get(_p["outcome"],
                                         _pb.CONFIRM_OUTCOME_UNSPECIFIED))
            _lp.rung_key.CopyFrom(TELEMETRY.keyer.keyed_hash(
                _tenant, _p["phash"].encode()))
            _ladder.append(_lp)
        TELEMETRY.emit_completion(
            req_id, tenant=_tenant,
            outcome=(_pb.HIT if hit else _pb.MISS), resume_pos=resume_pos,
            hit_tier=_tier, ladder=_ladder, cost=_cost, out_tokens=len(out_ids),
            timings=_tim, prompt_content=prompt_hash.encode())

    print(f"[{cache_status}] {len(ids)} tok | paid {prefilled} skip {prefill_skipped} "
          f"| {len(tool_calls)} tool_call(s) | {dt:.2f}s | lib={index.rows} "
          f"| cum_skip={rec['cum_skip_frac']*100:.0f}%", flush=True)
    return jsonify({
        "id": f"chatcmpl-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "created": int(t0),
        "model": MODEL,
        "choices": [{"index": 0, "message": msg, "finish_reason": finish}],
        "usage": {"prompt_tokens": len(ids), "completion_tokens": len(out_ids),
                  "total_tokens": len(ids) + len(out_ids)},
        "faxl": {"cache": cache_status, "prefilled_tokens": prefilled,
                 "library_size": index.rows, "latency_s": dt},
    })


@app.route("/v1/models", methods=["GET"])
def models():
    return jsonify({"object": "list", "data": [{"id": MODEL, "object": "model", "owned_by": "faxl"}]})


@app.route("/health", methods=["GET"])
def health():
    # M0: logging/audit failures surface here (never silent). In collection
    # mode they FAIL health (503) — a corpus with holes must not look green.
    problems = list(LOG_FAILURES)
    if AUDIT and AUDIT.failed:
        problems.append(AUDIT.failed)
    _tel_health = TELEMETRY.health() if TELEMETRY is not None else None
    if _tel_health:
        problems.extend(_tel_health["failures"])
    body = {"status": "ok" if not problems else "logging-failure",
            "model": MODEL, "library_size": index.rows, "nocache": NOCACHE,
            "collect": COLLECT, "log_failures": problems[:5],
            "n_log_failures": len(problems), "licence": licence.status(),
            "telemetry": _tel_health}
    return jsonify(body), (503 if (problems and COLLECT) else 200)


@app.route("/metrics", methods=["GET"])
def metrics():
    t = dict(TOTALS)
    denom = (t["prefill_skipped"] + t["prefill_paid"]) or 1
    t["skip_frac"] = round(t["prefill_skipped"] / denom, 4)
    t["hit_rate"] = round(t["hits"] / (t["requests"] or 1), 4)
    t["mode"] = "nocache" if NOCACHE else "cache"
    return jsonify(t)


def main():
    port = int(os.environ.get("FAXL_PORT", "8080"))
    # Loopback by default: the console (and its unauthenticated loopback GETs)
    # assume the proxy is not reachable off-box. Binding elsewhere is an explicit
    # opt-in and prints a loud warning (the console also shows a persistent
    # banner + requires auth on reads when non-loopback — server topology).
    host = os.environ.get("FAXL_HOST", "127.0.0.1")
    if host not in ("127.0.0.1", "localhost", "::1"):
        print(f"!! FAXL_HOST={host} is NOT loopback — the proxy and its /console "
              f"are reachable off-box; ensure auth is configured (the console's "
              f"loopback-GET-no-auth assumption does NOT hold here)", flush=True)
    print(f"faxl proxy on http://{host}:{port}/v1  (model {MODEL})")
    app.run(host=host, port=port, threaded=True)  # FIX D6 (lock serializes inference)


if __name__ == "__main__":
    main()

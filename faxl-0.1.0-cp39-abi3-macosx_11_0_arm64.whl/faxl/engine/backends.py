#!/usr/bin/env python3
"""backends.py — where faxl executes prefill and decode.

faxl owns the request: the chat template, the ladder lookup, the byte-for-byte
confirm, checkpoint placement, the store, telemetry, the console and the
licence gate all sit on the proxy's path and are backend-independent. A
backend is only the part that runs the model.

    make_cache()                  -> a fresh prompt cache for this model
    prefill(ids, cache, start)    -> fold tokens into that cache
    generate(seed, cache, n)      -> (token_ids, t_first)
    trimmable                     -> bool, pure-KV family (trim-on-load)
    stop_ids / tokenizer          -> what the proxy needs to decode

Two backends today:

  LocalMlxBackend   one machine, mlx_lm in this process. The shipped path.
  ExoBackend        an exo cluster over the network: many Macs joined by
                    Thunderbolt, addressed as one engine. This is what makes
                    models too large for one machine reachable (Kimi K3 at
                    ~700 GB), and exo's own prefix cache is switched off so
                    faxl owns reuse.

THE GRID IS NOT A BACKEND DETAIL. Every backend must chunk prefill on
absolute multiples of SEG. Hybrid linear-attention models (Granite's mamba
layers, Kimi's KDA layers) are boundary-dependent: folding the same tokens in
a different decomposition yields a different recurrent state and a different
answer, deterministically, so it reads as a plausible reply rather than an
error. Measured on granite-4.0-h: state max|diff| 67 vs one-pass, WITH a
bit-exact save/load round trip. Pure-KV models are exact under any chunking,
so the grid costs them nothing. A backend that cannot honour it cannot serve
a faxl checkpoint.
"""
import os
import time


class BackendError(RuntimeError):
    """The backend cannot serve. Raised at construction, never mid-request —
    a backend that silently stops executing is worse than one that refuses."""


class Backend:
    """What the proxy needs from an execution engine."""

    name = "backend"
    trimmable = False
    # CAN THIS BACKEND SEE? Default no, because the failure of guessing wrong
    # is silent: a text model handed an image reads a placeholder and invents
    # an answer. The proxy refuses images unless a backend says it can read
    # them, so a new backend is safe until it opts in.
    accepts_images = False

    def make_cache(self):
        raise NotImplementedError

    def prefill(self, ids, cache, start=0):
        raise NotImplementedError

    def generate(self, seed, cache, max_tokens):
        raise NotImplementedError

    def close(self):
        pass


class LocalMlxBackend(Backend):
    """mlx_lm in this process: one Mac, the shipped single-machine path.

    The model, tokenizer, sampler and stop ids are passed in rather than
    loaded here, so the proxy keeps its existing boot sequence (warm-up,
    capability probe, licence) exactly as it is.
    """

    name = "mlx"

    def __init__(self, model, tokenizer, sampler, stop_ids, seg,
                 trimmable=False, processor=None):
        self.model = model
        self.tokenizer = tokenizer
        self.sampler = sampler
        self.stop_ids = set(stop_ids)
        self.seg = int(seg)
        self.trimmable = bool(trimmable)
        # A processor means mlx_vlm loaded this model and the vision tower is
        # bound. It is the ONLY thing that distinguishes a model that can read
        # a photograph from one that will invent its contents.
        self.processor = processor
        self.accepts_images = processor is not None

    @staticmethod
    def _logits_only(lm):
        """Wrap a vision model's language half so it returns LOGITS.

        mlx_lm's generate_step and the warm-up both do `model(x)[...]` -- they
        expect an array. A VLM's language model returns a LanguageModelOutput
        (logits, hidden_states, cross_attention_states, encoder_outputs), which
        is not subscriptable, so BOTH failed.

        The warm-up failure was the expensive one. It exists to bind the GPU
        stream on the main thread, and when it fails EVERY request dies with
        "no Stream(gpu, N) in current thread" -- text requests included, on a
        model that otherwise works. The proxy's own warning predicted exactly
        that and was ignored because the model still loaded.

        A wrapper rather than a change at each call site: nn.Module.__call__
        is used in several places and any one of them missed is a silent
        wrong-shape bug much later.
        """
        # A PLAIN object, deliberately not an nn.Module subclass. Subclassing
        # it and delegating in __getattr__ recurses forever: nn.Module's own
        # __getattr__ looks up "inner" before object.__setattr__ has set it,
        # which calls __getattr__ again -- RecursionError at the warm-up.
        # This wrapper holds no parameters, so it has no business being a
        # Module; it only has to be callable and forward attribute lookups.
        class _LogitsOnly:
            __slots__ = ("_inner",)

            def __init__(self, inner):
                object.__setattr__(self, "_inner", inner)

            def __call__(self, *a, **kw):
                out = self._inner(*a, **kw)
                return getattr(out, "logits", out)

            def __getattr__(self, name):
                # layers, head_dim, make_cache... whatever mlx_lm reaches for.
                return getattr(object.__getattribute__(self, "_inner"), name)

        return _LogitsOnly(lm)

    def _lm(self):
        """The LANGUAGE half of the model.

        A vision model is a wrapper: model.language_model holds the decoder
        whose KV cache faxl checkpoints, and model.encode_image runs the tower.
        Everything the ladder does -- make_prompt_cache, chunked prefill,
        save and load -- addresses the language half, and it is an ordinary
        stack of KVCache layers there (36 on Qwen3-VL-4B, round-tripped through
        faxl's own save_prompt_cache/load_prompt_cache with the offset intact).
        """
        lm = getattr(self.model, "language_model", None)
        if lm is None:
            return self.model
        if getattr(self, "_lm_wrapped", None) is None:
            self._lm_wrapped = self._logits_only(lm)
        return self._lm_wrapped

    def make_cache(self):
        from mlx_lm.models.cache import make_prompt_cache
        return make_prompt_cache(self._lm())

    def prefill(self, ids, cache, start=0):
        """Chunk ends sit on the ABSOLUTE token grid (multiples of SEG),
        regardless of where this segment starts — see the module docstring."""
        import mlx.core as mx
        lm = self._lm()
        # A FRESH CACHE MUST NOT INHERIT THE LAST PROMPT'S M-RoPE GEOMETRY.
        #
        # THIS IS THE ONE THAT MADE EVERY CAPTION "None.", and it is a TEXT
        # path bug, which is why looking at the vision code never found it.
        #
        # mlx_vlm caches _position_ids on the LANGUAGE MODEL, not per request,
        # and at cache_offset == 0 language.py:538 REUSES it rather than
        # recomputing: `position_ids = self._position_ids[:, :, 0:L]`. It only
        # computes fresh ones when the field is None.
        #
        # The proxy's own warm-up is what poisons it. _warmup (faxl_proxy.py:
        # 1368) runs a deliberate ONE-TOKEN forward pass to bind the GPU
        # stream on the main thread -- required, and it must stay -- and that
        # leaves _position_ids with shape (3, 1, 1). The first real request
        # then slices a length-1 array for its 256-token chunk, so the whole
        # preamble is numbered from a single stale position. The picture is
        # spliced against geometry that describes one token, the model reads a
        # turn it cannot place, and the reply is "None." -- with a 98.8% cache
        # hit and the vision tower having run correctly.
        #
        # Worse, it is DURABLE: the checkpoint written from that first request
        # is saved with the corrupt state folded in, so every later HIT
        # inherits it and a clean process still answers "None." until the
        # store is cleared.
        #
        # Measured at boot on Qwen3-VL-4B, same photograph, same prompt:
        #   posids (3,1,1) left by the warm-up  -> 'None.'
        #   cleared before the preamble          -> 'TEXT: NONE / SCENE: A man
        #      with a beard and glasses poses for a selfie ... balloons'
        #
        # Keyed on the CACHE being empty, not on "after the warm-up": any
        # earlier short request leaves the same trap, and a resumed cache
        # (offset > 0) legitimately keeps the geometry it was built with.
        _lang = getattr(self.model, "language_model", None)
        if _lang is not None and cache:
            try:
                _o = cache[0].offset
                _o = int(_o if isinstance(_o, int) else
                         (_o if _o.ndim == 0 else _o[0]).item())
            except (AttributeError, IndexError, TypeError):
                _o = None
            if _o == 0:
                _lang._position_ids = None
                _lang._rope_deltas = None
        n = int(ids.shape[0])
        pos = 0
        while pos < n:
            nxt = min(pos + self.seg - ((start + pos) % self.seg), n)
            lm(ids[None, pos:nxt], cache=cache)
            mx.eval([c.state for c in cache])
            pos = nxt

    def prefill_with_images(self, ids, cache, images, start=0):
        """Fold a prompt that CONTAINS PICTURES into the cache.

        The ladder hashes an image as one <image:digest> atom, so the token
        ids it hands us carry a placeholder where the picture goes. The model
        needs the real thing: the vision tower turns pixels into embeddings
        that sit inline in the language model's input, and those embeddings
        are what must land in the KV cache.

        So this runs the tower, splices its output into the embedded prompt,
        and prefills the language half over the result -- still on the
        ABSOLUTE GRID, because a checkpoint boundary inside a hybrid model's
        recurrent span changes the state (see the module docstring).

        AN IMAGE SPAN IS ATOMIC. A chunk boundary may fall before or after a
        picture's embeddings but never inside them: half an image is not a
        smaller image, it is a different one, and a checkpoint taken there
        would be restored as nonsense. Same rule the proxy already applies
        when hashing -- see tests/test_image_atomicity.py.
        """
        import io

        import mlx.core as mx
        from PIL import Image
        from mlx_vlm.utils import prepare_inputs

        # prepare_inputs takes PIL images (or paths), not raw bytes -- it
        # rejects bytes with "only a single or a list of entries is
        # supported". faxl carries images as bytes because that is what a
        # data: URL decodes to and what the digest is computed over, so the
        # decode happens here, at the one place that needs pixels.
        pil = []
        for raw in images:
            img = Image.open(io.BytesIO(raw))
            img.load()                      # decode now, inside our try
            pil.append(img.convert("RGB"))  # drop alpha/EXIF surprises
        images = pil

        # THE MODEL'S OWN IMAGE MARKERS, NOT faxl's HASH ATOM.
        #
        # The ladder keys on "<image:d4fc...>" -- a stable digest so the same
        # photograph hashes alike and a different one cannot collide. The model
        # knows nothing of that: Qwen3-VL splices its vision features where it
        # finds <|vision_start|><|image_pad|><|vision_end|>, and with no marker
        # merge_input_ids_with_image_features has nowhere to put them and
        # raises. Swap our atom for the model's marker, one for one and in
        # order, so the hash stays ours and the prompt is the model's.
        import re as _re
        prompt = self.tokenizer.decode(
            [int(t) for t in (ids.tolist() if hasattr(ids, "tolist") else ids)])
        marker = "<|vision_start|><|image_pad|><|vision_end|>"
        prompt, swapped = _re.subn(r"<image:[0-9a-f]+>", marker, prompt)
        if swapped == 0:
            # THIS CHUNK HAS NO PICTURE IN IT, which is normal rather than
            # wrong: once the instruction preamble is long enough to
            # checkpoint (and it must be -- faxl keys nothing under 1,024
            # tokens), prefill arrives here in chunks and the image sits in
            # one of them. Text-prefill this one and let the chunk that does
            # carry the marker do the vision work.
            return self.prefill(ids, cache, start)
        if swapped != len(images):
            # A genuine mismatch: more or fewer markers than pictures. The
            # model would splice the wrong count and describe an image that
            # was never sent, so refuse rather than guess.
            raise BackendError(
                f"{len(images)} image(s) supplied but {swapped} placeholder(s) "
                f"in this chunk; refusing to prefill a mismatched multimodal "
                f"prompt")
        inputs = prepare_inputs(self.processor, images=images,
                                prompts=[prompt])
        emb_ids = inputs.get("input_ids")
        pixels = inputs.get("pixel_values")
        if emb_ids is None or pixels is None:
            # NOTHING TO SPLICE. Falling through to the text prefill here would
            # serve an answer invented from the <image:digest> placeholder,
            # which is the precise failure this whole path exists to prevent.
            # Refuse loudly instead: a caller can act on an error, not on a
            # confident description of a photograph nobody looked at.
            raise BackendError(
                f"the vision processor returned no "
                f"{'input_ids' if emb_ids is None else 'pixel_values'} for "
                f"{len(images)} image(s); refusing to answer from a "
                f"placeholder")
        print(f"[faxl] vision: {len(images)} image(s) -> "
              f"{int(emb_ids.shape[1])} tokens at position {start}",
              flush=True)

        extra = {k: v for k, v in inputs.items()
                 if k not in ("input_ids", "pixel_values", "attention_mask")}
        # PREFILL EXACTLY WHAT WE WERE GIVEN. The caller has already withheld
        # the final token for its seed -- the prefill loop runs to
        # `n = len(ids) - 1` -- so this chunk arrives as
        #   "<image:...><|im_end|>\n<|im_start|>assistant"
        # and taking another token off here would drop "assistant" and leave
        # the model mid-scaffold.
        lm = self._lm()
        # One forward over the whole multimodal prompt. Chunking is not
        # applied across the image span, and for a single picture the span is
        # the prompt -- ~4,206 tokens on Qwen3-VL-4B, which is exactly why
        # this result is worth checkpointing.
        # POSITION IDS MUST ACCOUNT FOR WHAT IS ALREADY IN THE CACHE.
        #
        # Qwen3-VL uses M-RoPE, and mlx_vlm computes its position ids from the
        # ids it is handed: get_rope_index(input_ids, image_grid_thw) numbers
        # this CHUNK from zero (qwen3_vl.py:95). That is right for a whole
        # prompt and wrong for a resumed one -- the picture then sits at
        # positions 0..4206, on top of the preamble already in the cache, and
        # the model reads a turn that is already finished. It emitted
        # <|im_end|> as its very first token and every reply came back empty,
        # with a 99% cache hit and the vision tower having run correctly.
        #
        # The cache knows the truth, so number this chunk from where the cache
        # actually ends. Shape is (3, batch, seq): three because M-RoPE keeps
        # a temporal and two spatial axes, and for a text-position sequence
        # all three advance together.
        #
        # Measured after this change: expansion 4,206 tokens and a cache going
        # 1,780 -> 5,986 -- the same 5,987-token prompt the working exo run
        # reports for the same photograph (docs/plans/
        # welcome-page-and-workflows-NOTES.md: "preamble 1,772 tokens, image
        # ~4,200 pad tokens, total 5,987").
        # CLEAR THE MODEL'S LEFTOVER M-RoPE STATE FIRST.
        #
        # mlx_vlm caches _position_ids and _rope_deltas ON THE LANGUAGE MODEL
        # (qwen3_vl.py:98), not per request. They are set from the LAST
        # prompt's grid, and language.py reuses them when cache_offset != 0 --
        # which is every resumed request faxl serves. So request two onward
        # numbered its picture against request one's geometry.
        #
        # The signature is unmistakable once seen: a fresh process answers
        # correctly and every request after it returns "None." with a perfect
        # cache hit and the vision tower having run. Clearing the two fields
        # before the tower runs restores the correct caption verbatim.
        #
        # This is per-process global state in a library, so faxl must own it:
        # the proxy serves many prompts through one model instance, which is
        # not the one-shot shape mlx_vlm's own generate() assumes.
        _lang = getattr(self.model, "language_model", None)
        if _lang is not None:
            _lang._position_ids = None
            _lang._rope_deltas = None
        # NUMBER THIS CHUNK FROM WHERE THE CACHE ACTUALLY ENDS, not from
        # `start`. `start` is a position in the ATOM stream, where a picture
        # is 18 text tokens; the cache holds EXPANDED positions, where the
        # same picture is ~4,200. The two agree only for the first image of a
        # request. cache[0].offset is the model's own count and is right for
        # every image -- which is what an insurance prompt (five reference
        # photographs, then the claim) needs to work at all.
        _off = start
        if cache:
            try:
                _o = cache[0].offset
                _off = int(_o if isinstance(_o, int) else
                           (_o if _o.ndim == 0 else _o[0]).item())
            except (AttributeError, IndexError, TypeError):
                pass
        if "position_ids" not in extra:
            _n = int(emb_ids.shape[1])
            _pos = mx.arange(_off, _off + _n).reshape(1, 1, -1)
            extra["position_ids"] = mx.broadcast_to(
                _pos, (3, int(emb_ids.shape[0]), _n))
        self.model(emb_ids, pixels, cache=cache, **extra)
        mx.eval([c.state for c in cache])
        # AND CORRECT THE STATE THE TOWER JUST LEFT BEHIND. This is the whole
        # reason every caption came back "None." through the served proxy
        # while the same prompt answered correctly in-process.
        #
        # Clearing the two fields BEFORE the call (just above) is necessary
        # and not sufficient: qwen3_vl.get_input_embeddings RE-SETS both of
        # them during this very call (qwen3_vl.py:92-98), from
        # get_rope_index(input_ids, ...), which numbers the chunk FROM ZERO
        # because it never sees the cache.
        #
        # What then happens on the DECODE step, exactly: language.py:519
        # clears both fields whenever pixel_values is not None, and because
        # this call passes explicit position_ids the block that would
        # repopulate them is skipped (`if position_ids is None ...`). So the
        # tower leaves _rope_deltas as None -- verified in the live process --
        # and the seed token, arriving with no position_ids of its own, takes
        # the `self._rope_deltas is None` branch at language.py:534. That
        # calls get_rope_index on a ONE-TOKEN input and numbers it 0. The
        # model reads its own first generated token as position zero of the
        # conversation -- a turn already finished -- and emits <|im_end|>
        # immediately, so the reply is empty. With a 99% cache hit and the
        # vision tower having run correctly.
        #
        # Setting deltas to 0 routes decode into the OTHER branch, where
        # position = cache_offset + delta = cache_offset + 0, which is the
        # true position of the next token.
        #
        # delta = 0 is the right value, not a nudge: our position_ids above
        # already number this chunk absolutely, so the decode step needs
        # cache_offset and nothing added to it. _position_ids must go too --
        # it is indexed as [:, :, cache_offset : cache_offset + L], and the
        # tower's copy is only as long as this chunk.
        #
        # Measured on one photograph through the live stack:
        #   as written by the tower : '\nNone.'
        #   with deltas zeroed      : 'TEXT: NONE / SCENE: A young woman with
        #                              curly hair sits at a red-and-white
        #                              checkered table, using a smartphone...'
        if _lang is not None:
            _lang._position_ids = None
            _lang._rope_deltas = mx.array([0])
        return int(emb_ids.shape[1])

    def generate(self, seed, cache, max_tokens):
        """(out_ids, t_first). t_first is when the FIRST token was decoded,
        so TTFT is measured directly rather than reconstructed."""
        from mlx_lm.generate import generate_step
        out = []
        t_first = None
        for i, (t, _) in enumerate(generate_step(
                seed, self._lm(), prompt_cache=cache,
                max_tokens=max_tokens, sampler=self.sampler)):
            if t_first is None:
                t_first = time.time()
            if int(t) in self.stop_ids:
                break
            out.append(int(t))
            if i + 1 >= max_tokens:
                break
        return out, t_first


class ExoBackend(Backend):
    """An exo cluster, addressed as one engine.

    exo shards a model across Apple-silicon machines on a LAN or Thunderbolt
    fabric, which is how a model too large for one box becomes runnable at
    all. faxl keeps everything above the engine: the ladder decides what to
    reuse, the store holds it, the console reports it, the licence gates it.
    exo's own in-RAM prefix cache is disabled (EXO_PREFIX_CACHE=0) — it dies
    with the runner processes on any topology event, which is precisely where
    a cluster needs a cache most.

    Requires exo's source on the path (EXO_SRC) and a reachable node. Both are
    checked at construction: a cluster that is not there must fail loudly at
    boot, not per request.
    """

    name = "exo"
    # The cluster's runners hold the real model, vision tower included, and
    # the proxy forwards the ORIGINAL request body with its images intact.
    accepts_images = True

    def __init__(self, model_id, endpoint=None, seg=256, src=None,
                 timeout_s=1800.0):
        self.model_id = model_id
        self.endpoint = (endpoint
                         or os.environ.get("FAXL_EXO_ENDPOINT",
                                           "http://127.0.0.1:52415"))
        self.seg = int(seg)
        self.timeout_s = float(timeout_s)
        # AN INSTALLED exo IS THE NORMAL CASE, and this ran at construction, so
        # a default pointing inside one developer's home meant FAXL_BACKEND=exo
        # could not start AT ALL on a machine that was not this one -- however
        # exo had been installed. EXO_SRC remains an override for driving a
        # working copy; absent, exo is imported like any other dependency.
        src = src or os.environ.get("EXO_SRC")
        if src:
            src = os.path.expanduser(src)
            if not os.path.isdir(src):
                raise BackendError(
                    f"EXO_SRC points at {src}, which is not a directory. Unset "
                    f"it to use the installed exo package.")
        self._src = src
        self._check_reachable()

    def _check_reachable(self):
        """A cluster that is not answering is a boot failure, not a slow
        request."""
        import json
        import urllib.error
        import urllib.request
        url = f"{self.endpoint}/v1/models"
        try:
            with urllib.request.urlopen(url, timeout=10) as r:
                body = json.loads(r.read().decode())
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise BackendError(
                f"exo is not answering at {self.endpoint} ({e}). Start a node "
                f"with EXO_PREFIX_CACHE=0 so faxl owns reuse, or select a "
                f"different FAXL_BACKEND.") from e
        ids = [m.get("id") for m in (body.get("data") or [])]
        if ids and self.model_id not in ids:
            print(f"!! exo at {self.endpoint} serves {ids}, not "
                  f"{self.model_id!r} — requests will be placed on demand",
                  flush=True)

    # The cluster holds the cache for a request in its own workers; faxl
    # addresses it by the checkpoint it supplied. These are implemented
    # against exo's worker API in the cluster milestone — declared here so the
    # seam is explicit, and raising rather than silently degrading.
    def make_cache(self):
        raise BackendError(
            "ExoBackend.make_cache is not implemented: the cluster execution "
            "path is the next milestone. Use FAXL_BACKEND=mlx for the "
            "single-machine path.")

    def prefill(self, ids, cache, start=0):
        raise BackendError("ExoBackend.prefill is not implemented yet")

    def generate(self, seed, cache, max_tokens):
        raise BackendError("ExoBackend.generate is not implemented yet")


def make_backend(name, **kw):
    """Select the execution backend.

        FAXL_BACKEND=mlx   (default) one machine, in process
        FAXL_BACKEND=exo   an exo cluster

    An unknown name is a hard error listing what exists: a typo must never
    silently pick a different engine.

    Which names exist is faxl_backends' (the descriptor registry, shared with
    the console): a name it does not know, or knows but marks unavailable, is
    refused with its note. The execution classes stay here, per product line:
    _CLASSES maps a registered name to the class that runs it in this line.
    """
    from faxl.engine import faxl_backends
    name = (name or os.environ.get("FAXL_BACKEND", "mlx")).strip().lower()
    d = faxl_backends.get(name)
    offered = [n for n in faxl_backends.names()
               if faxl_backends.is_available(n) and n in _CLASSES]
    if d is None:
        raise BackendError(
            f"unknown backend {name!r}; available: {', '.join(offered)}")
    if not d["available"]:
        raise BackendError(
            f"backend {name!r} is not available"
            + (f" ({d['note']})" if d.get("note") else "")
            + f"; available: {', '.join(offered)}")
    cls = _CLASSES.get(name)
    if cls is None:
        raise BackendError(
            f"backend {name!r} ({d['label']}) has no execution class in this "
            f"build; available: {', '.join(offered)}")
    return cls(**kw)


# registered name -> the class that runs it on this product line.
_CLASSES = {"mlx": LocalMlxBackend, "exo": ExoBackend}

# What faxl_proxy imports at MODULE TOP, whatever the backend (2026-09-22):
# mlx.core and mlx_lm (load, make_prompt_cache, generate_step, make_sampler,
# hf_repo_to_path). On a Linux box without mlx the proxy cannot even be
# imported -- the gap step 4 closes by making those imports lazy.
PROXY_TOP_IMPORTS = ("mlx.core", "mlx_lm")
# The engine each backend needs importable, beyond the proxy's own imports.
ENGINE_IMPORTS = {"vllm": ("vllm", "torch")}


def _importable(mod):
    import importlib.util
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError):
        return False


def proxy_can_run(name):
    """(ok, reason): can `python -m faxl.engine.faxl_proxy` serve backend
    `name` in this interpreter? Checked WITHOUT importing the proxy (which
    loads a model at import). faxl_start.sh asks before starting anything."""
    name = str(name or "").strip().lower()
    missing = [m for m in PROXY_TOP_IMPORTS if not _importable(m)]
    if missing:
        return False, (f"faxl.engine.faxl_proxy cannot be imported here: it "
                       f"imports {', '.join(missing)} at module top (mlx is "
                       f"Apple-only)")
    if name not in _CLASSES:
        return False, (f"this build has no execution class for {name!r} "
                       f"(faxl.engine.backends has "
                       f"{', '.join(sorted(_CLASSES))})")
    need = [m for m in ENGINE_IMPORTS.get(name, ()) if not _importable(m)]
    if need:
        return False, f"{', '.join(need)} not installed in this interpreter"
    return True, None


def main(argv=None):
    import argparse
    import sys
    ap = argparse.ArgumentParser(prog="python -m faxl.engine.backends")
    ap.add_argument("--can-run", metavar="BACKEND", required=True,
                    help="exit 0 if the proxy can serve BACKEND here, else 4 "
                         "with the reason on stderr")
    a = ap.parse_args(argv)
    ok, why = proxy_can_run(a.can_run)
    if ok:
        print(f"ok {a.can_run}")
        return 0
    print(why, file=sys.stderr)
    return 4


if __name__ == "__main__":
    raise SystemExit(main())

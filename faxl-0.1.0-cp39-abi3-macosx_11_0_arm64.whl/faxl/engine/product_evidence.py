# Vendored engine module (product_evidence.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""Explicitly opted-in raw serving evidence. Never enabled by telemetry.

Token convention: JSON UTF-8, compact separators, nonnegative integer IDs.
Raw engine IDs include stop IDs; effective preparse IDs exclude trailing stop
IDs exactly as the backend does. HTTP bytes are base64, with no normalization.
"""
import base64
import copy
import datetime as dt
import gzip
import hashlib
import importlib
import importlib.metadata
import json
import marshal
import os
import re
import site
import sysconfig
from pathlib import Path
import sys
import threading
import uuid

SCHEMA = "faxl-product-evidence-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def snapshot(value):
    """Detach every nested measurement before releasing the serving lock."""
    return copy.deepcopy(value)


def bytes_record(data):
    return {"base64": base64.b64encode(data).decode("ascii"), "sha256": sha(data), "length": len(data)}


def ids_record(ids):
    if ids is None:
        return None
    ids = list(ids)
    if any(type(t) is not int or t < 0 for t in ids):
        raise ValueError("token IDs must be nonnegative integers")
    return {"ids": ids, "encoding": "json-compact-utf8-v1", "sha256": sha(canonical(ids)), "length": len(ids)}


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def publish(path, data):
    """Publish once, fsync bytes and directory; refuse existing artifacts."""
    path = Path(path)
    tmp = path.with_name("." + path.name + "." + uuid.uuid4().hex)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(tmp, path)
        tmp.unlink()
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        if tmp.exists():
            tmp.unlink()


# Runtime discovery may include vendored metadata added to sys.path by imports.
# Installation identity instead uses Python's enabled installation directories.
CRITICAL_DISTRIBUTIONS = {"torch": "torch", "vllm": "vllm",
                          "transformers": "transformers", "packaging": "packaging",
                          "faxl": "faxl", "ultradim": "ultradim"}


def distribution_name(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def installation_roots():
    roots = [sysconfig.get_path("purelib"), sysconfig.get_path("platlib")]
    roots.extend(site.getsitepackages())
    if site.ENABLE_USER_SITE:
        user = site.getusersitepackages()
        roots.extend([user] if isinstance(user, str) else user)
    return sorted({str(Path(root).resolve()) for root in roots if root})


def distribution_record(dist, include_payload=False):
    # Files/locate_file are the public Distribution API. Refuse unlocated or
    # ambiguous metadata rather than manufacturing identity from a name alone.
    candidates = [f for f in (dist.files or ())
                  if len(f.parts) == 2 and f.name in ("METADATA", "PKG-INFO")
                  and (f.parent.name.endswith(".dist-info") or f.parent.name.endswith(".egg-info"))]
    if len(candidates) != 1:
        raise RuntimeError("unlocated/ambiguous distribution metadata: " + str(dist.metadata["Name"]))
    path = Path(dist.locate_file(candidates[0])).resolve(strict=True)
    data = path.read_bytes()
    record = path.parent / "RECORD"
    record_bytes = record.read_bytes()  # unsupported/unverifiable install fails
    name, version = dist.metadata["Name"], dist.version
    if not name or not version:
        raise RuntimeError("missing distribution name/version: " + str(path))
    row = {"name": name, "canonical_name": distribution_name(name), "version": version,
            "root": str(Path(dist.locate_file("")).resolve(strict=True)),
            "metadata_origin": str(path), "metadata_sha256": sha(data), "metadata_size_bytes": len(data),
            "record_origin": str(record), "record_sha256": sha(record_bytes), "record_size_bytes": len(record_bytes)}
    if include_payload:
        row["metadata_bytes"] = bytes_record(data)
        row["record_bytes"] = bytes_record(record_bytes)
    return row


def dependency_identity():
    """Raw discovery plus unambiguous installed and actually imported identity.

    Critical modules must already have been imported by the caller. External,
    editable, and shadowed critical modules fail when RECORD cannot bind their
    actual origin to the selected installed distribution. No imports, GPU work,
    version normalization, or sys.path changes happen inside this observation.
    """
    roots = installation_roots()
    installed = {}
    for dist in importlib.metadata.distributions(path=roots):
        row = distribution_record(dist, include_payload=True)
        key = row["canonical_name"]
        if key in installed:
            raise RuntimeError("ambiguous installed distribution: " + key)
        if row["root"] not in roots:
            raise RuntimeError("distribution outside installation roots: " + key)
        installed[key] = row
    visible = sorted((distribution_record(d) for d in importlib.metadata.distributions()),
                     key=lambda r: (r["canonical_name"], r["metadata_origin"], r["version"]))
    selected, loaded = {}, {}
    for name, key in CRITICAL_DISTRIBUTIONS.items():
        dist = importlib.metadata.distribution(key)
        selected[name] = distribution_record(dist, include_payload=True)
        if key not in installed or selected[name] != installed[key]:
            raise RuntimeError("selected critical distribution outside canonical installation: " + name)
        module = sys.modules.get(name)
        origin = getattr(module, "__file__", None)
        if not origin:
            raise RuntimeError("critical module not imported or missing origin: " + name)
        path = Path(origin).resolve(strict=True)
        members = {Path(dist.locate_file(f)).resolve() for f in (dist.files or ())}
        if path not in members:
            raise RuntimeError("critical import not owned by selected distribution: " + name)
        data = path.read_bytes()
        version = getattr(module, "__version__", None)
        loaded[name] = {"origin": str(path), "sha256": sha(data), "size_bytes": len(data),
                        "version": str(version) if version is not None else None, "bytes": bytes_record(data)}
        if name == "torch":
            loaded[name]["cuda_build"] = module.version.cuda
    return {"schema": "faxl-dependency-identity-v2", "installation_roots": roots,
            "installed": dict(sorted(installed.items())), "visible_distributions": visible,
            "selected": selected, "loaded": loaded}


class Writer:
    def __init__(self, directory, identity, modules):
        self.boot_id = uuid.uuid4().hex
        self.directory = Path(directory).absolute() / self.boot_id
        self.directory.mkdir(parents=True, mode=0o700, exist_ok=False)
        fd = os.open(self.directory.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        self.lock = threading.Lock()
        self.failed = None
        pins = {}
        for name, module in sorted(modules.items()):
            origin = getattr(module, "__file__", None)
            if not origin:
                raise RuntimeError("evidence binding missing module origin: " + name)
            path = Path(origin).resolve(strict=True)
            data = path.read_bytes()
            digest = sha(data)
            pin = name + "." + digest + ".gz"
            publish(self.directory / pin, gzip.compress(data, mtime=0))
            pins[name] = {"origin": str(path), "sha256": digest, "pin": pin}
            cached = getattr(module, "__cached__", None)
            if cached and Path(cached).is_file():
                cache_bytes = Path(cached).read_bytes()
                code = marshal.loads(cache_bytes[16:])
                if compile(data, code.co_filename, "exec", dont_inherit=True,
                           optimize=sys.flags.optimize) != code:
                    raise RuntimeError("imported bytecode does not match pinned source: " + name)
                cache_digest = sha(cache_bytes)
                cache_pin = name + ".cached." + cache_digest + ".gz"
                publish(self.directory / cache_pin, gzip.compress(cache_bytes, mtime=0))
                pins[name]["cached"] = {"origin": str(Path(cached).resolve()),
                                       "sha256": cache_digest, "pin": cache_pin}
        required = {"faxl.engine.product_evidence", "faxl.engine.faxl_proxy", "faxl.engine.backends", "faxl._faxl", "ultradim._ultradim"}
        if not required <= pins.keys():
            raise RuntimeError("evidence binding missing required imports: " + repr(sorted(required - pins.keys())))
        self.writer_sha256 = pins["faxl.engine.product_evidence"]["sha256"]
        dependencies = dependency_identity()
        anchor = {"schema": SCHEMA, "kind": "boot", "boot_id": self.boot_id,
                  "writer_sha256": self.writer_sha256, "utc": utc(), "pid": os.getpid(),
                  "interpreter": os.path.abspath(sys.executable), "python": sys.version,
                  "packages": {k: row["version"] for k, row in dependencies["installed"].items()},
                  "dependencies": dependencies,
                  "pins": pins, "identity": identity}
        self.anchor_sha256 = sha(canonical(anchor))
        publish(self.directory / "anchor.json", canonical(anchor) + b"\n")
        # The stream must be writable before serving, and its existence durable.
        publish(self.directory / "records.jsonl", b"")

    def append(self, kind, serving_request_id, api_response_id, **fields):
        with self.lock:
            if self.failed:
                raise RuntimeError("evidence writer unavailable: " + self.failed)
            record = {"schema": SCHEMA, "kind": kind, "boot_id": self.boot_id,
                      "writer_sha256": self.writer_sha256, "anchor_sha256": self.anchor_sha256,
                      "serving_request_id": serving_request_id, "api_response_id": api_response_id,
                      "utc": utc(), **fields}
            try:
                with (self.directory / "records.jsonl").open("ab") as stream:
                    stream.write(canonical(record) + b"\n")
                    stream.flush()
                    os.fsync(stream.fileno())
            except Exception as exc:
                self.failed = str(exc)
                raise


def from_environment(identity):
    directory = os.environ.get("FAXL_EVIDENCE_DIR")
    raw = os.environ.get("FAXL_EVIDENCE_RAW")
    if directory is None and raw is None:
        return None
    if not directory or raw != "1":
        raise RuntimeError("raw evidence requires both FAXL_EVIDENCE_DIR and explicit FAXL_EVIDENCE_RAW=1")
    if identity["backend"] != "vllm":
        raise RuntimeError("raw product evidence is supported only on the vllm backend")
    modules = {name: module for name, module in list(sys.modules.items())
               if module is not None and (name == "faxl" or name.startswith("faxl.")
                                          or name == "ultradim" or name.startswith("ultradim."))
               and getattr(module, "__file__", None)}
    proxy = sys.modules.get("__main__")
    if proxy is not None and Path(getattr(proxy, "__file__", "")).name == "faxl_proxy.py":
        modules["faxl.engine.faxl_proxy"] = proxy
    if identity["backend"] == "vllm":
        for name in ("vllm.outputs", "vllm.v1.metrics.stats", "vllm.v1.engine.output_processor"):
            module = sys.modules.get(name)
            if module is None:
                raise RuntimeError("evidence binding missing runtime import: " + name)
            modules[name] = module
    return Writer(directory, identity, modules)

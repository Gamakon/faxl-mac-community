"""faxl's ladder, served to an exo cluster over exo's own prefill wire.

This is R1. A prompt arrives at the faxl proxy; the proxy decides what to
reuse and hands execution to exo. When exo's runner needs a prefill it opens
exo's disaggregated-prefill socket to the endpoint it was given
(FAXL_PREFILL_ENDPOINT), and that endpoint is this server. faxl runs its
ladder over the token ids in the request and streams back the deepest
confirmed checkpoint it holds; exo prefills whatever tail is left.

WHY THIS IS THE RIGHT DIRECTION. The bytes travel exo -> faxl on a socket exo
opened, but the request arrived at faxl, faxl owns the store, faxl decides
what is reused, and exo is the engine faxl drives. A socket's direction is
transport, not architecture. faxl is never imported into exo's runner.

WHAT THIS SERVER NEEDS: nothing but the store. load_prompt_cache rebuilds an
mlx cache from the safetensors metadata alone -- no weights, no GPU, no
tokenizer -- so this thread never contends with the proxy's inference and can
serve a 48B model's cache from a process holding no model memory at all.

THREE RULES, each of which is a bug if broken:

  * start_pos is ALWAYS 0 on the way out. It means "the receiver already has
    this many tokens, send only what is beyond" -- a delta. The store holds
    WHOLE caches from token 0. Passing the ladder position instead makes
    send_mlx_kv_cache skip every KV layer (offset <= start_pos) while the
    ArraysCache branch, which has no such check, sends the recurrent state
    anyway: the two halves of a hybrid end up at different depths and decode
    runs from state that disagrees with itself. See
    exo/.../tests/test_start_pos_hybrid_desync.py.

  * A SHARDED rank gets only its own layers. The wire carries local indices,
    so a whole-model cache must be sliced to [start_layer, end_layer) before
    it goes out; `enumerate` then relabels it to local indices for free.

  * Done(total_tokens) is AUTHORITATIVE. The client derives its offset from
    KV token counts, and a shard holding only recurrent layers has none --
    it would compute 0 and re-prefill everything, re-folding the recurrent
    state on top of itself.
"""
import os
import sys
import threading

from faxl.engine.media_regions import MediaRegion, find_regions

STORE_LOCK = threading.Lock()


class PrefillServerError(RuntimeError):
    """The prefill server cannot start. Raised at construction, never mid-request."""


class StoreWireError(RuntimeError):
    """A pushed checkpoint could not be read off the wire."""


def _import_exo(src=None):
    """Put exo's source on the path and return the pieces of its wire we use.

    faxl imports exo, never the reverse: exo is the engine this product
    drives. Importing its serializer is what keeps the two sides on one
    format -- a second implementation of the same frames would be a second
    thing to get wrong.
    """
    # AN INSTALLED PACKAGE IS THE NORMAL CASE. This used to REQUIRE a source
    # directory and defaulted to a path inside one developer's home --
    # ~/Dev/gamakon/exo-workbench/exo/src -- which shipped in the wheel. A
    # customer has no such folder, so the exo backend could not start however
    # exo was installed, and the error told them to go and find a checkout.
    #
    # So: import exo the way any other dependency is imported. EXO_SRC (or the
    # `src` argument) stays as an override for driving a working copy, which is
    # how this machine develops against an unreleased exo.
    src = src or os.environ.get("EXO_SRC")
    if src:
        src = os.path.expanduser(src)
        if not os.path.isdir(src):
            raise PrefillServerError(
                f"EXO_SRC points at {src}, which is not a directory. Unset it "
                f"to use the installed exo package.")
        if src not in sys.path:
            sys.path.insert(0, src)
    try:
        from exo.worker.disaggregated.protocol import (ArraysState, Done, Header,
                                                       KVChunk, read_header,
                                                       read_message, write_done,
                                                       write_header)
        from exo.worker.disaggregated.server import PrefillRequest, PrefillServer
        from exo.worker.engines.mlx.disaggregated.adapter import (
            chunk_to_mlx_nhd, inject_arrays_cache, inject_kv_chunk,
            send_mlx_kv_cache, wire_dtype_from_cache)
    except ImportError as e:
        where = f"the checkout at {src}" if src else "the installed exo package"
        raise PrefillServerError(
            f"faxl could not import exo's prefill wire from {where} ({e}). "
            f"Either exo is not installed — install it, or set EXO_SRC to a "
            f"checkout — or faxl and exo are on different protocol versions."
        ) from e
    return {"Header": Header, "write_header": write_header,
            "write_done": write_done, "PrefillRequest": PrefillRequest,
            "PrefillServer": PrefillServer,
            "send_mlx_kv_cache": send_mlx_kv_cache,
            "wire_dtype_from_cache": wire_dtype_from_cache,
            "read_header": read_header, "read_message": read_message,
            "KVChunk": KVChunk, "ArraysState": ArraysState, "Done": Done,
            "chunk_to_mlx_nhd": chunk_to_mlx_nhd,
            "inject_kv_chunk": inject_kv_chunk,
            "inject_arrays_cache": inject_arrays_cache}


# Image pad tokens, by model family. An image is expanded into N copies of ONE
# pad id, so the picture itself is NOT in the token stream -- it arrives as
# pixel embeddings. Two different photos of the same size therefore produce
# BYTE-IDENTICAL ids, the ladder's confirm passes, and the first photo's state
# is served for the second. Measured: 134 of 141 requests collided and 24
# different photos got one identical caption.
#
# These ids are now only needed to SPOT an image in a request that arrived
# without regions -- identity itself comes from the wire. Qwen-VL 151655,
# Gemma 3 262144, Llava 32000, Pixtral 10; overridable for a model not listed.
# A pad id that is not this model's is simply never present, so a wrong guess
# costs nothing, and a missed one only costs a hit (the ids still have to
# confirm byte-for-byte).
IMAGE_PAD_IDS = {151655, 262144, 32000, 10}
_extra = os.environ.get("FAXL_IMAGE_PAD_IDS", "").strip()
if _extra:
    IMAGE_PAD_IDS |= {int(x) for x in _extra.replace(",", " ").split() if x.strip().isdigit()}


def _regions_for(request, ids):
    """The image regions this request's tokens cover.

    Normally the wire carries them: exo's vision encoder placed the
    embeddings, so it knows exactly where each image sits and what it was
    (sha256 of decoded RGB pixels).

    WHEN IT CARRIES NONE BUT THE IDS HOLD A PAD RUN, regions are derived from
    the ids with EMPTY hashes. That is not a fallback that guesses -- an empty
    hash never matches anything, so the effect is that a match can never
    extend into an image whose identity is unknown. It caps at the image and
    the picture is reprocessed.

    This is what makes the guarantee hold for every backend rather than for
    the one that remembers to send regions. A backend that sends nothing
    degrades to text-prefix hits; it cannot produce a wrong image hit. exo
    itself takes this path when vision processing fails and it falls back to
    text-only (batch_generate.py:163), which is exactly when the ids still
    contain pads but no identity is available.
    """
    wire = getattr(request, "media_regions", None) or []
    if wire:
        return [MediaRegion(content_hash=str(getattr(r, "content_hash", "")),
                            start_pos=int(getattr(r, "start_pos", 0)),
                            end_pos=int(getattr(r, "end_pos", 0)))
                for r in wire]
    return find_regions(ids, IMAGE_PAD_IDS, [])


def _serve_nothing(exo, wfile, request, model_id, reason):
    """Answer a miss with a VALID empty response, not an error.

    Returning False from a resolve handler makes exo's server send a 503,
    which EXO_REMOTE_PREFILL=strict turns into a raised exception. A ladder
    miss is not a failure -- it is the normal cold path, and every prompt is
    cold once. So a miss is a well-formed zero-token serve: exo sees
    final_offset 0 and prefills the whole prompt itself.
    """
    exo["write_header"](wfile, exo["Header"](
        request_id=request.request_id, model_id=str(model_id),
        num_layers=0, dtype="bfloat16", start_pos=0))
    exo["write_done"](wfile, 0)
    wfile.flush()
    print(f"[faxl] prefill miss ({reason}) — exo will prefill locally",
          flush=True)
    return True


def _receive_checkpoint(exo, store, model_id, request, wfile, rfile):
    """R2: the request CARRIES state. Read it, verify it, store it.

    The frames that follow a store=True request are exactly what a serve
    produces, so this is the reading half of the same protocol -- one format,
    both directions.

    Everything is checked before anything is written. A checkpoint recorded at
    the wrong depth is not a bad hit, it is silent corruption: the store
    cannot inspect an mlx cache to find out how deep it is (an ArraysCache is
    one rolled-up tensor with no position in it at all), so the sender's
    figure is taken on trust and must therefore be justified.
    """
    ids = list(request.token_ids)
    caches, depth = [], 0
    try:
        exo["read_header"](rfile)
        by_layer = {}
        arrays = {}
        while True:
            msg = exo["read_message"](rfile)
            if msg is None:
                break
            if isinstance(msg, exo["KVChunk"]):
                by_layer.setdefault(msg.layer_idx, []).append(msg)
            elif isinstance(msg, exo["ArraysState"]):
                arrays[msg.layer_idx] = msg.arrays
            elif isinstance(msg, exo["Done"]):
                depth = int(msg.total_tokens)
                break
            else:
                raise StoreWireError(f"sender reported an error: {msg}")
    except Exception as e:  # noqa: BLE001 — a bad push must not kill the server
        print(f"!! [faxl] checkpoint push unreadable ({type(e).__name__}: {e})",
              flush=True)
        return _ack(exo, wfile, request, model_id, 0)

    n_layers = max(list(by_layer) + list(arrays), default=-1) + 1
    if n_layers <= 0:
        return _ack(exo, wfile, request, model_id, 0)

    # IMAGE IDENTITY, on the way in as well as out. The regions are STORED
    # alongside the state, and the read path compares them, so a checkpoint
    # can only ever be served back to the pictures that produced it.
    #
    # A checkpoint whose depth falls INSIDE an image is kept, not refused. It
    # is the normal case and the valuable one: in a 7442-token insurance
    # prompt only one multiple of the 256-token grid is clear of every image,
    # and it sits past the claim photo. Such state matches only a prompt
    # carrying the same picture at the same offset -- which the stored regions
    # are what enforce.
    regions = _regions_for(request, ids)

    # REFUSALS, before any state is rebuilt. Each of these would otherwise
    # produce an entry the ladder either cannot read or must not trust.
    if depth <= 0 or depth % store.seg:
        print(f"!! [faxl] checkpoint push REFUSED: depth {depth} is not on the "
              f"{store.seg}-token grid", flush=True)
        return _ack(exo, wfile, request, model_id, 0)
    if depth > len(ids):
        print(f"!! [faxl] checkpoint push REFUSED: depth {depth} exceeds the "
              f"{len(ids)} tokens supplied", flush=True)
        return _ack(exo, wfile, request, model_id, 0)

    # The KV half states its own depth; it must agree with what the sender
    # claimed, or one of the two halves is at the wrong position.
    kv_depth = max((sum(c.num_tokens for c in ch) for ch in by_layer.values()),
                   default=depth)
    if by_layer and kv_depth != depth:
        print(f"!! [faxl] checkpoint push REFUSED: KV layers hold {kv_depth} "
              f"tokens but Done says {depth}", flush=True)
        return _ack(exo, wfile, request, model_id, 0)

    # A sharded rank cannot write a whole-model checkpoint: the store's blob
    # is whole-model, and half of one is not a thing the ladder can resume.
    span = getattr(request, "layer_span", None)
    if callable(span) and int(getattr(request, "n_layers", 0)):
        lo, hi = span(int(request.n_layers))
        if (lo, hi) != (0, int(request.n_layers)):
            print(f"!! [faxl] checkpoint push REFUSED: rank holds layers "
                  f"[{lo},{hi}) of {request.n_layers} — a whole-model "
                  f"checkpoint cannot be written from one shard", flush=True)
            return _ack(exo, wfile, request, model_id, 0)

    # Rebuild the caches the sender described, in layer order.
    from mlx_lm.models.cache import ArraysCache, KVCache
    for i in range(n_layers):
        if i in by_layer:
            c = KVCache()
            chunks = by_layer[i]
            if len(chunks) == 1:
                k, v = exo["chunk_to_mlx_nhd"](chunks[0])
            else:
                import mlx.core as mx
                dec = [exo["chunk_to_mlx_nhd"](x) for x in chunks]
                k = mx.concatenate([a for a, _ in dec], axis=0)
                v = mx.concatenate([b for _, b in dec], axis=0)
            exo["inject_kv_chunk"](c, k, v, depth)
            caches.append(c)
        elif i in arrays:
            c = ArraysCache(len(arrays[i]))
            exo["inject_arrays_cache"](c, arrays[i])
            caches.append(c)
        else:
            print(f"!! [faxl] checkpoint push REFUSED: layer {i} missing",
                  flush=True)
            return _ack(exo, wfile, request, model_id, 0)

    hybrid = bool(arrays)
    with STORE_LOCK:
        entry = store.checkpoint(model_id, ids, depth, caches,
                                 hybrid=hybrid, regions=regions)
    if entry is None:
        # Already stored (write-once) or refused by the store's own gate.
        print(f"[faxl] checkpoint push at {depth}: nothing written "
              f"(already held, or below the gate)", flush=True)
        return _ack(exo, wfile, request, model_id, depth)

    counts = getattr(_receive_checkpoint, "_counts", None)
    if counts is not None:
        counts["stored"] = counts.get("stored", 0) + 1
    print(f"[faxl] checkpoint STORED at {depth}/{len(ids)} tokens "
          f"({n_layers} layers, hybrid={hybrid})", flush=True)
    return _ack(exo, wfile, request, model_id, depth)


def _ack(exo, wfile, request, model_id, stored):
    """Acknowledge a push: Header + Done(stored). 0 means nothing was kept."""
    exo["write_header"](wfile, exo["Header"](
        request_id=request.request_id, model_id=str(model_id),
        num_layers=0, dtype="bfloat16", start_pos=0))
    exo["write_done"](wfile, int(stored))
    wfile.flush()
    return True


def make_resolver(store, model_id, exo=None, counts=None):
    """Build the resolve handler exo's PrefillServer calls per connection.

    `counts` is the proxy's EXO_COUNTS dict: hit/miss is decided HERE, not in
    the request handler, so this is how /metrics and the console learn what
    happened. Bumped on every serve.
    """
    exo = exo or _import_exo()
    counts = counts if counts is not None else {}

    def resolve(request, wfile, rfile=None):
        # WRONG MODEL. Serving one model's state into another's layers is
        # unbounded corruption, so this one refuses outright rather than
        # degrading to a miss.
        if str(request.model_id) != str(model_id):
            print(f"!! [faxl] prefill REFUSED: request for "
                  f"{request.model_id!r}, this store serves {model_id!r}",
                  flush=True)
            return False

        # DIRECTION. store=True means the request CARRIES state rather than
        # asking for it: R2, the writeback after a local prefill.
        if bool(getattr(request, "store", False)):
            if rfile is None:
                print("!! [faxl] checkpoint push arrived with no read stream",
                      flush=True)
                return False
            return _receive_checkpoint(exo, store, model_id, request,
                                       wfile, rfile)

        # A non-zero start_pos means the caller already holds partial state
        # this store cannot reason about. The store's caches begin at token 0.
        if int(getattr(request, "start_pos", 0)) != 0:
            return _serve_nothing(exo, wfile, request, model_id,
                                  f"start_pos={request.start_pos} != 0")

        ids = list(request.token_ids)
        counts["requests"] = counts.get("requests", 0) + 1
        counts["last_served"] = 0

        # IMAGES ARE NOT IDENTIFIED BY THEIR TOKENS. An image expands into N
        # copies of one pad id, so the pixels never enter the token stream and
        # two different photos of the same size are byte-identical here.
        #
        # The fix is to compare the images the prompt actually carries against
        # the ones the stored state was built from. The request says WHERE
        # each image sits and WHICH picture it was, so:
        #   same photo      -> the prefix HITS, image included
        #   different photo -> the match stops at THAT image's start, and only
        #                      that picture is reprocessed
        #
        # Stopping at the image rather than dropping the whole prefix is what
        # makes a multi-image prompt worth caching: five reference photographs
        # followed by the one to judge keeps the five and pays for the one.
        # A prompt with no image is unaffected.
        regions = _regions_for(request, ids)

        with STORE_LOCK:
            hit = store.lookup(model_id, ids, regions=regions)
        if hit is None:
            return _serve_nothing(exo, wfile, request, model_id,
                                  f"no checkpoint at or below {len(ids)} tokens")

        caches, pos = hit["caches"], int(hit["pos"])

        # SHARD SLICE. The rank asked for [start_layer, end_layer) of the
        # model; send exactly that, and enumerate relabels it to the local
        # indices the rank will inject at.
        span = getattr(request, "layer_span", None)
        start_layer, end_layer = (span(len(caches)) if callable(span)
                                  else (0, len(caches)))
        sliced = caches[start_layer:end_layer]
        if not sliced:
            return _serve_nothing(exo, wfile, request, model_id,
                                  f"layers [{start_layer},{end_layer}) empty")

        dtype = exo["wire_dtype_from_cache"](sliced)
        exo["write_header"](wfile, exo["Header"](
            request_id=request.request_id, model_id=str(model_id),
            num_layers=len(sliced), dtype=dtype, start_pos=0))
        # start_pos=0: whole caches, both halves, from token 0. See THE TRAP.
        exo["send_mlx_kv_cache"](wfile, sliced, dtype=dtype, start_pos=0)
        # AUTHORITATIVE depth. The store's `pos` is the only place the token
        # count lives for the recurrent half, which carries none of its own.
        exo["write_done"](wfile, pos)
        wfile.flush()

        counts["hits"] = counts.get("hits", 0) + 1
        counts["last_served"] = pos
        layers = (f"layers [{start_layer},{end_layer}) "
                  if (start_layer, end_layer) != (0, len(caches)) else "")
        print(f"[faxl] prefill HIT {pos}/{len(ids)} tokens {layers}"
              f"(phash {hit.get('phash', '?')[:16]})", flush=True)
        return True

    return resolve


def start_prefill_server(port, model_id, store=None, host="127.0.0.1", src=None,
                         counts=None):
    """Start the prefill server on `port` and return it.

    The socket carries token ids, which decode straight back to the prompt
    text, so it binds loopback unless told otherwise -- the same care the
    store takes with its 0600 token files. A cluster needs a reachable
    address here, which is a deliberate decision, not a default.
    """
    exo = _import_exo(src)
    if store is None:
        from faxl.engine.exo_store import open_store
        store = open_store(model_id)

    _receive_checkpoint._counts = counts
    server = exo["PrefillServer"](
        resolve=make_resolver(store, model_id, exo=exo, counts=counts),
        host=host, port=port)
    # The console needs to report THIS store, not the mlx-line Index, which on
    # the exo backend is empty by construction -- it read `index.exact` and
    # rendered "CACHE ENTRIES 0" while 50 checkpoints and 39 GB sat on disk
    # and the same page reported an 84% hit rate. Hang the store off the
    # server so the proxy can read it without importing serving internals.
    server.faxl_store = store
    scope = "loopback" if host in ("127.0.0.1", "localhost") else host
    print(f"[faxl] prefill server on {host}:{port} ({scope}) serving "
          f"{model_id} from {len(store)} checkpoint(s)", flush=True)
    return server

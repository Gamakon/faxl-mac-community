# Vendored engine module (audit_trail.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""audit_trail.py — M0 audit trail: schema + durable outbox writer.

Implements master plan v4.1 M0 (register rows 55/56/62/76/130/145; review
ER4/ER10/ER15/F2/F11/F12). ONE schema, emitted identically by the proxy
(faxl_proxy.py, real serving) and the calibrated simulator
(schedule_sim.py, replay of recorded traffic) so the replay validator
(audit_replay.py) runs on either.

ENVELOPE — every line carries (irreversible-schema list,
docs/requirements-traceability.md §3):
    schema_version   int, = SCHEMA_VERSION
    seq              per-process outbox sequence, strictly increasing from 0
    process_id       12-hex, new per process start; global order is
                     (process_id, seq) per node — NEVER wall clock (row 145)
    event_id         uuid4 hex (globally unique, dedup key for ingestion)
    wall_ts          informational wall clock (float s)
    ns_hash          int — index prefix (first 8 digest bytes, big-endian)
    ns_digest        64-hex SHA-256 — WITH ns_hash the composite namespace
                     on EVERY line (ER10: no line needs a join to find its
                     namespace); full 7-tuple lives in session_meta
    session          session label
    request_id       present on all request-scoped kinds
    kind             event kind (below)

KINDS
    session_meta   once per process: full canonical 7-tuple, strategy name
                   + JSON-safe config, gate constants, model curve in
                   force, fork_enabled, collect flag, sink path, workload
    request        prompt_len, prompt_sha, prefix_hashes = the FULL
                   per-request prefix-hash array (row 55). TOKEN CONTENT —
                   the array is invertible (data-handling policy §2); the
                   sink is classified C-TOKEN end to end
    lookup         probes = [{pos, phash, outcome}] deepest-first
                   (outcome: miss | confirm_unreadable | confirm_fail |
                   load_fail | confirm_pass), resume_pos, resume_phash
    decision       ctx = the full ScheduleContext (row 60b), strategy,
                   placements, anchor_count (the live count the tail-anchor
                   gate consulted; null when unused), fork = the gate
                   evaluation record with RAW inputs (row 56) or null
    lifecycle      action: stored | deduped | superseded | evicted |
                   rejected_write; phash, pos, ckpt_kind, blob_id, bytes,
                   chain_id (nullable), signals (raw decision-time),
                   predicted_ev = null until M3b, ev_model_version = null
    outcome        one per request: hit, resume_pos, counters, timings

Durability: unbuffered line-per-step — every emit is write+flush+fsync
(standing rule). A write failure is recorded on `self.failed` and printed
loudly; in collect mode the caller MUST surface it (the proxy fails
/health). The sink REFUSES volatile paths in collect mode (row 62).
"""
import json
import os
import socket
import tempfile
import time
import uuid

SCHEMA_VERSION = 1

_VOLATILE_PREFIXES = ("/tmp", "/var/tmp", "/private/tmp", "/private/var",
                      "/dev/shm")


def is_volatile_path(path):
    real = os.path.realpath(os.path.abspath(path))
    tmpdir = os.path.realpath(tempfile.gettempdir())
    return (real.startswith(tuple(p + "/" for p in _VOLATILE_PREFIXES))
            or real in _VOLATILE_PREFIXES
            or real == tmpdir or real.startswith(tmpdir + "/"))


class AuditTrail:
    def __init__(self, dir_path, session, ns, meta, collect=False):
        """ns: ns_identity.NamespaceIdentity. meta: session_meta payload
        (strategy, config, gate constants, curve, workload, fork_enabled)."""
        self.dir = os.path.abspath(dir_path)
        self.session = session
        self.ns = ns
        self.collect = bool(collect)
        self.failed = None      # first failure reason; caller surfaces it
        self.process_id = uuid.uuid4().hex[:12]
        self.seq = 0
        if self.collect and is_volatile_path(self.dir):
            raise SystemExit(
                f"!! AUDIT SINK {self.dir} is a VOLATILE path — collection "
                f"mode refuses to start (M0/register row 62): an "
                f"apparently-valid corpus that evaporates is the worst "
                f"outcome. Set FAXL_AUDIT_DIR to a durable path.")
        if not self.collect and is_volatile_path(self.dir):
            print(f"!! AUDIT SINK {self.dir} is volatile — fine for smoke "
                  f"tests, refused in collection mode", flush=True)
        os.makedirs(self.dir, exist_ok=True)
        self.path = os.path.join(self.dir, f"{session}.audit.jsonl")
        self._ns_hash = ns.ns_hash()
        self._ns_digest = ns.digest_hex()
        self.emit("session_meta", ns_tuple=ns.as_dict(),
                  node=socket.gethostname(), **meta)

    def emit(self, kind, request_id=None, **payload):
        rec = {"schema_version": SCHEMA_VERSION, "seq": self.seq,
               "process_id": self.process_id, "event_id": uuid.uuid4().hex,
               "wall_ts": time.time(), "ns_hash": self._ns_hash,
               "ns_digest": self._ns_digest, "session": self.session,
               "kind": kind}
        if request_id is not None:
            rec["request_id"] = request_id
        rec.update(payload)
        try:
            with open(self.path, "a") as f:
                f.write(json.dumps(rec) + "\n")
                f.flush()
                os.fsync(f.fileno())
        except OSError as e:
            # LOUD, never swallowed (F11/ER4); collect-mode callers fail
            # health on self.failed.
            self.failed = f"audit write failed: {e}"
            print(f"!! AUDIT WRITE FAILED ({e}) — trail INCOMPLETE from "
                  f"seq={self.seq}; "
                  f"{'collection is INVALID' if self.collect else 'non-collect mode'}",
                  flush=True)
        self.seq += 1

    # ---- typed emitters (one place defines the payload shapes) -------------
    def request(self, request_id, prompt_len, prompt_sha, prefix_hashes,
                workload=None):
        self.emit("request", request_id, prompt_len=prompt_len,
                  prompt_sha=prompt_sha, prefix_hashes=list(prefix_hashes),
                  workload=workload)

    def lookup(self, request_id, probes, resume_pos, resume_phash,
               trim=None):
        """trim (KV plan B.2, schema-additive): the trim-on-load record —
        {d_star, d, owner, anchor_phash, anchor_P, bytes, tps, save_ms,
        load_ms, gate_ok, outcome: served|gated_out|trim_confirm_fail|
        load_fail} or null on non-trimmable/no-candidate requests."""
        self.emit("lookup", request_id, probes=probes, resume_pos=resume_pos,
                  resume_phash=(str(resume_phash)
                                if resume_phash is not None else None),
                  trim=trim)

    def decision(self, request_id, ctx, strategy, placements,
                 anchor_count=None, fork=None):
        self.emit("decision", request_id, ctx=ctx, strategy=strategy,
                  placements=sorted(placements), anchor_count=anchor_count,
                  fork=fork)

    def lifecycle(self, request_id, action, phash, pos=None, ckpt_kind=None,
                  blob_id=None, nbytes=None, chain_id=None, signals=None,
                  by_phash=None, esn=None):
        assert action in ("stored", "deduped", "superseded", "evicted",
                          "rejected_write"), action
        # esn (optional, OBSERVATIONAL): per-band summary of the 4-band
        # reservoir key the proxy already computed for this write —
        # {c1..c4: {nnz, norm, top: [[dim, val], ...]}}. Feature data for
        # the online learner; never a serving signal; the validator does
        # not reconstruct it (the key is model-state-derived).
        self.emit("lifecycle", request_id, action=action,
                  phash=(str(phash) if phash is not None else None), pos=pos,
                  ckpt_kind=ckpt_kind, blob_id=blob_id, bytes=nbytes,
                  chain_id=chain_id, signals=signals,
                  by_phash=(str(by_phash) if by_phash is not None else None),
                  esn=esn, predicted_ev=None, ev_model_version=None)

    def outcome(self, request_id, **fields):
        self.emit("outcome", request_id, **fields)

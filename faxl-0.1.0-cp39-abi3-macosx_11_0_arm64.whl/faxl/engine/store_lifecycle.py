# VENDORED FROM faxl-core/python/engine/store_lifecycle.py — DO NOT EDIT HERE.
# Edit faxl-core and run tools/sync_engine.py --sync mac; the gate runs --check.
"""store_lifecycle.py — the store's lifecycle as a PURE event API (phase 0).

Plan v1.5 round-3 change 2: one state machine owns what lives in the store;
the proxy (Index) and the simulator both DRIVE it, so simulated storage can
be differentially tested against production event-by-event.

    write(CheckpointRecord) -> LifecycleEffects
    hit(phash, t)                      # LRU clock touch
    supersede(chain_id)                # kill a chain's live fork blob
    evict_to(cap_bytes)                # shrink adaptive+divergence LRU pools
    restart()                          # drop volatile state, keep persisted
    corrupt(phash)                     # blob unreadable -> verified miss

Persisted state (survives restart): `records` (phash -> CheckpointRecord),
`chains` (chain_id -> live fork phash). Volatile: LRU clocks, observed max
blob. Retention by kind: grid = permanent under the per-kind caps; adaptive
(policy-placed) = byte-capped LRU; extension-fork = superseded per chain;
divergence-fork = LRU under the fork byte cap. Under the STORE-WIDE cap
(evict_scored) nothing is permanent — grid included (AM directive
2026-09-01, after a full store refused new writes and froze out live
traffic): oldest unpopular blobs go first, scored by time-since-last-hit
over popularity. No filesystem access here — callers translate effects
into blob writes/deletes.

Usage durability: append_usage/load_usage give callers an append-only
`{phash, ts}` JSONL (flushed+fsynced per line) so hit counts and last-hit
times survive restarts; a blob with no recorded hit scores by its
written_at (in production: the blob file's mtime).
"""
import json
import os
from dataclasses import dataclass, field
from typing import Optional


def append_usage(path, phash, ts):
    """Durably append one hit event (flush+fsync — a failure at request N
    must not silently lose requests 1..N-1's history)."""
    with open(path, "a") as f:
        f.write(json.dumps({"phash": str(phash), "ts": ts}) + "\n")
        f.flush()
        os.fsync(f.fileno())


def load_usage(path):
    """Replay the usage log -> {phash(str): [hits, last_hit_ts]}. Tolerates a
    torn final line (crash mid-append)."""
    out = {}
    if not os.path.exists(path):
        return out
    with open(path) as f:
        for line in f:
            try:
                d = json.loads(line)
                p = str(d["phash"])
            except (ValueError, KeyError):
                continue  # torn tail line
            hits, last = out.get(p, (0, 0.0))
            # a compacted summary line carries its collapsed count as `hits`
            out[p] = [hits + int(d.get("hits", 1)),
                      max(last, float(d["ts"]))]
    return out


def compact_usage(path, usage):
    """Rewrite the log as one summary line per phash (boot-time compaction —
    the replay result is equivalent; hits collapse into a `hits` field)."""
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        for p, (hits, ts) in usage.items():
            f.write(json.dumps({"phash": p, "ts": ts, "hits": hits}) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


@dataclass(frozen=True)
class CheckpointRecord:
    phash: int
    pos: int
    bytes: int
    keyed: bool
    kind: str                    # 'grid' | 'adaptive' | 'extension-fork' | 'divergence-fork'
    chain_id: Optional[int] = None
    written_at: float = 0.0
    blob_ref: Optional[str] = None
    namespace: str = "default"


@dataclass
class LifecycleEffects:
    """What the caller must do to the physical store."""
    deduped: bool = False
    stored: bool = False
    superseded: Optional[int] = None      # phash whose blob dies
    evicted: list = field(default_factory=list)   # phashes whose blobs die


KINDS = ("grid", "adaptive", "extension-fork", "divergence-fork", "anchor")
# "anchor" (KV plan B.4): a TRIMMABLE chain's live tail anchor — same
# per-chain supersession semantics as extension-fork (one live blob per
# chain), but written by the placement strategy, not the fork gate.


class StoreLifecycle:
    def __init__(self, fork_cap_bytes=20e9, adaptive_cap_bytes=None):
        # persisted
        self.records = {}      # phash -> CheckpointRecord
        self.chains = {}       # chain_id -> live extension-fork phash
        # volatile (production rebuilds hit_counts/last_hit_ts from the
        # durable usage log at boot — see append_usage/load_usage)
        self.clock = 0
        self.last_touch = {}   # phash -> volatile LRU clock
        self.hit_counts = {}   # phash -> times reused (blob++)
        self.last_hit_ts = {}  # phash -> wall time of last reuse
        self.observed_max = 0
        self.fork_cap_bytes = fork_cap_bytes
        self.adaptive_cap_bytes = adaptive_cap_bytes

    # ---- queries -----------------------------------------------------------
    def live_bytes(self, kind=None):
        return sum(r.bytes for r in self.records.values()
                   if kind is None or r.kind == kind)

    def known_positions(self):
        return sorted({r.pos for r in self.records.values()}, reverse=True)

    def has(self, phash):
        return phash in self.records

    # ---- events ------------------------------------------------------------
    def _touch(self, phash):
        self.clock += 1
        self.last_touch[phash] = self.clock

    def write(self, rec: CheckpointRecord) -> LifecycleEffects:
        assert rec.kind in KINDS, rec.kind
        eff = LifecycleEffects()
        if rec.phash in self.records:
            eff.deduped = True
            return eff
        self.records[rec.phash] = rec
        self._touch(rec.phash)
        self.observed_max = max(self.observed_max, rec.bytes)
        eff.stored = True
        if rec.kind in ("extension-fork", "anchor"):
            # per-chain supersession: the chain's previous live blob dies
            old = self.chains.get(rec.chain_id)
            if old is not None and old != rec.phash and old in self.records:
                del self.records[old]
                eff.superseded = old
            self.chains[rec.chain_id] = rec.phash
        elif rec.kind == "divergence-fork":
            eff.evicted = self._evict_lru("divergence-fork",
                                          self.fork_cap_bytes)
        elif rec.kind == "adaptive" and self.adaptive_cap_bytes is not None:
            eff.evicted = self._evict_lru("adaptive", self.adaptive_cap_bytes)
        return eff

    def hit(self, phash, t=None):
        if phash in self.records:
            self._touch(phash)
            self.hit_counts[phash] = self.hit_counts.get(phash, 0) + 1
            if t is not None:
                self.last_hit_ts[phash] = t

    def evict_scored(self, cap_bytes, now, protect=frozenset()):
        """STORE-WIDE cap (AM 2026-09-01): when total bytes exceed cap_bytes,
        evict by score = time-since-last-hit / (1 + hits) — the oldest
        unpopular blobs go first; a frequently-hit old blob outlives a
        never-hit recent one. NOTHING is permanent here, grid included: a
        full store must admit new traffic, never refuse writes (the failure
        this replaces starved live hourly traffic behind stale blobs).
        `protect` (e.g. the blob just written and the one just resumed) is
        never evicted. A blob with no recorded hit scores by written_at."""
        out = []
        def score(p):
            r = self.records[p]
            last = self.last_hit_ts.get(p, r.written_at)
            return (now - last) / (1.0 + self.hit_counts.get(p, 0))
        pool = lambda: [p for p in self.records if p not in protect]  # noqa: E731
        while self.live_bytes() > cap_bytes and pool():
            victim = max(pool(), key=score)
            r = self.records.pop(victim)
            if r.kind == "extension-fork" or r.kind == "anchor":
                for cid, ph in list(self.chains.items()):
                    if ph == victim:
                        del self.chains[cid]
            out.append(victim)
        return out

    def supersede(self, chain_id):
        old = self.chains.pop(chain_id, None)
        if old is not None and old in self.records:
            del self.records[old]
            return old
        return None

    def evict_to(self, cap_bytes):
        """Shrink the EVICTABLE pools (adaptive + divergence-fork LRU) until
        their combined bytes fit cap_bytes. Grid is permanent; live
        extension-forks die only by supersession."""
        evictable = ("adaptive", "divergence-fork")
        out = []
        pool = lambda: [p for p, r in self.records.items() if r.kind in evictable]  # noqa: E731
        while sum(self.records[p].bytes for p in pool()) > cap_bytes and pool():
            victim = min(pool(), key=lambda p: self.last_touch.get(p, 0))
            del self.records[victim]
            out.append(victim)
        return out

    def _evict_lru(self, kind, cap_bytes):
        out = []
        pool = lambda: [p for p, r in self.records.items() if r.kind == kind]  # noqa: E731
        while sum(self.records[p].bytes for p in pool()) > cap_bytes and pool():
            victim = min(pool(), key=lambda p: self.last_touch.get(p, 0))
            del self.records[victim]
            out.append(victim)
        return out

    def restart(self):
        """Volatile state dies; persisted records + chain table survive
        (production rebuilds them from meta)."""
        self.clock = 0
        self.last_touch = {}
        self.hit_counts = {}
        self.last_hit_ts = {}
        self.observed_max = 0

    def corrupt(self, phash):
        """A blob found unreadable is a verified miss: the record dies so the
        lookup stops offering it."""
        r = self.records.pop(phash, None)
        if r is not None and r.kind == "extension-fork":
            for cid, ph in list(self.chains.items()):
                if ph == phash:
                    del self.chains[cid]
        return r is not None


@dataclass
class ScheduleContext:
    """Everything a placement policy may see, constructed AFTER hash + lookup
    + fork discovery, strictly pre-arrival (plan standing design). The write
    path consumes policy.decide(ctx) -> [Placement]."""
    prompt_len: int
    resume_pos: int
    d_star: int                 # 0 = nothing shared
    fork_kind: Optional[str]    # 'extension' | 'divergence' | None
    kappa: float
    chain_ewma_inc: Optional[float]
    live_bytes: int
    observed_max: int
    arrivals_at_dstar: int
    model: str
    # prefix hash at D* — lets a strategy consult the hash++ counting index
    # for continuation evidence without re-deriving it. None when no shared
    # prefix was found (a first arrival).
    d_star_hash: Optional[int] = None


@dataclass(frozen=True)
class Placement:
    pos: int
    keyed: bool


# ---------------------------------------------------------------------------
# PLACEMENT STRATEGIES
#
# A strategy answers ONE question: given this arrival, at which prefix
# positions should a checkpoint be written? Correctness never depends on the
# answer — a hit still requires an exact prefix-hash match plus a
# token-for-token confirm — so a strategy can only trade cost against reuse.
#
# Selected by name via FAXL_STRATEGY (see STRATEGIES below). Adding a new one
# means writing a class with `decide(ctx) -> [Placement]` and registering it;
# nothing else in the write path changes.
#
# Measured on the recorded traces (net cost, frozen M3 rates,
# docs/schedule-opt/crr-variants.md and tail-anchor.json):
#
#   strategy        journal    xlat     endurance   note
#   tail_anchor     2.824      0.181    22.701      DEFAULT; +25.7%/+37.8%
#   grid            3.801      0.181    36.513      previous default
#   (clairvoyant)   2.478      0.571    22.997      labelled ceiling, not causal
#
# Status: those numbers are DESCRIPTIVE (simulation on 3 recorded traces;
# the held-out evaluation is spent). tail_anchor is default because it wins
# on both continuation workloads and is never worse than grid on the
# one-shot workload; it is a candidate for the >=20-session evaluation, not
# a proven ship result.
# ---------------------------------------------------------------------------


class GridPolicy:
    """GEOMETRIC GRID — the original strategy (default until 2026-08-16).

    Checkpoints at geometrically growing depths (250, 750, 1750, 3750, ...):
    dense near the reused start, sparse in the changing tail, so storage
    follows reuse probability. Deterministic — the same positions every run,
    which is what lets a query's ladder align with stored checkpoints.

    Known limitation (the reason it is no longer the default): its positions
    are indexed by PROMPT LENGTH, so they almost never coincide with a
    conversation's TURN BOUNDARIES. A continuing turn resumes at the last
    grid point below its true boundary and re-pays the remainder — the
    endurance sawtooth. It remains the right choice for traffic with no
    continuation structure, and as the fallback when a strategy must be
    provably identical to the legacy write path.
    """

    name = "grid"

    def __init__(self, base=250, ratio=2.0, gate_tokens=64):
        self.base, self.ratio, self.gate = base, ratio, gate_tokens

    def decide(self, ctx: ScheduleContext):
        from faxl.engine.ckpt_schedule import ckpt_positions
        return [Placement(p, keyed=True)
                for p in ckpt_positions(ctx.prompt_len, self.base, self.ratio)
                if p > ctx.resume_pos and p >= self.gate]


class TailAnchorPolicy:
    """TAIL-ANCHOR — the default strategy.

    Writes ONE checkpoint at `prompt_len - margin`: the position where the
    NEXT turn of this conversation will resume. Turn N+1's prompt is turn
    N's prompt plus the reply plus the new message, so the deepest prefix
    they share ends where turn N stopped.

    MARGIN is a CORRECTNESS CONSTANT, not a tuning knob. Chat templates
    append a generation suffix that is re-rendered next turn, so the true
    shared boundary sits a few tokens back from the prompt end. Measured on
    the recorded traces it is exactly 3; margin 2 misses by one token and
    the checkpoint is NEVER hit (endurance skip collapses 0.9521 -> 0.09).
    Margins above 3 still work and merely leave a little prefill unclaimed.
    Do not lower it below 3 without re-measuring against real templates.

    `with_grid` keeps the geometric ladder alongside the anchor. Measured:
    better on journal (short, many chains), worse on endurance (one long
    chain, where the extra blobs stop paying for themselves).

    `min_arrivals` gates the anchor on continuation evidence: write it only
    when this chain's prefix has been seen at least N times before (the
    hash++ count). On one-shot traffic the anchor would otherwise write a
    checkpoint that is never reused — measured ~3x worse than grid on the
    translation workload. Requires a counting index (`count_of`); with no
    counter available the gate is skipped.
    """

    name = "tail_anchor"

    def __init__(self, margin=3, with_grid=False, min_arrivals=0,
                 base=250, ratio=2.0, gate_tokens=64, count_of=None):
        if margin < 3:
            raise ValueError(
                f"tail-anchor margin={margin} is below the measured "
                "correctness floor of 3 tokens; a checkpoint one token off "
                "the boundary is never hit (see store_lifecycle docstring)")
        self.margin = margin
        self.with_grid = with_grid
        self.min_arrivals = min_arrivals
        self.base, self.ratio, self.gate = base, ratio, gate_tokens
        self.count_of = count_of      # callable(phash) -> prior arrivals

    def decide(self, ctx: ScheduleContext):
        from faxl.engine.ckpt_schedule import ckpt_positions
        out = []
        if self.with_grid:
            out += [p for p in ckpt_positions(ctx.prompt_len, self.base,
                                              self.ratio)
                    if p > ctx.resume_pos and p >= self.gate]
        anchor = ctx.prompt_len - self.margin
        if ctx.resume_pos < anchor < ctx.prompt_len and self._continuing(ctx):
            out.append(anchor)
        return [Placement(p, keyed=True) for p in sorted(set(out))]

    def _continuing(self, ctx):
        """Has this chain continued before? Uses the hash++ count when a
        counting index is wired; otherwise treats every arrival as eligible
        (the gate exists to suppress one-shot traffic, and with no counter
        we cannot tell one-shot from continuation)."""
        if not self.min_arrivals:
            return True
        if self.count_of is None:
            return True
        return self.count_of(ctx) >= self.min_arrivals


class NoWritePolicy:
    """Write nothing. The control arm (cache reads still serve); useful for
    measuring what the cache is worth on a given workload."""

    name = "none"

    def decide(self, ctx: ScheduleContext):
        return []


STRATEGIES = {
    "tail_anchor": TailAnchorPolicy,   # default
    "grid": GridPolicy,
    "none": NoWritePolicy,
}

DEFAULT_STRATEGY = "tail_anchor"


def make_policy(name=None, **kw):
    """Build a placement strategy by name (FAXL_STRATEGY). Unknown names are
    a hard error listing what exists — a typo must never silently fall back
    to a different placement policy."""
    name = (name or DEFAULT_STRATEGY).strip().lower()
    if name not in STRATEGIES:
        raise ValueError(f"unknown placement strategy {name!r}; "
                         f"available: {sorted(STRATEGIES)}")
    return STRATEGIES[name](**kw)

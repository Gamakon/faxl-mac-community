# Vendored engine module (trim_lookup.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""trim_lookup.py — KV plan Phase B: trim-on-load candidate machinery.

ONE implementation consumed by three drivers (the proxy's serving path,
the simulator's trimmable mode, and the M0 replay validator) so the
reconstruction can never drift from production.

A TRIMMABLE (pure-KV) chain keeps ONE live tail anchor at depth P; any
resume depth d <= P is served by loading the anchor and
trim_prompt_cache-ing back P−d tokens. Pieces:

- AnchorRegistry: chain identity for streams (extension turns inherit
  the matched stream's chain; anything else opens a new chain) + the
  per-chain live anchor (phash, P, stream). Recording a new anchor
  returns the superseded ancestor's phash (caller deletes its blob —
  index row first, per the shipped supersession ordering). Optional
  JSON persistence (proxy restart; C2 drill).
- resolve_candidate: divergence-case candidate finding [review F1] —
  attribution (pos_hashes[d][hash] -> owning stream) -> chain -> live
  anchor with P >= d. Advisory ONLY: the caller must token-confirm the
  first d tokens against the anchor's token file before any resume.
- economic_gate [review F5]: trim-resume only when predicted prefill
  saving beats predicted load cost, d / tps > load_fit(bytes(P)); both
  sides measured models. Returns raw terms for the audit trail.

Trim depth rule [review F2]: d = min(D_raw, len(ids) − 1) — trimming to
len(ids) would double-feed the seed token. The caller owns that cap;
this module asserts d >= 1 only.
"""
import json
import os


class AnchorRegistry:
    def __init__(self, state_path=None):
        self.state_path = state_path
        self.stream_cid = {}     # stream full-hash (int) -> chain id
        self.anchors = {}        # chain id -> {"phash","P","stream"}
        self.next_cid = 0
        self._load()

    def _load(self):
        if not self.state_path or not os.path.exists(self.state_path):
            return
        try:
            st = json.load(open(self.state_path))
            self.stream_cid = {int(k): v
                               for k, v in st.get("stream_cid", {}).items()}
            self.anchors = {int(k): v
                            for k, v in st.get("anchors", {}).items()}
            self.next_cid = st.get("next_cid", 0)
        except Exception as e:
            print(f"!! anchor state unreadable ({e}) — fresh registry",
                  flush=True)

    def _save(self):
        if not self.state_path:
            return
        tmp = self.state_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"stream_cid": self.stream_cid,
                       "anchors": self.anchors,
                       "next_cid": self.next_cid}, f)
        os.replace(tmp, self.state_path)

    def observe_stream(self, full_hash, matched_stream=None):
        """Assign this arrival's stream to a chain: an EXTENSION of a
        known stream joins that stream's chain; everything else opens a
        new one. Idempotent per stream. Returns the chain id."""
        full_hash = int(full_hash)
        if full_hash in self.stream_cid:
            return self.stream_cid[full_hash]
        if matched_stream is not None \
                and int(matched_stream) in self.stream_cid:
            cid = self.stream_cid[int(matched_stream)]
        else:
            cid = self.next_cid
            self.next_cid += 1
        self.stream_cid[full_hash] = cid
        self._save()
        return cid

    def record_anchor(self, cid, phash, P, stream_full):
        """New live anchor for a chain; returns the SUPERSEDED previous
        anchor phash (or None). Caller deletes its blob AFTER re-pointing
        the index (shipped ordering)."""
        old = self.anchors.get(cid)
        self.anchors[cid] = {"phash": str(phash), "P": int(P),
                             "stream": int(stream_full)}
        self._save()
        if old and old["phash"] != str(phash):
            return old["phash"]
        return None

    def candidate_for_stream(self, owner_full_hash):
        """The live anchor of the chain owning this stream, or None."""
        cid = self.stream_cid.get(int(owner_full_hash))
        if cid is None:
            return None
        return self.anchors.get(cid)


def resolve_candidate(registry, pos_hashes, qhash, d):
    """Divergence-case candidate: the query shares a prefix to depth d
    with SOME earlier stream (attribution index); that stream's chain's
    live anchor serves any resume <= its P. Returns the anchor dict
    (with 'owner' added) iff its P >= d, else None. ADVISORY: caller
    must prefix-confirm ids[:d] against the anchor's token file."""
    if d < 1:
        return None
    owner = pos_hashes.get(d, {}).get(qhash[d])
    if owner is None:
        return None
    anchor = registry.candidate_for_stream(owner)
    if anchor is None or anchor["P"] < d:
        return None
    return dict(anchor, owner=int(owner))


def economic_gate(d, prefill_tps, blob_bytes, load_intercept_ms,
                  load_slope_ms_per_gb):
    """Trim-resume pays iff predicted prefill seconds saved exceed the
    predicted anchor load wall. Returns (ok, save_ms, load_ms) — raw
    terms recorded in the audit trail (#56 for gated-out candidates)."""
    save_ms = d / max(prefill_tps, 1e-9) * 1000.0
    load_ms = load_intercept_ms + (blob_bytes / 1e9) * load_slope_ms_per_gb
    return save_ms > load_ms, save_ms, load_ms

# Vendored engine module (faxl_panel_voice.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Voice2Text, the page: `/console/apps/voice2text` (docs/plans/voice2text.md,
chunk 2 of 3; the server side is faxl_voice).

WHAT A PERSON SEES, in the panel's own shell (stylesheet, top bar, drawers and
the `window.faxl` runtime come from faxl_panel, never copied):

  launch     "Launch Voice2Text". It reads GET /api/voice/status.
  download   when the speech model is not on this machine: the catalogue's
             choices with label, languages and download size ("size unknown"
             where the catalogue records none -- that choice cannot be
             downloaded, because the fit check refuses rather than guesses),
             and the requirements BEFORE anything downloads: microphone and
             browser permission, the download size, memory on top of what is
             running, Apple Silicon or NVIDIA. Download -> POST
             /api/voice/download; progress from /api/voice/download/status
             (measured bytes and %); the server's errors verbatim.
  record     when the speech model is installed and the repair model is
             serving: a status light (red steady = ready, green blinking =
             recording, grey = microphone not granted), one big mic button,
             hands-free after that. Beside it "Save recording", off by
             default: ticking it posts /api/voice/session/save for the
             session (and again for each new session while it stays
             ticked); once a chunk is saved the folder and Download links
             for audio.wav, raw.txt and final.txt appear.

THE AUDIO PATH (all in the page's script, VOICE_JS):
  getUserMedia({audio: true}) -> AudioContext -> ScriptProcessorNode ->
  downsample to 16 kHz mono (box average) -> 30 ms frames -> VAD (RMS energy
  against an adaptive noise floor; a chunk ends after 700 ms of silence or at
  15 s; under 300 ms of speech is dropped) -> little-endian int16 ->
  POST /api/voice/transcribe?session=&language=&repair=0 as
  application/octet-stream (split at faxl_voice.MAX_PCM_BYTES) -> the raw
  text appears greyed -> POST /api/voice/repair -> the chunk's corrected
  text, or -- when the correction failed -- its raw text in the normal
  colour with a dotted underline and the reason as its title (never struck
  through, never hidden).

  In parallel a MediaRecorder on the same stream (audio/webm;codecs=opus,
  else audio/mp4 -- the only one WebKit has -- else audio/ogg) uploads 5 s
  pieces in order to /api/voice/session/<id>/backup; Stop calls .../finalize
  and the whole recording's transcript is shown as the authoritative raw
  text, with the live path's gap, if any, said in words. A watchdog rebuilds
  the capture when no audio frame arrives for 2 s (amber light), and the
  counters show recorded / heard live / transcribed live / backup seconds.

WHY ScriptProcessorNode AND NOT AudioWorklet. addModule() needs a module
URL. The console's HUMAN_CSP is `default-src 'none'; script-src
'unsafe-inline'` with no worker-src, and a worklet module is fetched under
script-src: a same-origin file would need a route and 'self', a blob: URL
would need blob:. Neither is allowed, by design, so the deprecated-but-
universal ScriptProcessorNode does the capture on the main thread. At 4,096
frames per callback it is ~85 ms of audio per call -- plenty of slack.

  render_voice(state, nonce=None) -> str     the human page
  voice_payload(serving_model, backend_name, config_dir) -> dict   ?format=json
  render_voice_agent(p, origin) -> str       agent-mode inner HTML
  render_voice_text(p, origin) -> str        ?format=text
"""

import html as _html
import os as _os

from faxl.engine import faxl_panel as _P
from faxl.engine import faxl_voice as _V

URL = "/console/apps/voice2text"
NAME = "Voice to text"
WHAT = "Talk; get clean text. Private, on this machine."


def _e(s):
    return _html.escape(str(s), quote=True)


def _lang_options():
    return "".join('<option value="%s"%s>%s</option>'
                   % (_e(c), ' selected' if c == "en" else "", _e(n))
                   for c, n in _V.LANGUAGES)


def _home_short(path):
    """`path` with the home directory written as ~, and a trailing /."""
    home = _os.path.expanduser("~")
    if path == home or path.startswith(home + _os.sep):
        path = "~" + path[len(home):]
    return path.rstrip("/") + "/"


def render_voice(state, nonce=None):
    """The whole page as one string. Every live value is filled by the
    script from /api/voice/status and /api/state."""
    cfg = {"max_pcm_bytes": _V.MAX_PCM_BYTES, "sample_rate": _V.SAMPLE_RATE,
           "default_model": _V.DEFAULT_MODEL_ID,
           "voice_dir": _home_short(_V.voice_dir()),
           "vocabulary": _V.DEFAULT_VOCABULARY}
    blob = ('<script type="application/json" id="faxl-voice">'
            + _P.state_json(cfg) + '</script>')
    main = (VOICE_HTML.replace("@@LANGS@@", _lang_options())
            .replace("@@VOCABMAX@@", str(_V.MAX_PROMPT_CHARS)))
    page = _P.render_shell(state, title="faxl — Voice2Text",
                           main_html=main + blob, page_css=VOICE_CSS,
                           page_js=VOICE_JS, here="voice", nonce=nonce,
                           app_id="app-voice")
    # The top bar's "agent view" is this page's own agent view.
    return page.replace('href="/console?mode=agent"',
                        'href="%s?mode=agent"' % URL, 1)


def voice_payload(serving_model, backend_name, config_dir):
    """The ?format=json body: the status the page reads, the download job,
    the limits and the calls an agent makes instead of pressing buttons."""
    try:
        st = _V.status(None, serving_model=serving_model,
                       backend_name=backend_name)
        err = None
    except Exception as exc:  # noqa: BLE001 -- reported in the payload
        st, err = None, f"{type(exc).__name__}: {exc}"
    dl = _V.download_status(_os.path.join(_os.path.expanduser(config_dir),
                                          "voice"))
    return {
        "app": "voice2text", "name": NAME, "what": WHAT, "url": URL,
        "status": st, "status_error": err, "download": dl,
        "limits": {"max_pcm_bytes": _V.MAX_PCM_BYTES,
                   "sample_rate": _V.SAMPLE_RATE,
                   "pcm": "little-endian int16, mono",
                   "languages": _V.LANGUAGE_CODES},
        "endpoints": [
            {"method": "GET", "path": "/api/voice/status",
             "what": "installed? sizes, free disk, does it fit"},
            {"method": "POST", "path": "/api/voice/download",
             "body": '{"model_id": "%s"}' % _V.DEFAULT_MODEL_ID,
             "what": "start the download (this machine only)"},
            {"method": "GET", "path": "/api/voice/download/status",
             "what": "measured bytes done / total"},
            {"method": "POST",
             "path": "/api/voice/transcribe?session=<id>&language=<code>",
             "body": "raw PCM, application/octet-stream",
             "what": "speech to text, then repair (repair=0 skips it)"},
            {"method": "POST", "path": "/api/voice/repair",
             "body": '{"session": "<id>", "raw": "<text>"}',
             "what": "repair one raw chunk in a session"},
            {"method": "POST",
             "path": "/api/voice/session/<id>/backup?seq=<n>&part=<p>",
             "body": "one MediaRecorder piece, audio/webm|audio/mp4|audio/ogg",
             "what": "append the backup recording, in order (this machine only)"},
            {"method": "POST", "path": "/api/voice/session/<id>/finalize",
             "body": '{"language": "en", "prompt": "<names and terms>"}',
             "what": "decode the backup (ffmpeg) and transcribe the whole "
                     "recording: {full_text, audio_s}"},
            {"method": "POST", "path": "/api/voice/session/reset",
             "body": '{"session": "<id>"}', "what": "forget a session"},
            {"method": "POST", "path": "/api/voice/session/save",
             "body": '{"session": "<id>", "save": true}',
             "what": "save this session's audio and transcripts under "
                     "$FAXL_HOME/voice (off by default; this machine only)"},
            {"method": "GET", "path": "/api/voice/session/<id>/files",
             "what": "the saved files (this machine only)"},
            {"method": "GET",
             "path": "/api/voice/session/<id>/download?file=audio.wav",
             "what": "one saved file: audio.wav, raw.txt, final.txt or "
                     "meta.json (this machine only)"},
        ],
    }


def _curl(origin):
    o = origin.rstrip("/")
    return (
        f"curl -sS {o}/api/voice/status\n"
        f"curl -sS -X POST {o}/api/voice/download "
        f"-H 'Content-Type: application/json' "
        f"-d '{{\"model_id\": \"{_V.DEFAULT_MODEL_ID}\"}}'\n"
        f"curl -sS {o}/api/voice/download/status\n"
        "# any audio -> 16 kHz mono little-endian int16, at most "
        f"{_V.MAX_PCM_BYTES} bytes (60 s)\n"
        "ffmpeg -i speech.wav -f s16le -ac 1 -ar 16000 chunk.pcm\n"
        f"curl -sS -X POST '{o}/api/voice/transcribe?session=s1&language=en' "
        "-H 'Content-Type: application/octet-stream' --data-binary @chunk.pcm\n"
        f"curl -sS -X POST {o}/api/voice/session/reset "
        "-H 'Content-Type: application/json' -d '{\"session\": \"s1\"}'")


def _summary_lines(p):
    st = p.get("status") or {}
    sm = st.get("speech_model") or {}
    rm = st.get("repair_model") or {}
    fit = st.get("fit") or {}
    lines = []
    if p.get("status_error"):
        lines.append(("status", "could not be read: " + p["status_error"]))
    if st:
        lines += [
            ("speech model", "%s — %s" % (sm.get("id"), "installed"
                                          if sm.get("installed")
                                          else "not downloaded")),
            ("speech model size", "%s (%s)" % (
                "size unknown" if sm.get("bytes") is None
                else "%d bytes" % sm["bytes"], sm.get("bytes_basis"))),
            ("repair model", str(rm.get("id") or "none configured")),
            ("fits", "yes" if fit.get("ok") else
             "no: " + "; ".join(fit.get("reasons") or [])),
            ("requirements", "; ".join(st.get("requirements") or [])),
        ]
    dl = p.get("download") or {}
    lines.append(("download job", str(dl.get("state"))))
    return lines


def render_voice_agent(p, origin):
    """Agent mode: the same facts as the JSON, and the calls behind the
    page's buttons."""
    rows = "".join(f"<dt>{_e(k)}</dt><dd>{_e(v)}</dd>"
                   for k, v in _summary_lines(p))
    langs = ", ".join(f"{c} ({n})" for c, n in _V.LANGUAGES)
    return (f"<p>{_e(WHAT)} The page records from the microphone, cuts the "
            f"audio at pauses and posts each piece as raw PCM; an agent "
            f"posts the same PCM.</p><dl>{rows}</dl>"
            f"<p>languages: {_e(langs)}</p>"
            f"<h2>calls</h2><pre>{_e(_curl(origin))}</pre>"
            f'<p><a href="{URL}?format=json">{URL}?format=json</a></p>')


def render_voice_text(p, origin):
    lines = [f"{NAME}\t{URL}", WHAT, ""]
    lines += [f"{k}\t{v}" for k, v in _summary_lines(p)]
    lines += ["", _curl(origin)]
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------
# Markup. Static; the script fills every value.
# --------------------------------------------------------------------------
_MIC_SVG = ('<svg viewBox="0 0 24 24" width="40" height="40" aria-hidden="true" '
            'fill="none" stroke="currentColor" stroke-width="1.7" '
            'stroke-linecap="round" stroke-linejoin="round">'
            '<rect x="9" y="3" width="6" height="11" rx="3"/>'
            '<path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/></svg>')

VOICE_HTML = r"""<main id="v-main">
<section class="card" id="v-head" aria-labelledby="v-h">
  <div class="row"><h2 id="v-h" class="v-title">Voice2Text</h2>
    <span class="muted">Talk; get clean text. Private, on this machine.</span>
    <span class="spacer"></span>
    <label for="v-lang" class="muted">language</label>
    <select id="v-lang">@@LANGS@@</select></div>
</section>
<div id="v-errors" aria-live="assertive"></div>
<section class="card" id="v-launch" aria-labelledby="v-launch-h">
  <h3 id="v-launch-h" class="card-h">Start</h3>
  <p class="v-lead">Speech is cut at your pauses, turned into text by a speech model on this
  machine, then corrected by the model faxl is serving. Nothing leaves this computer.</p>
  <p class="row"><button type="button" class="btn v-big" id="v-launch-btn">Launch Voice2Text</button>
  <span class="muted" id="v-launch-msg" role="status"></span></p>
</section>
<section class="card" id="v-dl" aria-labelledby="v-dl-h" hidden>
  <h3 id="v-dl-h" class="card-h">Download the speech model</h3>
  <p>The speech model is not on this machine yet. Read this before downloading:</p>
  <ul id="v-reqs" class="v-reqs"></ul>
  <fieldset class="v-models"><legend>Choose a speech model</legend><div id="v-models"></div></fieldset>
  <ul id="v-fit" class="v-fit" hidden></ul>
  <p class="row"><button type="button" class="btn v-big" id="v-dl-btn" disabled>Download</button>
  <span class="muted" id="v-dl-note"></span></p>
  <div id="v-dl-prog" hidden>
    <div class="meter"><div class="bar" aria-hidden="true"><i id="v-dl-bar"></i></div>
    <span class="mono" id="v-dl-pct">&#8212;</span></div>
    <p class="mono" id="v-dl-text" role="status" aria-live="polite"></p>
  </div>
</section>
<section class="card" id="v-wait" hidden>
  <h3 class="card-h">Waiting for the repair model</h3>
  <p id="v-wait-msg" role="status"></p>
</section>
<section class="card" id="v-rec" aria-labelledby="v-rec-h" hidden>
  <h3 id="v-rec-h" class="card-h">Dictate</h3>
  <p class="v-notice" id="v-lib" hidden></p>
  <p class="v-notice" id="v-ffmpeg" hidden></p>
  <p class="v-notice" id="v-backup-note" hidden></p>
  <div class="v-deck">
    <button type="button" class="v-mic" id="v-mic" aria-pressed="false" aria-label="start recording">""" + _MIC_SVG + r"""</button>
    <div class="v-state">
      <p class="row"><span class="v-light nomic" id="v-light" aria-hidden="true"></span>
      <span id="v-light-text" role="status">microphone not granted yet — press the mic</span></p>
      <p class="muted" id="v-hint">Press once and talk. Pauses send what you said; press again to stop.</p>
      <p class="muted mono" id="v-stats"></p>
      <p class="mono" id="v-counters" role="status"></p>
      <p class="muted mono" id="v-backup-type"></p>
      <p class="v-vocab"><label for="v-vocab">names and terms</label>
      <input type="text" id="v-vocab" maxlength="@@VOCABMAX@@" spellcheck="false" aria-describedby="v-vocab-note">
      <span class="muted" id="v-vocab-note">given to the speech model so it spells these right</span></p>
      <p class="v-save"><label><input type="checkbox" id="v-save"> Save recording</label>
      <span class="muted" id="v-save-note">Keeps the audio and both transcripts on this machine in ~/.faxl/voice/ — nothing leaves the machine.</span></p>
    </div>
  </div>
  <p class="row v-saved" id="v-saved" hidden><span class="muted">Saved in <span class="mono" id="v-save-dir"></span></span>
    <span class="spacer"></span><span id="v-save-links"></span></p>
  <div id="v-transcript" class="v-tx" role="log" aria-live="polite" aria-label="transcript" tabindex="0"><span id="v-frozen"></span><span id="v-pending"></span></div>
  <p class="row v-actions">
    <button type="button" class="btn" id="v-copy">Copy</button>
    <button type="button" class="btn btn-quiet" id="v-new">New session</button>
    <button type="button" class="btn btn-quiet" id="v-stop" disabled>Stop</button>
    <span class="spacer"></span><span class="muted mono" id="v-session"></span></p>
  <ol id="v-chunks" class="v-chunks" aria-label="chunks"></ol>
  <div class="v-full" id="v-full-wrap" hidden>
    <h4 class="card-h">Whole recording — authoritative raw text</h4>
    <p class="muted" id="v-full-state" role="status"></p>
    <p class="v-gap" id="v-gap" role="status"></p>
    <div id="v-full" class="v-tx" aria-label="whole-recording transcript" tabindex="0"></div>
    <p class="row v-actions"><button type="button" class="btn" id="v-copy-full">Copy whole-recording text</button></p>
  </div>
</section>
</main>"""

VOICE_CSS = r"""
#app-voice{display:grid;height:100vh;grid-template-rows:auto minmax(0,1fr);
  padding:0 var(--gap) var(--gap);min-width:0}
#v-main{min-height:0;overflow:auto;display:flex;flex-direction:column;gap:var(--gap);
  width:100%;max-width:900px;margin:var(--gap) auto 0}
.v-title{font:700 16px var(--sans)}
#v-head .row{flex-wrap:wrap}
.v-lead{margin:0 0 10px;font-size:14px;max-width:70ch}
.btn.v-big{height:32px;padding:0 16px;font-size:13.5px}
.v-reqs,.v-fit{margin:6px 0 12px;padding-left:20px;line-height:1.55}
.v-fit{color:var(--bad)}
.v-models{border:1px solid var(--line);border-radius:var(--radius);margin:0 0 10px;padding:6px 10px}
.v-models legend{font-weight:600;color:var(--ink-2);padding:0 4px}
.v-model{display:grid;grid-template-columns:auto 1fr auto;gap:2px 10px;align-items:baseline;
  padding:7px 2px;border-top:1px solid var(--line)}
.v-model:first-child{border-top:0}
.v-model .v-mname{font-weight:600}
.v-model .v-msize{font-family:var(--mono);white-space:nowrap}
.v-model .v-mmeta{grid-column:2/-1;font-size:12px;color:var(--ink-2)}
.v-model.off{opacity:.6}
#v-errors{display:flex;flex-direction:column;gap:6px}
#v-errors:empty{display:none}
.v-err{display:flex;gap:8px;align-items:flex-start;border:1px solid var(--bad);border-left-width:3px;
  border-radius:var(--radius);background:color-mix(in srgb,var(--bad) 8%,var(--panel));padding:7px 10px;font-size:13px}
.v-err span{flex:1;overflow-wrap:anywhere}
.v-notice{border:1px solid var(--warn);border-left-width:3px;border-radius:var(--radius);padding:7px 10px;margin:0 0 10px}
.v-deck{display:flex;align-items:center;gap:18px;margin:4px 0 12px}
.v-mic{flex:none;width:96px;height:96px;border-radius:50%;border:2px solid var(--accent);
  background:var(--accent);color:var(--accent-ink);cursor:pointer;display:flex;align-items:center;justify-content:center}
.v-mic:hover{background:var(--accent-hover)}
.v-mic[aria-pressed="true"]{background:var(--panel);color:var(--ok);border-color:var(--ok)}
.v-mic[disabled]{opacity:.45;cursor:default}
.v-state p{margin:0 0 4px}
.v-light{flex:none;display:inline-block;width:16px;height:16px;border-radius:50%;
  background:var(--ink-2);opacity:.45}
.v-light.ready{background:var(--bad);opacity:1}
.v-light.rec{background:var(--ok);opacity:1;animation:vblink 1s steps(1,end) infinite}
.v-light.amber{background:var(--warn);opacity:1}
@keyframes vblink{50%{opacity:.15}}
@media (prefers-reduced-motion:reduce){.v-light.rec{animation:none;opacity:1}}
#v-light-text{font-weight:600}
.v-tx{min-height:160px;max-height:46vh;overflow:auto;padding:12px 14px;border:1px solid var(--line-2);
  border-radius:var(--radius);background:var(--panel);font:16px/1.6 var(--sans);white-space:pre-wrap}
#v-frozen{color:var(--ink)}
/* A chunk whose correction failed is TEXT, in the normal colour: at most a
   dotted underline and a title with the reason. Never struck through. */
#v-frozen .v-uncorrected{color:var(--ink);text-decoration:underline dotted var(--warn);text-underline-offset:4px}
#v-pending .v-raw{color:var(--ink-2);font-style:italic}
.v-err .v-count{font-family:var(--mono);color:var(--bad)}
.v-err .v-count:empty{display:none}
.v-vocab{margin:6px 0 0;font-size:13px;display:flex;gap:6px;align-items:baseline;flex-wrap:wrap}
.v-vocab input{flex:1;min-width:14em}
.v-full{margin:12px 0 0}
.v-full .v-tx{min-height:80px}
.v-gap{margin:4px 0 8px;font-size:13px}
.v-gap.bad{color:var(--bad);font-weight:600}
.v-actions{margin:10px 0 6px}
.v-chunks{margin:0;padding-left:26px;font:12px var(--mono);color:var(--ink-2);max-height:160px;overflow:auto}
.v-chunks li{padding:1px 0}
.v-chunks .v-cache{color:var(--teal)}
.v-save{margin:6px 0 0;font-size:13px}
.v-save label{font-weight:600;margin-right:6px;cursor:pointer}
.v-saved{margin:0 0 10px;flex-wrap:wrap;gap:6px}
#v-save-links{display:flex;gap:6px;flex-wrap:wrap}
#v-save-links .btn{text-decoration:none}
"""

VOICE_JS = r"""
(function () {
  "use strict";
  var F = window.faxl, U = F.util, $ = U.$, el = U.el, get = U.get, fmt = F.fmt;
  var CFG = {};
  try { CFG = JSON.parse(($("faxl-voice") || {}).textContent || "{}") || {}; } catch (e) { CFG = {}; }
  var MAX_PCM = CFG.max_pcm_bytes;          // faxl_voice.MAX_PCM_BYTES, from the server
  var RATE = CFG.sample_rate;               // 16000, the only rate the server takes
  var FRAME = Math.round(RATE * 0.03), FRAME_MS = 30;
  var END_SILENCE_MS = 700, MAX_CHUNK_MS = 15000, MIN_SPEECH_MS = 300;
  var PREROLL_FRAMES = 10, TAIL_KEEP_FRAMES = 10;   // 300 ms either side of speech
  var MIN_THRESHOLD = 0.004, FLOOR_FACTOR = 3;      // RMS, on a -1..1 scale
  var DL_POLL_MS = 1000;

  var st = null, screen = "launch", launched = false, dlTimer = null, dlModel = null;

  // ---- errors: on the page, in plain words, until dismissed ---------------
  // The same failure (same key) is shown ONCE, with a count, not stacked:
  // a repair model that keeps failing is one line saying "×12".
  function showErr(msg, key) {
    var box = $("v-errors"); key = key || msg;
    var p = null;
    Array.prototype.forEach.call(box.children, function (x) { if (x.getAttribute("data-key") === key) p = x; });
    if (p) {
      p.vCount = (p.vCount || 1) + 1;
      p.querySelector("span").textContent = msg;
      p.querySelector(".v-count").textContent = "×" + p.vCount;
      if (box.firstChild !== p) box.insertBefore(p, box.firstChild);
      return;
    }
    p = el("div", "v-err"); p.setAttribute("data-key", key); p.vCount = 1;
    p.appendChild(el("span", null, msg));
    p.appendChild(el("b", "v-count", ""));
    var x = el("button", "btn btn-quiet", "dismiss"); x.type = "button";
    x.addEventListener("click", function () { if (p.parentNode) p.parentNode.removeChild(p); });
    p.appendChild(x);
    box.insertBefore(p, box.firstChild);
    while (box.children.length > 5) box.removeChild(box.lastChild);
  }
  function errOf(e) { return (e && e.message) || String(e); }
  function describe(status, data, what) {
    var t = (data && (data.error || data.message)) || "";
    if (!status) return "The proxy is not answering, so the " + what + " did not happen.";
    if (status === 413) return "That piece of audio was too large for the server, so it was not transcribed: " + t;
    if (status === 501) return t + " — install it into the Python the proxy runs from, then restart the proxy.";
    if (status === 502) return "The " + what + " failed: " + t;
    if (status === 403) return t;
    return "The " + what + " failed (HTTP " + status + "): " + (t || "no message");
  }

  // ---- screens ---------------------------------------------------------------
  function show(name) {
    screen = name;
    $("v-launch").hidden = name !== "launch";
    $("v-dl").hidden = name !== "download";
    $("v-wait").hidden = name !== "wait";
    $("v-rec").hidden = name !== "record";
  }
  function repairServing(s) { return get(s, "backend.up") === true && !!get(s, "model.id"); }

  function loadStatus(model) {
    return F.api("/api/voice/status" + (model ? "?model=" + encodeURIComponent(model) : ""))
      .then(function (d) { st = d; return d; });
  }
  function route() {
    var dl = st.download || {};
    if (dl.state === "running") { showDownload(); pollDownload(); return; }
    if (!get(st, "speech_model.installed")) { showDownload(); return; }
    if (!repairServing(F.state)) { showWait(); return; }
    showRecord();
  }
  $("v-launch-btn").addEventListener("click", function () {
    var b = this; b.disabled = true;
    $("v-launch-msg").textContent = "reading /api/voice/status…";
    loadStatus().then(function () {
      launched = true; $("v-launch-msg").textContent = ""; route();
    }, function (e) {
      $("v-launch-msg").textContent = "";
      showErr("Voice2Text could not read its status: " + errOf(e));
    }).then(function () { b.disabled = false; });
  });

  // ---- the download moment ---------------------------------------------------
  function sizeText(n) { return U.isNum(n) ? fmt.gb(n) : "size unknown"; }
  function li(ul, text) { ul.appendChild(el("li", null, text)); }
  function renderReqs() {
    var ul = $("v-reqs"); ul.textContent = "";
    var sm = st.speech_model || {}, rm = st.repair_model || {}, fit = st.fit || {}, disk = st.disk || {};
    var row = modelRow(st.selected) || {};
    li(ul, "A microphone, and this browser's permission to use it (it asks the first time you press the mic).");
    li(ul, "Download: " + (row.label || sm.id) + ", " + sizeText(sm.bytes) + " (" + (sm.bytes_basis || "no basis recorded") + ").");
    li(ul, "Repair model: " + (rm.id || "none configured") + ", " + sizeText(rm.bytes) +
       (rm.bytes_basis ? " (" + rm.bytes_basis + ")" : "") + " — the model faxl is serving; it is not downloaded here.");
    li(ul, rm.counted_in_memory === false
      ? "Memory: " + sizeText(fit.need_memory_bytes) + " for the speech model on this machine (the repair model runs on the cluster); " +
        fmt.dash(fit.memory_of) + " has " + sizeText(fit.have_memory_bytes) + " usable."
      : "Memory: " + sizeText(fit.need_memory_bytes) + " for the speech and repair models together, on top of what else is running; " +
        fmt.dash(fit.memory_of) + " has " + sizeText(fit.have_memory_bytes) + " usable.");
    (st.requirements || []).slice(1, 2).forEach(function (r) { li(ul, "Hardware: " + r + "."); });
    (st.requirements || []).slice(2).forEach(function (r) { li(ul, "Decoder: " + r + "."); });
    li(ul, "Disk: " + sizeText(disk.bytes_needed) + " needed, " + sizeText(disk.free_bytes) + " free at " + fmt.dash(disk.where) + ".");
    var f = $("v-fit"); f.textContent = "";
    (fit.reasons || []).forEach(function (r) { li(f, r); });
    f.hidden = !(fit.reasons || []).length;
  }
  function modelRow(id) { return (st.models || []).filter(function (m) { return m.id === id; })[0] || null; }
  function renderModels() {
    var box = $("v-models"); box.textContent = "";
    (st.models || []).forEach(function (m) {
      var unknown = !U.isNum(m.download_bytes), noEngine = !m.engine;
      var row = el("label", "v-model" + (unknown || noEngine ? " off" : ""));
      var r = el("input"); r.type = "radio"; r.name = "v-model"; r.value = m.id;
      r.checked = m.id === st.selected; r.disabled = unknown || noEngine;
      r.addEventListener("change", function () { if (r.checked) pickModel(m.id); });
      row.appendChild(r);
      row.appendChild(el("span", "v-mname", m.label + (m["default"] ? " (default)" : "") + (m.installed ? " — installed" : "")));
      var sz = el("span", "v-msize", unknown ? "size unknown" : fmt.gb(m.download_bytes));
      sz.title = m.download_bytes_basis || "";
      row.appendChild(sz);
      var meta = "Languages: " + (m.language_names || []).join(", ") + (m.languages_note ? " (" + m.languages_note + ")" : "") + ".";
      if (unknown) meta += " No download size is recorded, so it cannot be downloaded: faxl refuses rather than guesses.";
      if (noEngine) meta += " No speech engine for this platform.";
      else meta += " Engine: " + m.engine + " (" + (m.library_installed ? "installed" : "not installed: pip install " + m["package"]) + ").";
      row.appendChild(el("span", "v-mmeta", meta));
      box.appendChild(row);
    });
  }
  function renderDlButton() {
    var b = $("v-dl-btn"), row = modelRow(st.selected) || {}, dl = st.download || {};
    var running = dl.state === "running";
    b.textContent = "Download " + (row.label || st.selected) + " (" + sizeText(row.download_bytes) + ")";
    b.disabled = running || !get(st, "fit.ok") || !U.isNum(row.download_bytes) || !!row.installed;
    $("v-dl-note").textContent = running ? "downloading…" : !get(st, "fit.ok") ? "not started: see the reasons above" : "";
  }
  function showDownload() { renderReqs(); renderModels(); renderDlButton(); show("download"); }
  function pickModel(id) {
    loadStatus(id).then(showDownload, function (e) { showErr("Could not read the status for " + id + ": " + errOf(e)); });
  }
  $("v-dl-btn").addEventListener("click", function () {
    var b = this; b.disabled = true; dlModel = st.selected;
    F.api("/api/voice/download", {body: {model_id: st.selected}}).then(function (d) {
      renderProgress(d.status || {}); pollDownload();
    }, function (e) {
      if (e.status === 409) { pollDownload(); return; }
      showErr(e.status ? "The download did not start: " + errOf(e) : "The proxy is not answering, so the download did not start.");
      b.disabled = false;
    });
  });
  function renderProgress(d) {
    $("v-dl-prog").hidden = false;
    var done = d.bytes_done, total = d.bytes_total;
    var frac = U.isNum(done) && U.isNum(total) && total > 0 ? Math.min(1, done / total) : null;
    $("v-dl-bar").style.width = frac == null ? "0" : (frac * 100).toFixed(1) + "%";
    U.setText("v-dl-pct", frac == null ? U.DASH : fmt.pct(frac));
    U.setText("v-dl-text", (d.state || "?") + " · " + fmt.int(done) + " of " +
      (U.isNum(total) ? fmt.int(total) : "unknown") + " bytes" +
      (d.total_basis ? " · total: " + d.total_basis : ""));
  }
  function pollDownload() {
    if (dlTimer) return;
    $("v-dl-btn").disabled = true;
    function tick() {
      F.api("/api/voice/download/status").then(function (d) {
        renderProgress(d);
        if (d.state === "running") { dlTimer = setTimeout(tick, DL_POLL_MS); return; }
        dlTimer = null;
        if (d.state === "done") {
          loadStatus(dlModel || undefined).then(route, function (e) { showErr("Downloaded, but the status could not be read: " + errOf(e)); });
        } else if (d.state === "failed") {
          showErr("The download failed: " + (d.error || "no error recorded"));
          $("v-dl-btn").disabled = false;
        } else if (d.state === "interrupted") {
          showErr("The download was interrupted (the proxy restarted). Press Download to continue from what is already on disk.");
          $("v-dl-btn").disabled = false;
        } else {
          showErr("The download job reports state \"" + d.state + "\"" + (d.error ? ": " + d.error : "") + ".");
          $("v-dl-btn").disabled = false;
        }
      }, function (e) {
        dlTimer = null;
        showErr("Could not read the download's progress: " + errOf(e));
        $("v-dl-btn").disabled = false;
      });
    }
    dlTimer = setTimeout(tick, DL_POLL_MS);
  }

  // ---- waiting for the repair model ------------------------------------------
  function showWait() {
    var id = get(st, "repair_model.id");
    $("v-wait-msg").textContent = "The speech model is installed. The repair step runs on the model faxl serves" +
      (id ? " (" + id + ")" : "") + ", and it is not serving now (backend " + fmt.dash(get(F.state, "backend.name")) +
      (get(F.state, "backend.up") === false ? ", down" : "") + "). Start or switch it from the top bar; this page moves on by itself when it is up.";
    show("wait");
  }
  F.onState(function (s) {
    if (!launched) return;
    if (screen === "wait" && repairServing(s)) showRecord();
    else if (screen === "record" && !repairServing(s) && !recording) showWait();
  });

  // ---- the record screen -------------------------------------------------------
  var LIGHT = {nomic: "microphone not granted yet — press the mic", ready: "ready", rec: "recording"};
  function setLight(k, text) {
    $("v-light").className = "v-light " + k;
    U.setText("v-light-text", text || LIGHT[k] || "");
    var on = k === "rec" || k === "amber", mic = $("v-mic");
    mic.setAttribute("aria-pressed", on ? "true" : "false");
    mic.setAttribute("aria-label", on ? "stop recording" : "start recording");
    $("v-stop").disabled = !on;
    $("v-new").disabled = on;      // the recording belongs to this session until Stop
  }
  function showRecord() {
    var row = modelRow(get(st, "speech_model.id")) || {};
    var lib = $("v-lib");
    lib.hidden = row.library_installed !== false;
    lib.textContent = row.library_installed === false ? row["package"] + " is not installed in the Python the proxy runs from: pip install " +
      row["package"] + ". Transcription fails until it is; restart the proxy after installing." : "";
    var ff = $("v-ffmpeg"), noFf = !!st.ffmpeg && !st.ffmpeg.path;
    ff.hidden = !noFf;
    ff.textContent = noFf ? "ffmpeg is not installed on the machine running faxl, so the backup recording cannot be decoded and the " +
      "whole-recording transcript at Stop will fail (FfmpegMissing). Install it (brew install ffmpeg), then restart the proxy." : "";
    U.setText("v-session", "session " + sessionId);
    saveNote();
    show("record");
    if (!recording) {
      setLight("nomic");
      try {
        if (navigator.permissions && navigator.permissions.query) {
          navigator.permissions.query({name: "microphone"}).then(function (p) {
            if (p && p.state === "granted" && !recording) setLight("ready");
          }, function () {});
        }
      } catch (e) { /* the permissions API does not know "microphone" here */ }
    }
  }

  // ---- audio capture -----------------------------------------------------------
  // Two paths from ONE microphone stream:
  //   live    AudioContext -> ScriptProcessorNode -> VAD -> chunks (below);
  //           fast text while you talk, but it can stop with no error at all
  //           (WebKit, 2026-09-22: onaudioprocess stopped after ~75 s).
  //   backup  MediaRecorder, 5 s pieces uploaded in order; at Stop the server
  //           transcribes the WHOLE recording from it -- the authoritative text.
  // A watchdog restarts the live path when frames stop for WATCHDOG_MS, and
  // the counters say how much each path has: a gap is shown, never hidden.
  var WATCHDOG_MS = 2000, WATCH_TICK_MS = 250;
  var MR_TYPES = ["audio/webm;codecs=opus", "audio/mp4", "audio/ogg"];   // WebKit has only audio/mp4
  var TIMESLICE_MS = 5000, RECORDER_STALL_MS = 2 * TIMESLICE_MS + 2000, BK_RETRY_MS = 2000;
  var recording = false, stream = null, recStream = null, ctx = null, src = null, proc = null, ctxN = 0;
  var recStartAt = 0, recordedBaseS = 0, lastFrameAt = 0, lastRestartAt = 0, capturedS = 0, liveS = 0;
  var restarts = 0, watchTimer = null, restarting = false, amber = null;
  var mr = null, mrPart = -1, lastBlobAt = 0, partBaseS = 0, bkSeq = 0, bkQueue = [], bkBusy = false;
  var bkUploadedS = 0, bkBytes = 0, bkIdle = null, bkBroken = false, bkSid = null, finalized = false, fullAudioS = null;
  function now() { return Date.now(); }
  function recordedS() { return recordedBaseS + (recording ? (now() - recStartAt) / 1000 : 0); }
  function counters() {
    var t = "recorded " + recordedS().toFixed(1) + " s · heard live " + capturedS.toFixed(1) + " s · transcribed live " +
      liveS.toFixed(1) + " s · backup " + (fullAudioS != null ? fullAudioS.toFixed(1) + " s (decoded)" : bkUploadedS.toFixed(0) + " s") +
      (bkQueue.length ? " (" + bkQueue.length + " piece" + (bkQueue.length > 1 ? "s" : "") + " waiting to upload)" : "");
    if (restarts) t += " · capture restarted " + restarts + "×";
    U.setText("v-counters", t);
  }
  function setAmber(text) { amber = text; setLight("amber", text); }
  function clearAmber() { amber = null; if (recording) setLight("rec"); }
  function micError(e) {
    var n = e && e.name;
    setLight("nomic", n === "NotAllowedError" || n === "SecurityError" ? "microphone not granted" : "microphone not available");
    if (n === "NotAllowedError" || n === "SecurityError")
      showErr("The microphone was refused. Allow it for this page in the browser's site settings (the icon at the left of the address bar), then press the mic again.");
    else if (n === "NotFoundError" || n === "OverconstrainedError")
      showErr("No microphone was found. Plug one in or choose one in the system's sound settings, then press the mic again.");
    else if (n === "NotReadableError")
      showErr("The microphone is in use by another application or could not be opened (NotReadableError).");
    else showErr("The microphone could not be started: " + (n ? n + ": " : "") + errOf(e));
  }
  function buildCapture(s) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error("this browser has no Web Audio (AudioContext)");
    var c = new AC(); ctxN++;
    ctx = c;
    src = c.createMediaStreamSource(s);
    proc = c.createScriptProcessor(4096, 1, 1);
    proc.onaudioprocess = function (ev) {
      var d = ev.inputBuffer.getChannelData(0);
      lastFrameAt = now(); capturedS += d.length / c.sampleRate;
      onAudio(d, c.sampleRate);
    };
    src.connect(proc); proc.connect(c.destination);
    c.onstatechange = function () {
      if (!recording || c !== ctx || c.state === "running") return;
      // "suspended" / "interrupted" (WebKit, e.g. another app took the audio)
      setAmber("the audio context is " + c.state + " — resuming it");
      if (c.resume) c.resume().then(null, function () {});
    };
    if (c.state === "suspended" && c.resume) c.resume();
  }
  function teardownCapture() {
    try { if (proc) { proc.onaudioprocess = null; proc.disconnect(); } } catch (e) {}
    try { if (src) src.disconnect(); } catch (e) {}
    try { if (ctx) { ctx.onstatechange = null; if (ctx.close) ctx.close(); } } catch (e) {}
    proc = src = ctx = null;
  }
  function tracksLive(s) {
    return !!s && s.getTracks().some(function (t) { return t.readyState !== "ended"; });
  }
  function watchTracks(s) {
    s.getTracks().forEach(function (t) {
      t.onended = function () { if (recording && s === stream) restartCapture("the microphone track ended — restarting capture", true); };
      t.onmute = function () { if (recording && s === stream) setAmber("the system muted the microphone — no audio is arriving"); };
      t.onunmute = function () { if (recording && s === stream && amber) clearAmber(); };
    });
  }
  function stopTracks(s) { try { if (s) s.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} }
  function restartCapture(why, regum) {
    restarts++; restarting = true; lastRestartAt = now();
    setAmber(why);
    if (inChunk) endChunk();          // what was heard before the stall is sent
    teardownCapture();
    var p = (!regum && tracksLive(stream)) ? Promise.resolve(stream)
      : navigator.mediaDevices.getUserMedia({audio: true}).then(function (s) {
          if (stream !== recStream) stopTracks(stream);   // never the one the backup records
          stream = s; watchTracks(s); return s;
        });
    p.then(function (s) {
      if (!recording) return;
      buildCapture(s); resetVad();
      if (!mr || mr.state === "inactive") startRecorder(s);
    }).then(null, function (e) {
      showErr("Capture could not be restarted: " + (e && e.name ? e.name + ": " : "") + errOf(e) +
              " — the backup recording keeps running if its stream is alive.", "restart-failed");
    }).then(function () { restarting = false; lastRestartAt = now(); counters(); });
  }
  function watchdog() {
    if (!recording) return;
    var t = now();
    if (!restarting) {
      if (t - Math.max(lastFrameAt, lastRestartAt) > WATCHDOG_MS) {
        // odd restarts rebuild the AudioContext on the same stream; even ones
        // ask for the microphone again, in case the stream is the problem
        restartCapture("the microphone stopped delivering audio — restarting capture", restarts % 2 === 1);
      } else if (amber && lastFrameAt > lastRestartAt &&
                 !(stream && stream.getTracks().some(function (x) { return x.muted; }))) {
        clearAmber();
      }
    }
    if (mr && mr.state === "recording" && t - lastBlobAt > RECORDER_STALL_MS) {
      showErr("The backup recorder delivered nothing for " + Math.round((t - lastBlobAt) / 1000) + " s — restarting it as a new part.", "mr-stall");
      restartRecorder();
    }
    counters();
  }

  // ---- the backup recorder: MediaRecorder -> ordered uploads ------------------
  function pickMime() {
    var M = window.MediaRecorder;
    if (!M) return null;
    for (var i = 0; i < MR_TYPES.length; i++) {
      try { if (!M.isTypeSupported || M.isTypeSupported(MR_TYPES[i])) return MR_TYPES[i]; } catch (e) {}
    }
    return null;
  }
  function backupNote(t) { var n = $("v-backup-note"); n.hidden = !t; n.textContent = t || ""; }
  function startRecorder(s) {
    var mime = pickMime();
    if (!mime) {
      backupNote("This browser offers no MediaRecorder for " + MR_TYPES.join(", ") + ": there is NO backup recording, " +
                 "so only the live path runs and a stall in it can lose speech.");
      return;
    }
    var m;
    try { m = new window.MediaRecorder(s, {mimeType: mime}); }
    catch (e) { backupNote("The backup recorder could not start (" + mime + "): " + errOf(e) + ". Only the live path runs."); return; }
    mr = m; recStream = s; mrPart++;
    var part = mrPart, t0 = now(), base = partBaseS, type = mime.split(";")[0];
    lastBlobAt = t0;
    m.ondataavailable = function (ev) {
      lastBlobAt = now();
      var upto = base + (lastBlobAt - t0) / 1000;
      partBaseS = upto;
      if (!ev.data || !ev.data.size) return;
      bkQueue.push({seq: bkSeq++, part: part, piece: ev.data, type: type, upto: upto});
      pump();
    };
    m.onstop = function () {
      if (recording && m === mr) { showErr("The backup recorder stopped by itself — restarting it as a new part.", "mr-stopped"); restartRecorder(); }
      else if (m.vOnDone) m.vOnDone();
    };
    m.onerror = function (ev) { showErr("The backup recorder reported an error: " + errOf(ev && ev.error || ev), "mr-error"); };
    m.start(TIMESLICE_MS);
    backupNote("");
    U.setText("v-backup-type", "backup: " + mime);
  }
  function restartRecorder() {
    var old = mr; mr = null;
    try { if (old && old.state !== "inactive") old.stop(); } catch (e) {}
    var s = tracksLive(stream) ? stream : null;
    if (s) startRecorder(s);
    else navigator.mediaDevices.getUserMedia({audio: true}).then(function (n) { if (recording) startRecorder(n); },
      function (e) { showErr("The backup recorder could not be restarted: " + errOf(e), "mr-restart"); });
  }
  function pump() {
    if (bkBusy) return;
    if (!bkQueue.length) { counters(); if (bkIdle) { var f = bkIdle; bkIdle = null; f(); } return; }
    if (bkBroken) return;
    bkBusy = true;
    var it = bkQueue[0], sid = bkSid;
    fetch("/api/voice/session/" + encodeURIComponent(sid) + "/backup?seq=" + it.seq + "&part=" + it.part,
          {method: "POST", body: it.piece, cache: "no-store", credentials: "same-origin",
           headers: {"Content-Type": it.type, "Accept": "application/json"}})
      .then(readJson, function () { return {ok: false, status: 0, data: {}}; })
      .then(function (r) {
        bkBusy = false;
        if (sid !== bkSid) return;
        if (r.ok) {
          bkQueue.shift(); bkUploadedS = it.upto; bkBytes = r.data.bytes || bkBytes;
          pump(); return;
        }
        if (r.status === 409 || r.status === 413 || r.status === 415) {
          bkBroken = true;
          showErr(describe(r.status, r.data, "backup upload") + " — the backup stops at " + bkUploadedS.toFixed(0) +
                  " s; the live transcript is all there is after that.", "backup-broken");
          if (bkIdle) { var f = bkIdle; bkIdle = null; f(); }
          return;
        }
        showErr(describe(r.status, r.data, "backup upload") + " — piece " + it.seq + " is kept in the page and retried every " +
                (BK_RETRY_MS / 1000) + " s.", "backup-retry");
        setTimeout(pump, BK_RETRY_MS);
      });
    counters();
  }
  function whenUploaded(fn) {
    if (!bkBusy && (!bkQueue.length || bkBroken)) fn(); else bkIdle = fn;
  }

  function start() {
    var md = navigator.mediaDevices;
    if (!md || !md.getUserMedia) {
      setLight("nomic", "microphone not available");
      showErr("This browser offers no microphone to this page (navigator.mediaDevices is missing). Open the console as http://127.0.0.1:<port> or http://localhost:<port>: browsers only allow the microphone on a secure context.");
      return;
    }
    var mic = $("v-mic"); mic.disabled = true;
    md.getUserMedia({audio: true}).then(function (s) {
      try { buildCapture(s); } catch (e) { stopTracks(s); throw e; }
      stream = s; watchTracks(s);
      if (bkSid !== sessionId) { bkSid = sessionId; }
      finalized = false; fullAudioS = null;
      recStartAt = lastFrameAt = lastRestartAt = now();
      resetVad(); recording = true; setLight("rec");
      startRecorder(s);
      watchTimer = setInterval(watchdog, WATCH_TICK_MS);
      counters();
    }).then(null, function (e) {
      if (e && e.name) micError(e); else showErr("The microphone could not be started: " + errOf(e));
    }).then(function () { mic.disabled = false; });
  }
  function stop() {
    if (!recording) return;
    recordedBaseS = recordedS();
    recording = false; amber = null;
    clearInterval(watchTimer); watchTimer = null;
    if (inChunk) endChunk();   // what was said before Stop is sent, not lost
    teardownCapture();
    var m = mr, live = stream, rs = recStream; mr = null; stream = recStream = null;
    function done() { stopTracks(live); if (rs !== live) stopTracks(rs); whenUploaded(finalize); }
    if (m && m.state !== "inactive") {
      m.vOnDone = done;          // the last piece arrives before onstop
      try { m.stop(); } catch (e) { done(); }
    } else done();
    setLight("ready");
    counters();
  }
  $("v-mic").addEventListener("click", function () { if (recording) stop(); else start(); });
  $("v-stop").addEventListener("click", stop);

  // ---- the whole recording, transcribed at Stop: the authoritative text --------
  function finalizeBody() {
    return {language: lang(), model: get(st, "speech_model.id") || CFG.default_model, prompt: vocab()};
  }
  function finalize() {
    if (!bkSeq || !bkSid) return;
    var sid = bkSid;
    $("v-full-wrap").hidden = false;
    U.setText("v-full-state", "transcribing the whole recording (" + recordedBaseS.toFixed(1) + " s)…");
    F.api("/api/voice/session/" + encodeURIComponent(sid) + "/finalize", {body: finalizeBody()}).then(function (d) {
      if (sid !== sessionId) return;
      finalized = true; showFull(d);
    }, function (e) {
      if (sid !== sessionId) return;
      U.setText("v-full-state", "the whole-recording transcript failed — see the message above; the backup file is kept");
      showErr(describe(e.status, e.data || {error: errOf(e)}, "whole-recording transcription"), "finalize");
    });
  }
  function showFull(d) {
    fullAudioS = U.isNum(d.audio_s) ? d.audio_s : null;
    U.setText("v-full", d.full_text || "(no words recognised in the whole recording)");
    U.setText("v-full-state", "whole recording: " + (fullAudioS || 0).toFixed(1) + " s transcribed in " +
      fmt.ms((d.elapsed_s || 0) * 1000) + (d.parts > 1 ? " · " + d.parts + " parts" : "") +
      (d.saved ? " · saved as full.txt" : ""));
    var a = fullAudioS || 0, rec = recordedBaseS, slack = function (x) { return Math.max(2, 0.02 * x); };
    var msgs = [], bad = false;
    if (capturedS < a - slack(a)) {
      bad = true;
      msgs.push("live path heard " + capturedS.toFixed(1) + " s (transcribed live " + liveS.toFixed(1) + " s of speech) of " +
                a.toFixed(1) + " s recorded — the full-recording transcript is used");
    } else {
      msgs.push("live path heard " + capturedS.toFixed(1) + " s of " + a.toFixed(1) + " s recorded — no gap; the full-recording transcript is used");
    }
    if (a < rec - slack(rec)) {
      bad = true;
      msgs.push("the backup itself holds " + a.toFixed(1) + " s of the " + rec.toFixed(1) + " s you recorded");
    }
    // SAY WHAT DID THE WORK, AND THAT IT WAS HERE. (AM, 2026-09-25.) This
    // line used to carry ffmpeg's raw stderr -- "[opus @ 0x937024700] Error
    // parsing Opus packet header" -- on a decode that had SUCCEEDED. On a
    // page whose whole argument is that nothing leaves the machine, an
    // unexplained "Opus" reads like a cloud model rather than the audio
    // codec inside every .webm.
    //
    // Naming the two local tools turns the same sentence from a worry into
    // the reassurance it should always have been. Warnings now appear only
    // when ffmpeg actually failed, where they are diagnostic.
    var tools = "decoded on this Mac by ffmpeg";
    if (d.model) {
      // The id already carries the family ("whisper-large-v3-turbo"), so
      // prefixing "Whisper" would stutter. Say it only when it does not.
      var m = String(d.model);
      tools += ", transcribed by " +
               (/whisper/i.test(m) ? m : "Whisper " + m);
    }
    msgs.push(tools);
    (d.decode_warnings || []).forEach(function (w) { msgs.push("decoder: " + w); });
    if (d.save_error) showErr(d.save_error, "save-error");
    U.setText("v-gap", msgs.join(" · "));
    $("v-gap").className = "v-gap" + (bad ? " bad" : "");
    counters();
  }
  $("v-copy-full").addEventListener("click", function () { copyText($("v-full").textContent); });
  // Closing the tab mid-recording: ask the server to transcribe what the
  // backup holds (it writes full.txt when Save recording is on). Pieces still
  // in the page's upload queue cannot be sent from here and are lost.
  window.addEventListener("pagehide", function () {
    if (!bkSeq || finalized || !bkSid || !navigator.sendBeacon) return;
    try { if (mr && mr.state === "recording" && mr.requestData) mr.requestData(); } catch (e) {}
    try {
      navigator.sendBeacon("/api/voice/session/" + encodeURIComponent(bkSid) + "/finalize", JSON.stringify(finalizeBody()));
    } catch (e) {}
  });

  // ---- downsample to 16 kHz mono: box average, the fraction carried over -------
  var carry = new Float32Array(0), carryPos = 0;
  function downsample(input, rate) {
    if (rate === RATE) return new Float32Array(input);
    var buf = new Float32Array(carry.length + input.length);
    buf.set(carry, 0); buf.set(input, carry.length);
    var ratio = rate / RATE, out = [], p = carryPos;
    while (p + ratio <= buf.length) {
      var a = Math.floor(p), b = Math.max(a + 1, Math.floor(p + ratio)), s = 0;
      for (var i = a; i < b; i++) s += buf[i];
      out.push(s / (b - a));
      p += ratio;
    }
    var keep = Math.floor(p);
    carry = buf.slice(keep); carryPos = p - keep;
    return new Float32Array(out);
  }

  // ---- VAD: RMS against an adaptive noise floor --------------------------------
  var frameBuf = new Float32Array(FRAME), frameLen = 0, noiseFloor = 0.002;
  var inChunk = false, chunk = [], preroll = [], speechMs = 0, silenceMs = 0, sentN = 0, droppedN = 0;
  function resetVad() {
    carry = new Float32Array(0); carryPos = 0; frameLen = 0;
    inChunk = false; chunk = []; preroll = []; speechMs = silenceMs = 0;
  }
  function onAudio(input, rate) {
    if (!recording) return;
    var d = downsample(input, rate);
    for (var i = 0; i < d.length; i++) {
      frameBuf[frameLen++] = d[i];
      if (frameLen === FRAME) { vadFrame(frameBuf); frameBuf = new Float32Array(FRAME); frameLen = 0; }
    }
  }
  function vadFrame(f) {
    var s = 0;
    for (var i = 0; i < f.length; i++) s += f[i] * f[i];
    var rms = Math.sqrt(s / f.length);
    var speech = rms > Math.max(noiseFloor * FLOOR_FACTOR, MIN_THRESHOLD);
    // The floor falls fast and rises slowly -- and only very slowly while
    // someone is talking, so a steady new noise (a fan) becomes the floor in
    // seconds instead of holding every chunk open to the 15 s cap.
    noiseFloor += (rms - noiseFloor) * (rms < noiseFloor ? 0.3 : speech ? 0.002 : 0.05);
    if (!inChunk) {
      if (speech) { inChunk = true; chunk = preroll.concat([f]); preroll = []; speechMs = FRAME_MS; silenceMs = 0; }
      else { preroll.push(f); if (preroll.length > PREROLL_FRAMES) preroll.shift(); }
      return;
    }
    chunk.push(f);
    if (speech) { speechMs += FRAME_MS; silenceMs = 0; } else silenceMs += FRAME_MS;
    if (silenceMs >= END_SILENCE_MS || chunk.length * FRAME_MS >= MAX_CHUNK_MS) endChunk();
  }
  function endChunk() {
    var frames = chunk, spoken = speechMs;
    var drop = Math.max(0, Math.round(silenceMs / FRAME_MS) - TAIL_KEEP_FRAMES);
    frames = frames.slice(0, frames.length - drop);
    inChunk = false; chunk = []; preroll = []; speechMs = silenceMs = 0;
    if (spoken < MIN_SPEECH_MS) { droppedN++; stats(); return; }
    var n = frames.length * FRAME, pcm = new Float32Array(n);
    for (var i = 0; i < frames.length; i++) pcm.set(frames[i], i * FRAME);
    emit(pcm);
  }
  function toInt16LE(pcm) {
    var buf = new ArrayBuffer(pcm.length * 2), dv = new DataView(buf);
    for (var i = 0; i < pcm.length; i++) {
      var v = Math.max(-1, Math.min(1, pcm[i]));
      dv.setInt16(i * 2, v < 0 ? Math.round(v * 32768) : Math.round(v * 32767), true);
    }
    return buf;
  }
  function emit(pcm) {
    var bytes = toInt16LE(pcm);
    // faxl_voice.MAX_PCM_BYTES (60 s) is far above the 15 s cap, but the
    // split is here so a change to either number can never produce a 413.
    for (var off = 0; off < bytes.byteLength; off += MAX_PCM) {
      var piece = bytes.slice(off, Math.min(bytes.byteLength, off + MAX_PCM));
      enqueue(piece);
    }
  }
  function stats() {
    U.setText("v-stats", sentN + " sent · " + droppedN + " too short to send (< " + MIN_SPEECH_MS + " ms of speech)");
  }

  // ---- sending, in order: one chunk at a time, repairs in sequence ---------------
  function newSession() {
    var a = new Uint8Array(8), s = "v";
    try { window.crypto.getRandomValues(a); } catch (e) { for (var j = 0; j < 8; j++) a[j] = Math.floor(Math.random() * 256); }
    for (var i = 0; i < a.length; i++) s += (a[i] < 16 ? "0" : "") + a[i].toString(16);
    return s;
  }
  // pieces: the transcript as the page shows it, one entry per chunk, each
  // corrected or -- when the correction failed -- raw, in the normal colour.
  var sessionId = newSession(), pieces = [], queue = Promise.resolve(), chunkN = 0;
  function readJson(r) {
    return r.text().then(function (t) {
      var d = null;
      if (t) { try { d = JSON.parse(t); } catch (e) { d = null; } }
      return {ok: r.ok && !(d && d.ok === false), status: r.status, data: d || {error: String(t || "").slice(0, 300)}};
    });
  }
  function enqueue(bytes) {
    sentN++; stats();
    var c = {n: ++chunkN, sid: sessionId, bytes: bytes, secs: bytes.byteLength / 2 / RATE};
    c.span = el("span", "v-raw", " …");
    $("v-pending").appendChild(c.span);
    c.row = el("li", null, "#" + c.n + " · " + c.secs.toFixed(1) + " s audio · transcribing…");
    $("v-chunks").appendChild(c.row);
    queue = queue.then(function () { return sendChunk(c); }, function () { return sendChunk(c); });
  }
  function note(c, text, cache) {
    c.row.textContent = "#" + c.n + " · " + c.secs.toFixed(1) + " s audio · " + text;
    if (cache) { c.row.appendChild(document.createTextNode(" · ")); c.row.appendChild(el("span", "v-cache", cache)); }
  }
  function lang() { return $("v-lang").value; }
  function vocab() { return String($("v-vocab").value || "").trim(); }
  function sendChunk(c) {
    var q = "session=" + encodeURIComponent(c.sid) + "&language=" + encodeURIComponent(lang()) +
            "&repair=0&model=" + encodeURIComponent(get(st, "speech_model.id") || CFG.default_model) +
            (vocab() ? "&prompt=" + encodeURIComponent(vocab()) : "");
    return fetch("/api/voice/transcribe?" + q, {method: "POST", body: c.bytes, cache: "no-store",
        credentials: "same-origin",
        headers: {"Content-Type": "application/octet-stream", "Accept": "application/json"}})
      .then(readJson, function () { return {ok: false, status: 0, data: {}}; })
      .then(function (r) {
        if (c.sid !== sessionId) return null;
        if (!r.ok) {
          c.span.parentNode && c.span.parentNode.removeChild(c.span);
          note(c, "not transcribed (HTTP " + r.status + ")");
          showErr(describe(r.status, r.data, "transcription"), "tx:" + r.status + ":" + ((r.data && r.data.error_type) || ""));
          return null;
        }
        showSaved(r.data.saved, c.sid);
        liveS += c.secs; counters();
        var voc = r.data.vocabulary;
        if (voc && voc.applied === false) U.setText("v-vocab-note", "not applied: " + (voc.reason || voc.engine));
        else if (voc) U.setText("v-vocab-note", "applied (" + voc.engine + ")");
        var raw = String(r.data.text || "").trim();
        c.raw = raw;
        if (!raw) {
          c.span.parentNode && c.span.parentNode.removeChild(c.span);
          note(c, "no words recognised");
          return null;
        }
        c.span.textContent = " " + raw;
        note(c, "transcribed in " + fmt.ms((r.data.elapsed_s || 0) * 1000) + " · repairing…");
        return repair(c);
      });
  }
  function cacheText(k) {
    if (!k || !k.outcome) return "";
    var t = String(k.outcome).toLowerCase();
    if (U.isNum(k.prefill_skipped)) t += " · " + fmt.int(k.prefill_skipped) + " tok skipped";
    return t;
  }
  function keepRaw(c, reason, key, msg) {
    pieces.push({text: c.raw, corrected: false, reason: reason});
    note(c, "kept raw — not corrected: " + reason);
    showErr(msg, key);
  }
  function repair(c) {
    return F.api("/api/voice/repair", {body: {session: c.sid, raw: c.raw}}).then(function (d) {
      if (c.sid !== sessionId) return;
      if (c.span.parentNode) c.span.parentNode.removeChild(c.span);
      if (d.corrected != null) {
        pieces.push({text: d.corrected, corrected: true});
        note(c, "repaired in " + fmt.ms((d.elapsed_s || 0) * 1000), cacheText(d.cache));
      } else {
        keepRaw(c, d.reason || "no reason given", "repair:" + (d.reason_code || ""),
                "Not corrected — the raw text is in the transcript: " + (d.reason || "no reason given"));
      }
      if (d.save_error) showErr(d.save_error, "save-error");
      renderText();
    }, function (e) {
      if (c.sid !== sessionId) return;
      if (c.span.parentNode) c.span.parentNode.removeChild(c.span);
      keepRaw(c, "the repair request failed: " + errOf(e), "repair-http:" + (e.status || 0),
              describe(e.status, e.data || {error: errOf(e)}, "repair request") + " — the raw text is kept in the transcript, uncorrected.");
      renderText();
    });
  }
  function renderText() {
    var box = $("v-frozen"); box.textContent = "";
    pieces.forEach(function (p, i) {
      if (i) box.appendChild(document.createTextNode(" "));
      if (p.corrected) { box.appendChild(document.createTextNode(p.text)); return; }
      var s = el("span", "v-uncorrected", p.text);
      s.title = "not corrected: " + p.reason;
      box.appendChild(s);
    });
  }
  function fullText() {
    var parts = pieces.map(function (p) { return p.text; });
    Array.prototype.forEach.call($("v-pending").children, function (s) { parts.push(s.textContent.trim()); });
    return parts.filter(function (x) { return x && x !== "…"; }).join(" ");
  }
  function copyText(t) {
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      showErr("This browser does not let the page write to the clipboard here; select the transcript and copy it.");
      return;
    }
    navigator.clipboard.writeText(t).then(function () { F.toast("copied " + t.length + " characters", "ok"); },
      function (e) { showErr("Copy failed: " + errOf(e)); });
  }
  $("v-copy").addEventListener("click", function () { copyText(fullText()); });
  $("v-new").addEventListener("click", function () {
    if (recording) return;
    var old = sessionId;
    F.api("/api/voice/session/reset", {body: {session: old}}).then(function () {
      sessionId = newSession(); pieces = [];
      $("v-pending").textContent = ""; $("v-chunks").textContent = ""; renderText();
      sentN = droppedN = 0; stats(); U.setText("v-session", "session " + sessionId);
      $("v-saved").hidden = true; $("v-save-links").textContent = "";
      bkSid = null; bkSeq = 0; mrPart = -1; bkQueue = []; bkBroken = false; bkUploadedS = partBaseS = 0; fullAudioS = null;
      recordedBaseS = capturedS = liveS = 0; restarts = 0; finalized = false;
      $("v-full-wrap").hidden = true; U.setText("v-full", ""); U.setText("v-gap", "");
      counters();
      if ($("v-save").checked) setSave(true);   // the new session saves too
    }, function (e) { showErr("The session could not be reset: " + errOf(e)); });
  });
  // The names and terms: kept in this browser for next time (a convenience;
  // the page works the same when storage is unavailable).
  (function () {
    var v = $("v-vocab");
    v.value = CFG.vocabulary || "";
    try { var s = window.localStorage.getItem("faxl.voice.vocab"); if (s !== null) v.value = s; } catch (e) {}
    v.addEventListener("change", function () { try { window.localStorage.setItem("faxl.voice.vocab", v.value); } catch (e) {} });
  })();

  // ---- save recording: off by default; the server keeps the files -------------
  function saveNote() {
    var where = get(st, "platform") === "darwin" ? "this Mac" : "this machine";
    U.setText("v-save-note", "Keeps the audio and both transcripts on " + where + " in " +
      (CFG.voice_dir || "~/.faxl/voice/") + " — nothing leaves the machine.");
  }
  function setSave(on) {
    var box = $("v-save"), sid = sessionId;
    box.disabled = true;
    return F.api("/api/voice/session/save", {body: {session: sid, save: on}}).then(function (d) {
      if (sid !== sessionId) return;
      if (on) {
        $("v-saved").hidden = false;
        U.setText("v-save-dir", d.dir || (CFG.voice_dir || d.voice_dir) + " (a folder for this session is made at the first piece of speech)");
      }
    }, function (e) {
      box.checked = !on;
      showErr("Save recording could not be switched " + (on ? "on" : "off") + ": " + errOf(e));
    }).then(function () { box.disabled = false; });
  }
  $("v-save").addEventListener("change", function () { setSave(this.checked); });
  function showSaved(sv, sid) {
    if (!sv || !sv.dir || sid !== sessionId) return;
    $("v-saved").hidden = false;
    U.setText("v-save-dir", sv.dir);
    var box = $("v-save-links");
    if (box.children.length) return;
    ["audio.wav", "raw.txt", "final.txt"].forEach(function (f) {
      var a = el("a", "btn btn-quiet", "Download " + f);
      a.href = "/api/voice/session/" + encodeURIComponent(sid) + "/download?file=" + encodeURIComponent(f);
      a.setAttribute("download", f);
      box.appendChild(a);
    });
  }

  // For the page's tests: the pure parts, no state of their own.
  window.faxlVoice = {downsample: downsample, toInt16LE: toInt16LE};
  F.start();
})();
"""

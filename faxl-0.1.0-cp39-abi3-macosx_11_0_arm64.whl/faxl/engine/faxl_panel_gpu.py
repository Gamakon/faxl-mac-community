# Vendored engine module (faxl_panel_gpu.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""Selected CUDA device console, sharing faxl_panel's chrome and runtime.

GPU memory is faxl_config.gpu_memory contract v1, never summed inventory.
History contains distinct driver samples, capped at 120 for the selected UUID.
The connector view is a bounded tail, not lifetime counters or proof of T1.
No framework imports, model loads, or telemetry writes happen in this module.
"""
import collections
import copy
import html
import json
import math
import os
import stat
import threading
import time

from faxl.engine import faxl_config
from faxl.engine import faxl_panel as _P


class EventTail:
    """Read at most 256 KiB / 100 complete records from the real sidecar.

    A three-second cache bounds repeated polls; unchanged files reuse decoded
    records. Non-regular files refuse without blocking. Errors remain visible.
    This is the newest file tail and is never labelled all-time activity.
    """
    MAX_BYTES = 256 * 1024
    # One byte of the total read budget is reserved for boundary detection.
    MAX_TAIL_BYTES = MAX_BYTES - 1
    MAX_ROWS = 100

    def __init__(self):
        self._path = self._key = self._value = None
        self._checked = -math.inf

    def read(self, path):
        now = time.monotonic()
        if path == self._path and now - self._checked < 3 and self._value is not None:
            return copy.deepcopy(self._value)
        out = {"path": path, "rows": None, "error": None, "note": None,
               "tail_truncated": None, "bytes_read": None,
               "max_bytes": self.MAX_BYTES, "max_rows": self.MAX_ROWS}
        try:
            if not path:
                raise ValueError("live backend does not expose its connector events_path")
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            with os.fdopen(fd, "rb") as f:
                info = os.fstat(f.fileno())
                if not stat.S_ISREG(info.st_mode):
                    raise ValueError("connector event path is not a regular file")
                key = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
                if path == self._path and key == self._key and self._value is not None:
                    self._checked = now
                    return copy.deepcopy(self._value)
                offset = max(0, info.st_size - self.MAX_TAIL_BYTES)
                f.seek(max(0, offset - 1))
                before = f.read(1) if offset else b''
                data = f.read(min(info.st_size, self.MAX_TAIL_BYTES))
            # A boundary-aligned first record is complete, so retain it. The
            # one-byte lookbehind is inside MAX_BYTES, not an unbounded scan.
            lines = data.split(b'\n')
            if offset and before != b'\n':
                lines = lines[1:]
            partial = bool(lines and lines[-1]) or bool(data and not data.endswith(b'\n'))
            lines = lines[:-1] if lines else []
            truncated = bool(offset or len(lines) > self.MAX_ROWS)
            rows, errors = [], []
            for line in lines[-self.MAX_ROWS:]:
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                    if not isinstance(row, dict):
                        raise ValueError("connector event must be a JSON object")
                    rows.append(row)
                except (UnicodeDecodeError, ValueError) as exc:
                    errors.append(f"{type(exc).__name__}: {exc}; raw={line!r}")
            out.update(rows=rows, bytes_read=len(data) + len(before), tail_truncated=truncated,
                       error="\n".join(errors) if errors else None,
                       note=("unfinished trailing record omitted until its newline is written"
                             if partial else "bounded newest records; not lifetime counts"))
            self._key = key
        except (OSError, ValueError) as exc:
            out["error"] = f"{type(exc).__name__}: {exc}"
            self._key = None
        self._path, self._checked, self._value = path, now, out
        return copy.deepcopy(out)


class GpuFeed:
    """One feed per console Blueprint, serialized across concurrent requests."""
    def __init__(self):
        self._lock = threading.Lock()
        self._uuid = None
        self._history = collections.deque(maxlen=120)
        self._events = EventTail()

    def payload(self, model, backend_stats, *, include_events=True):
        with self._lock:
            notices = []
            def read(source, fn):
                try:
                    return fn()
                except Exception as exc:
                    notices.append(f"{source}: {type(exc).__name__}: {exc}")
                    return None
            memory = read("GPU selection", faxl_config.gpu_memory)
            selected = (memory or {}).get("selected_device") or {}
            uuid = selected.get("uuid")
            if uuid != self._uuid:
                self._uuid = uuid
                self._history.clear()
            sampled = selected.get("driver_sampled_at_unix_seconds")
            if isinstance(sampled, (int, float)) and math.isfinite(sampled):
                if not self._history or self._history[-1]["driver_sampled_at_unix_seconds"] != sampled:
                    self._history.append({
                        "uuid": uuid, "driver_sampled_at_unix_seconds": sampled,
                        "used_bytes": selected.get("used_bytes"),
                        "driver_total_bytes": selected.get("total_bytes"),
                        "utilization_percent": selected.get("utilization_percent")})
            elif selected:
                notices.append("driver sample timestamp unavailable; no history point recorded")
            engine = read("live backend", backend_stats) if backend_stats else None
            if engine is None:
                notices.append("live backend stats unavailable; resolved settings and KV pool are unmeasured")
            fit = read("serving model fit", lambda: faxl_config.fits_gpu(model, mem=memory)) if model and memory else None
            recommendations = read("model ladder", lambda: faxl_config.recommend_vllm_models(mem=memory)) if memory else None
            if include_events:
                events = self._events.read((engine or {}).get("events_path"))
            else:
                events = {"path": None, "rows": None, "error":
                          "connector events are readable from this machine only"}
            if (memory or {}).get("error"):
                notices.append(memory["error"])
            return {"contract_version": 1, "memory": memory,
                    "model": model or None, "model_fit": fit,
                    "recommendations": recommendations,
                    "engine": engine, "history": list(self._history),
                    "history_limit": self._history.maxlen,
                    "history_note": "distinct driver samples observed by this console for the selected UUID; cached polls add no points",
                    "events": events, "notices": notices,
                    "fit_note": "selected runtime capacity × fit ratio is a weight estimate, not free VRAM or a KV/context guarantee",
                    "phototag_command": "python -m faxl.engine.apps.phototag DIR --limit 1 --dry-run"}


def render_gpu(state, gpu, nonce=None):
    blob = ('<script type="application/json" id="faxl-gpu">'
            + _P.state_json(gpu) + '</script>')
    return _P.render_shell(state, title="faxl — GPU", main_html=GPU_HTML + blob,
                           page_css=GPU_CSS, page_js=GPU_JS, here="gpu",
                           app_id="app-gpu", nonce=nonce)


def render_gpu_text(payload):
    # Full field names/values keep sample provenance and refusals in agent mode.
    return "faxl GPU console\n/console /console/gpu /api/gpu\n\n" + json.dumps(
        payload, indent=2, ensure_ascii=True, allow_nan=False) + "\n"


def render_gpu_agent(payload):
    return ('<!doctype html><html lang="en-GB"><meta charset="utf-8">'
            '<title>faxl GPU console</title><nav><a href="/console">console</a> · '
            '<a href="/console/gpu?format=json">JSON</a> · '
            '<a href="/console/gpu?format=text">text</a></nav><h1>GPU console</h1><pre>'
            + html.escape(render_gpu_text(payload)) + '</pre></html>')


GPU_CSS = r"""
#app-gpu{display:grid;min-height:100vh;grid-template-columns:minmax(280px,1fr) minmax(400px,1.8fr) minmax(300px,1.2fr);gap:var(--gap);padding:0 var(--gap) var(--gap)}
#app-gpu #topbar,#g-status{grid-column:1/-1}
.g-col{min-width:0;display:flex;flex-direction:column;gap:var(--gap)}
#app-gpu .kv dd{overflow-wrap:anywhere}
.g-scroll{overflow:auto;max-height:370px}
.g-table{border-collapse:collapse;width:100%;font-size:12px}
.g-table th,.g-table td{text-align:left;padding:5px 7px;border-bottom:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere}
.g-table th{color:var(--ink-2)}
#g-chart{width:100%;height:160px;display:block}
.g-notice{color:var(--bad);white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}
#g-events{margin:0;padding:8px;background:var(--panel-2);max-height:500px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:11.5px/1.5 var(--mono)}
.g-model{padding:8px 0;border-bottom:1px solid var(--line);font-size:12px;overflow-wrap:anywhere}
.g-model p{margin:3px 0}
.g-inventory{border-top:1px solid var(--line);padding-top:8px;margin-top:8px}
@media(max-width:1100px){#app-gpu{grid-template-columns:1fr 1fr}.g-col:last-child{grid-column:1/-1}}
@media(max-width:720px){#app-gpu{grid-template-columns:1fr}.g-col:last-child{grid-column:auto}}
"""

GPU_HTML = r"""
<section class="card" id="g-status">
  <div class="card-h"><h2>GPU operator console</h2><span class="aux" id="g-live">loading</span>
    <button class="btn btn-quiet" data-drawer="drawer-models" type="button">choose model</button></div>
  <p id="g-selection" class="mono"></p><div id="g-notices" class="g-notice" role="status"></div>
</section>
<div class="g-col">
  <section class="card"><div class="card-h"><h2>Selected CUDA device</h2></div><dl class="kv" id="g-device"></dl>
    <p class="muted">Single-device engine on logical CUDA 0. CUDA resolves masks and order; driver inventory is informational.</p></section>
  <section class="card"><div class="card-h"><h2>Precision eligibility</h2></div><dl class="kv" id="g-precision"></dl></section>
  <section class="card"><div class="card-h"><h2>Driver inventory</h2></div><p class="muted" id="g-masks"></p><div id="g-inventory"></div></section>
  <section class="card"><div class="card-h"><h2>Photo tagging CLI</h2></div>
    <p class="muted">The Linux package provides photo tagging through the CLI. Serving images needs a vision model. Follow the release checklist: licensed T1 verification precedes photo inference.</p>
    <p class="mono wrap" id="g-phototag"></p></section>
</div>
<div class="g-col">
  <section class="card"><div class="card-h"><h2>Driver samples over time</h2></div>
    <p class="muted">Utilization (%) and used VRAM (% of driver total). Actual driver timestamps; cached polls add no samples.</p>
    <svg id="g-chart" viewBox="0 0 600 160" role="img" aria-label="GPU utilization and VRAM usage at recorded driver sample times"></svg>
    <p class="muted" id="g-history-note"></p><div class="g-scroll"><table class="g-table"><thead><tr><th>driver sampled at (UTC)</th><th>used VRAM</th><th>utilization</th></tr></thead><tbody id="g-history"></tbody></table></div></section>
  <section class="card"><div class="card-h"><h2>Serving model fit</h2></div><p id="g-model" class="mono wrap"></p>
    <dl class="kv" id="g-fit"></dl><p class="muted" id="g-fit-note"></p></section>
  <section class="card"><div class="card-h"><h2>Model ladder</h2></div><div class="g-scroll" id="g-ladder"></div></section>
</div>
<div class="g-col">
  <section class="card"><div class="card-h"><h2>Resolved vLLM engine</h2></div><p class="mono" id="g-versions"></p>
    <dl class="kv" id="g-settings"></dl><p class="muted">These are live engine settings, not the settings a future restart will request.</p>
    <p id="g-engine-note" class="g-notice"></p></section>
  <section class="card"><div class="card-h"><h2>KV pool</h2></div><dl class="kv" id="g-kv"></dl>
    <p class="muted">Token capacity and maximum concurrency come directly from vLLM's group-aware cache initialization. Blocks × block size is not token capacity for hybrid models.</p></section>
  <section class="card"><div class="card-h"><h2>Connector events</h2></div><p class="mono wrap" id="g-event-path"></p>
    <p class="muted" id="g-event-note"></p><p id="g-event-error" class="g-notice" role="status"></p><pre id="g-events"></pre></section>
</div>
"""

GPU_JS = r"""
(function(){
  "use strict";
  var F = window.faxl, U = F.util, $ = U.$, mk = U.el, fmt = F.fmt;
  function text(id, value){ $(id).textContent = value == null ? "—" : String(value); }
  function yes(v){ return v == null ? "—" : v ? "yes" : "no"; }
  function utc(v){ return U.isNum(v) ? new Date(v * 1000).toISOString() : "—"; }
  function kv(id, pairs){
    var box = $(id); box.textContent = "";
    pairs.forEach(function(p){ box.appendChild(mk("dt", null, p[0])); box.appendChild(mk("dd", "mono", p[1] == null ? "—" : String(p[1]))); });
  }
  function fields(id, obj){ kv(id, Object.keys(obj || {}).map(function(k){ return [k.replace(/_/g," "), obj[k]]; })); }
  function chart(rows){
    var svg = $("g-chart"), ns = "http://www.w3.org/2000/svg"; svg.textContent = "";
    function add(tag, attrs){ var n = document.createElementNS(ns,tag); Object.keys(attrs).forEach(function(k){ n.setAttribute(k,attrs[k]); }); svg.appendChild(n); return n; }
    [0,50,100].forEach(function(v){ add("line",{x1:35,x2:595,y1:145-v*1.2,y2:145-v*1.2,stroke:"var(--line)"}); var n=add("text",{x:0,y:149-v*1.2,fill:"var(--ink-2)","font-size":11}); n.textContent=v+"%"; });
    if(!rows.length) return;
    var min = rows[0].driver_sampled_at_unix_seconds, span = rows[rows.length-1].driver_sampled_at_unix_seconds-min;
    function xy(r,v){return [35+(span ? (r.driver_sampled_at_unix_seconds-min)/span*550 : 275),145-v*1.2];}
    [["utilization_percent","var(--series-1)","utilization"],["used_bytes","var(--series-2)","used VRAM"]].forEach(function(series){
      var segment=[];
      function flush(){if(segment.length) add("polyline",{points:segment.join(" "),fill:"none",stroke:series[1],"stroke-width":2}); segment=[];}
      rows.forEach(function(r){
        var v = series[0] === "used_bytes" ? (U.isNum(r.used_bytes) && U.isNum(r.driver_total_bytes) && r.driver_total_bytes > 0 ? 100*r.used_bytes/r.driver_total_bytes : null) : r.utilization_percent;
        if(!U.isNum(v)){flush();return;}
        var point=xy(r,v); segment.push(point.join(","));
        var dot=add("circle",{cx:point[0],cy:point[1],r:2,fill:series[1]});
        var title=document.createElementNS(ns,"title"); title.textContent=utc(r.driver_sampled_at_unix_seconds)+" · "+series[2]+" "+v.toFixed(1)+"%"; dot.appendChild(title);
      }); flush();
    });
  }
  function render(p){
    var mem=p.memory || {}, d=mem.selected_device || {}, eng=p.engine || {}, rows=p.history || [];
    text("g-selection",mem.selection_status === "selected" ? (d.name || "—")+" · logical CUDA "+fmt.dash(d.logical_index)+" · "+fmt.dash(d.uuid) : mem.error || "selected device unresolved");
    text("g-notices",(p.notices || []).join("\n"));
    kv("g-device",[["name",d.name],["UUID",d.uuid],["logical CUDA device",d.logical_index],["visible runtime devices",d.visible_device_count],
      ["driver index",d.index],["PCI bus",d.pci_bus_id],["driver",d.driver],["compute capability",d.compute_cap],
      ["CUDA runtime capacity",fmt.bytes(d.runtime_total_bytes)],["driver capacity",fmt.bytes(d.total_bytes)],
      ["driver used VRAM",fmt.bytes(d.used_bytes)],["driver utilization",U.isNum(d.utilization_percent) ? d.utilization_percent+"%" : "—"],
      ["driver sampled at UTC",utc(d.driver_sampled_at_unix_seconds)],["runtime sampled at UTC",utc(d.runtime_sampled_at_unix_seconds)]]);
    kv("g-precision",[["BF16 supported",yes(mem.bfloat16_supported)],["BF16 refusal",mem.bfloat16_refusal || (mem.bfloat16_supported ? "eligible" : "unavailable")],
      ["FP8 supported",yes(mem.fp8_supported)],["FP8 refusal",mem.fp8_refusal || (mem.fp8_supported ? "eligible" : "unavailable")]]);
    text("g-masks","CUDA_VISIBLE_DEVICES="+(mem.cuda_visible_devices == null ? "unset" : JSON.stringify(mem.cuda_visible_devices))+" · CUDA_DEVICE_ORDER="+(mem.cuda_device_order == null ? "unset" : JSON.stringify(mem.cuda_device_order)));
    var inventory=$("g-inventory"); inventory.textContent="";
    (mem.gpus || []).forEach(function(g){ var box=mk("div","g-inventory"), title=mk("p","mono",(g.uuid === d.uuid ? "selected · " : "inventory · ")+fmt.dash(g.name)); box.appendChild(title);
      box.appendChild(mk("p","mono",fmt.dash(g.uuid)+" · driver index "+fmt.dash(g.index)+" · PCI "+fmt.dash(g.pci_bus_id)));
      box.appendChild(mk("p","muted",fmt.bytes(g.used_bytes)+" used / "+fmt.bytes(g.total_bytes)+" driver total · driver "+fmt.dash(g.driver)+" · sampled "+utc(g.driver_sampled_at_unix_seconds))); inventory.appendChild(box); });
    if(!(mem.gpus || []).length) inventory.appendChild(mk("p","muted","driver inventory unavailable"));
    text("g-phototag",p.phototag_command);
    text("g-history-note",rows.length ? rows.length+" distinct sample(s) · navy utilization, teal used VRAM · "+p.history_note : "no timestamped driver samples available");
    var history=$("g-history"); history.textContent="";
    rows.forEach(function(r){var tr=mk("tr"); [utc(r.driver_sampled_at_unix_seconds),fmt.bytes(r.used_bytes),U.isNum(r.utilization_percent) ? r.utilization_percent+"%" : "—"].forEach(function(v){tr.appendChild(mk("td","mono",v));}); history.appendChild(tr);}); chart(rows);
    text("g-model",p.model); var fit=p.model_fit || {};
    kv("g-fit",[["weight fit + eligibility",p.model_fit ? yes(fit.ok) : "—"],["reason",fit.reason || (fit.ok ? "eligible weight estimate" : "unavailable")],
      ["weight estimate",fmt.bytes(fit.need_bytes)],["selected runtime budget",fmt.bytes(mem.usable_bytes)],["fit ratio",mem.fit_ratio]]); text("g-fit-note",p.fit_note);
    var ladder=$("g-ladder"); ladder.textContent="";
    (p.recommendations || []).forEach(function(r){var item=mk("div","g-model"); item.appendChild(mk("strong",null,r.model));
      item.appendChild(mk("p","mono",(r.fp8 ? "FP8" : "BF16")+" · supported "+yes(r.supported)+" · weight fit "+yes(r.fits)+(r.recommended ? " · recommended" : "")));
      item.appendChild(mk("p",r.refusal_reason ? "g-notice" : "muted",r.refusal_reason || r.note)); ladder.appendChild(item);});
    if(!p.recommendations) ladder.appendChild(mk("p","muted","model ladder unavailable"));
    text("g-versions",eng.versions ? "vLLM "+fmt.dash(eng.versions.vllm)+" · torch "+fmt.dash(eng.versions.torch) : "engine versions unavailable");
    fields("g-settings",eng.resolved_settings); fields("g-kv",eng.kv_pool);
    text("g-engine-note",p.engine ? Object.keys(eng.unavailable || {}).map(function(k){return k+": "+eng.unavailable[k];}).join("\n") : "live engine settings and KV pool unavailable");
    var events=p.events || {}; text("g-event-path",events.path); text("g-event-note",events.note || "bounded newest records; not lifetime counts");
    if(events.tail_truncated) $("g-event-note").textContent += " · earlier records omitted by byte/row limit";
    text("g-event-error",events.error || ""); text("g-events",events.rows == null ? "events unavailable" : events.rows.length ? events.rows.map(function(r){return JSON.stringify(r);}).join("\n") : "no complete events in this tail");
  }
  try{render(JSON.parse($("faxl-gpu").textContent));}catch(e){text("g-live",e.message);}
  var busy=false;
  F.addPoll(function(){if(busy)return;busy=true;return F.api("/api/gpu").then(function(p){render(p);text("g-live","live · sample timestamps below");},function(e){text("g-live","GPU feed failed: "+e.message);}).then(function(){busy=false;});});
  F.start();
})();
"""

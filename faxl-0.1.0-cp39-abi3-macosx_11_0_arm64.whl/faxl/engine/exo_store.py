#!/usr/bin/env python3
"""exo_store.py — faxl's checkpoint ladder, for the exo backend.

exo's own prefix cache is in-RAM, per rank, and dies with the runner
processes on any topology event (plan.py:75-101 — a runner dies if ANY peer
rank fails, and nothing in the worker tree serialises state). This module is
the persistent store that replaces it: exo asks faxl what it already has,
faxl answers with a restored cache and the tail still to prefill, and exo
hands the resulting state back to be checkpointed.

Two calls, matching the two paths:

    lookup(model_id, token_ids) -> {caches, pos, prefill_tps} | None
    checkpoint(model_id, token_ids, pos, caches, ...) -> blob path | None

The lookup is the same ladder the mac-line proxy runs: one O(N) prefix-hash
pass (the compiled `faxl.prefix_hashes`), probe the persisted positions
deepest-first, and CONFIRM the stored token prefix byte-for-byte before
anything is restored. A hash match alone never serves — at ~2^-61 the
collision risk is negligible but not zero, and a wrong resume is a wrong
answer, so the confirm is the correctness authority.

Design constraints, none of them optional:

  GRID. States are persisted only at absolute multiples of SEG (256 — which
  is also granite-4.0-h's own `mamba_chunk_size`). Hybrid linear-attention
  models are boundary-dependent: folding the same tokens in a different chunk
  decomposition yields a different recurrent state, deterministically, so the
  reply reads as plausible rather than wrong. Persisting on the absolute grid
  is what lets a warm run re-enter the decomposition a cold run used.
  Off-grid entries are refused on load.

  RECURRENT STATE IS ATOMIC. The recurrent half of a hybrid model (Granite's
  mamba layers, Kimi's KDA layers) is one rolled-up tensor with no position
  index inside it. It cannot be cut at a token boundary or rebuilt from a
  suffix. save_prompt_cache/load_prompt_cache round-trip it whole, which is
  what we rely on; only the attention half is position-sliceable, and this
  module never tries to slice either.

  NAMESPACE. Every entry carries the canonical 7-tuple and its digest, and
  `verify_before_load` runs before any state is returned — one store safely
  serves many models, quantisations and configs.

  WRITE-ONCE, CONTENT-ADDRESSED. The key is (namespace, exact token prefix),
  so the same prefix stores once no matter how many sessions produce it.

Storage layout under FAXL_EXO_STORE (default ~/.faxl/exo-store):

    <ns_hash>:<phash>/blob.safetensors   the mlx prompt cache
    <ns_hash>:<phash>/meta.json          ns tuple + digest, pos, token count,
                                         hybrid flag, prefill_tps
    tokens/<phash>.json                  the verbatim token prefix (0600)
"""
import hashlib
import json
import os
import shutil
import time
import uuid

from mlx_lm.models.cache import load_prompt_cache, save_prompt_cache

from faxl.engine.media_regions import MediaRegion, truncate_to_first_mismatch
from faxl.engine import faxl_config
from faxl.engine.ns_identity import (NamespaceError, NamespaceIdentity,
                                     scoped_key, verify_before_load)
from faxl.engine.store_lifecycle import (append_usage, compact_usage,
                                         load_usage, pick_victims)

try:  # the compiled core: the same prefix hash the proxy's ladder uses
    import faxl as _faxl
except ImportError:  # pragma: no cover - the wheel is a hard requirement
    _faxl = None

# Absolute checkpoint grid. 256 matches the mac-line proxy's SEG and
# granite-4.0-h's mamba_chunk_size; a store written under one grid must not be
# read under another, so it is part of the namespace config hash below.
SEG = int(os.environ.get("FAXL_EXO_SEG", "256"))

# Read through faxl_config so the console can change it: env var first (a
# working copy driven by FAXL_EXO_STORE keeps behaving exactly as before),
# then ~/.faxl/config.json, then this default. Still resolved at import, so a
# change needs a restart -- which is what the console's Configure page says.
STORE_DIR = faxl_config.store_dir("exo")

# Below this the ladder is not worth a round trip: the prefill it would save
# is smaller than the blob load it would cost.
#
# THE SAME GATE BINDS BOTH PATHS. It is applied to the PROMPT length on
# lookup and on checkpoint, never to the checkpoint depth: gating the write on
# the grid-floored position while gating the read on the prompt length lets
# the two disagree, and the store then fills with blobs the ladder can never
# read. Measured: a 781-token prompt checkpointed at 768 and then missed
# forever, because 781 < GATE on the read side and 768 was written anyway.
GATE_TOKENS = int(os.environ.get("FAXL_EXO_GATE_TOKENS", "1024"))

# THE SAME DIAL AS THE MLX-LINE STORE. FAXL_STORE_CAP_GB, one variable, one
# product: a second env var meaning the same thing under another name is how
# two halves of one system drift apart.
#
# NOTHING IS PERMANENT, grid blobs included (AM 2026-09-01). A store with no
# cap is not a cache, it is a disk leak: this store reached 9.8GB from 14
# entries of a photo run, none of which could ever be read again.
STORE_CAP_GB = faxl_config.cap_gb()


class StoreError(RuntimeError):
    """The store cannot operate. Raised at open, never mid-request."""


LICENCE_FILE = os.path.expanduser(
    os.environ.get("FAXL_LICENCE", "~/.faxl-licence"))


def ensure_licence():
    """Load the licence key into the compiled core, once per process.

    The cache tier is gated inside the wheel: without a key `prefix_hashes`
    refuses and every prefill runs cold. The mlx proxy loads it at boot, but
    an embedded host does not — exo spawns its runner as a FRESH subprocess
    through multiprocessing, so whatever the parent did is not inherited.
    Loading it here means the store works in any host process rather than
    only inside the proxy.

    Never raises: an unlicensed store still serves (every lookup a miss,
    every prefill cold), which is the documented degrade-not-refuse
    behaviour. Returns True when the cache tier is entitled.
    """
    if _faxl is None:
        return False
    try:
        if _faxl.licence_status()[0]:
            return True                      # already loaded in this process
    except Exception:  # noqa: BLE001
        pass
    try:
        raw = open(LICENCE_FILE).read().strip()
    except OSError:
        print(f"!! faxl exo store: no licence at {LICENCE_FILE} — the cache "
              f"tier is DISABLED and every prefill will run cold", flush=True)
        return False
    key = "".join(ln for ln in raw.splitlines() if not ln.startswith("#"))
    try:
        cust, exp, _action = _faxl.set_licence(key)
    except Exception as e:  # noqa: BLE001 — a bad key must not kill the host
        print(f"!! faxl exo store: licence at {LICENCE_FILE} rejected ({e}) — "
              f"cache tier DISABLED", flush=True)
        return False
    days = (exp - time.time()) / 86400.0
    print(f"[faxl] licensed to {cust}; {days:.0f} days remaining", flush=True)
    return True


def _token_prefix_hash(token_ids):
    """Prefix hash at every position, from the compiled core so the exo
    backend and the mlx proxy agree bit-for-bit on what a prefix is."""
    if _faxl is None:
        raise StoreError(
            "the faxl wheel is not installed — the exo store cannot compute "
            "prefix hashes without it")
    return _faxl.prefix_hashes(list(token_ids))


# entry_key MOVED to media_regions (2026-09-25): the rule is pure hashlib over
# MediaRegion attributes, and keeping it here meant every non-mlx backend had
# to refuse it because this module imports mlx_lm at its top. Re-exported so
# existing callers keep working against ONE implementation.
from faxl.engine.media_regions import entry_key  # noqa: E402,F401


class ExoStore:
    """Persistent checkpoint store for one model on the exo backend."""

    def __init__(self, model_id, root=STORE_DIR, seg=SEG,
                 tenant=None, revision=None, dtype=None, quantisation="",
                 cap_gb=None):
        self.model_id = model_id
        self.root = os.path.expanduser(root)
        self.seg = int(seg)
        # The wheel gates the cache tier; an embedded host (exo's runner is a
        # fresh multiprocessing subprocess) has not loaded the key.
        self.entitled = ensure_licence()
        if self.seg <= 0:
            raise StoreError(f"checkpoint grid must be positive, got {seg}")
        self.tokens_dir = os.path.join(self.root, "tokens")
        try:
            os.makedirs(self.root, exist_ok=True)
            # 0700: token prefixes decode straight back to the prompt text.
            os.makedirs(self.tokens_dir, mode=0o700, exist_ok=True)
            os.chmod(self.tokens_dir, 0o700)
        except OSError as e:
            raise StoreError(f"cannot open store at {self.root}: {e}") from e

        # The grid is namespace-defining: state persisted on one grid must
        # never be served to a process using another.
        cfg = hashlib.sha256(json.dumps(
            {"seg": self.seg, "wire": "exo_mlx_prompt_cache_v1"},
            sort_keys=True).encode()).hexdigest()[:16]
        self.ns = NamespaceIdentity(
            tenant_domain=tenant or os.environ.get("FAXL_TENANT",
                                                   "gamakon-dev"),
            model=str(model_id),
            revision=revision or os.environ.get("FAXL_MODEL_REVISION",
                                                "unpinned"),
            backend="exo-mlx",
            dtype=dtype or quantisation or os.environ.get("FAXL_DTYPE",
                                                          "as-published"),
            cache_format="mlx_prompt_cache_v1",
            config_hash=cfg)
        self._ns_digest = self.ns.digest_hex()
        # Positions where this namespace is known to hold a checkpoint,
        # deepest first. Rebuilt from disk at open so a restart serves warm.
        self._positions = []
        self._index = {}          # phash(str) -> entry dir
        self._bytes = {}          # phash(str) -> blob size on disk
        # DURABLE USAGE, replayed at boot and compacted. Retention is earned
        # by use, so the hit history has to outlive the process -- a store
        # that forgets its hits on restart scores everything by file mtime,
        # which is LRU wearing a scoring costume.
        self.usage_path = os.path.join(self.root, "usage.jsonl")
        self.usage = load_usage(self.usage_path)
        self.cap_gb = float(cap_gb if cap_gb is not None else STORE_CAP_GB)
        # COMPACT AFTER THE SCAN, NOT BEFORE. _scan adopts history written
        # under the pre-fix key, and compaction is what makes that adoption
        # durable -- append_usage can only add single events, so a "this entry
        # already has 62 hits" fact has no other way onto disk.
        #
        # Compacting first was a silent hit-loss bug: the adopted count lived
        # only in memory, so a migrated store forgot every hit earned since the
        # last restart. Measured: bare=62 on disk, three real hits, reopen, and
        # the three were gone -- and would stay gone on every boot until
        # entry-key hits alone exceeded 62. Usage-based retention that forgets
        # its usage is LRU wearing a scoring costume.
        migrated = self._scan()
        if self.usage:
            compact_usage(self.usage_path, self.usage)

    # ---- boot ------------------------------------------------------------

    def _scan(self):
        """Index the entries belonging to THIS namespace. Foreign entries are
        left untouched — the store is shared by design."""
        found = 0
        migrated = 0
        try:
            names = os.listdir(self.root)
        except OSError as e:
            raise StoreError(f"cannot read store {self.root}: {e}") from e
        prefix = f"{self.ns.ns_hash():016x}:"
        positions = set()
        for name in names:
            if not name.startswith(prefix):
                continue
            d = os.path.join(self.root, name)
            meta_path = os.path.join(d, "meta.json")
            blob = os.path.join(d, "blob.safetensors")
            # SWEEP, don't skip. Each `continue` below used to leave the
            # directory on disk and out of the index -- so it held its bytes
            # against the cap, could never be read, and could never be evicted
            # either, because eviction only ever considers what is INDEXED.
            # That is a permanent leak, and on a network filesystem (where a
            # non-atomic rename can publish a half-written entry) it is the
            # expected outcome rather than a rare one. These defects cannot
            # resolve themselves, so the scan removes them.
            if not (os.path.exists(meta_path) and os.path.exists(blob)):
                self._sweep(d, "incomplete entry (no meta.json or no blob)")
                continue
            try:
                meta = json.load(open(meta_path))
            except (OSError, json.JSONDecodeError) as e:
                self._sweep(d, f"meta.json unreadable ({e})")
                continue
            pos = meta.get("pos")
            phash = meta.get("phash")
            if pos is None or phash is None:
                self._sweep(d, "meta.json has no pos/phash")
                continue
            if int(pos) % self.seg:
                # NOT swept. Written under a different grid: resuming it would
                # reintroduce the boundary divergence the grid prevents, but
                # the entry is intact and a store opened under that grid can
                # read it. Deleting another configuration's valid work is not
                # this scan's business.
                print(f"!! faxl exo store: entry at {pos} is off the "
                      f"{self.seg}-token grid — ignored", flush=True)
                continue
            key = meta.get("entry_key") or phash
            self._index[str(key)] = d
            try:
                self._bytes[str(key)] = os.path.getsize(blob)
            except OSError:
                self._bytes[str(key)] = 0
            positions.add(int(pos))
            found += 1
            # CARRY FORWARD HISTORY WRITTEN UNDER THE OLD KEY. Hits used to be
            # recorded against the bare phash while everything else used the
            # entry key. Now that both agree, a store written before the fix
            # holds real earned history under a name nothing looks up any more
            # -- and a blob that has been reused sixty times would come back as
            # never-used and go to the front of the eviction queue.
            #
            # Adopt it once, in favour of whichever record has seen more, and
            # leave the old row alone: it costs a few bytes and it is the only
            # copy if this ever has to be undone.
            if str(key) != str(phash) and str(phash) in self.usage:
                old_hits, old_last = self.usage[str(phash)]
                # ADOPT ONCE, THEN NEVER AGAIN. The old row is deliberately
                # LEFT ON DISK -- it is the only copy of pre-fix history and
                # nothing else can reconstruct it. But "prefer the larger"
                # cannot be the rule on every boot: once the entry has
                # inherited 62 hits and then earns 3 more of its own, a later
                # comparison of 62 against 3 would throw the 3 away, forever.
                #
                # So inheritance is recorded as part of the entry's own count:
                # after adoption the entry key holds the total, and the bare
                # row is never consulted for this entry again.
                new_hits, new_last = self.usage.get(str(key), (0, 0.0))
                if old_hits > new_hits:
                    self.usage[str(key)] = [old_hits, max(old_last, new_last)]
                    migrated += 1
        self._positions = sorted(positions, reverse=True)
        if migrated:
            print(f"[faxl] exo store: adopted usage history for {migrated} "
                  f"entr(ies) written before hits were keyed the way the index "
                  f"is — they would otherwise have looked never-used",
                  flush=True)
        print(f"[faxl] exo store {self.root}: {found} checkpoint(s) for "
              f"{self.model_id} ({self.live_bytes() / 1e9:.2f} GB of a "
              f"{self.cap_gb:g} GB cap, ns {self._ns_digest[:16]}, "
              f"grid {self.seg})", flush=True)
        return migrated

    # ---- paths -----------------------------------------------------------

    def _entry_dir(self, phash):
        return os.path.join(self.root, scoped_key(self.ns, phash))

    def _token_file(self, phash):
        # Token prefixes are content-addressed and deliberately unscoped:
        # identical ids are identical content whoever wrote them.
        return os.path.join(self.tokens_dir, f"{phash}.json")

    # ---- R1: lookup ------------------------------------------------------

    def lookup(self, model_id, token_ids, regions=None):
        """Deepest confirmed checkpoint at or below this prompt, or None.

        Returns {"caches", "pos", "prefill_tps"}. `pos` is how many tokens of
        the prompt the returned state covers; the caller prefills the rest.

        `regions` are the images THIS prompt carries (MediaRegion: where each
        one sits and a hash of its decoded pixels). The token ids cannot
        identify a picture -- an image is N copies of one pad id -- so a
        candidate whose stored images do not match the prompt's is refused and
        the ladder drops to a shallower rung.

        REFUSED, NOT TRIMMED. exo's in-RAM cache can shorten a match to the
        first differing image because a KV cache is sliceable by position. A
        persisted hybrid checkpoint is not: the recurrent half is one rolled-up
        tensor with no position inside it, so there is no way to hand back
        "the first 6000 tokens of this blob". The region check is therefore a
        PREDICATE on each candidate -- serve this depth or try a shallower one
        -- never an instruction to serve less than was stored.
        """
        if str(model_id) != str(self.model_id):
            # One store instance serves one model; a mismatch is a wiring bug.
            raise StoreError(
                f"store is for {self.model_id!r}, asked for {model_id!r}")
        ids = list(token_ids)
        n = len(ids)
        if n < GATE_TOKENS or not self._positions:
            return None
        qhash = _token_prefix_hash(ids)

        for pos in self._positions:
            if pos >= n - 1:
                continue          # need at least one tail token to generate
            if pos % self.seg:
                continue          # belt and braces; _scan already filtered
            # KEYED ON TOKENS AND PICTURES. The ids alone cannot tell two
            # photographs apart, so the key the write used is recomputed here
            # from this prompt's own images.
            covered = [r for r in (regions or []) if int(r.start_pos) < pos]
            key = entry_key(qhash[pos], covered, pos)
            d = self._index.get(key)
            if d is None:
                continue
            entry = self._load_entry(d, qhash[pos], ids, pos, regions, key=key)
            if entry is not None:
                return entry
        return None

    def _sweep(self, d, why):
        """Remove a defective entry DIRECTORY found during the scan.

        Not _quarantine: this runs before the entry is in `_index`, so there
        is nothing to un-index, and remove_blob would find no key. The token
        file is deliberately left alone -- it is SHARED between entries with
        the same prefix (two photographs at the same offsets), and the scan
        cannot tell whether a healthy sibling still needs it. An orphan token
        file is a few KB of JSON; a wrongly deleted one costs a live entry its
        byte confirm forever.
        """
        try:
            freed = os.path.getsize(os.path.join(d, "blob.safetensors"))
        except OSError:
            freed = 0
        try:
            shutil.rmtree(d)
        except OSError as e:
            print(f"!! faxl exo store: could not remove defective entry {d}: "
                  f"{e}", flush=True)
            return
        print(f"[faxl] exo store SWEPT {os.path.basename(d)} "
              f"({freed / 1e9:.2f} GB) — {why}", flush=True)

    def _quarantine(self, key, why):
        """A CORRUPT entry is REMOVED, not merely refused.

        Refusing was only half the job. A blob that fails to read can never be
        read -- not by this lookup and not by any later one -- yet it kept its
        bytes and its rung in the ladder, so every future prompt over that
        prefix paid a probe to be refused again, and the space stayed gone
        until the cap forced an eviction out. The store filled with entries
        the ladder could never read. Now the defect is the trigger: detect it
        once, remove it, and the next lookup meets a clean store.

        NOT every refusal is a defect. A namespace mismatch, an image
        mismatch, or a confirm fail are all CORRECT answers about a healthy
        entry that simply does not match this prompt -- those keep their blob
        and fall shallower. Only state that cannot be read reaches here.
        """
        try:
            freed = self.remove_blob(key)
        except Exception as exc:  # noqa: BLE001 — cleanup never fails a lookup
            print(f"!! faxl exo store: could not remove corrupt entry {key}: "
                  f"{type(exc).__name__}: {exc}", flush=True)
            return
        print(f"[faxl] exo store REMOVED corrupt entry {key} "
              f"({freed / 1e9:.2f} GB) — {why}", flush=True)

    def _load_entry(self, d, phash, ids, pos, regions=None, key=None):
        """Verify then load one candidate. Any defect refuses it LOUDLY and
        returns None so the ladder tries a shallower rung — a corrupt deep
        entry must never cost a valid shallow hit.

        A defect that can NEVER resolve itself -- unreadable meta, unreadable
        token prefix, a blob that will not load -- also removes the entry; see
        _quarantine. A mismatch is not a defect and keeps its blob."""
        meta_path = os.path.join(d, "meta.json")
        blob = os.path.join(d, "blob.safetensors")
        try:
            meta = json.load(open(meta_path))
        except (OSError, json.JSONDecodeError) as e:
            print(f"!! faxl exo store: unreadable meta at {d} ({e}) — "
                  f"trying shallower", flush=True)
            self._quarantine(key, f"meta.json unreadable ({e})")
            return None

        # NAMESPACE: full tuple + digest, before any state is touched.
        try:
            verify_before_load(self.ns, meta.get("ns"), meta.get("ns_digest"))
        except (NamespaceError, KeyError) as e:
            print(f"!! faxl exo store: NAMESPACE REFUSED at {d}: {e} — "
                  f"trying shallower", flush=True)
            return None

        # CONFIRM: the stored token prefix, byte for byte. This is what makes
        # a hit exact rather than a hash guess.
        tokf = self._token_file(phash)
        try:
            stored = json.load(open(tokf))
        except (OSError, json.JSONDecodeError) as e:
            print(f"!! faxl exo store: token prefix unreadable at {tokf} "
                  f"({e}) — trying shallower", flush=True)
            # Without the token file the byte confirm can never run, so this
            # blob can never be served -- however intact the blob itself is.
            self._quarantine(key, f"token prefix unreadable ({e})")
            return None
        if stored != ids[:pos]:
            print(f"!! faxl exo store: CONFIRM FAIL at pos={pos} "
                  f"phash={phash} — refusing, trying shallower", flush=True)
            return None

        # IMAGES: the tokens confirmed, but an image is N copies of one pad id
        # and says nothing about the picture. Two different photographs of the
        # same size produce a byte-identical prefix and pass the confirm above,
        # so the pictures are compared separately -- measured, without this 24
        # different photos received one identical caption.
        #
        # A stored depth INSIDE an image is fine and is the common case (in a
        # 7442-token insurance prompt only one grid multiple is clear of every
        # image). It simply requires that the picture at that offset is the
        # same one, which is exactly what this compares.
        stored_regions = [MediaRegion.from_dict(r)
                          for r in (meta.get("media_regions") or [])]
        if truncate_to_first_mismatch(pos, stored_regions,
                                      list(regions or [])) != pos:
            print(f"!! faxl exo store: IMAGE MISMATCH at pos={pos} — this "
                  f"prefix held different pictures; trying shallower",
                  flush=True)
            return None

        try:
            caches = load_prompt_cache(blob)
        except Exception as e:  # noqa: BLE001 — any load defect falls cold
            print(f"!! faxl exo store: blob load failed at {blob} ({e}) — "
                  f"trying shallower", flush=True)
            # This is the network-filesystem case: a rename that is not atomic
            # leaves a partially visible blob. safetensors refuses it, and it
            # would otherwise sit there full-size and unreadable for good.
            self._quarantine(key, f"blob will not load ({e})")
            return None

        # A CONFIRMED, SERVED HIT — recorded here and nowhere else. Every
        # earlier return in this method is a REFUSED candidate (namespace,
        # confirm, image mismatch, unreadable blob) and must not count: a
        # refused rung that scored itself a hit would protect the very blob
        # the ladder just rejected.
        self._record_hit(key if key is not None else phash)

        return {"caches": caches, "pos": pos,
                "prefill_tps": float(meta.get("prefill_tps", 0.0)),
                "hybrid": bool(meta.get("hybrid", False)),
                "phash": str(phash)}

    def _record_hit(self, key):
        """Durably note that this blob earned its place.

        KEYED THE WAY THE INDEX IS KEYED, which is `entry_key` -- the tokens
        AND the pictures. This used to record the bare phash while `_index`,
        `evict_over_cap` and `usage_score` all used the entry key, and for a
        text-only entry the two strings are identical, so the mismatch was
        invisible until an image-bearing store filled up.

        What it cost, measured on a live 71-entry store at 59.61 of a 60 GB
        cap: every blob with 62 real hits scored as 0 hits, giving it an
        eviction score of ~160,000 against 645 for the one entry whose key
        happened to match. The ranking was INVERTED -- the store was about to
        delete its most-reused blobs first, which is the precise opposite of
        what usage-based retention exists to do, and the eviction log would
        have said "score 0 hit(s)" and corroborated itself.
        """
        now = time.time()
        key = str(key)
        hits, _ = self.usage.get(key, (0, 0.0))
        self.usage[key] = [hits + 1, now]
        try:
            append_usage(self.usage_path, key, now)
        except OSError as e:
            # Losing a hit record costs retention accuracy, never the reply.
            print(f"!! faxl exo store: could not record hit for {key} "
                  f"({e})", flush=True)

    # ---- retention -------------------------------------------------------

    def live_bytes(self):
        return sum(self._bytes.values())

    def remove_blob(self, phash):
        """Delete one entry: blob, meta, token prefix, and every index that
        points at it.

        _positions MUST be rebuilt, not left alone. It drives which rungs the
        ladder probes, so a position left behind for a deleted blob makes
        every later lookup probe a phash that is gone -- wasted RPCs on the
        mlx line, and here a guaranteed miss at the deepest rung, which is
        the one most worth hitting.
        """
        key = str(phash)
        d = self._index.pop(key, None)
        self._bytes.pop(key, None)
        freed = 0
        tok_phash = None
        if d and os.path.isdir(d):
            try:
                freed = os.path.getsize(os.path.join(d, "blob.safetensors"))
            except OSError:
                pass
            try:
                tok_phash = json.load(
                    open(os.path.join(d, "meta.json"))).get("phash")
            except (OSError, ValueError):
                pass
            shutil.rmtree(d, ignore_errors=True)
        # THE TOKEN FILE IS SHARED. Two photographs at the same offsets have
        # the SAME token prefix and so the same token file, while being
        # different entries. Deleting it with the first entry would leave the
        # second unable to run its byte confirm -- "token prefix unreadable",
        # a permanent miss on a blob that is still on disk. It goes only when
        # nothing left points at it.
        if tok_phash is not None and not self._phash_in_use(tok_phash):
            try:
                os.remove(self._token_file(tok_phash))
            except OSError:
                pass
        # Rebuild the probe ladder from what actually survives.
        positions = set()
        for ph, entry in self._index.items():
            try:
                positions.add(int(json.load(
                    open(os.path.join(entry, "meta.json")))["pos"]))
            except (OSError, ValueError, KeyError):
                continue
        self._positions = sorted(positions, reverse=True)
        return freed

    def _phash_in_use(self, phash):
        """Does any SURVIVING entry still confirm against this token file?"""
        for entry in self._index.values():
            try:
                if str(json.load(open(os.path.join(entry, "meta.json")))
                       .get("phash")) == str(phash):
                    return True
            except (OSError, ValueError):
                continue
        return False

    def evict_over_cap(self, protect=frozenset()):
        """Bring the store back under its cap, worst-scoring blob first.

        Runs AFTER a write lands rather than refusing writes at the cap: a
        refuse-at-cap guard freezes live traffic out behind stale blobs, which
        is what this replaced on the mlx line.

        Scoring is store_lifecycle.pick_victims -- the same function the mlx
        store uses, so both halves of the product retain the same things.
        """
        over = self.live_bytes() - self.cap_gb * 1e9
        if over <= 0:
            return []
        pool = [(ph, os.path.join(self._index[ph], "blob.safetensors"),
                 self._bytes.get(ph, 0))
                for ph in list(self._index)]
        victims = pick_victims(pool, self.usage, time.time(), over, protect)
        if not victims:
            print(f"!! faxl exo store: {self.live_bytes() / 1e9:.2f} GB over "
                  f"the {self.cap_gb:g} GB cap but nothing evictable "
                  f"({len(self._index)} entr(ies) protected) — overshoot "
                  f"accepted", flush=True)
            return []
        gone = []
        for ph, _nbytes in victims:
            freed = self.remove_blob(ph)
            gone.append(ph)
            print(f"[faxl] exo store evicted {ph} ({freed / 1e9:.2f} GB, "
                  f"score {self.usage.get(str(ph), [0, 0])[0]} hit(s)) — "
                  f"now {self.live_bytes() / 1e9:.2f} GB", flush=True)
        return gone

    # ---- R2: checkpoint --------------------------------------------------

    def checkpoint(self, model_id, token_ids, pos, caches,
                   snapshots=None, hybrid=False, prefill_tps=0.0,
                   regions=None):
        """Persist `caches` as the state covering token_ids[:pos].

        `pos` MUST be how many tokens the caller's cache actually holds — not
        a rounded-down grid position, and not the prompt length. The store
        cannot inspect an mlx cache to find out (a KVCache exposes an offset,
        an ArraysCache is one rolled-up tensor with no position in it at all),
        so this is a contract the caller has to honour.

        Getting it wrong is silent corruption, not a bad hit: record a blob as
        covering 1536 tokens when it really holds 1650 and every resume
        re-prefills 114 tokens that are already folded in. Attention layers
        mask it; recurrent layers do not, and the reply reads as plausible
        rather than wrong. Measured on granite-4.0-h: a one-token shift in the
        seed, output diverging at the first decoded token.

        `pos` must therefore be on the grid AND equal to the cache's real
        depth: prefill to a grid multiple, checkpoint there, then prefill the
        remainder. `grid_floor` computes the right stopping point.

        `regions` are the images the prompt carried. They are stored with the
        state so a later lookup can tell whether the pictures at those offsets
        are the same ones -- the token ids cannot say, and without them this
        state would be served to any prompt with images of the same sizes.

        Write-once: an identical prefix is stored once, ever. Returns the
        entry directory, or None when the write was skipped (already stored,
        below the gate, or off-grid).
        """
        if str(model_id) != str(self.model_id):
            raise StoreError(
                f"store is for {self.model_id!r}, asked for {model_id!r}")
        pos = int(pos)
        if pos <= 0 or pos % self.seg:
            # Refuse rather than write something the ladder would then refuse
            # to read: an off-grid blob is dead weight and a latent
            # correctness trap.
            print(f"!! faxl exo store: refusing to checkpoint at {pos} — not "
                  f"on the {self.seg}-token grid", flush=True)
            return None
        full = list(token_ids)
        if len(full) < GATE_TOKENS:
            # The read path skips the ladder below this length, so a blob
            # written here could never be served. Same gate, both paths.
            return None
        ids = full[:pos]
        if len(ids) < pos:
            raise StoreError(
                f"asked to checkpoint {pos} tokens but only {len(ids)} given")

        phash = _token_prefix_hash(ids)[pos]
        covered = [r for r in (regions or []) if int(r.start_pos) < pos]
        # AN IMAGE WE CANNOT IDENTIFY makes this state unservable: the lookup
        # predicate refuses an empty hash on either side, by design, so the
        # blob would occupy the cap forever and never answer anything.
        if any(not str(r.content_hash) for r in covered):
            print(f"!! faxl exo store: refusing to checkpoint at {pos} — it "
                  f"covers an image with no content hash, which could never "
                  f"be served back", flush=True)
            return None
        key = entry_key(phash, covered, pos)
        d = self._entry_dir(key)
        if os.path.exists(os.path.join(d, "meta.json")):
            self._index[str(key)] = d            # already stored (write-once)
            return None

        tmp = d + f".tmp{os.getpid()}-{uuid.uuid4().hex[:8]}"
        os.makedirs(tmp, exist_ok=True)
        try:
            # The recurrent half rides along whole inside the prompt cache —
            # it has no position index to cut on.
            save_prompt_cache(os.path.join(tmp, "blob.safetensors"), caches)
            meta = {"ns": self.ns.as_dict(), "ns_digest": self._ns_digest,
                    "model_id": str(self.model_id), "pos": pos,
                    # phash identifies the TOKEN prefix (and so the token
                    # file, which really is content-addressed); entry_key adds
                    # the pictures, and is what the index is keyed on.
                    "phash": str(phash), "entry_key": str(key),
                    "n_tokens": len(ids),
                    "hybrid": bool(hybrid), "grid": self.seg,
                    "prefill_tps": float(prefill_tps),
                    "n_snapshots": len(snapshots or []),
                    # Only the regions this blob actually covers. One starting
                    # beyond `pos` was never folded into this state and must
                    # not constrain a prompt that reuses it.
                    "media_regions": [r.to_dict() for r in covered],
                    "written_at": time.time()}
            with open(os.path.join(tmp, "meta.json"), "w") as f:
                json.dump(meta, f)
                f.flush()
                os.fsync(f.fileno())
            self._write_token_prefix(phash, ids)
            os.replace(tmp, d)      # atomic publish
        except OSError as e:
            self._cleanup(tmp)
            print(f"!! faxl exo store: checkpoint at {pos} FAILED ({e}) — "
                  f"nothing stored", flush=True)
            return None
        except Exception as e:  # noqa: BLE001 — a save failure must not 500
            self._cleanup(tmp)
            print(f"!! faxl exo store: checkpoint at {pos} FAILED "
                  f"({type(e).__name__}: {e}) — nothing stored", flush=True)
            return None

        self._index[str(key)] = d
        try:
            self._bytes[str(key)] = os.path.getsize(
                os.path.join(d, "blob.safetensors"))
        except OSError:
            self._bytes[str(key)] = 0
        if pos not in self._positions:
            self._positions = sorted(set(self._positions) | {pos},
                                     reverse=True)
        # RETENTION, after the write, protecting what was just written: a
        # store at its cap must not evict the entry it is in the middle of
        # storing, or it thrashes and never keeps anything.
        self.evict_over_cap(protect={str(key)})
        return d

    def _write_token_prefix(self, phash, ids):
        """The verbatim prefix the confirm compares against. REQUIRED for
        correctness, and 0600 because it decodes back to the prompt: opened
        with the mode, never chmod-after-write, which leaves a window."""
        tokf = self._token_file(phash)
        if os.path.exists(tokf):
            return                                  # content-addressed
        tmpf = tokf + f".tmp{uuid.uuid4().hex[:8]}"
        fd = os.open(tmpf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(list(ids), f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmpf, tokf)

    @staticmethod
    def _cleanup(tmp):
        try:
            for n in os.listdir(tmp):
                os.remove(os.path.join(tmp, n))
            os.rmdir(tmp)
        except OSError:
            pass

    def grid_floor(self, n_tokens):
        """The deepest grid position at or below `n_tokens`.

        The intended write sequence, which keeps the recorded depth equal to
        the cache's real depth:

            stop = store.grid_floor(len(prompt) - 1)
            prefill(cache, prompt[:stop])          # cache now holds `stop`
            store.checkpoint(model, prompt, stop, cache, ...)
            prefill(cache, prompt[stop:-1])        # finish the tail

        Returns 0 when nothing is worth storing.
        """
        n = int(n_tokens)
        return (n // self.seg) * self.seg if n >= self.seg else 0

    # ---- introspection ---------------------------------------------------

    def positions(self):
        """Checkpoint depths this namespace holds, deepest first."""
        return list(self._positions)

    def blob_rows(self):
        """One row per blob in THIS namespace, for the console's scatter.

        Returns [{phash, hits, last_used, bytes, pos}] — the contract
        faxl_console.shape_blobs consumes.

        THE KEYING TRAP, and it is silent. `self._index` is keyed by
        `entry_key`. Hits are now recorded under that same key, but a store
        written before that fix holds its history under the bare phash, so both
        are consulted and the larger wins -- see _record_hit for what the
        mismatch cost. A blob never hit reports its file mtime, the same
        convention store_lifecycle.usage_score uses when it scores one with no
        history.
        no recorded hit, so the plot shows what eviction sees.

        Never raises. The index is snapshotted (`checkpoint`/`remove_blob`
        mutate it on the request thread while the console polls on another)
        and every per-entry read is guarded: a blob unlinked by an eviction
        between listing and stat drops out of the plot rather than 500ing the
        console.
        """
        rows = []
        # list(...) FIRST, deliberately: the console reads this on Flask's
        # thread while checkpoint and eviction write on the request thread.
        # CPython builds that list under the GIL without releasing it, so the
        # snapshot is atomic and a concurrent write cannot raise "changed size
        # during iteration" here. Measured: 3,000 list(d.items()) against a dict
        # under continuous insert/delete from another thread, zero errors --
        # including with an os.stat inside the loop body. Iterating self._index
        # DIRECTLY would not have that guarantee, so do not "simplify" it away.
        for key, d in list(self._index.items()):
            try:
                meta = json.load(open(os.path.join(d, "meta.json")))
            except (OSError, ValueError):
                continue        # unreadable or vanished mid-iteration
            phash = meta.get("phash")
            if phash is None:
                continue
            phash = str(phash)
            try:
                st = os.stat(os.path.join(d, "blob.safetensors"))
            except OSError:
                continue        # blob gone (eviction race) — not plottable
            # USAGE IS KEYED THE WAY THE INDEX IS, i.e. by entry key. The
            # bare phash is still consulted as a fallback: a store written
            # before hits were re-keyed carries its history there, and _scan
            # only adopts rows for entries it could read. Prefer whichever has
            # seen more, so a migrated store never plots a blob as colder than
            # it really is, and never double-counts by adding the two.
            hits, last = self.usage.get(str(key), (0, 0.0))
            old_hits, old_last = self.usage.get(phash, (0, 0.0))
            if old_hits > hits:
                hits, last = old_hits, old_last
            if not last:
                last = st.st_mtime
            rows.append({"phash": phash, "hits": int(hits),
                         "last_used": float(last), "bytes": st.st_size,
                         "pos": meta.get("pos")})
        return rows

    def store_rows(self):
        """One row per NAMESPACE on disk, not just this one.

        Returns [{ns_hash, model, entries, bytes}].

        WHY THIS IS NOT `len(self)`. The namespace hash folds in the model id,
        so a store holding 71 entries written by other models matches 0 of
        them in `_scan` and reports zero — while the bytes sit on disk,
        invisible to the console AND unreclaimable, because `cap_gb` is
        enforced per namespace and eviction never looks outside `_index`.
        This is what lets the console say "56 GB cached, 0 GB for this model"
        instead of a bare zero.

        READ-ONLY ACCOUNTING. Off-grid entries are NOT filtered out here even
        though `_scan` refuses them: they are unreadable, but they still
        occupy the disk, and the point of this row is the disk. That means
        this namespace's `entries` here can legitimately exceed `len(self)`.

        Never raises: an unreadable store returns [].
        """
        try:
            names = os.listdir(self.root)
        except OSError:
            return []
        agg = {}
        for name in names:
            if ":" not in name:
                continue        # tokens/, usage.jsonl, ...
            d = os.path.join(self.root, name)
            meta_path = os.path.join(d, "meta.json")
            blob = os.path.join(d, "blob.safetensors")
            try:
                st = os.stat(blob)
                meta = json.load(open(meta_path))
            except (OSError, ValueError):
                # No blob, no meta, or a half-written ".tmp<pid>-<hex>"
                # directory a concurrent checkpoint is still filling.
                continue
            ns_hash = name.split(":", 1)[0]
            # The model name lives in the stored namespace tuple; model_id is
            # the same string written alongside it, and is the fallback rather
            # than dropping a row whose ns tuple is malformed.
            ns = meta.get("ns") or {}
            model = ns.get("model") if isinstance(ns, dict) else None
            model = model or meta.get("model_id") or "unknown"
            row = agg.setdefault(ns_hash, {"ns_hash": ns_hash,
                                           "model": str(model),
                                           "entries": 0, "bytes": 0})
            row["entries"] += 1
            row["bytes"] += st.st_size
        return sorted(agg.values(), key=lambda r: -r["bytes"])

    def __len__(self):
        return len(self._index)


def open_store(model_id, **kw):
    """Open the exo-backend store for one model.

    Raises StoreError if it cannot be opened — a cache that silently stops
    caching is the failure this line exists to prevent, so the caller decides
    whether to run without one and says so loudly.
    """
    return ExoStore(model_id, **kw)

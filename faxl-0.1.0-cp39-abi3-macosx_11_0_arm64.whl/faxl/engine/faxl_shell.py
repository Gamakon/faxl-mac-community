# Vendored engine module (faxl_shell.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""The page shell — one wrapper, so every console page is the same website.

The customer bought faxl on faxl.ai and then opens this on their own machine.
It has to be recognisably the same product, not an operator's instrument panel
bolted to the side of one. So this reproduces the site's own structure exactly:
skip link, `header.site-head` with the mark and nav, `main#main > .wrap`, and
`footer.site-foot` with the ten-colour ramp strip.

USE THE SITE'S VOCABULARY, NOT NEW CLASSES. faxl-website/site/css/style.css is
opinionated and its comments say why: *"LISTS — facts, not cards. No boxes round
prose."* There is deliberately no .card, no .grid, no utility classes. When you
add a screen, reach for what is already there:

    .figures > .figure > span.n + span.what   a KPI, unboxed
    dl.spec > div > dt + dd                   a label/value row
    .tag / .tag.warn                          a status badge
    table inside .table-scroll                tabular data
    .cta / .cta-quiet inside .actions         buttons, ONE primary per view
    .keybox                                   a monospace value
    .kicker                                   the label above an h2
    .section                                  a block; siblings get a hairline

Page-specific CSS goes in an inline <style> in the head, which is how shop.html
and account.html do it on the public site. Do not grow style.css: it is copied
from the website and should stay diffable against it.

WHAT IS DELIBERATELY DIFFERENT FROM THE PUBLIC SITE. The console is a private
tool on someone's own machine, so: `noindex` (it must never be crawled if the
bind is widened), no canonical/og/twitter tags, no external links -- the site's
footer points at gamakon.ai, which is a dead end with the network off, and these
customers bought sovereign AI. Everything is served from faxl_brand's data URIs.
"""

import html as _html

from faxl.engine.faxl_brand import LOGO_SVG_URI, brand_head

# The ten brand colours, in the site's order. Copied from the footer of every
# page on faxl-website; the site sets them inline on the spans and so do we.
_RAMP = ("#51b3aa", "#c1a14e", "#2a3640", "#6d9f40", "#5e3538",
         "#962729", "#a2411a", "#b99aa0", "#e196c0", "#d4494c")


def _ramp_strip():
    spans = "".join(f'<span style="background:{c}"></span>' for c in _RAMP)
    return f'<div class="ramp-strip" aria-hidden="true">{spans}</div>'


def nav_html(items, current=None):
    """The top nav. `items` is [(label, href)]; `current` marks the page we are
    on with aria-current, which the stylesheet underlines in gold."""
    out = []
    for label, href in items:
        cur = ' aria-current="page"' if label == current else ""
        # One item leaves the console (the shop, on the public site). It opens
        # in a new tab so a person mid-task does not lose the console, and it
        # is marked so that is not a surprise.
        ext = ' target="_blank" rel="noopener"' if href.startswith("http") else ""
        out.append(f'<a href="{href}"{cur}{ext}>{_html.escape(label)}</a>')
    return "".join(out)


def footer_html(items, agent_href=None):
    """The site footer, minus its outbound links.

    The public footer ends with gamakon.ai. Here that is a link off the machine
    from a tool whose whole promise is that it keeps working when the internet
    does not, so the link list is the console's own sections instead.

    That rule is why the shop is filtered out here: it is in the TOP nav, where
    it is a deliberate act with a marked outbound link, and leaving it in the
    footer too would put a dead link at the bottom of every page on a
    disconnected machine.
    """
    links = "".join(f'<a href="{href}">{_html.escape(label)}</a>'
                    for label, href in items if not href.startswith("http"))
    # Spec §2: every human page carries "agent view", the same URL in the
    # other mode. Only the analytics page had one, and it pointed at /console.
    if agent_href:
        links += f'<a href="{_html.escape(agent_href)}">agent view</a>'
    return (f'<footer class="site-foot"><div class="wrap">'
            f'<p class="foot-links">{links}</p>'
            f'<p class="foot-small"><strong>faxl</strong> is a Gamakon Ltd '
            f'product. '
            f'&copy; 2026 Gamakon Ltd.</p>'
            f'{_ramp_strip()}</div></footer>')


# .tag and .keybox are NOT in the site stylesheet — on faxl.ai they are declared
# page-locally in shop.html and account.html, which is that site's convention for
# a component. The console needs them on every page, so they live here, copied
# from account.html verbatim so the two stay recognisably the same thing.
CONSOLE_CSS = """
/* The site gives every link a trailing arrow, which reads as "go do this". On
   a site map that is six of them in a row, and on a footer link list, seven.
   A navigation bar is not a call to action. */
.site-nav a:after,.foot-links a:after,.brand:after{content:""}
.tag{font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;
  padding:.18rem .5rem;border:1px solid var(--rule-gold);border-radius:2px;
  color:var(--muted);white-space:nowrap}
.tag.warn{color:var(--ramp-oxblood);border-color:var(--ramp-oxblood)}
.keybox{font-family:var(--mono);font-size:.78rem;word-break:break-all;
  background:var(--card);border:1px solid var(--rule);border-radius:3px;
  padding:.8rem;margin:.7rem 0;white-space:pre-wrap}
/* A row of facts, as account.html renders a licence: hairlines, never a box. */
.row{border-top:1px solid var(--rule);padding:1.3rem 0}
.row:last-of-type{border-bottom:1px solid var(--rule)}
.row-head{display:flex;flex-wrap:wrap;align-items:baseline;gap:.5rem 1rem;
  margin-bottom:.6rem}
.row-head h3{margin:0}
/* Numbers are compared down a column, so they line up and use the mono face. */
td.num,th.num{text-align:right;font-family:var(--mono);font-size:.85rem}
"""


def page(*, title, nav_items, current, body, head_extra="", hero=None,
         alt_json=None, agent_href=None):
    """Wrap `body` in the faxl.ai shell and return a complete HTML document.

    body       already-built HTML for inside .wrap -- normally one or more
               <section class="section"> blocks.
    head_extra page-specific <style>, following the public site's convention.
    hero       optional HTML placed ABOVE <main>, as index.html does.
    alt_json   URL of this page's JSON view, advertised to agents via
               <link rel="alternate">, which is how the agent renderer has
               always exposed itself. Keep doing it here.
    """
    alt = (f'<link rel="alternate" type="application/json" href="{alt_json}">'
           if alt_json else "")
    return (
        "<!doctype html><html lang=\"en-GB\"><head><meta charset=\"utf-8\">"
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        # Never crawled: this is somebody's private console, and FAXL_HOST can
        # widen the bind beyond loopback.
        '<meta name="robots" content="noindex, follow">'
        f"<title>{_html.escape(title)} — faxl</title>"
        f"{brand_head()}<style>{CONSOLE_CSS}{TABLE_CSS}</style>{alt}{head_extra}"
        "</head><body>"
        '<a class="skip-link" href="#main">Skip to content</a>'
        '<header class="site-head">'
        '<a class="brand" href="/console" aria-label="faxl home">'
        f'<img src="{LOGO_SVG_URI}" alt="" width="28" height="32"><span>faxl</span></a>'
        f'<nav class="site-nav" aria-label="Main">{nav_html(nav_items, current)}</nav>'
        "</header>"
        f"{hero or ''}"
        f'<main id="main"><div class="wrap">{body}</div></main>'
        f"{footer_html(nav_items, agent_href)}"
        "</body></html>")


def section(*, kicker=None, heading=None, body="", id=None):
    """One `.section`. Siblings are separated by a hairline, never a box."""
    ident = f' id="{id}"' if id else ""
    k = f'<p class="kicker">{_html.escape(kicker)}</p>' if kicker else ""
    h = f"<h2>{_html.escape(heading)}</h2>" if heading else ""
    return f'<section class="section"{ident}>{k}{h}{body}</section>'


class raw(str):
    """Mark a string as ALREADY HTML, so the helpers below leave it alone.

    SAFE BY DEFAULT, UNSAFE ON PURPOSE. These helpers used to insert every value
    verbatim, which was correct for their callers and one careless line away from
    an XSS: the values are telemetry, and telemetry carries model names and
    client strings taken from request headers a caller controls. Escaping by
    default means a future caller has to ASK for raw HTML, in a word that says
    what it is, rather than getting it by not thinking about it.

        spec([("model", r["model"])])              # escaped, the safe default
        spec([("state", raw(tag("ok")))])          # markup, deliberately
    """
    __slots__ = ()


def _h(v):
    return str(v) if isinstance(v, raw) else _html.escape(str(v))


def figures(items):
    """A row of KPIs. `items` is [(number, what)].

    NOTHING HERE INVENTS A NUMBER. A value the proxy could not measure must
    reach this function as the word it should display, or not be passed at all.
    Rendering 0 for "we did not measure it" is the failure this console exists
    to avoid.
    """
    out = []
    for n, what in items:
        out.append(f'<div class="figure"><span class="n">{_h(n)}</span>'
                   f'<span class="what">{_h(what)}</span></div>')
    return f'<div class="figures">{"".join(out)}</div>'


def spec(rows):
    """A definition list of label/value pairs -- the site's settings-row shape.
    `rows` is [(label, value)]; wrap a value in raw() to pass markup."""
    out = "".join(f"<div><dt>{_html.escape(str(k))}</dt><dd>{_h(v)}</dd></div>"
                  for k, v in rows)
    return f"<dl class=\"spec\">{out}</dl>"


def tag(text, warn=False):
    """A status badge. Returns raw() because it IS markup, already escaped."""
    cls = "tag warn" if warn else "tag"
    return raw(f'<span class="{cls}">{_html.escape(str(text))}</span>')


# Tables sit ON a card, like the figure tiles and the welcome cards. The log
# page rendered bare on the page ground while the analytics table had a bordered
# scroll box of its own -- the same data in two designs. This is the one
# definition; _shell_style() copies it into the standalone asset too.
TABLE_CSS = """
  .table-card{background:var(--card);border:1px solid var(--rule);
    margin:1.6rem 0}
  .table-scroll{max-height:26rem;overflow:auto}
  .table-card table{margin:0}
  .table-card thead th{position:sticky;top:0;background:var(--card);
    border-top:0;border-bottom:1px solid var(--rule);
    padding:.7rem .9rem;z-index:1}
  .table-card td{padding:.6rem .9rem;border-top:1px solid var(--rule)}
  .table-card tbody tr:first-child td{border-top:0}
"""


def table(headers, rows, empty="Nothing to show yet."):
    """A table, or an honest sentence when there is nothing in it.

    An empty table that renders as a bare header row, or as nothing at all,
    looks identical to one that failed to load. Say which.
    """
    if not rows:
        return f'<p class="smallprint">{_html.escape(empty)}</p>'
    head = "".join(f"<th>{_html.escape(str(h))}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{_h(c)}</td>" for c in r) + "</tr>"
                   for r in rows)
    return (f'<div class="table-card"><div class="table-scroll">'
            f'<table><thead><tr>{head}</tr></thead>'
            f"<tbody>{body}</tbody></table></div></div>")

# Vendored engine module (faxl_config.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl_config.py — settings that survive a restart.

THE PROBLEM THIS SOLVES. The store path and the cap are module-level
constants, read from the environment at IMPORT time:

    STORE_DIR    = os.path.expanduser(os.environ.get("FAXL_EXO_STORE", ...))
    STORE_CAP_GB = float(os.environ.get("FAXL_STORE_CAP_GB", "60"))

So the console cannot change them in a running proxy, and it cannot change
them by setting an environment variable either -- the launcher starts a new
process from a shell script, and nothing the console exports reaches it. A
console that offers a setting it cannot make stick is worse than no console.

The answer is a file both sides read: the console writes it, and every faxl
process reads it at import. One file, one meaning, and the same values
whether the proxy was started from the console or from the launcher by hand.

PRECEDENCE, highest first:

    1. the environment      FAXL_EXO_STORE=... faxl_exo_up.sh
    2. this config file     ~/.faxl/config.json
    3. the built-in default

The environment stays on top deliberately: driving a working copy with an env
var must keep working, and a developer who exports something has said what
they want more recently than a file did.

WHICH BACKEND AND WHICH MODEL live here too (2026-09-21). They used to be
FAXL_BACKEND / FAXL_MODEL, read at import, and chosen in practice by WHICH of
two launchers ran (faxl_up.sh for mlx, faxl_exo_up.sh for exo). That does not
survive managing customers: support cannot ask "which script did you run, and
what was exported in that shell", and the console could only change backend by
choosing a script. Now the console writes the choice here, the one launcher
(faxl_start.sh) reads it, and the proxy reads it at import -- the same pattern
as the store path. The env vars still win, for the same reason as above, and
describe() says for every key WHERE its value came from, because "it says
exo but I picked mlx" is answered in one line when the answer is "env".

    python -m faxl.engine.faxl_config --show            what, and from where
    python -m faxl.engine.faxl_config --get backend     one value, for a shell
    python -m faxl.engine.faxl_config --set backend=exo write one setting
    python -m faxl.engine.faxl_config --fits            does the model fit here

THE MODEL MUST FIT (2026-09-21). A switch from exo to mlx kept the cluster's
model (MiniMax-M2.7-4bit, ~130 GB), the proxy called mlx_lm.load on it, and
one Mac began downloading 130 GB with the console dark for the duration. Two
rules since, both enforced here and by the console:

    1. The default is a LADDER sized to the machine (DEFAULT_MODEL_LADDER,
       2026-09-22). Its FLOOR -- DEFAULT_MODEL, what an 8 GB Mac and a Mac
       whose RAM cannot be read come up on -- is under
       DEFAULT_MODEL_BUDGET_BYTES (10 GB, low on purpose). Rungs above the
       floor are elected only by a machine measured able to hold them, so
       they may exceed the budget: the budget is a promise about a FRESH
       INSTALL on the smallest Mac, not a cap on a 64 GB Studio.
       SHIPPED_DEFAULTS records every rung's size and a test pins them.
    2. Nothing is configured that does not fit. need = the model's bytes (on
       disk for mlx, exo's catalogue for exo); have = RAM x fit_ratio (this
       Mac's for mlx, the online nodes' sum for exo). Unknown size, unknown
       memory, or weights not on this Mac (mlx) are refusals, not guesses.

Each backend remembers its own model ("models": {"mlx": ..., "exo": ...}), so
a switch comes back on THAT backend's last model, never the other one's.
"""
import json
import os
import re
import sys
import time

from faxl.engine import faxl_backends


def _warn(msg):
    """Warnings go to stderr: the CLI's stdout is a VALUE a shell captures
    (`BACKEND=$(... --get backend)`), and a warning printed there becomes part
    of the backend name. The proxy's log takes both streams, so nothing is
    lost there."""
    print(msg, file=sys.stderr, flush=True)


def config_path():
    """~/.faxl/config.json, or $FAXL_HOME/config.json.

    Beside the logs and the store, not in the ~/faxl-live scratch directory
    this was developed out of.
    """
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "config.json")


def read(path=None):
    """The stored settings, or {} — never an exception.

    A config file that cannot be parsed must not stop the proxy booting: the
    defaults are all serviceable, and a proxy that refuses to start because a
    settings file has a stray comma is a worse failure than one that ignores
    it and says so.
    """
    p = path or config_path()
    try:
        with open(p) as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as exc:  # noqa: BLE001 — see the docstring
        _warn(f"!! faxl: ignoring unreadable config at {p} ({exc})")
        return {}


def _env(env_var):
    """The env override, or None. Empty counts as unset: `export FAXL_MODEL=`
    in a profile is somebody clearing a value, not choosing the empty one."""
    if not env_var:
        return None
    raw = os.environ.get(env_var)
    if raw is None or not str(raw).strip():
        return None
    return raw


def resolve(key, env_var=None, default=None, cast=None, data=None):
    """(value, source) for one setting -- source is "env", "config" or
    "default", which is what describe() reports.

    `cast` is applied to whatever wins; it may raise TypeError/ValueError to
    reject a value, and a rejected value falls to the DEFAULT with a warning
    (never to a crash, and never silently). `data` is an already-read config,
    so one describe() reads the file once.
    """
    raw, source = _env(env_var), "env"
    if raw is None:
        raw, source = (read() if data is None else data).get(key), "config"
    if raw is None:
        return default, "default"
    if cast is None:
        return raw, source
    try:
        return cast(raw), source
    except (TypeError, ValueError):
        where = env_var if source == "env" else f"{config_path()} {key}"
        _warn(f"!! faxl: config {key}={raw!r} ({where}) is not usable; "
              f"using {default!r}")
        return default, "default"


def get(key, env_var=None, default=None, cast=None):
    """One setting, resolved by the precedence above.

    `cast` is applied to whatever wins. A cast that fails falls to the
    default rather than raising -- the same reasoning as read().
    """
    return resolve(key, env_var, default, cast)[0]


def write(updates, path=None):
    """Merge `updates` into the file and replace it atomically.

    Read-modify-write rather than overwrite: this file will grow settings,
    and a console that saves one of them must not silently drop the rest.
    The temp file sits in the SAME directory so the rename stays on one
    filesystem, which is what makes it atomic.
    """
    p = path or config_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    data = read(p)
    data.update(updates)
    tmp = p + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.write("\n")
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, p)
    return data


# ---- the settings themselves ----------------------------------------------
# Named here rather than spelled out at each call site, so the console and the
# engine cannot disagree about what a key is called.

def store_dir(backend="exo"):
    """Where the cache blobs live, for the backend actually running.

    The two lines keep separate stores and separate env vars; which one is
    live depends on the backend, so the console must ask with one.
    """
    if backend == "exo":
        return os.path.expanduser(
            get("exo_store", "FAXL_EXO_STORE", "~/.faxl/exo-store"))
    # ~/.faxl/cache-general, NOT /tmp (AM 2026-10-02). The old default put the
    # general store under /tmp, which the proxy itself warned about at every
    # boot ("VOLATILE STORE ... will NOT survive a reboot"): a cache that
    # evaporates on restart is a correctness trap, and warning about a default
    # we chose is worse than choosing a better one. Named "cache-general" to
    # pair with "photo-cache" -- the two pools, visibly siblings.
    return os.path.expanduser(
        get("blob_dir", "FAXL_BLOBS", "~/.faxl/cache-general"))


def store_key(backend="exo"):
    """The config key store_dir() reads for this backend."""
    return "exo_store" if backend == "exo" else "blob_dir"


# ---- TWO STORES: TEXT AND PHOTO (AM 2026-10-02) ----------------------------
#
# A photograph and a document do not belong in one pool. They differ in every
# property the cap cares about:
#
#   A photo checkpoint is SMALL and NUMEROUS. The camera roll sends one image
#   per request at ~6,929 tokens, and the blobs measured on the owner's store
#   run 38-415 MB. They are also DISPOSABLE: you re-read a photo once and
#   rarely again, so a photo pool wants a small cap and frequent clear-down.
#
#   A text checkpoint is LARGE and REUSED. One Qwen3.8-Flash-Next checkpoint is
#   188 MB and a Ling one 702 MB, and the whole point is the next turn of the
#   same conversation resuming off it.
#
# Sharing one pool made the eviction score arbitrate between them, so a burst
# of camera-roll traffic evicted the conversation prefixes that were about to
# be reused, and a long document run pushed out the photo entries. Two
# directories, two caps, one scored sweep each: neither can starve the other.
def photo_store_dir(backend="exo"):
    """Where PHOTO checkpoints live. Defaults beside the text store."""
    if backend == "exo":
        return os.path.expanduser(
            get("exo_photo_store", "FAXL_EXO_PHOTO_STORE",
                "~/.faxl/exo-photo-cache"))
    return os.path.expanduser(
        get("photo_blob_dir", "FAXL_PHOTO_BLOBS", "~/.faxl/photo-cache"))


def photo_store_key(backend="exo"):
    """The config key photo_store_dir() reads for this backend."""
    return "exo_photo_store" if backend == "exo" else "photo_blob_dir"


def cap_gb():
    """ONE dial for both lines, as FAXL_STORE_CAP_GB already is.

    This is the TEXT store's cap; the photo store has its own (photo_cap_gb).
    """
    return get("store_cap_gb", "FAXL_STORE_CAP_GB", 60.0, cast=float)


def photo_cap_gb():
    """The PHOTO store's cap, separately dialled.

    Smaller than the text cap by default and deliberately so: photo entries are
    numerous, individually small and seldom re-read, so a big photo pool buys
    little and costs disk. 8 GB holds roughly 200 camera-roll checkpoints at
    the 38 MB that most of them measure.
    """
    return get("photo_cap_gb", "FAXL_PHOTO_CAP_GB", 8.0, cast=float)


# ---- the backend and the model ---------------------------------------------
# Which engine runs the model (mlx: in this process, on this Mac; exo: an exo
# cluster behind faxl) and which model. Read by faxl_start.sh to decide what to
# start, by the proxy at import, and by the console to report and to switch.

# The names faxl_config always knew. Any other REGISTERED and AVAILABLE
# backend (faxl_backends -- the descriptor registry) is accepted too, so a
# product line that registers one needs no edit here.
BACKENDS = ("mlx", "exo")
DEFAULT_BACKEND = "mlx"

# WHAT FAXL RECOMMENDS, PER MACHINE (2026-09-22). Not a contract, and not a
# rule about what anyone may run: a recommendation with its reasoning shown.
# faxl ships without weights ("batteries not included"), comes up on the
# console with no model, and the welcome page asks -- this ladder is what it
# offers, best first, with sizes and headroom (recommend_models()).
#
# It used to be ONE model for both backends, chosen so it fits anywhere: the
# exo default had been Kimi-Linear-48B (~40 GB), and a default only a big
# machine can hold is a download nobody asked for. What changed is that
# "fits anywhere" no longer has to mean "the same everywhere".
#
# The owner's rule: "cater for the largest number of users, so we can drive
# adoption. at the same time, if a user has a great computer, up the spec so
# the quality is amazing. we need to be inclusive while people get the
# quality they can afford." So the FLOOR runs on the smallest Mac Apple still
# sells with 8 GB, and the recommendation rises with the machine -- nobody
# with a 128 GB Studio is offered a 4B because an 8 GB Air exists.
#
# And his correction, the same day, which is why none of this refuses
# anything: "the hardware and decisions about what fits is not a contract.
# there is no THIS MUST HAPPEN type logic here, we are recommending to users
# what's best and they will make the informed decisions themselves." The
# numbers below are the REASONING BEHIND THE ADVICE, shown to the person so
# the choice is informed. They are not permission.
#
# Thinking builds are deliberately absent from every rung. The vision apps
# are OCR and camera-roll (faxl_backends._VISION_APPS): reading a glyph is
# perception, not deliberation, and a reasoning trace cannot sharpen a
# character the vision tower already misread -- it only spends tokens and
# latency. Instruct at every size.
#
# WHY THESE RUNGS, ARITHMETICALLY. A rung must hold weights AND the working
# set, but fits_mlx()/judge() compare bytes ON DISK against RAM x fit_ratio:
# that is a download check, and using it alone to pick a default would seat a
# model that loads and then thrashes. So the chooser adds what the disk size
# leaves out:
#
#   KV cache. Qwen3-VL-4B and -8B are both 36 layers x 8 KV heads x 128 head
#   dim; at fp16 that is 36*8*128*2*2 = 147,456 B/token (the 2B is 28 layers,
#   114,688 B/token). faxl_proxy measures ~6,929 tokens for ONE photograph
#   (faxl_proxy.py:3028), and the camera-roll app sends more than one, so the
#   rungs budget 7k tokens -- ~1.03 GB on a 4B/8B, ~0.80 GB on a 2B. A long
#   OCR session at 20k tokens is ~2.95 GB, which is what the headroom below
#   is for.
#
#   Everything else resident: the vision tower's prefill activations, the
#   image preprocessing buffers, the proxy itself, macOS. 0.60 GB, flat.
#
# Measured against those two. Headroom is shown at BOTH fit_ratio 0.70 and
# at 0.667, because the ratio comment below records that Metal wires only
# ~2/3 of RAM on <= 36 GB machines -- on a small machine 0.70 is optimistic,
# and a rung must clear the pessimistic figure to be called comfortable:
#
#                              disk +  KV  + ovh =  need   @0.70    @0.667
#   8 GB   4B-Instruct-4bit    3.11   1.03   0.60   4.74   +1.27    +0.99
#   16 GB  8B-Instruct-5bit    6.80   1.03   0.60   8.43   +3.60    +3.03
#   32 GB  8B-Instruct-8bit    9.87   1.03   0.60  11.50  +12.55   +11.42
#   48 GB  32B-Instruct-4bit  19.64   1.84   0.60  22.08  +14.00   +12.30
#   64 GB  32B-Instruct-8bit  36.02   1.84   0.60  38.46   +9.65    +7.38
#
# Two rungs were moved DOWN a size after the arithmetic was checked against
# real config.json shapes rather than assumed ones, and both moves matter:
#
#   On 8 GB faxl still recommends the 4B-4bit it always did: 4B-8bit comes
#   to 6.75 GB against about 6.01 GB usable, and 8B-5bit to 8.43 GB, so both
#   would swap. They are still listed and still selectable -- the welcome
#   page says what would happen and the person decides.
#
#   32 GB was 32B-4bit until the 32B's real KV shape was read: it is 64
#   layers (not 36 like the 4B/8B), so 262,144 B/token, and 32B-4bit needs
#   22.08 GB against 22.92 GB wired at 0.667 -- +0.84 GB, which is a model
#   that loads and then fights the window manager for the last gigabyte.
#   so 32 GB is recommended 8B-8bit instead and 32B-4bit is recommended from
#   48 GB, where it has +12.30. A person who wants 32B-4bit on a 32 GB Mac
#   picks it from the same list, with the +0.84 shown.
#
# 235B-A22B is deliberately NOT a rung. The 3-bit build is 104 GB and would
# only be reachable on a 192 GB machine; a default that large is the
# Kimi-Linear mistake in a new suit. Someone with that Mac can pick it.
DEFAULT_MODEL_LADDER = (
    # (min physical RAM bytes, model id) -- ascending; the chooser takes the
    # LAST rung whose machine is big enough and whose measured need fits.
    (8  * 2**30, "mlx-community/Qwen3-VL-4B-Instruct-4bit"),
    (16 * 2**30, "mlx-community/Qwen3-VL-8B-Instruct-5bit"),
    (32 * 2**30, "mlx-community/Qwen3-VL-8B-Instruct-8bit"),
    (48 * 2**30, "mlx-community/Qwen3-VL-32B-Instruct-4bit"),
)
# 32B-8bit WAS the 64 GiB rung and is gone (2026-10-03). It was elected on this
# 128 GiB Mac and the weights were never on it -- a default that picks a model
# the machine has to download 36 GB of before it can answer is not a default.
# The 4-bit build of the same model stays: same architecture, 19.64 GB, and it
# is the rung a 48 GiB machine already gets.
#
# Nothing replaces it at the top. A ladder rung has to be a model we have
# verified serves, and the obvious candidate -- a text MoE such as
# Qwen3.6-35B-A3B -- has no vision tower, so electing it by default would take
# the camera-roll and OCR apps away from every machine big enough to choose it.
# That is a product decision, not a sizing one, so the ladder stops here until
# it is made.

# The floor: what an 8 GB Mac comes up on, what a machine whose RAM cannot be
# read comes up on, and what every "is this a model faxl ships?" check still
# means by "the default". Kept as DEFAULT_MODEL because the proxy banner
# (faxl_proxy.py:166), the fetch note (line ~1035) and the fit test all read
# it as "the shipped floor", which is exactly what it still is.
DEFAULT_MODEL = DEFAULT_MODEL_LADDER[0][1]

# The budget applies to the FLOOR, not to every rung: it is the promise that
# a fresh install on the smallest supported Mac is a small download. A 32 GB
# machine electing a 19.64 GB model is not a budget violation, it is the
# ladder working -- so the test pins the floor under the budget and pins
# every rung as recorded, rather than pinning all of SHIPPED_DEFAULTS under
# 10 GB as it did when there was one default.
DEFAULT_MODEL_BUDGET_BYTES = 10 * 10**9

# The working set the disk size leaves out; the arithmetic is above. Used
# ONLY by choose_default_model() -- fits_mlx() keeps comparing disk bytes,
# because a user who names a model explicitly is answering for it themselves
# and a refusal there must stay a download-fits question.
DEFAULT_IMAGE_TOKENS = 7000        # ~one photograph, faxl_proxy.py:3028
# layers x kv_heads x head_dim x 2 (K and V) x 2 (fp16). Every figure read
# from that model's own config.json on the Hub, 2026-09-22 -- NOT scaled from
# a neighbour: the 32B is 64 layers where the 4B and 8B are 36, and the MoEs
# use 4 KV heads where the dense models use 8, so a guess here is wrong by
# about 2x in both directions and it is the KV term that decides a rung.
_KV_BYTES_PER_TOKEN = {
    "2B": 114_688,        # 28 x 8 x 128 x 2 x 2
    "4B": 147_456,        # 36 x 8 x 128 x 2 x 2
    "8B": 147_456,        # 36 x 8 x 128 x 2 x 2
    "32B": 262_144,       # 64 x 8 x 128 x 2 x 2
    "30B-A3B": 98_304,    # 48 x 4 x 128 x 2 x 2
    "235B-A22B": 192_512,  # 94 x 4 x 128 x 2 x 2
    # Qwen3.8-Flash-Next (qwen4_exp) is a HYBRID: only 12 of its 48 layers are
    # full attention and hold a KV cache at all; the other 36 are Gated
    # DeltaNet, whose recurrent state is a fixed ~0.11 GB regardless of
    # context. Measured from the released config.json rather than inferred
    # from the parameter count: 12 x 2 KV heads x 256 head dim x (K+V) x bf16
    # = 24,576 B/token, plus 3,072 B/token for QSA's index keys (12 x 1 head x
    # 128 dim x bf16). That is a SIXTH of the 4B dense model's per-token cost
    # on a model forty times its size, which is why an 80 GB checkpoint is
    # servable here at all.
    "Flash-Next": 27_648,  # 24,576 KV + 3,072 QSA index
}
_RUNTIME_OVERHEAD_BYTES = 600_000_000   # tower activations, proxy, macOS
# Below this much slack, "it fits" is inside the estimate's own error bars:
# the ladder itself moved 32B-4bit off the 32 GB rung over +0.84 GB, so the
# advice must not call the same margin comfortable elsewhere.
_TIGHT_HEADROOM_BYTES = 2_000_000_000

# Every model id faxl may come up on without being told, with its size on
# disk. The fit check uses the recorded size when the weights are not here to
# measure (a fresh install, or the default on a cluster whose catalogue does
# not list it); tests/test_faxl_fit.py pins that the floor is under the
# budget and that every shipped default resolves to one of these.
SHIPPED_DEFAULTS = {
    # measured: ~/.exo/models/mlx-community--Qwen3-VL-4B-Instruct-4bit on the
    # owner's Mac, 2026-09-21 -- 2.9 GB of weights, tokenizer and config.
    # (The Hub API totals the same repo at 3.11 GB: GiB-vs-GB plus the files
    # the cache does not keep. The measured number is the one that ships.)
    DEFAULT_MODEL: 2_900_000_000,
    # The rungs above the floor: Hub API totals (sum of every sibling blob),
    # read 2026-09-22, NOT yet measured on local disk. Recorded so the fit
    # check can size a rung before it is downloaded.
    "mlx-community/Qwen3-VL-8B-Instruct-5bit": 6_800_000_000,
    "mlx-community/Qwen3-VL-8B-Instruct-8bit": 9_870_000_000,
    "mlx-community/Qwen3-VL-32B-Instruct-4bit": 19_640_000_000,
    # The vLLM rungs (VLLM_MODEL_LADDER): HF-format checkpoints, since an MLX
    # build does not load there. Hub API totals read 2026-09-22. FP8 repos
    # are roughly 60% of their bf16 twin and are only offered on Ada/Hopper.
    "Qwen/Qwen3-VL-2B-Instruct": 4_270_000_000,
    "Qwen/Qwen3-VL-4B-Instruct-FP8": 6_040_000_000,
    "Qwen/Qwen3-VL-4B-Instruct": 8_890_000_000,
    "Qwen/Qwen3-VL-8B-Instruct-FP8": 10_610_000_000,
    "Qwen/Qwen3-VL-8B-Instruct": 17_550_000_000,
    "Qwen/Qwen3-VL-32B-Instruct-FP8": 35_530_000_000,
    "Qwen/Qwen3-VL-32B-Instruct": 66_730_000_000,
    # Qwen3.8-Flash-Next, 2-bit. MEASURED on local disk 2026-10-02, byte-exact
    # against the repo's model.safetensors.index.json total_size. NOT a rung in
    # any ladder -- see the note under DEFAULT_MODEL_LADDER -- but recorded so
    # the console can size it and the fit check can judge it before the 80 GB
    # download starts rather than after.
    "mlx-community/Qwen3.8-Flash-Next-OptiQ-2bit": 79_870_000_000,
}


def _model_family(model_id):
    """The size tag in a Qwen3-VL repo id ("8B", "30B-A3B"), or None. Longest
    match first, so "30B-A3B" is never read as "30B"."""
    s = str(model_id or "")
    for fam in sorted(_KV_BYTES_PER_TOKEN, key=len, reverse=True):
        # "-8B-" matches an MLX id; "-8B" at the end of a segment matches the
        # HF ids used by vLLM ("Qwen/Qwen3-VL-8B-Instruct"), which have no
        # quantisation suffix. Both spellings, one table.
        if f"-{fam}-" in s or s.endswith(f"-{fam}"):
            return fam
    return None


def runtime_need_bytes(model_id, size=None, image_tokens=None):
    """What `model_id` actually needs resident: its bytes on disk, plus the
    KV cache for `image_tokens`, plus the flat runtime overhead. None when
    the size is unknown -- the caller must refuse rather than guess.

    This is the number the AUTO choice is made on. fits_mlx() deliberately
    does not use it: see DEFAULT_IMAGE_TOKENS above."""
    need = shipped_size(model_id) if size is None else size
    if not need:
        return None
    fam = _model_family(model_id)
    n = DEFAULT_IMAGE_TOKENS if image_tokens is None else image_tokens
    kv = _KV_BYTES_PER_TOKEN.get(fam, 0) * n
    return int(need + kv + _RUNTIME_OVERHEAD_BYTES)


def choose_default_model(ram=None, ratio=None, ladder=None):
    """The best rung of DEFAULT_MODEL_LADDER this Mac can hold comfortably.

    Walks the ladder and keeps the LAST rung that clears BOTH gates: the
    machine has at least the rung's stated RAM, and the rung's measured
    runtime need fits RAM x fit_ratio. The second gate is what makes the
    first honest -- a 16 GB machine whose owner lowered fit_ratio drops back
    to the floor instead of electing a model it cannot wire.

    RAM that cannot be read returns the FLOOR, never a refusal: this is the
    model a fresh install comes up on, and a default that refuses is not a
    default. (fits_mlx() still refuses on unknown memory -- that is a
    question about a model someone NAMED, and guessing there is how a Mac
    started downloading 130 GB.)"""
    rungs = DEFAULT_MODEL_LADDER if ladder is None else ladder
    floor = rungs[0][1]
    # ram=None means "not supplied, go and read it"; a READ that comes back
    # None (or 0) means the machine could not be sized, and that is the floor.
    # Collapsing those two into one `if not ram` made an unreadable machine
    # inherit whatever the caller happened to pass -- the test caught it.
    if ram is None:
        ram = ram_bytes()
    if not ram:
        return floor
    r = fit_ratio() if ratio is None else ratio
    have = int(ram * r)
    best = floor
    for min_ram, mid in rungs:
        if ram < min_ram:
            break
        need = runtime_need_bytes(mid)
        if need is None or need > have:
            break
        best = mid
    return best


# THE vLLM LADDER, BY VRAM (2026-09-22). The Mac ladder's twin, and the
# NVIDIA product may be the larger one by users, so it gets the same
# treatment rather than one hardcoded default.
#
# Two differences from the Mac, both from the hardware:
#
#   FP8 IS NOT UNIVERSAL. The hardware path needs compute capability >= 8.9
#   (Ada: 4090, L40S; Hopper: H100). On an A100 (8.0) or a 3090 (8.6) vLLM
#   either refuses the checkpoint or emulates it slowly, so an FP8 rung is
#   offered ONLY when the GPU reports 8.9+. A driver too old to report the
#   field reads as None, and unknown is treated as "no" -- recommending a
#   checkpoint that will not load is the waste of time this whole change is
#   about. bf16 rungs are offered on any card with the VRAM.
#
#   VRAM IS NOT SHARED WITH THE OS, but vLLM pre-allocates a KV arena
#   (gpu_memory_utilization, VLLM_DEFAULTS 0.90) rather than growing into
#   it. The fit question is therefore the weights against usable VRAM; the
#   arena is what the remaining headroom becomes, and more headroom means a
#   longer usable context rather than merely comfort.
_FP8_MIN_COMPUTE_CAP = 8.9
VLLM_MODEL_LADDER = (
    # (min usable VRAM bytes, model id, needs_fp8)
    (6_500_000_000,  "Qwen/Qwen3-VL-2B-Instruct", False),
    (7_000_000_000,  "Qwen/Qwen3-VL-4B-Instruct-FP8", True),
    (10_000_000_000, "Qwen/Qwen3-VL-4B-Instruct", False),
    (12_000_000_000, "Qwen/Qwen3-VL-8B-Instruct-FP8", True),
    (19_000_000_000, "Qwen/Qwen3-VL-8B-Instruct", False),
    (38_000_000_000, "Qwen/Qwen3-VL-32B-Instruct-FP8", True),
    (70_000_000_000, "Qwen/Qwen3-VL-32B-Instruct", False),
)


def _gpu_compute_cap(mem=None):
    """The LOWEST compute capability across this machine's GPUs, or None when
    it cannot be read. Lowest because a model is served across all of them:
    one Ampere card in the box means no FP8, however new the others are."""
    gpus = (mem or gpu_memory()).get("gpus") or []
    caps = [g.get("compute_cap") for g in gpus if g.get("compute_cap")]
    return min(caps) if caps else None


def recommend_vllm_models(mem=None, ratio=None, image_tokens=None):
    """Every vLLM rung this machine could run, BEST FIRST, with the numbers.

    The GPU twin of recommend_models(). Same contract: it recommends, it does
    not decide, and a rung that will not fit is still LISTED with the reason
    -- except an FP8 checkpoint on a card that cannot execute it, which is
    not a trade-off but a checkpoint that will not load, so it is marked
    unsupported rather than merely tight."""
    mem = gpu_memory(ratio) if mem is None else mem
    have = mem.get("usable_bytes")
    cap = _gpu_compute_cap(mem)
    fp8_ok = cap is not None and cap >= _FP8_MIN_COMPUTE_CAP
    best = choose_vllm_model(mem=mem, ratio=ratio)
    out = []
    for _min_vram, mid, needs_fp8 in reversed(VLLM_MODEL_LADDER):
        need = runtime_need_bytes(mid, size=SHIPPED_DEFAULTS.get(mid),
                                  image_tokens=image_tokens)
        d = local_model_dir(mid, hf_only=True)
        size = SHIPPED_DEFAULTS.get(mid) or 0
        head = (have - need) if (have is not None and need is not None) else None
        unsupported = needs_fp8 and not fp8_ok
        if unsupported:
            where = (f"this GPU reports compute capability {cap}"
                     if cap is not None else
                     "this GPU's compute capability could not be read")
            note = (f"FP8 needs compute capability "
                    f"{_FP8_MIN_COMPUTE_CAP}+ (Ada or Hopper) and {where} -- "
                    f"vLLM would refuse it or emulate it slowly")
        elif have is None:
            note = ("this machine's VRAM could not be read, so this is a "
                    "guess from the checkpoint's size alone")
        elif head is not None and head < 0:
            note = (f"needs about {fmt_bytes(need)} but only "
                    f"{fmt_bytes(have)} of VRAM is usable here")
        elif mid == best:
            note = (f"the best fit for this GPU: about {fmt_bytes(need)} of "
                    f"{fmt_bytes(have)} usable, {fmt_bytes(head)} left for "
                    f"the KV arena")
        elif head < _TIGHT_HEADROOM_BYTES:
            note = (f"fits, but leaves only {fmt_bytes(head)} for the KV "
                    f"arena -- expect a short usable context")
        else:
            note = (f"fits with {fmt_bytes(head)} for the KV arena -- a "
                    f"smaller download and faster replies, with less "
                    f"accurate reading of small or messy text")
        out.append({"model": mid, "need_bytes": need, "have_bytes": have,
                    "headroom": head, "on_disk": d is not None,
                    "download_bytes": 0 if d else size,
                    "recommended": mid == best, "fp8": needs_fp8,
                    "supported": not unsupported, "compute_cap": cap,
                    "note": note})
    return out


def choose_vllm_model(mem=None, ratio=None):
    """The best vLLM rung this GPU can hold, FP8 only where it will execute.

    VRAM that cannot be read returns the smallest bf16 rung, never a refusal
    and never an FP8 one: the same rule as the Mac floor, plus "do not
    assume hardware you could not see"."""
    mem = gpu_memory(ratio) if mem is None else mem
    have = mem.get("usable_bytes")
    cap = _gpu_compute_cap(mem)
    fp8_ok = cap is not None and cap >= _FP8_MIN_COMPUTE_CAP
    floor = VLLM_MODEL_LADDER[0][1]
    if not have:
        return floor
    best = floor
    for min_vram, mid, needs_fp8 in VLLM_MODEL_LADDER:
        if needs_fp8 and not fp8_ok:
            continue
        need = runtime_need_bytes(mid, size=SHIPPED_DEFAULTS.get(mid))
        if have < min_vram or need is None or need > have:
            continue
        best = mid
    return best


def recommend_models(backend_name=None, ram=None, ratio=None,
                     image_tokens=None):
    """Every rung this machine could run, BEST FIRST, each with the numbers
    behind the advice. This is a RECOMMENDATION, not a verdict: faxl does not
    decide what a person may run on their own Mac, it shows what it would
    pick and what that costs, and the welcome page asks.

    Each entry:
        model          the hub id
        need_bytes     weights + KV for one photograph + runtime overhead
        have_bytes     RAM x fit_ratio (None when RAM cannot be read)
        headroom       have - need, negative when it would not fit
        download_bytes what a fresh install would fetch (0 when on disk)
        on_disk        already here
        recommended    the best rung this Mac holds comfortably
        note           one plain sentence: why this rung, or what is risky

    Nothing here refuses anything. A rung with negative headroom is still
    listed, with a note saying what would happen -- an informed choice needs
    the bad options visible, not hidden."""
    out = []
    ram = ram_bytes() if ram is None else ram
    r = fit_ratio() if ratio is None else ratio
    have = int(ram * r) if ram else None
    best = choose_default_model(ram=ram, ratio=ratio) if ram else DEFAULT_MODEL
    for _min_ram, mid in reversed(DEFAULT_MODEL_LADDER):
        need = runtime_need_bytes(mid, image_tokens=image_tokens)
        d = local_model_dir(mid)
        size = shipped_size(mid) or 0
        head = (have - need) if (have is not None and need is not None) else None
        if have is None:
            note = ("this Mac's memory could not be read, so this is a guess "
                    "from the model's size alone")
        elif head is not None and head < 0:
            note = (f"needs about {fmt_bytes(need)} but only "
                    f"{fmt_bytes(have)} is usable here -- it would swap, and "
                    f"long sessions would stall")
        elif mid == best:
            note = (f"the best fit for this Mac: about {fmt_bytes(need)} of "
                    f"{fmt_bytes(have)} usable, {fmt_bytes(head)} to spare")
        elif head < _TIGHT_HEADROOM_BYTES:
            # It fits on paper and would still be unpleasant. Metal wires only
            # ~2/3 of RAM on a <= 36 GB Mac (see fit_ratio), so a gigabyte of
            # slack is within the error bars of the estimate itself -- say
            # that plainly rather than call it comfortable.
            note = (f"fits, but only just ({fmt_bytes(head)} to spare) -- "
                    f"a long session or a second app could push this Mac "
                    f"into swapping")
        elif size > (shipped_size(best) or 0):
            note = (f"bigger than the recommendation and still fits "
                    f"({fmt_bytes(head)} to spare) -- more accurate on small "
                    f"or messy text, a longer download and slower replies")
        else:
            note = (f"runs comfortably ({fmt_bytes(head)} to spare) -- a "
                    f"smaller download and faster replies, with less accurate "
                    f"reading of small or messy text")
        out.append({"model": mid, "need_bytes": need, "have_bytes": have,
                    "headroom": head, "on_disk": d is not None,
                    "download_bytes": 0 if d else size,
                    "recommended": mid == best, "note": note})
    return out


def default_model_candidates(backend_name=None, ram=None, ratio=None):
    """What a backend may come up on without being told, BEST FIRST: the rung
    this machine elects, then every rung below it.

    A ladder that offered only its elected rung would be a regression for the
    person it is meant to serve. Picture a 64 GB Mac with the 4B already
    downloaded and no 32B: the elected rung is not on disk, fits_mlx refuses
    "not on this Mac", and a machine that came up fine yesterday now refuses
    to start -- worse than the single default it replaced, and the opposite
    of inclusive. So the console walks these in order and takes the first
    that FITS AND IS PRESENT, noting what it stepped down from.

    A backend whose descriptor names a default (vllm) has exactly one
    candidate: an MLX build will not load there, so there is nothing to walk."""
    d = faxl_backends.get(backend_name) if backend_name else None
    named = (d or {}).get("default_model") or DEFAULT_MODELS.get(backend_name)
    if named:
        return [named]
    if backend_name == "vllm":
        return [r["model"] for r in recommend_vllm_models()
                if r["supported"]] or [VLLM_MODEL_LADDER[0][1]]
    if backend_name not in (None, "mlx", "exo"):
        return [DEFAULT_MODEL]
    top = choose_default_model(ram=ram, ratio=ratio)
    out, seen = [], set()
    for _min_ram, mid in reversed(DEFAULT_MODEL_LADDER):
        if not out and mid != top:
            continue            # skip rungs ABOVE the elected one
        if mid not in seen:
            seen.add(mid)
            out.append(mid)
    return out or [DEFAULT_MODEL]


# Per backend: the descriptor's default_model (faxl_backends), so vLLM comes
# up on the HF build. mlx and exo are None in the registry so that the ladder
# -- not a hardcoded string -- answers for them; see default_model().
# vllm is None for the same reason mlx and exo are: the VRAM ladder answers
# (choose_vllm_model), and a string here would outrank it.
DEFAULT_MODELS = {"mlx": None, "exo": None, "vllm": None}


def default_model(backend_name=None):
    """The model a backend comes up on when nothing is remembered for it.

    A descriptor that names a default wins (vLLM does: an MLX build will not
    load there). mlx and exo name none, and fall through to the LADDER --
    choose_default_model() sizes this Mac and answers with the best rung it
    can hold. That fall-through is the whole mechanism: faxl_backends is a
    leaf module that cannot import this one, so a default hardcoded in a
    descriptor would silently outrank the ladder and nothing would scale.

    exo takes the same rung as mlx, which sizes THIS Mac rather than the
    cluster. That is the conservative direction -- the node you are sitting
    at is a member of the cluster, so a rung it can hold is one the cluster
    can hold -- and the console re-checks against cluster RAM before a switch
    (faxl_console _plan), where a bigger model can still be chosen by hand."""
    d = faxl_backends.get(backend_name) if backend_name else None
    named = (d or {}).get("default_model") or DEFAULT_MODELS.get(backend_name)
    if named:
        return named
    if backend_name == "vllm":
        return choose_vllm_model()
    if backend_name in (None, "mlx", "exo"):
        return choose_default_model()
    return DEFAULT_MODEL


def default_backend():
    """The first available backend for this platform (mlx on a Mac, vllm on
    Linux), else DEFAULT_BACKEND."""
    for d in faxl_backends.for_platform(available_only=True):
        return d["name"]
    return DEFAULT_BACKEND

# What faxl_exo_up.sh hardcoded. endpoint is where exo's API answers;
# prefill_port is where faxl's prefill server listens for exo's runner (faxl
# binds it and PUBLISHES it -- exo never configures it separately);
# trust_remote_code is on for exo because Kimi's tokenizer is code.
EXO_DEFAULTS = {"endpoint": "http://127.0.0.1:52415",
                "prefill_port": 52440,
                "trust_remote_code": True}
EXO_ENV = {"endpoint": "FAXL_EXO_ENDPOINT",
           "prefill_port": "FAXL_PREFILL_PORT",
           "trust_remote_code": "FAXL_TRUST_REMOTE_CODE"}

# org/name, as HuggingFace and exo spell a model. One slash, no spaces.
HUB_ID_RE = re.compile(
    r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")


def _known_backend(b):
    """mlx and exo, as always; any other registered backend only when it is
    available ON THIS PLATFORM -- a Mac's config naming vllm falls back with
    a warning rather than sending the launcher down a branch it cannot run."""
    return b in BACKENDS or any(
        d["name"] == b for d in faxl_backends.for_platform(available_only=True))


def _backend_cast(raw):
    b = str(raw).strip().lower()
    if not _known_backend(b):
        raise ValueError(b)
    return b


def _model_cast(raw):
    """A hub id (org/name) or an absolute path to a directory of weights.

    Anything else is refused rather than passed on: a relative path means a
    different thing from every directory the proxy might be started in, and
    the loaders turn a malformed id into an error that names neither the
    setting nor the file it came from.
    """
    m = str(raw).strip()
    if HUB_ID_RE.match(m):
        return m
    p = os.path.expanduser(m)
    if os.path.isabs(p):
        return p
    raise ValueError(m)


def _bool_cast(raw):
    if isinstance(raw, bool):
        return raw
    v = str(raw).strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    raise ValueError(v)


def _port_cast(raw):
    port = int(raw)
    if not 0 < port < 65536:
        raise ValueError(port)
    return port


def _endpoint_cast(raw):
    e = str(raw).strip().rstrip("/")
    if not e.startswith(("http://", "https://")):
        raise ValueError(e)
    return e


_EXO_CASTS = {"endpoint": _endpoint_cast, "prefill_port": _port_cast,
              "trust_remote_code": _bool_cast}


# vLLM runs IN the proxy (faxl_backends: the proven s0j.7 path is the
# offline LLM() in-process, not `vllm serve`), so there is no endpoint to
# configure. These are the two engine knobs an owner may need to turn; the
# rest (bf16, seed 1234, enforce_eager, prefix caching off, max_num_seqs 1,
# chunked prefill on the checkpoint grid, the faxl connector) are the
# determinism protocol and are NOT settings -- changing one voids the
# byte-identical result. Defaults are R3's proven values on a 24 GB 4090.
VLLM_DEFAULTS = {"gpu_memory_utilization": 0.90, "max_model_len": 8192}
VLLM_ENV = {"gpu_memory_utilization": "FAXL_VLLM_GPU_UTIL",
            "max_model_len": "FAXL_VLLM_MAX_MODEL_LEN"}


def _len_cast(raw):
    n = int(raw)
    if n < 256:
        raise ValueError(n)
    return n


_VLLM_CASTS = {"gpu_memory_utilization": lambda r: _ratio_cast(r),
               "max_model_len": _len_cast}


def backend_source(data=None):
    """(backend, source). An unknown name -- a typo in the file or the env --
    falls to mlx with a warning: a proxy that will not boot over a settings
    typo is worse than one that boots the default and says so."""
    return resolve("backend", "FAXL_BACKEND", default_backend(),
                   cast=_backend_cast, data=data)


def backend():
    """"mlx" or "exo" -- env > config.json > "mlx"."""
    return backend_source()[0]


def _file_backend(data):
    """The backend the FILE names (not the env), or the default. Which
    backend a legacy top-level "model" belongs to."""
    try:
        return _backend_cast(data.get("backend", default_backend()))
    except (TypeError, ValueError):
        return default_backend()


def _models_map(data):
    """{"mlx": id, "exo": id} -- the last model used on each backend, as
    stored (unvalidated; model_source casts)."""
    m = data.get("models")
    if not isinstance(m, dict):
        return {}
    return {k: v for k, v in m.items()
            if _known_backend(k) and isinstance(v, str)}


def model_source(backend_name=None, data=None):
    """(model, source) for a backend -- the one configured, or the one named.

    env FAXL_MODEL > the backend's remembered model (config "models") > the
    legacy top-level "model", ONLY when the file's backend is this one (a
    file written before "models" existed) > DEFAULT_MODEL.

    The legacy rule is the incident fix: {"backend": "exo", "model":
    MiniMax} asked for mlx answers DEFAULT_MODEL, never MiniMax. A model is
    remembered per backend and never carried to the other.
    """
    d = read() if data is None else data
    b = backend_name or backend_source(d)[0]
    dflt = default_model(b)
    if _env("FAXL_MODEL") is not None:
        return resolve("model", "FAXL_MODEL", dflt,
                       cast=_model_cast, data={})
    remembered = _models_map(d).get(b)
    if remembered is not None:
        return resolve(b, None, dflt, cast=_model_cast,
                       data={b: remembered})
    if "models" not in d and b == _file_backend(d):
        return resolve("model", None, dflt, cast=_model_cast, data=d)
    return dflt, "default"


def model(backend_name=None):
    """The model to serve -- env > the backend's model in config.json >
    DEFAULT_MODEL."""
    return model_source(backend_name)[0]


def _exo_sources(data=None):
    d = read() if data is None else data
    stored = d.get("exo")
    stored = stored if isinstance(stored, dict) else {}
    return {k: resolve(k, EXO_ENV[k], EXO_DEFAULTS[k], cast=_EXO_CASTS[k],
                       data=stored)
            for k in EXO_DEFAULTS}


def exo_settings():
    """{endpoint, prefill_port, trust_remote_code} for the exo backend, each
    env > config.json "exo" object > the value faxl_exo_up.sh hardcoded."""
    return {k: v for k, (v, _src) in _exo_sources().items()}


def _vllm_sources(data=None):
    d = read() if data is None else data
    stored = d.get("vllm")
    stored = stored if isinstance(stored, dict) else {}
    return {k: resolve(k, VLLM_ENV[k], VLLM_DEFAULTS[k], cast=_VLLM_CASTS[k],
                       data=stored)
            for k in VLLM_DEFAULTS}


def vllm_settings():
    """{gpu_memory_utilization, max_model_len}: env > config.json "vllm"
    object > R3's proven values."""
    return {k: v for k, (v, _src) in _vllm_sources().items()}


# A backend's own settings block, for the console's engine card. A table,
# so the console asks by the name it was built with and never spells one.
_SETTINGS = {"vllm": vllm_settings}


def backend_settings(backend_name):
    """The settings block for `backend_name`, or None when it has none."""
    fn = _SETTINGS.get(str(backend_name or "").strip().lower())
    return fn() if fn else None


def hub_id(model_id):
    """The HuggingFace id for a model known by a PATH, or the value as given.

    exo knows models by hub id only; an mlx proxy often holds a directory --
    exo's copy (``~/.exo/models/org--name``) or the HF cache
    (``.../hub/models--org--name/snapshots/<sha>``). Handing exo the path is
    how a proxy died on boot with "Repo id must be in the form 'repo_name' or
    'namespace/repo_name'". Anything that cannot be named comes back as
    given, and the caller decides whether that is usable.
    """
    s = str(model_id or "").strip()
    if not s or HUB_ID_RE.match(s):
        return s
    parts = [p for p in s.replace("\\", "/").split("/") if p]
    for p in parts:
        if p.startswith("models--") and "--" in p[len("models--"):]:
            return p[len("models--"):].replace("--", "/", 1)
    last = parts[-1] if parts else s
    if "--" in last:
        cand = last.replace("--", "/", 1)
        if HUB_ID_RE.match(cand):
            return cand
    return s


def set_backend(backend_name, model_id=None, path=None):
    """Write the backend and its model atomically; -> the merged file.

    With a model: that model, on that backend, remembered for it. Without
    one: the backend's REMEMBERED model (config "models"), else
    DEFAULT_MODEL -- never the model the other backend was running. The
    outgoing backend's model is remembered for it first, so a file written
    before "models" existed does not lose it on the first switch.

    Writes "model" (the active one, which older readers use), "models" and
    "backend". Raises ValueError on a value the accessors would reject: the
    writer is where a bad value is stopped, so the file never holds something
    the next boot silently replaces with a default. Whether the model FITS is
    the caller's check (the console's fits(), the launcher's --fits): this
    function only records a choice.
    """
    b = _backend_cast(backend_name)
    chosen = None
    if model_id is not None and str(model_id).strip():
        chosen = _model_cast(model_id)
    data = read(path)
    models = {}
    for k, v in _models_map(data).items():
        try:
            models[k] = _model_cast(v)
        except (TypeError, ValueError):
            pass
    old_b = _file_backend(data)
    if "models" not in data and old_b not in models and data.get("model"):
        try:
            models[old_b] = _model_cast(data["model"])
        except (TypeError, ValueError):
            pass
    if chosen is None:
        chosen = models.get(b) or default_model(b)
    models[b] = chosen
    return write({"backend": b, "model": chosen, "models": models}, path)


def describe():
    """Every backend/model setting with its value AND where it came from.

        {"path": ..., "backend": {"value", "source", "env_var"},
         "model": {...}, "exo": {"endpoint": {...}, ...}}

    source is "env" | "config" | "default". This is what support reads first:
    a value from "env" cannot be changed by the console, and says so.
    """
    data = read()
    b, bsrc = backend_source(data)
    m, msrc = model_source(b, data)
    per = {}
    for name in list(BACKENDS) + [
            d["name"] for d in faxl_backends.for_platform(available_only=True)
            if d["name"] not in BACKENDS]:
        v, src = model_source(name, data)
        per[name] = {"value": v, "source": src}
    return {
        "path": config_path(),
        "backend": {"value": b, "source": bsrc, "env_var": "FAXL_BACKEND"},
        "model": {"value": m, "source": msrc, "env_var": "FAXL_MODEL"},
        # the model each backend comes up on -- a switch restores THAT one
        "models": per,
        "fit_ratio": fit_ratio(data),
        "exo": {k: {"value": v, "source": src, "env_var": EXO_ENV[k]}
                for k, (v, src) in _exo_sources(data).items()},
        "vllm": {k: {"value": v, "source": src, "env_var": VLLM_ENV[k]}
                 for k, (v, src) in _vllm_sources(data).items()},
    }


def sources():
    """{"backend": "env"|"config"|"default", "model": ..., "exo.endpoint": ...}"""
    d = describe()
    out = {"backend": d["backend"]["source"], "model": d["model"]["source"]}
    out.update({f"exo.{k}": v["source"] for k, v in d["exo"].items()})
    return out


# ---- the fit rule -------------------------------------------------------------
# "When you click to switch models, it should NOT allow you to configure things
# that don't fit." (the owner, 2026-09-21, after a switch started a 130 GB
# download onto one Mac.) The console's fits() and the launcher's --fits both
# stand on these functions, so the page, the server and the shell cannot
# disagree about what fits.
#
#   need = the model's bytes: on disk for mlx (the directory the proxy would
#          load, symlinks followed), exo's catalogue size for exo; the
#          recorded size for a SHIPPED_DEFAULTS model that is not here yet.
#   have = RAM x fit_ratio: this Mac's physical RAM for mlx, the sum over the
#          ONLINE nodes for exo.
#   ok   = need and have both known, need <= have, and (mlx) the weights are
#          on this Mac. Anything unknown is a refusal, never a guess.
#
# fit_ratio, default 0.70: Metal wires at most ~2/3 (<= 36 GB machines) to ~3/4
# (bigger ones) of physical RAM for the GPU by default (iogpu.wired_limit_mb
# unset), and the weights are not the only thing resident -- the KV cache, the
# prefill activations, macOS and the apps around it. 0.70 sits at the bottom
# of that band. A config key ("fit_ratio", or FAXL_FIT_RATIO) for the machine
# whose owner raised the wired limit on purpose.

DEFAULT_FIT_RATIO = 0.70

# Files that ARE weights. A directory with a config.json and none of these is
# a tokenizer fetch (the proxy pulls the small files of an exo model into the
# HF cache), not a model this Mac can run -- and treating it as one is how a
# switch to mlx came up on a cluster model and started downloading it.
WEIGHT_EXTS = (".safetensors", ".bin", ".gguf", ".npz")

_SIZE_CACHE = {}          # path -> (expires_at, bytes)
_SIZE_TTL = 60.0


def _ratio_cast(raw):
    r = float(raw)
    if not 0.0 < r <= 1.0:
        raise ValueError(r)
    return r


def fit_ratio(data=None):
    """The share of RAM a model may take: env FAXL_FIT_RATIO > config
    "fit_ratio" > 0.70. Must be in (0, 1]."""
    return resolve("fit_ratio", "FAXL_FIT_RATIO", DEFAULT_FIT_RATIO,
                   cast=_ratio_cast, data=data)[0]


def ram_bytes():
    """This machine's physical RAM in bytes, or None when it cannot be read.
    sysconf works on macOS and Linux alike, with no subprocess."""
    try:
        n = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (AttributeError, ValueError, OSError):
        return None
    return int(n) if n and n > 0 else None


def exo_models_dir():
    """exo's own model directory (org--name), EXO_MODELS overriding."""
    return os.path.expanduser(os.environ.get("EXO_MODELS", "~/.exo/models"))


def hf_hub_dir():
    """The HuggingFace hub cache: HF_HUB_CACHE, else $HF_HOME/hub, else
    ~/.cache/huggingface/hub -- the order huggingface_hub itself uses."""
    if os.environ.get("HF_HUB_CACHE"):
        return os.path.expanduser(os.environ["HF_HUB_CACHE"])
    if os.environ.get("HF_HOME"):
        return os.path.join(os.path.expanduser(os.environ["HF_HOME"]), "hub")
    return os.path.expanduser("~/.cache/huggingface/hub")


def weights_complete(path):
    """True when `path` holds a model that loads without a download: a
    config.json, and every shard its safetensors index names (or, with no
    index, at least one weights file). Symlinks are followed, as the HF cache
    is made of them; a dangling one is a missing shard."""
    try:
        if not os.path.isfile(os.path.join(path, "config.json")):
            return False
        idx = os.path.join(path, "model.safetensors.index.json")
        if os.path.isfile(idx):
            with open(idx) as fh:
                wm = (json.load(fh) or {}).get("weight_map") or {}
            files = set(v for v in wm.values() if isinstance(v, str))
            if files and all(os.path.isfile(os.path.join(path, f))
                             for f in files):
                return True
            # THE INDEX CAN OUTLIVE THE LAYOUT IT DESCRIBES, and it is not
            # what the loader opens.
            #
            # Measured on the shipped default: Qwen3-VL-4B-Instruct-4bit was
            # repacked into a SINGLE model.safetensors while its index still
            # named model-0000{1,2}-of-00002. Both were absent, this returned
            # False, and the launcher refused to start a model that had been
            # serving all day -- after it had already killed the running one.
            #
            # So a stale index is not evidence of absence -- but a MISSING
            # SHARD still is, and the two look identical from the index
            # alone. The difference is on disk: a repacked model has none of
            # the shards the index names and a whole model.safetensors
            # instead; a half-downloaded one has SOME of them.
            #
            # Fall through only when the index describes a layout that is not
            # here AT ALL. Any shard present means the index is current and
            # the download is incomplete, which must still refuse.
            if any(os.path.isfile(os.path.join(path, f)) for f in files):
                return False
        return any(n.endswith(WEIGHT_EXTS)
                   and not n.startswith(("tokenizer", "training_args"))
                   and os.path.isfile(os.path.join(path, n))
                   for n in os.listdir(path))
    except (OSError, ValueError, TypeError, AttributeError):
        return False


def _ls(path):
    try:
        return sorted(os.listdir(path))
    except OSError:
        return []


def _hf_snapshot(hub):
    """The complete snapshot directory for org/name in the HF cache, or None.
    refs/main first (what huggingface_hub resolves), then any complete one."""
    root = os.path.join(hf_hub_dir(), "models--" + hub.replace("/", "--"))
    snaps = os.path.join(root, "snapshots")
    order = []
    try:
        with open(os.path.join(root, "refs", "main")) as fh:
            order.append(fh.read().strip())
    except OSError:
        pass
    order += [s for s in _ls(snaps) if s not in order]
    for sha in order:
        d = os.path.join(snaps, sha)
        if sha and weights_complete(d):
            return d
    return None


def mlx_format(path):
    """True when the directory is an MLX build (config.json carries MLX's
    top-level "quantization": {"bits", "group_size"}). vLLM cannot load one:
    the vLLM backend lists and accepts HF-format weights only."""
    try:
        with open(os.path.join(path, "config.json")) as fh:
            q = (json.load(fh) or {}).get("quantization")
        return isinstance(q, dict) and "bits" in q and "group_size" in q
    except (OSError, ValueError, TypeError, AttributeError):
        return False


def local_model_dir(model_id, hf_only=False):
    """The directory this Mac would load `model_id` from WITHOUT downloading
    anything, or None.

    An absolute path is itself or nothing. A hub id is looked up where the
    proxy looks: the HF cache, then exo's directory (org--name) -- unless
    hf_only (vLLM: exo's directory holds MLX builds, and vLLM loads HF
    snapshots).
    """
    s = str(model_id or "").strip()
    if not s:
        return None
    p = os.path.expanduser(s)
    if os.path.isabs(p):
        return p if weights_complete(p) else None
    if not HUB_ID_RE.match(s):
        return None
    snap = _hf_snapshot(s)
    if snap or hf_only:
        return snap
    exo = os.path.join(exo_models_dir(), s.replace("/", "--", 1))
    return exo if weights_complete(exo) else None


def local_models(source="local_dirs"):
    """[(id, directory)] -- every complete model on this machine, once each.

    source "local_dirs" (mlx): exo's directory (id org/name from org--name)
    and the HF cache. "hf_cache" (vLLM): the HF cache only, MLX builds
    excluded -- the models vLLM can load."""
    found = {}
    hf_only = source == "hf_cache"
    ed = exo_models_dir()
    for name in ([] if hf_only else _ls(ed)):
        full = os.path.join(ed, name)
        if weights_complete(full):
            mid = name.replace("--", "/", 1) if "--" in name else full
            found.setdefault(mid, full)
    for name in _ls(hf_hub_dir()):
        if not name.startswith("models--"):
            continue
        hub = name[len("models--"):].replace("--", "/", 1)
        snap = _hf_snapshot(hub)
        if snap and not (hf_only and mlx_format(snap)):
            found.setdefault(hub, snap)
    return sorted(found.items())


def dir_bytes(path):
    """Bytes under `path`, symlinks to files followed (the HF cache is
    symlinks into blobs/). Cached for a minute: a 130 GB model is thousands
    of stat calls, and the console asks on every poll."""
    now = time.time()
    hit = _SIZE_CACHE.get(path)
    if hit and hit[0] > now:
        return hit[1]
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    _SIZE_CACHE[path] = (now + _SIZE_TTL, total)
    return total


def clear_size_cache():
    _SIZE_CACHE.clear()
    _GPU_CACHE.clear()


# ---- GPU memory (vLLM) ---------------------------------------------------------
# have = the VRAM of every GPU nvidia-smi reports x fit_ratio. The WEIGHTS must
# fit that; the KV cache needs headroom on top, which vLLM carves out of
# gpu_memory_utilization x VRAM at boot (vllm_settings) -- so fit_ratio (0.70)
# leaves the rest of that share for the cache and the activations. No
# nvidia-smi = no NVIDIA GPU visible = a refusal, never a guess.

_GPU_CACHE = {}           # "gpu" -> (expires_at, raw result)
_GPU_TTL = 10.0
NO_GPU = "no NVIDIA GPU visible (nvidia-smi not found)"


def _nvidia_smi():
    """([{index, name, total_bytes, used_bytes, compute_cap}], error or None).
    nvidia-smi reports MiB; 3 s timeout; cached 10 s (the console asks every
    poll). compute_cap is the CUDA compute capability as a float (8.9 = Ada,
    9.0 = Hopper), or None on a driver too old to report it."""
    now = time.time()
    hit = _GPU_CACHE.get("gpu")
    if hit and hit[0] > now:
        return hit[1]
    import subprocess
    gpus, err = [], None
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,"
             "compute_cap", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3)
        if out.returncode != 0:
            err = (f"nvidia-smi failed: "
                   f"{(out.stderr or out.stdout).strip()[:200] or out.returncode}")
        for line in (out.stdout or "").splitlines() if not err else []:
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 4:
                continue
            try:
                # compute_cap decides FP8: the hardware path needs Ada or
                # Hopper (8.9+). Older drivers do not know the field and
                # print "[N/A]" or drop it -- None then, and the ladder
                # treats unknown as "do not assume FP8".
                cap = None
                if len(parts) > 4:
                    try:
                        cap = float(parts[4])
                    except ValueError:
                        cap = None
                gpus.append({"index": int(parts[0]), "name": parts[1],
                             "total_bytes": int(float(parts[2])) * 1024 * 1024,
                             "used_bytes": int(float(parts[3])) * 1024 * 1024,
                             "compute_cap": cap})
            except ValueError:
                continue
        if not err and not gpus:
            err = "nvidia-smi reported no GPUs"
    except FileNotFoundError:
        err = NO_GPU
    except (OSError, subprocess.SubprocessError) as exc:
        err = f"nvidia-smi could not be run ({type(exc).__name__}: {exc})"
    res = (gpus, err)
    _GPU_CACHE["gpu"] = (now + _GPU_TTL, res)
    return res


def gpu_memory(ratio=None):
    """{gpus, vram_bytes, used_bytes, usable_bytes, error} over every GPU.
    usable = total VRAM x fit_ratio; everything None (and error set) when
    no GPU can be read."""
    gpus, err = _nvidia_smi()
    r = fit_ratio() if ratio is None else ratio
    total = sum(g["total_bytes"] for g in gpus) if gpus else None
    used = sum(g["used_bytes"] for g in gpus) if gpus else None
    return {"gpus": gpus, "vram_bytes": total, "used_bytes": used,
            "usable_bytes": int(total * r) if total else None,
            "error": err}


def fmt_bytes(n):
    """130 GB / 2.9 GB -- decimal GB, the unit a Mac's RAM is sold in."""
    if n is None:
        return "?"
    return f"{n / 1e9:.0f} GB" if n >= 10e9 else f"{n / 1e9:.1f} GB"


def shipped_size(model_id):
    """The recorded size of a SHIPPED_DEFAULTS model, or None."""
    return SHIPPED_DEFAULTS.get(hub_id(model_id))


def judge(model_id, need, have, place="this Mac", on_disk=None,
          down_reason=None, disk_where="this Mac"):
    """The one verdict: {ok, need_bytes, have_bytes, reason, on_disk}.

    `place` names whose memory `have` is ("this Mac", "the cluster");
    `on_disk` False refuses (mlx never downloads as a side effect);
    `down_reason` is why the memory could not be read at all. Reasons are
    written for the owner: they are shown verbatim beside a disabled choice.
    """
    out = {"ok": False, "need_bytes": need, "have_bytes": have,
           "reason": None, "on_disk": on_disk}
    if need is not None and have is not None and need > have:
        out["reason"] = (f"needs {fmt_bytes(need)}, {place} has "
                         f"{fmt_bytes(have)} usable")
    elif on_disk is False:
        hub = hub_id(model_id)
        out["reason"] = (f"not on {disk_where} — download it first (hf "
                         f"download {hub})" if HUB_ID_RE.match(hub or "") else
                         f"not on {disk_where} — no model weights at "
                         f"{model_id}")
    elif down_reason:
        out["reason"] = down_reason
    elif not need:
        out["reason"] = "size unknown — refusing rather than guessing"
    elif have is None:
        out["reason"] = (f"{place}'s memory could not be read — refusing "
                         f"rather than guessing")
    else:
        out["ok"] = True
    return out


def fits_mlx(model_id, ram=None, ratio=None):
    """Does `model_id` fit on THIS Mac, in-process? judge() with need = its
    bytes on disk and have = RAM x fit_ratio. Adds "path" (what would load).
    """
    d = local_model_dir(model_id)
    need = dir_bytes(d) if d else shipped_size(model_id)
    ram = ram_bytes() if ram is None else ram
    r = fit_ratio() if ratio is None else ratio
    have = int(ram * r) if ram else None
    v = judge(model_id, need, have, "this Mac", on_disk=d is not None)
    v["path"] = d
    return v


GPU_PLACE = "the GPU"


def fits_gpu(model_id, mem=None, ratio=None):
    """Does `model_id` fit this machine's GPU(s) under vLLM? need = the HF
    snapshot's bytes on disk (or the recorded size of a shipped default);
    have = total VRAM x fit_ratio. The weights must be on this machine in
    HF format -- an MLX build is refused by name. Adds "path"."""
    d = local_model_dir(model_id, hf_only=True)
    mlx_build = bool(d and mlx_format(d))
    need = dir_bytes(d) if d else shipped_size(model_id)
    mem = gpu_memory(ratio) if mem is None else mem
    v = judge(model_id, need, mem.get("usable_bytes"), GPU_PLACE,
              on_disk=d is not None, down_reason=mem.get("error"),
              disk_where="this machine")
    if mlx_build:
        v.update(ok=False, reason=("an MLX build — vLLM loads HF-format "
                                   "weights (bf16/fp8 safetensors)"))
    v["path"] = d
    return v


def mlx_memory(ratio=None):
    """{ram_bytes, usable_bytes} for this Mac."""
    ram = ram_bytes()
    r = fit_ratio() if ratio is None else ratio
    return {"ram_bytes": ram, "usable_bytes": int(ram * r) if ram else None}


# ---- the command line --------------------------------------------------------
# For faxl_start.sh, which must decide in bash what to start, and for a person
# at a terminal. stdout is only ever the value asked for.

def _lookup(key):
    """(value, source) for a --get / --source key; KeyError if unknown."""
    d = describe()
    if key in ("backend", "model"):
        return d[key]["value"], d[key]["source"]
    if key.startswith("exo.") and key[4:] in d["exo"]:
        e = d["exo"][key[4:]]
        return e["value"], e["source"]
    if key == "path":
        return d["path"], "default"
    if key == "store_cap_gb":
        return resolve("store_cap_gb", "FAXL_STORE_CAP_GB", 60.0, cast=float)
    if key.startswith("vllm.") and key[5:] in d["vllm"]:
        e = d["vllm"][key[5:]]
        return e["value"], e["source"]
    if key.startswith("models.") and key[7:] in d["models"]:
        e = d["models"][key[7:]]
        return e["value"], e["source"]
    if key == "fit_ratio":
        return resolve("fit_ratio", "FAXL_FIT_RATIO", DEFAULT_FIT_RATIO,
                       cast=_ratio_cast)
    raise KeyError(key)


def _set(pair, path=None):
    """key=value -> write. The same validation as the accessors."""
    key, sep, value = pair.partition("=")
    key = key.strip()
    if not sep:
        raise ValueError(f"expected key=value, got {pair!r}")
    if key == "backend":
        return set_backend(value, None, path)
    if key == "model":
        # For the backend the next start will run (env included), remembered
        # for it; the active "model" follows when the file names that backend.
        m = _model_cast(value)
        data = read(path)
        b = backend_source(data)[0]
        models = dict(_models_map(data))
        if "models" not in data and data.get("model"):
            ob = _file_backend(data)
            if ob != b:
                models.setdefault(ob, data["model"])
        models[b] = m
        updates = {"models": models}
        if b == _file_backend(data):
            updates["model"] = m
        return write(updates, path)
    if key == "fit_ratio":
        return write({"fit_ratio": _ratio_cast(value)}, path)
    if key.startswith("exo.") and key[4:] in EXO_DEFAULTS:
        field = key[4:]
        exo = read(path).get("exo")
        exo = dict(exo) if isinstance(exo, dict) else {}
        exo[field] = _EXO_CASTS[field](value)
        return write({"exo": exo}, path)
    if key.startswith("vllm.") and key[5:] in VLLM_DEFAULTS:
        field = key[5:]
        v = read(path).get("vllm")
        v = dict(v) if isinstance(v, dict) else {}
        v[field] = _VLLM_CASTS[field](value)
        return write({"vllm": v}, path)
    if key == "store_cap_gb":
        return write({"store_cap_gb": float(value)}, path)
    raise KeyError(key)


def _fits_cli():
    """--fits: may the configured model start on the configured backend?

    -> exit 0 (fits; one line on stdout) or 3 (refused; the reason on
    stderr). faxl_start.sh runs this before starting anything on mlx.

    mlx: fits_mlx(). Two allowances, both said on stderr:
      * NOTHING is fetched automatically (2026-09-22, "batteries not
        included"). There used to be an allowance here: the shipped default
        was downloaded unasked on first start. Once the default became a
        ladder that allowance meant a fresh 64 GB Mac pulling 36 GB before
        the console appeared, which is an imposition however good the model
        is. faxl now ships without weights, comes up on the console with no
        model, and the welcome page asks -- recommend_models() gives it the
        ranked options with sizes and reasons;
      * FAXL_ALLOW_DOWNLOAD=1 lifts the on-disk rule for a developer. It
        never lifts "too big".
    exo: the cluster is sized from exo's own report of its nodes, which only
    exists once exo runs -- and this is asked BEFORE the launcher starts it.
    The console sizes it (and refuses) before every switch; here it is said.
    """
    b = backend()
    m = model(b)
    src = (faxl_backends.get(b) or {}).get("memory_from", "host_ram")
    if src == "cluster_ram":
        print(f"faxl: {m} on exo is sized by the console against the "
              f"cluster's memory once exo answers", file=sys.stderr)
        print(f"ok {m} (exo)")
        return 0
    gpu = src == "gpu_vram"
    place = GPU_PLACE if gpu else "this Mac"
    v = fits_gpu(m) if gpu else fits_mlx(m)
    if v["ok"]:
        print(f"ok {m}: {fmt_bytes(v['need_bytes'])} of "
              f"{fmt_bytes(v['have_bytes'])} usable on {place}")
        return 0
    if gpu and v["have_bytes"] is None:
        # no GPU: nothing else matters (and no download is worth starting)
        print(f"faxl: {m} cannot start: {v['reason']}", file=sys.stderr)
        return 3
    # "too big" is ADVICE, not a veto: a person may run what they like on
    # their own Mac. It still gates the SILENT paths (an unattended start, a
    # bare API call), because the 2026-09-21 incident was a 130 GB download
    # nobody asked for -- the console's confirm is what lifts it.
    too_big = (v["need_bytes"] is not None and v["have_bytes"] is not None
               and v["need_bytes"] > v["have_bytes"])
    if not v["on_disk"] and not too_big:
        # A FRESH INSTALL and A MODEL SOMEONE CHOSE are different situations,
        # and only the first may start. Fresh install: nothing was ever
        # picked, so config.json names no model and model() answered with the
        # recommendation -- come up on the console and let them choose.
        # Otherwise somebody put a specific model in config.json and it is
        # not here: that is the 2026-09-21 incident's exact setup (a 130 GB
        # cluster model left configured on mlx), and starting would either
        # download it unasked or serve a console that silently ignored the
        # choice. Stop and say which model, so they can fetch it or pick
        # another.
        _configured, _src = model_source(b)
        if not gpu and _src == "default":
            print(f"faxl: no model on this Mac yet -- starting the console "
                  f"so you can pick one. Nothing is downloaded until you "
                  f"do.", file=sys.stderr)
            print("ok: no model yet, the console will ask")
            return 0
        if os.environ.get("FAXL_ALLOW_DOWNLOAD") == "1":
            print(f"faxl: FAXL_ALLOW_DOWNLOAD=1 -- {m} is not here "
                  f"and WILL BE DOWNLOADED by the proxy", file=sys.stderr)
            print(f"ok {m}: download allowed")
            return 0
    print(f"faxl: {m} cannot start on {place}: {v['reason']}",
          file=sys.stderr)
    return 3


def _shell(value):
    if isinstance(value, bool):
        return "1" if value else "0"
    return str(value)


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(
        prog="python -m faxl.engine.faxl_config",
        description=f"faxl settings ({config_path()}). Precedence: "
                    f"environment > config file > default.")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--get", metavar="KEY",
                   help="print one resolved value: backend, model, "
                        "models.mlx, models.exo, "
                        "exo.endpoint, exo.prefill_port, "
                        "exo.trust_remote_code, store_cap_gb, fit_ratio, "
                        "path")
    g.add_argument("--source", metavar="KEY",
                   help="print where KEY's value comes from: "
                        "env, config or default")
    g.add_argument("--set", metavar="KEY=VALUE", action="append",
                   help="write a setting (repeatable)")
    g.add_argument("--show", action="store_true",
                   help="every backend/model setting and its source, as JSON")
    g.add_argument("--hub-id", metavar="MODEL",
                   help="the org/name id for a model path, or MODEL as given")
    g.add_argument("--fits", action="store_true",
                   help="may the configured model start on the configured "
                        "backend: exit 0, or 3 with the reason on stderr")
    a = ap.parse_args(argv)
    if a.fits:
        return _fits_cli()
    try:
        if a.get or a.source:
            value, src = _lookup(a.get or a.source)
            print(_shell(value) if a.get else src)
        elif a.set:
            for pair in a.set:
                _set(pair)
            for pair in a.set:
                k = pair.partition("=")[0].strip()
                value, src = _lookup(k)
                note = ("" if src == "config" else
                        f"  (but {src} wins: the environment overrides the "
                        f"file)" if src == "env" else "")
                print(f"{k}={_shell(value)}{note}")
        elif a.show:
            print(json.dumps(describe(), indent=2, sort_keys=True))
        else:
            print(hub_id(a.hub_id))
    except KeyError as exc:
        print(f"faxl_config: unknown key {exc.args[0]!r}", file=sys.stderr)
        return 2
    except (TypeError, ValueError) as exc:
        print(f"faxl_config: not a usable value: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())


# ---- HUGGINGFACE TOKEN ------------------------------------------------------
# WHY THIS IS HERE AND NOT IN config.json. A token is a credential: it belongs
# in a 0600 file of its own, like the licence, NOT in the settings file the
# console renders back to the page. Putting it in config.json would print it
# into /api/configure and onto the screen.
#
# WHY IT EXISTS AT ALL. A gated repo was reported only by exo, only after a
# download had already failed, as "Run `hf auth login`, or set HF_TOKEN" inside
# an error string. On the Mac line there was no token handling whatsoever: the
# failure arrived as a traceback and nothing told the user a token was the
# thing missing. The console is where settings belong. (AM, 2026-10-05: "the
# hugging face token/key needs to be configured ON THE USER INTERFACE ...
# that's what the user interface is FOR.")
#
# PRECEDENCE, and it is deliberate: the environment wins, then an existing
# `hf auth login`, then ours. A machine already logged in must not be asked
# again, and an env var set by a launcher must not be silently overridden by a
# stale saved value -- the same rule the store settings follow.

HF_TOKEN_FILE = os.path.expanduser(
    os.environ.get("FAXL_HF_TOKEN_FILE", "~/.faxl/hf-token"))


def _read_token_file(path):
    try:
        with open(path) as fh:
            tok = fh.read().strip()
        return tok or None
    except OSError:
        return None


def hf_token():
    """The token to use, or None. Never logged, never returned to the page."""
    for var in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN"):
        tok = (os.environ.get(var) or "").strip()
        if tok:
            return tok
    tok = _read_token_file(os.path.expanduser("~/.cache/huggingface/token"))
    if tok:
        return tok
    return _read_token_file(HF_TOKEN_FILE)


def hf_token_status():
    """Is a token set, and where did it come from? The SECRET IS NEVER IN HERE.

    `source` lets the console say something useful rather than a bare
    yes/no: a user whose token comes from the environment needs to know that
    editing the field will not take effect, exactly as the store panel says
    for its own env overrides.
    """
    for var in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN"):
        if (os.environ.get(var) or "").strip():
            return {"set": True, "source": "env", "env_var": var,
                    "editable": False}
    if _read_token_file(os.path.expanduser("~/.cache/huggingface/token")):
        return {"set": True, "source": "hf_cli", "env_var": None,
                "editable": False}
    if _read_token_file(HF_TOKEN_FILE):
        return {"set": True, "source": "faxl", "env_var": None,
                "editable": True}
    return {"set": False, "source": None, "env_var": None, "editable": True}


def write_hf_token(token):
    """Save the token 0600, or delete it when given an empty value.

    0600 inside a 0700 directory, written tmp+replace and fsynced, and the
    mode is set with fchmod as well as the open mode -- an open mode alone
    does not retighten a file that already exists with looser permissions.
    """
    token = (token or "").strip()
    d = os.path.dirname(HF_TOKEN_FILE) or "."
    os.makedirs(d, mode=0o700, exist_ok=True)
    if not token:
        try:
            os.unlink(HF_TOKEN_FILE)
        except OSError:
            pass
        return False
    tmp = HF_TOKEN_FILE + f".tmp{os.getpid()}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as fh:
            fh.write(token + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, HF_TOKEN_FILE)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return True

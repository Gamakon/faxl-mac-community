# Vendored engine module (faxl_panel_right.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""The right-hand side of the control panel: do something.

Five strings, imported by faxl_panel.py (the shell) and dropped into its page:

  RIGHT_HTML    inside <aside id="col-right">: chat, then apps
  RIGHT_CSS     styles for both of the above and for the drawers below
  RIGHT_JS      the chat and the apps list
  DRAWERS_HTML  inside <div id="drawers">: licence, store, models, verify,
                diagnostics, app (the shell owns drawer-request)
  DRAWERS_JS    what the drawers do

THE CONTRACT is docs/plans/console-dashboard-rebuild.md section D. The scripts
run after the shell has defined window.faxl and do nothing without it, so this
module can be absent (the shell renders an empty column) or present without
the shell (nothing runs).

NO DATA IS INTERPOLATED. Everything here is a raw string and is inserted as
is; every number and name on screen comes from the proxy at run time and is
written with textContent. The CSP is the console's: inline only, connect-src
'self', no eval, no external host.

THE TONE RULE. "We are not here to lie, just to do prefill." A verdict comes
from the proxy's request log, never from the browser's opinion; a number the
proxy did not measure is a dash, never a zero; a cold cache is called cold.
"""

# ---------------------------------------------------------------------------
# markup
# ---------------------------------------------------------------------------

RIGHT_HTML = r"""
<section class="card r-chat" id="r-chat" aria-labelledby="r-chat-h">
  <div class="card-h r-head">
    <h2 id="r-chat-h">Chat <span class="muted">/ try it</span></h2>
    <button class="btn btn-quiet" id="r-chat-new" type="button">New conversation</button>
  </div>
  <div id="r-chat-log" class="r-chat-log" role="log" aria-live="polite">
    <p class="muted r-empty" id="r-chat-empty">Messages go through the proxy,
    exactly as any client sends them. Under each reply: what faxl did with it,
    read from the proxy's own request log. The first message is a cold prompt;
    the follow-up resends it, and that is where the cache earns its keep.</p>
  </div>
  <form id="r-chat-form" class="r-chat-form" autocomplete="off">
    <div id="r-chat-att" class="r-att" hidden>
      <img id="r-chat-thumb" alt="the attached picture">
      <span id="r-chat-attname" class="muted mono"></span>
      <button class="btn btn-quiet" id="r-chat-attrm" type="button">remove</button>
    </div>
    <textarea id="r-chat-in" class="r-chat-in" rows="3" spellcheck="false"
      aria-label="Message"
      placeholder="Ask the model something, then a follow-up. Cmd/Ctrl+Enter sends."></textarea>
    <div class="r-actions">
      <button class="btn" id="r-chat-send" type="submit">Send</button>
      <button class="btn btn-quiet" id="r-chat-pic" type="button">Attach picture</button>
      <input type="file" id="r-chat-file" accept="image/*" hidden>
      <span class="muted r-note" id="r-chat-note" aria-live="polite"></span>
    </div>
  </form>
</section>
<section class="card r-apps" id="r-apps" aria-labelledby="r-apps-h">
  <div class="card-h r-head">
    <h2 id="r-apps-h">Apps</h2>
    <button class="btn btn-quiet" type="button" data-open-drawer="drawer-diagnostics">diagnostics</button>
  </div>
  <ul id="r-apps-list" class="r-apps-list"></ul>
  <p class="muted r-empty" id="r-apps-empty" hidden>No apps reported by the proxy.</p>
</section>
"""

DRAWERS_HTML = r"""
<section class="drawer" id="drawer-licence" hidden aria-labelledby="dl-h">
  <h2 id="dl-h">Licence</h2>
  <h3 class="r-sub">What it covers</h3>
  <dl class="kv" id="dl-facts"><dt>status</dt><dd>—</dd></dl>
  <p class="muted" id="dl-none" hidden>No licence is installed. The proxy still
  answers every request; what is off is the cache tier, so every prefill runs
  cold.</p>
  <h3 class="r-sub">Install a key</h3>
  <div class="field">
    <label for="dl-key">Paste the key from your licence email</label>
    <textarea id="dl-key" class="r-key mono" rows="5" spellcheck="false"
      autocapitalize="off" autocomplete="off"
      placeholder="One long line with a dot in the middle. Paste the whole thing."></textarea>
  </div>
  <div class="r-actions">
    <button class="btn" id="dl-save" type="button">Save licence</button>
    <span class="r-msg" id="dl-msg" aria-live="polite"></span>
  </div>
</section>

<section class="drawer" id="drawer-store" hidden aria-labelledby="ds-h">
  <h2 id="ds-h">Cache store</h2>
  <dl class="kv" id="ds-facts"><dt>path</dt><dd>—</dd></dl>
  <p class="r-warn" id="ds-env" hidden></p>
  <div class="field">
    <label for="ds-path">Store folder</label>
    <input id="ds-path" class="mono r-wide" type="text" spellcheck="false">
  </div>
  <div class="field">
    <label for="ds-cap">Cap (GB)</label>
    <input id="ds-cap" class="mono" type="number" min="1" step="1">
    <span class="muted">past the cap, the least-reused entries are evicted first</span>
  </div>
  <div class="field">
    <label class="r-check"><input type="checkbox" id="ds-move" checked>
    Move the existing cache to the new folder (the old copy is deleted only
    after the move is verified)</label>
  </div>
  <p class="r-callout" id="ds-say"><strong>Saving restarts the proxy.</strong>
  These settings are read when it starts, so it stops and comes back &mdash;
  about a minute, longer while a cache is moved. Nothing already cached is
  lost. Unticked, the old cache stays where it is and faxl starts with an
  empty store in the new folder.</p>
  <div class="r-actions">
    <button class="btn" id="ds-save" type="button">Save and restart</button>
    <span class="r-msg" id="ds-msg" aria-live="polite"></span>
  </div>
  <p class="mono r-prog" id="ds-prog" hidden></p>
</section>

<section class="drawer" id="drawer-models" hidden aria-labelledby="dm-h">
  <h2 id="dm-h">Models</h2>
  <h3 class="r-sub">On this Mac</h3>
  <p class="muted" id="dm-lead">Run in-process by this Mac (MLX). Switching
  restarts the proxy onto the model you pick.</p>
  <p class="muted" id="dm-budget"></p>
  <ul class="r-models" id="dm-list"></ul>
  <p class="r-msg" id="dm-msg" aria-live="polite"></p>

  <h3 class="r-sub">Models for the exo cluster</h3>
  <p class="muted">On the exo backend, exo runs one model across several
  machines and faxl stays in front of it: the chat template, the lookup, the
  store and the verification are still faxl&#8217;s, and exo&#8217;s own
  prefix cache is off. It is how a model too large for one Mac &#8212; Kimi K3,
  about 700&nbsp;GB &#8212; runs at all.</p>
  <p class="muted"><strong class="r-hy">Hybrid / recurrent models &#8212; only
  faxl caches these correctly.</strong> Mamba, SSM and linear-attention models
  (Kimi&#8217;s KDA among them) keep one rolled-up recurrent state instead of a
  KV cache. Cached without handling that, they return a different answer
  &#8212; plausible, not an error, so nothing tells you it happened. faxl
  stores and replays the real state.</p>
  <div id="dx-off" hidden>
    <p class="r-msg" id="dx-offmsg"></p>
    <button class="btn" id="dx-switch" type="button">switch the backend to exo cluster</button>
  </div>
  <div id="dx-on" hidden>
    <p class="r-msg" id="dx-note"></p>
    <div id="dx-dl"></div>
    <div class="field r-inline">
      <input id="dx-filter" class="r-wide" type="text" spellcheck="false"
        placeholder="filter: kimi, hybrid, vision, on disk&#8230;" aria-label="filter the cluster catalogue">
      <button class="btn btn-quiet" id="dx-reload" type="button">reload</button>
    </div>
    <p class="muted" id="dx-count"></p>
    <div class="r-scroll"><table class="r-tbl" id="dx-tbl">
      <thead><tr><th scope="col">model</th><th scope="col">architecture</th>
      <th scope="col">size</th><th scope="col">context</th>
      <th scope="col" title="vision">vision</th><th scope="col" title="thinking">thinking</th>
      <th scope="col" title="the model can be split across machines">multi-node</th>
      <th scope="col">weights</th><th scope="col"></th></tr></thead>
      <tbody id="dx-body"></tbody></table></div>
    <p class="r-msg" id="dx-msg" aria-live="polite"></p>
  </div>

  <h3 class="r-sub">Add a model from HuggingFace</h3>
  <p class="muted" id="dm-howto"></p>
  <div class="field r-inline">
    <input id="dm-repo" class="mono r-wide" type="text" spellcheck="false"
      placeholder="org/name, e.g. mlx-community/Qwen3-VL-4B-Instruct-4bit"
      aria-label="HuggingFace repo id">
    <button class="btn" id="dm-add" type="button">Add</button>
  </div>
  <p class="r-msg" id="dm-addmsg" aria-live="polite"></p>
</section>

<section class="drawer" id="drawer-verify" hidden aria-labelledby="dv-h">
  <h2 id="dv-h">Verify losslessness</h2>
  <p class="muted">A cache that answers differently from a cold run is worth
  nothing, however fast. These send real requests through this proxy at
  temperature 0 and compare the answers byte for byte. Hit and resume position
  come from the proxy's own request log, not from this page.</p>
  <div class="r-tests">
    <div class="r-test">
      <h3>Same prompt, three times</h3>
      <p class="muted">Run 1 fills the cache; runs 2 and 3 should resume from
      it and return byte-identical answers.</p>
      <button class="btn" id="dv-t1" type="button">Run</button>
    </div>
    <div class="r-test">
      <h3>Shared prefix, different questions</h3>
      <p class="muted">Three questions over one long shared preamble, then the
      first again. The repeat must match run 1 exactly; runs 2&ndash;4 should
      resume from the shared prefix.</p>
      <button class="btn" id="dv-t2" type="button">Run</button>
    </div>
  </div>
  <div class="r-actions"><button class="btn btn-quiet" id="dv-both" type="button">Run both</button>
  <span class="r-msg" id="dv-msg" aria-live="polite"></span></div>
  <div id="dv-out"></div>
  <p id="dv-overall" class="r-overall" hidden></p>
  <p class="muted" id="dv-record" hidden></p>
</section>

<section class="drawer" id="drawer-diagnostics" hidden aria-labelledby="dd-h">
  <h2 id="dd-h">Diagnostics</h2>
  <div class="r-actions">
    <button class="btn" id="dd-copy" type="button">Copy</button>
    <button class="btn btn-quiet" id="dd-reload" type="button">Reload</button>
    <span class="r-msg" id="dd-msg" aria-live="polite"></span>
  </div>
  <pre class="mono r-pre" id="dd-pre">—</pre>
</section>

<section class="drawer" id="drawer-app" hidden aria-labelledby="da-h">
  <h2 id="da-h">App</h2>
  <p class="muted"><a id="da-tab" href="#" target="_blank" rel="noopener">open in a new tab</a></p>
  <iframe id="da-frame" class="r-frame" title="app"></iframe>
</section>
"""

# ---------------------------------------------------------------------------
# styles -- only the section D variables and classes, plus r-* of our own
# ---------------------------------------------------------------------------

RIGHT_CSS = r"""
#col-right{display:flex;flex-direction:column;gap:var(--gap);min-height:0;min-width:0}
#col-right .r-chat{flex:1 1 auto;min-height:14rem;display:flex;flex-direction:column}
#col-right .r-apps{flex:0 0 auto;max-height:40%;overflow:auto}
.r-head{display:flex;align-items:center;justify-content:space-between;gap:var(--gap)}
.r-head h2{margin:0;font-size:inherit}
.r-empty{margin:var(--gap) 0}
.r-chat-log{flex:1 1 auto;min-height:0;overflow-y:auto;display:flex;
  flex-direction:column;gap:var(--gap);padding:var(--gap) 0}
.r-msg-b{border:1px solid var(--line);border-radius:var(--radius);
  padding:6px 9px;white-space:pre-wrap;overflow-wrap:anywhere}
.r-msg-b.r-you{background:var(--bg)}
.r-msg-b.r-failed{border-color:var(--bad)}
.r-msg-b .r-who{display:block;font-size:11px;text-transform:uppercase;
  letter-spacing:.05em;color:var(--ink-2);margin-bottom:3px}
.r-msg-b img{display:block;max-width:10rem;max-height:7rem;border-radius:4px;
  margin-bottom:4px}
.r-pending{color:var(--ink-2)}
.r-err{color:var(--bad)}
.r-verdict{margin:5px 0 0;font-size:12px;color:var(--ink-2);font-family:var(--mono);
  white-space:normal}
.r-verdict .pill{margin-right:4px}
.r-chat-form{flex:0 0 auto;border-top:1px solid var(--line);padding-top:var(--gap)}
.r-chat-in{width:100%;box-sizing:border-box;font:inherit;padding:6px 8px;
  border:1px solid var(--ink-2);border-radius:var(--radius);background:var(--bg);
  color:var(--ink);resize:vertical}
.r-chat-in:focus{outline:2px solid var(--teal);outline-offset:1px}
.r-actions{display:flex;align-items:center;flex-wrap:wrap;gap:var(--gap);margin-top:6px}
.r-note{font-size:12px}
.r-att{display:flex;align-items:center;gap:var(--gap);margin-bottom:6px}
.r-att img{max-height:3rem;max-width:5rem;border-radius:4px;border:1px solid var(--line)}
.r-apps-list{list-style:none;margin:0;padding:0}
.r-apps-list li{display:flex;align-items:center;gap:var(--gap);padding:5px 0;
  border-bottom:1px solid var(--line);flex-wrap:wrap}
.r-apps-list li:last-child{border-bottom:0}
.r-app-t{flex:1 1 auto;min-width:0}
.r-job{font-family:var(--mono);font-size:12px;color:var(--ink-2)}
.r-job .r-dot{color:var(--ok)}
.r-armed{border-color:var(--bad)!important;color:var(--bad)!important}
.r-sub{font-size:12px;text-transform:uppercase;letter-spacing:.05em;
  color:var(--ink-2);margin:14px 0 6px}
.r-key{width:100%;box-sizing:border-box;min-height:6rem;word-break:break-all;
  padding:6px 8px;border:1px solid var(--line);border-radius:var(--radius);
  background:var(--bg);color:var(--ink)}
.r-wide{width:100%;box-sizing:border-box}
.r-inline{display:flex;gap:var(--gap)}
.r-check{display:flex;gap:6px;align-items:flex-start}
.r-msg{font-size:13px}
.r-msg.r-ok{color:var(--ok)}
.r-msg.r-bad{color:var(--bad)}
.r-warn{color:var(--warn)}
.r-callout{border-left:3px solid var(--warn);padding:4px 8px;margin:10px 0}
.r-prog{font-size:12px;color:var(--ink-2)}
.r-models{list-style:none;margin:0;padding:0}
.r-hy{color:var(--ok)}
.r-scroll{max-height:48vh;overflow:auto;border:1px solid var(--line);border-radius:var(--radius)}
#dx-tbl td{white-space:nowrap}
#dx-tbl td.r-mid{white-space:normal;overflow-wrap:anywhere;min-width:12rem}
#dx-tbl tr.r-run td{background:color-mix(in srgb,var(--ok) 9%,transparent)}
.r-dlrow{display:flex;align-items:center;gap:8px;font-size:12px;margin:4px 0}
.r-dlrow .r-bar{flex:1;height:6px;border-radius:3px;background:var(--panel-2);border:1px solid var(--line);overflow:hidden}
.r-dlrow .r-bar i{display:block;height:100%;background:var(--accent)}
.r-models li{display:flex;align-items:center;gap:var(--gap);padding:6px 0;
  border-bottom:1px solid var(--line);flex-wrap:wrap}
.r-models .r-mname{flex:1 1 12rem;min-width:0;overflow-wrap:anywhere}
.r-tests{display:grid;grid-template-columns:repeat(auto-fit,minmax(14rem,1fr));
  gap:var(--gap);margin:10px 0}
.r-test{border:1px solid var(--line);border-radius:var(--radius);padding:8px 10px}
.r-test h3{margin:0 0 4px;font-size:14px}
.r-test p{margin:0 0 8px;font-size:13px}
.r-res{margin:12px 0}
.r-res h3{margin:0 0 4px;font-size:14px}
.r-tbl{border-collapse:collapse;font-size:12px;width:100%}
.r-tbl th,.r-tbl td{text-align:left;padding:3px 8px 3px 0;border-bottom:1px solid var(--line);
  vertical-align:top}
.r-tbl td{font-family:var(--mono)}
.r-overall{font-weight:600;margin:12px 0 4px}
.r-pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;
  border:1px solid var(--line);border-radius:var(--radius);padding:8px;max-height:70vh;
  overflow:auto}
.r-frame{width:100%;height:75vh;border:1px solid var(--line);border-radius:var(--radius)}
"""

# ---------------------------------------------------------------------------
# shared helpers: prepended to BOTH scripts (each is its own IIFE, and the
# shell may place them in either order)
# ---------------------------------------------------------------------------

_COMMON_JS = r"""
  var F = window.faxl;
  function $(id){ return document.getElementById(id); }
  function mk(tag, cls, text){
    var e = document.createElement(tag);
    if(cls) e.className = cls;
    if(text != null) e.textContent = String(text);
    return e;
  }
  function clear(e){ while(e && e.firstChild) e.removeChild(e.firstChild); }
  // null is unmeasured: a dash, never 0.
  function num(n){ return (n == null || n === "") ? "—" : Number(n).toLocaleString(); }
  function dash(v){ return (v == null || v === "") ? "—" : String(v); }
  function gb(b){ return b == null ? "—" : (b / 1e9).toFixed(b >= 1e10 ? 0 : 1) + " GB"; }
  function ms(v){ return v == null ? "—" : Math.round(Number(v)).toLocaleString() + " ms"; }
  function toast(t, lvl){ try{ if(F.toast) F.toast(t, lvl || "info"); }catch(_){} }
  function refresh(){ try{ return Promise.resolve(F.refresh && F.refresh()).catch(function(){}); }
                      catch(_){ return Promise.resolve(); } }
  function st(){ return F.state || {}; }

  // The message the SERVER wrote, in whichever of its shapes: {error:{message}},
  // {error:"…"}, the licence route's {banner:{message}}, or plain text.
  function errText(d, text, status){
    var m = null;
    if(d && typeof d === "object"){
      if(d.error) m = (typeof d.error === "string") ? d.error : (d.error.message || JSON.stringify(d.error));
      else if(d.banner && d.banner.message) m = d.banner.message;
      else if(d.message) m = d.message;
    }
    if(!m) m = (text || "").slice(0, 300);
    if(!m) m = "HTTP " + status;
    return String(m);
  }
  // JSON in/out that NEVER rejects on an HTTP status: several routes put the
  // useful thing in a 4xx body (409 "needs exo", the licence banner), so the
  // caller gets {ok, status, d, text}. Rejects only when the proxy cannot be
  // reached at all.
  function req(path, opts){
    opts = opts || {};
    var init = {method: opts.method || "GET", cache: "no-store",
                headers: {Accept: "application/json"}};
    if(opts.body !== undefined){
      init.headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(opts.body);
    }
    return fetch(path, init).then(function(r){
      return r.text().then(function(t){
        var d = null; try{ d = t ? JSON.parse(t) : null; }catch(_){}
        return {ok: r.ok, status: r.status, d: d, text: t};
      });
    });
  }

  // ---- which log row is ours ----------------------------------------------
  // Ported from the chat page (_CHAT_SCRIPT). The completion id and the log's
  // transaction id are different namespaces, so the row is found by
  // DIFFERENCE: snapshot the feed's ids before sending, and the rows that
  // were not there afterwards are the candidates. One candidate is ours;
  // several are narrowed by the prompt-token count the completion reported;
  // otherwise we say we could not tell rather than pin somebody else's row.
  function feed(limit){
    return fetch("/api/requests?limit=" + limit,
                 {cache: "no-store", headers: {Accept: "application/json"}})
      .then(function(r){ if(!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function(d){ return (d && d.requests) || []; });
  }
  function snapshot(){
    return feed(50).then(function(rows){
      var seen = {}; rows.forEach(function(r){ seen[r.transaction_id] = 1; });
      return seen;
    }).catch(function(){ return null; });
  }
  function pick(rows, seen, d){
    var ids = [d && d.id, d && d.faxl && d.faxl.transaction_id];
    var exact = rows.filter(function(r){ return r.transaction_id != null && ids.indexOf(r.transaction_id) >= 0; });
    if(exact.length) return {row: exact[0], how: "id"};
    if(!seen) return {row: null, why: "logged, but could not be matched to this " +
      "message (the request feed could not be read before sending)"};
    var fresh = rows.filter(function(r){ return !seen[r.transaction_id]; });
    if(!fresh.length) return {row: null, retry: true, why: "no new row appeared in " +
      "the request feed for this message"};
    var pt = d && d.usage && d.usage.prompt_tokens;
    if(fresh.length === 1){
      var r1 = fresh[0], odd = pt != null && r1.prompt_tokens != null && r1.prompt_tokens !== pt;
      return {row: r1, how: odd ? "odd" : "only"};
    }
    var same = pt == null ? [] : fresh.filter(function(r){ return r.prompt_tokens === pt; });
    if(same.length === 1) return {row: same[0], how: "tokens"};
    var waiting = fresh.some(function(r){ return r.status === "pending"; });
    return {row: null, retry: waiting, why: "logged, but could not be matched: " +
      fresh.length + " requests arrived at the same time"};
  }
  // The row is written when the request completes, which can land just after
  // the response reaches us: give it a moment before giving up.
  function matchRow(seen, d, tries){
    return feed(50).then(function(rows){
      var m = pick(rows, seen, d);
      var again = m.row ? m.row.status === "pending" : m.retry;
      if(again && tries > 0)
        return new Promise(function(res){ setTimeout(res, 600); })
          .then(function(){ return matchRow(seen, d, tries - 1); });
      return m;
    }).catch(function(e){
      return {row: null, why: "could not read the request feed (" + String(e.message || e) + ")"};
    });
  }
  // The proxy's own error text for a failed /v1 call.
  function v1Error(r){
    return r.text().then(function(t){
      var m = t;
      try{ var j = JSON.parse(t);
        m = (j.error && (j.error.message || j.error)) || j.message || t;
        if(typeof m !== "string") m = JSON.stringify(m); }catch(_){}
      throw new Error("HTTP " + r.status + " — " + String(m).slice(0, 300));
    });
  }

  // Two-step confirm, never window.confirm: the first press arms the button
  // and says what will happen; the second, within five seconds, does it.
  function twoStep(btn, armedLabel, fn){
    var label = btn.textContent, armed = false, t = null;
    function disarm(){ armed = false; clearTimeout(t); btn.textContent = label;
                       btn.classList.remove("r-armed"); }
    btn.addEventListener("click", function(){
      if(!armed){ armed = true; btn.textContent = armedLabel; btn.classList.add("r-armed");
                  t = setTimeout(disarm, 5000); return; }
      disarm(); fn();
    });
    return disarm;
  }
  function open(id){ try{ F.openDrawer(id); }catch(_){} }
"""

# ---------------------------------------------------------------------------
# chat + apps
# ---------------------------------------------------------------------------

RIGHT_JS = r"""
(function(){
  if(!window.faxl) return;
""" + _COMMON_JS + r"""
  // ======================= CHAT =======================
  var log = $("r-chat-log"), form = $("r-chat-form"), input = $("r-chat-in"),
      send = $("r-chat-send"), note = $("r-chat-note"), fresh = $("r-chat-new"),
      picBtn = $("r-chat-pic"), file = $("r-chat-file"), att = $("r-chat-att"),
      thumb = $("r-chat-thumb"), attName = $("r-chat-attname"), attRm = $("r-chat-attrm"),
      empty = $("r-chat-empty");
  // The whole conversation is resent every turn, as every OpenAI-compatible
  // client does -- and that repeated prefix is exactly what faxl makes cheap.
  var history = [], picture = null, busy = false;

  function bubble(who, cls){
    if(empty) empty.hidden = true;
    var el = mk("div", "r-msg-b " + cls);
    el.appendChild(mk("span", "r-who", who));
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }
  function setBody(el, text, cls){
    var who = el.firstChild; clear(el); el.appendChild(who);
    el.appendChild(mk("span", cls || "", text));
  }

  // What faxl DID with the message, from the request feed. Absent fields stay
  // absent; no row at all is SAID, not skipped.
  function verdict(el, m, d){
    var p = mk("p", "r-verdict"), row = m && m.row;
    function bit(t){ if(p.childNodes.length) p.appendChild(document.createTextNode(" · "));
                     p.appendChild(document.createTextNode(t)); }
    if(!row){
      p.appendChild(mk("span", "muted", (m && m.why) || "no verdict available"));
      p.appendChild(document.createTextNode(" · the row, if any, is in the request log"));
      el.appendChild(p); return p;
    }
    if(row.status === "rejected"){
      p.appendChild(mk("span", "pill pill-bad", "REJECTED"));
      bit(row.reject_reason || "no reason recorded");
      el.appendChild(p); return p;
    }
    var oc = String(row.outcome || "").toUpperCase();
    // No outcome means no completion was folded for this row. That is not a
    // miss -- a miss is a measurement -- so it is not painted as one.
    if(!oc) p.appendChild(mk("span", "muted", "logged (" + (row.status || "?") + "), outcome not recorded"));
    else p.appendChild(mk("span", oc === "HIT" ? "pill pill-ok" : "pill", oc === "HIT" ? "HIT" : oc === "MISS" ? "MISS" : oc));
    var y = row.prompt_tokens != null ? row.prompt_tokens :
            (d && d.usage && d.usage.prompt_tokens != null ? d.usage.prompt_tokens : null);
    if(row.prefill_skipped != null)
      bit("from cache " + num(row.prefill_skipped) + " of " + num(y) + " prompt tokens");
    else if(y != null) bit(num(y) + " prompt tokens, cache figure not recorded");
    if(row.resume_pos != null && row.resume_pos > 0) bit("resumed at " + num(row.resume_pos));
    if(row.ttft_ms != null) bit("first reply " + ms(row.ttft_ms));
    if(m.how === "tokens") bit("matched to this message by prompt size");
    if(m.how === "only") p.title = "matched as the only new request in the feed";
    if(m.how === "odd") bit("the only new request, but its prompt size differs " +
                            "from the reply's — treat as unconfirmed");
    el.appendChild(p); return p;
  }

  function setBusy(b){
    busy = b; send.disabled = b; fresh.disabled = b; picBtn.disabled = b;
  }

  function ask(text){
    var content = text;
    if(picture){
      // The shape the apps pages send (tools/photo-tagger's): the words, then
      // the picture, as a data: URL in the request body.
      content = [];
      if(text) content.push({type: "text", text: text});
      content.push({type: "image_url", image_url: {url: picture.url}});
    }
    history.push({role: "user", content: content});
    var you = bubble("you", "r-you");
    if(picture){ var im = document.createElement("img"); im.src = picture.url;
                 im.alt = "the picture sent"; you.appendChild(im); }
    if(text) you.appendChild(mk("span", "", text));
    clearPicture();
    var el = bubble("faxl", "r-them r-pending");
    el.appendChild(mk("span", "", "…"));
    var seen = null, t0 = Date.now();
    setBusy(true); note.textContent = "sending…";
    // Not streamed, so the only honest progress signal is elapsed time.
    var tick = setInterval(function(){
      note.textContent = "waiting for the reply… " + Math.round((Date.now() - t0) / 1000) + " s";
    }, 1000);
    var body = {messages: history, max_tokens: 512};
    var mid = st().model && st().model.id;
    if(mid) body.model = mid;
    return snapshot().then(function(s){
      seen = s;
      return fetch("/v1/chat/completions", {method: "POST",
        headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    }).then(function(r){
      if(!r.ok) return v1Error(r);
      return r.json();
    }).then(function(d){
      var msg = (d.choices && d.choices[0] && d.choices[0].message) || {};
      var out = msg.content || "(empty reply)";
      history.push({role: "assistant", content: out});
      el.classList.remove("r-pending");
      setBody(el, out);
      note.textContent = "reading the request log…";
      return matchRow(seen, d, 5).then(function(m){ verdict(el, m, d); });
    }).catch(function(e){
      // The failed turn comes back out of the history: left in, the next
      // message would resend a question that never got an answer.
      if(history.length && history[history.length - 1].role === "user") history.pop();
      el.className = "r-msg-b r-them r-failed";
      setBody(el, "The request failed: " + String(e.message || e), "r-err");
      // A rejection is logged too, and its row carries the reason.
      if(seen) return matchRow(seen, null, 2).then(function(m){ if(m.row) verdict(el, m, null); });
    }).then(function(){
      clearInterval(tick); setBusy(false); note.textContent = "";
      log.scrollTop = log.scrollHeight;
      input.focus();
      return refresh();
    });
  }

  function clearPicture(){
    picture = null; att.hidden = true; thumb.removeAttribute("src");
    attName.textContent = ""; file.value = "";
  }
  picBtn.addEventListener("click", function(){ file.click(); });
  file.addEventListener("change", function(){
    var f = file.files && file.files[0];
    if(!f) return;
    var vis = st().model ? st().model.vision : null;
    if(vis === false){
      note.textContent = "the model being served does not read pictures";
      file.value = ""; return;
    }
    var rd = new FileReader();
    rd.onload = function(){
      picture = {url: String(rd.result), name: f.name};
      thumb.src = picture.url;
      attName.textContent = f.name + " · " + (picture.url.length / 1048576).toFixed(1) + " MB as sent";
      att.hidden = false;
    };
    rd.onerror = function(){ note.textContent = "could not read that file"; };
    rd.readAsDataURL(f);
  });
  attRm.addEventListener("click", clearPicture);

  form.addEventListener("submit", function(ev){
    ev.preventDefault();
    if(busy) return;
    var t = input.value.trim();
    if(!t && !picture) return;
    input.value = ""; ask(t);
  });
  input.addEventListener("keydown", function(ev){
    if((ev.metaKey || ev.ctrlKey) && ev.key === "Enter"){
      ev.preventDefault();
      if(form.requestSubmit) form.requestSubmit();
      else form.dispatchEvent(new Event("submit", {cancelable: true}));
    }
  });
  fresh.addEventListener("click", function(){
    history = []; clear(log);
    if(empty){ empty.hidden = true; log.appendChild(empty); }
    clearPicture();
    note.textContent = "new conversation — the next message is a cold prompt";
  });

  // ======================= APPS =======================
  var list = $("r-apps-list"), appsEmpty = $("r-apps-empty"), rows = {};
  function withMode(href){ return href + (href.indexOf("?") >= 0 ? "&" : "?") + "mode=human"; }

  function makeRow(a){
    var li = mk("li"), t = mk("span", "r-app-t", ""), job = mk("span", "r-job", "");
    var stop = mk("button", "btn btn-quiet", "stop"); stop.type = "button"; stop.hidden = true;
    var msg = mk("span", "r-msg", "");
    var go = mk("a", "btn", "open"); go.target = "_blank"; go.rel = "noopener";
    li.appendChild(t); li.appendChild(job); li.appendChild(stop); li.appendChild(go); li.appendChild(msg);
    var r = {li: li, t: t, job: job, stop: stop, go: go, msg: msg, slug: a.slug, app: a};
    // Apps open in a new tab. The console's CSP is default-src 'none', which
    // forbids frames, so an iframe in drawer-app would be blank. If the shell
    // allows frame-src 'self' it sets faxl.frameApps = true and the app opens
    // in the drawer instead.
    go.addEventListener("click", function(ev){
      if(F.frameApps !== true) return;
      ev.preventDefault();
      var fr = $("da-frame"), h = $("da-h"), tab = $("da-tab");
      if(h) h.textContent = r.app.title || r.app.slug;
      if(tab) tab.href = go.href;
      if(fr) fr.src = go.href;
      open("drawer-app");
    });
    if(a.slug === "cameraroll"){
      twoStep(stop, "confirm stop", function(){
        stop.disabled = true;
        msg.className = "r-msg"; msg.textContent = "stopping — the batch in hand finishes first…";
        req("/api/apps/cameraroll/stop", {method: "POST"}).then(function(x){
          if(!x.ok || (x.d && x.d.ok === false)){
            msg.className = "r-msg r-bad"; msg.textContent = errText(x.d, x.text, x.status);
          } else { msg.textContent = (x.d && x.d.note) || "stopping"; }
        }).catch(function(e){ msg.className = "r-msg r-bad"; msg.textContent = "could not reach the proxy: " + (e.message || e); })
          .then(function(){ stop.disabled = false; return refresh(); });
      });
    }
    return r;
  }
  function renderApps(s){
    var apps = (s && s.apps) || [], keep = {};
    appsEmpty.hidden = apps.length > 0;
    apps.forEach(function(a){
      if(!a || !a.slug) return;
      keep[a.slug] = 1;
      var r = rows[a.slug] || (rows[a.slug] = makeRow(a));
      r.app = a;
      r.t.textContent = a.title || a.slug;
      r.go.href = withMode(a.href || ("/console/apps/" + encodeURIComponent(a.slug)));
      var j = a.job;
      clear(r.job);
      if(j && j.running){
        r.job.appendChild(mk("span", "r-dot", "● "));
        r.job.appendChild(document.createTextNode("running " + num(j.done) + " / " + num(j.total)));
        r.stop.hidden = a.slug !== "cameraroll";
      } else {
        if(j) r.job.textContent = "last run " + num(j.done) + " / " + num(j.total);
        r.stop.hidden = true;
      }
      list.appendChild(r.li);        // keeps state order; moves, not copies
    });
    Object.keys(rows).forEach(function(k){
      if(!keep[k]){ if(rows[k].li.parentNode) rows[k].li.parentNode.removeChild(rows[k].li); delete rows[k]; }
    });
  }
  F.onState(renderApps);

  // Buttons in this column that open a drawer.
  var col = document.getElementById("col-right");
  if(col) col.addEventListener("click", function(ev){
    var b = ev.target && ev.target.closest ? ev.target.closest("[data-open-drawer]") : null;
    if(b){ ev.preventDefault(); open(b.getAttribute("data-open-drawer")); }
  });
})();
"""

# ---------------------------------------------------------------------------
# drawers
# ---------------------------------------------------------------------------

DRAWERS_JS = r"""
(function(){
  if(!window.faxl) return;
""" + _COMMON_JS + r"""
  // A drawer loads what it shows when it is opened. The shell opens drawers
  // (top bar, left rail); we notice by watching the `hidden` attribute, so no
  // extra hook is needed. faxl.drawers[id].load() is also exposed.
  var loaders = {};
  F.drawers = F.drawers || {};
  function onOpen(id, fn){
    loaders[id] = fn; F.drawers[id] = {load: fn};
    var el = $(id); if(!el) return;
    var was = el.hidden;
    if(typeof MutationObserver !== "undefined")
      new MutationObserver(function(){
        if(was && !el.hidden) fn();
        was = el.hidden;
      }).observe(el, {attributes: true, attributeFilter: ["hidden", "class"]});
  }
  function visible(id){ var el = $(id); return !!el && !el.hidden; }
  function say(el, text, kind){ el.className = "r-msg" + (kind ? " r-" + kind : ""); el.textContent = text; }
  function kv(dl, pairs){
    clear(dl);
    pairs.forEach(function(p){
      dl.appendChild(mk("dt", "", p[0]));
      var dd = mk("dd", "", dash(p[1]));
      if(p[2]){ dd.appendChild(document.createTextNode(" ")); dd.appendChild(mk("span", "muted", p[2])); }
      dl.appendChild(dd);
    });
  }
  function ymd(epoch){
    if(epoch == null || epoch === "" || epoch === 0) return null;
    var n = Number(epoch); if(!isFinite(n)) return String(epoch);
    return new Date(n * 1000).toISOString().slice(0, 10);
  }

  // After a restart, wait for the proxy to come back. It keeps answering for
  // ~2 s before it stops, so an answer only counts once we have seen it go
  // down, or once its uptime is younger than our wait.
  function waitForRestart(onTick){
    var t0 = Date.now(), down = false;
    return new Promise(function(res, rej){
      function tick(){
        var secs = Math.round((Date.now() - t0) / 1000);
        if(onTick) onTick(secs, down);
        if(secs > 300){ rej(new Error("the proxy has not answered for 5 minutes")); return; }
        req("/api/state").then(function(x){
          var up = x.d && x.d.proxy && x.d.proxy.uptime_s;
          if(x.ok && (down || (up != null && up < secs) || secs > 60)){ res(x.d); return; }
          if(!x.ok) down = true;
          setTimeout(tick, 2000);
        }).catch(function(){ down = true; setTimeout(tick, 2000); });
      }
      setTimeout(tick, 2500);
    });
  }

  // ======================= LICENCE =======================
  var dlFacts = $("dl-facts"), dlNone = $("dl-none"), dlKey = $("dl-key"),
      dlSave = $("dl-save"), dlMsg = $("dl-msg");
  function licenceFacts(p){
    var s = st().licence || {}, g = (p && p.grant) || {}, rows = [];
    var licensed = p ? !!p.licensed : (s.state === "active");
    rows.push(["status", p ? (licensed ? "active" : (p.installed ? "installed, not active" : "no licence")) : s.state]);
    rows.push(["licensed to", g.customer || (p && p.customer) || s.licensed_to]);
    if(g.product) rows.push(["product", g.product]);
    if(g.tier) rows.push(["tier", g.tier]);
    if(g.issued) rows.push(["issued", ymd(g.issued)]);
    rows.push(["expires", ymd(g.expiry || (p && p.expiry)) || s.expires]);
    var days = g.days_remaining != null ? g.days_remaining : (p ? p.days_remaining : s.days_remaining);
    rows.push(["days remaining", days == null ? null : Math.floor(Number(days))]);
    if(g.seats) rows.push(["seats", g.seats, "advisory — what was bought, not a limit the proxy enforces"]);
    if(g.features && g.features.length) rows.push(["features", [].concat(g.features).join(", ")]);
    if(g.format) rows.push(["key format", g.format]);
    if(p && p.on_expiry) rows.push(["when it lapses", p.on_expiry]);
    kv(dlFacts, rows);
    dlNone.hidden = licensed;
  }
  function loadLicence(){
    licenceFacts(null);
    return req("/api/licence").then(function(x){
      if(x.ok && x.d) licenceFacts(x.d);
      else say(dlMsg, "could not read the licence: " + errText(x.d, x.text, x.status), "bad");
    }).catch(function(e){ say(dlMsg, "could not reach the proxy: " + (e.message || e), "bad"); });
  }
  onOpen("drawer-licence", loadLicence);
  dlSave.addEventListener("click", function(){
    var key = (dlKey.value || "").trim();
    if(!key){ say(dlMsg, "Paste the key first.", "bad"); return; }
    dlSave.disabled = true; say(dlMsg, "checking…");
    // The key goes to the proxy and nowhere else: never into a message, a
    // toast or the console.
    req("/api/licence", {method: "POST", body: {key: key}}).then(function(x){
      if(x.ok && x.d && x.d.ok === true){
        dlKey.value = "";
        say(dlMsg, "Saved." + (x.d.warning ? " " + x.d.warning : ""), "ok");
        if(x.d.licence) licenceFacts(x.d.licence);
        toast("licence installed", "ok");
        return refresh();
      }
      // The server's typed banner, verbatim (expired arrives as 200 ok:false).
      var m = errText(x.d, x.text, x.status);
      if(x.d && x.d.banner && x.d.banner.detail) m += " (" + x.d.banner.detail + ")";
      say(dlMsg, m, "bad");
    }).catch(function(){
      say(dlMsg, "Could not reach the proxy. The key was not saved.", "bad");
    }).then(function(){ dlSave.disabled = false; });
  });

  // ======================= STORE =======================
  var dsFacts = $("ds-facts"), dsEnv = $("ds-env"), dsPath = $("ds-path"),
      dsCap = $("ds-cap"), dsMove = $("ds-move"), dsSave = $("ds-save"),
      dsMsg = $("ds-msg"), dsProg = $("ds-prog"), dsCfg = null, dsBusy = false;
  function srcOf(v){
    return v && v.value != null ? v.value + " (from " + (v.source || "?") + ")" : null;
  }
  function storeFacts(){
    var c = st().cache || {}, p = dsCfg || {}, s = p.store || {},
        cf = p.config || st().config || {};
    kv(dsFacts, [
      ["path", s.path || c.path],
      ["used", gb(s.used_bytes != null ? s.used_bytes : c.used_bytes)],
      ["cap", c.cap_bytes != null ? gb(c.cap_bytes) : (p.cap_gb != null ? p.cap_gb + " GB" : null)],
      ["free on that disk", gb(s.free_bytes != null ? s.free_bytes : c.free_bytes)],
      ["entries", c.entries == null ? null : num(c.entries) + (c.cold ? " (cold)" : "")],
      // Read-only: the backend and model are switched in the top bar, which
      // writes them to the same settings file. "from" is env | config |
      // default -- what support asks first.
      ["backend", srcOf(cf.backend)],
      ["model", srcOf(cf.model)],
      ["settings file", p.config_file || cf.path]
    ]);
    var envs = [];
    if(s.env_override) envs.push(s.env_var + "=" + s.env_override);
    ["backend", "model"].forEach(function(k){
      var v = cf[k] || {};
      if(v.source === "env") envs.push((v.env_var || k) + "=" + v.value);
    });
    if(p.cap_env_override) envs.push("cap override=" + p.cap_env_override);
    dsEnv.hidden = !envs.length;
    dsEnv.textContent = envs.length ? "Set in the environment, and it outranks anything saved here: " +
      envs.join(", ") + ". Unset it for these fields to take effect." : "";
  }
  function loadStore(){
    storeFacts();
    return req("/api/configure").then(function(x){
      if(!x.ok || !x.d){ say(dsMsg, "could not read the settings: " + errText(x.d, x.text, x.status), "bad"); return; }
      dsCfg = x.d;
      if(!dsBusy){
        dsPath.value = (x.d.store && x.d.store.path) || "";
        dsCap.value = x.d.cap_gb != null ? x.d.cap_gb : "";
      }
      storeFacts();
    }).catch(function(e){ say(dsMsg, "could not reach the proxy: " + (e.message || e), "bad"); });
  }
  onOpen("drawer-store", loadStore);
  function storeBody(){
    var b = {migrate: !!dsMove.checked};
    var p = (dsPath.value || "").trim();
    if(p) b.store = p;
    var c = (dsCap.value || "").trim();
    if(c !== "") b.cap_gb = Number(c);
    return b;
  }
  F.drawers.storeBody = storeBody;
  function pollMigration(){
    return new Promise(function(res){
      function go(){
        // The proxy is down for most of a move: failures here are expected.
        req("/api/configure/migration").then(function(x){
          var d = x.d || {};
          dsProg.hidden = false;
          if(d.phase === "failed"){ dsProg.textContent = "Move failed: " + (d.detail || d.error || "") +
              " — nothing was deleted and the setting is unchanged."; res(false); return; }
          if(d.phase === "done"){ dsProg.textContent = d.detail || "Moved."; res(true); return; }
          if(d.phase && d.phase !== "none") dsProg.textContent = d.phase + "… " + (d.detail || "");
          setTimeout(go, 2000);
        }).catch(function(){ dsProg.hidden = false;
          if(!dsProg.textContent) dsProg.textContent = "proxy stopped for the move…";
          setTimeout(go, 3000); });
      }
      setTimeout(go, 3000);
    });
  }
  twoStep(dsSave, "Confirm — restart the proxy", function(){
    var body = storeBody();
    if(body.cap_gb !== undefined && !(body.cap_gb > 0)){ say(dsMsg, "The cap must be a number greater than 0.", "bad"); return; }
    dsSave.disabled = true; dsBusy = true; say(dsMsg, "checking…");
    req("/api/configure", {method: "POST", body: body}).then(function(x){
      if(!x.ok || !x.d || !x.d.ok){
        say(dsMsg, errText(x.d, x.text, x.status), "bad"); return;
      }
      var notes = (x.d.notes || []).join(" ");
      var wait;
      if(x.d.migrating){
        // The move stops and restarts the proxy itself.
        say(dsMsg, (notes ? notes + " " : "") + "The proxy is stopped while the cache moves.");
        wait = pollMigration().then(function(){ return waitForRestart(); });
      } else if(x.d.restart_required){
        say(dsMsg, (notes ? notes + " " : "") + "Saved. Restarting the proxy…");
        wait = req("/api/restart", {method: "POST", body: {}}).then(function(r){
          if(!r.ok || !r.d || !r.d.ok) throw new Error("saved, but the restart was refused: " + errText(r.d, r.text, r.status) +
                                                        " — the new settings apply at the next start");
          return waitForRestart(function(s, down){
            dsProg.hidden = false;
            dsProg.textContent = (down ? "proxy stopped, waiting for it to answer… " : "restarting… ") + s + " s";
          });
        });
      } else {
        say(dsMsg, notes || "Nothing changed.", "ok"); return;
      }
      return wait.then(function(){
        say(dsMsg, "The proxy is answering again.", "ok");
        dsProg.hidden = true;
        return refresh().then(loadStore);
      });
    }).catch(function(e){ say(dsMsg, String(e.message || e), "bad"); })
      .then(function(){ dsSave.disabled = false; dsBusy = false; });
  });

  // ======================= MODELS =======================
  var dmList = $("dm-list"), dmMsg = $("dm-msg"), dmRepo = $("dm-repo"),
      dmAdd = $("dm-add"), dmAddMsg = $("dm-addmsg"), dmHow = $("dm-howto"), dmBusy = false;
  function hybridLabel(h){ return h === true ? "hybrid" : h === false ? "conventional" : "unknown"; }
  var dmSig = null;
  // Which backend is the cluster is the descriptors' to say (F.be, from
  // state.backend.available): never a backend name tested here.
  function onCluster(s){ return !!(F.be && F.be.onCluster(s)); }
  function clusterName(s){ var c = F.be && F.be.cluster(s); return c ? c.name : null; }
  function beLabel(name){ return F.backendLabel ? F.backendLabel(name) : name; }
  function renderModels(force){
    var s = st(), ms_ = s.models || [];
    // Rebuilt only when something changed: a rebuild on every 3 s poll would
    // disarm a switch button half way through its two-step confirm.
    var ex = (s.backend && s.backend.exo) || {};
    var sig = JSON.stringify([ms_, s.backend && s.backend.name, ex.running, dmBusy, s.memory]);
    if(force !== true && sig === dmSig) return;
    dmSig = sig;
    var onCl = onCluster(s);
    dmHow.textContent = (onCl || ex.running)
      ? "For the cluster: registering fetches the model's card from HuggingFace — no weights. Then download places the weights on the cluster's machines, and it can be served there. " +
        "For this Mac alone: put the weights on disk (hf download org/name) and the model appears under On this Mac."
      : "For this Mac: put the weights on disk (hf download org/name) and the model appears under On this Mac. " +
        "For the cluster: exo is not running — switch the backend to exo cluster, then register the repo here.";
    // On exo, state.models IS exo's catalogue (ids as exo names them, on
    // disk somewhere in the cluster): the same list the top bar's picker and
    // /api/restart use. Back to this Mac is the top bar's backend switch.
    $("dm-lead").textContent = onCl
      ? "On the cluster's disks, as exo's catalogue names them. Serving one restarts the proxy on exo; the whole catalogue, the nodes and downloads are on the exo page (top bar: exo)."
      : "Run in-process by " + (((F.be && F.be.serving(s)) || {}).label || "this machine") + ". Switching restarts the proxy onto the model you pick.";
    if(onCl) ms_ = ms_.filter(function(m){ return m.serving || m.on_disk === true; });
    // The machine budget the fit rule measures against (state.memory).
    var mx = s.memory && s.memory.cluster_ram;
    $("dm-budget").textContent = ((F.fmt && F.fmt.budget(s)) || "") +
      (mx && mx.ram_bytes != null ? " · the cluster: " + gb(mx.ram_bytes) + " RAM over " + mx.nodes +
        " node(s), " + gb(mx.usable_bytes) + " usable" : "");
    clear(dmList);
    if(!ms_.length){ dmList.appendChild(mk("li", "muted", "No models reported on this machine.")); renderCluster(); return; }
    ms_.forEach(function(m){
      var li = mk("li");
      var name = mk("span", "r-mname mono", m.short || m.id); name.title = m.id || "";
      li.appendChild(name);
      if(m.serving) li.appendChild(mk("span", "pill pill-ok", onCl ? "● serving on the cluster" : "● serving"));
      li.appendChild(mk("span", "mono muted", gb(m.size_bytes)));
      li.appendChild(mk("span", "pill", hybridLabel(m.hybrid)));
      if(!m.serving){
        var b = mk("button", "btn btn-quiet", onCl ? "serve" : "switch"); b.type = "button";
        if(m.on_disk === false){ b.disabled = true; b.title = "not on disk"; }
        // The fit rule: the server refuses (409) what does not fit; the
        // button says so first, with the server's reason beside it.
        if(m.fits === false){
          b.disabled = true; b.title = m.fit_reason || "does not fit";
          b.setAttribute("data-fit", "no");
          li.appendChild(mk("span", "muted r-fit", m.fit_reason || "does not fit"));
        }
        if(dmBusy) b.disabled = true;
        twoStep(b, onCl ? "confirm — restarts the proxy on exo with this model" : "confirm — restarts the proxy",
                function(){ switchTo(m); });
        li.appendChild(b);
      }
      dmList.appendChild(li);
    });
    renderCluster();
  }
  function switchTo(m){
    dmBusy = true; renderModels();
    say(dmMsg, "restarting the proxy onto " + (m.short || m.id) + "…");
    req("/api/restart", {method: "POST", body: {model_id: m.id}}).then(function(x){
      if(!x.ok || !x.d || !x.d.ok) throw new Error(errText(x.d, x.text, x.status));
      return waitForRestart(function(s, down){
        say(dmMsg, (down ? "proxy stopped, loading " : "restarting onto ") + (m.short || m.id) + "… " + s + " s");
      });
    }).then(function(){ return refresh(); }).then(function(){
      var now = st().model && st().model.id;
      if(now === m.id) say(dmMsg, "Now serving " + (m.short || m.id) + ".", "ok");
      else say(dmMsg, "The proxy is back, serving " + dash(now) + " — not the model asked for. See restart.log.", "bad");
    }).catch(function(e){ say(dmMsg, String(e.message || e), "bad"); })
      .then(function(){ dmBusy = false; renderModels(); });
  }
  // The backend switch lives in the shell (F.switchBackend): it owns the
  // lamp and the polling until /api/state answers on the new backend.
  function switchBackend(name, id, msgEl){
    if(typeof F.switchBackend !== "function"){ say(msgEl, "the backend switch is not available in this build", "bad"); return; }
    say(msgEl, "switching the backend to " + beLabel(name) +
        (id ? " with " + id : "") + " — the proxy is restarting; the lamp in the top bar follows it.");
    F.switchBackend(name, id || null).catch(function(e){ say(msgEl, String(e.message || e), "bad"); });
  }

  // ---- the exo cluster's catalogue --------------------------------------
  var dxOff = $("dx-off"), dxOffMsg = $("dx-offmsg"), dxSwitch = $("dx-switch"),
      dxOn = $("dx-on"), dxNote = $("dx-note"), dxDl = $("dx-dl"), dxBody = $("dx-body"),
      dxMsg = $("dx-msg"), dxFilter = $("dx-filter"), dxCount = $("dx-count"),
      dxRows = null, dxLoading = false, dxSig = null;
  function exoAvail(){
    return (F.be && F.be.cluster(st())) || null;
  }
  function exoUp(){
    var s = st(), be = s.backend || {};
    return onCluster(s) ? be.up !== false && (be.exo || {}).running !== false : !!(be.exo || {}).running;
  }
  function renderCluster(){
    var s = st(), onCl = onCluster(s), up = exoUp();
    dxOff.hidden = up; dxOn.hidden = !up;
    if(!up){
      dxRows = null;
      var a = exoAvail();
      if(onCl){
        dxOffMsg.textContent = "exo is not answering, and it is the backend: nothing is being served. Bring it back with the backend switch in the top bar, or see ~/.faxl/logs/exo.log.";
        dxSwitch.hidden = true;
      } else {
        dxOffMsg.textContent = "exo is not running — switch the backend to exo cluster to browse and download cluster models." +
          (a && a.can_switch === false && a.note ? " (" + a.note + ")" : "");
        dxSwitch.hidden = false;
        dxSwitch.disabled = !a || a.can_switch === false;
        dxSwitch.title = (a && a.note) || "the proxy restarts onto exo, with faxl in front — about a minute";
      }
      return;
    }
    dxNote.textContent = onCl
      ? "Serving on the exo cluster" + (s.backend.exo && s.backend.exo.nodes != null ? " · " + s.backend.exo.nodes + " node(s)" : "") + ". Serving another cluster model restarts the proxy onto it."
      : "exo is running, but this proxy serves on this Mac: faxl is not in front of that exo. Serving a model here switches the backend to exo cluster (the stray exo is stopped first); downloads start once it is the backend.";
    if(dxRows === null && !dxLoading) loadCatalogue();
    loadProgress();
  }
  function loadCatalogue(){
    dxLoading = true; say(dxMsg, "asking exo for its catalogue…");
    req("/api/models/catalogue?source=exo").then(function(x){
      if(!x.ok || !x.d || !x.d.ok){ dxRows = []; say(dxMsg, errText(x.d, x.text, x.status), "bad"); }
      else { dxRows = x.d.models || []; say(dxMsg, ""); }
      dxSig = null; drawCatalogue();
    }).catch(function(e){ dxRows = []; say(dxMsg, "could not reach the proxy: " + (e.message || e), "bad"); })
      .then(function(){ dxLoading = false; });
  }
  function tick(v){ return v ? "✓" : "·"; }
  function archOf(h){ return h === true ? "hybrid" : h === false ? "attention" : "?"; }
  function drawCatalogue(){
    if(!dxRows) return;
    var s = st(), onExo = onCluster(s);
    var q = (dxFilter.value || "").trim().toLowerCase();
    var sig = JSON.stringify([dxRows.length, q, onExo, dmBusy, s.model && s.model.id]);
    if(sig === dxSig) return;
    dxSig = sig;
    clear(dxBody);
    var shown = 0, hy = 0;
    dxRows.forEach(function(m){ if(m.hybrid === true) hy++; });
    dxRows.forEach(function(m){
      var words = [m.id, m.family, archOf(m.hybrid), m.on_disk ? "on disk" : "", m.vision ? "vision" : "",
                   m.thinking ? "thinking" : "", m.multi_node ? "multi-node" : ""].join(" ").toLowerCase();
      if(q && words.indexOf(q) < 0) return;
      shown++;
      var serving = onExo && (m.id === (s.model && s.model.id));
      var tr = mk("tr", serving ? "r-run" : null);
      var name = mk("td", "r-mid", m.id + (serving ? "  ◀ serving now" : ""));
      tr.appendChild(name);
      var arch = mk("td", m.hybrid === true ? "r-hy" : null, archOf(m.hybrid));
      tr.appendChild(arch);
      tr.appendChild(mk("td", null, m.size_bytes ? gb(m.size_bytes) : (m.gb ? m.gb + " GB" : "—")));
      tr.appendChild(mk("td", null, m.context ? Math.round(m.context / 1024) + "k" : "—"));
      tr.appendChild(mk("td", null, tick(m.vision)));
      tr.appendChild(mk("td", null, tick(m.thinking)));
      tr.appendChild(mk("td", null, tick(m.multi_node)));
      var w = mk("td");
      if(m.on_disk) w.appendChild(mk("span", "r-hy", "on disk"));
      else {
        var d = mk("button", "btn btn-quiet", "download"); d.type = "button";
        if(!onExo){ d.disabled = true; d.title = "downloads start once exo cluster is the backend, so faxl is in front of it"; }
        d.addEventListener("click", function(){ download(m.id, d); });
        w.appendChild(d);
      }
      tr.appendChild(w);
      var act = mk("td");
      if(!serving){
        var b = mk("button", "btn btn-quiet", "serve on the cluster"); b.type = "button";
        if(!m.on_disk && onExo){ b.disabled = true; b.title = "download it first"; }
        if(m.fits === false){
          b.disabled = true; b.title = m.fit_reason || "does not fit";
          b.setAttribute("data-fit", "no");
          act.appendChild(mk("span", "muted r-fit", m.fit_reason || "does not fit"));
        }
        if(dmBusy) b.disabled = true;
        twoStep(b, onExo ? "confirm — restarts the proxy onto it" : "confirm — switches the backend to exo cluster", function(){ serveOnCluster(m.id); });
        act.appendChild(b);
      }
      tr.appendChild(act);
      dxBody.appendChild(tr);
    });
    dxCount.textContent = dxRows.length + " models the cluster can place · " + hy + " hybrid / recurrent" +
      (q ? " · " + shown + " match" : "");
  }
  function serveOnCluster(id){
    var s = st();
    if(!onCluster(s)){ switchBackend(clusterName(s), id, dxMsg); return; }
    dmBusy = true; dxSig = null; drawCatalogue();
    say(dxMsg, "restarting the proxy onto " + id + " on the cluster…");
    req("/api/restart", {method: "POST", body: {model_id: id}}).then(function(x){
      if(!x.ok || !x.d || !x.d.ok) throw new Error(errText(x.d, x.text, x.status));
      return waitForRestart(function(sec, down){
        say(dxMsg, (down ? "proxy stopped, exo placing " : "restarting onto ") + id + "… " + sec + " s");
      });
    }).then(function(){ return refresh(); }).then(function(){
      var now = st().model && st().model.id;
      if(now === id) say(dxMsg, "Now serving " + id + " on the cluster.", "ok");
      else say(dxMsg, "The proxy is back, serving " + dash(now) + " — not the model asked for. See ~/.faxl/logs/restart.log.", "bad");
    }).catch(function(e){ say(dxMsg, String(e.message || e), "bad"); })
      .then(function(){ dmBusy = false; dxSig = null; drawCatalogue(); });
  }
  function download(id, btn){
    btn.disabled = true; say(dxMsg, "asking exo to place " + id + "…");
    req("/api/models/download", {method: "POST", body: {model_id: id}}).then(function(x){
      if(x.ok && x.d && x.d.ok){
        say(dxMsg, x.d.already ? id + " is already on disk." : id + ": downloading in the background — progress above.", "ok");
        loadProgress();
        if(x.d.already){ dxRows = null; loadCatalogue(); }
        return;
      }
      // 409: this proxy is on MLX, and a cluster download needs faxl in
      // front of exo. The server's words say so; they are shown as given.
      say(dxMsg, errText(x.d, x.text, x.status), x.status === 409 ? null : "bad");
      btn.disabled = false;
    }).catch(function(e){ say(dxMsg, "could not reach the proxy: " + (e.message || e), "bad"); btn.disabled = false; });
  }
  var dxProgAt = 0, dxWasActive = false;
  function loadProgress(){
    if(Date.now() - dxProgAt < 2500) return;
    dxProgAt = Date.now();
    req("/api/models/progress").then(function(x){
      clear(dxDl);
      var rows = (x.d && x.d.downloads) || [];
      if(!x.ok || !x.d || x.d.ok === false || x.d.applicable === false) return;
      rows.forEach(function(r){
        var row = mk("div", "r-dlrow");
        var lab = mk("span", "mono", r.model); row.appendChild(lab);
        var bar = mk("span", "r-bar"), fill = mk("i");
        var p = Math.max(0, Math.min(100, Number(r.percent) || 0));
        fill.style.width = p.toFixed(1) + "%";
        bar.setAttribute("role", "progressbar"); bar.setAttribute("aria-valuenow", String(p));
        bar.setAttribute("aria-label", "downloading " + r.model);
        bar.appendChild(fill); row.appendChild(bar);
        row.appendChild(mk("span", "mono", p.toFixed(1) + "% of " + dash(r.gb) + " GB"));
        dxDl.appendChild(row);
      });
      // a download that finished: its row becomes "on disk"
      if(dxWasActive && !rows.length){ dxRows = null; loadCatalogue(); }
      dxWasActive = rows.length > 0;
    }).catch(function(){});
  }
  twoStep(dxSwitch, "confirm — the proxy restarts onto exo, about a minute", function(){ switchBackend(clusterName(st()), null, dxOffMsg); });
  dxFilter.addEventListener("input", function(){ drawCatalogue(); });
  $("dx-reload").addEventListener("click", function(){ dxRows = null; loadCatalogue(); });

  onOpen("drawer-models", function(){ dxRows = null; renderModels(true); });
  F.onState(function(){ if(visible("drawer-models") && !dmBusy){ renderModels(); drawCatalogue(); } });
  dmAdd.addEventListener("click", function(){
    var repo = (dmRepo.value || "").trim();
    if(!repo){ say(dmAddMsg, "Give a HuggingFace repo id (org/name).", "bad"); return; }
    dmAdd.disabled = true; say(dmAddMsg, "asking the proxy…");
    req("/api/models/register", {method: "POST", body: {model_id: repo}}).then(function(x){
      if(x.ok && x.d && x.d.ok){
        var m = x.d.model || {};
        say(dmAddMsg, "Registered " + (m.id || repo) + " with the cluster" + (m.gb ? " (" + m.gb + " GB)" : "") +
            ". No weights yet: download it from the cluster list.", "ok");
        dxRows = null; loadCatalogue();
        return refresh();
      }
      var t = errText(x.d, x.text, x.status);
      // 409: exo is not running. The server says what to do -- the switch.
      say(dmAddMsg, t, x.status === 409 ? null : "bad");
    }).catch(function(e){ say(dmAddMsg, "could not reach the proxy: " + (e.message || e), "bad"); })
      .then(function(){ dmAdd.disabled = false; });
  });

  // ======================= VERIFY =======================
  // Ported from the verify page (_verify_human). temperature 0 and a small
  // max_tokens: a sampled answer would differ for reasons that have nothing
  // to do with the cache. The static preamble clears the first checkpoint
  // (position 250) so later runs have something to resume from.
  var STATIC = ("You are reading a fixed technical preamble that does not change between " +
    "requests. It exists so that the prefill cache has a long, stable prefix " +
    "to store and reuse. ").repeat(14);
  var TESTS = {
    t1: {title: "Same prompt, three times",
         qs: ["Name one primary colour.", "Name one primary colour.", "Name one primary colour."],
         ref: [null, 0, 0]},
    t2: {title: "Shared prefix, different questions",
         qs: ["Name one primary colour.", "Name one metal.", "Name one river.", "Name one primary colour."],
         ref: [null, null, null, 0]}
  };
  var dvOut = $("dv-out"), dvOverall = $("dv-overall"), dvMsg = $("dv-msg"),
      dvRecord = $("dv-record"), dvBtns = [$("dv-t1"), $("dv-t2"), $("dv-both")], dvBusy = false;

  function sha(text){
    try{
      if(window.crypto && crypto.subtle && window.TextEncoder)
        return crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)).then(function(b){
          return Array.prototype.map.call(new Uint8Array(b), function(x){ return ("0" + x.toString(16)).slice(-2); }).join("");
        }).catch(function(){ return null; });
    }catch(_){}
    return Promise.resolve(null);
  }
  function askV(q){
    var body = {temperature: 0, max_tokens: 24, stream: false,
                messages: [{role: "user", content: STATIC + "\n\nQuestion: " + q}]};
    var mid = st().model && st().model.id;
    if(mid) body.model = mid;
    return fetch("/v1/chat/completions", {method: "POST",
      headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)})
      .then(function(r){ if(!r.ok) return v1Error(r); return r.json(); });
  }
  function cell(tr, t, cls){ var td = mk("td", cls || "", t); tr.appendChild(td); return td; }

  // One test: run each question in turn, tie each to its own log row, then
  // judge. PASS needs every required comparison byte-identical AND at least
  // one later run that the log says resumed from the cache -- identical
  // answers from a cache that was never used prove nothing about the cache.
  function runTest(key){
    var T = TESTS[key], runs = [];
    var box = mk("div", "r-res"); box.appendChild(mk("h3", "", T.title));
    var tbl = mk("table", "r-tbl"), head = mk("tr");
    ["run", "question", "sha-256", "first bytes", "outcome", "resumed at", "from cache", "byte-identical"]
      .forEach(function(h){ head.appendChild(mk("th", "", h)); });
    tbl.appendChild(head); box.appendChild(tbl);
    var verdictP = mk("p", "r-overall", "running…"); box.appendChild(verdictP);
    dvOut.appendChild(box);
    var chain = Promise.resolve();
    T.qs.forEach(function(q, i){
      chain = chain.then(function(){
        var tr = mk("tr"); tbl.appendChild(tr);
        cell(tr, String(i + 1)); cell(tr, q);
        var cHash = cell(tr, "…"), cBytes = cell(tr, ""), cOut = cell(tr, ""),
            cRes = cell(tr, ""), cSk = cell(tr, ""), cId = cell(tr, "");
        var seen = null, d = null;
        return snapshot().then(function(s){ seen = s; return askV(q); }).then(function(dd){
          d = dd;
          var a = ((d.choices || [{}])[0].message || {}).content || "";
          return sha(a).then(function(h){ return {a: a, h: h}; });
        }).then(function(o){
          cHash.textContent = o.h ? o.h.slice(0, 12) : "—";
          if(o.h) cHash.title = o.h;
          cBytes.textContent = JSON.stringify(o.a.slice(0, 32)) + (o.a.length > 32 ? "…" : "");
          cBytes.title = o.a.length + " characters";
          return matchRow(seen, d, 5).then(function(m){
            var r = m.row;
            cOut.textContent = r ? String(r.outcome || r.status || "—") : "not matched";
            if(!r) cOut.title = m.why || "";
            cRes.textContent = r ? num(r.resume_pos) : "—";
            cSk.textContent = r ? num(r.prefill_skipped) : "—";
            var ref = T.ref[i], same = null;
            if(ref != null) same = runs[ref] && o.a === runs[ref].a;
            cId.textContent = ref == null ? (i === 0 ? "reference" : "n/a") : (same ? "yes" : "NO");
            if(same === false) cId.className = "r-err";
            runs.push({a: o.a, h: o.h, row: r, same: same, why: m.why});
          });
        });
      });
    });
    return chain.then(function(){
      var bad = runs.some(function(r){ return r.same === false; });
      var matched = runs.filter(function(r){ return r.row; }).length;
      var resumed = runs.slice(1).some(function(r){
        return r.row && ((r.row.resume_pos || 0) > 0 || (r.row.prefill_skipped || 0) > 0); });
      var status, text;
      if(bad){ status = "fail"; text = "FAIL — answers differ between a cold run and a cached run."; }
      else if(resumed){ status = "pass"; text = "PASS — byte-identical, and the log shows later runs resumed from the cache."; }
      else { status = "inconclusive"; text = "INCONCLUSIVE — byte-identical, but " +
        (matched < runs.length ? "not every run could be matched to its log row" : "the log shows no run resumed from the cache") +
        ", so the cache was not exercised."; }
      verdictP.textContent = text;
      verdictP.className = "r-overall " + (status === "pass" ? "r-ok" : status === "fail" ? "r-err" : "r-warn");
      return {key: key, title: T.title, status: status, runs: runs};
    }, function(e){
      verdictP.className = "r-overall r-err";
      verdictP.textContent = "Could not complete: " + String(e.message || e);
      return {key: key, title: T.title, status: "error", error: String(e.message || e), runs: runs};
    });
  }

  function runSet(keys){
    if(dvBusy) return Promise.resolve();
    dvBusy = true; dvBtns.forEach(function(b){ if(b) b.disabled = true; });
    clear(dvOut); dvOverall.hidden = true; dvRecord.hidden = true;
    say(dvMsg, "sending requests through the proxy… the first is a cold run and may take a moment");
    var results = [], chain = Promise.resolve();
    keys.forEach(function(k){ chain = chain.then(function(){ return runTest(k).then(function(r){ results.push(r); }); }); });
    return chain.then(function(){
      var any = function(s){ return results.some(function(r){ return r.status === s; }); };
      var overall = any("fail") ? "fail" : any("error") ? "error" : any("inconclusive") ? "inconclusive" : "pass";
      dvOverall.hidden = false;
      dvOverall.className = "r-overall " + (overall === "pass" ? "r-ok" : overall === "fail" || overall === "error" ? "r-err" : "r-warn");
      dvOverall.textContent = "Overall: " + (overall === "pass" ? "PASS" : overall === "fail" ? "FAIL" :
        overall === "error" ? "did not complete" : "INCONCLUSIVE");
      say(dvMsg, "");
      if(overall !== "pass" && overall !== "fail") return refresh();
      // Offer the result to the proxy, which owns the lossless status. A build
      // that does not record browser runs says so, and we repeat it.
      var body = {record: {status: overall, model: (st().model && st().model.id) || null,
        tests: results.map(function(r){ return {name: r.title, status: r.status,
          runs: r.runs.map(function(x){ return {answer_sha256: x.h, identical: x.same,
            transaction_id: x.row ? x.row.transaction_id : null,
            resume_pos: x.row ? x.row.resume_pos : null,
            prefill_skipped: x.row ? x.row.prefill_skipped : null}; })}; })}};
      return req("/api/verify", {method: "POST", body: body}).then(function(x){
        if(!x.ok){
          dvRecord.hidden = false;
          dvRecord.textContent = "The proxy did not record this result (" + errText(x.d, x.text, x.status) +
            "), so the lossless status in the top bar stays as the proxy reports it.";
        }
      }).catch(function(){}).then(refresh);
    }).then(function(){
      dvBusy = false; dvBtns.forEach(function(b){ if(b) b.disabled = false; });
    });
  }
  F.drawers.runVerify = runSet;
  $("dv-t1").addEventListener("click", function(){ runSet(["t1"]); });
  $("dv-t2").addEventListener("click", function(){ runSet(["t2"]); });
  $("dv-both").addEventListener("click", function(){ runSet(["t1", "t2"]); });

  // ======================= DIAGNOSTICS =======================
  var ddPre = $("dd-pre"), ddMsg = $("dd-msg");
  function loadDiag(){
    say(ddMsg, "loading…");
    return req("/api/diagnostics").then(function(x){
      if(x.ok && x.d != null){ ddPre.textContent = JSON.stringify(x.d, null, 2); say(ddMsg, ""); }
      else say(ddMsg, errText(x.d, x.text, x.status), "bad");
    }).catch(function(e){ say(ddMsg, "could not reach the proxy: " + (e.message || e), "bad"); });
  }
  onOpen("drawer-diagnostics", loadDiag);
  $("dd-reload").addEventListener("click", loadDiag);
  $("dd-copy").addEventListener("click", function(){
    var t = ddPre.textContent || "";
    function fallback(){
      try{ var r = document.createRange(); r.selectNodeContents(ddPre);
           var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
           say(ddMsg, "selected — press Cmd/Ctrl+C"); }catch(_){ say(ddMsg, "could not copy", "bad"); }
    }
    if(navigator.clipboard && navigator.clipboard.writeText)
      navigator.clipboard.writeText(t).then(function(){ say(ddMsg, "copied", "ok"); }, fallback);
    else fallback();
  });

  // Buttons inside drawers that open another drawer.
  var host = document.getElementById("drawers");
  if(host) host.addEventListener("click", function(ev){
    var b = ev.target && ev.target.closest ? ev.target.closest("[data-open-drawer]") : null;
    if(b){ ev.preventDefault(); open(b.getAttribute("data-open-drawer")); }
  });
  // A drawer already open when this script runs (the shell restored one).
  Object.keys(loaders).forEach(function(id){ if(visible(id)) loaders[id](); });
})();
"""

__all__ = ["RIGHT_HTML", "RIGHT_CSS", "RIGHT_JS", "DRAWERS_HTML", "DRAWERS_JS"]

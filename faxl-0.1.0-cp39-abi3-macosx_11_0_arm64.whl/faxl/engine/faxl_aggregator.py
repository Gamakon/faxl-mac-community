# VENDORED FROM faxl-core/python/engine/faxl_aggregator.py — DO NOT EDIT HERE.
# Edit faxl-core and run tools/sync_engine.py --sync mac; the gate runs --check.
#!/usr/bin/env python3
"""Halo telemetry aggregator — the ONE aggregation logic (local == server).

Consumes the transaction event stream (integration/telemetry/faxl_event.proto)
and produces the three surfaces the console reads:

  (a) per-tenant/day ROLLUPS  — sparkline, deltas, headline totals
  (b) a bounded ring of recent TRANSACTIONS — the requests feed
  (c) transaction lookup by id — full folded event (ladder + timings) for the
      request-detail view

Design (docs/proxy-console-telemetry-plan.md, settled through review):

  * Fold PER TRANSACTION, never rely on stream order. Local FileWal is in-order;
    server Kafka is only per-partition-ordered. A transaction's status derives
    from which event TYPES are present, not arrival order (COMPLETION may precede
    START). This is what makes "same canonical event set -> same output" true on
    both topologies.

  * Idempotency: dedupe on immutable event_id. A repeated event_id is ignored.
    A DIFFERENT event_id that collides on (txn, attempt, type, seq) is a data bug
    surfaced loudly (not silently dropped).

  * Terminal = COMPLETION or any REJECTED (syntactic seq=0, budget-overrun seq=1,
    serve_error seq=99). `incomplete` = a START past its watermark with no
    terminal. A late terminal RECONCILES (clears incomplete, counts the terminal)
    — never double-counted.

  * Honesty is DATA: rollups carry n_measured / n_estimated + estimator id/version.
    With today's emit every cold basis is ESTIMATED, so time_saved aggregates as
    estimated-only (measured coverage 0) while tokens_skipped is measured. That is
    correct output, not a bug. Tokens and time stay SEPARATE (W1).

  * Tenant-scoped even though local is single-tenant — or the server milestone
    rewrites this logic (the overlap sin).

v1 runtime: refresh-on-read. Remembers its WAL byte offset and consumes
incrementally; deterministic and testable, no background thread. Checkpointing +
Kafka source are the server milestone.
"""
import os
import struct
import time
from collections import defaultdict, deque

from faxl.engine.telemetry import faxl_event_pb2 as pb

# Default watermark for START records with deadline_unix_ns == 0 (unset). Serves
# queue for minutes under the proxy's serve lock, so this is generous.
DEFAULT_WATERMARK_S = float(os.environ.get("FAXL_TELEMETRY_WATERMARK_S", str(30 * 60)))

RECENT_RING = int(os.environ.get("FAXL_TELEMETRY_RECENT", "500"))

# Terminal REJECTED seqs the emitter uses (documented in the proto / emitter):
#   0  syntactic/validation rejection
#   1  budget-overrun (closes an already-durable START)
#  99  serve_error (request errored after START)
# Any REJECTED type is terminal regardless of seq; these are just for labelling.
_REJECT_LABEL = {0: "validation", 1: "budget_overrun", 99: "serve_error"}


def _day(unix_ns):
    """UTC day bucket 'YYYY-MM-DD' from a wall-clock ns timestamp."""
    return time.strftime("%Y-%m-%d", time.gmtime(unix_ns / 1e9))


class Transaction:
    """Folded state for one transaction_id across its events."""
    __slots__ = ("txn_id", "tenant", "backend", "model", "day",
                 "start", "completion", "rejected", "started_at_ns",
                 "deadline_ns")

    def __init__(self, txn_id):
        self.txn_id = txn_id
        self.tenant = ""
        self.backend = pb.BACKEND_UNSPECIFIED
        self.model = ""
        self.day = None
        self.start = None        # the START event (or None if only completion seen)
        self.completion = None   # the COMPLETION event
        self.rejected = None     # the first terminal REJECTED event
        self.started_at_ns = 0
        self.deadline_ns = 0

    @property
    def terminal(self):
        return self.completion is not None or self.rejected is not None

    def status(self, now_ns):
        if self.completion is not None:
            return "completed"
        if self.rejected is not None:
            return "rejected"
        # only a START (or nothing terminal) so far
        if self.start is not None:
            wm = self.deadline_ns or (self.started_at_ns
                                      + int(DEFAULT_WATERMARK_S * 1e9))
            if now_ns > wm:
                return "incomplete"
            return "pending"
        return "pending"


class Aggregator:
    """Folds events into rollups + recent ring + by-id lookup. Pure: feed it
    events (from iter_file_wal or any source). Idempotent on event_id."""

    def __init__(self):
        # NOTE (deferred, docs/proxy-console-telemetry-plan.md retention section):
        # _txns / _seen_event_ids grow unbounded — bounded retention + WAL rotation
        # are owed to the console/server milestone. attempt_id>0 currently collapses
        # into one Transaction (emitter never sets it today); attempt-splitting is
        # deferred with it.
        self._txns = {}                       # txn_id -> Transaction
        self._seen_event_ids = set()          # dedupe
        self._seen_tuples = {}                 # (txn,attempt,type,seq) -> event_id
        self.data_bugs = []                    # loud: tuple-collisions, surfaced
        self._recent = deque(maxlen=RECENT_RING)  # txn_ids, newest last
        self._wal_offset = 0                   # byte offset consumed (refresh-on-read)

    # ---- ingest ----
    def ingest(self, ev):
        """Fold one TelemetryEvent. Returns False if it was a duplicate."""
        if ev.event_id in self._seen_event_ids:
            return False
        self._seen_event_ids.add(ev.event_id)
        tup = (ev.transaction_id, ev.attempt_id, ev.event_type, ev.seq)
        prior = self._seen_tuples.get(tup)
        if prior is not None and prior != ev.event_id:
            # Same logical slot, DIFFERENT event_id — a real data bug, not a retry.
            # Do NOT fold it: overwriting-with-latest would make state depend on
            # arrival order (breaking the equivalence property). First-ingested
            # wins deterministically; the transaction is flagged suspect.
            self.data_bugs.append(f"duplicate slot {tup} with distinct event_ids "
                                  f"{prior} vs {ev.event_id}")
            return False
        self._seen_tuples[tup] = ev.event_id

        t = self._txns.get(ev.transaction_id)
        if t is None:
            t = Transaction(ev.transaction_id)
            self._txns[ev.transaction_id] = t
            self._recent.append(ev.transaction_id)
        # attribution: any event carries it; prefer non-empty
        t.tenant = ev.tenant or t.tenant
        t.backend = ev.backend or t.backend
        t.model = ev.model or t.model
        # day bucket keyed on the START's wall time when available, else this ev's
        if ev.emitted_at_unix_ns and (t.day is None or ev.event_type == pb.START):
            t.day = _day(ev.emitted_at_unix_ns)

        if ev.event_type == pb.START:
            t.start = ev
            t.started_at_ns = ev.emitted_at_unix_ns
            t.deadline_ns = ev.deadline_unix_ns
        elif ev.event_type == pb.COMPLETION:
            t.completion = ev
        elif ev.event_type == pb.REJECTED:
            if t.rejected is None:
                t.rejected = ev
        return True

    def ingest_file_wal(self, path):
        """Incrementally consume new bytes from a FileWal since the last read
        (refresh-on-read). Tolerates a torn tail frame."""
        if not os.path.exists(path):
            return 0
        n = 0
        with open(path, "rb") as f:
            f.seek(self._wal_offset)
            while True:
                pos = f.tell()
                hdr = f.read(4)
                if len(hdr) < 4:
                    break
                (ln,) = struct.unpack(">I", hdr)
                payload = f.read(ln)
                if len(payload) < ln:
                    # torn tail — stop, leave offset at the start of this frame
                    f.seek(pos)
                    break
                ev = pb.TelemetryEvent()
                try:
                    ev.ParseFromString(payload)
                except Exception as e:  # noqa: BLE001 — surface loudly, never crash the caller
                    self.data_bugs.append(f"WAL parse failure at offset {pos}: {e}")
                    # skip this frame; FileWal recovery-on-open prevents mid-file
                    # garbage, so this should only ever be a corrupt record.
                    self._wal_offset = f.tell()
                    continue
                if self.ingest(ev):
                    n += 1
                self._wal_offset = f.tell()
        return n

    # ---- output surfaces ----
    def overview(self, tenant=None, now_ns=None):
        """Rollup totals + measured/estimated coverage. Optionally tenant-scoped."""
        now_ns = now_ns or int(time.time() * 1e9)
        agg = {
            "requests": 0, "hits": 0, "misses": 0,
            "completed": 0, "rejected": 0, "incomplete": 0, "pending": 0,
            "tokens_skipped": 0, "tokens_prefilled": 0,
            "time_saved_ms_estimated": 0.0,
            "n_saved_measured": 0, "n_saved_estimated": 0,
            "estimators": set(),
        }
        for t in self._txns.values():
            if tenant is not None and t.tenant != tenant:
                continue
            st = t.status(now_ns)
            agg[st] = agg.get(st, 0) + 1
            if st == "completed":
                agg["requests"] += 1
                c = t.completion
                if c.outcome == pb.HIT:
                    agg["hits"] += 1
                elif c.outcome == pb.MISS:
                    agg["misses"] += 1
                agg["tokens_skipped"] += c.cost.prefill_skipped
                agg["tokens_prefilled"] += c.cost.prefill_paid
                # saved TIME is a counterfactual; carry basis coverage as DATA.
                if c.cost.cold_basis == pb.MEASURED:
                    agg["n_saved_measured"] += 1
                elif c.cost.cold_basis == pb.ESTIMATED:
                    agg["n_saved_estimated"] += 1
                    agg["time_saved_ms_estimated"] += c.cost.cold_prefill_ms_est
                if c.cost.estimator_id:
                    agg["estimators"].add(
                        f"{c.cost.estimator_id}@{c.cost.estimator_version}")
        agg["estimators"] = sorted(agg["estimators"])
        denom = agg["hits"] + agg["misses"]
        agg["hit_rate"] = round(agg["hits"] / denom, 4) if denom else 0.0
        # headline-eligibility input: fraction of saved-time rows that are MEASURED
        sv = agg["n_saved_measured"] + agg["n_saved_estimated"]
        agg["saved_time_measured_coverage"] = (
            round(agg["n_saved_measured"] / sv, 4) if sv else 0.0)
        return agg

    def daily(self, tenant=None, days=7, now_ns=None):
        """Per-UTC-day rollups (newest last) for the sparkline + delta-vs-yesterday.
        Same fold as overview(), grouped by the transaction's day. Days are UTC —
        the console must label 'today' with the UTC date."""
        now_ns = now_ns or int(time.time() * 1e9)
        by_day = defaultdict(lambda: {
            "requests": 0, "hits": 0, "misses": 0,
            "tokens_skipped": 0, "time_saved_ms_estimated": 0.0,
            "n_saved_measured": 0, "n_saved_estimated": 0})
        for t in self._txns.values():
            if tenant is not None and t.tenant != tenant:
                continue
            if t.status(now_ns) != "completed" or t.day is None:
                continue
            d = by_day[t.day]
            c = t.completion
            d["requests"] += 1
            if c.outcome == pb.HIT:
                d["hits"] += 1
            elif c.outcome == pb.MISS:
                d["misses"] += 1
            d["tokens_skipped"] += c.cost.prefill_skipped
            if c.cost.cold_basis == pb.MEASURED:
                d["n_saved_measured"] += 1
            elif c.cost.cold_basis == pb.ESTIMATED:
                d["n_saved_estimated"] += 1
                d["time_saved_ms_estimated"] += c.cost.cold_prefill_ms_est
        rows = []
        for day in sorted(by_day)[-days:]:
            r = dict(by_day[day]); r["day"] = day
            denom = r["hits"] + r["misses"]
            r["hit_rate"] = round(r["hits"] / denom, 4) if denom else 0.0
            sv = r["n_saved_measured"] + r["n_saved_estimated"]
            r["saved_time_measured_coverage"] = (
                round(r["n_saved_measured"] / sv, 4) if sv else 0.0)
            rows.append(r)
        return rows

    def recent(self, tenant=None, limit=50, now_ns=None):
        """Newest-first recent transactions for the requests feed (spec §5.2:
        time, hit/miss, rung, prefix tokens reused, prefill computed, TTFT, model,
        client)."""
        now_ns = now_ns or int(time.time() * 1e9)
        out = []
        for txn_id in reversed(self._recent):
            t = self._txns.get(txn_id)
            if t is None or (tenant is not None and t.tenant != tenant):
                continue
            c = t.completion
            out.append({
                "transaction_id": txn_id, "tenant": t.tenant,
                "status": t.status(now_ns), "day": t.day,
                "ts": (t.started_at_ns / 1e9 if t.started_at_ns else None),  # time
                "client": (t.start.client_label if t.start else ""),         # client
                "backend": pb.Backend.Name(t.backend), "model": t.model,
                "outcome": (pb.LookupOutcome.Name(c.outcome) if c else None),
                "resume_pos": (c.resume_pos if c else None),                 # rung
                "prefill_skipped": (c.cost.prefill_skipped if c else None),  # reused
                "prefill_paid": (c.cost.prefill_paid if c else None),        # computed
                "prompt_tokens": (c.cost.prompt_tokens if c else None),      # size received
                "wall_ms": (c.cost.warm_wall_ms if c else None),             # clock time
                "out_tokens": (c.out_tokens if c else None),                 # generated
                "hit_tier": (pb.HitTier.Name(c.hit_tier) if c else None),
                "ttft_ms": (c.cost.ttft_ms if c and c.cost.has_ttft else None),
                "reject_reason": (t.rejected.reject_reason if t.rejected else None),
            })
            if len(out) >= limit:
                break
        return out

    def ttft_stats(self, tenant=None, now_ns=None):
        """Median TTFT for warm (hit) vs cold (miss) completed transactions.
        Honors has_ttft — a backend that does not emit TTFT (mlx/hf often) yields
        None, NOT 0 (absent != zero). Aggregation lives here, not in the shaper."""
        now_ns = now_ns or int(time.time() * 1e9)
        warm, cold = [], []
        for t in self._txns.values():
            if tenant is not None and t.tenant != tenant:
                continue
            c = t.completion
            if c is None or not c.cost.has_ttft:
                continue
            (warm if c.outcome == pb.HIT else cold).append(c.cost.ttft_ms)

        def _median(xs):
            if not xs:
                return None
            xs = sorted(xs)
            n = len(xs)
            return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2.0
        return {"warm_ms": _median(warm), "cold_ms": _median(cold),
                "n_warm": len(warm), "n_cold": len(cold),
                "available": bool(warm or cold)}

    def transaction(self, txn_id, now_ns=None):
        """Full folded detail for the request-detail view (ladder + timings)."""
        now_ns = now_ns or int(time.time() * 1e9)
        t = self._txns.get(txn_id)
        if t is None:
            return None
        c = t.completion
        detail = {"transaction_id": txn_id, "tenant": t.tenant,
                  "status": t.status(now_ns), "day": t.day,
                  "backend": pb.Backend.Name(t.backend), "model": t.model}
        if t.start is not None:
            detail["start"] = {"prompt_bytes": t.start.prompt_bytes,
                               "n_messages": t.start.n_messages,
                               "client_label": t.start.client_label}
        if c is not None:
            detail["outcome"] = pb.LookupOutcome.Name(c.outcome)
            detail["resume_pos"] = c.resume_pos
            detail["hit_tier"] = pb.HitTier.Name(c.hit_tier)
            detail["out_tokens"] = c.out_tokens
            detail["ladder"] = [
                {"position": p.position,
                 "confirm": pb.ConfirmOutcome.Name(p.confirm),
                 "rung_key": p.rung_key.digest.hex()[:16]} for p in c.ladder]
            detail["timings_ms"] = {
                "hash_build": c.timings.hash_build_ms,
                "confirm": c.timings.confirm_ms,
                "blob_load": c.timings.blob_load_ms,
                "prefill": c.timings.prefill_ms,
                "decode": c.timings.decode_ms}
            detail["cost"] = {
                "prompt_tokens": c.cost.prompt_tokens,
                "prefill_paid": c.cost.prefill_paid,
                "prefill_skipped": c.cost.prefill_skipped,
                "warm_wall_ms": c.cost.warm_wall_ms,
                "cold_basis": pb.Basis.Name(c.cost.cold_basis),
                "cold_prefill_ms_est": c.cost.cold_prefill_ms_est,
                "ttft_ms": (c.cost.ttft_ms if c.cost.has_ttft else None)}
        if t.rejected is not None:
            detail["reject_reason"] = t.rejected.reject_reason
        return detail

    def health(self, now_ns=None):
        now_ns = now_ns or int(time.time() * 1e9)
        inc = sum(1 for t in self._txns.values()
                  if t.status(now_ns) == "incomplete")
        return {"transactions": len(self._txns), "incomplete": inc,
                "data_bugs": self.data_bugs[:5], "n_data_bugs": len(self.data_bugs)}

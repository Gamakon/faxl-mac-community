# Vendored engine module (faxl_panel_about.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""The console's about page: who we are, what to try, how to hire us.

`/console/about`, rendered by render_about(state). It wears the panel's top bar
and stylesheet -- imported from faxl_panel, never copied -- so it reads as the
same product, then gives itself room: one calm column, the serif wordmark and
the turtle. It is the one console page allowed to breathe.

THE WORDS COME FROM THE PUBLIC SITE. faxl-website/site/{about,index,enterprise,
cluster}.html are Gamakon's own wording; nothing here claims more than they do.
The NVIDIA edition is "in development" because the site says "Apple silicon
now, NVIDIA next"; the cluster is "being finished now" because cluster.html
says so. Edit the constants below; the human page, the agent page and the JSON
all read them, so the three cannot disagree.

THE PHOTOS are the only files the page reads. They live in
$FAXL_HOME/about/photo-1.jpg and photo-2.jpg (FAXL_HOME defaults to ~/.faxl),
served by /console/about/photo/<n>.jpg. The console decides whether each is
present and passes that in `state`; an absent one is a placeholder frame that
says exactly where to drop the file.

CSP. The page is served under the console's HUMAN_CSP: inline style and script,
img-src 'self' data:, no external fetch. The only links that leave the console
are faxl.ai, gamakon.ai, the booking page on the site's enterprise page, and a
mailto.
"""

import html as _html
import os as _os

from faxl.engine.faxl_panel import (PANEL_CSS, TOPBAR_HTML, LOGO_SVG_URI,
                                    ICON_32_URI, _font_css)

# --------------------------------------------------------------------------
# The content. Plain strings; escaped on the way out, never trusted as markup.
# --------------------------------------------------------------------------
COMPANY = {
    "name": "Gamakon Ltd",
    "place": "London",
    "strapline": "navigate the frontier",
    "about": ("faxl is one of Gamakon's products. Gamakon is a UK R&D firm "
              "in London, commercialising original algorithms that solve "
              "scientific and industry problems, and we build a family of "
              "software for sovereign AI: 100% private AI, on hardware you "
              "own or bare metal you rent. faxl is the caching layer in "
              "front of your own models; cogbot.io brings compiled skills "
              "to the machine beside them."),
    "measured": ("Every number we publish is measured, and says which model "
                 "and workload it came from."),
    "site": "https://gamakon.ai",
}

# (key, name, line, href, link label). key picks the glyph.
PRODUCTS = [
    ("mac", "faxl on this Mac",
     "Your prefill cache on an M-series Mac, via MLX. This console is it.",
     "/console", "open the panel"),
    ("exo", "faxl on an exo cluster",
     "Several Apple-silicon Macs as one engine, over Thunderbolt. Being "
     "finished now.",
     "/console/exo", "see the cluster"),
    ("nvidia", "faxl for NVIDIA",
     "The vLLM port passes the same byte-identity bars on GPU. In "
     "development.",
     "https://faxl.ai", "read more on faxl.ai"),
    ("ocr", "Read the text (OCR)",
     "Turn a photograph of a page, receipt or sign into clean text.",
     "/console/apps/ocr", "try it"),
    ("voice2text", "Voice to text",
     "Talk; get clean text. Private, on this machine.",
     "/console/apps/voice2text", "try it"),
    # Parked 2026-09-22 with the app itself (faxl_console.APPS_PARKED):
    # ("whiteboard", "Whiteboard to diagram",
    #  "Photograph a drawing on a whiteboard; get a Mermaid diagram.",
    #  "/console/apps/whiteboard", "try it"),
    ("cameraroll", "Tag your camera roll",
     "Caption and keyword your photographs, in bulk, on your own Mac.",
     "/console/apps/cameraroll", "try it"),
    ("cogbot", "cogbot.io",
     "Compiled WASM skill files, delivered to your local computer, so a "
     "weak local AI can do things it cannot do alone.",
     "https://cogbot.io", "go to cogbot.io"),
    ("shop", "faxl.ai",
     "Get a licence, and read how faxl works. Free for noncommercial use "
     "while we are pre-launch.",
     "https://faxl.ai", "go to faxl.ai"),
]

WORK = [
    ("Agentic consulting",
     "Every agent is defined by long prompts sent with every question: skill "
     "files, domain knowledge, rules, history. We help you engineer them — "
     "what is static goes first, what changes goes last — so the cache "
     "does the work and your token spend is something you can see and "
     "control."),
    ("Enterprise sovereign AI",
     "faxl is an OpenAI-compatible proxy in front of inference you control; "
     "existing clients change one URL. Run your own models in your own VPC or "
     "on-premises bare metal, and every request passes one place that knows "
     "what ran, for whom, and what it cost. Moving off hosted AI? Bring your "
     "traffic profile and model mix, and we will measure what a warm cache "
     "takes off the bill. Some controls are specified and in build rather "
     "than shipped; ask us which."),
]

CONTACT = {
    "name": "Andrew Morgan",
    "email": "andrew@gamakon.ai",
    # The booking link on faxl.ai/enterprise.html ("Book a meeting").
    "meeting": "https://calendly.com/andrew-gamakon/30min",
}

# The people, as gamakon.ai's team page has them. The photos are read from
# disk (photo_dir); the words live here.
PHOTOS = [
    {"n": 1, "file": "photo-1.jpg", "caption": "Andrew Morgan",
     "role": "Founder · CEO",
     "bio": ("Thirty years building enterprise data programmes. Scaled and "
             "led global teams across consulting and industry; delivered "
             "large-scale data platforms and AI solutions in public and "
             "private sectors. Data Science textbook author."),
     "tags": ["AI & data strategy", "Data mgmt., quality & platforms",
              "Distributed computing", "Multi-objective optimisation"]},
    {"n": 2, "file": "photo-2.jpg", "caption": "Jesung Park",
     "role": "Founder · Director of AI",
     "bio": ("Fifteen years applying machine learning techniques to solve "
             "business problems. Deployed computer vision pipelines, "
             "reinforcement learning-based recommender systems, an ML "
             "evaluation that saved a telecoms operator $600k a year, and "
             "most recently autonomous-vehicle simulation stacks."),
     "tags": ["Deep learning", "Reinforcement learning", "Computer vision",
              "NLP & generative AI", "Simulation"]},
]

FOOTER = "faxl is a Gamakon Ltd product, one of several. © 2026 Gamakon Ltd."


def photo_dir():
    """Where the photos live: $FAXL_HOME/about, or ~/.faxl/about. Read per call,
    so a changed FAXL_HOME (or a test's monkeypatch) is seen at once."""
    home = _os.environ.get("FAXL_HOME") or _os.path.expanduser("~/.faxl")
    return _os.path.join(home, "about")


def photo_path(n):
    """The file behind /console/about/photo/<n>.jpg, or None for any n that is
    not a slot. Fixed names only: n never builds a path."""
    for p in PHOTOS:
        if p["n"] == n:
            return _os.path.join(photo_dir(), p["file"])
    return None


def photo_state():
    """[{present, v}] per slot; v is the file's mtime, used as a cache-buster so
    a replaced photo shows at once despite the long cache header."""
    out = []
    for p in PHOTOS:
        path = photo_path(p["n"])
        try:
            st = _os.stat(path)
            ok = _os.path.isfile(path) and st.st_size > 0
            out.append({"present": bool(ok), "v": int(st.st_mtime) if ok else None})
        except OSError:
            out.append({"present": False, "v": None})
    return out


def about_payload(photos=None):
    """The ?format=json body: {company, products, contact, photos}."""
    photos = photos if photos is not None else photo_state()
    return {
        "company": {k: COMPANY[k] for k in
                    ("name", "place", "strapline", "about", "site")},
        "products": [{"name": n, "line": line, "href": h}
                     for _k, n, line, h, _lab in PRODUCTS],
        "work": [{"title": t, "text": x} for t, x in WORK],
        "contact": dict(CONTACT),
        "photos": [{"present": bool(p.get("present")),
                    "src": "/console/about/photo/%d.jpg" % s["n"],
                    "file": "~/.faxl/about/" + s["file"],
                    "caption": s["caption"]}
                   for s, p in zip(PHOTOS, photos)],
    }


# --------------------------------------------------------------------------
# Glyphs: monochrome line drawings in currentColor, so both themes hold.
# --------------------------------------------------------------------------
_G = ('<svg class="glyph" viewBox="0 0 48 48" width="48" height="48" '
      'aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" '
      'stroke-linecap="round" stroke-linejoin="round">%s</svg>')
GLYPHS = {
    "mac": _G % ('<rect x="7" y="9" width="34" height="23" rx="2"/>'
                 '<path d="M19 32l-2 7h14l-2-7M14 39h20"/>'),
    "exo": _G % ('<rect x="4" y="18" width="11" height="12" rx="1.5"/>'
                 '<rect x="18.5" y="18" width="11" height="12" rx="1.5"/>'
                 '<rect x="33" y="18" width="11" height="12" rx="1.5"/>'
                 '<path d="M9.5 18v-5h29v5M24 13v5" stroke-dasharray="2 2"/>'),
    "nvidia": _G % ('<rect x="13" y="13" width="22" height="22" rx="2"/>'
                    '<rect x="19" y="19" width="10" height="10"/>'
                    '<path d="M18 13V7M24 13V7M30 13V7M18 41v-6M24 41v-6M30 41'
                    'v-6M13 18H7M13 24H7M13 30H7M41 18h-6M41 24h-6M41 30h-6"/>'),
    "ocr": _G % ('<path d="M12 5h17l8 8v30H12z"/><path d="M29 5v8h8"/>'
                 '<path d="M17 20h14M17 25h14M17 30h10M17 35h12"/>'),
    "voice2text": _G % ('<rect x="18" y="6" width="12" height="22" rx="6"/>'
                        '<path d="M11 22a13 13 0 0 0 26 0M24 35v7M17 42h14"/>'),
    "whiteboard": _G % ('<rect x="5" y="7" width="38" height="28" rx="1.5"/>'
                        '<path d="M16 35l-4 8M32 35l4 8"/>'
                        '<rect x="10" y="13" width="10" height="7"/>'
                        '<rect x="28" y="22" width="10" height="7"/>'
                        '<path d="M20 16.5h4.5v9H28"/>'),
    "cameraroll": _G % ('<rect x="5" y="9" width="38" height="30" rx="2"/>'
                        '<circle cx="16" cy="19" r="3.5"/>'
                        '<path d="M5 34l12-11 9 8 6-5 11 9"/>'),
    "cogbot": _G % ('<path d="M24 5l17 10v18L24 43 7 33V15z"/>'
                     '<path d="M24 5v38M7 15l17 10 17-10"/>'
                     '<circle cx="24" cy="25" r="4"/>'),
    "shop": _G % ('<circle cx="15" cy="24" r="8"/><circle cx="15" cy="24" r="2.5"/>'
                  '<path d="M23 24h20M37 24v6M42 24v5"/>'),
}


# --------------------------------------------------------------------------
# Page CSS: only what this page adds. The panel's tokens and top bar come from
# PANEL_CSS, which is emitted first.
# --------------------------------------------------------------------------
ABOUT_CSS = r"""
html,body{height:auto}
body.about{overflow:auto;background:var(--bg)}
.about #topbar{position:sticky;top:0;z-index:20;margin:0}
/* The top bar's controls belong to the panel's runtime, which this page does
   not load: the brand, "about", "agent view" and the theme button stay. */
.about #topbar .tb-group{display:none}
.about #topbar .agent-link[aria-current]{color:var(--ink)}
.ab{max-width:1100px;margin:0 auto;padding:56px 32px 40px;font-size:15.5px;line-height:1.6}
.ab section{padding:44px 0;border-top:1px solid var(--line)}
.ab section:first-child{border-top:0;padding-top:8px}
.ab h2{font-family:var(--serif);font-weight:700;font-size:26px;line-height:1.2;margin:0 0 18px}
.ab h3{font-size:15.5px;font-weight:650;margin:0 0 6px}
.ab p{max-width:68ch}
.ab p + p{margin-top:12px}
.ab a{color:var(--ink);text-underline-offset:3px}
.ab-hero{display:flex;align-items:center;gap:28px;margin-bottom:28px}
.ab-hero img{width:92px;height:auto;flex:none}
.ab-hero .wm{font-family:var(--serif);font-weight:700;font-size:56px;line-height:1;letter-spacing:-.01em}
.ab-hero .strap{font-family:var(--serif);font-size:20px;color:var(--ink-2);margin-top:6px}
.ab .lede{font-size:18px}
.ab .muted{color:var(--ink-2)}
.ab-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:16px}
.ab-card{display:flex;flex-direction:column;gap:10px;padding:20px;background:var(--panel);
  border:1px solid var(--line);border-radius:10px}
.ab-card .glyph{color:var(--teal);display:block}
.ab-card p{font-size:14px;color:var(--ink-2);flex:1 1 auto}
.ab-card a.go{font-size:13.5px;font-weight:600;text-decoration:none;color:var(--ink)}
.ab-card a.go:hover{text-decoration:underline}
.ab-work{display:grid;grid-template-columns:1fr 1fr;gap:32px}
.ab-contact{margin-top:28px;padding:20px 22px;background:var(--panel);border:1px solid var(--line);
  border-radius:10px;display:flex;flex-wrap:wrap;align-items:center;gap:10px 24px}
.ab-contact .who{font-weight:600}
.ab-contact a.btn{text-decoration:none;display:inline-flex;align-items:center;height:32px;padding:0 14px;
  border-radius:var(--radius);background:var(--accent);color:var(--accent-ink);font-weight:600;font-size:13.5px}
.ab-people{display:grid;grid-template-columns:1fr 1fr;gap:24px}
.ab-people figure{margin:0}
.ab-people img,.ab-people .frame{display:block;width:100%;aspect-ratio:4/5;object-fit:cover;border-radius:10px;
  background:var(--panel-2)}
.ab-people .frame{display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;
  border:1.5px dashed var(--line-2);color:var(--ink-2);font-family:var(--mono);font-size:13px}
.ab-people figcaption{margin-top:12px;font-size:14px;color:var(--ink-2)}
.ab-people figcaption strong{display:block;font-size:20px;color:var(--ink)}
.ab-people figcaption em{display:block;margin:2px 0 8px;font-size:15px}
.ab-people figcaption p{line-height:1.5;margin:0 0 10px}
.ab-tags{display:flex;flex-wrap:wrap;gap:6px}
.ab-tags .pill{font-size:11.5px}
.ab-foot{border-top:1px solid var(--line);padding-top:24px;font-size:13.5px;color:var(--ink-2);
  display:flex;flex-wrap:wrap;gap:8px 20px}
.ab-foot a{color:var(--ink-2)}
@media (max-width:760px){
  .ab{padding:32px 16px}
  .ab-work,.ab-people{grid-template-columns:1fr}
  .ab-hero .wm{font-size:42px}
}
"""

# Theme only: the panel's runtime is written against the panel's DOM, so this
# page carries the one piece of it that applies -- the same localStorage key,
# so a choice made on either page holds on both.
ABOUT_JS = r"""
(function () {
  "use strict";
  var root = document.documentElement, btn = document.getElementById("theme-btn");
  try { var t = localStorage.getItem("faxl.theme"); if (t === "dark" || t === "light") root.setAttribute("data-theme", t); } catch (e) {}
  if (!btn) return;
  function isDark() {
    var t = root.getAttribute("data-theme");
    if (t) return t === "dark";
    return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  }
  function label() {
    var d = isDark();
    btn.setAttribute("aria-label", d ? "switch to light mode" : "switch to dark mode");
    btn.title = d ? "light mode" : "dark mode";
  }
  btn.addEventListener("click", function () {
    var next = isDark() ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("faxl.theme", next); } catch (e) {}
    label();
  });
  label();
})();
"""


def _e(s):
    return _html.escape(str(s), quote=True)


def _link(href):
    """External links open in a new tab; console links stay in this one."""
    if href.startswith("http"):
        return ' href="%s" target="_blank" rel="noopener"' % _e(href)
    return ' href="%s"' % _e(href)


def _topbar(logo):
    bar = TOPBAR_HTML.replace("@@LOGO@@", logo)
    # On this page "agent view" means this page's agent view, and "about" is
    # where you are.
    bar = bar.replace('href="/console?mode=agent"',
                      'href="/console/about?mode=agent"')
    return bar.replace('href="/console/about">',
                       'href="/console/about" aria-current="page">')


def _photos_html(photos):
    out = []
    for slot, p in zip(PHOTOS, photos):
        if p.get("present"):
            v = p.get("v")
            src = "/console/about/photo/%d.jpg" % slot["n"]
            if v is not None:
                src += "?v=%s" % _e(v)
            pic = '<img src="%s" alt="%s" loading="lazy">' % (
                src, _e(slot["caption"]))
        else:
            pic = ('<div class="frame">drop %s into ~/.faxl/about/</div>'
                   % _e(slot["file"]))
        tags = "".join('<span class="pill">%s</span>' % _e(t)
                       for t in slot.get("tags", []))
        out.append('<figure>%s<figcaption><strong>%s</strong>'
                   '<em>%s</em><p>%s</p><div class="ab-tags">%s</div>'
                   '</figcaption></figure>'
                   % (pic, _e(slot["caption"]), _e(slot.get("role", "")),
                      _e(slot.get("bio", "")), tags))
    return "".join(out)


def render_about(state=None, nonce=None):
    """The whole about page, as one string. `state` may carry
    {"photos": [{"present": bool, "v": mtime}, ...]}; anything missing renders
    as a placeholder. `nonce`, when given, is set on every <style>/<script>."""
    state = state if isinstance(state, dict) else {}
    photos = state.get("photos")
    if not isinstance(photos, list):
        photos = []
    photos = [p if isinstance(p, dict) else {} for p in photos]
    photos += [{}] * (len(PHOTOS) - len(photos))
    na = (' nonce="%s"' % _e(nonce)) if nonce else ""
    logo = ('<img src="%s" alt="" width="22" height="24">' % _e(LOGO_SVG_URI)
            if LOGO_SVG_URI else "")
    icon = ('<link rel="icon" type="image/png" href="%s">' % _e(ICON_32_URI)
            if ICON_32_URI else "")
    hero_logo = ('<img src="%s" alt="" width="92" height="99">' % _e(LOGO_SVG_URI)
                 if LOGO_SVG_URI else "")

    cards = "".join(
        '<article class="ab-card" data-product="%s">%s<h3>%s</h3><p>%s</p>'
        '<a class="go"%s>%s →</a></article>'
        % (_e(k), GLYPHS[k], _e(n), _e(line), _link(h), _e(lab))
        for k, n, line, h, lab in PRODUCTS)
    work = "".join('<div><h3>%s</h3><p>%s</p></div>' % (_e(t), _e(x))
                   for t, x in WORK)
    c = CONTACT
    contact = ('<div class="ab-contact"><span class="who">%s, %s</span>'
               '<a href="mailto:%s">%s</a>'
               '<a class="btn"%s>book a meeting</a></div>'
               % (_e(c["name"]), _e(COMPANY["name"]), _e(c["email"]),
                  _e(c["email"]), _link(c["meeting"])))

    body = (
        '<main class="ab">'
        '<section id="who" aria-labelledby="h-who">'
        '<div class="ab-hero">%s<div><div class="wm">faxl</div>'
        '<div class="strap">%s</div></div></div>'
        '<h2 id="h-who">Who we are</h2>'
        '<p class="lede">%s</p><p class="muted">%s</p></section>'
        '<section id="products" aria-labelledby="h-products">'
        '<h2 id="h-products">Products</h2><div class="ab-grid">%s</div></section>'
        '<section id="work" aria-labelledby="h-work">'
        '<h2 id="h-work">Work with us</h2><div class="ab-work">%s</div>%s</section>'
        '<section id="people" aria-labelledby="h-people">'
        '<h2 id="h-people">The people</h2><div class="ab-people">%s</div></section>'
        '<footer class="ab-foot"><span>%s</span>'
        '<a%s>faxl.ai</a><a%s>gamakon.ai</a>'
        '<a href="/console/about?mode=agent">agent view</a></footer>'
        '</main>'
        % (hero_logo, _e(COMPANY["strapline"]), _e(COMPANY["about"]),
           _e(COMPANY["measured"]), cards, work, contact,
           _photos_html(photos), _e(FOOTER), _link("https://faxl.ai"),
           _link(COMPANY["site"])))

    return "".join([
        '<!doctype html><html lang="en-GB"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        '<meta name="robots" content="noindex, nofollow">',
        '<meta name="color-scheme" content="light dark">',
        '<title>faxl — about</title>', icon,
        '<link rel="alternate" type="application/json" '
        'href="/console/about?format=json">',
        '<style', na, '>', _font_css(), PANEL_CSS, ABOUT_CSS, '</style>',
        '</head><body class="about">',
        _topbar(logo), body,
        '<script', na, '>', ABOUT_JS, '</script>',
        '</body></html>'])


def render_about_agent(photos=None):
    """The same content as plain HTML for an agent: no styling, no script,
    every link written out. Returns the inner body; the console wraps it."""
    p = about_payload(photos)
    li = "".join('<li><a href="%s">%s</a> — %s</li>'
                 % (_e(x["href"]), _e(x["name"]), _e(x["line"]))
                 for x in p["products"])
    work = "".join('<h2>%s</h2><p>%s</p>' % (_e(w["title"]), _e(w["text"]))
                   for w in p["work"])
    ph = "".join('<li>%s: %s</li>' % (
        _e(x["caption"]),
        ('<a href="%s">%s</a>' % (_e(x["src"]), _e(x["src"]))) if x["present"]
        else "absent \u2014 drop %s into ~/.faxl/about/"
        % _e(x["file"].rsplit("/", 1)[-1])) for x in p["photos"])
    c = p["contact"]
    return ('<p>%s, %s. <em>%s</em></p><p>%s</p><p>%s</p>'
            '<h2>products</h2><ul>%s</ul>%s'
            '<h2>contact</h2><p>%s — <a href="mailto:%s">%s</a> · '
            '<a href="%s">book a meeting</a></p>'
            '<h2>photos</h2><ul>%s</ul>'
            '<p>%s <a href="https://faxl.ai">faxl.ai</a> · '
            '<a href="%s">gamakon.ai</a> · '
            '<a href="/console/about?format=json">json</a></p>'
            % (_e(COMPANY["name"]), _e(COMPANY["place"]),
               _e(COMPANY["strapline"]), _e(COMPANY["about"]),
               _e(COMPANY["measured"]), li, work, _e(c["name"]),
               _e(c["email"]), _e(c["email"]), _e(c["meeting"]), ph,
               _e(FOOTER), _e(COMPANY["site"])))

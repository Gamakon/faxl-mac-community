#!/usr/bin/env python3
"""Convert Photos originals to OCR-ready JPEGs, in parallel.

Reads originals READ-ONLY and writes derivatives to a scratch dir.
The original files are never modified, moved, or copied elsewhere.

The EXIF rotation step is NOT optional: `sips -Z` writes pixels without
applying the orientation flag, so a portrait photo lands on disk as
landscape. ocrs then reads the page sideways and returns pure noise
(observed: a legible A4 page yielding "19 / M / B A / CRDNL WARE").
"""
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

from PIL import Image, ImageOps

MAX_PX = 2400  # measured sweet spot: >2400 is slower AND less accurate


def convert(lib, work, row):
    idx, rel, orig = row[0], row[1], row[2]   # row[3] is the UUID
    src = os.path.join(lib, "originals", rel)
    dst = os.path.join(work, f"p{idx}.jpg")
    # sips derives the output type from the extension, so the scratch file
    # must end in .jpg — "p1.jpg.raw.jpg" trips it up on PNG input.
    tmp = os.path.join(work, f"raw{idx}.jpg")
    # With iCloud "Optimise Mac Storage" the database lists assets whose
    # originals are not on disk. That is not an error, and we must not
    # trigger a download — skip and report, so the count stays honest.
    if not os.path.exists(src):
        print(f"[scan] not downloaded (iCloud-only), skipped: {orig}",
              file=sys.stderr)
        return False
    try:
        # PNG/JPEG already decode natively; only HEIC needs sips at all.
        if os.path.splitext(src)[1].lower() in (".png", ".jpg", ".jpeg", ".gif"):
            tmp = src
        else:
            subprocess.run(
                ["sips", "-s", "format", "jpeg", src, "--out", tmp],
                capture_output=True, check=True,
            )
        im = ImageOps.exif_transpose(Image.open(tmp))
        im.thumbnail((MAX_PX, MAX_PX), Image.LANCZOS)
        im.save(dst, quality=92)
        if tmp != src:  # never delete a Photos original
            os.remove(tmp)
        return True
    except Exception as exc:
        print(f"[scan] convert failed {orig}: {exc}", file=sys.stderr)
        return False


def main():
    lib, work, jobs = sys.argv[1], sys.argv[2], int(sys.argv[3])
    with open(os.path.join(work, "idx.tsv")) as fh:
        rows = [line.rstrip("\n").split("\t") for line in fh if line.strip()]
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        ok = sum(pool.map(lambda r: convert(lib, work, r), rows))
    print(f"[scan] converted {ok}/{len(rows)}", file=sys.stderr)


if __name__ == "__main__":
    main()

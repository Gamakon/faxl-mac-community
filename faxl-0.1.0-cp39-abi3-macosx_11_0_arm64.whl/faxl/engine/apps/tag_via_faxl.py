#!/usr/bin/env python3
"""Tag photos with a vision model through the faxl proxy, and measure the cache.

Replaces the ocrs.wasm step: instead of a local OCR engine reading text, the
image itself goes to a vision model behind faxl, which reads text AND describes
the scene (ocrs cannot do the latter -- see README "ocrs reads text, not
scenes").

WHAT MAKES THE CACHE VISIBLE, and why this script is shaped as it is.

A prefix cache only pays when requests SHARE a prefix. So every request here
sends the SAME instruction preamble, and the photo comes last:

    [ long, fixed instruction block ]  <- identical on every request
    [ the image                     ]  <- differs
    [ the question                  ]  <- identical

Request 1 is cold and pays for the whole preamble. Requests 2..N should resume
from a checkpoint laid down at the preamble's grid boundary and prefill only
the image and question. That is exactly the shape a real agent produces, and
the per-request `served` figure reports how much was reused.

AN IMAGE IS AN ATOM. The proxy hashes a whole image as one <image:digest>
token, never its bytes, so a boundary can fall before or after an image but
never inside it -- the same rule the recurrent half of a hybrid model obeys.
Two runs over the same photo therefore hash alike and can hit; a different
photo cannot collide.

Reads the JPEGs normalise.py already produced. Originals are never touched.
"""
import argparse
import base64
import json
import os
import signal
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# The fixed preamble. Long ON PURPOSE: it has to clear faxl's 1024-token gate
# for the ladder to engage at all, and a real agent's system prompt plus tool
# definitions are this size anyway.
PREAMBLE = (
    "You are a photo cataloguer. For each image you are shown, report:\n"
    "1. TEXT: every word legible in the image, verbatim. If none, write NONE.\n"
    "2. SCENE: what the photograph shows, in one short sentence.\n"
    "3. TAGS: three to six lowercase keywords, comma separated.\n\n"
    "Rules you must follow exactly:\n"
    "- Report only what is visible. Never guess at text you cannot read.\n"
    "- Do not describe the image quality, resolution, or file format.\n"
    "- Do not speculate about when or where the photo was taken unless a\n"
    "  date or place name is legible in the image itself.\n"
    "- Keep the whole reply under 80 words.\n"
    "- Use the three headings above, in that order, nothing else.\n\n"
    "Reference notes for consistency across a catalogue:\n"
    + ("A document photographed at an angle is still a document; tag it by "
       "what it says, not by the angle. A screenshot is a screenshot even if "
       "it contains a photograph. A receipt, invoice or business card should "
       "have its numbers reported character by character, because a digit "
       "misread is worse than a digit omitted. Handwriting should be marked "
       "as handwriting so it can be reviewed by a person later. ") * 20
)

QUESTION = "Catalogue this photograph using the three headings."


def preview_dir():
    """Where the console reads photographs from, after the batch is gone.

    Separate from the cache and from the staging directory: this is a small,
    bounded, human-facing store whose only job is letting the page show what
    it just worked on.
    """
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    d = os.path.join(base, "previews")
    os.makedirs(d, mode=0o700, exist_ok=True)
    return d


# BOUNDED, NOT PERMANENT (AM). Previews survive completed jobs so a finished
# photograph stays inspectable, but a store that only grows is a disk leak
# wearing a feature's clothes.
PREVIEW_MAX_AGE_DAYS = float(os.environ.get("FAXL_PREVIEW_MAX_AGE_DAYS", "30"))
PREVIEW_MAX_MB = float(os.environ.get("FAXL_PREVIEW_MAX_MB", "500"))
# ONE SIZE, NOT THREE. 800px on the longest edge is sharp for the large
# "current photo" panel on a Retina display and ~60 KB as a quality-82 JPEG;
# the filmstrip and pipeline stacks are the SAME file scaled by the browser.
# Keeping several physical sizes would triple the writes and the bookkeeping
# to save bytes that do not matter at this scale.
PREVIEW_PX = int(os.environ.get("FAXL_PREVIEW_PX", "800"))


def _keep_preview(src, uuid):
    """A durable, downsized copy of one photograph. Returns its name, or "".

    NEVER THE ORIGINAL. `src` is already a derivative -- the upright JPEG the
    fetch step produced -- and the photograph in the library is not touched by
    anything in this package.

    Named by UUID because that is the only identifier that is unique: a
    library holds thousands of duplicate IMG_ names (4,824 here) and naming a
    file by one would have two photographs overwrite each other.
    """
    if not uuid:
        return ""
    try:
        from PIL import Image
        out = os.path.join(preview_dir(), f"{uuid}.jpg")
        if not os.path.exists(out):
            im = Image.open(src)
            im.thumbnail((PREVIEW_PX, PREVIEW_PX), Image.LANCZOS)
            im.convert("RGB").save(out, quality=82, optimize=True)
        return os.path.basename(out)
    except Exception as exc:                              # noqa: BLE001
        # A preview is a nicety: never fail a tagging run for one.
        print(f"[tag] could not keep a preview for {uuid[:8]}: {exc}",
              file=sys.stderr, flush=True)
        return ""


def sweep_previews():
    """Keep the preview store under its age and size caps, oldest first.

    Runs once at the end of a job rather than per photograph: it is a stat of
    every file in one directory, and doing that 5,000 times would cost more
    than the space it reclaims.
    """
    try:
        d = preview_dir()
        now = time.time()
        files = []
        for n in os.listdir(d):
            p = os.path.join(d, n)
            try:
                st = os.stat(p)
            except OSError:
                continue
            files.append([p, st.st_mtime, st.st_size])
        cutoff = now - PREVIEW_MAX_AGE_DAYS * 86400
        keep = []
        freed = 0
        for f in files:
            if f[1] < cutoff:
                try:
                    os.remove(f[0])
                    freed += f[2]
                except OSError:
                    pass
            else:
                keep.append(f)
        keep.sort(key=lambda f: f[1])          # oldest first
        total = sum(f[2] for f in keep)
        cap = PREVIEW_MAX_MB * 1e6
        while keep and total > cap:
            p, _m, sz = keep.pop(0)
            try:
                os.remove(p)
                total -= sz
                freed += sz
            except OSError:
                break
        if freed:
            print(f"[tag] previews: reclaimed {freed / 1e6:.0f} MB",
                  file=sys.stderr, flush=True)
    except Exception:                                     # noqa: BLE001
        pass


def current_path():
    """The file the console reads to learn which photograph is in flight."""
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "jobs", "cameraroll", "current.json")


def _mark_current(info):
    """Publish "this is the photograph being analysed right now".

    tmp + os.replace, like the job's status file: the console polls this
    twice a second and must never read half a document.
    """
    try:
        p = current_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(info, fh)
        os.replace(tmp, p)
    except OSError:
        pass          # a progress hint is never worth failing a run for


def encode(path):
    with open(path, "rb") as fh:
        return base64.b64encode(fh.read()).decode()


def ask(endpoint, model, project, b64, timeout):
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": PREAMBLE},
            # THE QUESTION THEN THE PICTURE -- the order the working run used
            # to catalogue several hundred photographs from the real library.
            # Do not reorder this: the preamble is what checkpoints, and at
            # x20 the grid boundary lands at 1536 of 1763 tokens, well inside
            # the shared text, so every photograph resumes from it.
            {"role": "user", "content": [
                {"type": "text", "text": QUESTION},
                {"type": "image_url",
                 "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
            ]},
        ],
        "max_tokens": 140,
        "temperature": 0,
    }
    req = urllib.request.Request(
        f"{endpoint}/v1/chat/completions",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json",
                 "X-Faxl-Project": project},
        method="POST")
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    if not raw.strip():
        raise RuntimeError("empty body from the proxy — check the exo log")
    return json.loads(raw.decode()), time.time() - t0


def metrics(endpoint):
    try:
        with urllib.request.urlopen(f"{endpoint}/metrics", timeout=10) as r:
            return json.loads(r.read().decode())
    except Exception:                                    # noqa: BLE001
        return {}


def last_request(endpoint, txn=None):
    """What the proxy recorded for the request just made.

    /metrics counts ONLY what the exo prefill server reports, so on the mlx
    path every counter there stays at zero and this script printed served=0
    through a run that was in fact hitting the cache on every request
    (measured: prefill_skipped=1774 of prompt_tokens=1803, four for four).
    Reporting a working cache as broken is worse than not reporting it, so
    read the request feed, which both backends write to.
    """
    try:
        with urllib.request.urlopen(
                f"{endpoint}/api/requests?limit=8", timeout=10) as r:
            rows = json.loads(r.read().decode()).get("requests") or []
    except Exception:                                    # noqa: BLE001
        return {}
    if txn:
        for row in rows:
            if row.get("transaction_id") == txn:
                return row
    return rows[0] if rows else {}


# Set by SIGTERM so the per-photograph loop can stop promptly. A dict rather
# than a global so the handler can write it without a `global` declaration.
_stopping = {"now": False}


def _note_stop(signum, frame):                           # noqa: ARG001
    _stopping["now"] = True
    print("[tag] stop requested — finishing this photograph",
          file=sys.stderr, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("work", help="dir of pN.jpg files from normalise.py")
    ap.add_argument("out", help="JSONL to write")
    ap.add_argument("--endpoint", default=os.environ.get(
        "FAXL_ENDPOINT", "http://faxl.localhost:8767"))
    ap.add_argument("--model", default=os.environ.get(
        "FAXL_VISION_MODEL", "Qwen3-VL-4B-Instruct-4bit"))
    ap.add_argument("--project", default=os.environ.get(
        "FAXL_PROJECT", "photo-tagger"))
    ap.add_argument("--jobs", type=int, default=1,
                    help="concurrent requests (default 1: SEQUENTIAL, so the "
                         "cache effect is measurable rather than raced)")
    ap.add_argument("--timeout", type=float, default=1800.0)
    ap.add_argument("--write-photos", action="store_true",
                    help="write the caption and keywords into the Photos "
                         "library AS EACH PHOTO COMPLETES, not at the end")
    args = ap.parse_args()

    if not metrics(args.endpoint):
        print(f"FATAL: no faxl proxy at {args.endpoint}", file=sys.stderr)
        return 1

    # name AND uuid: the uuid is what addresses the photo, the name is only
    # for a human reading the output.
    idx, uuids = {}, {}
    tsv = os.path.join(args.work, "idx.tsv")
    if os.path.exists(tsv):
        for line in open(tsv):
            parts = line.rstrip("\n").split("\t")
            if len(parts) >= 3:
                idx[f"p{parts[0]}.jpg"] = parts[2]
            if len(parts) >= 4:
                uuids[f"p{parts[0]}.jpg"] = parts[3]

    jpgs = sorted(
        (f for f in os.listdir(args.work) if f.startswith("p") and f.endswith(".jpg")),
        key=lambda f: int(f[1:-4]) if f[1:-4].isdigit() else 0)
    if not jpgs:
        print(f"no pN.jpg in {args.work} — run normalise.py first", file=sys.stderr)
        return 1

    print(f"[tag] {len(jpgs)} photo(s) -> {args.model} via {args.endpoint} "
          f"(project={args.project}, {args.jobs}-way)", file=sys.stderr)
    print(f"[tag] writing to {args.out} as each photo completes", file=sys.stderr)

    # APPEND AND FLUSH PER PHOTO. Never collect rows and write at the end: a
    # run stopped, crashed or interrupted then loses everything it had already
    # done. Measured the hard way -- 77 completed photos, ten minutes of
    # compute, thrown away because the file was written after the loop. The
    # partial file is always valid and always current, so a run can be read
    # while it is still going and stopped at any point without loss.
    # cameraroll signals this process too: it is the one holding the model
    # call, so it is the one that has to notice.
    signal.signal(signal.SIGTERM, _note_stop)
    signal.signal(signal.SIGINT, _note_stop)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out_fh = open(args.out, "a", buffering=1)          # line buffered
    rows, t_start = [], time.time()

    def record(row):
        # WHEN, on every row. The console counts rows newer than the job's
        # own start to show live progress per PHOTOGRAPH rather than per
        # batch, and a durable record of a long run is worth a timestamp in
        # its own right.
        row.setdefault("ts", time.time())
        # ONE TRANSACTION PER PHOTO: do the library write FIRST, then record
        # what happened. Writing the JSONL first left photos_write always null
        # on disk -- the row had already been serialised -- so the durable
        # record disagreed with the library and could not be used to tell what
        # had actually landed or to resume a part-finished run.
        if args.write_photos and "error" not in row:
            try:
                from write_to_photos import caption_for, parse_catalogue, write_one
                parsed = parse_catalogue(row.get("catalogue", ""))
                cap = caption_for(parsed)
                if cap or parsed["tags"]:
                    st = write_one(row.get("uuid") or row["photo"],
                                   cap, parsed["tags"], True)
                    row["photos_write"] = st
                    print(f"      -> Photos: {st}", file=sys.stderr, flush=True)
            except Exception as e:                        # noqa: BLE001
                # Never fail a tagging run because the library write failed;
                # the JSONL above is already safe and can be replayed.
                row["photos_write"] = f"FAILED: {type(e).__name__}: {e}"
                print(f"      -> Photos FAILED: {e}", file=sys.stderr, flush=True)
        # Now the durable record, including what the library write did.
        out_fh.write(json.dumps(row) + "\n")
        out_fh.flush()
        os.fsync(out_fh.fileno())
        return row

    def one(n_and_name):
        n, name = n_and_name
        path = os.path.join(args.work, name)
        # THE PICTURE HAS TO OUTLIVE THE BATCH. cameraroll deletes its staging
        # directory when a batch finishes, so without this the console has
        # nothing to show the moment a photograph is done -- and the whole
        # point of the page is watching photographs move.
        preview = _keep_preview(path, uuids.get(name, ""))
        # SAY WHAT IS BEING WORKED ON, BEFORE THE WORK. The catalogue row is
        # only written when the model answers ~17s later, so without this the
        # page can infer "photo N finished" but never "photo N+1 started" --
        # no QUEUED -> ANALYSING transition, and no way to show the actual
        # photograph currently in front of the model.
        _mark_current({"photo": idx.get(name, name), "file": name,
                       "uuid": uuids.get(name, ""), "preview": preview,
                       "index": n, "of": len(jpgs),
                       "started_at": time.time()})
        try:
            reply, dt = ask(args.endpoint, args.model, args.project,
                            encode(path), args.timeout)
        except urllib.error.HTTPError as e:
            return record({"photo": idx.get(name, name), "error":
                           f"HTTP {e.code}: {e.read().decode()[:200]}"})
        except Exception as e:                            # noqa: BLE001
            return record({"photo": idx.get(name, name),
                           "error": f"{type(e).__name__}: {e}"})

        # content can be None -- a reply that was all markup, or an empty
        # generation. Record it as an error rather than crashing the run:
        # the JSONL is the durable record and a run that dies on photo 400
        # of 5,000 loses the schedule, not just the photograph.
        text = reply["choices"][0]["message"].get("content")
        if not text:
            return record({"photo": idx.get(name, name),
                           "uuid": uuids.get(name, ""), "file": name,
                           "error": "the model returned an empty reply"})
        row = last_request(args.endpoint, reply.get("id"))
        served = int(row.get("prefill_skipped", 0))
        outcome = row.get("outcome", "?")
        prompt_toks = int(reply.get("usage", {}).get("prompt_tokens", 0)) \
            or int(row.get("prompt_tokens", 0))
        ttft = row.get("ttft_ms")
        print(f"  {n}/{len(jpgs)} {name}  {dt:5.1f}s  prompt={prompt_toks:5d} "
              f"served={served:5d} {outcome}"
              + (f"  ttft={ttft:.0f}ms" if ttft else ""),
              file=sys.stderr, flush=True)
        return record({"photo": idx.get(name, name),
                       "uuid": uuids.get(name, ""), "file": name,
                       "preview": preview,
                       "catalogue": text.split("<|")[0].strip(),
                       "secs": round(dt, 2), "prompt_tokens": prompt_toks,
                       "served": served, "outcome": outcome,
                       "ttft_ms": round(ttft, 1) if ttft else None})

    work = list(enumerate(jpgs, 1))
    if args.jobs > 1:
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            rows = list(pool.map(one, work))
    else:
        # STOPPABLE BETWEEN PHOTOGRAPHS, not only between batches. SIGTERM
        # sets a flag and the loop checks it before starting the next one:
        # the JSONL is appended and fsynced per photograph, so stopping here
        # loses nothing, and waiting for a 20-photograph batch to finish is
        # up to five minutes of a person watching a Stop button do nothing.
        #
        # A photograph already in flight still finishes -- abandoning a model
        # call mid-generation would leave the proxy holding a request nobody
        # is going to read.
        rows = []
        for w in work:
            if _stopping["now"]:
                print(f"[tag] stopped after {len(rows)} photograph(s)",
                      file=sys.stderr, flush=True)
                break
            rows.append(one(w))

    out_fh.close()
    sweep_previews()

    ok = [r for r in rows if "error" not in r]
    elapsed = time.time() - t_start
    print(f"\n[tag] {len(ok)}/{len(rows)} catalogued in {elapsed:.0f}s",
          file=sys.stderr)
    if ok:
        first = ok[0]["secs"]
        rest = [r["secs"] for r in ok[1:]]
        print(f"[tag] first {first:.1f}s"
              + (f", then {sum(rest)/len(rest):.1f}s mean "
                 f"({first/max(sum(rest)/len(rest), 1e-9):.1f}x)" if rest else ""),
              file=sys.stderr)
        # THIS RUN's own rows, not a global counter: what the cache did for
        # the photos in front of us is the only figure worth quoting, and it
        # cannot drift with whatever else is talking to the proxy.
        hits = [r for r in ok if r.get("outcome") == "HIT"]
        served = sum(r.get("served") or 0 for r in ok)
        paid = sum(max((r.get("prompt_tokens") or 0)
                       - (r.get("served") or 0), 0) for r in ok)
        total = served + paid
        print(f"[tag] cache: {len(hits)}/{len(ok)} hits, "
              f"{served:,} tokens served from cache vs {paid:,} prefilled"
              + (f" ({served/total*100:.1f}% reused)" if total else ""),
              file=sys.stderr)
        ttfts = [r["ttft_ms"] for r in ok if r.get("ttft_ms")]
        if ttfts:
            print(f"[tag] first reply: {min(ttfts):.0f}ms best, "
                  f"{sum(ttfts)/len(ttfts):.0f}ms mean", file=sys.stderr)
    print(args.out)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

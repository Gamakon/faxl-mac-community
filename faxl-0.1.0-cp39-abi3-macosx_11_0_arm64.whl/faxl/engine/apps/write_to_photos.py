#!/usr/bin/env python3
"""Write a catalogue run back into the Photos library, so the tags are visible.

Reads the JSONL a tagging run produced and, for each photo, sets the fields
Photos shows in its Info panel (⌘I):

    SCENE -> description   (the "Caption" field)
    TAGS  -> keywords      (the "Keywords" field)
    TEXT  -> appended to the caption when the image contained legible text

LIBRARY METADATA ONLY. This uses Photos' own AppleScript API, the same path a
person editing the caption by hand takes, so:
  * the ORIGINAL FILE IS NEVER TOUCHED — not modified, moved, or re-encoded
  * the change syncs like any manual edit
  * it is undoable in Photos

DRY RUN BY DEFAULT. Writing to a photo library is not something to do to
someone's photos as a side effect of a benchmark, so it prints what it would
do and changes nothing until --apply is passed.

IDEMPOTENT. A keyword already present is not added twice, and re-running over
the same JSONL leaves the library in the same state.
"""
import argparse
import json
import re
import subprocess
import sys

# A caption Photos will show on one or two lines. Longer than this is a wall
# of text in a small panel, and the full record stays in the JSONL anyway.
MAX_CAPTION = 300


def parse_catalogue(text):
    """Pull SCENE / TAGS / TEXT out of the model's reply.

    The model was asked for three headings and mostly obeys, but a small
    quantised model drifts -- so this tolerates missing or reordered sections
    and returns whatever it could find rather than failing the photo.
    """
    out = {"scene": "", "tags": [], "text": ""}
    if not text:
        return out
    for key, pat in (("text", r"TEXT\s*:\s*(.*?)(?=\n\s*(?:SCENE|TAGS)\s*:|\Z)"),
                     ("scene", r"SCENE\s*:\s*(.*?)(?=\n\s*(?:TEXT|TAGS)\s*:|\Z)"),
                     ("tags", r"TAGS\s*:\s*(.*?)(?=\n\s*(?:TEXT|SCENE)\s*:|\Z)")):
        m = re.search(pat, text, re.S | re.I)
        if not m:
            continue
        val = " ".join(m.group(1).split())
        if key == "tags":
            out["tags"] = [t.strip().lower() for t in val.split(",")
                           if t.strip() and len(t.strip()) <= 40][:8]
        elif key == "text" and val.upper() not in ("NONE", "NONE.", ""):
            out["text"] = val
        elif key == "scene":
            out["scene"] = val
    return out


def caption_for(parsed):
    cap = parsed["scene"]
    if parsed["text"]:
        cap = (cap + f' Text in image: "{parsed["text"]}"').strip()
    return cap[:MAX_CAPTION]


def applescript_str(s):
    """Quote for AppleScript: it has no escape for a literal quote inside a
    string other than backslash, and a stray one is a syntax error that would
    silently skip the photo."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


# A Photos UUID: 8-4-4-4-12 hex, optionally with Apple's /L0/001 suffix.
_UUID_RE = re.compile(r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-"
                      r"[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}")


def write_one(ident, caption, keywords, apply):
    """Write a caption and keywords to ONE photo, addressed by its UUID.

    NEVER BY FILENAME. iPhone recycles IMG_XXXX after a reset, so a library
    holds many photos with the same name -- measured: 4,824 duplicate names
    here, some appearing eight times -- and `first media item whose filename
    is ...` picks an arbitrary one. Writing by name put 11 captions onto
    unrelated photos from two years earlier, and reading them back by the same
    name reported success.

    An identifier that is not a UUID is refused rather than guessed at.
    """
    if not apply:
        return "dry-run"
    if not _UUID_RE.match(str(ident)):
        return (f"REFUSED: {ident!r} is not a photo UUID. Addressing by "
                f"filename writes to the wrong photo.")
    kw_list = "{" + ", ".join(f'"{applescript_str(k)}"' for k in keywords) + "}"
    script = f'''
    tell application "Photos"
      set target to (first media item whose id starts with "{applescript_str(str(ident))}")
      set description of target to "{applescript_str(caption)}"
      set existing to (get keywords of target)
      if existing is missing value then set existing to {{}}
      set toAdd to {{}}
      repeat with k in {kw_list}
        if existing does not contain (k as text) then set toAdd to toAdd & {{k as text}}
      end repeat
      if (count of toAdd) > 0 then set keywords of target to existing & toAdd
      return "ok"
    end tell
    '''
    r = subprocess.run(["osascript", "-e", script],
                       capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        return f"FAILED: {r.stderr.strip()[:120]}"
    return "written"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl", help="a run from tag_via_faxl.py")
    ap.add_argument("--apply", action="store_true",
                    help="actually write to the Photos library "
                         "(default: dry run, changes nothing)")
    args = ap.parse_args()

    rows = []
    with open(args.jsonl) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    if not args.apply:
        print("DRY RUN — nothing will be written. Add --apply to write.\n")

    done = skipped = failed = 0
    for r in rows:
        fn = r.get("photo")
        if not fn or "error" in r:
            print(f"  skip {fn or '?'}: {str(r.get('error'))[:60]}")
            skipped += 1
            continue
        parsed = parse_catalogue(r.get("catalogue", ""))
        cap = caption_for(parsed)
        if not cap and not parsed["tags"]:
            print(f"  skip {fn}: nothing parsed out of the reply")
            skipped += 1
            continue

        ident = r.get("uuid") or ""
        if not ident:
            print(f"  skip {fn}: no uuid in the record — cannot address it "
                  f"safely (re-run the tagger to capture one)")
            skipped += 1
            continue
        status = write_one(ident, cap, parsed["tags"], args.apply)
        mark = {"written": "✓", "dry-run": "·"}.get(status, "✗")
        print(f"  {mark} {fn}")
        print(f"      caption : {cap[:110]}")
        print(f"      keywords: {', '.join(parsed['tags']) or '(none)'}")
        if status.startswith("FAILED"):
            print(f"      {status}")
            failed += 1
        elif status == "written":
            done += 1

    print(f"\n{done} written, {skipped} skipped, {failed} failed"
          + ("" if args.apply else "  (dry run)"))
    if args.apply and done:
        print("Open Photos and press ⌘I on a photo to see the caption and keywords.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

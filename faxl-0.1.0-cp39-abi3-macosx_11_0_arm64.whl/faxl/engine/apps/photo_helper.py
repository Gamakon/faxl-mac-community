#!/usr/bin/env python3
"""photo_helper.py — every PhotoKit call faxl makes, in one place.

WHY A SEPARATE PROCESS, AND WHY IT MUST BE AN .app.

macOS decides who is asking for your photographs by the RESPONSIBLE PROCESS,
not by the uid. A helper exec'd from a shell inherits whatever that shell was
granted -- so it proves nothing in testing, and on a customer's Mac the prompt
would name "Terminal" or "Python" and grant access to everything that
interpreter ever runs. Worse, a process whose bundle has no
NSPhotoLibraryUsageDescription is TERMINATED by TCC on first access rather
than prompted, which reads as a crash.

So this module is launched from inside a signed .app bundle (see
`faxl-photos.app`, built by tools/build_photo_helper.sh and shipped in the
wheel), via `open -W -a`, which makes LaunchServices give it its own identity.
The prompt then names faxl, and the grant covers faxl alone.

It also has to be a separate process for a second reason: PHPickerViewController
is AppKit. It needs an NSApplication and a window on the MAIN thread, which a
Flask request handler is not and cannot become.

WHAT THIS REPLACES. The old path read Photos.sqlite directly (requiring FULL
DISK ACCESS -- Mail, Messages, backups, everything) and materialised originals
with an AppleScript export. Both are gone:

    permission   Full Disk Access          -> the photos you pick
    enumeration  sqlite3 on Photos.sqlite  -> PHAsset fetch
    fetch        osascript export, 2.6s    -> PHImageManager, 0.5s
    convert      sips + PIL                -> PIL alone (originals are bytes)

MEASURED, on a library where 3,663 of the 4,000 most recent photographs are
iCloud-only: an iCloud original came back as 328 KB of JPEG in 0.50 seconds.
That was the risk worth probing before building any of this -- a demo that can
only read what happens to be on disk is broken for most people.

WRITE-BACK IS NOT HERE. PHAssetChangeRequest appears to expose
setAssetDescription_/setKeywordTitles_, but PHAsset is not key-value coding
compliant for those keys (NSUnknownKeyException on read), so they are private
and unverifiable. Captions are still written by write_to_photos.py through
Photos' own AppleScript API, which is a separate, one-click Automation prompt.

Two modes:

    pick  --out ids.json            show the system picker, record the choice
    fetch --ids ids.json --out DIR  write pN.jpg + idx.tsv for a SLICE
"""
import argparse
import json
import os
import sys
import time

# The identifier PhotoKit hands back is "<uuid>/L0/001". The UUID prefix is
# exactly the ZUUID the tagger records and the AppleScript write addresses by
# `id starts with`, so the two halves of this product agree about which
# photograph is which without any re-keying. Verified against a photo this
# session: A1B87F22-BEEC-4A64-877A-1FF55183DEAE.
def _uuid(local_identifier):
    return str(local_identifier).split("/")[0]


def _load():
    """Import PyObjC here, not at module import.

    The console imports this module to find its path; only the helper process
    -- inside the bundle -- actually talks to PhotoKit. Importing Photos in
    the proxy would load AppKit into a Flask process for nothing.
    """
    import Foundation
    import Photos
    return Foundation, Photos


LEVELS = {0: "notDetermined", 1: "restricted", 2: "denied",
          3: "authorized", 4: "limited"}


def authorise(Photos, Foundation, timeout=120.0):
    """Current access, asking for it if it has never been asked.

    Returns (status_int, name). 4 ("limited") is the good outcome: the user
    picked some photographs and we can see those. 3 ("authorized") means they
    chose to share everything, which is their call.
    """
    lvl = Photos.PHAccessLevelReadWrite
    st = Photos.PHPhotoLibrary.authorizationStatusForAccessLevel_(lvl)
    if st != 0:
        return st, LEVELS.get(st, str(st))
    done = {}
    Photos.PHPhotoLibrary.requestAuthorizationForAccessLevel_handler_(
        lvl, lambda new: done.__setitem__("v", new))
    # A HUMAN IS READING A DIALOG. Spin the run loop rather than block: the
    # callback arrives on the main thread and a plain sleep would deadlock it.
    end = time.time() + timeout
    while "v" not in done and time.time() < end:
        Foundation.NSRunLoop.currentRunLoop().runUntilDate_(
            Foundation.NSDate.dateWithTimeIntervalSinceNow_(0.1))
    st = done.get("v", Photos.PHPhotoLibrary
                  .authorizationStatusForAccessLevel_(lvl))
    return st, LEVELS.get(st, str(st))


def cmd_pick(args):
    """Show the system picker and record what was chosen.

    THE PICKER IS THE PERMISSION. Whatever the user selects here is what faxl
    can read -- there is no separate "allow" step and nothing else in the
    library is reachable. Selecting an album's worth, or pressing Cmd-A, is
    their decision and it is visible to them at the time.
    """
    Foundation, Photos = _load()
    import AppKit
    import PhotosUI

    st, name = authorise(Photos, Foundation)
    if st not in (3, 4):
        json.dump({"ok": False, "status": name,
                   "error": "faxl was not given access to any photographs"},
                  open(args.out, "w"))
        return 1

    app = AppKit.NSApplication.sharedApplication()
    app.setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)

    # initWithPhotoLibrary_ (NOT the plain init) is what makes the picker
    # return real asset identifiers rather than opaque copies -- and those
    # identifiers are what PHImageManager needs to fetch an original.
    cfg = PhotosUI.PHPickerConfiguration.alloc().initWithPhotoLibrary_(
        Photos.PHPhotoLibrary.sharedPhotoLibrary())
    cfg.setSelectionLimit_(0)                  # 0 = as many as they like
    cfg.setFilter_(PhotosUI.PHPickerFilter.imagesFilter())

    picked = {"ids": None}

    class Delegate(AppKit.NSObject):
        def picker_didFinishPicking_(self, picker, results):
            picked["ids"] = [str(r.assetIdentifier()) for r in results
                             if r.assetIdentifier()]
            # The picker owns the window now, so finishing means closing it
            # rather than dismissing a sheet that no longer exists.
            w = picker.view().window()
            if w is not None:
                w.close()
            AppKit.NSApp.stop_(None)

    pk = PhotosUI.PHPickerViewController.alloc().initWithConfiguration_(cfg)
    delegate = Delegate.alloc().init()
    pk.setDelegate_(delegate)

    # THE PICKER IS THE WINDOW, not a sheet floating inside one.
    #
    # Presenting it with presentViewControllerAsSheet_ on a bare
    # NSViewController gave a postage-stamp sheet -- the buttons clipped and
    # the thumbnails unreadable -- centred in a large empty grey window: the
    # host controller has no layout, so the sheet fell back to the picker's
    # own minimum size. Screenshot from AM, and it is unusable.
    #
    # Making PHPickerViewController the window's contentViewController hands
    # the sizing to the picker itself, which knows what it needs.
    # Resizable, and big enough to browse a library on an ordinary display.
    win = AppKit.NSWindow.alloc()\
        .initWithContentRect_styleMask_backing_defer_(
            AppKit.NSMakeRect(0, 0, 1040, 720),
            AppKit.NSWindowStyleMaskTitled
            | AppKit.NSWindowStyleMaskClosable
            | AppKit.NSWindowStyleMaskResizable,
            AppKit.NSBackingStoreBuffered, False)
    win.setTitle_("Choose the photographs faxl may read")
    # SIZE THE PICKER'S VIEW BEFORE IT BECOMES THE CONTENT, and set the
    # content size again after. Measured: without both, contentView comes
    # back 1 x 0 -- the view has not laid out yet, and the window adopts that
    # -- which is the collapsed state, by another route.
    pk.view().setFrame_(AppKit.NSMakeRect(0, 0, 1040, 720))
    win.setContentViewController_(pk)
    win.setContentSize_(AppKit.NSMakeSize(1040, 720))
    # A floor, so dragging the corner cannot reproduce the clipped state.
    win.setContentMinSize_(AppKit.NSMakeSize(760, 520))
    win.center()
    win.makeKeyAndOrderFront_(None)
    app.activateIgnoringOtherApps_(True)
    # CLOSING THE WINDOW MUST END THE RUN. Without this, dismissing the
    # picker without choosing leaves the helper spinning its run loop for
    # ever and the console's request waits out its whole timeout.
    class WinDelegate(AppKit.NSObject):
        def windowWillClose_(self, notification):
            AppKit.NSApp.stop_(None)

    wd = WinDelegate.alloc().init()
    win.setDelegate_(wd)
    app.run()

    ids = picked["ids"]
    if not ids:
        json.dump({"ok": False, "status": name, "picked": 0,
                   "error": "no photographs were chosen"},
                  open(args.out, "w"))
        return 1
    json.dump({"ok": True, "status": name, "picked": len(ids), "ids": ids},
              open(args.out, "w"))
    print(f"[photo_helper] {len(ids)} photograph(s) chosen", flush=True)
    return 0


def cmd_fetch(args):
    """Materialise ONE SLICE of the selection as upright JPEGs.

    FETCHED AS THEY ARE PROCESSED, NEVER ALL AT ONCE. The caller asks for
    [offset, offset+count) and tags those, then comes back for the next slice.
    Fetching 5,000 photographs up front would mean ~40 minutes before the
    first caption and gigabytes staged on someone's disk; a slice of 20 is
    ~10 seconds and a few megabytes, deleted when the batch finishes.

    Writes pN.jpg and idx.tsv in the shape normalise.py used to produce, so
    tag_via_faxl.py and write_to_photos.py are untouched:

        <n>\\t<path>\\t<original filename>\\t<uuid>
    """
    Foundation, Photos = _load()
    from io import BytesIO

    import Quartz
    from PIL import Image, ImageOps

    sel = json.load(open(args.ids))
    ids = sel.get("ids") or []
    todo = ids[args.offset:args.offset + args.count]
    if not todo:
        print("[photo_helper] nothing left to fetch", flush=True)
        json.dump({"ok": True, "fetched": 0, "exhausted": True},
                  open(os.path.join(args.out, "fetch.json"), "w"))
        return 0

    st, name = authorise(Photos, Foundation)
    if st not in (3, 4):
        json.dump({"ok": False, "status": name,
                   "error": "access to the chosen photographs was withdrawn"},
                  open(os.path.join(args.out, "fetch.json"), "w"))
        return 1

    mgr = Photos.PHImageManager.defaultManager()
    opts = Photos.PHImageRequestOptions.alloc().init()
    # THE ONE THAT MAKES ICLOUD WORK. Without it an asset that is not on this
    # Mac -- 92% of a real library, with Optimise Mac Storage on -- returns
    # nothing and the run looks broken.
    opts.setNetworkAccessAllowed_(True)
    opts.setSynchronous_(True)
    opts.setVersion_(Photos.PHImageRequestOptionsVersionCurrent)

    os.makedirs(args.out, exist_ok=True)
    rows, ok, failed = [], 0, 0
    for i, ident in enumerate(todo, 1):
        res = Photos.PHAsset.fetchAssetsWithLocalIdentifiers_options_(
            [ident], None)
        if res.count() == 0:
            # The selection can be revoked, or the photo deleted, between the
            # pick and now. Skip it rather than failing the batch.
            failed += 1
            print(f"[photo_helper] {ident[:8]} is no longer available",
                  flush=True)
            continue
        asset = res.objectAtIndex_(0)
        box = {}

        def handler(data, uti, orientation, info, _b=box):
            _b["data"] = data
            _b["info"] = dict(info) if info else {}

        t0 = time.time()
        # requestImageDataAndOrientation, NOT requestImageForAsset:targetSize:
        # The resizing variant returns None with no error under
        # synchronous+HighQuality, and hangs for 30s asynchronously. This one
        # hands back the ORIGINAL FILE BYTES, which is what we want anyway --
        # PIL does the rotation and the resize, so sips is not needed either.
        mgr.requestImageDataAndOrientationForAsset_options_resultHandler_(
            asset, opts, handler)
        raw = box.get("data")
        if raw is None:
            failed += 1
            err = box.get("info", {}).get("PHImageErrorKey")
            print(f"[photo_helper] could not fetch {ident[:8]}: {err}",
                  flush=True)
            continue

        n = args.offset + i
        dst = os.path.join(args.out, f"p{n}.jpg")
        try:
            data = _to_jpeg_bytes(Quartz, Foundation, raw)
            img = Image.open(BytesIO(data))
            # EXIF ROTATION IS LOAD-BEARING: a portrait photograph read
            # sideways is a different picture to the model, and normalise.py
            # records what that cost when it was missing.
            img = ImageOps.exif_transpose(img)
            img.thumbnail((2400, 2400), Image.LANCZOS)
            img.convert("RGB").save(dst, quality=92)
        except Exception as exc:                          # noqa: BLE001
            failed += 1
            print(f"[photo_helper] could not decode {ident[:8]}: {exc}",
                  flush=True)
            continue

        fname = _original_name(Photos, asset, ident)
        rows.append((n, dst, fname, _uuid(ident)))
        ok += 1
        print(f"[photo_helper] {i}/{len(todo)} {fname} "
              f"({len(bytes(raw)) / 1024:.0f} KB, {time.time() - t0:.1f}s)",
              flush=True)

    with open(os.path.join(args.out, "idx.tsv"), "w") as fh:
        for n, path, fname, uuid in rows:
            fh.write(f"{n}\t{path}\t{fname}\t{uuid}\n")
    json.dump({"ok": ok > 0, "fetched": ok, "failed": failed,
               "exhausted": args.offset + args.count >= len(ids),
               "remaining": max(len(ids) - (args.offset + len(todo)), 0)},
              open(os.path.join(args.out, "fetch.json"), "w"))
    print(f"[photo_helper] {ok} fetched, {failed} skipped", flush=True)
    return 0 if ok else 1


def _original_name(Photos, asset, ident):
    """The filename a PERSON would recognise: IMG_3957.HEIC.

    asset.valueForKey_("filename") hands back PhotoKit's internal name, which
    is the asset's own UUID -- fine as an identifier and useless in a progress
    line or a catalogue a human reads. PHAssetResource carries the name the
    camera gave the file.

    THE UUID REMAINS THE IDENTIFIER, always. This is for display only: a
    library holds thousands of duplicate IMG_ names (4,824 here, some eight
    times over) and addressing a photograph by one wrote eleven captions onto
    unrelated pictures. See c0de6de, and write_to_photos.py's refusal to
    accept anything but a UUID.
    """
    try:
        res = Photos.PHAssetResource.assetResourcesForAsset_(asset)
        for i in range(res.count()):
            name = res.objectAtIndex_(i).originalFilename()
            if name:
                return str(name)
    except Exception:                                     # noqa: BLE001
        pass
    return f"{_uuid(ident)}.jpg"


def _to_jpeg_bytes(Quartz, Foundation, nsdata):
    """Whatever PhotoKit handed us -> JPEG bytes PIL can open.

    THE ORIGINALS ARE HEIC. Measured on this library: every recent photograph
    comes back as public.heic (header "\x00\x00\x004ftypheic"), because that
    is what the iPhone actually stored. Pillow cannot decode HEIC without an
    extra native plugin (pillow-heif), and requiring one would put a
    compiled dependency in the install path of a demo app.

    macOS decodes it natively, so use that: ImageIO reads any container the
    system knows -- HEIC, JPEG, PNG, RAW -- and writes a JPEG in process. No
    external binary, no temporary file, and it retires the `sips` call the old
    normalise.py shelled out to.

    A JPEG is passed through untouched rather than re-encoded, so a photograph
    that was already JPEG loses nothing to a second lossy pass.
    """
    raw = bytes(nsdata)
    if raw[:2] == b"\xff\xd8":              # already JPEG
        return raw
    src = Quartz.CGImageSourceCreateWithData(nsdata, None)
    if src is None or Quartz.CGImageSourceGetCount(src) == 0:
        raise ValueError("ImageIO could not read this image")
    img = Quartz.CGImageSourceCreateImageAtIndex(src, 0, None)
    if img is None:
        raise ValueError("ImageIO decoded no image")
    out = Foundation.NSMutableData.data()
    dst = Quartz.CGImageDestinationCreateWithData(out, "public.jpeg", 1, None)
    if dst is None:
        raise ValueError("ImageIO would not create a JPEG writer")
    Quartz.CGImageDestinationAddImage(dst, img, None)
    if not Quartz.CGImageDestinationFinalize(dst):
        raise ValueError("ImageIO could not write the JPEG")
    return bytes(out)


def cmd_status(args):
    """What access do we have, without asking for any."""
    Foundation, Photos = _load()
    lvl = Photos.PHAccessLevelReadWrite
    st = Photos.PHPhotoLibrary.authorizationStatusForAccessLevel_(lvl)
    out = {"status": st, "name": LEVELS.get(st, str(st))}
    if st in (3, 4):
        o = Photos.PHFetchOptions.alloc().init()
        out["visible"] = Photos.PHAsset.fetchAssetsWithOptions_(o).count()
    json.dump(out, open(args.out, "w") if args.out else sys.stdout)
    if not args.out:
        print()
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pick")
    p.add_argument("--out", required=True)
    p.set_defaults(fn=cmd_pick)
    f = sub.add_parser("fetch")
    f.add_argument("--ids", required=True)
    f.add_argument("--out", required=True)
    f.add_argument("--offset", type=int, default=0)
    f.add_argument("--count", type=int, default=20)
    f.set_defaults(fn=cmd_fetch)
    s = sub.add_parser("status")
    s.add_argument("--out", default=None)
    s.set_defaults(fn=cmd_status)
    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())

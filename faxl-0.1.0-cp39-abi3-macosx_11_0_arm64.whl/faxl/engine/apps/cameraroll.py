#!/usr/bin/env python3
"""cameraroll.py — tag N photographs from the Photos library, unattended.

THE POINT IS THE JOB, NOT THE PICTURE. A file picker is a demo: a person with
27,000 photographs does not want to choose one, they want to point this at the
library, say how many, and walk away. AM, 2026-09-19: "people dont need help
uploading photos, they need help automating workflows."

AND A LONG JOB IS WHERE THE PROXY EARNS ITS KEEP. Every request shares the same
instruction preamble, so photo 1 pays for it and photos 2..N resume from the
checkpoint it left behind. Measured on 2026-09-15: 103 photographs, 103 cache
hits, 158,208 tokens reused. At ~1,024 tokens a photo a 5,000-image run reuses
around five million tokens it would otherwise have paid for -- the saving grows
with the length of the job, which is exactly the shape of the work people
actually have.

This replaces scan_faxl.sh for the console's purposes. That script hardcodes
$HOME/faxl-live/photo-tagger-ws and its bin/ directory, neither of which exists
after `pip install faxl`; the same defect the launcher had. Everything here is
resolved relative to this module or written under ~/.faxl.

READ-ONLY ON ORIGINALS, ALWAYS. The library is opened with sqlite3 -readonly,
derivatives live in a temp directory that is deleted on exit, and captions are
only written back when the caller explicitly asks -- see write_to_photos.py,
which uses Photos' own AppleScript API so the change is undoable in Photos.
"""
import json
import os
import re
import signal
import time
import urllib.request
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.expanduser("~/Pictures/Photos Library.photoslibrary")


def faxl_home():
    return os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")


def job_dir():
    d = os.path.join(faxl_home(), "jobs", "cameraroll")
    os.makedirs(d, exist_ok=True)
    return d


def _work_root():
    """Where a batch's converted JPEGs are staged.

    Set by setup_cameraroll.py and read here rather than hardcoded: these are
    derivatives of somebody's private photographs, so the volume they land on
    is the owner's decision. Falls back to the system temp directory, which is
    what this did before the setting existed.

    Created 0700 on the way past -- a batch of converted family photographs
    should not be world-readable on a shared Mac.
    """
    from faxl.engine import faxl_config
    root = faxl_config.get("photo_work_dir", "FAXL_PHOTO_WORK")
    if not root:
        return tempfile.gettempdir()
    root = os.path.abspath(os.path.expanduser(root))
    try:
        os.makedirs(root, mode=0o700, exist_ok=True)
    except OSError as exc:
        print(f"[cameraroll] cannot use {root} ({exc}) — staging in "
              f"{tempfile.gettempdir()} instead", file=sys.stderr, flush=True)
        return tempfile.gettempdir()
    return root


class PhotosAccessError(RuntimeError):
    """The library is there but macOS will not let us read it.

    This is the failure a customer actually hits, and it is invisible unless
    it is named: the proxy's process needs Full Disk Access, and until it has
    it sqlite3 reports "unable to open database file" -- which reads like a
    missing file rather than a permission.
    """


def check_access():
    """(ok, detail). Never raises: the page needs to explain, not crash."""
    db = os.path.join(LIB, "database", "Photos.sqlite")
    if not os.path.exists(LIB):
        return False, f"no Photos library at {LIB}"
    try:
        r = subprocess.run(["sqlite3", "-readonly", db,
                            "SELECT count(*) FROM ZASSET WHERE ZTRASHEDSTATE=0"],
                           capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as e:
        return False, f"could not run sqlite3: {e}"
    if r.returncode != 0:
        err = (r.stderr or "").strip()
        if "unable to open" in err or "authorization denied" in err:
            return False, ("macOS is blocking access to the Photos library. "
                           "Give Full Disk Access to whatever you started "
                           "faxl from (System Settings -> Privacy & Security "
                           "-> Full Disk Access), then start it again.")
        return False, err[:300] or "sqlite3 failed"
    return True, f"{(r.stdout or '').strip()} photographs in the library"


def newest(n):
    """The n newest originals, newest first.

    ZUUID IS THE IDENTIFIER, NEVER THE FILENAME. iPhone recycles IMG_XXXX
    after a reset, so one library holds many photographs with the same name --
    4,824 duplicates in this one, some appearing eight times. Addressing a
    photo by name picks an arbitrary one of them, and writing captions by name
    put eleven of them onto unrelated photographs from two years earlier.
    """
    db = os.path.join(LIB, "database", "Photos.sqlite")
    q = ("SELECT a.ZDIRECTORY||'/'||a.ZFILENAME, "
         "COALESCE(aa.ZORIGINALFILENAME,a.ZFILENAME), a.ZUUID "
         "FROM ZASSET a LEFT JOIN ZADDITIONALASSETATTRIBUTES aa "
         "ON aa.ZASSET=a.Z_PK "
         "WHERE a.ZTRASHEDSTATE=0 AND a.ZHIDDEN=0 AND a.ZKIND=0 "
         f"ORDER BY a.ZDATECREATED DESC LIMIT {int(n)};")
    r = subprocess.run(["sqlite3", "-readonly", db, q],
                       capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        raise PhotosAccessError((r.stderr or "sqlite3 failed").strip()[:300])
    rows = []
    for line in (r.stdout or "").splitlines():
        parts = line.split("|")
        if len(parts) >= 3:
            rows.append(parts)
    return rows


def on_disk(rows):
    """Only the photographs whose ORIGINAL is actually on this machine.

    THE LIBRARY IS MOSTLY NOT HERE. Measured on this Mac: 26,335 photographs
    in the index, 883 originals on disk -- 3%. With "Optimise Mac Storage" on,
    which is the default, the rest live in iCloud and the local file is a
    thumbnail or nothing at all.

    So a run of "the newest 5,000" would have skipped almost all of them and
    reported "converted 0/5000", which reads as a broken product rather than
    as photographs that are not here. The database's ZCLOUDLOCALSTATE does not
    answer this reliably (it says 26,178 are local, which the filesystem
    contradicts), so the file itself is the authority.

    Downloading them is the customer's decision, not ours: it is their
    bandwidth and their disk, and on a metered connection it is expensive.
    The page says how many are available and lets them choose.
    """
    out = []
    for rel, orig, uuid in ((r + ["", "", ""])[:3] for r in rows):
        if rel and os.path.exists(os.path.join(LIB, "originals", rel)):
            out.append([rel, orig, uuid])
    return out


def fetch_from_icloud(uuid, dest, timeout=180):
    """Materialise one iCloud original into `dest`. Returns the path, or None.

    WHY THIS EXISTS: 26,335 photographs in this library, 883 originals on disk
    -- 3%, because "Optimise Mac Storage" is the default. Without this, "tag
    the newest 5,000" would skip 97% of them and report almost nothing done.

    Photos' own AppleScript export is the supported way to ask for an original,
    the same call write_to_photos.py already uses to put captions back, so the
    permission is one the customer has granted once rather than twice.
    Measured: 2.6 seconds for a single photograph over this connection.

    Not a bulk download: one picture, fetched when the job reaches it, used,
    and left in a temp directory that is deleted at the end. The customer's
    disk holds what it held before.
    """
    scr = (f'tell application "Photos"\n'
           f'  set theItem to media item id "{uuid}"\n'
           f'  export {{theItem}} to POSIX file "{dest}" with using originals\n'
           f'end tell')
    try:
        r = subprocess.run(["osascript", "-e", scr],
                           capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    files = sorted(os.listdir(dest)) if os.path.isdir(dest) else []
    return os.path.join(dest, files[0]) if files else None


def available(limit=None):
    """(rows_on_disk, n_examined). Walks newest-first until it has `limit`.

    Scans in pages rather than pulling the whole index: a library of 26,000
    rows is cheap to query but pointless to materialise when the caller wants
    the newest 50 that are actually here.
    """
    want = limit or 10 ** 9
    got, seen, page, size = [], 0, 0, max(500, (limit or 0) * 8)
    while len(got) < want:
        rows = newest_offset(size, page * size)
        if not rows:
            break
        seen += len(rows)
        got.extend(on_disk(rows))
        page += 1
        if page > 200:            # a hard stop; 100k rows examined is plenty
            break
    return got[:want], seen


def newest_offset(limit, offset):
    db = os.path.join(LIB, "database", "Photos.sqlite")
    q = ("SELECT a.ZDIRECTORY||'/'||a.ZFILENAME, "
         "COALESCE(aa.ZORIGINALFILENAME,a.ZFILENAME), a.ZUUID "
         "FROM ZASSET a LEFT JOIN ZADDITIONALASSETATTRIBUTES aa "
         "ON aa.ZASSET=a.Z_PK "
         "WHERE a.ZTRASHEDSTATE=0 AND a.ZHIDDEN=0 AND a.ZKIND=0 "
         f"ORDER BY a.ZDATECREATED DESC LIMIT {int(limit)} "
         f"OFFSET {int(offset)};")
    r = subprocess.run(["sqlite3", "-readonly", db, q],
                       capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        raise PhotosAccessError((r.stderr or "sqlite3 failed").strip()[:300])
    rows = []
    for line in (r.stdout or "").splitlines():
        parts = line.split("|")
        if len(parts) >= 3:
            rows.append(parts)
    return rows


def already_done(out_path):
    """The uuids this run has already catalogued.

    RESUME IS THE WHOLE REASON THE JSONL IS APPEND-PER-PHOTO. A 5,000 photo
    run that stops at 2,000 must not redo those 2,000 -- that is hours of
    compute and the cache cannot help, because the work was already finished.
    The partial file is always valid, so it is also always a resume point.
    """
    seen = set()
    if not os.path.exists(out_path):
        return seen
    with open(out_path) as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue          # a torn final line; the next write fixes it
            if row.get("uuid"):
                seen.add(row["uuid"])
    return seen


BATCH = 20          # photographs fetched, tagged and deleted as one unit

# The tagger subprocess currently running, so a stop can reach it. Module
# level because the signal handler and run_batch are in different scopes.
CURRENT_CHILD = {"proc": None}


def parse_window(spec):
    """"23:00-07:00" -> (1380, 420) in minutes past midnight, or None.

    A window that wraps midnight is the normal case -- the whole point is to
    run while the owner is asleep -- so the pair is NOT required to be
    ascending and `inside_window` handles the wrap.
    """
    if not spec:
        return None
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*", spec)
    if not m:
        raise ValueError(f"window must look like 23:00-07:00, not {spec!r}")
    a_h, a_m, b_h, b_m = (int(x) for x in m.groups())
    for h, mi in ((a_h, a_m), (b_h, b_m)):
        if h > 23 or mi > 59:
            raise ValueError(f"{spec!r} is not a time of day")
    start, stop = a_h * 60 + a_m, b_h * 60 + b_m
    if start == stop:
        raise ValueError(f"{spec!r} is an empty window")
    return start, stop


def inside_window(win, now=None):
    if not win:
        return True
    now = now or time.localtime()
    mins = now.tm_hour * 60 + now.tm_min
    start, stop = win
    return start <= mins < stop if start < stop else (mins >= start or mins < stop)


def write_status(path, **fields):
    """Publish progress for the console to poll.

    tmp + os.replace, never a direct write: the console reads this file on a
    timer and a half-written JSON document renders as a broken page rather
    than as "no status yet". os.replace is atomic on the same filesystem.
    """
    fields["updated"] = time.time()
    tmp = path + ".tmp"
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(tmp, "w") as fh:
            json.dump(fields, fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except OSError:
        pass            # never fail a run because the status file could not
                        # be written; the JSONL is the durable record


def proxy_alive(endpoint, timeout=5):
    try:
        urllib.request.urlopen(f"{endpoint}/api/overview", timeout=timeout).read(1)
        return True
    except Exception:                                    # noqa: BLE001
        return False


def selection_path():
    return os.path.join(job_dir(), "selection.json")


def load_selection():
    """The photographs chosen through the system picker, or [].

    Returns the asset identifiers in the order they were picked. An empty
    list means no selection has been made and the job falls back to the
    library enumeration, which is the pre-picker behaviour.
    """
    try:
        with open(selection_path()) as fh:
            d = json.load(fh)
        return list(d.get("ids") or []) if d.get("ok") else []
    except (OSError, ValueError):
        return []


def next_from_selection(ids, want, offset, done):
    """The next `want` chosen photographs not already catalogued.

    The identifier carries the UUID as its first component, which is what the
    catalogue records, so "already done" is answered without touching Photos.
    """
    rows, i = [], offset
    while len(rows) < want and i < len(ids):
        ident = ids[i]
        i += 1
        if str(ident).split("/")[0] in done:
            continue
        rows.append(ident)
    return rows, i


def fetch_selection(idents, work, offset):
    """Materialise chosen photographs through the PhotoKit helper.

    FETCHED AS THEY ARE PROCESSED. The helper takes a slice, so a run over
    5,000 photographs stages ~20 at a time rather than gigabytes up front.
    """
    app = os.path.expanduser("~/.faxl/faxl-photos.app")
    if not os.path.isdir(app):
        print("[cameraroll] the Photos helper is not built; run the console's "
              "Choose photos button once", file=sys.stderr)
        return 3
    sel = os.path.join(work, "ids.json")
    with open(sel, "w") as fh:
        json.dump({"ok": True, "ids": list(idents)}, fh)
    r = subprocess.run(["/usr/bin/open", "-W", "-a", app, "--args", "fetch",
                        "--ids", sel, "--out", work,
                        "--offset", "0", "--count", str(len(idents))],
                       capture_output=True, text=True, timeout=1800)
    if r.returncode != 0:
        print(f"[cameraroll] helper failed: {(r.stderr or '')[:200]}",
              file=sys.stderr)
        return 3
    return 0


def _run_tagger(cmd, env):
    """Run the tagger, keeping a handle so a stop can reach it."""
    proc = subprocess.Popen(cmd, env=env)
    CURRENT_CHILD["proc"] = proc
    try:
        return proc.wait()
    finally:
        CURRENT_CHILD["proc"] = None


def run_batch(rows, args, work, selection=False):
    """Fetch, normalise and tag one batch. Returns the tagger's exit code.

    One batch is one self-contained unit of work: its staging directory is
    created here and removed by the caller, so a 5,000-photograph run never
    holds more than BATCH originals on disk at a time. Fetching all of them
    first would mean 3.6 hours before the first caption and ~15 GB in /tmp.
    """
    if selection:
        # The helper writes pN.jpg and idx.tsv itself -- it has the original
        # bytes, so there is nothing for sips or normalise.py to do.
        rc = fetch_selection(rows, work, 0)
        if rc:
            return rc
        env = dict(os.environ)
        env["FAXL_ENDPOINT"] = args.endpoint
        env["FAXL_PROJECT"] = "photo-tagger"
        cmd = [sys.executable, os.path.join(HERE, "tag_via_faxl.py"),
               work, args.out, "--jobs", str(args.jobs)]
        if args.write_photos:
            cmd.append("--write-photos")
        return _run_tagger(cmd, env)

    fetched = {}
    if args.icloud:
        staged = os.path.join(work, "icloud")
        os.makedirs(staged, exist_ok=True)
        missing = [r for r in rows
                   if not os.path.exists(os.path.join(LIB, "originals", r[0]))]
        for i, (rel, orig, uuid) in enumerate(missing, 1):
            one = os.path.join(staged, uuid)
            os.makedirs(one, exist_ok=True)
            got = fetch_from_icloud(uuid, one)
            if got:
                fetched[uuid] = got
                print(f"[cameraroll]   fetched {i}/{len(missing)} {orig}",
                      file=sys.stderr, flush=True)
            else:
                # FAIL THE BATCH FAST ON THE FIRST ONE. Photos' export sits at
                # the timeout when the network is gone, so twenty of them is
                # twenty times 180s of silence. One failure at the head of a
                # batch means something is wrong with the connection or the
                # permission, not with that photograph.
                print(f"[cameraroll]   could not fetch {orig}",
                      file=sys.stderr, flush=True)
                if i == 1:
                    print("[cameraroll] the first fetch of this batch failed "
                          "— stopping rather than waiting out the rest. Is "
                          "the network up, and is Photos automation allowed?",
                          file=sys.stderr, flush=True)
                    return 4
    with open(os.path.join(work, "idx.tsv"), "w") as fh:
        for i, (rel, orig, uuid) in enumerate(rows, 1):
            fh.write(f"{i}\t{fetched.get(uuid, rel)}\t{orig}\t{uuid}\n")
    # HEIC -> upright JPEG. The rotation is load-bearing; normalise.py
    # explains why a sideways photograph is read as a different picture.
    subprocess.run([sys.executable, os.path.join(HERE, "normalise.py"),
                    LIB, work, "12"], check=True, timeout=1800)
    env = dict(os.environ)
    env["FAXL_ENDPOINT"] = args.endpoint
    env["FAXL_PROJECT"] = "photo-tagger"
    cmd = [sys.executable, os.path.join(HERE, "tag_via_faxl.py"),
           work, args.out, "--jobs", str(args.jobs)]
    if args.write_photos:
        cmd.append("--write-photos")
    return _run_tagger(cmd, env)


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=8,
                    help="photographs to catalogue THIS RUN; ones already "
                         "done do not count towards it")
    ap.add_argument("--out", default=os.path.join(job_dir(), "catalogue.jsonl"))
    ap.add_argument("--endpoint",
                    default=os.environ.get("FAXL_ENDPOINT",
                                           "http://127.0.0.1:8767"))
    ap.add_argument("--write-photos", action="store_true")
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=BATCH,
                    help=f"photographs per batch (default {BATCH})")
    ap.add_argument("--window", default="",
                    help="only run between these times, e.g. 23:00-07:00. "
                         "Checked between batches, so a batch already "
                         "started always finishes.")
    ap.add_argument("--icloud", action="store_true", default=True,
                    help="fetch originals from iCloud as the job reaches "
                         "them (default: on; 97%% of this library is not on "
                         "disk)")
    ap.add_argument("--no-icloud", dest="icloud", action="store_false",
                    help="only photographs already downloaded to this Mac")
    args = ap.parse_args()

    try:
        win = parse_window(args.window)
    except ValueError as exc:
        print(f"FATAL: {exc}", file=sys.stderr)
        return 2

    # A SELECTION BEATS THE WHOLE LIBRARY. When the customer has chosen
    # photographs through the system picker, those are the only ones faxl can
    # read -- and the only ones it should touch. The sqlite enumeration below
    # is the older path, which needs Full Disk Access and is what the picker
    # exists to replace.
    selection = load_selection()
    if selection:
        print(f"[cameraroll] {len(selection)} photograph(s) chosen through "
              f"the Photos picker", file=sys.stderr)
    else:
        ok, detail = check_access()
        if not ok:
            print(f"FATAL: {detail}", file=sys.stderr)
            return 2
        print(f"[cameraroll] {detail}", file=sys.stderr)

    status = os.path.join(job_dir(), "status.json")
    done = already_done(args.out)
    if done:
        print(f"[cameraroll] {len(done)} already catalogued — resuming",
              file=sys.stderr)

    # STOP IS SIGTERM, HONOURED AT A BATCH BOUNDARY. Killing mid-batch would
    # leave a half-fetched staging directory and a photograph tagged but not
    # recorded; the JSONL is appended per photograph, so finishing the batch
    # in hand costs ~2 minutes and loses nothing.
    stopping = {"now": False}

    def _stop(signum, frame):                            # noqa: ARG001
        stopping["now"] = True
        print("[cameraroll] stop requested — finishing this photograph",
              file=sys.stderr, flush=True)
        # PASS IT ON. The tagger is the process actually spending the time --
        # ~15s a photograph, twenty to a batch -- so a stop that only sets a
        # flag here is not honoured until the whole batch ends, up to five
        # minutes of a Stop button doing nothing visible. The tagger stops
        # between photographs and loses nothing: its JSONL is fsynced per row.
        child = CURRENT_CHILD.get("proc")
        if child is not None and child.poll() is None:
            try:
                child.send_signal(signal.SIGTERM)
            except OSError:
                pass

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    tagged, offset, misses, batch_no = 0, 0, 0, 0
    t0 = time.time()
    write_status(status, state="running", tagged=0, target=args.count,
                 started=t0, pid=os.getpid())
    while tagged < args.count and not stopping["now"]:
        # THE WINDOW IS CHECKED HERE, BETWEEN BATCHES, and slept through in
        # short steps so a stop request is honoured within a minute rather
        # than at the end of an eight-hour wait.
        while not inside_window(win, None) and not stopping["now"]:
            write_status(status, state="waiting", tagged=tagged,
                         target=args.count, window=args.window, started=t0,
                         pid=os.getpid())
            print(f"[cameraroll] outside {args.window} — waiting",
                  file=sys.stderr, flush=True)
            for _ in range(60):
                if stopping["now"]:
                    break
                time.sleep(60)
        if stopping["now"]:
            break

        if not proxy_alive(args.endpoint):
            # The job outlives a proxy restart (start_new_session=True), and
            # without this it would churn through thousands of photographs
            # recording an HTTP error against each one.
            misses += 1
            if misses >= 3:
                print(f"FATAL: no faxl proxy at {args.endpoint} after three "
                      f"tries — stopping. Nothing catalogued so far is lost.",
                      file=sys.stderr)
                write_status(status, state="failed", tagged=tagged,
                             target=args.count, error="proxy unreachable",
                             started=t0)
                return 5
            print(f"[cameraroll] proxy not answering ({misses}/3) — waiting",
                  file=sys.stderr, flush=True)
            time.sleep(20)
            continue
        misses = 0

        want = min(args.batch, args.count - tagged)
        # Page the library rather than asking for everything: the ones already
        # catalogued are skipped here, so `--count` means "tag this many more".
        if selection:
            rows, offset = next_from_selection(selection, want, offset, done)
        else:
            rows, offset = next_batch(want, offset, done, args.icloud)
        if not rows:
            print("[cameraroll] no more photographs to catalogue",
                  file=sys.stderr)
            break

        batch_no += 1
        print(f"[cameraroll] batch {batch_no}: {len(rows)} photograph(s), "
              f"{tagged}/{args.count} done", file=sys.stderr, flush=True)
        write_status(status, state="running", tagged=tagged,
                     target=args.count, batch=batch_no, started=t0,
                     pid=os.getpid())

        # THE CUSTOMER CHOSE WHERE THIS GOES (setup_cameraroll.py). These are
        # converted copies of private photographs, so the location is theirs
        # to pick -- a hardcoded /tmp is both a disclosure on a shared box and
        # the wrong volume on a Mac with a small boot disk.
        work = tempfile.mkdtemp(prefix="faxl-cameraroll-", dir=_work_root())
        try:
            rc = run_batch(rows, args, work, selection=bool(selection))
        finally:
            # Only ever the directory this batch created, and only one it
            # made itself -- never a path that came from anywhere else.
            # The root is either the system temp dir or the one the customer
            # nominated; both are checked, so a configured path is cleaned up
            # and an unexpected one is still left alone.
            _roots = (tempfile.gettempdir(), _work_root())
            if work.startswith(_roots) and not os.environ.get("FAXL_KEEP_WORK"):
                shutil.rmtree(work, ignore_errors=True)
            elif os.environ.get("FAXL_KEEP_WORK"):
                print(f"[cameraroll] kept {work}", file=sys.stderr)
        if rc != 0:
            print(f"[cameraroll] batch {batch_no} failed (rc={rc}) — stopping",
                  file=sys.stderr)
            write_status(status, state="failed", tagged=tagged,
                         target=args.count, error=f"batch rc={rc}", started=t0)
            return rc

        # Count what actually landed in the JSONL, not what was attempted: a
        # photograph that failed to fetch must not consume the budget.
        now_done = already_done(args.out)
        tagged += len(now_done) - len(done)
        done = now_done

    elapsed = time.time() - t0
    state = "stopped" if stopping["now"] else "finished"
    write_status(status, state=state, tagged=tagged, target=args.count,
                 started=t0, elapsed=round(elapsed, 1))
    print(f"[cameraroll] {state}: {tagged} catalogued in {elapsed:.0f}s "
          f"-> {args.out}", file=sys.stderr)
    return 0


def next_batch(want, offset, done, icloud):
    """The next `want` photographs not already catalogued, and the new offset.

    Pages through the library by offset because `done` grows as the run goes
    on: asking for "the newest N" every time would hand back the same ones
    that were just finished.
    """
    rows, seen = [], offset
    while len(rows) < want:
        page = newest_offset(max(want * 2, 50), seen)
        if not page:
            break
        seen += len(page)
        for r in page:
            if r[2] in done:
                continue
            if not icloud and not os.path.exists(
                    os.path.join(LIB, "originals", r[0])):
                continue        # --no-icloud: only what is already here
            rows.append(r)
            if len(rows) >= want:
                break
    return rows, seen


if __name__ == "__main__":
    raise SystemExit(main())

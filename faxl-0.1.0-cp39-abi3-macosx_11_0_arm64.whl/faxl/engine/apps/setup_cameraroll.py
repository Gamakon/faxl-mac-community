#!/usr/bin/env python3
"""setup_cameraroll.py — prepare a machine to run the camera-roll tagger.

WHY THIS EXISTS, and why it asks rather than assumes.

The photo tagger writes two kinds of thing to disk that are NOT the customer's
photographs, and both of them have burned us:

  * CONVERTED COPIES. Every HEIC is turned into an upright JPEG before the
    model sees it (normalise.py: the rotation is load-bearing). Those are
    derivatives of somebody's private photographs, so where they land is the
    owner's decision, not a hardcoded /tmp -- on a Mac with FileVault off and
    a shared /tmp that is a real disclosure, and on a machine with a small
    boot volume a 5,000-photo run is tens of gigabytes in the wrong place.

  * THE CACHE. Checkpoints are large (~0.5 GB each here) and they are what
    makes the second photograph fast. A cap that is too small evicts the
    shared preamble and the demo stops working; too large and it fills a
    disk the owner wanted for something else.

AND A DEDICATED STORE IS WORTH MORE THAN TIDINESS. A store shared with other
work accumulates entries written by older code, and the ladder cannot always
tell a stale one from a good one by inspection. Measured today on the shared
store: TWENTY checkpoints written mid-atom by a build that predated the
boundary clamp. The reader now refuses them, but they still occupy the cap,
still get probed first, and -- because they carry recorded hits -- score as
POPULAR under usage-based retention, so they would outlive the good blobs.
Three photographs came back confidently described as "a plain white surface
with no discernible objects": the vision tower never ran, and the model
answered from the preamble.

So this offers a CLEAN SLATE, and asks before taking it. Deleting a cache is
cheap and safe -- every entry is reconstructible by re-running the prompt --
but it is still the customer's disk, so it is never done silently and never
without a y/n. Photographs are NEVER touched: the library is opened read-only
everywhere in this package, and this tool does not go near it.
"""
import argparse
import json
import os
import shutil
import sys

from faxl.engine import faxl_config

DEFAULT_WORK = "~/.faxl/photo-work"
DEFAULT_STORE = "~/.faxl/photo-cache"
# 8 GB holds ~16 checkpoints at the size this model produces, which is many
# times what a single-preamble workload needs (it stores ONE shared prefix and
# reuses it for every photograph). Small enough not to surprise anyone.
DEFAULT_CAP_GB = 8.0


def _ask(prompt, default):
    """One question, with the default in the prompt. Enter accepts it."""
    try:
        got = input(f"{prompt} [{default}]: ").strip()
    except EOFError:
        return default
    return got or default


def _confirm(prompt):
    """y/n, and ONLY an explicit yes is a yes.

    Not `startswith("y")` on an empty string, and no default: this gates a
    delete, and the safe answer must be the one you get by pressing Enter or
    by closing the terminal.
    """
    try:
        return input(f"{prompt} [y/N]: ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def _dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _describe(path):
    """(exists, n_entries, bytes) for a directory that may not be there."""
    if not os.path.isdir(path):
        return False, 0, 0
    try:
        n = len(os.listdir(path))
    except OSError:
        n = 0
    return True, n, _dir_size(path)


def _wipe(path, what):
    """Delete a directory and say what it cost. Never raises.

    Removed and RECREATED empty: the proxy expects the directory to exist and
    a missing one turns into a boot error the user has to decode.
    """
    _exists, n, nbytes = _describe(path)
    try:
        shutil.rmtree(path)
    except OSError as exc:
        print(f"  could not remove {path}: {exc}", file=sys.stderr)
        return False
    os.makedirs(path, exist_ok=True)
    print(f"  removed {what}: {n} entr(ies), {nbytes / 1e9:.2f} GB "
          f"-> {path} is now empty")
    return True


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Set up the camera-roll tagger: where converted photos "
                    "and the cache live, and optionally start from empty.")
    ap.add_argument("--work", help="directory for converted JPEGs")
    ap.add_argument("--store", help="directory for the cache")
    ap.add_argument("--cap-gb", type=float, help="cache size limit in GB")
    ap.add_argument("--reset", choices=("yes", "no"),
                    help="delete an existing cache without asking")
    ap.add_argument("--non-interactive", action="store_true",
                    help="never prompt; use the flags and the defaults. A "
                         "reset still requires --reset yes.")
    args = ap.parse_args(argv)

    interactive = not args.non_interactive and sys.stdin.isatty()

    print("\nfaxl — camera roll tagger setup\n" + "-" * 34)
    print("Your photographs are never modified and never leave this Mac.\n"
          "These two directories hold WORKING COPIES, not originals.\n")

    # ---- 1. where the converted photographs go --------------------------
    work = args.work or (
        _ask("Directory for converted photos (temporary, deleted per batch)",
             DEFAULT_WORK) if interactive else DEFAULT_WORK)
    work = os.path.abspath(os.path.expanduser(work))

    # ---- 2. where the cache goes, and how big ---------------------------
    store = args.store or (
        _ask("Directory for the faxl cache", DEFAULT_STORE)
        if interactive else DEFAULT_STORE)
    store = os.path.abspath(os.path.expanduser(store))

    cap = args.cap_gb
    if cap is None:
        cap = float(_ask("Cache size limit in GB", DEFAULT_CAP_GB)
                    if interactive else DEFAULT_CAP_GB)
    if cap <= 0:
        print("FATAL: the cache limit must be greater than 0", file=sys.stderr)
        return 2

    # REFUSE A NESTED PAIR. With the cache inside the work directory, the
    # per-batch cleanup deletes the cache mid-run; the other way round, a
    # reset throws away photographs waiting to be tagged.
    if work == store or work.startswith(store + os.sep) \
            or store.startswith(work + os.sep):
        print(f"FATAL: the photo directory and the cache directory must be "
              f"separate.\n  photos: {work}\n  cache : {store}\n"
              f"One inside the other means clearing one destroys the other.",
              file=sys.stderr)
        return 2

    # ---- 3. a clean slate, if they want one -----------------------------
    exists, n, nbytes = _describe(store)
    wiped = False
    if exists and n:
        print(f"\nThere is already a cache at {store}:\n"
              f"  {n} entr(ies), {nbytes / 1e9:.2f} GB")
        print("  Deleting it costs nothing but the time to fill it again --\n"
              "  every entry is rebuilt by re-running a prompt. Starting\n"
              "  empty is the reliable way to begin, because a store written\n"
              "  by an older build can hold checkpoints this one refuses.")
        if args.reset == "yes":
            do_reset = True
        elif args.reset == "no":
            do_reset = False
        elif interactive:
            do_reset = _confirm("  Delete it and start fresh?")
        else:
            do_reset = False
            print("  (not deleting: pass --reset yes to clear it)")
        if do_reset:
            wiped = _wipe(store, "cache")
    os.makedirs(store, exist_ok=True)
    os.makedirs(work, exist_ok=True)

    # The converted photographs are derivatives of private pictures: owner
    # only, and set on the directory so every file written into it inherits a
    # private parent even if a writer forgets.
    for d in (work, store):
        try:
            os.chmod(d, 0o700)
        except OSError:
            pass

    # ---- 4. save it where the proxy will read it ------------------------
    # blob_dir is the ONE setting: the proxy derives the ultradim db and the
    # token-prefix directory from it (faxl_proxy.py:81-90), so relocating it
    # moves the whole store rather than half of it.
    saved = faxl_config.write({
        faxl_config.store_key("mlx"): store,
        "store_cap_gb": float(cap),
        "photo_work_dir": work,
    })

    print(f"\nSaved to {faxl_config.config_path()}:")
    print(f"  converted photos : {work}")
    print(f"  cache            : {store}")
    print(f"  cache limit      : {cap:g} GB")
    if wiped:
        print("  cache was cleared — the first photograph will be cold, and\n"
              "  every one after it resumes from the checkpoint it leaves.")

    # THESE ARE READ AT IMPORT. A running proxy holds the old paths in module
    # globals and will keep using them, which would look exactly like the
    # setting being ignored -- so say so rather than let them find out.
    print("\nRestart the proxy for this to take effect:\n"
          "  the console's restart button, or stop and start faxl-proxy.\n")
    print("Then tag some photographs:\n"
          "  python -m faxl.engine.apps.cameraroll --count 20 "
          "--write-photos\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/bin/bash
# faxl_up.sh — faxl on its own, the model in-process (mlx). A WRAPPER NOW: faxl_start.sh is the launcher.
#
#   ./faxl_up.sh [model]
#
# The backend used to be decided by WHICH of two scripts ran, with the model
# in FAXL_MODEL. Both now live in ~/.faxl/config.json, and faxl_start.sh
# starts whatever it says. This script is kept so the instructions, memory and
# fingers that know its name keep working: it records "mlx" as the
# backend -- so the choice SURVIVES a restart from the console -- and hands
# over. [model], when given, is written to the config by faxl_start.sh.
#
# This is the DEFAULT SHAPE, and the one a customer gets: one process, one
# model, no cluster. exo is a switch you turn on, not the thing you start with.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${FAXL_PYTHON:-$(command -v python3)}"
export FAXL_PYTHON="$VENV"

"$VENV" -m faxl.engine.faxl_config --set backend=mlx >/dev/null || {
  echo "FATAL: $VENV could not write the faxl config -- can it import faxl?"
  echo "       Pass FAXL_PYTHON=<interpreter>."
  exit 1; }
# Running faxl_up.sh IS the choice of backend. A FAXL_BACKEND left exported in
# this shell would override the config just written and start the other one.
if [ -n "${FAXL_BACKEND:-}" ] && [ "$FAXL_BACKEND" != "mlx" ]; then
  echo "note: FAXL_BACKEND=$FAXL_BACKEND ignored -- faxl_up.sh means mlx"
fi
unset FAXL_BACKEND

exec bash "$HERE/faxl_start.sh" "$@"

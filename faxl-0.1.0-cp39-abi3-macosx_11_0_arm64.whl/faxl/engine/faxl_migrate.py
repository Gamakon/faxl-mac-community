# Vendored engine module (faxl_migrate.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
#!/usr/bin/env python3
"""faxl_migrate.py — move the cache store, then let the launcher bring the
proxy back up on it.

Runs in the window where the proxy is STOPPED. The console starts it as part
of the same stop/start the model switch uses, because the store is live: blobs
are written as requests land and evicted when the cap is reached, so a copy
taken underneath a running proxy either misses what arrived mid-copy or
catches a blob between its write and its rename.

    argv: <src> <dest> <config.json> <config key> <same_fs 0|1>

THE ORDER IS THE SAFETY:

    copy -> verify -> write the config -> delete the old

The delete is LAST and runs only when the verify passed. On any failure the
old store is untouched and the config is unchanged, so the machine comes back
exactly as it was and the user has lost nothing but the restart.

Progress is written to $FAXL_HOME/logs/migrate.json because the console is not
running for most of this; the page polls that file once the proxy answers
again.
"""
import json
import os
import shutil
import sys
import time


def _state_path():
    base = os.environ.get("FAXL_HOME") or os.path.expanduser("~/.faxl")
    return os.path.join(base, "logs", "migrate.json")


def _say(**kw):
    """Write the progress file atomically — the console may read it at any
    moment, and a half-written JSON file reads as a failure."""
    kw.setdefault("at", time.time())
    p = _state_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(kw, fh)
    os.replace(tmp, p)
    print(f"[faxl migrate] {kw.get('phase')}: {kw.get('detail', '')}",
          flush=True)


def _measure(path):
    """(files, bytes) under path. This is the verification: a count and a
    total catch every failure a copy actually produces -- truncation, a
    missing file, a partial tree -- and hashing tens of GB would add minutes
    to a window where the proxy is down."""
    files = 0
    total = 0
    for root, _dirs, names in os.walk(path):
        for n in names:
            try:
                total += os.path.getsize(os.path.join(root, n))
                files += 1
            except OSError:
                pass
    return files, total


def main(argv):
    if len(argv) < 6:
        print("usage: faxl_migrate.py <src> <dest> <config> <key> <same_fs>")
        return 2
    src, dest, cfg_path, key, same_fs = argv[1], argv[2], argv[3], argv[4], argv[5] == "1"

    if not os.path.isdir(src):
        # Nothing to move: record the new location and let the proxy start on
        # an empty store rather than failing the whole change.
        _write_config(cfg_path, key, dest)
        _say(phase="done", detail="no existing store to move", moved_bytes=0)
        return 0

    want_files, want_bytes = _measure(src)
    _say(phase="copying", detail=f"{want_files} files, "
         f"{want_bytes / 1e9:.1f} GB", total_bytes=want_bytes,
         total_files=want_files, src=src, dest=dest)

    try:
        if same_fs:
            # One filesystem: this is a rename. Instant, atomic, and there is
            # nothing left at the old path to delete afterwards.
            if os.path.isdir(dest) and not os.listdir(dest):
                os.rmdir(dest)
            os.rename(src, dest)
            _say(phase="verifying", detail="moved on one filesystem",
                 total_bytes=want_bytes, total_files=want_files)
        else:
            os.makedirs(dest, exist_ok=True)
            shutil.copytree(src, dest, dirs_exist_ok=True)
            _say(phase="verifying", detail="copied; checking",
                 total_bytes=want_bytes, total_files=want_files)
    except Exception as exc:  # noqa: BLE001 — report and leave everything alone
        _say(phase="failed", detail=f"{type(exc).__name__}: {exc}",
             note="nothing was deleted and the setting was not changed")
        return 1

    got_files, got_bytes = _measure(dest)
    if same_fs:
        pass                      # a rename cannot be partial
    elif got_files != want_files or got_bytes != want_bytes:
        _say(phase="failed",
             detail=(f"copy does not match: {got_files} files / "
                     f"{got_bytes} bytes at the destination, expected "
                     f"{want_files} / {want_bytes}"),
             note="the old store is untouched and the setting was not changed")
        return 1

    # Only now is the new location the real one.
    _write_config(cfg_path, key, dest)

    if not same_fs:
        # LAST, and only after a verify that passed.
        try:
            shutil.rmtree(src)
            _say(phase="done", detail=f"moved {got_bytes / 1e9:.1f} GB to "
                 f"{dest}; removed the old store", moved_bytes=got_bytes)
        except OSError as exc:
            _say(phase="done", detail=f"moved {got_bytes / 1e9:.1f} GB to "
                 f"{dest}, but the old store could not be removed ({exc})",
                 moved_bytes=got_bytes, note=f"delete {src} yourself")
    else:
        _say(phase="done", detail=f"moved {got_bytes / 1e9:.1f} GB to {dest}",
             moved_bytes=got_bytes)
    return 0


def _write_config(cfg_path, key, dest):
    """Merge, never overwrite: this file holds more than one setting."""
    data = {}
    try:
        with open(cfg_path) as fh:
            data = json.load(fh)
    except Exception:  # noqa: BLE001 — a fresh or broken file starts empty
        data = {}
    if not isinstance(data, dict):
        data = {}
    data[key] = dest
    os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
    tmp = cfg_path + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, cfg_path)


if __name__ == "__main__":
    sys.exit(main(sys.argv))

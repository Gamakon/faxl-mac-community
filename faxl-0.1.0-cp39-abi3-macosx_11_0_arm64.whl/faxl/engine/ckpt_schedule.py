# Vendored engine module (ckpt_schedule.py) — DO NOT EDIT HERE; edits are overwritten
# by the next engine sync (tools/sync_engine.py --sync mac; the gate runs --check).
"""ckpt_schedule.py — the deterministic checkpoint schedule + prefix hash.

Extracted from faxl_proxy.py (phase 0, plan v1.5) so the simulator, the
lookup regression test, and the lifecycle module can import them WITHOUT
loading a model. faxl_proxy.py imports from here; behavior is unchanged.

GEOMETRIC schedule (AM): the gap between checkpoints MULTIPLIES by
CKPT_RATIO each step, so checkpoints cluster densely near the reused start
and thin out in the changing tail. MUST be deterministic (same positions
every run) or a query's ladder won't align with stored checkpoints.
"""
import os

HB, HM = 1000003, (1 << 61) - 1

CKPT_EVERY = int(os.environ.get("FAXL_CKPT_EVERY", "250"))   # base interval
CKPT_RATIO = float(os.environ.get("FAXL_CKPT_RATIO", "2.0"))  # geometric gap


def prefix_hashes(tokens):
    """h[i] = hash of tokens[:i]; one O(N) pass, ~0.18 µs/token measured.
    NOTE: invertible from consecutive values — hash arrays are TOKEN CONTENT
    (plan v1.5 round-2 change 1) and are never committed."""
    out = [0] * (len(tokens) + 1)
    h = 0
    for i, t in enumerate(tokens):
        h = (h * HB + int(t) + 1) % HM
        out[i + 1] = h
    return out


def ckpt_positions(n_tokens, base=None, ratio=None):
    """Scheduled checkpoint positions for a prompt of n_tokens. `base` and
    `ratio` default to the env-pinned production values; the simulator passes
    explicit values when sweeping schedules."""
    base = CKPT_EVERY if base is None else base
    ratio = CKPT_RATIO if ratio is None else ratio
    pos, step, out = 0, float(base), []
    while True:
        pos += step
        if pos >= n_tokens:
            break
        out.append(int(pos))
        step *= ratio
    return out


def ckpt_set(n_tokens, base=None, ratio=None):
    return set(ckpt_positions(n_tokens, base, ratio))

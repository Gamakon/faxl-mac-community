"""Fork-point checkpointing: stream index, divergence search, and write gates.

Implements docs/plan-fork-point-checkpointing.md rev 5. Separated from
faxl_proxy.py so the logic is unit-testable without loading a model.

Terms (plan §1): a "stream" is one request's full prompt. Hashes are kept at
EVERY position (16 B/token with tokens, persisted content-addressed); blobs are
written only where the ladder PROVES a fork (two real requests diverged there),
subject to the rev-5 gates.

Pre-registered constants (rev 5): FAXL_FORK_TIME_RATIO=5, FAXL_FORK_AMORT=4,
FAXL_FORK_MAX_LIVE_GB=20, kappa EWMA alpha=0.2 init 0.5. Declared here, not
tuned: turn-increment EWMA alpha=0.5 (rev 5 pins the 2x multiplier but not the
EWMA alpha; declared before any run).
"""
import json
import os
import struct
import time

KAPPA_ALPHA = 0.2
KAPPA_INIT = 0.5
INC_EWMA_ALPHA = 0.5
# Extension tolerance (declared 2026-08-16, rev note): a query EXTENDS a stored
# stream if it matches that stream's hashes to within EXT_TOL tokens of the
# stream's end. Chat templates append a generation suffix (~30-40 tokens:
# assistant header / think toggle) to every prompt, so consecutive turns are
# near-extensions, never exact ones. 64 covers every template measured.
EXT_TOL = 64

# Measured per-model blob size curves (flat bytes, bytes per token).
# Nemotron/Granite: least-squares over on-disk data/fork_eval blobs
# (integration/blob_curve_fit.py → docs/schedule-opt/blob-curves.json;
# Nemotron n=16 cpos 250-98,627 residuals ±29 B; Granite n=10 cpos 19-3,750
# residuals ±5 B; both slopes are exactly 16,384 B/tok = 16 KiB/tok).
# Kimi: 6-depth measurement, docs/openclaw-agentic-commenting-result.md.
# UNKNOWN MODELS ARE A HARD ERROR — measure a curve first (plan v1.5
# round-5 change 1: no cross-model fallback, no observed-max fallback).
MODEL_CURVES = (
    ("kimi", 43.4e6, 8.06e3),
    ("nemotron", 143554360.0, 16384.0),
    ("granite", 152827328.0, 16384.0),
    # Pure-KV (fp16 KV regardless of weight quant) — measured by
    # integration/kv_onboard.py 2026-08-18 (docs/schedule-opt/
    # kv-onboard.jsonl): 6-depth fit to 16k, max residual 93 B; slope
    # matches the config-computed value exactly. MORE-SPECIFIC KEYS
    # FIRST — substring matching must never let 0.5b fall into the 7b
    # curve (test_model_curves.py guards this).
    ("qwen2.5-0.5b", 4320.3, 12288.0),
    ("qwen2.5-7b", 5220.1, 57344.0),
)


class UnknownModelCurve(ValueError):
    """No measured blob curve for this model — measure one before gating."""


def _curve(model_name):
    m = (model_name or "").lower()
    for key, flat, slope in MODEL_CURVES:
        if key in m:
            return flat, slope
    raise UnknownModelCurve(
        f"no measured blob curve for model {model_name!r}; run "
        "integration/blob_curve_fit.py against real blobs and add an entry "
        "to MODEL_CURVES (cross-model fallback removed by plan v1.5)")


def blob_bytes_predicted(model_name, pos, observed_max=None):
    """Predicted blob size at checkpoint depth `pos` from the measured curve.
    `observed_max` is accepted for caller compatibility but is never used as
    a fallback; an unmeasured model raises UnknownModelCurve."""
    flat, slope = _curve(model_name)
    return flat + slope * pos


class ForkIndex:
    """Per-position membership index over stored streams + fork bookkeeping.

    - pos_hashes[p] = set of prefix hashes seen at position p (any stream).
      Prefix sharing is monotone in length, so the deepest shared position is
      found by binary search over p with an O(1) set probe at each step.
    - ends[L] = set of full-stream hashes of streams whose length is exactly L
      (extension-vs-divergence test: the query EXTENDS a stored stream iff its
      hash at L equals a stored stream's full hash).
    - chains: extension-chain state for supersession + the turn-increment EWMA.
    - kappa: store-wide continuation EWMA for the divergence gate.
    """

    def __init__(self, streams_dir, state_path):
        self.streams_dir = streams_dir
        self.state_path = state_path
        os.makedirs(streams_dir, exist_ok=True)
        self.pos_hashes = {}
        self.ends = {}
        self.ends_near = {}     # pos -> {hash at pos: full-stream hash} for the
                                # last EXT_TOL positions of every stream
        self.stream_lens = {}   # full-stream hash -> length (dedup)
        self.chains = {}        # chain head hash -> {fork_phash, fork_pos, ewma_inc, length}
        self.kappa = KAPPA_INIT
        self.match_counts = {}  # str(prefix hash at D*) -> arrivals seen
        self._load()

    # ---- persistence -------------------------------------------------------
    def _load(self):
        t0 = time.time()
        n = 0
        for fn in os.listdir(self.streams_dir):
            if not fn.endswith(".bin"):
                continue
            try:
                with open(os.path.join(self.streams_dir, fn), "rb") as f:
                    raw = f.read()
                cnt = struct.unpack_from("<I", raw, 0)[0]
                hashes = struct.unpack_from(f"<{cnt}Q", raw, 4 + 4 * cnt)
                self._index_hashes(hashes)
                n += 1
            except Exception as e:
                print(f"!! fork stream {fn} unreadable ({e}) — skipped", flush=True)
        if os.path.exists(self.state_path):
            try:
                st = json.load(open(self.state_path))
                self.chains = {int(k): v for k, v in st.get("chains", {}).items()}
                self.kappa = st.get("kappa", KAPPA_INIT)
                self.match_counts = st.get("match_counts", {})
            except Exception as e:
                print(f"!! fork state unreadable ({e}) — fresh state", flush=True)
        if n:
            print(f"fork index: {n} streams reloaded in {time.time()-t0:.1f}s "
                  f"({len(self.pos_hashes)} positions)", flush=True)

    def _save_state(self):
        tmp = self.state_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"chains": self.chains, "kappa": self.kappa,
                       "match_counts": self.match_counts}, f)
        os.replace(tmp, self.state_path)

    def _index_hashes(self, hashes):
        # hashes[i] = hash of tokens[:i+1] (position i+1); index 1-based
        # positions. KV plan B.1 [review F1]: the membership value is the
        # OWNING STREAM's full hash (attribution; genuine hash collisions
        # ~2^-61) — `h in pos_hashes[p]` membership is unchanged (dict
        # keys), and pos_hashes[p][h] resolves the stream whose prefix
        # this is, which the trim-candidate search needs. First writer
        # keeps ownership (identical prefix => identical content; the
        # token-file confirm stays the correctness authority). Memory:
        # ~doubles the per-position entry (8 B -> 16 B), stated/accepted.
        L = len(hashes)
        full = hashes[-1] if L else None
        for i, h in enumerate(hashes):
            self.pos_hashes.setdefault(i + 1, {}).setdefault(h, full)
        if L:
            self.ends.setdefault(L, set()).add(full)
            self.stream_lens[full] = L
            for p in range(max(1, L - EXT_TOL), L + 1):
                self.ends_near.setdefault(p, {})[hashes[p - 1]] = full

    def add_stream(self, ids, qhash):
        """Persist this request's stream (tokens + hashes, content-addressed by
        full-prompt hash; identical prompts store once) and index it.
        Returns index_maint_ms."""
        t0 = time.time()
        full = qhash[len(ids)]
        if full not in self.stream_lens:
            path = os.path.join(self.streams_dir, f"{full}.bin")
            if not os.path.exists(path):
                tmp = path + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(struct.pack("<I", len(ids)))
                    f.write(struct.pack(f"<{len(ids)}I", *[t & 0xFFFFFFFF for t in ids]))
                    f.write(struct.pack(f"<{len(ids)}Q", *qhash[1:len(ids) + 1]))
                os.replace(tmp, path)
            self._index_hashes(qhash[1:len(ids) + 1])
        return (time.time() - t0) * 1000

    # ---- discovery ---------------------------------------------------------
    def deepest_shared(self, qhash, qlen):
        """Deepest position D in [1, qlen] where this query's prefix hash is in
        the membership index. 0 if nothing shares. O(log qlen) set probes."""
        if not self.pos_hashes:
            return 0
        lo, hi, best = 1, qlen, 0
        while lo <= hi:
            mid = (lo + hi) // 2
            s = self.pos_hashes.get(mid)
            if s is not None and qhash[mid] in s:
                best = mid
                lo = mid + 1
            else:
                hi = mid - 1
        return best

    def classify(self, qhash, d_star, qlen):
        """('extension', matched_stream_full_hash) if the query matches a stored
        stream to within EXT_TOL of that stream's end (prompt-boundary case —
        templates append a generation suffix, so exact end-matches don't occur
        between turns); else ('divergence', None)."""
        if d_star >= qlen:
            return "extension", None   # query itself is a prefix of a stored stream
        m = self.ends_near.get(d_star, {}).get(qhash[d_star])
        if m is not None and qlen >= self.stream_lens.get(m, qlen + 1):
            # matches a stored stream to within EXT_TOL of its end AND is longer
            # than it: the continuation case. A SHORTER stream that diverges near
            # a stored end is a true branch, not an extension.
            return "extension", m
        return "divergence", None

    # ---- kappa + chains ----------------------------------------------------
    def observe_match(self, d_hash):
        """Update the store-wide continuation EWMA. Operationalization
        (declared): sample=1 iff this shared prefix has been arrived at before
        (n >= 2 for P(n+1|n)); alpha=0.2, init 0.5."""
        key = str(d_hash)
        seen = self.match_counts.get(key, 0)
        sample = 1.0 if seen >= 1 else 0.0
        self.match_counts[key] = seen + 1
        self.kappa = (1 - KAPPA_ALPHA) * self.kappa + KAPPA_ALPHA * sample

    def chain_for(self, d_hash):
        return self.chains.get(int(d_hash)) if isinstance(d_hash, int) else self.chains.get(d_hash)

    def migrate_chain(self, old_head, new_head, increment):
        """Advance a chain's head to the current stream EVERY extension turn
        (forking or not) — heads must track the conversation or supersession
        can never find its ancestor. Updates the turn-increment EWMA. Returns
        the chain entry (carrying the last fork's phash) or None if new."""
        entry = self.chains.pop(int(old_head), None) if old_head is not None else None
        if entry is None:
            entry = {"fork_phash": None, "fork_pos": None,
                     "ewma_inc": increment, "length": None}
        else:
            entry["ewma_inc"] = ((1 - INC_EWMA_ALPHA) * entry["ewma_inc"]
                                 + INC_EWMA_ALPHA * increment)
        self.chains[int(new_head)] = entry
        self._save_state()
        return entry

    def set_chain_fork(self, head, fork_phash, fork_pos):
        """Record a written fork on the (already-migrated) chain; returns the
        SUPERSEDED ancestor fork phash (caller deletes its blob), or None."""
        entry = self.chains.setdefault(int(head), {"fork_phash": None,
                                                   "fork_pos": None,
                                                   "ewma_inc": 1.0,
                                                   "length": None})
        old = entry.get("fork_phash")
        entry["fork_phash"] = fork_phash
        entry["fork_pos"] = fork_pos
        self._save_state()
        return old

    def update_chain(self, old_head, new_head, fork_phash, fork_pos, increment):
        prev = self.chains.pop(int(old_head), None) if old_head is not None else None
        ewma = increment if prev is None else \
            (1 - INC_EWMA_ALPHA) * prev["ewma_inc"] + INC_EWMA_ALPHA * increment
        self.chains[int(new_head)] = {"fork_phash": fork_phash, "fork_pos": fork_pos,
                                      "ewma_inc": ewma, "length": None}
        self._save_state()
        return prev  # caller supersedes prev["fork_phash"] blob if present

    def save(self):
        self._save_state()


# ---- write-cost model (phase 0, plan v1.5) ---------------------------------
# Calibrated from REAL save_prompt_cache timings across the on-disk blob
# ladder (integration/write_cost_bench.py -> docs/schedule-opt/write-cost.json;
# n=78 saves, 148 MB - 1.76 GB): a PER-WRITE overhead plus a per-byte term.
# The old 32 MB fsync'd probe is retired as the gate constant — the probe
# fsyncs, save_prompt_cache does not, and the 2x small-write gap was the
# missing per-write overhead, not a per-byte penalty.
WRITE_COST_INTERCEPT_MS = 27.49
WRITE_COST_MS_PER_GB = 163.0


def _load_write_cost():
    """Refresh the calibrated constants from the committed fit if present."""
    global WRITE_COST_INTERCEPT_MS, WRITE_COST_MS_PER_GB
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "data", "write-cost.json")
    try:
        fit = json.load(open(p))["fits"]["save"]
        WRITE_COST_INTERCEPT_MS = float(fit["intercept_ms"])
        WRITE_COST_MS_PER_GB = float(fit["slope_ms_per_gb"])
    except Exception:
        pass  # keep the committed defaults above (same calibration)


_load_write_cost()


def write_cost_ms(blob_bytes):
    """Predicted save_prompt_cache wall for a blob of this size."""
    return WRITE_COST_INTERCEPT_MS + (blob_bytes / 1e9) * WRITE_COST_MS_PER_GB


# ---- gates (rev 5) ---------------------------------------------------------
def extension_gate(repaid_tail, ewma_inc, prefill_tps, blob_bytes, nvme_bps,
                   time_ratio):
    """Chain steady-state WALL-TIME gate: store iff predicted prefill seconds
    saved >= ratio x predicted blob-write seconds. Write cost comes from the
    calibrated intercept+slope model (phase 0); `nvme_bps` is retained in the
    signature for caller compatibility but no longer used."""
    saved_ms = max(0.0, (repaid_tail - 2.0 * ewma_inc)) / max(prefill_tps, 1e-9) * 1000
    write_ms = write_cost_ms(blob_bytes)
    return saved_ms >= time_ratio * write_ms, saved_ms, write_ms


def divergence_gate(blob_bytes, kappa, marginal_tokens, slope_bytes_per_tok,
                    amort):
    """Amortized-bytes gate: store iff the blob is expected to pay for itself
    within the amortization horizon."""
    kappa = min(max(kappa, 0.0), 0.999)
    expected_extra = kappa / (1.0 - kappa)
    budget = expected_extra * marginal_tokens * slope_bytes_per_tok * amort
    return blob_bytes <= budget, expected_extra, budget


def model_slope(model_name):
    """Marginal blob bytes per token for a MEASURED model; unmeasured models
    raise UnknownModelCurve (no 16.0e3 default — plan v1.5)."""
    _flat, slope = _curve(model_name)
    return slope

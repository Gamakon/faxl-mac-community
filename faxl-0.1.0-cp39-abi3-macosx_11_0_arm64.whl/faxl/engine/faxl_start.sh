#!/bin/bash
# faxl_start.sh — bring faxl up on the backend and model in ~/.faxl/config.json.
#
#   mlx:  prompt -> faxl.localhost:8767 -> mlx (executes, in this same process)
#
#   exo:  prompt -> faxl.localhost:8767 -> exo :52415 (executes)
#                        ^                  |
#                        |   R1: give me the prefix for these tokens
#                        +------------------+   R2: here is the state you missed
#                           faxl prefill server :52440
#
#   ./faxl_start.sh [model]
#
# ONE LAUNCHER. There used to be two -- faxl_up.sh (mlx) and faxl_exo_up.sh
# (exo) -- and the backend was whichever one you ran, with the model in an
# env var. That is not something support can reason about once there are
# customers: "which script did you run, and what was exported in that shell"
# has no answer after the fact. The choice now lives in config.json (the
# console writes it, `python -m faxl.engine.faxl_config --show` reads it back
# with where each value came from), and this script starts whatever it says.
# FAXL_BACKEND / FAXL_MODEL still override, as they do in the proxy.
#
# [model] is written to the config FIRST, so the choice survives the next
# restart -- a model named on the command line is a decision, not a one-off.
#
# faxl_up.sh and faxl_exo_up.sh are kept as thin wrappers (set the backend,
# exec this), so existing instructions and muscle memory keep working.
set -uo pipefail

# THE INTERPRETER IS PASSED IN, NOT GUESSED. The scripts used to hardcode
# "$EXO_SRC/.venv/bin/python" -- a developer checkout in one person's home
# directory, which does not exist after `pip install faxl`. The console runs
# in the venv that holds faxl (and exo), so it knows the right interpreter and
# passes it as FAXL_PYTHON=sys.executable. A bare `python3` from PATH is the
# last resort and will be the wrong one often enough to say so loudly.
VENV="${FAXL_PYTHON:-$(command -v python3)}"
# DETACH THE PROXY INTO ITS OWN SESSION so it survives the terminal closing and
# cannot be reaped by whatever supervised the launch (on 2026-10-02 one was,
# after 30 minutes, mid-use). Linux has setsid; macOS does not ship it, and
# there the proxy is detached by nohup plus start_new_session on the caller's
# side. Empty is a valid value -- the command simply runs without a prefix.
_SETSID="$(command -v setsid || true)"
LOG_DIR="${FAXL_HOME:-$HOME/.faxl}/logs"
mkdir -p "$LOG_DIR"
PROXY_LOG="$LOG_DIR/proxy.log"
EXO_LOG="$LOG_DIR/exo.log"
# 8767 is the PUBLIC INTERFACE: clients carry it in their config (openclaw
# providers, run_leadgen, the photo tagger) and cannot discover an
# alternative. It is a contract, not a convenience.
PROXY_PORT="${FAXL_PORT:-8767}"

say() { echo "$(date -u '+%H:%M:%S') $*"; }
cfg() { "$VENV" -m faxl.engine.faxl_config "$@"; }

[ -n "$VENV" ] && [ -x "$VENV" ] || {
  say "FATAL: no interpreter at ${VENV:-<none>} -- set FAXL_PYTHON"; exit 1; }
# A BARE python3 FROM PATH IS USUALLY THE WRONG ONE. On the machine this was
# written on it resolves to /opt/anaconda3/bin/python3, which has no faxl.
# Name it now, not as a confusing failure three steps later.
if ! "$VENV" -c 'import faxl' >/dev/null 2>&1; then
  say "FATAL: $VENV cannot import faxl. Pass FAXL_PYTHON=<interpreter>."
  exit 1
fi

# ---- what to start: the config, after the optional model argument.
if [ -n "${1:-}" ]; then
  cfg --set "model=$1" >/dev/null || {
    say "FATAL: $1 is not a model faxl can use (org/name, or an absolute path)"
    exit 1; }
  # The argument is the more recent statement. A FAXL_MODEL left exported in
  # this shell would otherwise override the value just written, silently.
  if [ -n "${FAXL_MODEL:-}" ] && [ "$FAXL_MODEL" != "$1" ]; then
    say "note: FAXL_MODEL=$FAXL_MODEL ignored -- the model argument wins"
  fi
  unset FAXL_MODEL
fi
BACKEND="$(cfg --get backend)" || { say "FATAL: could not read the faxl config"; exit 1; }
MODEL="$(cfg --get model)" || { say "FATAL: could not read the faxl config"; exit 1; }
say "config: $(cfg --get path)"
say "backend=$BACKEND ($(cfg --source backend)) model=$MODEL ($(cfg --source model))"

# ---- NOTHING IS DOWNLOADED WITHOUT BEING ASKED (2026-09-21 / 2026-09-22).
# A switch left a 130 GB cluster model configured on mlx; this script started
# the proxy, mlx_lm.load began downloading it onto one Mac, and the console
# was dark for the duration. The lesson is the SILENT download, not that a
# person may not run a big model: faxl recommends, the person decides.
#
# So faxl_config --fits no longer refuses a fresh install. No weights here is
# the normal state of a new install ("batteries not included") -- the proxy
# comes up serving the console with no model, the welcome page shows what
# this Mac should run and what each option costs, and the person picks. The
# only exit 3 left is a model that is configured AND does not fit AND was
# never confirmed; the console lifts that with a confirm, and
# FAXL_ALLOW_DOWNLOAD=1 lifts it for a developer.
if [ "$BACKEND" = "mlx" ]; then
  FIT_MSG="$(cfg --fits 2>&1 >/dev/null)"
  FIT_RC=$?
  if [ "$FIT_RC" -ne 0 ]; then
    # A RESTART ALWAYS COMES BACK. (AM, 2026-09-22: "we want the RESTART to
    # ALWAYS go live, with errors on the UI about things to fix".)
    #
    # This used to exit 3 and start NOTHING, which is the worst outcome
    # available: the console had already killed the running proxy, so a model
    # that did not fit -- or that the fit check merely BELIEVED did not fit,
    # which is what a stale safetensors index caused this morning -- left the
    # machine with no console at all and the reason in a log file.
    #
    # The proxy serves the console perfectly well with no model loaded: it
    # answers /v1/chat/completions with a 503 naming the problem, and the
    # welcome page shows what this Mac can run. So start it that way and put
    # the fault where the person is looking, instead of refusing to start.
    say "!! ${FIT_MSG:-the fit check failed (exit $FIT_RC)}"
    say "   starting the console anyway, with NO MODEL loaded — open it and"
    say "   pick one; it shows what fits this Mac and what each costs."
    # The proxy already degrades correctly on its own: it resolves the model,
    # finds nothing loadable, says so loudly and serves the console with
    # `model = None`, answering /v1/chat/completions 503. Nothing more to set
    # -- the only thing that had to change was this script refusing to run it.
  fi
  [ -n "$FIT_MSG" ] && say "$FIT_MSG"
fi

# DO NOT STACK PROXIES, AND DO NOT STACK MODELS.
#
# The proxy holds the WHOLE model resident: Qwen3.8-Flash-Next measured 80.8 GB
# on a 137 GB Mac whose Metal working set is 115.4 GB. Two copies is 160 GB and
# the machine dies -- it did, on 2026-10-02, taking a terminal session and its
# work with it. So this is not a tidiness check; it is the thing standing
# between a customer and a hard reboot.
#
# The port check alone was not enough, and all three gaps below were hit on the
# same afternoon:
#   * a proxy on a DIFFERENT port holds a second copy and binds nothing here;
#   * a proxy still SHUTTING DOWN has released its port but not its memory, so
#     `kill; sleep 2; start` begins mapping 80 GB while 80 GB is still resident;
#   * a side script that called mlx_vlm.load() (a probe, a notebook) is a
#     second copy by definition and touches no port at all.
#
# CHECKED TWICE, A SECOND APART. A process mid-exit appears in the first sample
# and not the second; a process mid-start appears in the second and not the
# first. One sample cannot tell those apart, and guessing wrong is what crashes
# the machine.
_proxy_pids() { pgrep -f '[f]axl.engine.faxl_proxy' 2>/dev/null | tr '\n' ' '; }
_port_pid()   { lsof -tiTCP:"$PROXY_PORT" -sTCP:LISTEN 2>/dev/null | head -1; }

_PIDS_A="$(_proxy_pids)"; _PORT_A="$(_port_pid)"
sleep 1
_PIDS_B="$(_proxy_pids)"; _PORT_B="$(_port_pid)"

if [ -n "${_PIDS_A}${_PIDS_B}${_PORT_A}${_PORT_B}" ]; then
  say "FATAL: faxl is already running (or still shutting down)."
  [ -n "${_PIDS_A}${_PIDS_B}" ] && say "  proxy pids: ${_PIDS_A}${_PIDS_B}"
  [ -n "${_PORT_A}${_PORT_B}" ] && say "  port $PROXY_PORT held by pid ${_PORT_A:-$_PORT_B}"
  say "  Starting a second copy would need roughly twice the model's memory."
  say "  Stop the running one first, and WAIT for it to exit:"
  say "    kill \$(cat $LOG_DIR/proxy.pid) && while pgrep -f '[f]axl.engine.faxl_proxy' >/dev/null; do sleep 1; done"
  exit 1
fi

# ANY process holding model-sized memory, proxy or not. 20 GB is well above
# anything that is not a model and well below the smallest model worth caching.
# EXCLUDES faxl's own proxies, which the process check above already covers by
# name. Without that exclusion this fired on the RUNNING PROXY -- the very
# thing the port and process checks exist to report precisely -- so a
# legitimate restart was refused with "another process is holding model-sized
# memory", and every test driving this launcher while a proxy was up failed.
# Measured: 9 suite failures, all from the launcher refusing to start.
_BIG="$(ps -axo pid=,rss=,command= 2>/dev/null \
        | grep -v 'faxl.engine.faxl_proxy' \
        | awk '$2 > 20000000 && $3 ~ /[Pp]ython/ {printf "  pid %s  %.1f GB  %s\n", $1, $2/1048576, $3}')"
if [ -n "$_BIG" ]; then
  say "FATAL: another process is holding model-sized memory:"
  printf '%s\n' "$_BIG"
  say "  That is probably a script that loaded the model directly. Starting the"
  say "  proxy alongside it puts two copies of the weights in RAM. Close it, or"
  say "  test against the running proxy over HTTP instead."
  exit 1
fi

# ============================================================== mlx
start_mlx() {
  say "starting faxl (backend=mlx, model in-process)"
  # No FAXL_BACKEND / FAXL_MODEL on the command line: the proxy reads the
  # same config this script just read, and its boot line then says "config"
  # rather than "env" -- which is the truth.
  # A NEW SESSION, so the proxy is not a child of this shell and survives the
  # terminal closing. nohup alone leaves it owned by whatever launched it -- on
  # 2026-10-02 a supervisor reaped a nohup'd proxy after 30 minutes and killed
  # it mid-use while the console was being used.
  # macOS HAS NO setsid BINARY (`setsid: command not found`, measured), so the
  # new session is created by the interpreter that is about to exec the proxy:
  # os.setsid() then os.execv(), which leaves no wrapper process behind and
  # behaves identically on Linux.
  # The new session comes from `setsid` where it exists (Linux) and from a
  # python one-liner where it does not (macOS has no setsid binary, measured).
  # Either way the proxy is started as `-m faxl.engine.faxl_proxy`: wrapping it
  # in `python -c ... execv(...)` ALSO works, but it changes what the process
  # command line says, and the suite pins that string because it is how a test
  # (and an operator reading ps) identifies the proxy. Keep the visible form.
  FAXL_PORT="$PROXY_PORT" \
    nohup $_SETSID "$VENV" -m faxl.engine.faxl_proxy \
      >>"$PROXY_LOG" 2>&1 < /dev/null &
  PROXY_PID=$!
  echo "$PROXY_PID" > "$LOG_DIR/proxy.pid"
  say "proxy pid $PROXY_PID -> $PROXY_LOG"

  # WAIT FOR IT TO ANSWER, AND SAY SO IF IT DOES NOT. A vision model is several
  # GB and takes tens of seconds to load; exiting "UP" before it answers is how
  # a restart reports success over a process that is about to die.
  for _ in $(seq 1 180); do
    if curl -fsS -o /dev/null --max-time 2 \
         "http://127.0.0.1:$PROXY_PORT/console" 2>/dev/null; then
      say "UP."
      echo
      echo "  proxy    http://faxl.localhost:$PROXY_PORT/v1   (any api key)"
      echo "  console  http://faxl.localhost:$PROXY_PORT/console"
      echo "  log      $PROXY_LOG"
      exit 0
    fi
    kill -0 "$PROXY_PID" 2>/dev/null || {
      say "FATAL: the proxy exited while starting. Last lines:"
      tail -20 "$PROXY_LOG"
      exit 1
    }
    sleep 1
  done
  say "FATAL: the proxy did not answer on :$PROXY_PORT within 180s."
  tail -20 "$PROXY_LOG"
  exit 1
}

# ============================================================== exo
start_exo() {
  # exo is imported as an installed package; EXO_SRC only matters for driving
  # a working copy, and `python -m exo` needs no particular cwd.
  local EXO_SRC="${EXO_SRC:-}"
  # 52415 is exo's API; the prefill port (52440) is INTERNAL PLUMBING: exo's
  # runner dials it to ask faxl for a prefix. faxl binds it and publishes what
  # it bound to ~/.faxl/prefill-endpoint.json; exo reads that. Both come from
  # the config's "exo" object, which the proxy reads too -- one value, not two.
  local EXO_ENDPOINT PREFILL_PORT HUB
  EXO_ENDPOINT="$(cfg --get exo.endpoint)" || exit 1
  PREFILL_PORT="$(cfg --get exo.prefill_port)" || exit 1

  # exo knows models by HuggingFace id. A path left in the config by an mlx
  # run is named if it can be (the proxy does the same); if it cannot, stop
  # here with the fix, not in the proxy log with "Repo id must be in the form".
  HUB="$(cfg --hub-id "$MODEL")"
  case "$HUB" in
    /*) say "FATAL: exo needs a HuggingFace id (org/name); the model is a path:"
        say "       $MODEL"
        say "       run: $(dirname "$0")/faxl_exo_up.sh <org/name>"
        exit 1 ;;
  esac

  # NEVER STACK INSTANCES. A second exo leaves the first holding tens of GB;
  # a few rounds of that exhausted RAM and kernel-panicked this machine.
  if pgrep -f -- "-m exo" >/dev/null 2>&1 || pgrep -f "exo.worker.runner" >/dev/null 2>&1; then
    say "FATAL: exo is already running. Stop it first:  bash $(dirname "$0")/exo_stop.sh"
    exit 1
  fi
  "$VENV" -c 'import exo, faxl' >/dev/null 2>&1 || {
    say "FATAL: $VENV cannot import exo and faxl -- set FAXL_PYTHON to the"
    say "       interpreter they are installed in."
    exit 1; }

  # ---- exo: its own cache OFF, and pointed at faxl's prefill server.
  #
  # EXO_PREFIX_CACHE=0 is what hands cache ownership to faxl. exo's in-RAM
  # cache dies with the runner processes on any topology event, which is
  # precisely when a cluster most needs one.
  #
  # EXO_REMOTE_PREFILL=strict means "no silent fallback": a cache that cannot
  # answer raises rather than quietly becoming a slow local prefill. It does
  # NOT raise on a short serve — a prefix-ladder hit is short by construction.
  say "starting exo ($HUB)"
  (
    if [ -n "$EXO_SRC" ]; then cd "$EXO_SRC" || exit 1; fi
    # NO FAXL_PREFILL_ENDPOINT here. faxl binds the socket and publishes what
    # it bound; passing it here too is the duplicate configuration that let
    # the two drift apart.
    EXO_PREFIX_CACHE=0 \
    EXO_REMOTE_PREFILL=strict \
    nohup "$VENV" -m exo >"$EXO_LOG" 2>&1 &
    echo $! > "$LOG_DIR/exo.pid"
  )
  say "exo pid $(cat "$LOG_DIR/exo.pid" 2>/dev/null) -> $EXO_LOG"

  for _ in $(seq 1 60); do
    curl -s -m 2 "$EXO_ENDPOINT/v1/models" >/dev/null 2>&1 && break
    sleep 1
  done
  if ! curl -s -m 2 "$EXO_ENDPOINT/v1/models" >/dev/null 2>&1; then
    say "FATAL: exo did not come up in 60s — see $EXO_LOG"
    exit 1
  fi
  say "exo answering on $EXO_ENDPOINT"

  # ---- faxl: the front door. Loads the TOKENIZER only on this backend; the
  # weights live on exo, and for a 700GB model a second copy here is not an
  # inefficiency but a contradiction.
  say "starting the faxl proxy (backend=exo, tokenizer only)"
  (
    # EXO_SRC must be EXPORTED, not written as a conditional assignment
    # prefix: bash decides what is an assignment before expansion, so
    # ${EXO_SRC:+EXO_SRC="$EXO_SRC/src"} expands into the command name and
    # the launch dies with "command not found".
    if [ -n "$EXO_SRC" ]; then
      cd "$EXO_SRC" || exit 1
      export EXO_SRC="$EXO_SRC/src"
    fi
    # The exo settings (endpoint, prefill port, trust_remote_code) are NOT
    # passed as env: the proxy reads them from the same config, so there is
    # one place they are set. FAXL_EXO_ENDPOINT and friends still override.
    FAXL_PORT="$PROXY_PORT" \
    nohup $_SETSID "$VENV" -m faxl.engine.faxl_proxy \
      >"$PROXY_LOG" 2>&1 < /dev/null &
    echo $! > "$LOG_DIR/proxy.pid"
  )
  say "proxy pid $(cat "$LOG_DIR/proxy.pid" 2>/dev/null) -> $PROXY_LOG"

  for _ in $(seq 1 90); do
    curl -s -m 2 "http://127.0.0.1:$PROXY_PORT/metrics" >/dev/null 2>&1 && break
    sleep 1
  done
  if ! curl -s -m 2 "http://127.0.0.1:$PROXY_PORT/metrics" >/dev/null 2>&1; then
    say "FATAL: the proxy did not come up — see $PROXY_LOG"
    tail -20 "$PROXY_LOG"
    exit 1
  fi

  say "UP."
  echo
  echo "  proxy    http://faxl.localhost:$PROXY_PORT/v1   (any api key)"
  echo "  console  http://faxl.localhost:$PROXY_PORT/console"
  echo "  metrics  http://faxl.localhost:$PROXY_PORT/metrics"
  echo "  exo      $EXO_ENDPOINT"
  echo "  prefill  127.0.0.1:$PREFILL_PORT   (exo asks here; faxl answers)"
  echo
  echo "  logs     $PROXY_LOG"
  echo "           $EXO_LOG"
  echo
  echo "  stop     bash $(dirname "$0")/exo_stop.sh && kill \$(cat $LOG_DIR/proxy.pid)"
  exit 0
}

case "$BACKEND" in
  exo) start_exo ;;
  mlx) start_mlx ;;
  # vLLM is Linux/NVIDIA. Its launcher branch, vllm_stop.sh and their tests
  # moved to the Linux wheel (step 3 of the Linux wheel plan); this Mac wheel
  # names where it went rather than falling through to "unknown backend".
  vllm) say "FATAL: vllm runs on the Linux wheel (faxl-nvidia-dev/crates/faxl-py);"
        say "       this is the Mac wheel (mlx, exo). nothing was started."
        exit 1 ;;
  *)   say "FATAL: unknown backend $BACKEND"; exit 1 ;;
esac

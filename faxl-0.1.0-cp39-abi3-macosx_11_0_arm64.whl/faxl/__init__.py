"""faxl — prefill cache for local LLM inference on Apple silicon.

Copyright Gamakon Ltd. Distributed under the PolyForm Noncommercial License
1.0.0 (see LICENSE.md in this distribution); commercial licences are available
from Gamakon Ltd (andrew@gamakon.ai).

A cache hit means a prompt prefix has been seen before, so its prefill is not
recomputed: the model resumes from the stored state and prefills only the tail.
A hit requires an exact prefix match.

    import faxl
    faxl.set_licence(open("~/.faxl-licence").read())   # required first
    idx = faxl.ExactIndex()
    h = faxl.prefix_hashes(token_ids)
    for pos in faxl.ckpt_positions(len(token_ids)):   # deepest first
        got = idx.lookup(h[pos], token_ids[:pos])
        if got:
            blob, cpos = got
            break
"""
from ._faxl import (ExactIndex, ckpt_positions, high_water, licence_status,
                    prefix_hashes, probe_key, seeds, set_high_water,
                    set_licence, __version__)

__all__ = ["ExactIndex", "ckpt_positions", "high_water", "licence_status",
           "prefix_hashes", "probe_key", "seeds", "set_high_water",
           "set_licence", "__version__"]

# faxl — Quickstart

faxl is a prefill cache for local LLM inference on Apple silicon. When a prompt
prefix has been seen before, that prefill is not recomputed: the model resumes
from stored state and prefills only the tail.

Requires: Apple silicon (M-series), macOS 11+, Python 3.12 (the UltraDim wheel is cp312).

## 1. Install

```sh
pip install faxl-0.1.0-cp39-abi3-macosx_11_0_arm64.whl
pip install UltraDim-<version>-cp312-cp312-macosx_11_0_arm64.whl
pip install mlx mlx-lm flask
```

Both wheels are supplied by Gamakon; neither is on PyPI.

## 2. Install your licence key

Save the key file we sent you as `~/.faxl-licence` (a different path works via
`FAXL_LICENCE`). Leading `#` comment lines are ignored.

## 3. Run

```sh
export FAXL_BLOBS=~/faxl-store          # NOT under /tmp — this is your cache
python -m faxl.engine.faxl_config --set backend=mlx \
    --set model=mlx-community/Qwen3-VL-4B-Instruct-4bit
faxl-proxy                              # serves on :8080
```

The backend and the model are saved in `~/.faxl/config.json`, so they survive a
restart and the console can change them. `python -m faxl.engine.faxl_config --show`
prints what the next start will use and where each value came from (`env`,
`config` or `default`). `FAXL_BACKEND` / `FAXL_MODEL` in the environment still
override the file — handy for a one-off, but while one is set the console cannot
switch that setting.

**The model must fit.** Every default faxl ships is under 6 GB, so it runs on
any modern Mac. Anything else must already be on this Mac (`hf download
<org/name>`) — faxl never downloads a model as a side effect of starting or
switching — and must fit in 70% of its RAM (`fit_ratio` in config.json, or
`FAXL_FIT_RATIO`). `python -m faxl.engine.faxl_config --fits` checks the
configured model (exit 0, or 3 with the reason); `FAXL_ALLOW_DOWNLOAD=1` lets
the proxy fetch a model that is not here. Each backend remembers its own model,
so switching between this Mac and an exo cluster never carries a cluster-sized
model onto the Mac.

On startup you should see:

```
[faxl] licensed to <you>; 180 days remaining
```

## 4. Point your client at it

Any OpenAI-compatible client, any API key:

```python
from openai import OpenAI
c = OpenAI(base_url="http://localhost:8080/v1", api_key="unused")
c.chat.completions.create(model="faxl", messages=[{"role":"user","content":"hi"}])
```

## Checking it works

```sh
curl -s localhost:8080/health | python3 -m json.tool
```

`licence` shows your customer name, expiry and days remaining. `library_size`
grows as checkpoints accumulate.

**The cache helps when prompts share long prefixes** — a fixed system prompt,
a RAG preamble, document Q&A, an agent loop, few-shot headers. Prompts with
nothing in common will not hit, and you will see no speedup.

## When the licence lapses

The proxy **keeps serving**. The cache tier switches off, so every prefill runs
cold and first-token latency returns to uncached speed. You will see one line:

```
[faxl] LICENCE LAPSED (customer <you>, expired ...) -- cache tier DISABLED ...
```

Nothing is deleted; installing a renewed key restores hits from your existing
store. Contact andrew@gamakon.ai to renew.

## Settings

| Variable | Default | Meaning |
|---|---|---|
| `FAXL_LICENCE` | `~/.faxl-licence` | licence key file |
| `FAXL_BLOBS` | `/tmp/faxl_proxy_blobs` | cache store — **set this**, `/tmp` is volatile |
| `FAXL_MODEL` | config.json `models.<backend>`, else Qwen3-VL-4B-Instruct-4bit | overrides the saved model (org/name or an absolute path) |
| `FAXL_FIT_RATIO` | config.json `fit_ratio`, else `0.70` | share of RAM a model may take |
| `FAXL_ALLOW_DOWNLOAD` | unset | `1` lets the proxy download a model that is not on this Mac |
| `FAXL_BACKEND` | config.json `backend`, else `mlx` | overrides the saved backend (`mlx` or `exo`) |
| `FAXL_NOCACHE` | `0` | `1` bypasses the cache (A/B comparison) |
| `FAXL_CKPT_EVERY` | `250` | base checkpoint interval, tokens |

Changing `FAXL_WIDTH`, `FAXL_WIRING`, `FAXL_K` or `FAXL_SEEDS` **invalidates an
existing store** — they define the key namespace. Don't change them on a store
you want to keep.

## Support

andrew@gamakon.ai

faxl is distributed under the PolyForm Noncommercial License 1.0.0 — see LICENSE.md. Commercial licences: andrew@gamakon.ai. UltraDim is proprietary, licensed for use with faxl only.

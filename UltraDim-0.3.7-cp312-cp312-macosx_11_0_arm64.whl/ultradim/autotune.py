#!/usr/bin/env python3
"""UltraDim auto-tuner — point it at a dataset, it finds a configuration that
clears the recall gate.

This is the companion tool to docs/UltraDim_Tuning_Guide.md. It embodies the
guide's discipline so you do not have to run it by hand: it samples your data,
derives the sparsity cap from the data (never a default), and sweeps the levers
that actually change recall ON THIS BUILD, in cost order.

What actually moves recall on this build (verified against the engine source):
  * `active_seeds` — how many of the family's seeds vote on each query. This is
    the ONE retrieval lever MeasureRecall forwards to the search
    (`ultradimdb/src/template_ops.rs:1656`), and it is FREE to sweep: build the
    family once at the largest seed count, then vote over a subset per request.
  * `projection_dim` — the width of the projected key. Changing it needs a fresh
    family (frozen in the CSR header), so it is the expensive axis, swept last.

What does NOT move recall on this build — and why the earlier version of this
tuner was wrong: MeasureRecall accepts `top_m` and `hnsw_ef`, echoes them in its
response and log line, but NEVER forwards them to the search. On `use_template`
(the only serving path on the clean build) the walk/beam knobs are hardcoded to
None (`template_ops.rs:1648-1662`). Sweeping `top_m`/`hnsw_ef` through
MeasureRecall sweeps dead fields. This tuner therefore sweeps `active_seeds`, not
those. (The serving-time knobs `walk_ef`/`beam_ef`/`take_per_seed` DO reach the
search on TrellisTemplateSearch, but MeasureRecall does not expose them; a CR to
forward them through MeasureRecall is separate from this tool.)

It drives the embedded wheel in-process (`db.call_json`) — the same 202-RPC
surface as the gRPC server; nothing here needs a running server.

Native RPCs used (all measured by the engine, no NumPy on the recall path):
  CreateUltradimV23Collection -> UpsertUltradimV23Points ->
  BuildUltradimV23TrellisIndex (make-searchable) -> CreateSparseOracles (once
  per family) -> MeasureRecall (per active_seeds config).

Usage:
    from tools.ultradim_autotune import autotune, SparseRow
    rows = [SparseRow(indices=[...], values=[...]), ...]   # a SAMPLE of your data
    result = autotune(db, rows, gate=0.99)
    print(result.best)          # the winning config, or None if the gate is unreachable
    print(result.sweep)         # every config tried, with its recall

`db` is an opened `ultradim.UltraDim(path)`.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any, Callable


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------
@dataclass
class SparseRow:
    """One sparse input row: strictly-ascending unique indices, L2-normalised
    values. (The engine rejects a row whose squared norm is off by >1e-4, so
    normalise before you pass rows in.)"""
    indices: list[int]
    values: list[float]


@dataclass
class Config:
    """A candidate configuration. `projection_dim` forces a rebuild; the count of
    active seeds is swept per request against one oracle."""
    # Projection (rebuild-required):
    projection_dim: int
    # Retrieval (per-request against one family/oracle):
    active_seeds: list[int]
    # Fixed at family creation, carried for the record:
    max_nnz_per_row: int
    k: int

    def label(self) -> str:
        return (f"proj={self.projection_dim} active_seeds={len(self.active_seeds)} "
                f"nnz={self.max_nnz_per_row} k={self.k}")


@dataclass
class Trial:
    config: Config
    recall: float
    note: str = ""


@dataclass
class Result:
    best: Config | None
    best_recall: float
    gate: float
    sweep: list[Trial] = field(default_factory=list)
    derived_max_nnz: int = 0
    verdict: str = ""


# --------------------------------------------------------------------------
# The sweep grids (cost order: free active_seeds first, then rebuild projection)
# --------------------------------------------------------------------------
# active_seeds counts to vote over — swept for free against one oracle. Each
# family is built at the MAX of this list; smaller counts vote over a prefix.
ACTIVE_SEED_COUNTS = [4, 8, 16]
# Projection widths — each is a fresh family + oracle. This is the expensive axis.
PROJECTION_DIM = [2048, 4096]

# A fixed seed pool the tuner draws from (deterministic, so a rerun is
# reproducible; the values themselves are arbitrary distinct u64s).
_SEED_POOL = [101, 202, 303, 404, 505, 606, 707, 808,
              909, 111, 222, 333, 444, 555, 666, 777]


def _seeds(n: int) -> list[int]:
    if n > len(_SEED_POOL):
        raise ValueError(f"seed pool has {len(_SEED_POOL)} entries, asked for {n}")
    return _SEED_POOL[:n]


# --------------------------------------------------------------------------
# Deriving the sparsity cap FROM THE DATA (never a default)
# --------------------------------------------------------------------------
def derive_max_nnz(rows: list[SparseRow]) -> int:
    """ceil(1.10 * observed_max_nnz) — the repository's own rule. The 10% headroom
    absorbs a slightly denser row appearing later; the cap REJECTS an over-dense
    row (it does not truncate), so under-setting it would throw real data away."""
    observed_max = max((len(r.indices) for r in rows), default=0)
    if observed_max == 0:
        raise ValueError("no non-zeros in the sample: cannot derive max_nnz")
    return math.ceil(1.10 * observed_max)


def _source_dim(rows: list[SparseRow]) -> int:
    """D_raw = one past the largest index seen. This is the KEY width, the width
    the projection projects FROM — not any upstream reservoir/ESN dimension."""
    return max((max(r.indices) for r in rows if r.indices), default=-1) + 1


# --------------------------------------------------------------------------
# The engine calls (embedded wheel, call_json)
# --------------------------------------------------------------------------
def _rpc(db: Any, name: str, fields: dict[str, Any]) -> dict[str, Any]:
    return json.loads(db.call_json(name, json.dumps(fields)))


def _build_family(db: Any, name: str, rows: list[SparseRow], projection_dim: int,
                  seeds: list[int], max_nnz: int, source_dim: int) -> None:
    """Create + upsert + make-searchable one family at the given projection width
    and seed set (the FULL seed set — subsets are chosen per query later)."""
    _rpc(db, "CreateUltradimV23Collection", {
        "name": name,
        "source_dim": source_dim,
        "projection_dim": projection_dim,
        "seeds": seeds,
        "max_nnz_per_row": max_nnz,
        "sparse_substrate": True,
    })
    # Upsert in batches of 1000 (the universal GPU batch size).
    for start in range(0, len(rows), 1000):
        batch = rows[start:start + 1000]
        _rpc(db, "UpsertUltradimV23Points", {
            "name": name,
            "batch": {
                "row_ids": list(range(start, start + len(batch))),
                "sparse_vectors": [
                    {"indices": r.indices, "values": r.values} for r in batch
                ],
            },
        })
    # Make searchable (settle) — the graph and oracle both need a resident engine.
    _rpc(db, "BuildUltradimV23TrellisIndex", {"name": name})


def _build_oracle(db: Any, name: str, query_ids: list[int], k: int) -> str:
    """Exact brute-force top-k for the held-out queries. Built ONCE per family;
    every active_seeds config re-measures against it."""
    resp = _rpc(db, "CreateSparseOracles", {
        "name": name,
        "query_ids": query_ids,
        "top_k": k,
    })
    path = resp.get("artifact_path")
    if not path:
        raise RuntimeError(f"CreateSparseOracles returned no artifact_path: {resp}")
    return path


def _measure(db: Any, name: str, oracle_path: str, cfg: Config) -> float:
    """recall_at_k for one active_seeds config against the family's oracle.

    `exclude_self` MUST be True: the query row is in the index, so without it the
    row matches itself at rank 1 and every recall@10 pins to exactly 0.9 (self
    takes one of ten returned slots while the oracle excludes it). We send ONLY
    the live levers — `active_seeds`, `exclude_self`, `k`. `top_m`/`hnsw_ef` are
    not forwarded to the search on this build (`template_ops.rs:1648-1662`), so
    sending them would be sending dead fields."""
    resp = _rpc(db, "MeasureRecall", {
        "name": name,
        "oracle_path": oracle_path,
        "active_seeds": cfg.active_seeds,
        "k": cfg.k,
        "use_template": True,
        "exclude_self": True,
    })
    return float(resp.get("recall_at_k", -1.0))


# --------------------------------------------------------------------------
# The tuner
# --------------------------------------------------------------------------
def autotune(
    db: Any,
    rows: list[SparseRow],
    gate: float = 0.99,
    k: int = 10,
    n_queries: int = 200,
    family_prefix: str = "autotune",
    log: Callable[[str], None] = print,
) -> Result:
    """Find a configuration whose measured recall@k clears `gate`.

    Strategy (docs/UltraDim_Tuning_Guide.md §3): for each projection width, build
    ONE family at the largest seed count and sweep `active_seeds` (4 / 8 / 16) for
    free against a single oracle — more seeds is the highest-leverage recall lever
    and needs no rebuild. Stop at the first config that clears the gate. If none
    do at the current width, rebuild at the next width up. If none do at any
    width, report the best found and every trial — a limit claimed WITHOUT this
    sweep is an unfinished experiment.

    Projection is swept from the SMALLEST width up, so the cheapest adequate
    configuration wins rather than the largest.
    """
    if len(rows) < n_queries + 10:
        raise ValueError(
            f"sample too small: {len(rows)} rows, need > {n_queries + 10} to hold "
            f"out {n_queries} queries. Pass a larger dataset sample."
        )
    source_dim = _source_dim(rows)
    max_nnz = derive_max_nnz(rows)
    max_seeds = max(ACTIVE_SEED_COUNTS)
    full_seeds = _seeds(max_seeds)
    query_ids = list(range(n_queries))  # first n rows are the held-out queries
    log(f"[autotune] {len(rows)} rows, source_dim(D_raw)={source_dim}, "
        f"derived max_nnz={max_nnz}, gate={gate}, k={k}")

    sweep: list[Trial] = []
    best: Config | None = None
    best_recall = -1.0

    fam_n = 0
    # Projection sweep: smallest width first (cheapest adequate config wins).
    for pdim in PROJECTION_DIM:
        fam = f"{family_prefix}_{fam_n}"
        fam_n += 1
        log(f"[autotune] building family {fam}: proj={pdim} seeds={max_seeds} "
            f"(active_seeds swept per-query against this one build)")
        _build_family(db, fam, rows, pdim, full_seeds, max_nnz, source_dim)
        oracle = _build_oracle(db, fam, query_ids, k)

        # Free active_seeds sweep against this one oracle: 4 -> 8 -> 16.
        for n_active in ACTIVE_SEED_COUNTS:
            cfg = Config(projection_dim=pdim, active_seeds=_seeds(n_active),
                         max_nnz_per_row=max_nnz, k=k)
            recall = _measure(db, fam, oracle, cfg)
            sweep.append(Trial(cfg, recall))
            log(f"[autotune]   {cfg.label()} -> recall {recall:.4f}")
            if recall > best_recall:
                best_recall, best = recall, cfg
            if recall >= gate:
                log(f"[autotune] GATE CLEARED at {cfg.label()} "
                    f"(recall {recall:.4f})")
                return Result(
                    best=cfg, best_recall=recall, gate=gate, sweep=sweep,
                    derived_max_nnz=max_nnz,
                    verdict=f"cleared gate {gate} at {cfg.label()}",
                )

        # If voting over more seeds did not move recall at this width, the guide
        # says the projection width is the bottleneck — the outer loop's next step
        # (a wider projection) is exactly that escalation.
        width_trials = [t.recall for t in sweep[-len(ACTIVE_SEED_COUNTS):]]
        spread = max(width_trials) - min(width_trials)
        if spread < 0.005:
            log(f"[autotune]   more seeds barely moved recall "
                f"(spread {spread:.4f}) at proj={pdim} — the projection width is "
                "the bottleneck; escalating projection_dim.")

    verdict = (
        f"NO config reached the {gate} gate. Best found: {best.label() if best else 'none'} "
        f"at recall {best_recall:.4f}. This IS the evidence for an intrinsic limit — "
        "the full sweep (active_seeds x projection_dim) was run and reported. If you "
        "still need a map, force past the gate documenting this recall, or revisit "
        "the keys upstream (the reservoir / sparsity that produced them)."
    )
    log(f"[autotune] {verdict}")
    return Result(best=best, best_recall=best_recall, gate=gate, sweep=sweep,
                  derived_max_nnz=max_nnz, verdict=verdict)

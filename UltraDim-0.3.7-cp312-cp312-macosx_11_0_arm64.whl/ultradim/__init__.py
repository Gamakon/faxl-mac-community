"""UltraDim — the Gamakon vector database, embedded (clean build).

The database engine is the compiled PyO3 extension `ultradim._ultradim`; this
package re-exports its public surface so the shipped contract is unchanged:

    import ultradim
    db = ultradim.UltraDim(path)          # the engine, as always
    ultradim.__version__                  # the wheel version

The auto-tuner ships alongside the engine in this same wheel:

    from ultradim.autotune import autotune, SparseRow
    result = autotune(db, rows, gate=0.99)

See docs/UltraDim_Tuning_Guide.md for the discipline it automates.
"""
from ._ultradim import UltraDim, __version__

from . import autotune

__all__ = ["UltraDim", "__version__", "autotune"]
